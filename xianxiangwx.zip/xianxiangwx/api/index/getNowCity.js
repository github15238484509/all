import request from '@/api/request.js'


function getNowCity(data) {
	return request({
		url: '/index/city_name',
		method: 'POST',
		data
	})
}




export default {
	getNowCity
	
}