import request from '@/api/request.js'

function goodsList(data) {
	return request({
		url: '/Goods/merchant_goods_list',
		method: 'POST',
		data
	})
}





export default {
	goodsList
}