import request from '@/api/request.js'
//  商品详情页
function banner(data) {
	return request({
		url: '/index/banner',
		method: 'GET',
		data
	})
}





export default {
	banner
}