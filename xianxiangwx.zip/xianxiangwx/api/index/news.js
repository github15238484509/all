import request from '@/api/request.js'
//  商品详情页
function news(data) {
	return request({
		url: '/index/news',
		method: 'POST',
		data
	})
}





export default {
	news
}