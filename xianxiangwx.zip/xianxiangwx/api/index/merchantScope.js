
import request from '@/api/request.js'
//  商品详情页
function merchantScope(data) {
	return request({
		url: '/Merchant/scope',
		method: 'GET',
		data
	})
}





export default {
	merchantScope
}