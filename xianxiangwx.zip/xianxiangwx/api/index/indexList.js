import request from '@/api/request.js'
//  商品详情页
function merchant_detail(data) {
	return request({
		url: '/Merchant/merchant_detail',
		method: 'POST',
		data
	})
}

function affirmPay(data) {
	return request({
		url: '/task/affirmPay',
		method: 'POST',
		data
	})
}
function taskPay(data) {
	return request({
		url: '/pay/taskPay',
		method: 'POST',
		data
	})
}
function merchant_logo(data) {
	return request({
		url: '/merchant/merchant_logo',
		method: 'POST',
		data
	})
}
function addTask(data) {
	return request({
		url: '/task/addTask',
		method: 'POST',
		data
	})
}
function indexList(data) {
	return request({
		url: '/Merchant/merchant_list',
		method: 'POST',
		data
	})
}

function toker_list(data) {
	return request({
		url: '/Index/toker_list',
		method: 'POST',
		data
	})
}
//  商品列表
function user_merchant_list(data) {
	return request({
		url: '/Merchant/user_merchant_list',
		method: 'POST',
		data
	})
}

//  用户信息
function referrer(data) {
	return request({
		url: '/login/referrer',
		method: 'POST',
		data
	})
}
//  发布动态
function addTokerCircle(data) {
	return request({
		url: '/toker/addTokerCircle',
		method: 'POST',
		data
	})
}
// 拓客员申请缴费
function tokerPay(data) {
        return request({
                url: '/pay/tokerPay',
                method: 'POST',
                data
        })
}
// 拓客员申请缴费
function img(data) {
        return request({
                url: '/index/img',
                method: 'POST',
                data
        })
}


export default {
	indexList,
	toker_list,
	referrer,
	addTokerCircle,
	user_merchant_list,
	merchant_detail,
	addTask,
	merchant_logo,
	affirmPay,
	taskPay,
	tokerPay,
	img
	
}