import request from '@/api/request.js'
//登录
function merchant_pay(data) {
	return request({
		url: '/Merchant/merchant_pay',
		method: 'GET',
		data
	})
}
// 添加商品接口 
function getAgentGoodsDetail(data){
	return request({
		url: '/Goods/agent_goods_list',
		method: 'post',
		data
	})
}
// 代理商更改商家商品状态
function changeAgentType(data){
	return request({
		url: '/Goods/agent_examine_goods',
		method: 'post',
		data
	})
}

function getCommodity(data){
	return request({
		url: '/Goods/goods_list',
		method: 'post',
		data
	})
}
function getCommodityDetail(data){
	return request({
		url: '/Goods/goods_detail',
		method: 'post',
		data
	})
}
function getCommodityPut(data){
	return request({
		url: '/Goods/goods_save',
		method: 'post',
		data
	})
}
//商户详情
function merchant_detail(data){
	return request({
		url: '/Merchant/merchant_detail',
		method: 'post',
		data
	})
}

//代理商审核商户
function merchant_examine(data){
	return request({
		url: '/Merchant/merchant_examine',
		method: 'post',
		data
	})
}

//代理商提交的商户列表
function agent_merchant_list(data){
	return request({
		url: '/Merchant/agent_merchant_list',
		method: 'post',
		data
	})
}


//获取城市信息
function city(data){
	return request({
		url: '/Index/city',
		method: 'post',
		data
	})
}
//商品列表
function agent_goods_list(data){
	return request({
		url: '/Goods/agent_goods_list',
		method: 'post',
		data
	})
}
//商品列表
function merchant_order_branch(data){
	return request({
		url: '/Order/merchant_order_branch',
		method: 'post',
		data
	})
}

//代理商主页信息
function user_merchant_revenue(data){
	return request({
		url: '/User/user_revenue',
		method: 'post',
		data
	})
}

//提现金额
function withdraw(data){
	return request({
		url: '/user/user_extract_money_detail',
		method: 'post',
		data
	})
}

//提现记录
function withdrawalRecord(data){
	return request({
		url: '/user/user_extract_list',
		method: 'post',
		data
	})
}

//提现规则
function rules(data){
	return request({
		url: '/user/user_extract_rule',
		method: 'post',
		data
	})
}


//查询用户绑定银行卡信息
function binkCard(data){
	return request({
		url: '/user/user_bank',
		method: 'post',
		data
	})
}

//得到代理商通过的商家
function agent_merchant_lists(data){
	return request({
		url: '/Merchant/agent_merchant_lists',
		method: 'post',
		data
	})
}

//用户余额变更记录
function user_cash_change(data){
	return request({
		url: '/user/user_cash_change',
		method: 'post',
		data
	})
}

//代理商充值商户需要多少套
function merchant_year(data){
	return request({
		url: '/merchant/merchant_year',
		method: 'post',
		data
	})
}

//代理商充值商户需要多少套
function merchant_recharge(data){
	return request({
		url: '/Merchant/merchant_recharge',
		method: 'post',
		data
	})
}

//店铺商品列表
function merchant_goods_list(data){
	return request({
		url: '/Goods/merchant_goods_list',
		method: 'post',
		data
	})
}


//用户绑定银行卡
function user_bank_bind(data){
	return request({
		url: 'user/user_bank_bind',
		method: 'post',
		data
	})
}
//业务员
// function user_bank_bind(data){
// 	return request({
// 		url: 'user/user_bank_bind',
// 		method: 'post',
// 		data
// 	})
// }

//银行卡列表
function bank_list(data){
	return request({
		url: '/Index/bank_list',
		method: 'GET',
		data
	})
}

//用户提现
function user_extract(data){
	return request({
		url: '/user/user_extract',
		method: 'POST',
		data
	})
}

//用户绑定微信查询
function user_wechant(data){
	return request({
		url: '/User/user_wechant',
		method: 'POST',
		data
	})
}

//用户绑定微信
function get_openid(data){
	return request({
		url: '/User/get_openid',
		method: 'POST',
		data
	})
}

//用户强制弹窗公告信息
function get_alert_news(data){
	return request({
		url: '/index/get_alert_news',
		method: 'POST',
		data
	})
}
function user_salesman_detail(data){
	return request({
		url: '/User/user_salesman_detail',
		method: 'post',
		data
	})
}

export default {
	merchant_pay,getAgentGoodsDetail,changeAgentType,getCommodity,getCommodityDetail,getCommodityPut,
	merchant_detail,
	merchant_examine,
	agent_merchant_list,
	city,
	agent_goods_list,
	merchant_order_branch,
	user_merchant_revenue ,
	withdraw,
	withdrawalRecord,
	rules,
	binkCard,
	agent_merchant_lists,
	user_cash_change,
	merchant_year,
	merchant_recharge,
	merchant_goods_list,
	user_bank_bind,
	bank_list,
	user_extract,
	user_wechant,
	get_openid,
	get_alert_news,
	user_salesman_detail
}