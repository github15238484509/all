// const serveHost = 'http://localhost';
 // import settingFile from '@/baseurl.js'
 import qs from './qs.js';
 
 //获取当前服务器的路径    小程序无效
 // const baseurl =window.location.origin
	//!!!!!!!!上线的时候换这个baseurl
	//上线的时候换成正式接口根地址
   const baseurl ="https://test.jianyunkeji.net"
 

function http(options) {
	options.data = options.data || {}
	if(!options.data.token){ //没有携带token，自动携带token;
		options.data.token = uni.getStorageSync('xxytoken');
		// options.data.token = "12223161462052158";
	}
	return new Promise((resolve, reject) => {
		if (options.method.toLowerCase() == 'post') {
			// qs系列化  
			// https://www.npmjs.com/package/qs 
			//  arrayFormat: 'repeat' 作用:  { a: ['b', 'c'] }  ==> 'a=b&a=c'
			//  allowDots: true  作用: { a: { b: { c: 'd', e: 'f' } } }  ==>  'a.b.c=d&a.b.e=f'
			options.data = qs.stringify(options.data, {
				arrayFormat: 'repeat',
				allowDots: true
			})
		}
		
		
		var setting = {
			
			// url: settingFile.host + options.url,
			//下面配置了跨域   localurl 暂时没用到

			// #ifdef H5
			//本地开发用这个  这是h5的  方便调试用
			url: 'api'+options.url,
			// #endif
			
			// #ifdef MP-WEIXIN
			//线上/测试 用这个
			url:baseurl+'/XianxiangUapi/public/index.php/'+options.url,
			// #endif
			
			//如果不行 用test里的request111里的写法
			 // const baseurl = 'http://test.jianyunkeji.net/'   这个放页面上面
				// url: baseurl +'/tpapi/public/index.php/'+options.url,
			
		
			data: options.data,
			method: options.method.toUpperCase() || 'GET',
			timeout: 6000,
			header: {
				'content-type': 'application/x-www-form-urlencoded', // from data
			},
			success(res) {
				resolve(res.data);
			},
			fail(err) {
				console.log('err',err);
				uni.showToast({
					icon:'none',
					title: '网络超时!'
				})
				
				
				reject(err);
			},
			
		}
		if (options.header) {
			setting.header = Object.assign(setting.header, options.header);
		}
		uni.request(setting);
	})
}
 

export default http;


// {
// 		url: '/api/leju/front/find/aritlceList',
// 		method: 'get',
// 		data,
// 		header: {
	// xxx:xxx
// }
// 	}
// function foo(options){
// 	return new Promise((resolve,reject)=>{
	// 	requestSttting = {
	// 	    url: options.url, //仅为示例，并非真实接口地址。
	// 		method: options.method.toUpperCase(),
	// 	    data: option.data,
	// 	    header: {
	// 	        'custom-header': 'hello' //自定义请求头信息
	// 	    },
	// 	    success: (res) => {
		       
	// 	        tvar text = 'request success';
	// 			resolve(text);
	// 	    },
	// 		fail: (err)=>{
	// 			reject(err)
	// 		}
	// 	}
	// 	if(options.header){
	// 			requestSttting.header = Object.assign(requestSttting.header,options.header)
	// 	}
	// 	uni.request(requestSttting);
	// })
// }


