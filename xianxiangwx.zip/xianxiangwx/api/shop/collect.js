import request from "../request.js"

function collect(data) {
	return request({
		url: '/Merchant/user_merchant_focus',
		method: 'POST',
		data
	})
}



export default{
	collect
}