import request from '@/api/request.js'
//  商品详情页
function shopHome(data) {
	return request({
		url: '/Merchant/merchant_detail',
		method: 'POST',
		data
	})
}





export default {
	shopHome
}