import request from '@/api/request.js';

// 添加商品接口 
function getAgentGoodsDetail(data){
	return request({
		url: '/Goods/agent_goods_list',
		method: 'post',
		data
	})
}
// 代理商更改商家商品状态
function changeAgentType(data){
	return request({
		url: '/Goods/agent_examine_goods',
		method: 'post',
		data
	})
}
export default{
	getAgentGoodsDetail,changeAgentType
}