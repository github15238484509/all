import request from '@/api/request.js';

// 查询代理商业务员页面 
function getSalesman(data){
	return request({
		url: '/User/salesman_list',
		method: 'post',
		data
	})
}
function getSalesmanList(data){
	return request({
		url: '/User/user_salesman',
		method: 'post',
		data
	})
}
function user_salesman_detail(data){
	return request({
		url: '/User/user_salesman_detail',
		method: 'post',
		data
	})
}

export default{
	getSalesman,getSalesmanList,user_salesman_detail
}