import request from '@/api/request.js'
//  商品详情页
function applysSalesManIn(data) {
	return request({
		url: '/User/apply_salesman',
		method: 'POST',
		data
	})
}
function applysSalesManStatus(data) {
	return request({
		url: '/User/user_salesman_status',
		method: 'POST',
		data
	})
}
function applyTokerManIn(data) {
        return request({
                url: '/User/apply_toker',
                method: 'POST',
                data
        })
}


export default {
	applysSalesManIn,applysSalesManStatus,applyTokerManIn
}