import request from '@/api/request.js'
//  商品详情页
function aliImg(data) {
	return request({
		url: '/index/ali_picture',
		method: 'GET',
		data
	})
}





export default {
	aliImg
}