import request from '@/api/request.js'
//  个人信息
function referrer(data) {
	return request({
		url: '/login/referrer',
		method: 'GET',
		data
	})
}
//  团队长商户列表
function taskList(data) {
	return request({
		url: '/task/taskList',
		method: 'POST',
		data
	})
}
//  任务详情
function taskDetail(data) {
	return request({
		url: '/task/taskDetail',
		method: 'POST',
		data
	})
}
//  分享
function shareTask(data) {
	return request({
		url: '/task/shareTask',
		method: 'POST',
		data
	})
}

//放弃任务
function deleteTask(data) {
	return request({
		url: '/task/deleteTask',
		method: 'POST',
		data
	})
}
//开始接单
function acceptTask(data) {
	return request({
		url: '/task/acceptTask',
		method: 'POST',
		data
	})
}
//查看报名
function checkApply(data) {
	return request({
		url: '/toker/checkApply',
		method: 'POST',
		data
	})
}
//编辑任务
function updateTask(data) {
	return request({
		url: '/task/updateTask',
		method: 'POST',
		data
	})
}
//拓客员详情
function tokerDetail(data) {
	return request({
		url: '/toker/tokerDetail',
		method: 'POST',
		data
	})
}
//审核拓客员
function auditToker(data) {
	return request({
		url: '/toker/auditToker',
		method: 'POST',
		data
	})
}
//开启任务
function startTask(data) {
	return request({
		url: '/task/startTask',
		method: 'POST',
		data
	})
}
//开启招募
function recruitTask(data) {
	return request({
		url: '/task/recruitTask',
		method: 'POST',
		data
	})
}
//关闭招募
function closeTask(data) {
	return request({
		url: '/task/closeTask',
		method: 'POST',
		data
	})
}
//拓客员收入客户列表
function checkCustomer(data) {
	return request({
		url: '/toker/checkCustomer',
		method: 'POST',
		data
	})
}
//提交任务接口
function submitTask(data) {
	return request({
		url: '/task/submitTask',
		method: 'POST',
		data
	})
}
//拓客员任务列表
function tokerTaskList(data) {
	return request({
		url: '/task/tokerTaskList',
		method: 'POST',
		data
	})
}
//拓客员报名任务
function applyTask(data) {
	return request({
		url: '/toker/applyTask',
		method: 'POST',
		data
	})
}
//拓客员审核进度
function checkStatus(data) {
	return request({
		url: '/toker/checkStatus',
		method: 'POST',
		data
	})
}
//取消任务
function giveUpTask(data) {
	return request({
		url: '/task/giveUpTask',
		method: 'POST',
		data
	})
}

//提交任务
function taskSettlementPay(data) {
	return request({
		url: '/pay/taskSettlementPay',
		method: 'POST',
		data
	})
}

export default {
	referrer,
	taskList,
	taskDetail,
	shareTask,
	deleteTask,
	acceptTask,
	checkApply,
	updateTask,
	tokerDetail,
	auditToker,
	startTask,
	recruitTask,
	closeTask,
	checkCustomer,
	submitTask,
	tokerTaskList,
	applyTask,
	checkStatus,
	giveUpTask,
	taskSettlementPay
}