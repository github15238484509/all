import request from '@/api/request.js';

//用户信息
function referrer(data){
	return request({
		url: '/login/referrer',
		method: 'post',
		data
	})
}

//客户列表
function goods_list(data){
	return request({
		url: 'toker/clientList',
		method: 'post',
		data
	})
}

//客户详情
function get_clent_detail(data){
	return request({
		url: 'toker/clientDetail',
		method: 'post',
		data
	})
}

//审核客户
function set_audit(data){
	return request({
		url: 'toker/auditClient',
		method: 'post',
		data
	})
}

//录入客户信息
function add_client(data){
	return request({
		url: '/toker/inputCustomer',
		method: 'post',
		data
	})
}

//添加客户数量信息
 function add_client_number(data){
	return request({
		url: 'task/addCustomer',
		method: 'post',
		data
	})
}


//获取是否可以录入客户
function get_add_client(data){
	return request({
		url: 'toker/taskConduct',
		method: 'post',
		data
	})
}

//增加客户数量支付
function taskPay(data){
	return request({
		url: 'pay/taskAddClientPay',
		method: 'post',
		data
	})
}

    

export default {
	referrer,
	goods_list,
	get_clent_detail,
	set_audit,
	add_client,
	get_add_client,
	add_client_number,
	taskPay
}