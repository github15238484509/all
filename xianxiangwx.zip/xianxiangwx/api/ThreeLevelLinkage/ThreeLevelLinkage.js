import request from "../request.js"

function threeLevelLink(data) {
	return request({
		url: '/Index/city_list',
		method: 'POST',
		data
	})
}



export default{
	threeLevelLink
}