import request from '@/api/request.js';

//获取入驻行业
function getselectInDustry(data){
        return request({
                url: '/Merchant/scope',
                method: 'get',
                data
        })
}
//业务员，代理商商户列表
function getMerchant(data) {
	return request({
		url: '/Merchant/user_merchant_list',
		method: 'post',
		data
	})
}


function setTlement(data) {
	return request({
		url: 'Merchant/settlement',
		method: 'post',
		data
	})
}

//  商品详情页
function shopHome(data) {
	return request({
		url: '/Merchant/merchant_detail',
		method: 'POST',
		data
	})
}

//  商品详情页
function goodsList(data) {
	return request({
		url: '/Goods/goods_list',
		method: 'POST',
		data
	})
}

//查询用户代理商信息
function salesman_agent(data) {
	return request({
		url: '/User/salesman_agent',
		method: 'POST',
		data
	})
}

//业务员，代理商商户列表
function user_merchant_list(data) {
	return request({
		url: '/Merchant/user_merchant_list',
		method: 'POST',
		data
	})
}
//首页商户商品列表
function merchant_goods_list(data) {
	return request({
		url: '/Goods/merchant_goods_list',
		method: 'POST',
		data
	})
}
// 查询录入手机号的状态
function user_status(data){
	return request({
		url:"/Merchant/user_settlement_detail",
		method:"POST",
		data
	})
}

// 查询业务员入驻状态
function user_settlement_detail(data){
	return request({
		url:"/user/user_settlement_detail",
		method:"POST",
		data
	})
}

// 查询业务员详情
function user_salesman(data){
	return request({
		url:"/User/user_salesman",
		method:"POST",
		data
	})
}

// 查询拓客员入驻状态
function user_tockStatus(data){
        return request({
                url:"/user/apply_status",
                method:"POST",
                data
        })
}
function user_salesman_detail(data){
	return request({
		url: '/User/user_salesman_detail',
		method: 'post',
		data
	})
}
function user_salesman_status(data) {
        return request({
                url: '/User/user_salesman_status',
                method: 'POST',
                data
        })
}
export default{
        getselectInDustry,
		getMerchant,
		setTlement,
		shopHome,
		goodsList,
		salesman_agent,
		user_merchant_list,
		merchant_goods_list,
		user_status,
		user_settlement_detail,
		user_salesman,
		user_tockStatus,
		user_salesman_detail,
		user_salesman_status
}

