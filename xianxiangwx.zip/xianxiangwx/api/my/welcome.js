
import request from '@/api/request.js'

function welcome(data) {
	return request({
		url: '/login/referrer',
		method: 'post',
		data
	})
}

function getAliId(data) {
	return request({
		url: '/login/ali_login',
		method: 'post',
		data
	})
}






export default {
	welcome,getAliId
}