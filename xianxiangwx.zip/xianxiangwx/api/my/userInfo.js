import request from '@/api/request.js'

function userInfo(data) {
	return request({
		url: '/login/referrer',
		method: 'post',
		data
	})
}
function logout(data) {
	return request({
		url: '/login/logout',
		method: 'post',
		data
	})
}

function cancelBind(data) {
	return request({
		url: '/User/user_ali_unbind',
		method: 'post',
		data
	})
}


function bindAli(data) {
	return request({
		url: '/User/user_ali_bind',
		method: 'post',
		data
	})
}


function cancelBindWX(data) {
	return request({
		url: '/user/user_wechat_unbind',
		method: 'post',
		data
	})
}


export default {
	userInfo,logout,cancelBind,bindAli,cancelBindWX
}