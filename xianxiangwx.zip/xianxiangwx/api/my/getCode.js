import request from '@/api/request.js'
//  商品详情页
function getCode(data) {
	return request({
		url: '/login/verification_code',
		method: 'POST',
		data
	})
}





export default {
	getCode
}