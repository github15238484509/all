import request from '@/api/request.js'

function changePhone(data) {
	return request({
		url: '/User/user_save_phone',
		method: 'post',
		data
	})
}

function changeName(data) {
	return request({
		url: '/User/user_save_name',
		method: 'post',
		data
	})
}

function changeAvatar(data) {
	return request({
		url: '/User/user_save_photo',
		method: 'post',
		data
	})
}

function changeSex(data) {
	return request({
		url: '/User/user_save_sex',
		method: 'post',
		data
	})
}





export default {
	changePhone,changeName,changeAvatar,changeSex
}