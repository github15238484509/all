import request from '@/api/request.js'

function messageList(data) {
        return request({
                url: '/user/messageList',
                method: 'post',
                data
        })
}
function clear(data){
        return request({
                url: '/user/clear_message',
                method: 'post',
                data
        })
}



export default {
        messageList,clear
}