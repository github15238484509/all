import request from '@/api/request.js';

// 修改个人信息
function set_user_edit(data){
	return request({
		url: '/user/set_user_edit',
		method: 'post',
		data
		
	})
}
// 获取个人信息
function get_user_info(data){
	return request({
		url: '/login/get_user_info',
		method: 'post',
		data

	})
}
// 关于我们
function aboutWe(){
	return request({
		url: '/index/about_us',
		method: 'get'
		
	})
}
//获取余额
function balance_info(data){  
	return request({
		url: '/user/user_extract_money_detail',
		method: 'POST',
		data
	})
}
//获取待结算 收入 支出
function user_cash_change(data){  
	return request({
		url: '/user/user_cash_change',
		method: 'POST',
		data
	})
}
//获取提现记录列表
function user_extract_list(data){  
	return request({
		url: '/user/user_extract_list',
		method: 'POST',
		data
	})
}
//获取提现规则
function withdrawal_rule(data){  
	return request({
		url: '/user/withdrawal_rule',
		method: 'POST',
		data
	})
}


//获取银行卡列表
function user_apply_extract(data){  
	return request({
		url: '/user/user_apply_extract',
		method: 'POST',
		data
	})
}

//查询绑定银行卡信息
function user_bank(data){  
	return request({
		url: '/user/user_bank',
		method: 'POST',
		data
	})
}
//获取银行卡列表
function bank_list(data){  
	return request({
		url: '/user/bank_list',
		method: 'GET',
		data
	})
}
//绑定银行卡
function user_bind_bank(data){  
	return request({
		url: '/user/user_bind_bank',
		method: 'POST',
		data
	})
}
//  商品详情页
function help(data) {
        return request({
                url: '/index/help',
                method: 'GET',
                data
        })
}

//消息和帮助中心增加浏览记录
function browsingHistory(data) {
	return request({
		url: '/app/browsingHistory',
		method: 'post',
		data
	})
}
//浏览列表
function feedback(data){
        return request({
                url: '/index/feedback',
                method: 'post',
                data
        })
}

//  商品详情页
function feedbackList(data) {
        return request({
                url: '/index/feedbackList',
                method: 'post',
                data
        })
}
//  商品详情页
function feedbackDetail(data) {
        return request({
                url: '/index/feedbackDetail',
                method: 'post',
                data
        })
}
//  商品详情页
function faq(data) {
        return request({
                url: '/index/common_issue',
                method: 'GET',
                data
        })
}
//浏览列表
function browseList(data){
	return request({
		url: '/user/user_read',
		method: 'post',
		data
	})
}

function deleteBrowse(data){
	return request({
		url: '/user/delete_read',
		method: 'post',
		data
	})
}
//收藏列表 
function collectList(data){
	return request({
		url: '/user/user_collection',
		method: 'post',
		data
	})
}

function edit_collection(data){
	return request({
		url: '/user/edit_collection',
		method: 'post',
		data
	})
}
function get_comment(data){
	return request({
		url: '/user/user_comment',
		method: 'GET',
		data
	})
}
function user_address(data){
	return request({
		url: '/user/user_address',
		method: 'GET',
		data
	})
}
function get_province(data){
	return request({
		url: '/login/get_province',
		method: 'post',
		data
	})
}
function get_city(data){
	return request({
		url: '/login/get_city',
		method: 'post',
		data
	})
}
function get_district(data){
	return request({
		url: '/login/get_district',
		method: 'post',
		data
	})
}
function update_address(data){
	return request({
		url: '/user/update_address',
		method: 'post',
		data
	})
}
function edit_address(data){
	return request({
		url: '/user/edit_address',
		method: 'post',
		data
	})
}
function address_info(data){
	return request({
		url: '/user/address_info',
		method: 'post',
		data
	})
}
function user_invite(data){
	return request({
		url: '/user/user_invite',
		method: 'post',
		data
	})
}
function my_invitation(data){
	return request({
		url: '/user/my_invitation',
		method: 'post',
		data
	})
}
function upgrade_info(data){
	return request({
		url: '/user/upgrade_info',
		method: 'post',
		data
	})
}
function user_upgrade(data){
	return request({
		url: '/user/user_upgrade',
		method: 'post',
		data
	})
}
function user_team(data){
	return request({
		url: '/user/user_team',
		method: 'post',
		data
	})
}


export default {
	user_team,
	user_invite,
	user_upgrade,
	upgrade_info,
	my_invitation,
	address_info,
	edit_address,
	update_address,
	get_city,
	get_province,
	get_district,
	get_comment,
	get_user_info,
	set_user_edit,
	aboutWe,
	balance_info,
	user_cash_change,
	user_extract_list,
	withdrawal_rule,
	user_apply_extract,
	user_bank,
	bank_list,
	user_bind_bank,
	help,
	browsingHistory,
	feedback,
	feedbackList,
	feedbackDetail,
	faq,
	browseList,
	deleteBrowse,
	collectList,
	edit_collection,
	user_address
	
	
}