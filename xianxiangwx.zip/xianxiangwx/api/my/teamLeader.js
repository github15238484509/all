import request from '@/api/request.js'

function examineToke(data) {
	return request({
		url: '/toker/examineToker',
		method: 'post',
		data
	})
}

export default {
	examineToke
}