import request from '@/api/request.js'
//登录
function login(data) {
	return request({
		url: '/login/login',
		method: 'GET',
		data
	})
}
function earnings_statistics(data) {
    return request({
        url: '/login/earnings_statistics',
        method: 'post',
        data
    })
}
function wechat_login(data) {
	return request({
		url: '/login/wechat_login',
		method: 'GET',
		data
	})
}
//获取验证码
function getCode(data) {
	return request({
		url: '/login/phone_code',
		method: 'POST',
		data
	})
}
//获取验证码
function verification_code(data) {
	return request({
		url: '/login/verification_code',
		method: 'POST',
		data
	})
}
//判断是否是会员
function welcome(data) {
	return request({
		url: '/login/referrer',
		method: 'post',
		data
	})
}

//注册账户
function register(data) {
	return request({
		url: '/login/register',
		method: 'post',
		data
	})
}
//微信绑定注册
function wx_register(data) {
	return request({
		url: '/login/wx_register',
		method: 'post',
		data
	})
}


function news(data) {
	return request({
		url: '/index/news',
		method: 'post',
		data
	})
}

// 退出登录
function logout(data) {
	return request({
		url: '/login/logout',
		method: 'post',
		data
	})
}
function my_invite(data) {
	return request({
		url: '/login/my_invite',
		method: 'post',
		data
	})
}
function app_agreement(data) {
	return request({
		url: '/index/app_agreement',
		method: 'post',
		data
	})
}

function get_openid(data) {
	return request({
		url: '/User/get_openid',
		method: 'post',
		data
	})
}
function get_wechat(data) {
	return request({
		url: '/login/get_wechat',
		method: 'post',
		data
	})
}

export default {
	login,getCode,welcome,register,news,logout,verification_code,my_invite,app_agreement,get_openid,get_wechat,wx_register,wechat_login,earnings_statistics
}