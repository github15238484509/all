import request from '@/api/request.js';

// 添加商品接口 
function getOrderDetailList(data){
	return request({
		url: '/Order/order_detail',
		method: 'post',
		data
		
	})
}

export default{
	getOrderDetailList
}