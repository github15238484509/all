import request from '@/api/request.js';

// 添加商品接口 
function potCommercial(data){
	return request({
		url: '/Goods/settlement',
		method: 'post',
		data
	})
}

export default{
	potCommercial
}