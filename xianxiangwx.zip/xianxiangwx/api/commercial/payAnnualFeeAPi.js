import request from '@/api/request.js'

// 调用商家信息
function getCommercial(data){
	return request({
		url: '/Merchant/merchant_detail',
		method: 'post',
		data
	})
}
function getpayFee(data){
	return request({
		url: '/Merchant/merchant_pay',
		method: 'get',
		data
	})
}
export default{
	getCommercial,getpayFee
}