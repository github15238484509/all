import request from '@/api/request.js';

// 添加商品接口 
function getDeductionDetail(data){
	return request({
		url: '/Order/order_branch',
		method: 'post',
		data
	})
}

export default{
	getDeductionDetail
}