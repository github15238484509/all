import request from '@/api/request.js';

function getCommodity(data){
	return request({
		url: '/Goods/goods_list',
		method: 'post',
		data
	})
}
function getCommodityDetail(data){
	return request({
		url: '/Goods/goods_detail',
		method: 'post',
		data
	})
}
function getCommodityPut(data){
	return request({
		url: '/Goods/goods_save',
		method: 'post',
		data
	})
}
export default{
	getCommodity, getCommodityDetail,getCommodityPut
}