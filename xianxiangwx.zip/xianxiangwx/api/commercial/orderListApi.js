import request from '@/api/request.js';

// 添加商品接口 
function getOrderList(data){
	return request({
		url: '/Order/merchant_order_list',
		method: 'post',
		data
	})
}
// 查询商户营收记录 
function getOrderBranchList(data){
	return request({
		url: '/Order/merchant_order_branch',
		method: 'post',
		data
	})
}


export default{
	getOrderList,getOrderBranchList
}