import request from '@/api/request.js';

function getselectInDustry(data){
	return request({
		url: '/Merchant/scope',
		method: 'get',
		data
	})
}

export default{
	getselectInDustry
}