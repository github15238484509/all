import request from '@/api/request.js'

// 调用商家信息
function getCommercial(data){
	return request({
		url: '/Merchant/merchant_detail',
		method: 'post',
		data
	})
}
// 调取轮播图信息
function getbanner(data){
	return request({
		url: '/index/news',
		method: 'post',
		data
	})
}
// 修改商家信息接口 
function saveCommercial(data){
	return request({
		url: '/Merchant/merchant_save',
		method: 'post',
		data
	})
}
// 用地区名换取地区ID
function getCityId(data){
	return request({
		url: '/Index/city',
		method: 'post',
		data
	})
}
// 获取第三方授权二维码
function alipay_get_url(data){
	return request({
		url:"/Notify/alipay_get_url",
		method:"POST",
		data
	})
}

// 商户绑定分账授权
function relation_bind(data){
	return request({
		url:"/Notify/relation_bind",
		method:"POST",
		data
	})
}
// 商户营收记录
function businessRevenue(data){
	return request({
		url:"/Merchant/user_merchant_revenue",
		method:"POST",
		data
	})
}

// 商户营收记录
function merchant_auth_status(data){
	return request({
		url:"/Merchant/merchant_auth_status",
		method:"POST",
		data
	})
}

// 商户营收记录
function about_us(data){
	return request({
		url:"/index/about_us",
		method:"GET",
		data
	})
}
// 获取省市区
function get_province(data){
	return request({
		url:"/index/get_province",
		method:"GET",
		data
	})
}
function get_city(data){
	return request({
		url:"/index/get_city",
		method:"GET",
		data
	})
}
function get_district(data){
	return request({
		url:"/index/get_district",
		method:"GET",
		data
	})
}


export default{
	getCommercial,
	getbanner,
	saveCommercial,
	getCityId,	
	alipay_get_url,
	relation_bind,
	businessRevenue,
	merchant_auth_status,
	about_us,
	get_province,
	get_city,
	get_district
}