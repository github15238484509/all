import Vue from 'vue'
import App from './App'
import uView from "uview-ui";
Vue.use(uView);
Vue.config.productionTip = false

//身份是团队长
// uni.setStorageSync("xxytoken","5899851869347201223")

//身份是商户
// uni.setStorageSync("xxytoken","4810062088402811156")

//身份是拓客员1
// uni.setStorageSync("xxytoken","4810044987447502040")

//身份是拓客员2
// uni.setStorageSync("xxytoken","4810105466643816022")

//身份是业务员
// uni.setStorageSync("xxytoken","5899740327731170660")

//身份是代理商
// uni.setStorageSync("xxytoken","5896307074404201912")

//身份是普通会员
// uni.setStorageSync("xxytoken","4810098046578618128")
 
App.mpType = 'app'


const prePage = () => {
	let pages = getCurrentPages();
	let prePage = pages[pages.length - 2];
	// #ifdef H5
	return prePage;
	// #endif
	return prePage.$vm;
}
//cdn   正式服是cn结尾  测试服是net结尾
const cdnUrl = 'https://cdn.jianyunkeji.net/';
//图片路径拼接
const imgUrl = (url) => {
	let str = RegExp('http');
	// let str = RegExp('wxfile');
	let newUrl;
	//通过三元运算符进行判断该图片是否含有http域名，没有就拼接上去
	str.test(url) ? newUrl = url : newUrl = cdnUrl + url;
	return newUrl

}
const delimgUrl = (url) => {
	let str = RegExp('https://cdn.jianyunkeji.net/');
	let newUrl;
	str.test(url) ? newUrl = url.replace('https://cdn.jianyunkeji.net/', "") : newUrl = url;
	return newUrl
}

// 分转换成元的函数(固定保留两位小数)
const returnFloat = (value) => {
	let value1 = Math.round(parseFloat(value) * 100) / 10000;
	let xsd = value1.toString().split(".");
	if (xsd.length == 1) {
		value1 = value1.toString() + ".00";
		return value1;
	}
	if (xsd.length > 1) {
		if (xsd[1].length < 2) {
			value1 = value1.toString() + "0";
		}
		return value1;
	}
}
// 元转分(保留两位小数保留+-号)
const returnFloat1 = (value) => {
	let value1 = Math.round(parseFloat(value) * 100) / 10000;
	let xsd = value1.toString().split(".");
	if (xsd.length == 1) {
		value1 = value1.toString() + ".00";
		if (parseFloat(value1) > 0) {
			return '+' + value1;
		} else {
			return value1
		}
	}
	if (xsd.length > 1) {
		if (xsd[1].length < 2) {
			value1 = value1.toString() + "0";
		}
		if (parseFloat(value1) > 0) {
			return '+' + value1;
		} else {
			return value1
		}
	}
};
//图片上传路径   支付宝里不能动态获取 这里回头写成固定
// const uptBaseUrl=window.location.origin

// const uptImgUrl="http://app.jianyunkeji.cn/tpadmin/public/supplier.php/Upload/img"
const uptImgUrl = "https://test.jianyunkeji.net/XianxiangUapi/public/index.php/index/img"
// 上传图片路径    正式服上传图片路径也要写死 不能动态获取服务器 阿里小程序不支持
// const uptImgUrl=uptBaseUrl+"/tpadmin/public/supplier.php/Upload/img"

Vue.prototype.$cdnUrl = cdnUrl;
// Vue.prototype.$navTo = navTo;
Vue.prototype.$prePage = prePage;
Vue.prototype.$uptImgUrl = uptImgUrl;
Vue.prototype.$imgUrl = imgUrl;
Vue.prototype.$delimgUrl = delimgUrl;
Vue.prototype.$returnFloat = returnFloat;
Vue.prototype.$returnFloat1 = returnFloat1;

const time = (timestamp, num) => {

	timestamp = timestamp + '';
	timestamp = timestamp.length == 10 ? timestamp * 1000 : timestamp;
	var date = new Date(timestamp);
	var y = date.getFullYear();
	var m = date.getMonth() + 1;
	m = m < 10 ? ('0' + m) : m;
	var d = date.getDate();
	d = d < 10 ? ('0' + d) : d;
	var h = date.getHours();
	h = h < 10 ? ('0' + h) : h;
	var minute = date.getMinutes();
	var second = date.getSeconds();
	minute = minute < 10 ? ('0' + minute) : minute;
	second = second < 10 ? ('0' + second) : second;
	if (num == 0) {
		return y + '-' + m + '-' + d;
	}
	if (num == 1) {
		return y + '-' + m + '-' + d + ' ' + h + ':' + minute + ':' + second;
	}
	if (num == 2) {
		return y + '-' + m + '-' + d + ' ' + h + ':' + minute;
	}
	if (num == 3) {
		return h + ':' + minute + ':' + second;
	}
	if (num == 4) {
		return h + ':' + minute;
	}
}
const timeConvert = (timestamp, num) => {

	timestamp = timestamp + '';
	timestamp = timestamp.length == 10 ? timestamp * 1000 : timestamp;
	var date = new Date(timestamp);
	var y = date.getFullYear();
	var m = date.getMonth() + 1;
	m = m < 10 ? ('0' + m) : m;
	var d = date.getDate();
	d = d < 10 ? ('0' + d) : d;
	var h = date.getHours();
	h = h < 10 ? ('0' + h) : h;
	var minute = date.getMinutes();
	var second = date.getSeconds();
	minute = minute < 10 ? ('0' + minute) : minute;
	second = second < 10 ? ('0' + second) : second;
	if (num == 0) {
		return y + '-' + m + '-' + d;
	} else {
		return y + '-' + m + '-' + d + ' ' + h + ':' + minute + ':' + second;
	}
}
Vue.prototype.$timeConvert = timeConvert;
Vue.prototype.$time = time;
const app = new Vue({
	...App
})
app.$mount()
