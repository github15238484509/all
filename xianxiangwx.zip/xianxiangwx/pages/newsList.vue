<template>
	<view class="main-box">
		<view class="news-box" v-if="newsList.length>0">
			<view class="news-item" v-for="(item,index) in newsList" @click="toDetail(item.content,item.title)">
				
				<view class="line">
					{{item.title}}
				</view>
				<u-icon name="arrow-right" color="#999999"  size="32" style="margin-right:60rpx ;"></u-icon>
				
			</view>	
		</view>
		<view v-else style="text-align: center;margin-top: 300rpx;">
			<img :src="cdnUrl+'XianxiangUapi/static/datanull.png'" alt="" style="width: 480rpx;height: 360rpx;" >
		</view>
	</view>
</template>

<script>
	import loginApi from "../api/login/login.js"
	export default {
		data() {
			return {
                cdnUrl:"",
				newsList:[],
				status:"",
			}
		},
		onLoad(e) {
            this.cdnUrl=this.$cdnUrl
			this.status=e.status
			loginApi.news({
				region: this.status
			}).then(res => {
				console.log(res.result)
				this.newsList = res.result
			})
			
		},
		methods: {
			toDetail(url,title){
				
				uni.navigateTo({
					url:'./newsDetail?url='+url+'&title='+title
				})
			}
		}
	}
</script>
<style>
	page{
		background-color: #F5F5F5;
	}
</style>
<style lang="scss" scoped>
	.main-box{
		
	}
	.news-box{
		margin-top: 20rpx;
	}
	.news-item{
		display: flex;
		justify-content: space-between;
		line-height: 83rpx;
		height: 83rpx;
		font-size: 26rpx;
		padding: 0 30rpx;
		width: 750rpx;
		background-color: #FFFFFF;
		border-bottom: 1rpx solid #F5F5F5;
		.line{
			width: 680rpx;
			 white-space: nowrap;
								    text-overflow: ellipsis;
								    overflow: hidden;
								    word-break: break-all;
		}
	}

</style>
