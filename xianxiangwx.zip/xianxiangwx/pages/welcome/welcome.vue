<template>
	<view class="main">
		<view class="content">
			<view class="top">
				欢迎使用
			</view>
			<view class="btm">
				<view class="img">
					<image src="../../static/user-blue.png" mode="aspectFill"></image>
				</view>
				<view class="ipt">
					<input maxlength='11' type="number" v-model="phoneNum" placeholder="请输入手机号"
						placeholder-style="color:#999999;font-size: 30rpx" />
				</view>

			</view>
			<view class="line">

			</view>
		</view>
		<view class="xbtn-blue" @click="login">
			下一步
		</view>
		<view class="dl">
			<span></span>
			<view class="font-26" style="color: #999999; ">微信快捷登录</view>
			<span></span>
		</view>
		<view class="dl2">
			<image src="../../static/wxdl.png" style="width: 100rpx;height: 100rpx;"
				@click="$u.throttle(getUserInfo,1000)"></image>
		</view>

		<view style="display: flex;justify-content: center;width: 100%;">
			<view class="font">{{con}}</view>
			<view class="qr" style="position: fixed;bottom:70rpx;"><img :src="$imgUrl(aboutsUs.small_logo)" alt="">
			</view>
			<view class="smallfont" style="position: fixed;bottom: 30rpx;">{{aboutsUs.copyright}}</view>
		</view>
	</view>
</template>

<script>
	import commerciaCentreApi from "../../api/commercial/commerciaCentreApi.js"
	import welcomeApi from "../../api/login/login.js"
	export default {
		data() {
			return {
				phoneNum: "",
				time: 0,
				issend: false,
				merchant_id: "",
				money: "",
				token: "",
				userPhone: "",
				aboutsUs: {}, //公司信息
				code: "",
				openid: '',
				session_key: '',
				unionid: '',
				userInfo: {},
				sex: ""
			};
		},
		onLoad() {

			this.token = uni.getStorageSync("xxytoken")
			if (this.token != "") {
				// welcomeApi.welcome({
				// 	token: this.token
				// }).then(res => {
				// if (res.status == 200) {
				// 	if (res.result.rank == 2) {
				// 		uni.reLaunch({
				// 			url: "../../salesmanCenter/salesmanCenter"
				// 		})
				// 	} else if (res.result.rank == 3) {
				// 		uni.reLaunch({
				// 			url: "../../agentCentre/agentCentre?userPhone"
				// 		})
				// 	} else if (res.result.rank == 4) {
				// 		uni.reLaunch({
				// 			url: "../../salesmanCommercial/commercialCentre?userPhone"
				// 		})
				// 	}
				// }
				// })
				uni.reLaunch({
					url: '../../pagesB/pages/index/index/index'
				});
			}
			commerciaCentreApi.about_us().then(res => {
				if (res.status == 200) {
					this.aboutsUs = res.result
				} else {

				}
			})
			this.init()
			// console.log(e)
			// if (e.merchant_id) {
			// 	this.merchant_id = e.merchant_id
			// }
			// if (e.money) {
			// 	this.money = e.money
			// }
			// //token过期 重新登录过来带过来的商家id
			// if (e.relogMid) {
			// 	this.merchant_id = e.relogMid
			// }
		},
		methods: {
			getUserInfo() {
				console.log(1111)
				uni.getUserProfile({
					desc: "获取用户信息",
					success: res => {
						console.log(res)
						
						if (res.userInfo) {
							this.userInfo = res.userInfo
							this.userInfo.openId = this.openid
							if (this.userInfo.gender == 1) {
								this.sex = '男'
							} else {
								this.sex = '女'
							}
							welcomeApi.wechat_login({
								
								openid:this.userInfo.openId,
							}).then(res => {
							        console.log(res)
							        if (res.status == 200) {
										uni.setStorageSync("xxytoken",res.result.token)
										uni.reLaunch({
											url: '../../pagesB/pages/index/index/index'
										})
							        } else {
							              uni.navigateTo({
							              	url: "../../pagesB/pages/login/login2?item=" + encodeURIComponent(JSON.stringify(this
							              		.userInfo))
							              }) 
							        }
							})
							
						}
					},
					fail(err) {
						console.log(err)
					}
				})
			},
			init() {
				// console.log(1111);
				let self = this
				uni.login({
					success: res => {
						// 发送 res.code 到后台换取 openId, sessionKey, unionId
						self.code = res.code;
						// console.log(self.code);
						self.getOpenId()
						// self.getUserInfo()
					}
				})
			},
			getOpenId() {
				welcomeApi.get_wechat({
					code: this.code
				}).then(res => {
					if (res.status == 200) {
						console.log(res);
						this.openid = res.result.openid;
						this.session_key = res.result.session_key
						this.unionid = res.result.unionid
					}
				})
			},
			login() {
				if (!/(^1[3|4|5|6|7|8|9][0-9]{9}$)/.test(this.phoneNum)) {
					uni.showToast({
						title: '请输入正确的手机号码',
						icon: 'none'
					});
					return;
				}
				uni.setStorageSync('userPhone', this.phoneNum);
				welcomeApi.welcome({
					phone: this.phoneNum
				}).then(res => {
					if (res.result.type == 2) {
						welcomeApi.verification_code({
							phone: this.phoneNum,
							verification_type: 2
						}).then(res => {
							if (res.status == 200) {
								uni.navigateTo({
									url: '../../pagesB/pages/login/login?phoneNum=' + this.phoneNum
								})
							} else {
								uni.showToast({
									title: res.message,
									icon: 'none'
								})
							}
						})
					} else if (res.result.type == 1) {
						welcomeApi.verification_code({
							phone: this.phoneNum,
							verification_type: 1
						}).then(res => {
							if (res.status == 200) {
								uni.navigateTo({
									url: '../../pagesB/pages/login/login1?phoneNum=' + this.phoneNum
								})
							} else {
								uni.showToast({
									title: res.message,
									icon: 'none'
								})
							}
						})
					} else {
						uni.showToast({
							title: res.message,
							icon: 'none'
						})
					}
				});

			}
		},
		filters: {
			handleNum(p) {
				if (p) {
					return p.substring(0, 3) + '****' + p.substring(p.length - 4);
				}
			}
		}

	}
</script>
<style>
	page {
		background: #FFFFFF
	}
</style>
<style lang="scss" scoped>
	.dl {
		display: flex;
		justify-content: center;
		margin-bottom: 30rpx;
		margin-top: 117rpx;
		align-items: center;

		span {
			width: 60rpx;
			height: 1px;
			background: #CCCCCC;
		}

		.font-26 {
			margin-left: 20rpx;
			margin-right: 20rpx;
		}
	}

	.dl2 {
		display: flex;
		justify-content: center;
	}

	.font {
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #FFFFFF;
	}

	.qr>img {
		border-radius: 10rpx;
		width: 80rpx;
		height: 80rpx;
	}

	.smallfont {
		font-size: 18rpx;
		font-family: Microsoft YaHei;
		font-weight: 400;
	}

	.content {
		margin: 0 50rpx;
		font-family: PingFang SC;
		padding-top: 57rpx;

		.top {

			font-size: 56rpx;

			font-weight: bold;
			color: #222222;
			line-height: 66rpx;

		}

		.btm {
			display: flex;
			align-items: center;
			margin-top: 258rpx;


			.img {
				width: 38rpx;
				height: 46rpx;

				image {
					width: 100%;
					height: 100%;
				}
			}

			.ipt {
				margin-left: 40rpx;
				width: 500rpx;

			}

			.box {

				width: 165rpx;
				height: 60rpx;
				background: #E9EBEC;
				border-radius: 30rpx;
				text-align: center;
				line-height: 60rpx;
				margin-left: 190rpx;

			}
		}

		.line {
			margin-top: 16rpx;
			width: 650rpx;
			height: 1rpx;
			border-bottom: 1rpx solid #E0E0E0;
		}

		.ishidden {
			visibility: hidden
		}
	}

	.btn {
		width: 690rpx;
		height: 90rpx;


		image {
			width: 100%;
			height: 100%;
		}
	}

	.xbtn-blue {
		margin: 140rpx 30rpx 0;
	}

	.txt {
		width: 300rpx;
		margin: 187rpx auto 0;
		height: 30rpx;
		display: flex;
		align-items: center;
		color: #999999;

		.theline {
			width: 30rpx;
			height: 1rpx;
			background-color: #CCCCCC;
		}

	}

	.zfblogo {
		width: 100rpx;
		height: 100rpx;
		margin: 30rpx auto 0;

		image {
			width: 100%;
			height: 100%;
		}
	}

	.xxylogo {
		position: fixed;
		bottom: 60rpx;
		left: 50%;
		transform: translate(-50%, -50%);

		width: 80rpx;
		height: 80rpx;
		background: #EEEEEE;
		border-radius: 10rpx;

		image {
			width: 100%;
			height: 100%;

		}
	}

	.logotxt {
		position: fixed;
		bottom: 20rpx;
		left: 50%;
		transform: translate(-50%, -50%);
		// width: 500rpx;
		font-size: 18rpx;
		color: #999999;
	}
</style>
