<template>
	<view>
		<view style="position: relative;height: 260rpx;">
			<image :src="cdnUrl+'XianxiangUapi/static/my_header_bg.png'" class="myBg"></image>

			<view class="noLogin" v-if="showlogin">
				<view class="photo">
					<image @click="goSetting" :src="$imgUrl(user.photo)" mode="aspectFill"
						style="width: 100%;height: 100%;border-radius: 50%;">
						<!-- <image :src="$imgUrl(userObj.photo)" mode="aspectFill"  ></image> -->
					</image>
				</view>
				<view class="loginText" style="flex:1;display: flex;align-items: center;">
					<view style="height: 100%;">
						<view @click="goSetting"
							style="font-size: 36rpx;font-family: PingFang SC;font-weight: 500;color: #FFFFFF;">
							{{user.name? user.name : ''}}
						</view>
						<view @click="toTeam()"
							style="font-size: 26rpx;font-family: PingFang SC;font-weight: 400;color: #FFFFFF;margin-top: 20rpx;">
							{{ mobileFilter(user.phone)}}
						</view>

					</view>
					<view @click="goSetting" style="position: absolute;right: 56rpx;width: 74%;">
						<image src="../../../static/my/right_white.png" mode=""
							style="width: 17rpx;height: 32rpx;float: right;margin-right: 30rpx;">
						</image>
					</view>
				</view>
				<view class="rank">
					{{user.rank_name}}
				</view>
			</view>
			<view v-else>
				<view style="text-align:center;color: #fff;padding-top: 50rpx;">您还未登录哦~</view>
				<button class="loginBtn" @click='goLogin' plain="true"
					style="margin: 30rpx auto;color: #FFFFFF;">登录</button>
			</view>
		</view>


		<!-- 余额 -->
		<view class="money_manage">
			<view style="font-size:26rpx;color: #333333;font-weight:500">
				收益余额：
			</view>
			<view class="money_tit">
				<view style="font-size: 70rpx;color: #000000;font-weight: 500;">
					{{user.cash?$returnFloat(user.cash):"0.00"}}
				</view>
				<button class="right" @click='goMoney' plain="true">提现</button>
			</view>
		</view>

		<!-- 消息中心 -->
		<view class="root_noti">
			<image class='background-image' :src="cdnUrl+'XianxiangUapi/static/noti_bg.png'"></image>

			<!-- 弹性布局 -->
			<view class="content" style="display: flex;align-items: center;" @click='goNoti'>
				<image src="../../../static/my/noti_icon.png" mode=""
					style="width: 44rpx;height: 44rpx;margin-left: 41rpx;">
				</image>
				<text style="margin-left: 20rpx;color: #FFFFFF;">消息中心</text>
				<image src="../../../static/my/right_white.png" mode=""
					style="width: 17rpx;height: 32rpx;margin-left: 400rpx;"></image>
			</view>
		</view>

		<!-- 数据统计 -->
		<!-- 数据统计 -->
		<view class="root_msg">
			<view style="display: flex;justify-content: space-between;align-items: center;">
				<view v-if="rank==7"
					style="font-size: 30rpx;font-family: PingFang SC;color: #333333;font-weight:500;padding-left: 20rpx;padding-top: 20rpx;">
					团队收益数据
				</view>
				<view v-else
					style="font-size: 30rpx;font-family: PingFang SC;color: #333333;font-weight:500;padding-left: 20rpx;padding-top: 20rpx;">
					收益数据
				</view>
				<view style="display: flex;margin-right: 20rpx;margin-top: 10rpx;">
					<view :class="navTip==1?'selTip':'Tip'" class="tip1" @click="selTip(1)">全部</view>
					<view :class="navTip==2?'selTip':'Tip'" class="tip2" @click="selTip(2)">拓客费</view>
					<view :class="navTip==3?'selTip':'Tip'" class="tip3" @click="selTip(3)">体验课费用</view>
				</view>
			</view>

			<view class="view_row">
				<view class="bigView">
					<view
						style="font-size: 30rpx;font-family: PingFang SC;color: #333333;font-weight:400;text-align: center;margin-top: 60rpx;">
						{{today_money?$returnFloat(today_money):"0.00"}}
					</view>
					<view
						style="font-size: 30rpx;font-family: PingFang SC;color: #333333;font-weight:400;text-align: center;margin-top: 10rpx;">
						今日总收益（元）</view>
				</view>
				<view class="bigView">
					<view
						style="font-size: 30rpx;font-family: PingFang SC;color: #333333;font-weight:400;text-align: center;margin-top: 60rpx;">
						{{yesterday_money?$returnFloat(yesterday_money):"0.00"}}
					</view>
					<view
						style="font-size: 30rpx;font-family: PingFang SC;color: #333333;font-weight:400;text-align: center;margin-top: 10rpx;">
						昨日总收益（元）</view>

				</view>

			</view>
			<view class="view_row">
				<view class="bigView">

					<view
						style="font-size: 30rpx;font-family: PingFang SC;color: #333333;font-weight:400;text-align: center;margin-top: 60rpx;">
						{{month_money?$returnFloat(month_money):"0.00"}}
					</view>
					<view
						style="font-size: 30rpx;font-family: PingFang SC;color: #333333;font-weight:400;text-align: center;margin-top: 10rpx;">
						本月总收益（元）</view>
				</view>
				<view class="bigView">
					<view
						style="font-size: 30rpx;font-family: PingFang SC;color: #333333;font-weight:400;text-align: center;margin-top: 60rpx;">
						{{total_money?$returnFloat(total_money):"0.00"}}
					</view>
					<view
						style="font-size: 30rpx;font-family: PingFang SC;color: #333333;font-weight:400;text-align: center;margin-top: 10rpx;">
						累计总收益（元）</view>

				</view>

			</view>
		</view>

		<!-- 常用功能 -->
		<view class="courseAll" style="padding-bottom: 30rpx;">
			<view class="courseTitle">
				<text
					style="font-size: 30rpx;font-family: PingFang SC;font-weight: 500;color: #333333;padding-left: 20rpx;padding-top: 20rpx;">常用功能</text>
			</view>
			<view style="display: flex;flex-wrap: wrap;margin-top:27rpx">
				<view @click="taps(item.index)"
					style="display: flex;flex-direction: column;align-items: center;position:relative;width: 25%;margin-top:26rpx;"
					v-for="(item,index) in commonlyUsed" :key="index"
					v-if='index==0&&rank==1||index==1&&(rank==1||rank==6)||index==2&&rank==4||index==3&&rank==3||index==4&&rank==2||index>4||rank==1&&(index!=2&&index!=3)'>
					<image :src="item.img" mode="" style="width: 35rpx;height: 35rpx;"></image>
					<view v-if="index==4&&rank==1" class=""
						style="margin-top: 22rpx;font-size: 26rpx;font-family: PingFang SC;font-weight: 400;color: #333333;">
						申请业务员
					</view>
					<view v-else class=""
						style="margin-top: 22rpx;font-size: 26rpx;font-family: PingFang SC;font-weight: 400;color: #333333;">
						{{item.title}}
					</view>
					<button v-if="index ==6"
						style="opacity: 0;position: absolute;width: 100%;height: 100%;left: 0;top:0;" type="default"
						open-type="contact"></button>

				</view>
			</view>
		</view>

		<view style="height: 260rpx;"></view>

		<!-- 底部导航栏 start -->
		<view class="tabbar">
			<image :src="cdnUrl+'XianxiangUapi/static/tabbarbgc.png'" class="bgc"></image>
			<view class="box" v-show="tabbarAct==0" @click.stop="goTab(0)">
				<image :src="cdnUrl+'XianxiangUapi/static/tabbar1.png'" class="img"></image>
				<view class="text" style="color: #1576FF;">
					首页
				</view>
			</view>
			<view class="box" v-show="tabbarAct!==0" @click.stop="goTab(0)">
				<image :src="cdnUrl+'XianxiangUapi/static/tabbar1.png'" class="img"></image>
				<view class="text">
					首页
				</view>
			</view>

			<view class="box1" v-show="tabbarAct==1" @click.stop="goTab(1)">
				<image :src="cdnUrl+'XianxiangUapi/static/tabbarSel2.png'" class="img"></image>
				<view class="text" style="color: #1576FF;">
					任务
				</view>
			</view>
			<view class="box1" v-show="tabbarAct!==1" @click.stop="goTab(1)">
				<image :src="cdnUrl+'XianxiangUapi/static/tabbar2.png'" class="img"></image>
				<view class="text">
					任务
				</view>
			</view>
			<view class="box2" @click.stop="goTab(5)">
				<image :src="cdnUrl+'XianxiangUapi/static/backups.png'" class="img"></image>
				<view class="text">
					发布
				</view>
			</view>

			<view class="box3" v-show="tabbarAct==2" @click.stop="goTab(2)">
				<image :src="cdnUrl+'XianxiangUapi/static/tabbarSel3.png'" class="img"></image>
				<view class="text" style="color: #1576FF;">
					客户
				</view>
			</view>
			<view class="box3" v-show="tabbarAct!==2" @click.stop="goTab(2)">
				<image :src="cdnUrl+'XianxiangUapi/static/tabbar3.png'" class="img"></image>
				<view class="text">
					客户
				</view>
			</view>

			<view class="box4" v-show="tabbarAct==3" @click.stop="goTab(3)">
				<image :src="cdnUrl+'XianxiangUapi/static/tabbarSel4.png'" class="img"></image>
				<view class="text" style="color: #1576FF;">
					我的
				</view>
			</view>
			<view class="box4" v-show="tabbarAct!==3" @click.stop="goTab(3)">
				<image :src="cdnUrl+'XianxiangUapi/static/tabbar4.png'" class="img"></image>
				<view class="text">
					我的
				</view>
			</view>
		</view>
		<view class="beijing" v-if="flage1" @click="isFlage">
			<view class="dw">
				<view class="m1" @click.stop="go(1)">
					<image :src="cdnUrl+'XianxiangUapi/static/m1.png'" class="img"></image>
					<view class="text">
						发布拓客活动
					</view>
				</view>
				<view class="m2" @click.stop="go(2)" v-if="isSelf==true">
					<image :src="cdnUrl+'XianxiangUapi/static/m2.png'" class="img"></image>
					<view class="text">
						发布拓客动态
					</view>
				</view>
				<view class="m3" @click.stop="go(3)">
					<image :src="cdnUrl+'XianxiangUapi/static/m3.png'" class="img"></image>
					<view class="text">
						录入客户
					</view>
				</view>
			</view>

		</view>
		<!-- 底部导航栏 end -->
		<view class="beijing2" v-if="flage2" @click="isFlage1">
			<view class="card">
				<view class="gray" @click.stop="this.flage2=true">
					<view class="text">
						请选择您要发布的动态类型：
					</view>
				</view>
				<view class="ngray" @click.stop="go2(1)">
					<view class="text">
						视频动态
					</view>
				</view>
				<view class="ngray" @click.stop="go2(2)">
					<view class="text">
						图片动态
					</view>
				</view>
			</view>
			<view class="btm" @click.stop="isFlage1">
				<view class="text">
					取消
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import loginApi from "../../../api/login/login.js"
	import salesmanApi from "../../../api/salesmanCenter/salesmanCenter.js"
	import taskApi from "../../../api/product/product.js"
	import indexListApi from "../../../api/index/indexList.js"

	export default {
		data() {
			return {
				today_money: 0.00,
				yesterday_money: 0.00,
				month_money: 0.00,
				total_money: 0.00,
				//底部导航
				tabbarAct: 3,
				// 默认选中收益类型
				navTip: 1,
				flage1: false, //发布按钮
				flage2: false,
				showlogin: false,
				cdnUrl: "",
				token: "",
				userPhone: "",
				user: {},
				rank: "",
				//业务员状态
				theStatus: "99",
				isSelf: false,
				commonlyUsed: [{
						index: 0,
						img: '../../../static/my/tuoke_icon.png',
						title: '申请拓客员'
					},
					{
						index: 1,
						img: '../../../static/my/teamLeader_icon.png',
						title: '申请团队长'
					},
					{
						index: 2,
						img: '../../../static/my/store_icon.png',
						title: '商家中心'
					},
					{
						index: 3,
						img: '../../../static/my/pro_icon.png',
						title: '代理商中心'
					},
					{
						index: 4,
						img: '../../../static/my/personal_icon.png',
						title: '业务员中心'
					},
					{
						index: 5,
						img: '../../../static/my/yqzc.png',
						title: '邀请注册'
					},
					{
						index: 6,
						img: '../../../static/my/zxkf.png',
						title: '在线客服'
					},
					{
						index: 7,
						img: '../../../static/my/gywm.png',
						title: '关于我们'
					},
					{
						index: 8,
						img: '../../../static/my/cjwt.png',
						title: '常见问题'
					},
					{
						index: 9,
						img: '../../../static/my/yjfk.png',
						title: '意见反馈'
					},
					{
						index: 10,
						img: '../../../static/my/bzzx.png',
						title: '帮助中心'
					},

				]
			}
		},
		onLoad() {
			// console.log(222)
			this.cdnUrl = this.$cdnUrl
			this.token = uni.getStorageSync("xxytoken")
			this.userPhone = uni.getStorageSync("userPhone")

			if (uni.getStorageSync("xxytoken")) {
				this.showlogin = true;
				console.log(this.token)
				loginApi.welcome({
					phone: this.userPhone,
					token: this.token
				}).then(res => {
					if (res.result.status == 1) {
						this.isSelf = true
					}
					console.log(res)
					if (res.status) {
						this.user = res.result
						this.rank = res.result.rank
					} else {
						this.showlogin = false
					}

				})

			} else {
				this.showlogin = false
			}



		},
		onShow() {
			if (uni.getStorageSync("xxytoken")) {
				this.showlogin = true;
				console.log(this.token)
				loginApi.welcome({
					phone: this.userPhone,
					token: this.token
				}).then(res => {
					console.log(res)
					if (res.result.status == 1) {
						this.isSelf = true
					}
					if (res.status) {
						this.user = res.result
						this.rank = res.result.rank
					} else {
						this.showlogin = false
					}

				})
				this.selTip(1)
			} else {
				this.showlogin = false
			}
		},
		methods: {
			selTip(e) {
				this.navTip = e
				loginApi.earnings_statistics({
					status: this.navTip,
					token: this.token
				}).then(res => {
					console.log(res)
					if (res.status == 200) {
						this.today_money = res.result.today
						this.yesterday_money = res.result.yesterday
						this.month_money = res.result.month
						this.total_money = res.result.total
					}
				})
			},
			isFlage1() {
				this.flage2 = false
			},
			go2(num) {
				if (num == 2) {
					uni.navigateTo({
						url: "../../../pagesB/pages/index/index/fabu"
					})
				}
				if (num == 1) {
					uni.navigateTo({
						url: "../../../pagesB/pages/index/index/fabu2"
					})
				}
			},
			//tabbar
			goTab(num) {
				if (num == 5) {

					this.flage1 = true
				} else if (num == 0) {

					uni.reLaunch({
						url: "../../../pagesB/pages/index/index/index"
					})

				} else if (num == 1) {
					uni.reLaunch({
						url: "../../../pagesB/pages/task/task"
					})
				} else if (num == 2) {
					//this.tabbarAct = 2
					uni.reLaunch({
						url: "../../../pagesB/pages/custom/custom"
					})
				} else if (num == 3) {
					this.tabbarAct = 3
					/* uni.reLaunch({
						url: "../../../pages/my/my/my"
					}) */
				}
			},
			go(num) {
				//发布拓客活动
				if (num == 1) {
					if (!uni.getStorageSync("xxytoken")) {
						uni.showToast({
							title: "你还没有登录",
							icon: 'none'
						})
						return
					}
					indexListApi.referrer().then(res => {
						console.log(res, 1)

						if (res.status == 200) {
							if (res.result.rank == 7) {
								uni.navigateTo({
									url: "../../../pagesB/pages/index/index/fbhd"
								})
							} else if (res.result.rank == 4) {
								uni.navigateTo({
									url: "../../../pagesB/pages/index/index/fbhd2?ids=" + res.result
										.merchant_id
								})
							} else {
								uni.showToast({
									title: "你没有该权限~",
									icon: "none"
								})
							}
						} else {
							uni.showToast({
								title: res.message,
								icon: 'none'
							})
						}
					})
				}
				//发布拓客动态
				if (num == 2) {
					if (!uni.getStorageSync("xxytoken")) {
						uni.showToast({
							title: "你还没有登录",
							icon: 'none'
						})
						return
					}
					indexListApi.referrer().then(res => {
						console.log(res)
						if (res.status == 200) {
							if (res.result.rank == 7 || res.result.rank == 6) {
								this.flage1 = false
								this.flage2 = true
							} else {
								uni.showToast({
									title: "你没有该权限~",
									icon: "none"
								})
							}
						} else {
							uni.showToast({
								title: res.message,
								icon: 'none'
							})
						}
					})
				}
				//录入客户
				if (num == 3) {
					taskApi.get_add_client().then(res => {
						console.log(res)
						this.flage1 = false
						if (res.status == 200) {
							uni.navigateTo({
								url: "../../../pagesB/pages/index/index/lrkh?taskid=" + res.result
									.task_id +
									"&supplier_id=" +
									res.result.supplier_id
							})
						} else {
							uni.showToast({
								title: res.message,
								icon: 'none'
							})
						}
					})
				}
			},
			//弹窗
			isFlage() {
				this.flage1 = false
			},

			//登录
			goLogin() {
				uni.navigateTo({
					url: '../../welcome/welcome'
				});
			},
			goMoney() {
				if (!this.token) {
					uni.navigateTo({
						url: "../../welcome/welcome"
					})
					return;
				};
				// console.log(1)
				uni.navigateTo({
					url: "../myCash/myCash"
				})
			},
			goSetting() {
				if (!this.token) {
					uni.navigateTo({
						url: "../../welcome/welcome"
					})
					return;
				};
				uni.navigateTo({
					url: "../user/userInfo"
				})
			},
			goNoti() {
				if (!this.token) {
					uni.navigateTo({
						url: "../../welcome/welcome"
					})
					return;
				};
				uni.navigateTo({
					url: "../noti/noti"
				})
			},
			mobileFilter(val) {
				if (val) {
					let reg = /^(.{3}).*(.{4})$/
					return val.replace(reg, '$1****$2')
				}

			},
			// 常用功能
			taps(index) {
				if (!this.token) {
					uni.navigateTo({
						url: "../../welcome/welcome"
					})
					return;
				};
				console.log(index)
				switch (index) {

					case 0:
						// 申请拓客员
						if (this.rank == 1) {
							if (this.user.is_merchant == 1 || this.user.is_salesman == 1) {
								uni.showToast({
									title: "您已申请其他身份，请耐心等待",
									icon: 'none'
								})
							} else {
								salesmanApi.user_tockStatus().then(res => {
									// this.goodsDailList = res.result
									//审核状态 0未提交 1审核中 2已通过 3已拒绝
									if (res.result.card_status == 2) {
										uni.showToast({
											title: "您已经是拓客员",
											icon: 'none'
										})

									} else if (res.result.card_status == 0) {
										uni.navigateTo({
											url: "../../salesmanCenter/ApplysSalesman?type=1"
										})

									} else {
										setTimeout(() => {
											uni.reLaunch({
												url: "../../salesmanCenter/auditing/auditing?type=1"
											})
										}, 1000)

									}

								})
							}

						} else {
							uni.showToast({
								title: "您已有其他身份",
								icon: 'none'
							})
						}

						break;
					case 1:
						// 申请团队长
						if (this.rank == 7) {
							uni.showToast({
								title: "您已经是团队长了",
								icon: 'none'
							})
						} else if (this.rank == 1 || this.rank == 6) {

							uni.navigateTo({
								url: "../teamLeader/teamLeader"
							})
						} else {
							uni.showToast({
								title: "您已有其他身份",
								icon: 'none'
							})
						}

						break;
					case 2:
						// 商家中心
						if (this.rank == 4) {
							uni.navigateTo({
								url: "../../salesmanCommercial/commercialCentre"
							})
						} else {
							if (this.user.is_salesman == 1 || this.user.is_toker == 1) {
								uni.showToast({
									title: "您已申请其他身份，请耐心等待",
									icon: 'none'
								})
							} else {
								uni.showToast({
									title: "您还没有入驻，请联系代理商",
									icon: 'none'
								})
							}

						}

						break;
					case 3:
						// 代理商中心
						if (this.rank == 3) {
							uni.navigateTo({
								url: '../../agentCentre/agentCentre'
							})
						} else {
							// if(this.user.is_merchant==1||this.user.is_toker==1) {
							//     uni.showToast({
							//         title: "您已申请其他身份，请耐心等待",
							//         icon: 'none'
							//     })
							// } else {
							uni.showToast({
								title: "您还不是代理商，请联系平台",
								icon: 'none'
							})
							// }

						}

						break;
					case 4:
						// 业务员中心
						if (this.rank == 2) {
							uni.navigateTo({
								url: '../../salesmanCenter/salesmanCenter'
							})
						} else if (this.rank == 1) {
							if (this.user.is_merchant == 1 || this.user.is_toker == 1) {
								uni.showToast({
									title: "您已申请其他身份，请耐心等待",
									icon: 'none'
								})
							} else {
								salesmanApi.user_settlement_detail({
									phone: this.userPhone
								}).then(res => {
									console.log(res.result)
									// this.goodsDailList = res.result
									//审核状态：-2未入驻 -1表示审核失败、0表示未审核 1表示审核通过，2下架
									if (res.result.card_status == 1) {
										uni.navigateTo({
											url: '../../salesmanCenter/salesmanCenter'
										})

									} else if (res.result.card_status == -2) {
										uni.navigateTo({
											url: '../../salesmanCenter/ApplysSalesman?type=2'
										})

									} else if (res.result.card_status == 2) {
										uni.showToast({
											title: "您已被平台下架，请联系平台",
											icon: 'none'
										})

									} else {
										setTimeout(() => {
											uni.navigateTo({
												url: "../../salesmanCenter/auditing/auditing?phone=" +
													this.userPhone
											})
										}, 1000)

									}

								})
							}


						} else {
							uni.showToast({
								title: "您已有其他身份",
								icon: 'none'
							})

						}

						break;
					case 5:
						// 邀请注册
						uni.navigateTo({
							url: '../allowinvite/allowinvite'
						})
						break;
					case 6:
						// 在线客服

						break;
					case 7:
						// 关于我们
						uni.navigateTo({
							url: '../aboutUs'
						})
						break;
					case 8:
						// 常见问题
						uni.navigateTo({
							url: '../hu/faq'
						})
						break;
					case 9:
						// 意见反馈
						uni.navigateTo({
							url: '../feedBack'
						})
						break;
					case 10:
						// 帮助中心
						uni.navigateTo({
							url: '../help'
						})
						break;
				}
			}


		}
	}
</script>

<style lang="scss" scoped>
	.selTip {
		text-align: center;
		width: 150rpx;
		background: #4C96FB;
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		// border-radius: 6rpx;
		color: #FFFFFF;
	}

	.Tip {
		width: 150rpx;
		text-align: center;
		border: 1rpx solid #4C96FB;
		color: #4C96FB;
		// border-radius: 6rpx;
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
	}

	.tip1 {
		border-radius: 6rpx 0 0 6rpx;
		border-right: none;
	}

	.tip2 {
		border: 1rpx solid #4C96FB;
		border-radius: none;

	}

	.tip3 {
		border-radius: 0rpx 6rpx 6rpx 0rpx;
		border-left: none;
	}

	.beijing2 {
		position: fixed;
		width: 100%;
		height: 100%;
		left: 0;
		top: 0;
		background-color: rgba(0, 0, 0, .5);
		z-index: 999;

		.card {
			width: 690rpx;
			height: 270rpx;
			position: absolute;
			bottom: 138rpx;
			left: 30rpx;
			background-color: #FFF;
			border-radius: 10rpx;

			.gray {
				width: 100%;
				height: 90rpx;
				display: flex;
				justify-content: center;
				align-items: center;

				.text {

					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #999999;

				}
			}

			.ngray {
				width: 100%;
				height: 88rpx;
				border-top: 2rpx solid #F5F5F5;
				display: flex;
				justify-content: center;
				align-items: center;

				.text {

					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 400;

					color: #333333;

				}
			}
		}

		.btm {
			width: 690rpx;
			height: 90rpx;
			position: absolute;
			bottom: 28rpx;
			left: 30rpx;
			background-color: #FFF;
			border-radius: 10rpx;
			display: flex;
			justify-content: center;
			align-items: center;

			.text {

				font-size: 26rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #333333;
				// line-height: 36px;
			}
		}
	}

	page {
		background: #F5F5F5 !important;
	}

	.myBg {
		width: 100%;
		height: 260rpx;
		position: absolute;
		left: 0;
		top: 0;
	}

	.noLogin {
		display: flex;
		width: 100%;
		align-items: center;
		position: absolute;
		top: 60rpx;
		left: 0px;
		padding: 0 30rpx;

		.photo {
			width: 114rpx;
			height: 114rpx;
			border-radius: 50%;
			background-color: #222222;
		}

		.loginText {
			margin-left: 24rpx;
			font-size: 44rpx;
			font-family: PingFang SC;
			font-weight: 500;
			color: #FFFFFF;
		}

		.rank {
			width: 118rpx;
			height: 35rpx;
			text-align: center;
			line-height: 35rpx;
			position: absolute;
			border: 1px solid #62A4FF;
			border-radius: 18rpx;
			bottom: -22rpx;
			background-color: #fff;
			font-size: 22rpx;
			font-family: PingFang SC;
			font-weight: 500;
			color: #62A4FF;
			left: 30rpx;
		}
	}

	.loginBtn {
		width: 260rpx;
		height: 60rpx;
		line-height: 60rpx;
		text-align: center;
		border-radius: 50rpx;
		border: 1rpx solid #fff !important;
		margin: 20rpx auto 0;
		color: #fff;
	}

	.money_manage {
		width: 650rpx;
		height: 110rpx;
		padding: 20rpx 20rpx;
		position: absolute;
		top: 220rpx;
		left: 30rpx;
		background: rgba(255, 255, 255, 1);
		box-shadow: 0px 0px 15rpx 0px rgba(179, 179, 179, 0.4);
		border-radius: 10rpx;

		.money_tit {
			display: flex;
			justify-content: space-between;

			.right {
				display: inline-block;
				line-height: 50rpx;
				align-items: center;
				width: 135rpx;
				height: 50rpx;
				margin-right: 15rpx;

				border: 1rpx solid #62A4FF;
				font-size: 26rpx;
				border-radius: 25px;
				color: #62A4FF;
				text-align: center;
			}
		}

	}

	.root_noti {
		width: 650rpx;
		height: 100rpx;

		padding: 20rpx 20rpx;
		position: absolute;
		top: 120rpx;
		left: 30rpx;
		background: rgba(255, 255, 255, 1);
		box-shadow: 0px 0px 15rpx 0px rgba(179, 179, 179, 0.4);
		border-radius: 20rpx;

		// background-color: #70c7da;
		position: relative;

		.background-image {
			height: 100%;
			position: absolute;
			width: 100%;
			left: 0px;
			top: 0px;
		}

		.content {
			// line-height: 100rpx;
			position: absolute;
			width: 100%;
			height: 100%;
			left: 0px;
			top: 0px;
		}
	}

	.root_msg {
		width: 690rpx;
		height: 456rpx;

		position: absolute;
		top: 140rpx;
		left: 30rpx;
		background: rgba(255, 255, 255, 1);
		box-shadow: 0px 0px 15rpx 0px rgba(179, 179, 179, 0.4);
		border-radius: 10rpx;

		background-color: #FFFFFF;
		position: relative;

		.view_row {
			display: flex;
			justify-content: space-between;

			.bigView {
				// background-color: #000000;
				border-style: solid;
				width: 345rpx;
				height: 200rpx;
				border-left-width: 0rpx;
				border-top-width: 0rpx;
				border-right-width: 2rpx;
				border-right-color: #F5F5F5;
				border-bottom-width: 2rpx;
				border-bottom-color: #F5F5F5;

			}
		}

	}


	.courseAll {

		width: 690rpx;
		// height: 466rpx;

		position: absolute;
		top: 165rpx;
		left: 30rpx;
		background: rgba(255, 255, 255, 1);
		box-shadow: 0px 0px 15rpx 0px rgba(179, 179, 179, 0.4);
		border-radius: 10rpx;

		background-color: #FFFFFF;
		position: relative;
		margin-bottom: 20rpx;

		.courseTitle {
			display: flex;
			justify-content: space-between;
			align-items: center;
		}
	}

	.tabbar {
		// border-top: 1px solid #999999;
		position: fixed;
		left: 0;
		bottom: 0;
		// background-color: #FFF;
		height: 121rpx;
		width: 100%;
		display: flex;
		align-items: center;
		justify-content: space-around;
		z-index: 999;

		.bgc {
			position: absolute;
			left: 0;
			bottom: 0;
			height: 121rpx;
			width: 100%;
		}

		.img {
			height: 44rpx;
			width: 44rpx;
		}

		.text {
			width: 44rpx;
			height: 21rpx;
			font-size: 22rpx;
			font-family: PingFang SC;
			font-weight: 400;
			color: #666666;
			// line-height: 66px;
		}

		.box {
			height: 75rpx;
			width: 44rpx;
			// position: relative;
			position: absolute;
			left: 80rpx;
			bottom: 10rpx;
		}

		.box1 {
			height: 75rpx;
			width: 44rpx;
			// position: relative;
			position: absolute;
			bottom: 10rpx;
			left: 215rpx;
		}

		.box3 {
			height: 75rpx;
			width: 44rpx;
			// position: relative;
			position: absolute;
			bottom: 10rpx;
			right: 215rpx;
		}

		.box4 {
			height: 75rpx;
			width: 44rpx;
			// position: relative;
			position: absolute;
			bottom: 10rpx;
			right: 80rpx;
		}

		.box2 {
			// height: 75rpx;
			// width: 44rpx;
			position: absolute;
			left: 340rpx;

			bottom: 16rpx;

			.img {
				height: 70rpx;
				width: 70rpx;
				position: absolute;
				left: 0rpx;

				bottom: 24rpx;
			}

			.text {
				margin-left: 12rpx;
			}
		}
	}

	.beijing {
		position: fixed;
		width: 100%;
		height: 100%;
		left: 0;
		top: 0;
		background-color: rgba(0, 0, 0, .5);
		z-index: 999;

		.dw {
			width: 100%;
			position: absolute;
			bottom: 200rpx;
			left: 0;
			display: flex;
			justify-content: space-around;
			align-items: center;

			.m1 {
				width: 185rpx;
				height: 136rpx;
				display: flex;
				justify-content: center;
				flex-wrap: wrap;


				.img {
					width: 100rpx;
					height: 100rpx;

					margin-bottom: 10rpx;

				}

				.text {

					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 500;
					color: #FFFFFF;
				}
			}

			.m2 {
				width: 185rpx;
				height: 136rpx;
				display: flex;
				justify-content: center;
				flex-wrap: wrap;


				.img {
					width: 100rpx;
					height: 100rpx;
					margin-bottom: 10rpx;
				}

				.text {

					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 500;
					color: #FFFFFF;
				}
			}

			.m3 {
				width: 154rpx;
				height: 136rpx;
				display: flex;
				justify-content: center;
				flex-wrap: wrap;


				.img {
					width: 100rpx;
					height: 100rpx;
					margin-bottom: 10rpx;
				}

				.text {

					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 500;
					color: #FFFFFF;
				}
			}
		}


		// .img1{
		// 	width: 70rpx;
		// 	height: 70rpx;
		// 	position: absolute;
		// 	bottom: 70rpx;
		// 	left: 330rpx;
		// }
	}
</style>
