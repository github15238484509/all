<template>
	<view class="main-box">
		<view class="top-tip xal" v-if="myBrowseList.length > '0'">
			提示：长按可删除记录
		</view>
		<view class="content" v-for="(item,index) in myBrowseList" :key="index">
			<view class="top">
				{{item.date}}
			</view>
			<view class="content-item" v-for="(item1,index1) in item.list" :key="index1"
				@click="next(item1.goods_index)" @longpress="cancelCollect(item1.read_index)">

				<view class="left">
					<image :src="$imgUrl(item1.image)" mode="aspectFill"></image>
				</view>
				<view class="right">
					<view class="line1">
						<text class="text-type1">
							{{item1.zone_name?item1.zone_name:""}}
						</text>

						<text>
							{{item1.goods_name?item1.goods_name:""}}
						</text>

					</view>
					<view class='line2'>{{item1.goods_describe}}</view>
					<view class="line3">
						￥{{$returnFloat(item1.goods_cost)}}
					</view>
					<view class='line4'>
						<text class="left1">￥{{$returnFloat(item1.goods_price)}} </text> <text
							class="right1">已售{{item1.goods_sale}} </text>
						<!-- <image src="../../static/time.png" mode="aspectFill" style="margin-right: 10rpx;"></image> -->
					</view>
				</view>
			</view>
		</view>
		<!-- <image  v-if="myBrowseList.length == 0" src="../../../static/myCenter/datanull.png" class="imgs"></image> -->
		<view style="text-align: center; width: 100%;">
			<image v-if="myBrowseList.length==0" :src="cdnUrl+'XianxiangUapi/static/datanull.png'" class="imgsss"
				style="width: 344rpx;height: 300rpx; margin-top: 60%;"></image>

		</view>
		<view class="loadMore" style="margin: 20rpx 0;" v-if="myBrowseList.length > '0'">
			<u-loadmore :status="status" :load-text="loadText" @loadmore="clkloadMore" />
		</view>

		<u-modal v-if="myBrowseList.length!=0" confirm-color="#811120" v-model="isshow" :content="content" :show-cancel-button="true"
			@confirm="toConfirm" @cancel="cancel"></u-modal>


	</view>
</template>

<script>
	// import storeCollectApi from "../../api/mine/storeCollect.js"
	import browseListApi from '../../../api/my/my.js'
	export default {

		data() {
			return {
				isshow: false,
				content: '确定要删除该条记录吗？',
				//v-for 调试用
				myBrowseList: [],
				//店铺id
				mid: "",
				// token: '',
				count: 10,
				//当前页数
				page: 1,
				status: 'loading',
				totalPage: 1,
				loadText: {
					loadmore: '上拉或点击加载更多',
					loading: '努力加载中',
					nomore: '没有更多了'
				},
				//防止请求还没返回 就又再次触发触底发送请求
				reachFlag: true,
				cdnUrl:""
			}
		},
		onLoad() {
			this.cdnUrl = this.$cdnUrl
			this.init()
		},
		onReachBottom() {
			this.reachBtm()
		},
		methods: {
			init() {
				browseListApi.browseList({
					page: this.page,
					count: this.count
				}).then(res => {

					if (res.status == 200) {
						this.totalPage = res.result.last_page
						this.myBrowseList = res.result.data

						if (this.totalPage == this.page) {
							this.status = "nomore"
						} else if (this.totalPage > this.page) {
							this.status = "loadmore"
						}
						if (res.result.data.length == 0) {
							this.status = "nomore"
						}


					}
				})
			},
			next(id) {
				uni.navigateTo({
					url: "../../index/detail/detail?id=" + id
				})
			},
			cancelCollect(id) {
				this.isshow = true
				this.mid = id

			},
			//点击了确定   下面是模拟
			//真实环境 给后台发接口 拿到新数据重新给数组赋值
			toConfirm() {
				browseListApi.deleteBrowse({
					read_index: this.mid,
					// token: this.token,

				}).then(res => {
					if (res.status == 200) {
						uni.showToast({
							title: "删除成功",
							icon: "none"
						})
						this.init()
					} else {
						uni.showToast({
							title: res.message,
							icon: "none"
						})
					}
				})
			},
			cancel() {
				this.mid = ""
			},
			reachBtm() {


				if (this.page < this.totalPage) {
					this.status = 'loading';
					this.page++;
					browseListApi.browseList({
							// token: this.token,
							page: this.page,
							count: this.count
						})
						.then(res => {
							//如果有数据 重新赋值  如果没有 清空
							if (res.status == 200) {

								this.totalPage = res.result.last_page
								if (this.totalPage > this.page) {
									this.status = "loadmore"
								} else if (this.totalPage == this.page) {
									this.status = "nomore"
								}

								this.myBrowseList = this.myBrowseList.concat(res.result.data)


							}

						})
				} else {
					this.status = "nomore"
				}


			},

			clkloadMore() {
				this.reachBtm()
			}


		},

	}
</script>

<style lang="scss" scoped>
	.imgs {
		width: 100%;
		margin-top: 60%;
	}

	.top {
		width: 100%;
		margin-top: 20rpx;
		margin-bottom: 30rpx;
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #333333;

	}

	.top-tip {
		height: 50rpx;
		background-color: #B5BBC3;
		padding-left: 32rpx;
		color: #3E4D60;
		font-size: 26rpx;
		line-height: 50rpx;
	}

	.content {
		padding: 0 30rpx;

		.right {}
	}

	.content-item {

		margin-top: 20rpx;
		height: 200rpx;
		background: #FFFFFF;
		// border: 1rpx solid #EEEEEE;
		border-radius: 10rpx;
		display: flex;

		.left {
			width: 300rpx;
			height: 169rpx;
			border-radius: 10rpx;
			// overflow: hidden;

			margin: 10rpx;

			image {
				width: 100%;
				height: 100%;
			}
		}

		.right {
			width: 350rpx;
			margin-left: 16rpx;
			display: flex;
			flex-direction: column;
			justify-content: space-evenly;

			.line1 {
				overflow: hidden;
				white-space: nowrap;
				text-overflow: ellipsis;
				font-size: 32rpx;

				.text-type1 {
					// padding:  10rpx  10rpx;
					padding-left: 10rpx;
					padding-right: 10rpx;
					margin-right: 10rpx;
					background-color: #F87897;
					font-size: 22rpx;
					border-radius: 9rpx;
					color: #FFFFFF;
					height: 22rpx;
				}
			}

			.line2 {
				font-size: 26rpx;

				font-weight: 300;
				color: #999999;
				// width: 460rpx;
				height: 36rpx;

				overflow: hidden;
				white-space: nowrap;
				text-overflow: ellipsis;
			}

			.line3 {
				font-size: 30rpx;
				color: #D12222;
				font-weight: bolder;

				image {
					width: 28rpx;
					height: 28rpx;
				}

				display: flex;
				align-items: center;
			}

			.line4 {
				display: flex;
				justify-content: space-between;
				font-size: 24rpx;
				color: #999999;

				.left1 {
					text-decoration: line-through;
				}

				.right1 {}

			}
		}
	}
</style>
