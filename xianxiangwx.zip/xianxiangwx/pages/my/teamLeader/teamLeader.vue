<template>

    <view>

        <image :src="cdnUrl+'XianxiangUapi/teamLeader/tl_bg.png'" class="bg_img"></image>

        <image :src="cdnUrl+'XianxiangUapi/teamLeader/tl_title.png'" class="header_img"></image>
        <image :src="cdnUrl+'XianxiangUapi/teamLeader/tl_1.png'" class="bg_text1"></image>



        <image :src="cdnUrl+'XianxiangUapi/teamLeader/tl_2.png'" class="bg_text2"></image>

        <!-- <textarea class="text1" v-model="introduce" value="" placeholder="" disabled="disabled" /> -->
        <text class="text1">{{introduce}}</text>
        <text class="text2">{{upgrade}}</text>

        <view class="bottomBtn" @click="tap">
            联系平台
        </view>

    </view>

</template>

<script>
    import teamLeaderApi from "../../../api/my/teamLeader.js"
    import aboutUsApi from "../../../api/my/my.js"
    
    export default {
        data() {
            return {
                cdnUrl: "",
                introduce: "",
                upgrade: "",
                phone:""
            }
        },
        onLoad() {
            
            let self = this
            
            this.cdnUrl = this.$cdnUrl
            teamLeaderApi.examineToke().then(res => {
                console.log(res)
                self.introduce = res.result.introduce
                self.upgrade = res.result.upgrade
            })
            
            aboutUsApi.aboutWe(
            	
            ).then(res =>{
            	self.phone = res.result.service_phone
            	console.log(self.phone)
            })
        },
        methods: {
            tap() {
                console.log(1)
                uni.makePhoneCall({
                    phoneNumber:this.phone
                })
            },
        }
    }
</script>

<style lang="scss">
    page {
        width: 100%;
        height: 1500rpx;
        background-color: #479AF3;

    }

    .bg_img {
        width: 100%;
        height: 1500rpx;
        position: absolute;
        left: 0;
        top: 0;

    }

    .header_img {
        position: absolute;
        top: 84rpx;
        left: 100rpx;
        width: 560rpx;
        height: 240rpx;
    }

    .bg_text1 {

        position: absolute;
        top: 334rpx;
        left: 30rpx;
        right: 30rpx;
        width: auto;
        height: 430rpx;
    }

    .text1 {
        position: absolute;
        top: 420rpx;
        left: 60rpx;
        right: 60rpx;

        overflow-y: auto;
        width: 630rpx;
        height: 300rpx;

    }

    .bg_text2 {
        position: absolute;
        top: 774rpx;
        left: 30rpx;
        right: 30rpx;

        width: auto;
        height: 346rpx;

    }

    .text2 {

        overflow-y: auto;
        position: absolute;
        top: 864rpx;
        left: 60rpx;
        right: 60rpx;

        width: 630rpx;
        height: 220rpx;

    }

    .bottomBtn {
        position: absolute;
        top: 1220rpx;
        left: 30rpx;
        right: 30rpx;

        width: auto;
        height: 90rpx;

        background: linear-gradient(0deg, #ABCFF7, #479AF3);
        box-shadow: 0px 0px 13px 0px rgba(23, 40, 161, 0.6);
        border-radius: 44px;

        color: #FFFFFF;
        text-align: center;
        line-height: 90rpx;

    }
</style>
