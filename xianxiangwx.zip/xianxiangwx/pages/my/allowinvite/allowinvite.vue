<template>
	<view class="imgbox">
		<view class="one"></view>
		<image :src="cdnUrl+'XianxiangUapi/static/yq1.png'" class="img1"></image>
		<image :src="cdnUrl+'XianxiangUapi/static/yq2.png'" class="img2"></image>
		<image :src="cdnUrl+'XianxiangUapi/static/yq3.png'" class="img3"></image>
		<image :src="cdnUrl+'XianxiangUapi/static/yq4.png'" class="img4"></image>
		<image :src="cdnUrl+'XianxiangUapi/static/yq5.png'" class="img5"></image>
		<image :src="cdnUrl+'XianxiangUapi/static/yq6.png'" class="img6"></image>
		<image :src="cdnUrl+'XianxiangUapi/static/yq7.png'" class="img7"></image>
		<image :src="cdnUrl+'XianxiangUapi/static/yq7.png'" class="img8"></image>
		<text class="text1">邀请好友</text>
		<text class="text2">好友升级/消费</text>
		<text class="text3">获得相应奖励</text>
		<!-- <image src="../../../static/my/yq8.png" class="img9"></image> -->
		<image :src="cdnUrl+'XianxiangUapi/static/yq9.png'" class="img10"></image>

		<view class="num">
			分享<text> {{askPresons}} </text>位好友
		</view>
		<view class="lookAll">
			<text @click="goAllPresons">查看全部>></text>
		</view>

		<view class="askText">
			<view class="title">
				<view class="line">

				</view>
				<view class="title-c">
					邀请说明
				</view>
				<view class="line">

				</view>
			</view>
			<view class="textTile">
				一、邀请奖励说明：
			</view>
			<view class="textCon">
				·VIP体验官级别成功邀请5个VIP体验官，可晋升为初
			</view>
			<view class="textCon">
				级代理商
			</view>

			<view class="textTile">
				二、当您未邀请成功时，其他相应奖励不可领取！
			</view>
		</view>

		<view class="bottomBtn">
			<image :src="cdnUrl+'XianxiangUapi/static/yq10.png'" class="img-b" @click="goPage()"></image>
			<view class="img-c">
				<image :src="cdnUrl+'XianxiangUapi/static/yq11.png'" class="img-d"></image>
				<button type="default" open-type="share" style="width: 100%;height: 100%;opacity: 0;position: absolute;
					left: 0;
					top: 0;"></button>
			</view>



		</view>
	</view>
</template>

<script>
	import myApi from "../../../api/my/my.js"
	export default {
		data() {
			return {
				cdnUrl: "",
				askPresons: 0,
				img: ""
			}
		},

		onLoad() {
			this.cdnUrl = this.$cdnUrl
			// console.log(indexApi)
			myApi.user_invite({
				page: 1,
				count: 20
			}).then(res => {
				console.log(res)
				if (res.status == 200) {
					this.askPresons = res.result.straight_num
				} else {
					uni.showToast({
						title: res.message,
						icon: 'none'
					})
				}
			})
			myApi.my_invitation().then(res => {
				console.log(res)
				if (res.status == 200) {
					this.img = res.result.reg_photo
				} else {
					uni.showToast({
						title: res.message,
						icon: 'none'
					})
				}
			})
		},
		methods: {
			showToast() {
				this.$refs.uToast.show({
					title: '分享成功',
					type: 'default',
				})
			},
			goPage() {
				let imgUrl = this.$imgUrl(this.img)
				uni.previewImage({
					urls: [imgUrl]
				});
				indexApi.share_goods({
					// token:uni.getStorageSync('token'),
					page: "/pages/index/detail/detail",
					goods_id: this.goods_index
				}).then(res => {

					this.share_goods = res.result.share_goods
					console.log(this.share_goods)
				})

			},

			goAllPresons() {
				uni.navigateTo({
					url: './goAllPresons/goAllPresons'
				});
			}
		},
		onShareAppMessage(res) {
			return {
				title: '先享用',
				path: '/pages/index/index'
			}
		}
	}
</script>

<style lang="scss" scoped>
	.imgbox {
		width: 100%;
		position: relative;
		height: 2070rpx;

		.one {
			position: absolute;
			left: 0;
			top: 0;
			width: 100%;
			height: 2056rpx;
			background-color: #3F89ED;
		}

		.img1 {
			width: 650rpx;
			height: 178rpx;
			position: absolute;
			left: 50rpx;
			top: 60rpx;
		}

		.img2 {
			width: 750rpx;
			height: 671rpx;
			position: absolute;
			left: 0rpx;
			top: 130rpx;
			// object-fit: fill;
		}

		.img3 {
			width: 670rpx;
			height: 350rpx;
			position: absolute;
			left: 40rpx;
			top: 700rpx;
		}

		.img4 {
			width: 97.5rpx;
			height: 97.5rpx;
			position: absolute;
			left: 94rpx;
			top: 835rpx;
		}

		.img5 {
			width: 97.5rpx;
			height: 97.5rpx;
			position: absolute;
			left: 320rpx;
			top: 835rpx;
		}

		.img6 {
			width: 97.5rpx;
			height: 97.5rpx;
			position: absolute;
			right: 117rpx;
			top: 835rpx;
		}

		.img7 {
			width: 82rpx;
			height: 22rpx;
			position: absolute;
			left: 218rpx;
			top: 873rpx;
		}

		.img8 {
			width: 82rpx;
			height: 22rpx;
			position: absolute;
			left: 439rpx;
			top: 873rpx;
		}

		.img9 {
			width: 650rpx;
			height: 131rpx;
			position: absolute;
			left: 50rpx;
			top: 1090rpx;
		}

		.text1 {
			position: absolute;
			left: 98rpx;
			top: 940rpx;
			font-size: 23rpx;
			font-family: Source Han Sans CN;
			font-weight: 300;
			color: #666666;

		}

		.text2 {
			position: absolute;
			left: 303rpx;
			top: 940rpx;
			font-size: 23rpx;
			font-family: Source Han Sans CN;
			font-weight: 300;
			color: #666666;
		}

		.text3 {
			position: absolute;
			right: 104rpx;
			top: 940rpx;
			font-size: 23rpx;
			font-family: Source Han Sans CN;
			font-weight: 300;
			color: #666666;
		}

		.img10 {
			width: 670rpx;
			height: 254rpx;
			position: absolute;
			left: 40rpx;
			top: 1100rpx;
		}

		.num {
			position: absolute;
			left: 68rpx;
			top: 1232rpx;
			font-size: 30rpx;
			font-family: Source Han Sans CN;
			font-weight: 300;
			color: #666666;

			text {
				margin-left: 17rpx;
				margin-right: 17rpx;
				font-size: 59rpx;
				font-family: Source Han Sans CN;
				font-weight: bold;
				color: #436AF2;
			}
		}


		.lookAll {
			position: absolute;
			right: 105rpx;
			top: 1250rpx;
			font-family: Source Han Sans CN;
			font-weight: 300;
			text-decoration: underline;
			font-size: 30rpx;
			color: #436AF2;
		}

		.askText {
			position: absolute;
			top: 1450rpx;
			left: 0;
			width: 100%;

			.title {
				padding: 0px 50rpx;
				display: flex;
				justify-content: space-around;
				align-items: center;

				width: 570rpx;
				margin: 0 auto;
				margin-bottom: 35rpx;

				.line {
					width: 120rpx;
					height: 2rpx;
					background: #B5D5FF;
				}

				.title-c {

					font-size: 30rpx;
					font-family: PingFang SC;
					font-weight: bold;
					color: #B5D5FF;
				}
			}

			.textTile,
			.textCon {
				line-height: 45rpx;
				font-size: 26rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: #B5D5FF;
				padding: 0px 50rpx;
			}

			.textCon {
				text-indent: 2em;
			}
		}

		.bottomBtn {
			position: fixed;
			bottom: 0;
			left: 0;
			width: 100%;
			height: 124rpx;
			background-color: #71A8F4;
			display: flex;
			align-items: center;
			justify-content: space-around;

			.img-b {

				width: 350rpx;
				height: 110rpx;
			}

			.img-c {

				width: 350rpx;
				height: 110rpx;
				position: relative;

				.img-d {
					position: absolute;
					left: 0;
					top: 0;
					width: 350rpx;
					height: 110rpx;
				}
			}
		}
	}
</style>
