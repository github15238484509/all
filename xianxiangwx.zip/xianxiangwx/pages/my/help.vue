<template>
	<view class="">
		<view class="help_list" v-if='helpList.length!=0' v-for="(item,i) in helpList" :key="i" @click="goDetail(item)">
			<view class="help_list_top">
				{{item.title}}
			</view>
			<view class="help_list_foot">
				<view class="help_list_foot_left">
					{{item.help_des}}
				</view>
				<view class="help_list_foot_right">
					{{item.time}}
				</view>
			</view>
		</view>
		<view v-else style="text-align: center; width: 100%;">
			<image v-if="helpList.length==0" :src="cdnUrl+'XianxiangUapi/static/datanull.png'" class="imgsss"
				style="width: 344rpx;height: 300rpx; margin-top: 60%;"></image>
		</view>
	</view>
</template>

<script>
	import {
		formatTime
	} from '../../untils/common.js'
	import helpApi from "../../api/my/my.js"

	export default {
		data() {
			return {
				helpList: [],
				showVideo: true,
				controls: false, //
				cdnUrl:""
			}
		},
		methods: {
			init() {
				let self = this

				helpApi.help().then(res => {
					if (res.status == 200) {
						for (let i = 0; i < res.result.length; i++) {
							res.result[i].time = formatTime(res.result[i].add_time * 1000)
						};
						self.helpList = res.result
						// this.helpList=res.result
					} else {
						uni.showToast({
							icon: 'none',
							title: res.message
						})
					}
				})
				// self.request({
				// 	url:'/public/index.php/App/help',
				// 	success:function(res){

				// 	}
				// })
			},
			goDetail(item) {
				helpApi.browsingHistory({
					id: item.id,
					type: "2"
				}).then(res => {
					console.log(res)
				})
				if (item.type == 1) {
					uni.navigateTo({
						url: 'helpDetail?src=' + item.help_content,

					})
				} else {
					// this.request({
					// 	url:'/public/index.php/Recommend/helpPv',
					// 	data:{
					// 		help_id:item.id
					// 	},
					// 	success:function(res){
					// 		console.log(res)
					// 	}
					// })
					uni.navigateTo({
						url: './videoCommon?url=' + item.video_url + '&img=' + item.video_cover
					})
				}
			}
		},
		onShow() {
			this.cdnUrl = this.$cdnUrl
			this.init()
		}
	}
</script>
<style>
	page {
		background-color: #FFFFFF;
	}
</style>
<style lang="scss">
	.help_list {
		background: #fff;
		border-bottom: 1px solid #f5f5f5;
		padding: 20px 10px;

		.help_list_top {
			font-size: 26rpx;
			font-family: PingFang SC;
			font-weight: 500;
			color: rgba(33, 33, 33, 1);
		}

		.help_list_foot {
			display: flex;
			justify-content: space-between;
			margin-top: 10rpx;
			font-size: 22rpx;
			font-family: PingFang SC;
			font-weight: 400;
			color: rgba(153, 153, 153, 1);
		}
	}

	.none {
		text-align: center;
		margin-top: 50rpx;
	}
</style>
