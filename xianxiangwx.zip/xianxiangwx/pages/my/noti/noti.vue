<template>
	<view class="msg-box">
		<view class="clear" v-if="msgList.length>0" @click="toClear">

			<image src="../../../static/clear.png" mode="aspectFill"></image>

			清空消息
		</view>
		<view class="msg-item" v-for="item in msgList">
			<view class='line1 xbt'>
				<view class='left' style="color: #333333;">{{item.message_title}}</view>
				<view class='right' style="color: #999999;">{{$time(item.message_time,2)}}</view>
			</view>
			<view class='line2'>
				<text class="line2-desc">{{item.message_text}}</text>
                
				<text v-if="item.path.length>0" class="right-toNow" @click="toNow(item.path)">立即前往>></text>
                
                
                <!-- <navigator v-if="item.path.length>0" url=item.path open-type="navigate">
                     <view class="right-toNow">立即前往>></view>
                </navigator> -->
                
			</view>

		</view>
        <view v-if="msgList.length==0" style="text-align: center;padding-top: 300rpx;">
			<image :src="cdnUrl+'XianxiangUapi/static/datanull.png'" alt="" style="width: 470rpx;height: 345rpx;">
			</image>
		</view>

		<view class="more" style="margin-top: 20rpx;" v-if="msgList.length>0">
			<u-loadmore :status="status" :load-text="loadText" @loadmore="clkloadMore" />
		</view>

	</view>
</template>

<script>
	import systemMsgApi from "../../../api/my/systemMsg.js"
	export default {
		data() {
			return {
				token: "",
				msgList: [],
				count: 2,
				//当前页数
				page: 1,
				status: 'loading',
				totalPage: 1,
                cdnUrl: "",
				loadText: {
					loadmore: '上拉或点击加载更多',
					loading: '努力加载中',
					nomore: '没有更多了'
				},
				//防止请求还没返回 就又再次触发触底发送请求
				reachFlag: true
			}
		},
		methods: {
			toNow(r) {
				uni.navigateTo({
					url: r
				})
			},
			reachBtm() {
				if (this.reachFlag) {
					this.reachFlag = false
					if (this.page < this.totalPage) {
						this.status = 'loading';
						this.page++;
						systemMsgApi.messageList({
							token: this.token,
							page: this.page,
							count: this.count
						}).then(res => {
							//如果有数据 重新赋值  如果没有 清空
							if (res.result) {

								this.totalPage = res.result.last_page
								if (this.totalPage > this.page) {
									this.status = "loadmore"
								} else if (this.totalPage == this.page) {
									this.status = "nomore"
								}

								this.msgList = this.msgList.concat(res.result.data)
								this.reachFlag = true

							} else {
								this.page--
								this.reachFlag = true

								this.status = "nomore"
							}

						})
					} else {
						this.status = "nomore"
					}
				}

			},

			clkloadMore() {
				this.reachBtm()
			},
			toClear() {
                let this_= this
				uni.showModal({
				    title: '提示',
				    content: '确定全部清空吗?',
				    success: function (res) {
				        if (res.confirm) {
				          systemMsgApi.clear().then(res => {
				          	if (res.status == 200) {
				          		uni.showToast({
				          			title: res.message,
				          			icon: 'none'
				          		})
				          		this_.msgList = []
				          	} else {
				          		uni.showToast({
				          			title: res.message,
				          			icon: 'none'
				          		})
				          	}
				          })
				        } else if (res.cancel) {
				            console.log('用户点击取消');
				        }
				    }
				});
				
				
			}


		},
		onLoad() {
            this.cdnUrl = this.$cdnUrl
			this.token = uni.getStorageSync('xxytoken')
			systemMsgApi.messageList({
				token: this.token,
				page: this.page,
				count: this.count
			}).then(res => {
				if (res.status == 200) {
					if (res.result) {
						this.msgList = res.result.data
						this.totalPage = res.result.last_page
						if (this.totalPage <= this.page) {
							this.status = "nomore"
						} else if (this.totalPage > this.page) {
							this.status = "loadmore"
						} 
					}else{
						this.status = "nomore"
					}
				} else {
						
					uni.showToast({
						title: res.message,
						icon: 'none'
					})
				}

			})
		},
		onReachBottom() {
			this.reachBtm()

		},

	}
</script>
<style>
	body {
		background: #F5F5F5;
	}
</style>
<style scoped lang="scss">
	.msg-box {
		padding: 0 30rpx 20rpx;

		.msg-item {
			margin-top: 20rpx;

			background-color: #FFFFFF;

			border-radius: 10rpx;
			padding-top: 20rpx;
			padding-bottom: 20rpx;

			.line1 {

				font-size: 26rpx;
				padding: 0 20rpx;
				margin-bottom: 20rpx;
			}

			.line2 {
				position: relative;
				padding: 20rpx;
				display: flex;
				align-items: center;

				width: 650rpx;
				line-height: 36rpx;
				margin: 0 auto;
				color: #999999;
				font-size: 26rpx;
				background-color: #F8F8F8;

				.line2-desc {
					display: inline-block;
					margin-bottom: 36rpx;
				}

				.right-toNow {


					position: absolute;
					font-size: 26rpx;
					color: #999999;
					bottom: 20rpx;
					right: 20rpx;
				}
			}
		}
	}

	.clear {
		margin: 20rpx auto;
		width: 180rpx;
        font-size: 26rpx;
		height: 50rpx;
		display: flex;
		justify-content: space-evenly;
		background: #FFFFFF;
		border-radius: 25rpx;
		align-items: center;

		image {
			width: 36rpx;
			height: 36rpx;
		}
	}
</style>
