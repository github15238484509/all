<template>
	<view class="main-box">
		<view class="xline-bet" @click="editAvatar">
			<view class="left">
				头像
			</view>
			<view class="right avatar">
				<image :src="$imgUrl(userObj.photo)" mode="aspectFill"></image>
				<u-icon name="arrow-right" size="28" style="margin-left: 10rpx;" color="#CCCCCC"></u-icon>
			</view>
		</view>
		<view class="xline-bet" @click="editName">
			<view class="left">
				昵称
			</view>
			<view class="right">
				{{userObj.name ? userObj.name : ''}}
				<u-icon top="2" style="margin-left: 10rpx;" name="arrow-right" size="28" color="#CCCCCC"></u-icon>
			</view>
		</view>
		<view class="xline-bet">
			<view class="left">
				性别
			</view>
			<!-- <view class="right">
							<u-icon name="arrow-right" size="28" style="margin-left: 10rpx;"  color="#CCCCCC"></u-icon>
					</view> -->
			<!-- <view class="right" @click="genderControl" v-if="!isselectShow">
						请选择 <u-icon name="arrow-right" size="32" color="#CCCCCC"></u-icon>
					</view> -->
			<view class="right" @click="genderControl" style="color: #000000;">
				{{genderValue}}
				<u-icon name="arrow-right" size="32" color="#CCCCCC"></u-icon>
			</view>
		</view>
		<view class="xline-bet" @click="editPhone">
			<view class="left">
				手机号
			</view>
			<view class="right">
				{{userObj.phone? mobileFilter(userObj.phone) :''}}
				<u-icon name="arrow-right" size="28" style="margin-left: 10rpx;" color="#CCCCCC"></u-icon>
			</view>
		</view>
		<view class="xline-bet">
			<view class="left">
				注册时间
			</view>
			<view class="right">
				{{userObj.regtime? $timeConvert(userObj.regtime,1) : '' }}
			</view>
		</view>
		<view class="xline-bet-end">
			<view class="left">
				绑定微信
			</view>
			<view class="right" style="display: flex;">

				<view class="" v-if="isWeChat" @click="cancelBind">
				    已绑定
				</view>
				<view v-else style="color: #999999;" @click="toBind">
				    未绑定
				</view>

				<!-- 未绑定    已绑定 等加字段 -->

				<u-icon name="arrow-right" size="28" style="margin-left: 10rpx;" color="#CCCCCC"></u-icon>
			</view>
		</view>



		<view class="xbtn-blue" @click="logout">
			退出登录
		</view>
		<u-select v-model="isGenderShow" :list="genderList" @confirm="genderConfirm"></u-select>
	</view>

</template>

<script>
	import userInfoApi from "../../../api/my/userInfo.js"
	import userApi from '../../../api/my/user.js'
	import welcomeApi from '../../../api/my/welcome.js'
    import loginApi from "../../../api/login/login.js"
    import agentCenterApi from "../../../api/agentCenter/agentCenter.js"
    
	export default {

		data() {
			return {
				token: "",
				userObj: {},
				isselectShow: true,
				isGenderShow: false,
                isWeChat:false,
				genderList: [{
						value: '0',
						label: '男'
					},
					{
						value: '1',
						label: '女'
					}
				],
				aliId: "",
				sex: '',
				//默认的性别
				genderValue: ""
			}
		},
		onLoad() {
			this.token = uni.getStorageSync('xxytoken')
			uni.$on('uAvatarCropper', path => {
				this.avatar = path;
				// 可以在此上传到服务端
				uni.uploadFile({
					url: this.$uptImgUrl,
					filePath: path,
					name: 'file',
					complete: (res) => {
						console.log(res);
						let newData = JSON.parse(res.data)
						let newUrl = newData.result

						newUrl = '/' + newUrl
						userApi.changeAvatar({
							token: this.token,
							photo: newUrl
						}).then(res => {
							if (res.status == 200) {
								uni.showToast({
									title: res.message,
									icon: 'none'
								})
								this.userObj.photo = newUrl
							} else {
								uni.showToast({
									title: res.message,
									icon: 'none'
								})
							}
						})

					}
				});
			})
            
            // 查询是否绑定过微信
            agentCenterApi.user_wechant({token:this.token}).then(res=>{
            	if(res.status==200){
            		if(res.result.type==2){
            			this.isWeChat=true
            		}else {
            			this.isWeChat=false
            		}
            	}
            })
		},
		onShow() {
			// this.token = uni.getStorageSync('xxytoken')
            console.log(1)
			userInfoApi.userInfo({
				token: this.token
			}).then(res => {
                console.log(res)
				this.userObj = res.result
				if (res.result.sex == 0) {
					this.genderValue = '男'
				} else if (res.result.sex == 1) {
					this.genderValue = '女'
				}

			})
		},
		methods: {
			mobileFilter(val) {
				if (val) {
                    console.log(val)
					let reg = /^(.{3}).*(.{4})$/
					return val.replace(reg, '$1****$2')
				}

			},
			editAvatar() {

				console.log(this.$u.route);
				// 此为uView的跳转方法，详见"文档-JS"部分，也可以用uni的uni.navigateTo
				this.$u.route({
					// 关于此路径，请见下方"注意事项"
					url: '/uview-ui/components/u-avatar-cropper/u-avatar-cropper',
					// 内部已设置以下默认参数值，可不传这些参数
					params: {
						// 输出图片宽度，高等于宽，单位px
						destWidth: 300,
						// 裁剪框宽度，高等于宽，单位px
						rectWidth: 200,
						// 输出的图片类型，如果'png'类型发现裁剪的图片太大，改成"jpg"即可
						fileType: 'jpg',
					}
				})

			},
			toBind() {
			    
			    let self = this
			    uni.login({
			        success: res => {
			            // 发送 res.code 到后台换取 openId, sessionKey, unionId
			            self.code = res.code;
			            console.log(self.code);
			            
			            self.getOpenId()

			        }
			    })
			},
			getOpenId() {
			    // let that = this
			    loginApi.get_openid({
			        code: this.code
			    }).then(res => {
			        if (res.status == 200) {
			            console.log(res);
			            // this.openid = res.result.openid;
			            // this.session_key = res.result.session_key
			            // this.unionid = res.result.unionid
			            uni.showToast({
			                title: '绑定成功'
			            })
			            this.isWeChat = true
			            this.onload()
			            
			        }
			    })
			},
			//取消绑定
			cancelBind() {
			    uni.showModal({
			        title: '提示',
			        content: '确定解除绑定吗？',
			        success: (res) => {
			            if (res.confirm) {
			                userInfoApi.cancelBindWX({
			                        token: this.token
			                    })
			                    .then(res => {
			                        if (res.status == 200) {
			                            uni.showToast({
			                                title: '解绑成功'
			                            })
			                            this.isWeChat = false
			                            userInfoApi.userInfo({
			                                token: this.token
			                            }).then(res => {
			
			                                this.userObj = res.result
			                                if (res.result.sex == 0) {
			                                    this.genderValue = '男'
			                                } else if (res.result.sex == 1) {
			                                    this.genderValue = '女'
			                                }
			
			                            })
			                        }
			                    })
			            } else if (res.cancel) {
			
			            }
			        }
			    });
			
			},
			editName() {
				uni.navigateTo({
                    url:'../editUserInfo/editName?name=' + this.userObj.name
				})
			},
			editPhone() {

				uni.navigateTo({
                    url:'../editUserInfo/editPhone/editPhone?phoneNum=' + this.userObj.phone

				})
			},
			genderControl() {
				this.isGenderShow = true
			},
			genderConfirm(e) {
				this.isGenderShow = false
				this.genderValue = e[0].label
				this.sex = e[0].value
				userApi.changeSex({
					token: this.token,
					sex: this.sex
				}).then(res => {
					if (res.status == 200) {
						this.isselectShow = true
						uni.showToast({
							title: res.message,
							icon: 'none'
						})
					} else {
						uni.showToast({
							title: res.message,
							icon: 'none'
						})
					}
				})


			},
			logout() {
				userInfoApi.logout({
					token: this.token
				}).then(res => {
					if (res.status == 200) {
						uni.showToast({
							title: '退出登录成功',
							icon: 'none'
						})
						uni.removeStorageSync('xxytoken')
						uni.clearStorageSync()
						setTimeout(() => {
							uni.reLaunch({
								url: '../my/my'
							})
						}, 1500)
					} else {
						uni.showToast({
							title: res.message
						})
					}
				})
			}
		}

	}
</script>

<style lang="scss" scoped>
	.main-box {
		padding: 36rpx 30rpx 0;

		.avatar {

			// overflow: hidden;
			display: flex;
			align-items: center;

			image {
				width: 80rpx;
				height: 80rpx;
				border-radius: 50%;


			}
		}
	}

	.xbtn-blue {
		position: fixed;
		bottom: 105rpx;
	}
</style>
