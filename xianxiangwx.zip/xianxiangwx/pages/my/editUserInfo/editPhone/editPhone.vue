<template>
    <view class="main">

        <view class="content">
            <view class="top">
                <view class='line1'>
                    当前绑定手机号
                </view>
                <view class='line2'>
                    {{mobileFilter(phoneNum)}}
                </view>
            </view>


            <view class="btm">

                <text style="color:#4794FF;font-size: 30rpx;margin-left: 30rpx;">+86</text>

                <image src="../../../../static/edit1.png" mode="aspectFill" style="margin-left: 10rpx;"></image>

                <view class="iptline">

                </view>
                <view class="ipt">
                    <input type="number" value="" maxlength="11" v-model="newPhoneNum" placeholder="请输入新手机号"
                        placeholder-style="color:#999999;font-size: 30rpx" />
                </view>

            </view>
            <view class="btm">
                <view class="img1">
                    <image src="../../../../static/edit2.png" mode="aspectFill"></image>
                </view>
                <view class="iptline1">

                </view>
                <view class="ipt">
                    <input type="number" value="" maxlength="6" v-model="code" placeholder="验证码"
                        placeholder-style="color:#999999;font-size: 30rpx" />
                </view>
                <view class="box">

                    <view class="second" v-if="!issend" @click="tosend" style="font-size: 26rpx;color: #4794FF;">
                        获取验证码
                    </view>
                    <view class="send" v-if="issend" style="font-size: 26rpx;color: #4794FF">
                        {{time}}s
                    </view>
                </view>
            </view>

        </view>
        <view class="btn" @click="resetPhoneNum">
            <!-- <image src="../../static/login.png" mode=""></image> -->
            <view class="xbtn-blue">
                确认修改手机号
            </view>

        </view>

        <view class="tip">
            修改手机号后，可以使用新手机登录
        </view>

    </view>
</template>

<script>
    // import loginApi from "../../api/index/login.js"
    // import getcodeApi from "../../api/index/getCode.js"
    // import doLoginApi from "../../api/index/doLogin.js"
    import getcodeApi from "../../../../api/my/getCode.js"
    import userApi from "../../../../api/my/user.js"
    export default {
        data() {
            return {
                phoneNum: "",
                time: 60,
                issend: false,
                code: "",
                merchant_id: "",
                money: "",
                newPhoneNum: "",
                token: ""
            };
        },
        onLoad(e) {
            this.phoneNum = e.phoneNum
            this.token = uni.getStorageSync('xxytoken')
            if (e) {
                this.phoneNum = e.phoneNum
            }



        },
        methods: {
            tosend() {
                getcodeApi.getCode({
                    phone: this.newPhoneNum,
                    verification_type: 4
                }).then(res => {
                    console.log(res)
                    if (res.status == 200) {


                        this.issend = true
                        var start = setInterval(() => {
                            this.time--
                            if (this.time <= 0) {
                                clearInterval(start)
                                this.issend = false
                                this.time = 60
                            }
                        }, 1000)
                    } else if (res.status != 200) {
                        uni.showToast({
                            title: res.message,
                            duration: 1500,
                            icon: "none"
                        });

                    }
                })
                //在成功的回调里   把issend改成true

            },
            resetPhoneNum() {
                if (!/(^1[3|4|5|7|8][0-9]{9}$)/.test(this.newPhoneNum)) {
                    uni.showToast({
                        title: '请输入正确的手机号码',
                        icon: 'none'
                    })
                    return;
                }
                if (!this.code) {
                    uni.showToast({
                        title: '验证码不能为空',
                        icon: 'none'
                    })
                    return;
                }


                userApi.changePhone({
                        token: this.token,
                        phone: this.newPhoneNum,
                        verification: this.code
                    })
                    .then(res => {
                        if (res.status == 200) {
                            uni.showToast({
                                title: '修改成功',
                                icon: "none"
                            });
                            //修改手机号成功 清空缓存 并跳转到欢迎登录
                            uni.clearStorageSync()
                            setTimeout(() => {
                                uni.reLaunch({
                                    url: "../../../welcome/welcome"
                                })
                            }, 1500)
                        } else {
                            uni.showToast({
                                title: res.message,
                                icon: "none"
                            });
                        }
                    })
            },
            mobileFilter(val) {
                if (val) {
                    let reg = /^(.{3}).*(.{4})$/
                    return val.replace(reg, '$1****$2')
                }

            }


        },
        filters: {
            handleNum(p) {

                if (p) {
                    return p.substring(0, 3) + '****' + p.substring(p.length - 4);
                }
            }
        }

    }
</script>
<style>
    page {
        background: #F5F5F5
    }
</style>
<style lang="scss" scoped>
    .content {
        margin: 0 50rpx;
        font-family: PingFang SC;
        padding-top: 56rpx;

        .top {

            font-size: 56rpx;

            font-weight: bold;
            color: #222222;
            line-height: 66rpx;
            text-align: center;
            margin-top: 133rpx;

            .line1 {
                color: #666666;
                font-size: 30rpx;
            }

            .line2 {
                margin-top: 20rpx;
                color: #666666;
                font-size: 42rpx;
                margin-bottom: 87rpx;
            }

        }

        .mid {
            margin-top: 100rpx;
            width: 325rpx;
            height: 64rpx;
            font-size: 24rpx;
            text-align: left;
            color: #999999;

        }

        .btm {
            width: 640rpx;
            height: 100rpx;
            background: #FFFFFF;
            border-radius: 10rpx;
            display: flex;
            align-items: center;
            margin-top: 50rpx;





            image {
                width: 14rpx;
                height: 9rpx;


            }

            .img1 {
                width: 36rpx;
                height: 36rpx;
                margin-left: 46rpx;

                image {
                    width: 100%;
                    height: 100%;
                }
            }

            .ipt {
                margin-left: 30rpx;
                width: 290rpx;

            }

            .box {
                box-sizing: border-box;
                width: 165rpx;
                height: 46rpx;
                background: #FFFFFF;
                border-radius: 30rpx;
                text-align: center;
                line-height: 46rpx;
                // margin-left: 39rpx;

                border: 1rpx solid #4794FF;

            }
        }




    }

    .btn {
        width: 690rpx;
        height: 90rpx;
        margin: 140rpx 30rpx 0;

        image {
            width: 100%;
            height: 100%;
        }
    }

    .tip {
        text-align: center;
        margin-top: 30rpx;
        font-size: 26rpx;
        color: #999999;
    }

    .iptline {
        width: 2rpx;
        height: 60rpx;
        background: #F5F5F5;
        margin-left: 25rpx;
    }

    .iptline1 {
        width: 2rpx;
        height: 60rpx;
        background: #F5F5F5;
        margin-left: 51rpx;
    }
</style>
