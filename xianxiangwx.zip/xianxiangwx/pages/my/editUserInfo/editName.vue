<template>
	<view class="main-box">
		<view class="edit-box">
			<input type="text" v-model="newName" value=""  placeholder="请输入您的新昵称" />
		</view>
		<view class="xbtn-blue"  @click="confirm">
			确认
		</view>
	</view>
</template>

<script>
	// import userApi from "../../../api/my/my.js"
    import userApi from "../../../api/my/user.js"
	export default {
		data() {
			return {
				newName:"",
				token:""
			}
		},
		onLoad() {
			this.token=uni.getStorageSync('xxytoken')
		},
		methods: {
			confirm(){
				if(!this.newName){
						uni.showToast({
							title:"昵称不能为空",
							icon:"none"
						})
						return
				}
				userApi.changeName({
					// token:this.token,
					name:this.newName
				}).then(res =>{
					if(res.status==200){
						uni.showToast({
							title:res.message,
							icon:"none"
						})
						
						setTimeout(()=>{
							uni.navigateBack({
								
							})
						},1500)
					}else{
						uni.showToast({
							title:res.message,
							icon:"none"
						})
					}
					
					
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	.edit-box{
		margin: 60rpx auto 0;
		background-color: #FFFFFF;
		width: 690rpx;
		height: 82rpx;
		border-radius: 10rpx;
		overflow: hidden;
		input{
			width: 660rpx;
			height: 80rpx;
			background-color: #FFFFFF;
			font-size: 30rpx;
			line-height: 80rpx;
			padding-left: 30rpx;
		}
	}
	.xbtn-blue{
		margin: 60rpx auto 0;
	}
	
</style>
