<template>
	<view class="box">
		<view class="header">
			<view class="text">
				<text>支付金额</text>
			</view>
			<view class="num">
				<text>￥{{$returnFloat(money)}}</text>
			</view>
		</view>
		<view class="line">
		</view>
		<view class="ye">
			<view class="left">
				<image src="../../static/ye.png" class="img1"></image>
				<view class="text">
					<view>余额支付 ({{yueText}})</view>
					<view>我的余额：{{$returnFloat(cash)}}</view>

				</view>
			</view>
			<!-- <image @click="change" v-if="!yuePay&&hui==false" src="../../../static/yuan.png" class="img">
			</image> -->
			<image v-if="yuePay" src="../../static/yuan2.png" class="img"></image>
			<!-- <image v-if="hui" src="../../../../static/zh.png" class="img"></image> -->
		</view>
		<view class="line">
		</view>
		<view class="wx">
			<view class="left">
				<image src="../../static/wx1.png" class="img"></image>
				<view class="text">
					微信支付
				</view>
			</view>
			<image @click="change1" v-if="!wxPay" src="../../static/yuan.png" class="img"></image>
			<image @click="change1" v-if="wxPay" src="../../static/yuan2.png" class="img"></image>

		</view>
		<view class="btn" @click="pay">
			<text>确认支付</text>
		</view>
	</view>
</template>

<script>
	import orderApi from "../../api/index/indexList.js"
	export default {
		data() {
			return {
				wxPay: false,
				yuePay: true,
				item: {},
				remarks: "",
				order_supplier_coupon: "",
				code: "",
				//hui: false,
				is_wxpay: "0",
				is_yepay: "1",
				is_upgrade: "",
				yueText: "",
				id: "",
				cash: "0.00",
				money: "0.00",
				type: "",

			};
		},
		onLoad: function(option) {

			this.id = option.id
			this.type = option.type
			let post_type = "1"
			if (this.type == 4) {
				post_type = 4
			}
			orderApi.affirmPay({
				task_id: this.id,
				type: post_type
			}).then(res => {
				console.log(res)
				if (res.status == 200) {
					this.cash = res.result.cash
					this.money = res.result.money
					if (res.result.cash < res.result.money) {
						this.yueText = "余额不足,需混合支付"
						/* if (res.result.cash == '0') {
							this.yuePay = false
							this.hui = true
							this.wxPay = true
						} else {
							this.wxPay = true
						} */
						this.wxPay = true

					} else {
						this.wxPay = false
						this.yuePay = true
						this.yueText = "余额充足"
					}
				} else {
					uni.showToast({
						title: res.message,
						icon: 'none'
					})
				}
			})


		},
		// onShareAppMessage: function(options) {
		// 	return {
		// 		title: '源爱汇',
		// 		path: '/page/index/index',
		// 		success: function(res) {
		// 			// 转发成功
		// 		},
		// 		fail: function(res) {
		// 			// 转发失败
		// 		}		
		// 	}		
		// },
		methods: {
			/*change() {
				this.yuePay = !this.yuePay
				this.wxPay = false
			},*/
			change1() {
				this.wxPay = !this.wxPay
				/*if (!this.hui) {
					this.yuePay = false
				}*/
			},
			pay() {
				if (this.yuePay == true && this.wxPay == true) {
					let url = '';
					let this_ = this
					uni.login({
						provider: 'weixin',
						success: function(e) {
							orderApi.tokerPay({
								// token:"5846783423223160416",
								pay_type: "3",
								task_id: this_.id,
								apply_index: this_.id,
								code: e.code
							}).then(res => {
								console.log(res)
								if (res.status !== 200) {
									uni.showModal({
										content: "支付失败，请重试！",
										showCancel: false
									});
									return;
								}
								if (res.status === 200) {
									// console.log("得到接口prepay_id", res.data.payment);
									let paymentData = res.result;
									console.log(paymentData)
									paymentData.timeStamp = paymentData.timeStamp + ''
									uni.requestPayment({
										timeStamp: paymentData.timeStamp,
										nonceStr: paymentData.nonceStr,
										appId: paymentData.appId, //商户
										package: paymentData.package,
										signType: paymentData.signType,
										// signType: 'MD5',
										paySign: paymentData.paySign,
										success: (res) => {
											uni.showToast({
												title: "支付成功!"
											})

											if (this_.type == 4) {
												uni.reLaunch({
													url: "../salesmanCenter/auditing/auditing?type=1"
												})
											} else {
												uni.reLaunch({
													url: "../../pagesB/pages/index/index/payOk?money=" +
														this_.money
												})
											}


										},
										fail: (res) => {
											// console.log(666666666);
											uni.showModal({
												content: "支付失败 ",

												showCancel: false
											})
										},
										complete: () => {
											this.loading = false;
										}
									})
								} else {

									uni.showModal({
										content: res.data.desc,
										showCancel: false
									})
								}
							})
						}
					});

				} else if (this.yuePay == true) {
					let this_ = this
					orderApi.tokerPay({
						// token:"5846783423223160416",
						pay_type: "1",
						task_id: this_.id,
						apply_index: this_.id
					}).then(res => {
						if (res.status == 200) {
							console.log(res);
							if (this_.type == 4) {
								uni.reLaunch({
									url: "../salesmanCenter/auditing/auditing?type=1"
								})
							} else {
								uni.reLaunch({
									url: "../../pagesB/pages/index/index/payOk?money=" + this_.money
								})
							}

							// this.order_supplier_coupon = res.result.order_supplier_coupon
							// this.remarks = res.result.remarks
							// this.is_upgrade = res.result.is_upgrade
							// uni.navigateTo({
							// 	url: "./payOk/payOk?remarks=" + this.remarks + "&order_supplier_coupon=" +
							// 		this.order_supplier_coupon + "&order_index=" + this.item.order_index +
							// 		"&is_upgrade=" + this.is_upgrade
							// })
						} else {
							uni.showToast({
								title: res.message,
								icon: "none"
							})
						}

					})
				} else if (this.wxPay == true) {
					let url = '';
					let this_ = this
					uni.login({
						provider: 'weixin',
						success: function(e) {
							orderApi.tokerPay({
								// token:"5846783423223160416",
								pay_type: "2",
								task_id: this_.id,
								apply_index: this_.id,
								code: e.code
							}).then(res => {
								console.log(res)
								if (res.status !== 200) {
									uni.showModal({
										content: "支付失败，请重试！",
										showCancel: false
									});
									return;
								}
								if (res.status === 200) {

									// console.log("得到接口prepay_id", res.data.payment);
									let paymentData = res.result;
									console.log(paymentData)
									paymentData.timeStamp = paymentData.timeStamp + ''
									uni.requestPayment({
										timeStamp: paymentData.timeStamp,
										nonceStr: paymentData.nonceStr,
										appId: paymentData.appId, //商户
										package: paymentData.package,
										signType: paymentData.signType,
										// signType: 'MD5',
										paySign: paymentData.paySign,
										success: (res) => {
											uni.showToast({
												title: "支付成功!"
											})
											// uni.reLaunch({
											// 	url:"./payOk?money="+this_.money
											// })
											if (this_.type == 4) {
												uni.reLaunch({
													url: "../salesmanCenter/auditing/auditing?type=1"
												})
											} else {
												uni.reLaunch({
													url: "../../pagesB/pages/index/index/payOk?money=" +
														this_.money
												})
											}


										},
										fail: (res) => {
											// console.log(666666666);
											uni.showModal({
												content: "支付失败 ",

												showCancel: false
											})
										},
										complete: () => {
											this.loading = false;
										}
									})
								} else {

									uni.showModal({
										content: res.data.desc,
										showCancel: false
									})
								}
							})
						}
					});


				} else {
					uni.showToast({
						title: '请选择支付方式',
						duration: 2000
					});
				}

			}
		}
	}
</script>
<style>
	page {
		height: 100%;
	}
</style>
<style lang="scss">
	.box {

		// height: 100%;
		.btn {
			margin-top: 560rpx;
			width: 690rpx;
			height: 90rpx;
			background: #3699FF;
			border-radius: 10rpx;
			margin-left: 30rpx;
			display: flex;
			justify-content: center;
			align-items: center;

			text {
				font-size: 36rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: #F5F5F5;
			}
		}

		.header {
			height: 288rpx;
			width: 100%;
			overflow: hidden;

			// display: flex;
			// align-items: center;
			// justify-content: center;
			.text {
				margin-top: 80rpx;
				// margin-left: 322rpx;
				font-size: 26rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: #333333;
				display: flex;
				justify-content: center;
			}

			.num {
				font-size: 50rpx;
				font-family: PingFang SC;
				font-weight: bold;
				color: #333333;
				display: flex;
				justify-content: center;
				margin-top: 60rpx;
			}
		}

		.line {
			width: 750rpx;
			height: 20rpx;
			background: #F5F5F5;
		}

		.wx {
			height: 100rpx;
			width: 100%;
			display: flex;
			justify-content: space-between;
			align-items: center;

			.left {
				margin-left: 30rpx;
				display: flex;
				justify-content: flex-start;
				align-items: center;

				.img {
					width: 44rpx;
					height: 44rpx;
					margin-right: 20rpx;
				}

				.text {

					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #333333;

				}
			}

			.img {
				width: 36rpx;
				height: 36rpx;
				margin-right: 30rpx;
			}
		}

		.ye {
			height: 100rpx;
			width: 100%;
			display: flex;
			justify-content: space-between;
			align-items: center;

			.left {
				margin-left: 30rpx;
				display: flex;
				justify-content: flex-start;
				align-items: center;

				.img1 {
					width: 44rpx;
					height: 44rpx;
					margin-right: 20rpx;
				}

				.text {

					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #333333;

				}

			}

			.img {
				width: 36rpx;
				height: 36rpx;
				margin-right: 30rpx;
			}
		}
	}
</style>
