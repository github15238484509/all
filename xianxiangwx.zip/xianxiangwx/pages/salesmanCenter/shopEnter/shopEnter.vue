<template>
	<view class="main-box">
		<view class="top">
			<view class="top-txt">
				<view class="xline-bet">
					<view class="top-txt-left">
						门店名称<text class="red">*</text>
					</view>
					<view class="top-txt-right">
						<input type="text" v-model="storeName" placeholder="请输入门店名字"
							placeholder-style="font-size:26rpx" @oninput="delemoji" />
					</view>
				</view>
				<view class="xline-bet">
					<view class="top-txt-left">
						联系人<text class="red">*</text>
					</view>
					<view class="top-txt-right">
						<input value="" v-model="name"  placeholder="请输入联系人姓名" placeholder-style="font-size:26rpx" />
					</view>
				</view>
				<view class="xline-bet">
					<view class="top-txt-left">
						联系电话<text class="red">*</text>
					</view>
					<view class="top-txt-right">
						<input type="number" maxlength="11" value="" v-model="phone" placeholder="请输入联系人电话"
							placeholder-style="font-size:26rpx" />
					</view>
				</view>
				<view class="xline-bet">
					<view class="area">营业时间<text class="red">*</text></view>
					<view class="timeFrame">

						<!-- @click="gettaking" -->
						<view style="display: flex;justify-content: flex-end;">
							<picker mode="time" @change="bindDateChange" :value="taking" :start="startDate"
								:end="endDate" :class="taking=='开始时间'? 'unact' : 'act' " style="margin-left: 200rpx;">
								{{ taking }}
							</picker>

							<text style="margin-left: 5rpx;margin-right: 5rpx;">—</text>

							<picker mode="time" @change="bindDateChanges" :value="takingend" :start="taking"
								:end="endDate" :class="takingend=='结束时间'? 'unact' : 'act' ">{{ takingend }}</picker>
							<u-icon name="arrow-right" size="28"></u-icon>
						</view>
					</view>

				</view>
				<view class="btm">
					<view class="btm-reason">
						店铺简介:<text class="red">*</text>
					</view>
					<view class="btm-text">
						<textarea class="theTextarea" v-model="textareaValue" value="" maxlength="200"
							placeholder="请简单介绍一下门店，最多输入200个字。" placeholder-style="font-size:24rpx;color:#999999" />

					</view>

				</view>
				<view class="xline-bet" @click="choiceAdd">
					<view class="top-txt-left">
						门店地址<text class="red">*</text>
					</view>
					<view class="top-txt-right" style="display: flex;align-items: center;" >
						<text :class="address==''? 'unact' : 'act'" v-if="!address"> 请选择您所在地区</text>
						<text v-if="address">{{address}}</text>
						<u-icon name="arrow-right" :class="address==''? 'unact' : 'act'" size="28"></u-icon>
					</view>
				</view>


			</view>

		</view>
		<view class="content">
			<view class="add-box">
				<view class="add-box-top">
					<input type="text"  value="" v-model="addressDetail" placeholder="请输入详细地址"
						placeholder-style="font-size:26rpx;text-alien:left" />
				</view>
				<view class="add-box-content">
					<map style="width: 100%; height: 288rpx;" 
					@click.stop="getaddress"
					:latitude="latitude"
					:longitude="longitude"
					:markers="position"
					:enable-zoom="false"
					>
					</map>
				</view>
			</view>
			<view class="shop-box">
				<view class="shop-box-left">
					<view class="theline-1">
						店铺logo（1张）<text class="red">*</text>
					</view>
					<view class="theline-2">
						1.建议尺寸：500*500
					</view>
					<view class="theline-3">
						2.为保证图片质量，大小不小于500KB
					</view>
				</view>
				<u-upload :custom-btn="true" max-count="1" :action="action" :auto-upload="true" width="130rpx"
					height="130rpx" @on-success="imgChange" @on-remove="removeLogo" :file-list="merchantLogo">
					<view slot="addBtn" class="slot-btn" hover-class="slot-btn__hover" hover-stay-time="150">
						<image src="../../../static/upload.png" class="img" style="width: 130rpx;height: 130rpx;">
						</image>
					</view>
				</u-upload>
			</view>

			<view class="" style="padding: 0 30rpx;">
				<view class="xline">

				</view>
			</view>
			<view class="environment-box">
				<view class="environment-box-top">
					<view class="theline-1">
						环境照片（最多上传5张）<text class="red">*</text>
					</view>
					<view class="theline-2">
						1.建议比例：5:2，建议尺寸大小：690*275px
					</view>
					<view class="theline-3">
						2.为保证质量，单张大小不小于500KB
					</view>
				</view>
				<view class="environment-box-btm">
					<u-uploadd ref="uUpload" :custom-btn="true" max-count="5" :action="action" :auto-upload="true"
						width="130rpx" height="130rpx" @on-success="imgChange1"  @on-remove="removeArr" :file-list="envimgs">
						<view slot="addBtn" class="slot-btn" hover-class="slot-btn__hover" hover-stay-time="150">
							<image src="../../../static/upload.png" class="img" style="width: 130rpx;height: 130rpx;">
							</image>
						</view>
					</u-uploadd>
				</view>



			</view>
			<view class="" style="padding: 0 30rpx;">
				<view class="xline" style="margin-top: 10rpx;">

				</view>
			</view>

			<view class="uptVideo-box">
				<view class="uptVideo-box-left">
					<view class="theline-1">
						上传视频封面 （选填）
					</view>
					<view class="theline-2">
						1.建议比例：16：9
					</view>
					<view class="theline-3">
						2.为保证质量，建议大小不小于500KB
					</view>
				</view>

				<view class="uptVideo-box-right">
					<u-upload :custom-btn="true" max-count="1" :action="action" :auto-upload="true" width="130rpx"
						height="130rpx" @on-success="imgChange6" @on-remove="removeVideoImg" :file-list="videoimg">
						<view slot="addBtn" hover-class="slot-btn__hover" hover-stay-time="150" class="slot-btn">
							<image src="../../../static/upload.png" class="img" style="width: 130rpx;height: 130rpx;">
							</image>
						</view>
					</u-upload>
				</view>
			</view>
			<view class="" style="padding: 0 30rpx;">
				<view class="xline" style="margin-top: 20rpx;">

				</view>
			</view>

			<view class="uptVideo-box">
				<view class="uptVideo-box-left">
					<view class="theline-1">
						上传视频 （选填）
					</view>
					<view class="theline-2">
						1.建议比例：16：9
					</view>
					<view class="theline-3">
						2.为保证质量，建议大小不小于20M
					</view>
				</view>
				<view class="uptVideo-box-right"  style="position: relative;">
					<view slot="addBtn" class="slot-btn" hover-class="slot-btn__hover" hover-stay-time="150">
					<image src="../../../static/upload.png" class="img" style="width: 130rpx;height: 130rpx;"
						@click="upvideo" v-if="!videoUrl&&loadingShow==true"></image>
					<video style="width: 130rpx;height: 130rpx;" v-if="videoUrl&&loadingShow==true" :src="$imgUrl(videoUrl)"
						controls></video>
						<u-icon v-if="videoUrl!=''" name="close-circle-fill" color="#333333" size="30" style="position: absolute;bottom: 90rpx;left: 100rpx;" @click="delVideoUrl"></u-icon>
						<u-loading style="position: absolute;" mode="circle"  v-if="loadingShow===false"></u-loading>
						<view style="width: 130rpx;height: 130rpx;background-color: #FFFFFF;" v-if="loadingShow===false"></view>
					</view>
				</view>
			</view>
		</view>

		<u-picker mode="region" v-model="isChoiceAddShow" @confirm="addConfirm"></u-picker>
		<!-- <navigator :url="'../shopAptitude/shopAptitude?item='+ encodeURIComponent(JSON.stringify(item))" class="xbtn-blue btn1" @tap="next">
			下一步
		</navigator> -->
		<view class="xbtn-blue btn1" @tap="next">
			下一步
		</view>
		<!-- <navigator :url="'/pages/test/test?item='+ encodeURIComponent(JSON.stringify(item))"></navigator> -->
		<view class="xline20fff">

		</view>
	</view>
</template>

<script>
	import unipopup from "../../../components/uni-popup/uni-popup.vue"
	import upimg from "../../../components/upimg.vue"
	import upimgSingle from "../../../components/upimgSingle.vue"
	import upvideo from "../../../components/tm-upload/tm-upload.vue"
	import threeLevelLinkApi from "../../../api/ThreeLevelLinkage/ThreeLevelLinkage.js"
	import agentCenterApi from "../../../api/agentCenter/agentCenter.js"
	export default {
		components: {
			upimg,
			upimgSingle,
			upvideo
		},
		// 得到录入的手机号及选择的行业ID
		onLoad(o) {
			uni.getLocation({
				type: 'gcj02',
				success: (res) => {
					this.longitude = res.longitude
					this.latitude = res.latitude
					this.position[0].longitude = res.longitude
					this.position[0].latitude = res.latitude
				},fail:(res)=>{
					this.longitude = 116.3972282409668
					this.latitude = 39.90960456049752
					this.position[0].longitude = 116.3972282409668
					this.position[0].latitude = 39.90960456049752
				}
			});
			console.log("得到的参数")
			console.log(o)
			this.token=uni.getStorageSync('xxytoken');
			if(o.phone){
				this.userPhone = o.phone
			}else {
				this.Reexamine=true
				if(o.userPhone){
					this.userPhone=o.userPhone
				}
				agentCenterApi.merchant_detail({
					phone:o.userPhone,
					merchant_id:o.merchant_id
				}).then(res=>{
				if(res.status==200&&res.result!=""){
					this.regionId1=res.result.merchant_province;
					this.regionId2=res.result.merchant_city;
					this.regionId3=res.result.merchant_county;
					this.storeName=res.result.merchant_name;
					this.name=res.result.merchant_contacts
					this.phone=res.result.merchant_tel
					this.taking=res.result.merchant_worktime_start
					this.takingend=res.result.merchant_worktime_end
					this.textareaValue=res.result.merchant_desp
					this.address=res.result.merchant_province_name+" "+res.result.merchant_city_name+" "+res.result.merchant_county_name
					this.addressDetail=res.result.merchant_address
					this.position[0].latitude=parseFloat(res.result.merchant_latitude)
					this.position[0].longitude=parseFloat(res.result.merchant_longitude)
					this.longitude=res.result.merchant_longitude
					this.latitude=res.result.merchant_latitude
					this.goodsID=res.result.merchant_id
					var a = [{url: ""}];
					a[0].url = this.$imgUrl(res.result.merchant_logo);
					this.merchantLogo=a;
					if(res.result.merchant_image!=""){
						var b=res.result.merchant_image.split(",")
						this.imgArr=b
						for(var i=0;i<b.length;i++){
							this.envimgs.push({url:this.$imgUrl(b[i])})
						}
					}else{
						this.envimgs=""
					}
					if(res.result.video_pic!=''){
						var c = [{url: ""}];
						c[0].url = this.$imgUrl(res.result.video_pic);
						this.videoimg=c;
						this.videoUrl=res.result.video_url
					}else{
						this.videoimg=''
					}

				}
			})
			}
			this.industry = o.scope_index
			// 得到自身的定位(WX只支持国标局的格式)
	
		},
		data() {
			return {
				loadingShow:true,
				// 判断是否是重新审核
				Reexamine:false,
				// 视频封面返显
				videoImgShow:"",
				// 店铺照片返显列表
				merchantLogo:"",
				token:"",
				position: [{
					latitude: "",
					longitude: ""
				}],
				//上传地址
				action: this.$uptImgUrl,
				//店铺名称
				storeName: "",
				//联系人
				name: "",
				//会员手机号
				userPhone: "",
				//商户分类
				industry: "",
				//联系电话
				phone: "",
				//店铺简介
				textareaValue: "",
				//省市区
				address: "",
				//区
				county: "",
				//市
				city: "",
				//省
				province: "",
				//详细地址
				addressDetail: "",
				// 店铺图标
				shopLogo: "",
				//环境照片 数组
				envimgs: [],
				// 视频封面图
				videoCover: "",
				//视频路径
				videoUrl: "",
				taking: '开始时间', //营业时间
				takingend: '结束时间',
				open_time: '', //营业时间(集合)
				startDate: '',
				endDate: '',
				isChoiceAddShow: false,
				//文本域的内容
				textValue: "",
				//纬度
				latitude: "",
				//经度
				longitude: "",
				//接受数据的对象
				item: {},

				id: 0, // 使用 marker点击事件 需要填写id
				title: 'map',
				videoUrl: "",
				videoimg: "",
				regionId1: "",
				regionId2: "",
				regionId3: "",
				imgArr:[],
				goodsID:"",
			}
		},
		methods: {
			opensetting(){
				uni.openSetting({
					success:(res)=>{
						console.log(res)
					}
				})
			},
			// 删除店铺LOGO
			removeLogo(){
				this.merchantLogo=""
			},
			// 匹配unicode表情字符
			delemoji(e){
				console.log(e)
				storeName = storeName.replace(/\uD83C[\uDF00-\uDFFF]|\uD83D[\uDC00-\uDE4F]/g, '');
			},
			//删除环境图片
			removeArr(index){
				this.imgArr.splice(index,1);
			},
			// 删除视频
			delVideoUrl(){
				this.videoUrl=""
			},
			removeVideoImg(){
				this.videoimg=""
			},
			// 获取地区选择的位置
			getaddress() {
				var that=this
				uni.chooseLocation({
					success: function(res) {
						that.longitude=res.longitude
						that.latitude=res.latitude
						that.position[0].longitude=res.longitude
						that.position[0].latitude=res.latitude
						that.addressDetail=res.address
					},
					fail:function(res){
						console.log(res)
						if(res.errMsg=='chooseLocation:fail auth deny')
						uni.showModal({
							title:"请授权位置信息",
							content:"检测到您未打开地理位置权限,请前往开启",
							confirmText:"前往开启",
							showCancel:false,
							success:(res)=>{
								uni.openSetting({
									success:(res)=>{
									}
								})
							}
						})
							// uni.openSetting({
							// 	success:(res)=>{
							// 	}
							// })
							
					}
				});
			},
			// 开始时间
			bindDateChange(e) {
				console.log(e)
				this.taking = e.target.value;
			},
			// 结束时间
			bindDateChanges(e) {
				this.takingend = e.target.value;
			},
			choiceAdd() {
				this.isChoiceAddShow = true
			},
			addConfirm(e) {
				let str = ""
				str = e.province.label + " " + e.city.label + " " + e.area.label
				this.address = str
				this.province = e.province.label.replace(/(省|市|自治区|自治州|县|区)/g, '')
				this.city = e.city.label.replace(/(省|市|自治区|自治州|县|区)/g, '')
				this.county = e.area.label.replace(/(省|市|自治区|自治州|县|区)/g, '')
				console.log(this.province, this.city, this.county)
				// this.county=str1


				agentCenterApi.city({
					city_name: this.province
				}).then(res => {
					// console.log(res)
					this.regionId1 = res.result.region_id
				})
				agentCenterApi.city({
					city_name: this.city
				}).then(res => {
					// console.log(res)
					this.regionId2 = res.result.region_id
				})
				agentCenterApi.city({
					city_name: this.county
				}).then(res => {
					// console.log(res)
					this.regionId3 = res.result.region_id
				})
			},
			imgChange(e) {
				this.merchantLogo = e.result
			},
			imgChange1(e) {
				console.log("得到的返回值")
				console.log(e)
				// this.files = this.$refs.uUpload.lists;
				this.imgArr.push(e.result)
			},
			// 上传视频图片封面获得图片
			imgChange6(e) {
				this.videoimg = e.result
			},
			upvideo() {
				this.loadingShow=false
				var that = this;
				wx.chooseVideo({
					sourceType: ["album"],
					success(res) {
						wx.uploadFile({
							url:that.$uptImgUrl,
							filePath: res.tempFilePath,
							name: "file",
							success(res) {
								console.log(res)
								that.videoUrl = JSON.parse(res.data).result
								console.log(that.videoUrl)
								that.loadingShow=true
							},
							fail(){
								that.loadingShow=true
							}
						})
					},
					fail(){
						that.loadingShow=true
					}
				})
			},
			next() {
				if(!this.storeName){
					uni.showToast({
						title:"请输入店铺名称",
						icon:"none"
					})
					return
				}
				if(!this.name){
					uni.showToast({
						title:"请输入联系人姓名",
						icon:"none"
					})
					return
				}
				if(!this.phone){
					uni.showToast({
						title:"请输入联系人电话",
						icon:"none"
					})
					return
				}
				if(this.taking=="开始时间"||this.takingend=="结束时间"){
					uni.showToast({
						title:"请输入完整的营业时间",
						icon:"none"
					})
					return
				}
				if(!this.textareaValue){
					uni.showToast({
						title:"请输入店铺简介",
						icon:"none"
					})
					return
				}
				if(!this.address){
					uni.showToast({
						title:"请输入门店地址",
						icon:"none"
					})
					return
				}
				if(this.position[0].latitude==''||this.position[0].latitude==''){
					uni.showToast({
						title:"请选择地图地址",
						icon:"none"
					})
					return
				}
				if(!this.merchantLogo){
					uni.showToast({
						title:"请上传店铺logo图片",
						icon:"none"
					})
					return
				}
				if(this.imgArr.length==0){
					uni.showToast({
						title:"请上传店铺环境照片",
						icon:"none"
					})
					return
				}
				if(this.Reexamine==true){
					this.item.userPhone=this.userPhone
					this.item.merchant_id=this.goodsID
				}else{
					//会员手机号
					this.item.phone = this.userPhone
				}
				if(this.loadingShow==false){
					uni.showToast({
						title:"视频正在上传，请稍后",
						icon:"none"
					})
					return
				}
				console.log("店铺环境图片列表")
				console.log(this.imgArr)
				//商户分类
				this.item.industry = this.industry
				//店铺名称
				this.item.storeName = this.storeName
				//省
				this.item.province = this.regionId1
				//市
				this.item.city = this.regionId2
				//区
				this.item.county = this.regionId3
				//联系人名称
				this.item.name = this.name
				//联系电话
				this.item.merchant_tel = this.phone
				//营业开始时间
				this.item.start = this.taking
				//营业结束时间
				this.item.end = this.takingend
				//店铺简介
				this.item.desp = this.textareaValue
				//纬度
				this.item.latitude = this.latitude
				//经度
				this.item.longitude = this.longitude
				//详细地址
				this.item.merchant_address = this.addressDetail
				//环境照片
				this.item.license_image = this.imgArr.toString()
				// 店铺图标
				if(this.merchantLogo[0].url){
					this.item.merchant_logo =this.$delimgUrl(this.merchantLogo[0].url) 
				}else{
					this.item.merchant_logo = this.merchantLogo
				}
				if(this.videoimg!=''){
					if(this.videoimg[0].url){
						this.item.video_pic =this.$delimgUrl(this.videoimg[0].url)
					}else{
						this.item.video_pic = this.videoimg
					}
				}else{
					this.item.video_pic = this.videoimg
				}
				// 视频封面图片
				// this.item.video_pic = this.videoimg
				// 视频地址
				this.item.video_url = this.videoUrl
				if(this.item.video_pic==""&&this.item.video_url==""){
					uni.navigateTo({
						url: '../shopAptitude/shopAptitude?item=' + encodeURIComponent(JSON.stringify(this.item))
					})
					
				}else if(this.item.video_pic!=""&&this.item.video_url!=""){
					uni.navigateTo({
						url: '../shopAptitude/shopAptitude?item=' + encodeURIComponent(JSON.stringify(this.item))
					})
				}else{
					uni.showToast({
						title:"视频封面图片与视频必须同时上传,请检查",
						icon:"none"
					})
				}
			}

		}
	}
</script>

<style scoped lang="scss">
	.red {
		margin: 0 auto;
		height: 56rpx;
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #FF4747;
	}
	.main-box {

		// background-color: red;
		.top {
			width: 690rpx;
			margin: 0 auto;
		}

		.timeFrame {
			color: #999999;
			font-size: 26rpx;
			display: flex;
			align-items: center;


		}

	}
	.xbtn-blue {
		width: 690rpx;
		height: 90rpx;
		background-color: #4894FE;
		color: #FFFFFF;
		text-align: center;
		line-height: 90rpx;
		font-size: 36rpx;
		border-radius: 10rpx;
		margin-top: 30rpx;

	}

	/* 白底按钮 */
	.xbtn-white {
		width: 690rpx;
		height: 90rpx;
		background-color: #FFFFFF;
		color: #4794FF;
		border: 1rpx solid #4794FF;
		border-radius: 10rpx;
		text-align: center;
		line-height: 90rpx;
		font-size: 36rpx;

	}

	/* 高度90 between对齐 带下边框 */
	.xline-bet {
		height: 83rpx;
		display: flex;
		align-items: center;
		justify-content: space-between;
		border-bottom: 1rpx solid #F5F5F5;
	}

	/* 高度90 between对齐 不带下边框  用于末尾元素*/
	.xline-bet-end {
		height: 83rpx;
		display: flex;
		align-items: center;
		justify-content: space-between;
	}

	.xblack {
		color: #333333;
	}

	.xgray {
		color: #666666;
	}

	.xline {
		width: 100%;
		height: 1rpx;
		background-color: #F5F5F5
	}

	.xline20 {
		width: 100%;
		height: 20rpx;
		background-color: #F5F5F5
	}

	.xline20fff {
		width: 100%;
		height: 10rpx;
		background-color: #FFFFFF
	}

	.xbt {
		display: flex;
		align-items: center;
		justify-content: space-between;
	}

	.xev {
		display: flex;
		align-items: center;
		justify-content: space-evenly;
	}

	.xal {
		display: flex;
		align-items: center;

	}

	.xflex {
		display: flex;
	}

	.top-txt {
		text-align: right;
	}

	.top-txt-left {
		font-size: 26rpx;
	}

	.top-txt-right {
		font-size: 26rpx;
	}

	.timeFrame {
		font-size: 26rpx;
	}

	.area {
		font-size: 26rpx;
	}

	.unact {
		color: #999999;
	}

	.act {
		color: #333333;
	}

	.btm {
		width: 690rpx;
		height: 300rpx;
		background-color: #FFFFFF;

		// padding: 0 30rpx;
		.btm-text {
			text-align: left;
			position: relative;
			width: 690rpx;
			height: 200rpx;
			background: #F5F5F5;
			border-radius: 10rpx;

			overflow: hidden;

			text {
				width: 100%;
			}

			.theTextarea {
				padding: 10rpx 20rpx 0;
				width: 100%;
				height: 100%;
				color: #999999;
				font-size: 26rpx;

			}
		}

		.btm-reason {
			text-align: left;
			height: 75rpx;
			line-height: 75rpx;
			font-size: 24rpx;
		}
	}

	.content {

		.add-box {
			.add-box-top {
				height: 103rpx;
				padding: 0 30rpx;
				display: flex;
				flex-wrap: wrap;
				align-items: center;
				font-size: 26rpx;

				input {
					width: 690rpx;
					overflow: hidden;
				}
			}

			.add-box-content {
				width: 730rpx;
				margin: 0 auto;
				height: 288rpx;
			}
		}

		.shop-box {
			height: 196rpx;
			padding: 0 30rpx;
			margin-top: 30rpx;
			display: flex;
			align-items: center;
			justify-content: space-between;

			.shop-box-left {
				height: 100%;
				display: flex;
				flex-direction: column;
				justify-content: space-evenly;
				text-align: left;

			}

			.shop-box-right {
				width: 130rpx;
				height: 130rpx;
				background-color: pink;
			}
		}
	}

	.environment-box {
		// height: 315rpx;
		padding: 0 30rpx;

		.environment-box-top {
			height: 156rpx;
			display: flex;
			flex-direction: column;
			justify-content: space-evenly;
		}
	}

	.theline-1 {
		font-size: 26rpx;
		color: #222222;
	}

	.theline-2 {
		font-size: 24rpx;
		color: #999999;
	}

	.theline-3 {
		font-size: 24rpx;
		color: #999999;
	}

	.slot-btn {
		// width: 329rpx;
		height: 140rpx;
		display: flex;
		justify-content: center;
		align-items: center;
		// background: rgb(244, 245, 246);
		border-radius: 10rpx;
	}

	.slot-btn__hover {
		background-color: rgb(235, 236, 238);
	}

	.uptVideo-box {
		display: flex;
		justify-content: space-between;
		align-items: center;
		margin-top: 20rpx;
		padding: 0 30rpx;
		height: 130rpx;

		.uptVideo-box-left {
			display: flex;
			height: 100%;
			flex-direction: column;
			justify-content: space-around;
		}

		.uptVideo-box-right {
			width: 130rpx;
			height: 130rpx;
			// background-color: pink;

		}
	}

	.btn1 {
		margin: 80rpx auto;
		margin-bottom: 20rpx;
	}
</style>
