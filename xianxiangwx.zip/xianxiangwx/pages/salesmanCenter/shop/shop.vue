<template>
	<view class="main-box">
		<view class="swiper-box">
			<hswiper swiperHeight="276" :cdnUrl="theCdn" :coverImg="coverUrl" :imgList="BannerimgList" :videoSrc="videoUrl"
			 :swiperWidth="690" :test="test"></hswiper>
		</view>

		<view class="shopinfo-box">
			<view class='left'>
				<image :src="$imgUrl(shopObj.merchant_logo)"></image>
			</view>
			<view class='mid'>
				<view class='line1'>{{shopObj.merchant_name}}</view>
				<view class='line2'>营业时间：{{shopObj.merchant_worktime_start}}-{{shopObj.merchant_worktime_end}}</view>
				<view class='line3'>年费到期时间：{{timeDue(shopObj.expire_time)}}</view>
			</view>
		</view>
		<view class="xline" style="height: 20rpx;">

		</view>
		<view class="addr-box">
			<view class='line1'>
				<view class='left'>店铺简介：</view>
				<!-- <view class='right'>{{shopObj.merchant_desp}}</view> -->
				<view class='right'>
					{{shopObj.merchant_desp}}
				</view>

			</view>
			<view class='line2' @click="toMap">
				<view class='left'>地 <text style="margin-left: 50rpx;">址：</text></view>
				<view class='right'>{{shopObj.merchant_address}}
					<image src="../../../static/map.png" mode="aspectFill"></image>
				</view>

			</view>
			<view class='line3'>
				<view class='left'>联系电话：</view>
				<view class='right' @click="call">{{shopObj.merchant_tel}}</view>
				<view class="pic" @click="call">
					<image src="../../../static/phoneblue.png" mode="aspectFill"></image>
				</view>
			</view>
		</view>

		<view class="xline" style="height: 20rpx;"></view>
		<view class="goods-box">

			<view class='line'>
				<image src="../../../static/box-blue.png" mode="aspectFill"></image>店铺产品
			</view>
			<view class="goods-item" v-for=" (item,index) in goodsList.data" :key="index">

				<view class='line2'>
					<image :src="$imgUrl(item.goods_icon)" mode="aspectFill"></image>
				</view>
				<view class='line3'>
					{{item.goods_name}}
				</view>
				<view class='line4'>
					<view class='left'>￥{{item.stage}}</view>
					<view class='mid'>x{{item.goods_type}}期</view>
					<view class='right'>￥{{item.goods_cost}}</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import hswiper from "../../../components/h-swiper.vue"
	import shophomeApi from "../../../api/salesmanCenter/salesmanCenter.js"

	export default {
		components: {
			hswiper
		},
		data() {
			return {
				videoUrl: "",
				coverUrl: "",
				imgUrl: [""],
				theCdn: "",
				shopObj: {},
				BannerimgList: [],
				test: "111",
				longitude: "",
				latitude: "",
				//商家手机
				merPhone: "",
				//是否关注
				focus: "-1",
				token: "",
				//商家id
				merchant_id: "",
				//页数
				page: "1",
				//一页多少条
				count: "10",
				goodsList: {
					data: []
				},
				//用户电话
				userPhone: ""
			}
		},
		onLoad(options) {
			this.merchant_id = options.id
			this.userPhone = options.phone
			this.theCdn = this.$cdnUrl

			//商户id
			// this.merchant_id=options.merchant_id

			this.token = uni.getStorageSync('xxytoken')

			shophomeApi.shopHome({
				merchant_id: this.merchant_id,
				phone: this.userPhone,
				token: uni.getStorageSync('xxytoken')
			}).then(res => {
				if (res.status == 200) {
					// console.log(res.result.merchant_image)
					this.shopObj = res.result
					this.BannerimgList = res.result.merchant_image.split(",")

					this.test = "改变后"
					// console.log(this.test)
					this.videoUrl = res.result.video_url
					this.coverUrl = res.result.video_pic
					this.longitude = res.result.merchant_longitude
					this.latitude = res.result.merchant_latitude
					this.merPhone = res.result.merchant_tel
					this.focus = res.result.focus
				} else {
					uni.showToast({
						title: res.message,
						icon: "none"
					})
				}

			})
			//拿店铺内商品列表
			this.getnewsList()
		},
		// 下拉加载更多
		onReachBottom() {
			if (this.page < this.goodsList.last_page) {
				++this.page;
				this.getnewsList();
			} else {
				uni.showToast({
					title: "没有更多数据了",
					icon: "none"
				})
			}
		},
		methods: {
			// 拿到店铺商品列表
			getnewsList() {
				shophomeApi.merchant_goods_list({
					merchant_id: this.merchant_id,
					page: this.page,
					count: "10"
				}).then(res => {
					if (this.goodsList.data.length > 0) {
						this.goodsList.data = this.goodsList.data.concat(res.result.data); //将数据拼接在一起
					} else if (res.result != null) {
						this.goodsList = res.result
					} else {
						this.goodsList = {
							data: []
						}
					}
				})
			},
			toMap() {
				uni.openLocation({
					longitude: Number(this.longitude),
					latitude: Number(this.latitude),
					// name: "11",
					// address: "22222"
				})
			},
			// 吊起拨打电话
			call() {
				uni.makePhoneCall({
					phoneNumber: this.merPhone,
					success: () => {
						// console.log("成功拨打电话")
					}
				})
			},
			// 处理到期时间
			timeDue(e){
				console.log(e)
				if(e==0){
					return "暂未缴费"
				}else if(e==-1){
					return "永久"
				}else{
					return this.$timeConvert(e,0)
				}
			},
		}
	}
</script>
<style>
	page {
		background: #FFFFFF
	}
</style>
<style lang="scss" scoped>
	.main-box {}

	.swiper-box {
		margin: 0 30rpx;
		margin-top: 21rpx;
		border-radius: 10rpx;
		overflow: hidden;
	}

	.goods-box {
		margin: 0 30rpx 100rpx 30rpx;
		background-color: #FFFFFF;

		.goods-item {

			margin-top: 20rpx;

			border: 1rpx solid #EEEEEE;
			box-shadow: 0rpx 2rpx 2rpx 0rpx rgba(38, 86, 165, 0.06);
			border-radius: 10rpx;
		}

		.line {
			height: 36rpx;
			display: flex;
			align-items: center;
			margin-top: 30rpx;

			image {
				width: 34rpx;
				height: 34rpx;
				margin-right: 10rpx;
			}
		}

		.line2 {
			width: 690rpx;
			height: 276rpx;
			margin-top: 20rpx;
			border-radius: 10rpx 10rpx 0rpx 0rpx;
			overflow: hidden;

			image {
				width: 100%;
				height: 100%;

			}


		}

		.line3 {
			padding: 0 16rpx;
			height: 76rpx;
			line-height: 76rpx;
		}

		.line4 {
			padding: 0 16rpx;
			display: flex;
			align-items: center;
			height: 69rpx;
			line-height: 69rpx;

			.left {
				font-size: 30rpx;
				color: #4794FF;
			}

			.mid {
				font-size: 26rpx;
				color: #85B8FF;
			}

			.right {
				margin-left: 18rpx;
				color: #999999;
				font-size: 30rpx;

				text-decoration: line-through;
			}
		}
	}

	.addr-box {
		margin: 0 30rpx;
		background-color: #FFFFFF;
		font-size: 26rpx;
		font-weight: 400;
		color: #333333;

		.line1 {
			display: flex;

			margin-top: 20rpx;

			.left {
				width: 130rpx;
			}

			.right {
				width: 540rpx;

			}
		}

		.line2 {
			margin-top: 40rpx;
			display: flex;

			.left {
				width: 130rpx;
			}

			.right {
				width: 540rpx;
				display: flex;
				align-items: center;

				image {
					margin-left: 20rpx;
					width: 50rpx;
					height: 36rpx;
				}
			}

		}

		.line3 {
			display: flex;
			height: 30rpx;
			margin-top: 20rpx;
			align-items: center;
			margin-bottom: 20rpx;

			.left {
				width: 130rpx;
			}

			.right {
				color: #4794FF;
				// width: 514rpx;

				text-decoration: underline;
			}

			.pic {
				margin-left: 10rpx;

				image {
					width: 26rpx;
					height: 26rpx;
				}
			}
		}
	}

	.shopinfo-box {
		margin: 0 30rpx;
		display: flex;
		justify-content: flex-start;
		align-items: center;
		margin-top: 20rpx;
		background-color: #FFFFFF;
		margin-bottom: 30rpx;

		.left {
			width: 119rpx;
			height: 120rpx;
			border-radius: 6rpx;

			image {
				width: 100%;
				height: 100%;

			}
		}

		.mid {
			margin-left: 20rpx;

			.line1 {
				margin-top: 8rpx;
				font-size: 36rpx;
			}

			.line2 {
				margin-top: 6rpx;
				color: #999999;
				font-size: 26rpx;
			}

			.line3 {
				margin-top: 6rpx;
				font-size: 24rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #4794FF;
			}
		}

		.right {

			text-align: center;
			line-height: 47rpx;

			.right-top {
				margin-top: 10rpx;
				width: 118rpx;
				height: 47rpx;
				background: #4794FF;
				border-radius: 24rpx;

				font-size: 24rpx;
				color: #FFFFFF;
			}

			.right-bottom {
				margin-top: 10rpx;
				width: 118rpx;
				height: 47rpx;
				background: #FFFFFF;
				border: 1rpx solid #4794FF;
				border-radius: 24rpx;

				font-size: 24rpx;

				color: #4794FF;
			}
		}
	}
</style>
