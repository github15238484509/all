<template>
	<view class="box">
		<view class="header">
			<view class="header-l">
				<image class="user" :src="$imgUrl(user.photo)"></image>
				<view class="text">
					<view class="u-name">
						{{user.name}}
					</view>
					<view class="phone">
						{{user.phone}}
					</view>
					<view class="to" @click="open" v-if="isSuperiorAgent">
						查看代理商信息
					</view>
					<view v-if="!isSuperiorAgent" class="to" style="	text-decoration: none;">
						暂无上级代理商
					</view>
				</view> 
			</view>
			<view class="header-r">
				<img src="../../static/退出登录.png" alt="" style="width: 200rpx;height: 70rpx;" @click="log_out">
			</view>

		</view>
		<view class="banner">
			<image class="img" src="../../static/lb.png"></image>
			<view class="page-section swiper">
				<view class="page-section-spacing">
					<swiper class="swiper" :autoplay="true" :interval="3000" :vertical="true" :circular="true">
						<swiper-item class="swiper-item" v-for="(item,index) in title" :key="index" >
							<view class="swiper-text" @click="goNoticeList(item)">{{item.title}}</view>
						</swiper-item>

					</swiper>
				</view>
			</view>
			<view class="swiper-link" @click="goNotice">
				全部>>
			</view>
		</view>
		<view class="nav">
			<u-sticky>
				<div class="content-nav">
					<div class="nav-item" :class="{active: current=='4'}" @tap="currentChange('4')">
						<text class="text">新录入</text>
					</div>
					<div class="nav-item" :class="{active: current=='1'}" @tap="currentChange('1')">
						<text class="text">营业中</text>
					</div>
					<div class="nav-item" :class="{active: current=='2'}" @tap="currentChange('2')">
						<text class="text">即将到期</text>
					</div>
					<div class="nav-item" :class="{active: current=='3'}" @tap="currentChange('3')">
						<text class="text">已到期</text>
					</div>
				</div>
			</u-sticky>
		</view>
		<div v-show="current == 1" class="content">
			<view v-if="shopList.data.length==0" style="text-align: center;padding-top: 207rpx;"> <img :src="cdnUrl+'XianxiangUapi/static/datanull.png'" alt="" style="width: 470rpx;height: 345rpx;"></view>
			<view class="score-item" v-for="item in shopList.data" :key="item.merchant_id" @click.stop="go(item)"  >
				<view class="left1">
					<image :src="$imgUrl(item.merchant_logo)" mode="aspectFill"></image>
				</view>
				<view class="right1">
					<view class="rline1">
						{{item.merchant_name}}
						<image src="../../static/phone1.png" class="img" @click.stop="markPhone(item)"></image>
					</view>
					<view class="rline2">
						{{item.merchant_address}}
					</view>
					<view class="rline3">
						<image src="/static/time.png" mode="aspectFill"></image>
						<text class="line-txt">{{item.merchant_worktime_start}}-{{item.merchant_worktime_end}}</text>
					</view>
					<view class="rline4">
						<text v-if="item.merchant_status==3" class="line-txt">年费到期时间:{{timeDue(item.expire_time)}}</text>
						<text v-if="item.merchant_status==1"  class="line-txt">审核中</text>
						<view class="refuse" v-if="item.merchant_status==4">
							<view class="fff">
								审核驳回
							</view>
							<view class="ml" @click.stop="goStatus(item.merchant_id)">
								点击查看原因>>
							</view>
						</view>
					</view>
				</view>
			</view>
		</div>
		<div v-show="current == 2" class="content">
			<view v-if="shopList.data.length==0" style="text-align: center;padding-top: 207rpx;"> <img :src="cdnUrl+'XianxiangUapi/static/datanull.png'" alt="" style="width: 470rpx;height: 345rpx;"></view>
			<view class="score-item" v-for="item in shopList.data" :key="item.merchant_id" @click="go(item)">
				<view class="left1">
					<image :src="$imgUrl(item.merchant_logo)" mode="aspectFill"></image>
				</view>
				<view class="right1">
					<view class="rline1">
						{{item.merchant_name}}
						<image src="../../static/phone1.png" class="img" @click="markPhone(item)"></image>
					</view>
					<view class="rline2">
						{{item.merchant_address}}
					</view>
					<view class="rline3">
						<image src="/static/time.png" mode="aspectFill"></image>
						<text class="line-txt">{{item.merchant_worktime_start}}-{{item.merchant_worktime_end}}</text>
					</view>
					<view class="rline4">

						<text class="line-txt" style="color:red;">年费到期时间:{{timeDue(item.expire_time)}}</text>

					</view>
				</view>
			</view>
		</div>
		<div v-show="current == 3" class="content">
			<view v-if="shopList.data.length==0" style="text-align: center;padding-top: 207rpx;"> <img :src="cdnUrl+'XianxiangUapi/static/datanull.png'" alt="" style="width: 470rpx;height: 345rpx;"></view>
			<view class="score-item" v-for="item in shopList.data" :key="item.merchant_id" @click="go(item)">
				<view class="left1">
					<image :src="$imgUrl(item.merchant_logo)" mode="aspectFill"></image>
				</view>
				<view class="right1">
					<view class="rline1">
						{{item.merchant_name}}
						<image src="../../static/phone1.png" class="img" @click="markPhone(item)"></image>
					</view>
					<view class="rline2">
						{{item.merchant_address}}
					</view>
					<view class="rline3">
						<image src="/static/time.png" mode="aspectFill"></image>
						<text class="line-txt">{{item.merchant_worktime_start}}-{{item.merchant_worktime_end}}</text>
					</view>
					<view class="rline4">

						<text v-if="item.merchant_expire_type!='1'" class="line-txt"
							style="color:red;">年费到期时间:{{timeDue(item.expire_time)}}</text>
						<text v-if="item.merchant_expire_type=='1'" class="line-txt" style="color:red;">暂未缴纳年费</text>
					</view>
				</view>
			</view>
		</div>
		<div v-show="current == 4" class="content">
			<view v-if="shopList.data.length==0" style="text-align: center;padding-top: 207rpx;"> <img :src="cdnUrl+'XianxiangUapi/static/datanull.png'" alt="" style="width: 470rpx;height: 345rpx;"></view>
			<view class="score-item" v-for="item in shopList.data" :key="item.merchant_id" @click="goStatus(item.merchant_id)">
				<view class="left1">
					<image :src="$imgUrl(item.merchant_logo)" mode="aspectFill"></image>
				</view>
				<view class="right1">
					<view class="rline1">
						{{item.merchant_name}}
						<image src="../../static/phone1.png" class="img" @click.stop="markPhone(item)"></image>
					</view>
					<view class="rline2">
						{{item.merchant_address}}
					</view>
					<view class="rline3">
						<image src="/static/time.png" mode="aspectFill"></image>
						<text class="line-txt">{{item.merchant_worktime_start}}-{{item.merchant_worktime_end}}</text>
					</view>
					<view class="rline4">
						<text v-if="item.merchant_status==1"  class="line-txt">代理商审核中</text>
						<text v-if="item.merchant_status==2"  class="line-txt">平台审核中</text>
						<view class="refuse" v-if="item.merchant_status==4">
							<view class="fff">
								审核驳回
							</view>
							<view class="ml" @click.stop="goStatus(item.merchant_id)">
								点击查看原因>>
							</view>
						</view>
					</view>
				</view>
			</view>
		</div>

		<navigator url="./addSeller/addSeller?id=2" hover-class="navigator-hover" class="footer">
			<view class="add">
				<image src="../../static/add1.png" class="img"></image>
				<text>录入商家</text>
			</view>
		</navigator>
		<uni-popup ref="popup" type="center">
			<view class="dialog">
				<view class="dia-t">
					<view class="title">
						代理商信息
					</view>
					<image src="../../static/close.png" class="img" @tap="close"></image>
				</view>
				<view class="dia-c">
					<view class="pic">
						<view class="text">
							用户头像：
						</view>
						<image :src="$imgUrl(obj.photo)" class="img"></image>
					</view>
					<view class="name">
						用户昵称：{{obj.name}}
					</view>
					<view class="level">
						<view>
							等
						</view>
						<view class="text">

							级：代理商
						</view>
					</view>
					<view class="phone">
						<text>
							手 机 号：
						</text>

						<text class="blue">
							{{obj.phone}}
						</text>
						<image src="../../static/phone1.png" class="img" @click="makeCall"></image>
					</view>
				</view>
			</view>
		</uni-popup>
		<view>
			<u-mask :show="showNews" @click="showNewsFun">
				<view style="position: relative;">
					<view class="noticePopup"  @click="goNoticeList(alertNewsList)">
						<view class="alertNewsTitle">
							{{alertNewsList.title}}
						</view>
						<veiw class="alertNewsTime">
							<view>
								时间:{{$timeConvert(alertNewsList.add_time)}}
							</view>
							<view>
								发布人:{{alertNewsList.edit_user}}
							</view>
						</veiw>
						<view  class="noticeContent">
							<rich-text :nodes="alertNewsList.url_content"></rich-text>
						</view>
						<view class="alertNewsBtn" style="border-top: 2rpx solid #F5F5F5;margin-top: 20rpx;">
							查看详情
						</view>
					</view>
					<img src="../../static/closeNews.png" alt=""
						style="position:absolute;width: 50rpx;height:98rpx;top:990rpx;z-index: 999999;left: 350rpx;margin: 0;">
				</view>
			</u-mask>
		</view>
	</view>
</template>

<script>
	import salesmanCenter from "../../api/salesmanCenter/salesmanCenter.js"
	import login from "../../api/login/login.js"
	import agentCenterApi from "../../api/agentCenter/agentCenter.js"
	export default {
		data() {
			return {
                cdnUrl:"",
				alertNewsList:"",
				showNews:false,
				//激活的tab栏
				current: '4',
				//代理商信息
				obj: {},
				//用户
				user: {},
				// 用户电话
				userPhone: "",
				//轮播
				title: [],
				//商家列表
				shopList: {
					data:[]
				},
				token: "",
				isSuperiorAgent:true,
			}
		},
		// 下拉加载更多功能
		onReachBottom(){
			if(this.pageIndex<this.shopList.data.length){
				++this.pageIndex;
				this.init();
			}else{
				uni.showToast({
					title:"没有更多数据了",
					icon:"none"
				})
			}
		},
		// 页面加载前执行的函数
		onLoad(e) {
            this.cdnUrl=this.$cdnUrl
			this.token = uni.getStorageSync('xxytoken')
			this.userPhone = e.userPhone
			//轮播
			login.news({
				region: "2"
			}).then(res => {
				this.title = res.result
			})
			//代理商信息
			salesmanCenter.salesman_agent({
				token: this.token
			}).then(res => {
				if(res.status==200){
					this.isSuperiorAgent=true
					this.obj = res.result
				}else{
					this.isSuperiorAgent=false
				}
			})
			//会员信息
			login.welcome({
				token: this.token,
				phone: this.userPhone
			}).then(res => {
				console.log(res)
				this.user = res.result
			})
			// 查询用户强制弹窗
			agentCenterApi.get_alert_news({
				region: "2",
				token: this.token
			}).then(res => {
				if (res.status == 200 && res.result != null) {
					this.alertNewsList = res.result
					this.showNews = true
					if (res.result.title.length > 27) {
						this.alertNewsList.title = res.result.title.substring(0, 27) + "..."
					}
				}
			});
			//tab栏
			this.init()
		},
		methods: {
			showNewsFun(){
				agentCenterApi.get_alert_news({
					region: "2",
					token: this.token,
					id:this.alertNewsList.id
				}).then(res => {
					if (res.status == 200 ) {
						this.showNews = false
					}else{
						this.showNews = false
					}
				})
			},
			// 点击新闻详情
			goNoticeList(e){
				uni.navigateTo({
					url:"../newsDetail?url="+e.content+'&title='+e.title
				})
			},
			// 去公告页面
			goNotice(){
				uni.navigateTo({
					url:"../newsList?status=2"
				})
			},
			// 退出登录功能
			log_out(){
				login.logout({token:this.token}).then(res=>{
					if(res.status==200){
						uni.removeStorageSync("xxytoken");
						uni.removeStorageSync("userPhone");
						uni.reLaunch({
							url:"../login/welcome/welcome"
						})
					}
				})
			},
			// 拨打商家电话
			markPhone(e) {
				console.log(e)
				uni.makePhoneCall({
					phoneNumber: e.merchant_tel
				})
			},
			// 拨打上级代理商电话
			makeCall() {
				uni.makePhoneCall({
					phoneNumber: this.obj.phone
				})
			},
			//切换tab栏
			currentChange(e) {
				console.log(e)
				this.current = e
				this.shopList={data:[]}
				this.pageIndex=1
				this.init()
			},
			//弹出层
			open() {
				// 通过组件定义的ref调用uni-popup方法
				this.$refs.popup.open()
			},
			close() {
				this.$refs.popup.close()
			},
			// 查询业务员商家列表数据
			init() {
				salesmanCenter.user_merchant_list({
					token: uni.getStorageSync('xxytoken'),
					type: this.current,
					page: this.pageIndex,
					count: "10"
				}).then(res => {
					if(res.status==200&&res.result!=null){
						if(this.shopList.data.length>0){
							this.shopList.data=[...this.shopList.data,...res.result.data]
						}else{
							this.shopList=res.result
						}
					}else if(res.status!=200){
						uni.showToast({
							title:res.message,
							icon:"none"
						})
					}
				})
			},
			//跳转到商户详情
			go(e) {
				if(e.merchant_status)
				uni.navigateTo({
					url: `/pages/salesmanCenter/shop/shop?id=` + e.merchant_id + `&phone=` + this.userPhone
				})
			},
			goStatus(id){
				uni.navigateTo({
					url:"ApplySalesmanStatus?id="+id
				})
			},
			timeDue(e){
				if(e==0){
					return "暂未缴纳年费"
				}else if(e==-1){
					return "永久"
				}else{
					return this.$timeConvert(e,0)
				}
			}
		},
		computed: {
			type() {
				return Number(this.current) + 1 + "";
			}

		},
	}
</script>

<style lang="scss" scoped>
	.noticeContent{
		font-size: 28rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #999999;
		margin-top: 30rpx;
		width: 480rpx;
		height: 360rpx;
		overflow: hidden;
	}
	.alertNewsBtn {
		font-size: 32rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #4894FF;
		text-align: center;
		width: 100%;
		height: 90rpx;
		line-height: 90rpx;
	}
	
	.alertNewsTime {
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #999999;
	}
	
	.alertNewsTitle {
		height: 70rpx;
		font-size: 32rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #222222;
		margin-bottom: 30rpx;
	}
	
	.noticePopup {
		position: absolute;
		left: 105rpx;
		top:300rpx;
		width: 480rpx;
		height: 640rpx;
		background: #FFFFFF;
		border-radius: 10px;
		padding: 30rpx;
		border-bottom: 2rpx solid #F5F5F5;
	}
	.box {
		background-color: #F5F5F5;

		.header {
			display: flex;
			justify-content: space-between;
			align-items: center;
			height: 190rpx;
			width: 100%;
			background-color: #fff;

			.header-l {
				margin-left: 30rpx;
				display: flex;
				justify-content: space-between;

				.user {
					width: 120rpx;
					height: 120rpx;
					border-radius: 50%;
				}

				.text {
					text-align: center;
					margin-left: 30rpx;
					.u-name {
						width: 148rpx;
						line-height: 28rpx;
						font-size: 30rpx;
						font-family: PingFang SC;
						font-weight: 400;
						color: #333333;
						margin-top: 10rpx;
					}

					.phone {
						margin-top: 15rpx;
						line-height: 18rpx;
						font-size: 24rpx;
						font-family: PingFang SC;
						font-weight: 400;
						color: #999999;

					}
				}
			}

			.header-r {
				display: flex;
				align-items: center;
			}
		}

		.to {
			margin-top: 20rpx;
			width: 169rpx;
			height: 26rpx;
			font-size: 24rpx;
			font-family: PingFang SC;
			font-weight: 400;
			text-decoration: underline;
			color: #4794FF;

		}

		.banner {
			width: 750rpx;
			height: 80rpx;
			background: #DAEAFF;
			display: flex;
			justify-content: flex-start;
			align-items: center;

			.img {
				height: 32rpx;
				width: 32rpx;
				margin-left: 40rpx;

			}

			.swiper {
				height: 80rpx;
				width: 568rpx;

				.swiper-item {
					display: flex;
					justify-content: flex-start;
					align-items: center;


					.swiper-text {
						white-space: nowrap;
						text-overflow: ellipsis;
						overflow: hidden;
						word-break: break-all;
						width: 480rpx;
						font-size: 24rpx;
						font-family: PingFang SC;
						font-weight: 400;
						color: #333333;
						line-height: 66rpx;
						margin-left: 10rpx;
					}

				}

			}

			.swiper-link {
				font-size: 24rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #999999;
				// margin-left: 50rpx;
			}
		}

		.nav {
			background-color: #fff;
			margin-top: 20rpx;
			height: 70rpx;

			.content-nav {
				background-color: #fff;
				display: flex;
				justify-content: space-around;

				.nav-item {
					.text {
						width: 76rpx;
						height: 25rpx;
						font-size: 26rpx;
						font-family: PingFang SC;
						font-weight: 400;
						line-height: 66rpx;
					}
				}

				.active {
					border-bottom: 4rpx solid #4794FF;

					.text {
						color: #4794FF;
						font-weight: 500;
						font-size: 30rpx !important;
						line-height: 66rpx;
						font-family: PingFang SC;
						// height: 29rpx;
					}
				}
			}
		}

		.content {
			padding: 0 30rpx;
			background-color: #fff;
			margin-top: 2rpx;
			margin-bottom: 90rpx;
			.score-item {
				width: 690rpx;
				height: 200rpx;
				background: #FFFFFF;
				border-bottom: 1rpx solid #EEEEEE;
				border-radius: 10rpx;
				display: flex;
				align-items: center;
				// margin-bottom: 20rpx;

				.left1 {
					width: 179rpx;
					height: 180rpx;
					border-radius: 10rpx;
					margin-left: 11rpx;
					overflow: hidden;

					image {
						width: 180rpx;
						height: 180rpx;
					}
				}

				.right1 {
					margin-left: 22rpx;
					width: 458rpx;
					height: 100%;
					display: flex;
					flex-direction: column;
					justify-content: space-evenly;

					.rline1 {
						font-size: 30rpx;
						display: flex;
						justify-content: space-between;

						.img {
							width: 44rpx;
							height: 44rpx;

							border-radius: 50%;

						}
					}

					.rline2 {
						font-size: 24rpx;
						color: #666666;
						white-space: nowrap;
						text-overflow: ellipsis;
						overflow: hidden;
						word-break: break-all;

					}

					.rline3 {
						width: 500rpx;
						font-size: 24rpx;
						display: flex;
						align-items: center;

						image {
							width: 28rpx;
							height: 28rpx;
							margin-left: 1rpx;
						}
					}

					.rline4 {
						width: 500rpx;
						font-size: 24rpx;
						display: flex;
						align-items: center;

						// padding-left: 5rpx;
						image {
							width: 20rpx;
							height: 27rpx;
							margin-left: 6rpx;
						}

						.refuse {
							display: flex;
							align-items: center;
							justify-content: center;

							font-size: 24rpx;
							font-family: PingFang SC;
							font-weight: 400;
							color: #FE5E5E;

							.fff {
								border-bottom: 1rpx solid #FFF;
							}

							.ml {
								margin-left: 10rpx;
								border-bottom: 1rpx solid #FE5E5E;
							}
						}
					}

				}
			}

		}

		.footer {
			// z-index: 99999;
			position: fixed;
			left: 0;
			bottom: 0;
			display: flex;
			justify-content: center;
			height: 90rpx;
			width: 100%;
			background-color: #4794FF;

			.add {
				display: flex;
				align-items: center;
				font-size: 30rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: #FFFFFF;


				.img {
					width: 36rpx;
					height: 36rpx;
					margin-right: 20rpx;
				}
			}
		}
	}

	.line-txt {
		// width: 311px;
		// height: 23px;
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #4794FF;
	}

	.rline3 {

		.line-txt {
			margin-left: 10rpx;

			color: #333333;
		}
	}


	.dialog {
		width: 500rpx;
		height: 400rpx;
		background: #FFFFFF;
		border-radius: 10rpx;
		position: relative;
		overflow: hidden;

		.dia-t {
			text-align: center;
			margin-top: 50rpx;
			margin-bottom: 40rpx;

			.title {
				font-size: 36rpx;
				font-family: PingFang SC;
				font-weight: bold;
				color: #333333;
				line-height: 34rpx;
			}

			.img {
				position: absolute;
				top: 28rpx;
				right: 28rpx;
				width: 36rpx;
				height: 36rpx;
			}
		}

		.dia-c {
			font-size: 24rpx;
			font-family: PingFang SC;
			font-weight: 400;
			color: #333333;
			line-height: 23rpx;
			margin-left: 60rpx;

			.pic {
				display: flex;
				align-items: center;
				margin-bottom: 20rpx;

				.img {
					width: 70rpx;
					height: 70rpx;
					border-radius: 10rpx;
				}
			}

			.name {

				margin-bottom: 20rpx;
			}

			.level {
				display: flex;
				align-items: center;
				margin-bottom: 20rpx;

				.text {
					margin-left: 48rpx;
				}
			}

			.phone {
				// margin-top: 20rpx;

				display: flex;
				align-items: center;

				.img {
					width: 44rpx;
					height: 44rpx;
					margin-left: 50rpx;
				}

				.blue {
					color: #4695FE;
				}
			}

		}

	}
</style>
