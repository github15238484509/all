<template>
    <view class="main-box">
        <view class="content" v-if="isShow">
            <view class="content-top">
                <view class="dot">

                </view>
                <view class="">
                    <view class='line1'>信息提交成功,等待审核</view>
                    <view class='line2'>{{submit_time?$timeConvert(submit_time):""}}</view>
                </view>

            </view>
            <view class="content-btm" v-if="isFail">
                <view class="dot">
                </view>
                <view class="">
                    <view class='line1'>信息审核失败</view>
                    <view class='line2'>{{audit_time?$timeConvert(audit_time):""}}</view>
                    <view class='line3'>
                        失败原因：{{reject_reason?reject_reason:""}}
                        <text style="color: #4794FF;margin-left: 10rpx;" @click="goaddPage()">重新提交</text>
                    </view>
                </view>

            </view>
        </view>
        <view class="btm">
            审核时间为1-3天，如有疑问请联系客服
        </view>
    </view>
</template>

<script>
    import salesmanApi from "../../../api/agent/salesmanList.js"
    import salesmanCenterApi from "../../../api/salesmanCenter/salesmanCenter.js"
    export default {
        data() {
            return {
                //这个页面设一个isShow 如果拿到数据 才显示页面  如果拿不到 给个弹框 页面就不出了
                isShow: true,
                isFail: false,
                token: "",
                salesman: {},
                oldPhone: "",
                oldId: "",
                type: "",
                //提交时间
                submit_time:"",
                //审核状态1未审核2已通过3已拒绝
                audit_status:"",
                //审核时间
                audit_time:"",
                //拒绝原因
                reject_reason:""
            }
        },
        onLoad(e) {

            this.token = uni.getStorageSync('xxytoken');
            if (e.phone) {
                this.oldPhone = e.phone
                salesmanCenterApi.user_settlement_detail({
                    phone: e.phone
                }).then(res => {
                    if (res.status == 200) {
						console.log(res);
                        this.salesman = res.result
                        this.audit_status = res.result.card_status
                        this.submit_time = res.result.card_submit_time
                        this.audit_time = res.result.card_pass_time
                        this.reject_reason = res.result.card_refuse_reason
                        
                        if (res.result.card_status == -1) {
                            this.isFail = true
                        }
                    }
                })
            } else if (e.id) {
				
                this.oldId = e.id
				
                salesmanApi.getSalesmanList({
                    token: this.token,
                    user_id: e.id
                }).then(res => {
                    if (res.status == 200) {
						
                        this.salesman = res.result
                        this.audit_status = res.result.card_status
                        this.submit_time = res.result.card_submit_time
                        this.audit_time = res.result.card_pass_time
                        this.reject_reason = res.result.card_refuse_reason
                        if (res.result.card_status == -1) {
                            this.isFail = true
                        }
                    }
                })
            } else if (e.type) {
                this.type = e.type
                console.log(e.type)
                salesmanCenterApi.user_tockStatus().then(res => {
                    // this.goodsDailList = res.result
                    this.salesman = res.result
                    this.audit_status = res.result.card_status
                    this.submit_time = res.result.submit_time
                    this.audit_time = res.result.audit_time
                    this.reject_reason = res.result.reject_reason
                    if (res.result.card_status == 3) {
                        this.isFail = true
                    }
                    console.log(res.result.card_status)
                })
            }

        },
        methods: {
            goaddPage() {
                uni.navigateTo({
                    url: "../ApplysSalesman?id=" + this.oldId + "&isre=true" + "&type=" + this.type +"&phone66="+this.oldPhone
                })
            }
        }
    }
</script>

<style lang="scss" scoped>
    .btm {
        width: 100%;
        position: fixed;
        left: 50%;
        bottom: 20rpx;
        transform: translate(-50%, -50%);
        font-size: 26rpx;
        text-align: center;
        font-weight: 500;
        color: #999999;
    }

    .main-box {
        overflow: hidden;
    }

    .content {
        margin-left: 60rpx;
        position: relative;
        margin-top: 50rpx
    }

    .content-top {
        display: flex;
        align-items: center;
        margin-top: 50rpx;
        font-size: 24rpx;
        color: #999999;

        .line1 {
            font-size: 26rpx;
            color: #333333;
        }

        .line2 {
            font-size: 24rpx;
            color: #999999;
        }
    }

    .content-btm {
        display: flex;
        align-items: center;
        margin-top: 65rpx;
        font-size: 24rpx;
        color: #999999;

        .line1 {
            font-size: 26rpx;
            color: #333333;
        }

        .line2 {
            font-size: 24rpx;
            color: #999999;
        }

        .line3 {
            font-size: 24rpx;
            color: #999999;
        }
    }

    .dot {
        width: 20rpx;
        height: 20rpx;
        background: #4794FF;
        border-radius: 50%;
        margin-right: 16rpx;
    }

    .dot-line {
        width: 2rpx;
        height: 80rpx;
        left: 10rpx;
        top: 30%;
        background: #4794FF;
        position: absolute;
    }
</style>
