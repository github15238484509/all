<template>
    <!-- v-if="theStatus=='99'" -->
    <view class="main-box">
        <view class="top">
            <view class='line1 line'>
                <view class="img">
                    <image src="../../static/salesManAct.png" mode="aspectFill"></image>
                </view>

                <view class="top-txt" style="color: #4794FF;">
                    上传身份证
                </view>
            </view>
            <view class="step-line">

            </view>
            <view class='line2 line'>
                <view class="img">
                    <image src="../../static/salesMan2.png" mode="aspectFill"></image>
                </view>

                <view class="top-txt">
                    提交申请资料
                </view>
            </view>
            <view class="step-line">

            </view>
            <view class='line3 line'>
                <view class="img">
                    <image src="../../static/salesMan3.png" mode="aspectFill"></image>
                </view>

                <view class="top-txt">
                    完成认证
                </view>
            </view>
        </view>
        <view class="content">
            <view class="content-item">
                <view class="content-item-top" v-if="isrxShow">
                    第一步：请拍摄身份证人像面
                </view>

                <view class="content-item-top" v-if="!isrxShow">
                    第一步：请确认身份证信息
                </view>

                <view class="xline">

                </view>
                <view class="content-item-mid ">

                    <view class="upt-box sfz" @click.stop="toUpload(1)">

                        <!-- <suniupimg :upload_count='1' @change="imgChange" :url="$uptImgUrl" ref="uptref"></suniupimg> -->
                        <view class="delbox" v-if="sfzurl" @click.stop="delimg">
                            <image src="../../static/del-round.png" mode="aspectFill"></image>
                        </view>
                        <view class="prebox" v-if="sfzurl">
                            <image :src="sfzurl" mode="aspectFill" @click.stop="imgclk"></image>
                        </view>
                        <view class="mask" @click.stop="clkMask" v-if="isMaskShow">

                        </view>
                    </view>
                    <!-- <view class="mid-photo">
						<image src="../../static/photo.png" mode="aspectFill"></image>
					</view> -->

                </view>
                <view class="content-item-btm" v-if="isrxShow">
                    保证图片的清晰
                </view>
                <!-- 正面 -->
                <view class="cardPositive" v-if="!isrxShow">
                    <view class="carNumber">

                        <text style="margin-right: 20rpx;">证件号码</text>{{cardNum}}

                    </view>
                    <view class="card-line">

                    </view>
                    <view class="cardName">
                        <text style="margin-right: 50rpx;">姓</text>名 <text
                            style="margin-left: 18rpx;">{{cardName}}</text>
                    </view>
                    <view class="card-line">

                    </view>
                </view>


            </view>
            <view class="content-item" style="margin-top: 20rpx;">
                <view class="content-item-top " v-if="isghShow">
                    第二步：请拍摄身份证国徽面
                </view>
                <view class="content-item-top " v-if="!isghShow">
                    第二步：请确认身份证信息
                </view>
                <view class="xline">

                </view>
                <view class="content-item-mid">

                    <view class="upt-box sfz1" @click.stop="toUpload(2)">
                        <view class="delbox" v-if="sfzurl1" @click.stop="delimg1">
                            <image src="../../static/del-round.png" mode="aspectFill"></image>
                        </view>
                        <view class="prebox" v-if="sfzurl1">

                            <image :src="sfzurl1" mode="aspectFill" @click.stop="imgclk"></image>
                        </view>


                        <!-- <suniupimg :upload_count='1' @change="imgChange1" :url="$uptImgUrl" ref="uptref1"></suniupimg> -->
                        <view class="mask1" @click.stop="clkMask1" v-if="isMaskShow1">

                        </view>
                    </view>
                    <!-- <view class="mid-photo">
						<image src="../../static/photo.png" mode="aspectFill"></image>
					</view> -->

                </view>
                <view class="content-item-btm" v-if="isghShow">
                    保证图片的清晰
                </view>
                <view class="content-item-btm datato" v-if="!isghShow">
                    <!-- reTimeTo存在 是反显的 -->

                    有效期 {{start_date}} ~ {{end_date}}

                    <view class="card-line1">

                    </view>
                </view>




            </view>
        </view>
        <view class="xbtn-blue" style="margin: 80rpx auto 0;" @click="toNext">
            下一步
        </view>
        <!-- <view class="popup-box"> -->
        <unipopup ref="popup" type='center'>
            <view class="popup-box">
                <view class='popup-box-item1'>

                </view>
                <view class='popup-box-item2'></view>
                <view class='popup-box-item3'>
                    <image :src="cdnUrl+'XianxiangUapi/static/rx1.png'" mode="aspectFill"></image>
                </view>
                <view class='popup-box-item4' @click="close">
                    我知道了
                </view>


            </view>

        </unipopup>
        <!-- </view> -->
        <!-- <view class="popup-box"> -->
        <unipopup ref="popup1" type='center'>
            <view class="popup-box">
                <view class='popup-box-item1'>
                    拍摄身份证国徽面
                </view>
                <view class='popup-box-item2'>
                    身份证完整、日期和文字清晰
                </view>
                <view class='popup-box-item3'>
                    <image :src="cdnUrl+'XianxiangUapi/static/guohui1.png'" mode="aspectFill"></image>
                </view>
                <view class='popup-box-item4' @click="close1">
                    我知道了
                </view>


            </view>

        </unipopup>
        <!-- </view> -->
    </view>
    </view>
</template>



<script>
    import unipopup from "../../components/uni-popup/uni-popup.vue"
    import aliImgApi from "../../api/main/aliImg.js"
    import salesmanCenterApi from "../../api/salesmanCenter/salesmanCenter.js"
    export default {
        components: {
            unipopup
        },
        onLoad(options) {
            console.log(options.type)
            this.type = options.type
            this.cdnUrl = this.$cdnUrl
            if (options.type == 1) {
                uni.setNavigationBarTitle({
                    title: '申请拓客员'
                });
                
                this.phone_business = options.phone
                //是否重新提交 如果是 要拿一下拓客员信息 反显
                if (options.isre) {
                    this.isre = options.isre
                    salesmanCenterApi.user_tockStatus().then(res => {
                        if (res.status == 200) {
                            this.myObj = res.result
                            this.sfzurl = this.$imgUrl(this.myObj.identity_front)
                            this.sfzurl1 = this.$imgUrl(this.myObj.identity_contrary)
                            this.cardNum = this.myObj.identity
                            this.cardName = this.myObj.real_name
                            this.presfzurl = this.myObj.identity_front
                            this.presfzurl1 = this.myObj.identity_contrary
                            this.isrxShow = false
                            this.isghShow = false
                            this.isMaskShow = false
                            this.isMaskShow1 = false
                            this.start_date = this.myObj.start_date
                            this.end_date = this.myObj.end_date
                        }
                    })
                }
            } else if (options.phone66){
				uni.setNavigationBarTitle({
				    title: '申请业务员'
				});
				
				this.phone_business = options.phone66
				//是否重新提交 如果是 要拿一下业务员信息 反显
				this.token = uni.getStorageSync('xxytoken')
				if (options.isre) {
				    this.isre = options.isre
				    salesmanCenterApi.user_salesman_status({
				        token: this.token
				        
				    }).then(res => {
						console.log(res);
				        if (res.status == 200) {
				            this.myObj = res.result
				            this.sfzurl = this.$imgUrl(this.myObj.card_front)
				            this.sfzurl1 = this.$imgUrl(this.myObj.card_reverse)
				            this.cardNum = this.myObj.card_id
				            this.cardName = this.myObj.card_name
				            this.presfzurl = this.myObj.card_front
				            this.presfzurl1 = this.myObj.card_reverse
				            this.isrxShow = false
				            this.isghShow = false
				            this.isMaskShow = false
				            this.isMaskShow1 = false
				            this.start_date = this.myObj.start_date
				            this.end_date = this.myObj.end_date
				        }
				    })
				}
			}else {
				// console.log(options);
                uni.setNavigationBarTitle({
                    title: '申请业务员'
                });
                
                this.phone_business = options.phone
                //是否重新提交 如果是 要拿一下业务员信息 反显
                this.token = uni.getStorageSync('xxytoken')
                if (options.isre) {
                    this.isre = options.isre
                    salesmanCenterApi.user_salesman({
                        token: this.token,
                        user_id: options.id
                    }).then(res => {
						console.log(res);
                        if (res.status == 200) {
                            this.myObj = res.result
                            this.sfzurl = this.$imgUrl(this.myObj.card_front)
                            this.sfzurl1 = this.$imgUrl(this.myObj.card_reverse)
                            this.cardNum = this.myObj.card_id
                            this.cardName = this.myObj.card_name
                            this.presfzurl = this.myObj.card_front
                            this.presfzurl1 = this.myObj.card_reverse
                            this.isrxShow = false
                            this.isghShow = false
                            this.isMaskShow = false
                            this.isMaskShow1 = false
                            this.start_date = this.myObj.start_date
                            this.end_date = this.myObj.end_date
                        }
                    })
                }
            }
            


            
            // if(options.isre){
            // 	this.theStatus='99'
            // }else{
            // 	//查询业务员状态
            // 	this.token=uni.getStorageSync('xxytoken')
            // 	applysSalesManApi.applysSalesManStatus({
            // 		token:this.token
            // 	}).then(res =>{
            // 		if(res.status==200){
            // 			this.theStatus=res.result.card_status

            // 			if(this.theStatus==0||1||-1){
            // 				uni.redirectTo({
            // 					url:'./checkProgress'
            // 				})
            // 			}
            // 		//不是业务员
            // 		}else if(res.status==100){
            // 			this.theStatus='99'
            // 		}

            // 	})
            // }


        },
        data() {
            return {
                cdnUrl: "",
                //1是拓客员 2是业务员
                type: "",
                //控制两个弹出层的显示隐藏
                isShow: false,
                isShow1: false,
                //控制两个透明遮罩层的显示隐藏
                isMaskShow: true,
                isMaskShow1: true,
                //审核状态，0表示未审核，1表示审核通过，-1表示审核失败 2下架
                theStatus: '-100',
                isrxShow: true,
                isghShow: true,
                sfzurl: "",
                sfzurl1: "",
                presfzurl: "",
                presfzurl1: "",
                cardNum: "",
                // 身份证姓名
                cardName: "",
                //有效期
                timeTo: "",
                urlface: "",
                urlback: "",
                start_date: "",
                end_date: "",
                token: "",
                myObj: {},
                isre: false,
                //控制反显有效期的字段
                reTimeTo: "",
                start_date: "",
                end_date: "",
                


            }
        },
        methods: {
            //上传成功 和点击叉号删除 都会触发该方法   点击删除以后 清空读出来的身份证号  并切换第一步后面跟的文字信息
            imgChange(e) {
                console.log(e)
                console.log(e.length)
                //如果长度为1 是上传成功了
                if (e.length == 1) {
                    console.log(this.$refs.uptref.backdata)
                }

                //如果长度为0  是点击叉号清空了 准备重新上传
                if (e.length == 0) {

                }
            },
            imgChange1(e) {
                console.log(e.length)
                //如果长度为1 是上传成功了
                if (e.length == 1) {
                    console.log(this.$refs.uptref1.backdata)
                }

                //如果长度为0  是点击叉号清空了 准备重新上传
                if (e.length == 0) {

                }
            },
            toNext() {
                // if (!this.cardName) {
                //     uni.showToast({
                //         title: "请完善身份证人像面信息",
                //         icon: "none"
                //     })
                //     return
                // }
                // if (!this.start_date) {
                //     uni.showToast({
                //         title: "请完善身份证国徽面信息",
                //         icon: "none"
                //     })
                //     return
                // }
                if (this.isre) {
                    let infoObj = JSON.stringify(this.myObj)
                    uni.navigateTo({
                        url: './ApplysSalesmanNext?card_front=' + this.presfzurl + "&card_reverse=" + this
                            .presfzurl1 + "&card_id=" + this.cardNum + "&card_name=" + this.cardName +
                            "&start_date=" + this.start_date + "&end_date=" + this.end_date + "&infoObj=" +
                            infoObj + "&saleman_phone=" + this.myObj.saleman_phone + "&type=" + this.type
                    })
                }
                if (!this.isre) {

                    uni.navigateTo({
                        url: './ApplysSalesmanNext?card_front=' + this.presfzurl + "&card_reverse=" + this
                            .presfzurl1 + "&card_id=" + this.cardNum + "&start_date=" + this.start_date +
                            "&end_date=" + this.end_date + "&card_name=" + this.cardName + '&saleman_phone=' +
                            this.phone_business + "&type=" + this.type
                    })
                }



            },
            clkMask() {
                //点击透明遮罩层以后 打开提示弹窗 
                this.$refs.popup.open()
            },
            clkMask1() {
                //点击透明遮罩层以后 打开提示弹窗1 
                this.$refs.popup1.open()
            },
            close() {
                this.$refs.popup.close()
                this.isMaskShow = false

            },
            close1() {
                this.$refs.popup1.close()
                this.isMaskShow1 = false
            },
            toUpload(id) {
                console.log("外层")
                wx.chooseImage({
                    count: 1,
                    chooseImage: 1,
                    success: res => {
                        const path = res.tempFilePaths[0];
                        console.log(path);
                        wx.uploadFile({
                            // url: 'https://zhufubao.oss-cn-beijing.aliyuncs.com',
                            url: this.$uptImgUrl,
                            name: 'file',
                            filePath: path,
                            formData: {
                                name: "${fileName}",
                                //res.apFilePaths[0]是支付宝小程序调用chooseImage接口返回的图片地址，需要自己去修改，因为它返回的是  temp://+图片地址，可以分割得到图片地址，在存储的时候自定义存储路径，用host对应的bucket吓得文件路径拼接上图片地址
                                //key: 'equipment-image/'+path.split('://')[1],
                                key: res.tempFilePaths[
                                    0], //上传到OSS的Object名称。如果名称包含路径，如a/b/c/b.jpg，则OSS会自动创建相应的文件夹。
                                policy: '',
                                OSSAccessKeyId: '',
                                signature: '',
                                success_action_status: 200 //如果不设置success_action_status，文件上传成功后则返回204状态码。
                            },
                            success: res => {
                                console.log(res)

                                if (id == 1) {
                                    this.sfzurl = JSON.parse(res.data).result
                                    this.urlface = "/" + this.sfzurl
                                    this.presfzurl = this.sfzurl
                                    this.sfzurl = this.$imgUrl(JSON.parse(res.data).result)
                                    
                                    
                                    
                                    
                                    
                                    this.imageDiscern()
                                    // this.cardNum = res.result.num
                                    // this.cardName = res.result.name
                                    // this.isrxShow = false
                                    
                                    
                                } else if (id == 2) {
                                    this.sfzurl1 = JSON.parse(res.data).result
                                    this.urlback = "/" + this.sfzurl1
                                    this.presfzurl1 = this.sfzurl1
                                    this.sfzurl1 = this.$imgUrl(JSON.parse(res.data).result)


                                    console.log(123)
                                    console.log(this.sfzurl1)
                                    console.log(this.urlback)
                                    
                                    
                                    
                                    this.imageDiscern1()
                                    // this.isghShow = false
                                    // this.start_date = res.result.start_date
                                    // this.end_date = res.result.end_date
                                    // this.timeTo = this.start_date + '~' + this.end_date
                                }

                                uni.showToast({
                                    title: '上传成功',
                                    icon: "none"
                                });
                            },
                            fail: function(res) {
                                uni.showToast({
                                    title: '上传失败',
                                    icon: "none"
                                });
                            },
                        });
                    },
                });
            },
            imgclk() {
                console.log(23333)

            },
            delimg() {
                // let that=this
                uni.showModal({
                    title: '提示',
                    content: '确定删除吗？',
                    success: (res) => {
                        if (res.confirm) {
                            console.log(this)
                            this.sfzurl = ""
                            this.isrxShow = true
                            this.cardNum = ""
                            this.cardName = ""
                        } else if (res.cancel) {

                        }
                    }
                });
            },
            delimg1() {
                let that = this
                uni.showModal({
                    title: '提示',
                    content: '确定删除吗？',
                    success: (res) => {
                        if (res.confirm) {
                            this.sfzurl1 = ""
                            this.isghShow = true
                            this.start_date = ""
                            this.end_date = ""

                        } else if (res.cancel) {

                        }
                    }
                });
            },
            //图片识别接口   拿到上传图片路径以后 调用这个方法
            imageDiscern() {
                // uni.showToast({
                // 	title:'身份证识别中'
                // })
                uni.showLoading({
                    title: '身份证识别中'
                })
                aliImgApi.aliImg({
                    path: this.urlface,
                    side: "face"
                }).then(res => {
                    console.log(1111111111)
                    console.log(res)
                    if (res.status == 200) {
                        uni.hideLoading()
                        this.cardNum = res.result.num
                        this.cardName = res.result.name
                        this.isrxShow = false
                    } else if (res.status == 100) {
                        uni.showToast({
                            title: '识别失败，请重新上传',
                            icon: 'none'
                        })
                        uni.hideLoading()
                    } else {
                        uni.hideLoading()
                        uni.showToast({
                            title: res.message,
                            icon: 'none'
                        })
                    }





                })
            },
            imageDiscern1() {
                uni.showLoading({
                    title: '身份证识别中'
                })
                aliImgApi.aliImg({
                    path: this.urlback,
                    side: "back"
                }).then(res => {
                    console.log(res)
                    if (res.status == 200) {
                        uni.hideLoading()
                        this.isghShow = false
                        this.start_date = res.result.start_date
                        this.end_date = res.result.end_date
                        this.timeTo = this.start_date + '~' + this.end_date
                    } else if (res.status == 100) {
                        uni.showToast({
                            title: '识别失败，请重新上传',
                            icon: 'none'
                        })
                        uni.hideLoading()
                    } else {
                        uni.hideLoading()
                        uni.showToast({
                            title: res.message,
                            icon: 'none'
                        })
                    }


                })
            }






        }
    }
</script>

<style>
    page {
        background-color: #F5F5F5;
    }
</style>
<style lang="scss" scoped>
    .top {
        display: flex;
        margin: 22rpx auto 0;
        justify-content: space-between;
        width: 650rpx;
        height: 100rpx;
        font-size: 24rpx;
        align-items: center;

        .img {
            width: 60rpx;
            height: 60rpx;

            image {
                width: 60rpx;
                height: 60rpx;

            }
        }
    }

    .line {
        width: 150rpx;
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        justify-content: center;
    }

    .content {
        margin-top: 30rpx;
    }

    .content-item {
        text-align: center;
        margin: 0 auto;
        width: 690rpx;
        height: 452rpx;
        background: #FFFFFF;
        border-radius: 10rpx;

        .content-item-top {
            height: 69rpx;
            line-height: 69rpx;
        }

        .content-item-mid {
            margin-top: 29rpx;
            position: relative;
            height: 230rpx;
            display: flex;
            justify-content: center;
            align-items: center;


        }

        .content-item-btm {
            height: 130rpx;
            line-height: 130rpx;

            font-size: 24rpx;

            color: #999999;

        }

        .datato {
            font-size: 24rpx;
            color: #333333 !important;
        }
    }

    .sfz {
        position: relative;
        width: 360rpx;
        height: 230rpx;
        background: url(../../static/sfzrx.png);
        background-size: 100% 100%;

        .prebox {

            width: 100%;
            height: 100%;

            image {
                width: 100%;
                height: 100%;
            }
        }

        .delbox {
            width: 36rpx;
            height: 36rpx;
            position: absolute;
            right: 6rpx;
            top: 6rpx;

            image {
                width: 100%;
                height: 100%;
                z-index: 100;
            }
        }

    }

    .sfz1 {
        position: relative;
        width: 360rpx;
        height: 230rpx;
        background: url(../../static/sfzgh.png);
        background-size: 100% 100%;

        .prebox {
            width: 100%;
            height: 100%;

            image {
                width: 100%;
                height: 100%;
            }
        }

        .delbox {
            width: 36rpx;
            height: 36rpx;
            position: absolute;
            right: 6rpx;
            top: 6rpx;

            image {
                width: 100%;
                height: 100%;
                z-index: 100;
            }
        }
    }

    .mid-photo {
        width: 120rpx;
        height: 120rpx;

        image {
            width: 100%;
            height: 100%;
        }

        position: absolute;
        left: 50%;
        top: 50%;
        transform: translate(-50%, -50%);
    }

    .mask {
        position: absolute;
        width: 100%;
        height: 100%;
        left: 0;
        top: 0;
        background-color: #FFFFFF;
        opacity: 0;
        z-index: 30;
    }

    .mask1 {
        position: absolute;
        width: 100%;
        height: 100%;
        left: 0;
        top: 0;
        background-color: #FFFFFF;
        opacity: 0;
        z-index: 31;
    }

    .popup-box {
        position: relative;
        width: 600rpx;
        height: 700rpx;
        background-color: #FFFFFF;
        text-align: center;
        border-radius: 10rpx;

        .popup-box-item1 {
            height: 70rpx;
            line-height: 70rpx;
            font-size: 30rpx;
            font-weight: bolder;
        }

        .popup-box-item2 {
            height: 50rpx;
            line-height: 50rpx;
            font-size: 24rpx;
            color: #999999;
        }

        .popup-box-item3 {
            margin-left: 24rpx;
            width: 552rpx;
            height: 422rpx;

            image {
                width: 100%;
                height: 100%;
            }

        }

        .popup-box-item4 {
            position: absolute;
            left: 50%;
            transform: translateX(-50%);
            bottom: 20rpx;
            width: 240rpx;
            height: 80rpx;
            background: #4794FF;
            border-radius: 40rpx;
            color: #FFFFFF;
            line-height: 80rpx;
            text-align: center;
            letter-spacing: 1rpx;
        }
    }

    .cardPositive {
        margin-left: 160rpx;
        margin-top: 20rpx;
        width: 465rpx;
        text-align: left;
        font-size: 24rpx;
        color: #333333;

        .cardNumber {}

        .cardName {
            margin-top: 10rpx;
        }


    }

    .card-line {
        width: 370rpx;
        height: 2rpx;
        background: #E7E7E7;
        margin-top: 6rpx;
    }

    .card-line1 {
        width: 370rpx;
        height: 2rpx;
        background: #E7E7E7;
        margin: -40rpx auto 0;
    }

    .step-line {
        width: 68rpx;
        height: 2rpx;
        background: #CCCCCC;
        margin-bottom: 30rpx;
    }
</style>
