<template>
	<view class="box">
		<view class="info">
			<view class="title">
				{{titleText}}
			</view>
			<view class="user">
				<view class="user-phone">
					<image src="../../../static/user-blue.png" class="img"></image>
					<input class="uni-input" @input="onKeyInput" type="number" maxlength="11" placeholder="请输入会员手机号" />
				</view>
				<view class="user-name">
					<image :src="$imgUrl(userInformation.photo)" class="img" v-if="userInformation.photo!=''"></image>
					<view class="name">
						{{userInformation.name}}
					</view>
				</view>
			</view>
		</view>
		<view class="next" @click="login">下一步</view>
	</view>
</template>

<script>
	import loginApi from "../../../api/login/login.js"
	import salesmanApi from "../../../api/salesmanCenter/salesmanCenter.js"
	export default {
		data() {
			return {
				referrer: false,
				titleText: "",
				inputValue: "",
				showType: "0",
				salesmanListL: "",
				idIndex: "",
				userInformation: {
					name: "",
					photo: ""
				},
				employee_id: "",
				token: "",
				searchSalesmanStatus:"",
				searchMerchantStatus:""
				
			}
		},
		// 判断从哪个页面跳过来,显示不同标题
		onLoad(e) {
			this.token = uni.getStorageSync("xxytoken")
			this.idIndex = e.id
			if (e.id == 1) {
				this.showType = e.id
				this.titleText = "添加业务员"
				uni.setNavigationBarTitle({
					title: '添加业务员'
				});
			}
			if (e.id == 2) {
				this.showType = e.id
				this.titleText = "录入商家"
				uni.setNavigationBarTitle({
					title: '录入商家'
				});
			}
		},
		methods: {
			// 键盘输入触发
			onKeyInput: function(event) {
				this.inputValue = event.target.value
				// 当输入的手机号位数达到11位进行请求查询手机号是否已经注册
				if (event.target.value.length == 11) {
					loginApi.welcome({
						phone: this.inputValue,
                        type:1
					}).then(res => {
						// && res.result.rank == 1
						if (res.status == 200&&res.result.type==2) {
							this.userInformation = res.result
							this.employee_id = res.result.employee_id
							if(res.result.rank==1){
								// 当用户已经入驻商户或者业务员但是还未审核时用户的状态还是1而且状态为启用
								// 所以分别区请求业务员入驻状态接口和商家入驻状态接口
								// if(salesmanApi.user_settlement_detail({phone:this.inputValue}).then(res=>{
								// 	if(res.result.card_status)
								// }))
								this.referrer = 1
							}else if(res.result.rank==2){
								this.referrer = 2
							}else if(res.result.rank==3){
								this.referrer = 3
							}else if(res.result.rank==4){
								this.referrer=4
							}
							return
						} else if(res.message!="查询成功") {
							uni.showToast({
								title: res.message,
								icon: "none"
							})
						}
					})
					// 如果不到11位不显示用户头像与用户昵称
				} else {
					this.referrer=0
					this.userInformation = {
						name: "",
						photo: ""
					}
				}
			},
			// 点击下一步的跳转到录入商家页面或者录入业务员页面
			login() {
				salesmanApi.user_status({phone:this.inputValue}).then(res=>{
					if(res.status==200&&res.result!=null){
						this.searchMerchantStatus= res.result.merchant_status
						salesmanApi.user_settlement_detail({phone:this.inputValue}).then(res=>{
							if(res.status==200&&res.result!=null){
								this.searchSalesmanStatus= res.result.card_status
								loginApi.welcome({
									token: this.token
								}).then(res => {
									// 判断请求是否正常
									var a=this.inputValue
									if(this.inputValue.length==11){
										if (res.status == 200&&res.result!=null) {
											// 判断是否该用户是否为注册过且没有其他身份
											if (this.referrer == 1) {
												// 判断上级的状态如果是业务员有没有分配上级代理商
												if(res.result.rank==2&&res.result.employee_id != 0){
													if(this.searchSalesmanStatus==-2&&this.searchMerchantStatus==0){
														this.goWhere()
													}else if(this.searchSalesmanStatus!=-2) {
														uni.showToast({
																title: "该用户已经注册过业务员，请勿重复注册",
																icon: "none"
															})
													}else if(this.searchMerchantStatus!=0){
														uni.showToast({
																title: "该用户已经注册过商家，请勿重复注册",
																icon: "none"
															})
													}
												}else if(res.result.rank==3){
													if(this.searchSalesmanStatus==-2&&this.searchMerchantStatus==0){
														this.goWhere()
													}else if(this.searchSalesmanStatus!=-2) {
														uni.showToast({
																title: "该用户已经注册过业务员，请勿重复注册",
																icon: "none"
															})
													}else if(this.searchMerchantStatus!=0){
														uni.showToast({
																title: "该用户已经注册过商家，请勿重复注册",
																icon: "none"
															})
													}
												}else if(res.result.rank==2&&res.result.employee_id == 0){
													uni.showToast({
															title: "您还未被分配代理商，请联系平台",
															icon: "none"
														})
												}
											} else if(this.referrer==2) {
												uni.showToast({
													title: "该用户已经是业务员",
													icon: "none"
												})
											}else if(this.referrer==3){
												uni.showToast({
													title: "该用户已经是代理商",
													icon: "none"
												})
											}else if(this.referrer==4){
												uni.showToast({
													title: "该用户已经是商家",
													icon: "none"
												})
											}
										} else {
											uni.showToast({
												title: res.message,
												icon: "none"
											})
										}
									}else{
										uni.showToast({
											title:"请输入正确的手机号",
											icon:"none"
										})
									}
								})
							}
						})
					}
				})
	
			},
		 	searchSalesman(e){
				salesmanApi.user_settlement_detail({phone:e}).then(res=>{
					if(res.status==200&&res.result!=null){
						this.searchSalesmanStatus=res.result.card_status
					}
				})
			},
			searchMerchant(e){
				salesmanApi.user_status({phone:e}).then(res=>{
					if(res.status==200&&res.result!=null){
						this.searchMerchantStatus= res.result.merchant_status
					}
				})
			},
			goWhere(){
                console.log(this.idIndex)
				if (this.idIndex == 1) {
					uni.navigateTo({
						url: "../ApplysSalesman?phone=" + this.inputValue
					})
				} else {
					uni.navigateTo({
						url: "../selectIndustry/selectIndustry?phone=" + this.inputValue
					})
				}
			}
		}
	}
</script>
<style>
	page {
		height: 100%;
	}
</style>
<style lang="scss" scoped>
	.box {
		background-image: url(../../../static/background.png);
		background-repeat: no-repeat;
		background-size: 100% 100%;
		width: 100%;
		height: 100%;
		// height: calc(100vh - 90rpx);
		overflow: hidden;
		position: relative;

		.info {
			border-radius: 10rpx;
			background-color: #fff;
			width: 690rpx;
			height: 500rpx;
			margin: 0 auto;
			margin-top: 234rpx;
			padding: 52rpx 60rpx;
			box-sizing: border-box;

			.title {
				height: 53rpx;
				font-size: 56rpx;
				font-family: PingFang SC;
				font-weight: bold;
				color: #222222;
				line-height: 66rpx;
			}

			.user {
				overflow: hidden;
				margin-top: 90rpx;

				.user-phone {
					display: flex;
					justify-items: flex-start;
					align-items: center;
					width: 620rpx;
					height: 100rpx;
					border-bottom: 2rpx solid #E0E0E0;

					.img {
						width: 30rpx;
						height: 38rpx;
						margin-left: 30rpx;
					}

					.uni-input {
						margin-left: 25rpx;
					}
				}

				.user-name {
					display: flex;
					justify-items: flex-start;
					width: 620rpx;
					height: 100rpx;
					align-items: center;
					padding-top: 20rpx;

					.img {
						width: 100rpx;
						height: 100rpx;
						background: #280D20;
						border-radius: 50%;

					}

					.name {
						margin-left: 20rpx;
					}
				}
			}
		}

		.next {
			width: 690rpx;
			height: 90rpx;
			text-align: center;
			background: #FFFFFF;
			opacity: 0.8;
			border-radius: 10px;
			color: #4794FF;
			line-height: 90rpx;
			position: absolute;
			left: 30rpx;
			bottom: 30rpx;

		}
	}
</style>
