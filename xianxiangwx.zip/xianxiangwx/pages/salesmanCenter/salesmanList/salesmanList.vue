<template>
	<!-- 总体 -->
	<view class="Trade">
		<view class="searchstyle" >
			<view class="searchInput" style="padding-left:30rpx;">
				<view style="width: 100%;height:70rpx;display: flex;align-items: center;justify-content: space-between;">
					<img src="../../../static/搜索.png" alt="" style="width: 32rpx;height: 32rpx;margin: 0 20rpx;z-index: 10;">
					<input  type="text" placeholder="请输入业务员姓名" v-model="searchValue" class="fontsmall" style="color:#FFFFFF;opacity: 0.6;flex-grow: 1;" placeholder-style="color:#FFFFFF;opacity: 0.6;">
					<view class="searchButton" style="" @click="searchSalesman">搜索</view>
				</view>
<!-- 				<u-search shape="square" placeholder="请输入搜索内容" placeholder-color="#FFFFFF"
				 v-model="keyword"  bg-color="none" search-icon-color=" #FFFFFF" ></u-search> -->
			</view>
		</view>
		<!-- 导航栏 -->
		<view class="navgation fontstyle" style="position: fixed;top:90rpx;width: 100%;background-color: #FFFFFF;z-index: 2;">
			<!-- 三元运算 -->
			<view :class="nav===index?'active':''" v-for="(item,index) in tileList" :key="item.id" @click="select(index)">
				{{item.title}}
			</view>
		</view>
		<!-- 我的业务员 -->
		<view>
			<view class="mysalesman" v-if="nav==0&&salesmanListGet.data.length>0">
				<view   v-for="(item,index) in salesmanListGet.data " :key="item.card_user" style="display: flex;align-items: center;margin: 20rpx 0;">
					<view style="margin-right: 20rpx;">
						<img :src="$imgUrl(item.referrer_photo)" alt=""
							style="width: 80rpx;height: 80rpx;margin-left: 6rpx;border-radius: 50%;">
						<view class="salesmanStyle" style="">业务员</view>
					</view>
					<view style="flex-grow:1">
						<view class="fontstyle">用户昵称:&nbsp{{item.referrer_name}}</view>
						<view class="fontsmallstyle">手机号码:&nbsp{{item.referrer_phone}}</view>
					</view>
					<view class="fontsmallstyle" @click="selectSaleman(item)">查看>></view>
				</view>
			</view>
			<view v-else-if="nav==0&&salesmanListGet.data.length==0" style="margin-top: 300rpx;width: 100%;text-align: center;"><img :src="cdnUrl+'XianxiangUapi/static/datanull.png'" alt="" style="width: 480rpx;height: 360rpx;"></view>
		</view>
		
		<!-- 审核中 -->
		<view>
			<view  class="mysalesman" v-if="nav==1">
				<view class="Tradeshow"  v-for="(item,index) in salesmanListGet.data" :key="item.card_user" style="display: flex;align-items: center;margin: 20rpx 0;">
					<view style="margin-right: 20rpx;">
						<img :src="$imgUrl(item.referrer_photo)" alt=""
							style="width: 80rpx;height: 80rpx;margin-left: 6rpx;border-radius: 50%;">
						<view class="salesmanStyle" style="">业务员</view>
					</view>
					<view style="flex-grow:1">
						<view class="fontstyle">用户昵称:&nbsp{{item.referrer_name}}</view>
						<view class="fontsmallstyle">手机号码:&nbsp{{item.referrer_phone}}</view>
					</view>
					<view class="fontsmallstyle" @click="selectSaleman(item)">查看>></view>
				</view>
			</view>
			<view v-else-if="nav==1&&salesmanListGet.data.length==0" style="margin-top: 300rpx;width: 100%;text-align: center;"><img :src="cdnUrl+'XianxiangUapi/static/datanull.png'" alt="" style="width: 480rpx;height: 360rpx;"></view>
		</view>

		<!-- 已拒绝 -->
		<view>
			<view  class="mysalesman" v-if="nav==2">
					<view class="Tradeshow"  v-for="(item,index) in salesmanListGet.data" :key="item.card_user" style="display: flex;align-items: center;margin: 20rpx 0;">
						<view style="margin-right: 20rpx;">
							<img :src="$imgUrl(item.referrer_photo)" alt=""
								style="width: 80rpx;height: 80rpx;margin-left: 6rpx;border-radius: 50%;">
							<view class="salesmanStyle" style="">业务员</view>
						</view>
						<view style="flex-grow:1">
							<view class="fontstyle">用户昵称:&nbsp{{item.referrer_name}}</view>
							<view class="fontsmallstyle">手机号码:&nbsp{{item.referrer_phone}}</view>
						</view>
						<view class="fontsmallstyle" @click="selectSaleman(item)">查看>></view>
					</view>
				</view >
				<view v-else-if="nav==2&&salesmanListGet.data.length==0" style="margin-top: 300rpx;width: 100%;text-align: center;"><img :src="cdnUrl+'XianxiangUapi/static/datanull.png'" alt="" style="width: 480rpx;height: 360rpx;"></view>
		</view>
		<img src="../../../static/addsalesman.png" alt=""
			style="width: 113rpx;height: 113rpx;position: fixed;bottom: 200rpx;right: 0rpx;" @click="gosalesmanAdd()">
			
			<!-- 点击查看详情显示的模态框 -->
			<view>
				<u-popup v-model="show" mode="center" closeable="true" border-radius="10">
					<view style="width: 500rpx;padding:60rpx;overflow: hidden;">
						<view class="fontbigStyle" style="margin:50rpx 0 30rpx 0;text-align: center;">业务员详情</view>
						<view class="fontsmallstyle"
							style="height: 70rpx;line-height: 70rpx;display: flex;align-items: center;">
							用户头像:&nbsp <img :src="$imgUrl(salesman.photo)" alt="" style="width: 70rpx;height: 70rpx;border-radius:50%;">
						</view>
						<view class="fontsmallstyle">用户昵称:&nbsp{{salesman.name}}</view>
						<view class="fontsmallstyle">手机号:&nbsp{{salesman.phone}}</view>
						<view class="fontsmallstyle">性别:&nbsp{{sex(salesman.sex)}}</view>
						<view class="fontsmallstyle">年龄:&nbsp{{salesman.age}}</view>
						<view class="fontsmallstyle">
							联系地址:&nbsp{{salesman.card_province}}{{salesman.card_city}}{{salesman.card_county}}</view>
						<view class="fontsmallstyle">详细地址:&nbsp{{salesman.address}}</view>
						<view class="fontsmallstyle">姓名:&nbsp{{salesman.real_name}}</view>
						<view class="fontsmallstyle">身份证号:&nbsp{{salesman.card_id}}</view>
						<view class="fontsmallstyle">录入商家:&nbsp{{salesman.merchant_count}}</view>
						<view class="fontsmallstyle">注册时间:&nbsp{{$timeConvert(salesman.card_pass_time)}}</view>
					</view>
				</u-popup>
			</view>
	</view>

</template>

<script>
	import salesmanApi from "../../../api/agent/salesmanList.js"
	export default {
		data() {
			return {
                cdnUrl:"",
				// 搜索框的值
				searchValue:"",
				// 接收业务员详情信息
				salesman: {},
				// 模态框是否展示
				show: false,
				// 导航栏循环数据几条几个导航栏
				tileList: [{
						id: '1',
						title: "我的业务员"
					},
					{
						id: '2',
						title: "审核中"
					},
					{
						id: '3',
						title: "已拒绝"
					}
				],
				// 搜索框绑值
				keyword: "",
				// 判断点击的那个导航栏
				nav: 0,
				// 请求代理商所属的业务员列表的参数
				salesmanList: {
					token: "",
					type: "1",
					page: "1",
					count:"10",
					name:""
				},
				// 得到的业务员列表
				salesmanListGet: {
					data: []
				},
				// 全局的身份值
				token: "",
				// 页面索引
				pageIndex: "1"
			}
		},
		// 进入界面加载前执行的函数
		onLoad(e) {
            this.cdnUrl=this.$cdnUrl
			// 获取用户登录时存储在本地的token值
			this.salesmanList.token = uni.getStorageSync('xxytoken');
			this.token = uni.getStorageSync('xxytoken');
			this.ajax(this.salesmanList)
		},
		//页面展示时
		// 滚动页面时执行的方法
		onReachBottom() {
			this.salesmanList.name=this.searchValue
			if (this.pageIndex < this.salesmanListGet.last_page) {
				this.salesmanListGet.page = ++this.pageIndex;
				this.ajax(this.salesmanList)
			} else {
			}
		},
		methods: {
			// 查询业务员
			searchSalesman(){
				this.salesmanListGet={data:[]}
				this.salesmanList.name=this.searchValue
				
				this.ajax(this.salesmanList)
			},
			// 跳转至添加业务员页面
			gosalesmanAdd() {
				uni.navigateTo({
					url: "../addSeller/addSeller?id=1"
				})
			},
			// 切换至点击的导航栏
			select(index) {
				this.searchValue=""
				this.salesmanList.name=""
				this.nav = index;
				this.salesmanListGet = {
					data: []
				};
				this.salesmanList.type = ++index
				this.salesmanList.page = 1;
				this.pageIndex = 1;
				this.ajax(this.salesmanList);
			},
			// 查看点击事件
			selectSaleman(e) {
				console.log(e)
				if(this.nav==0){
					this.show=true;
					salesmanApi.getSalesmanList({
						token: this.token,
						user_id: e.card_user
					}).then(res => {
						if (res.status == 200) {
							this.salesman = res.result
						}
					})
				}else{
					uni.navigateTo({
						url:"../auditing/auditing?id="+e.card_user+'&type='+'1'
					})
				}
		
			},
			// 调用代理商业务员列表接口
			ajax(e) {
				salesmanApi.getSalesman(e).then(res => {
					// 如果请求成功
					if (res.status == 200 && res.result != null) {
						// 如果业务员列表不为空
						if (this.salesmanListGet.data.length > 0) {
							// 合并数组
							this.salesmanListGet.data = [...this.salesmanListGet.data, ...res.result.data];
						} // 如果业务员列表为空直接使业务员列表参数等于请求的值
						else {
							this.salesmanListGet = res.result;
							console.log(this.salesmanListGet.data)
						}
					}
					// 如果请求不成功
					else if(res.status!=200){
						uni.showToast({
							title:res.message,
							icon:"none"
						})
					}
				})
			},
			// 根据得到的值判断是男是女
			sex(e) {
				if (e == 0) {
					return "男"
				} else {
					return "女"
				}
			}
		}
	}
</script>

<style scoped>
	.searchButton {
		width: 120rpx;
		height: 60rpx;
		line-height: 60rpx;
		text-align: center;
		background-color: #4794FF;
		border-radius: 10rpx;
		margin-right: 5rpx;
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: bold;
		color: #FFFFFF;
	}

	.fontbigStyle {
		font-size: 36rpx;
		font-family: PingFang SC;
		font-weight: bold;
		color: #333333;
	}

	.mysalesman {
		margin-top: 160rpx;
		padding: 30rpx;

	}

	.fontsmallstyle {
		font-size: 26rpx;
		color: #999999;
		margin-bottom: 17rpx;
	}

	.fontstyle {
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #333333;
		margin-bottom: 20rpx;
	}

	.salesmanStyle {
		width: 92rpx;
		height: 26rpx;
		background: #FFFFFF;
		border: 1rpx solid #2239CF;
		border-radius: 13rpx;
		font-size: 18rpx;
		font-family: PingFang SC;
		font-weight: 400;
		text-align: center;
		position: relative;
		bottom: 16rpx;
		z-index: 1;
	}

	.searchInput {
		margin: 0 30rpx;
		width: 100%;
		background: #9ec5fa;
		border-radius: 10rpx;
	}

	.searchstyle {
		height: 90rpx;
		position: fixed;
		top: 0rpx;
		width: 100%;
		background-color: #4794FF;
		display: flex;
		justify-content: center;
		align-items: center;
		z-index: 2;
	}

	.font {
		margin-left: 20rpx;
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 400;
		text-decoration: line-through;
		color: #999999;

	}

	.fontsmall {
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #85B8FF;
	}

	.fontbig {
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #4794FF;

	}

	.navgation {
		display: flex;
		justify-content: space-around;
	}

	.navgation>view {
		text-align: center;
		height: 90rpx;
		line-height: 90rpx;
	}

	.fontstyle {
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #333333;
	}

	.fontstyle-Bold {
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #333333;
	}

	.active {
		border-bottom: 4rpx solid #4794FF;
		font-size: 30rpx;
		color: #4794FF;
	}

	.Tradeshow {
		margin: 30rpx;
		border-radius: 10rpx;
	}

	.bottomBar {
		background-color: #3699FF;
		display: flex;
		height: 90rpx;
		line-height: 90rpx;
		text-align: center;
		justify-content: space-between;
	}

	.bottomBar>view {
		width: 50%;
		height: 90rpx;
		line-height: 90rpx;
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #FFFFFF;
		background-color: #3699FF;
	}

	.bottomRefuse {
		height: 90rpx;
		line-height: 90rpx;
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #FFFFFF;
		background-color: #3699FF;
		text-align: center;
	}

	.navgat {
		height: 28px;
		font-size: 30px;
		font-family: PingFang SC;
		color: #FFFFFF;
	}
</style>
