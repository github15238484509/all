<template>
	<view class="main-box">
		<view class="main-top">
			<view class="top">

				<view class='line1 line'>
					<view class="img">
						<image src="../../static/salesManAct.png" mode="aspectFill"></image>
					</view>

					<view class="top-txt" style="color: #4794FF;">
						上传身份证
					</view>
				</view>
				<view class="step-line">

				</view>
				<view class='line2 line'>
					<view class="img">
						<image src="../../static/salesMan2Act.png" mode="aspectFill"></image>
					</view>

					<view class="top-txt" style="color: #4794FF;">
						提交申请资料
					</view>
				</view>
				<view class="step-line">

				</view>
				<view class='line3 line'>
					<view class="img">
						<image src="../../static/salesMan3.png" mode="aspectFill"></image>
					</view>

					<view class="top-txt">
						完成认证
					</view>
				</view>
			</view>
		</view>

		<view class="mid">
			<view class="xline-bet" style="height: 100rpx;">

				<view class="left">

					<view class="">
						手机号
					</view>
				</view>
				<view class="right">
					<input type="number" v-model="phone" value="" maxlength="11" placeholder="请输入手机号"
						placeholder-style="font-size:30rpx;color:#999999" />
				</view>
			</view>
			<view class="xline-bet" style="height: 100rpx;">

				<view class="left">

					<view class="">
						姓名
					</view>
				</view>
				<view class="right">
					<input type="text" value="" v-model="card_name" placeholder="请输入姓名"
						placeholder-style="font-size:30rpx;color:#999999" />
				</view>
			</view>
			<view class="xline-bet" style="height: 100rpx;">

				<view class="left">

					<view class="">
						年龄
					</view>
				</view>
				<view class="right">
					<input type="text" value="" v-model="age" placeholder="请输入年龄"
						placeholder-style="font-size:30rpx;color:#999999" />
				</view>
			</view>
			<view class="xline-bet" style="height: 100rpx;">

				<view class="left">

					<view class="">
						性别
					</view>
				</view>
				<view class="right">
					<view class="sex-choice">
						<view class="sex-box" @click="clkMan">
							<image src="../../static/fk_icon2.png" v-if="gender=='男'" mode="aspectFill"></image>
							<image src="../../static/fk_icon.png" v-if="gender=='女'" mode="aspectFill"></image>
							男
						</view>
						<view class="sex-box" @click="clkWoman" style="margin-left: 40rpx;">
							<image src="../../static/fk_icon2.png" mode="aspectFill" v-if="gender=='女'"></image>
							<image src="../../static/fk_icon.png" mode="aspectFill" v-if="gender=='男'"></image>
							女
						</view>

					</view>
				</view>
			</view>
			<view class="list2">
				<citydata @get_reginId="getId" :nnn="objs"></citydata>
			</view>

			<!-- <view class="xline-bet" style="height: 100rpx;">

                <view class="left">

                    <view class="">
                        联系地址
                    </view>
                </view>
                <view class="top-txt-right" style="" > -->
			<!-- {{adresslabel}} -->
			<!-- <u-icon name="arrow-right" size="32"></u-icon> -->
			<!-- <u-picker mode="region" v-model="isChoiceAddShow" :params="params" @confirm="changeAdress">
                    </u-picker> -->

			<!--               </view>

            </view> -->

			<view class="xline-bet-end" style="height: 100rpx;">


				<view class="add-detail">
					<input type="text" value="" v-model="address" placeholder="请输入详细地址"
						placeholder-style="font-size:26rpx;color:#999999" />
				</view>
			</view>

		</view>
		<view class="xline20">

		</view>
		<view class="btm">
			<view class="btm-reason">
				申请原因:
			</view>
			<view class="btm-text">
				<textarea class="theTextarea" v-model="reason" value="" @input="getNum" maxlength="500"
					placeholder="请描述申请缘由，最多输入500个字。" placeholder-style="font-size:24rpx;color:#999999" />
				<view class="txt-num">
					{{iptnum}}/500
				</view>
			</view>
		</view>
		<view class="xbtn-blue" @click="toConfirm">
			提交
		</view>
	</view>

	</view>

	</unipopup>
	</view>

	</view>
</template>

<script>
	import applysSalesManApi from "../../api/main/ApplysSalesman.js"
	import unipopup from "../../components/uni-popup/uni-popup.vue"
	import commerciaCentreApi from "../../api/commercial/commerciaCentreApi.js"
	import loginApi from "../../api/login/login.js"
	import orderApi from "../../api/index/indexList.js"
	import citydata from "../../components/citydata.vue"

	export default {
		components: {
			unipopup,
			citydata
		},
		data() {
			return {
				params: {
					province: true,
					city: true,
					area: true
				},
				adresslabel: "请选择区域",
				//输入的字数
				iptnum: 0,
				reason: "",
				isAreaShow: false,
				areaInfo: "",
				//默认选择男
				isManChoice: true,
				isWomanChoice: false,
				gender: "男",
				tabActId: "1",
				//城市id 
				Province: "",
				city: "",
				county: "",
				card_province: "",
				card_city: "",
				card_county: "",
				objs: {},
				province_id: "",
				province_name: "",
				city_id: "",
				city_name: "",
				county_id: "",
				county_name: "",
				selectArea: "",
				//是否激活确认
				isConfirmAct: false,
				//下面是接口要传的参数
				token: "",
				name: "",
				card_front: "",
				card_reverse: "",
				phone: "",
				sex: "0",
				age: "",
				address: "",
				card_id: "",
				card_name: "",
				start_date: "",
				end_date: "",
				isChoiceAddShow: false,
				userPhone: "",

				//1是拓客员 2是业务员
				type: "",
				//支付金额，如果为0 申请拓客员属于无押金申请，直接跳转审核状态页面
				money: "",
				//拓客员再次提交审核的序列id
				apply_index: ""

			}
		},
		onshow() {

		},
		onLoad(options) {
			this.type = options.type
			if (options.type == 1) {

				uni.setNavigationBarTitle({
					title: '申请拓客员'
				});

			} else {
				uni.setNavigationBarTitle({
					title: '申请业务员'
				});
			}
			if (options.infoObj) {

				this.myObj = JSON.parse(options.infoObj)
				// console.log(this.myObj,555555555555555555);
				this.phone = this.myObj.phone
				this.name = this.myObj.name
				this.age = this.myObj.age
				this.address = this.myObj.address
				if (options.type == 1) {
					this.adresslabel = this.myObj.province_name + '-' + this.myObj.city_name + '-' + this.myObj
						.county_name
					this.reason = this.myObj.apply_reason
					this.objs.province_id = this.myObj.province
					this.objs.city_id = this.myObj.city
					this.objs.county_id = this.myObj.county
					this.province_id = this.myObj.province
					this.city_id = this.myObj.city
					this.county_id = this.myObj.county
					this.objs.province_name = this.myObj.province_name
					this.objs.city_name = this.myObj.city_name
					this.objs.county_name = this.myObj.county_name
					this.apply_index = this.myObj.apply_index
				} else {

					this.adresslabel = this.myObj.card_province_name + '-' + this.myObj.card_city_name + '-' + this.myObj
						.card_county_name
					this.reason = this.myObj.reason
					this.objs.province_id = this.myObj.card_province
					this.objs.city_id = this.myObj.card_city
					this.objs.county_id = this.myObj.card_county
					this.province_id = this.myObj.card_province
					this.city_id = this.myObj.card_city
					this.county_id = this.myObj.card_county
					this.objs.province_name = this.myObj.card_province_name
					this.objs.city_name = this.myObj.card_city_name
					this.objs.county_name = this.myObj.card_county_name
					// console.log(this.objs,6666666666666);
				}

				console.log(this.myObj)
				this.iptnum = this.reason.length
				this.sex = this.myObj.sex
				if (this.sex == 1) {
					this.gender = '女'
				}
				if (this.sex == 0) {
					this.gender = '男'
				}
				commerciaCentreApi.getCityId({
					city_name: this.card_province
				}).then(res => {
					if (res.status == 200) {
						this.card_province = res.result.region_id
					}
				})

				commerciaCentreApi.getCityId({
					city_name: this.card_city
				}).then(res => {
					if (res.status == 200) {
						this.card_city = res.result.region_id
					}
				})
				commerciaCentreApi.getCityId({
					city_name: this.card_county
				}).then(res => {
					if (res.status == 200) {
						this.card_county = res.result.region_id
					}
				})
			}
			if (options.infoObj) {
				this.myObj = JSON.parse(options.infoObj)
				this.phone_business = this.myObj.saleman_phone
			} else {
				this.phone_business = options.saleman_phone
			}
			this.card_front = options.card_front
			this.card_reverse = options.card_reverse
			this.card_id = options.card_id
			this.card_name = options.card_name
			this.start_date = options.start_date
			this.end_date = options.end_date
			this.token = uni.getStorageSync('xxytoken')
			if (this.name == "") {
				this.name = options.card_name
			}
		},
		methods: {
			getId(obj) {
				console.log(obj);
				this.selectArea = obj
				this.province_name = obj.province_name;
				this.city_name = obj.city_name;
				this.county_name = obj.county_name;
				this.province_id = obj.province_id;
				this.city_id = obj.city_id;
				this.county_id = obj.county_id;
			},
			// 地区选择的三级联动
			changeAdress(e) {
				this.adresslabel = e.province.label + " " + e.city.label + " " + e.area.label
				this.county = e.area.label.replace(/(省|市|自治区|自治州|县|区|辖)/g, '')
				this.city = e.city.label.replace(/(省|市|自治区|自治州|县|区|辖)/g, '')
				this.province = e.province.label.replace(/(省|市|自治区|自治州|县|区|辖)/g, '')
				commerciaCentreApi.get_province({
					city_name: this.province
				}).then(res => {
					if (res.status == 200) {
						this.card_province = res.result.region_id
					}
				})

				commerciaCentreApi.get_city({
					city_name: this.city
				}).then(res => {
					if (res.status == 200) {
						this.card_city = res.result.region_id
					}
				})
				commerciaCentreApi.get_district({
					city_name: this.county
				}).then(res => {
					if (res.status == 200) {
						this.card_county = res.result.region_id
					}
				})
			},
			// 打开地址选择器
			choiceAdd() {
				this.isChoiceAddShow = true
			},
			getNum() {
				this.iptnum = this.reason.length
			},
			// 点击男性
			clkMan() {
				this.gender = "男"
				this.sex = 0
			},
			// 点击女性
			clkWoman() {
				this.gender = "女"
				this.sex = 1
			},
			// 点击保存发送请求
			toConfirm() {
				if (this.phone == "") {
					uni.showToast({
						title: "请输入手机号",
						icon: "none"
					})
				} else if (this.name == "") {
					uni.showToast({
						title: "请输入姓名",
						icon: "none"
					})
				} else if (this.age == "") {
					uni.showToast({
						title: "请输入年龄",
						icon: "none"
					})
				} else if (this.address == "") {
					uni.showToast({
						title: "请输入详细地址",
						icon: "none"
					})
				} else if (this.county_id == "") {
					uni.showToast({
						title: "请选择区域",
						icon: "none"
					})
				} else if (this.reason == "") {
					uni.showToast({
						title: "请输入申请原因",
						icon: "none"
					})
				} else {

					if (this.type == 1) {
						//申请拓客员
						console.log(1)
						applysSalesManApi.applyTokerManIn({
							token: this.token,
							name: this.name,
							card_front: this.card_front,
							card_reverse: this.card_reverse,
							phone: this.phone,
							sex: this.sex,
							age: this.age,
							card_province: this.province_id,
							card_city: this.city_id,
							card_county: this.county_id,
							address: this.address,
							reason: this.reason,
							card_id: this.card_id,
							card_name: this.card_name,
							start_date: this.start_date,
							end_date: this.end_date,
							id: this.apply_index,
							//下面这个字段 代理商入驻需要提交
							phone_business: this.phone_business
						}).then(res => {

							console.log(res)
							let id = res.result
							if (res.status == 200) {

								orderApi.affirmPay({
									task_id: res.result,
									type: "4"
								}).then(res => {
									console.log(res)
									if (res.status == 200) {

										this.money = res.result.money

										if (this.money > 0) {
											let alert_content = "申请成为拓客员需缴纳" + this.money / 100 +
												"元任务押金"
											uni.showModal({
												title: "提示",
												content: alert_content,
												confirmText: "立即缴纳",
												confirmColor: '#3898FF',
												cancelColor: '#999999',
												success: (res) => {
													console.log(id)
													if (res.confirm) {
														uni.navigateTo({
															url: '../pay/pay?type=4' +
																"&id=" + id
														})
													}

												}
											})
										} else {
											uni.showToast({
												title: "提交成功",
												icon: "none"
											})
											setTimeout(() => {
												uni.reLaunch({
													url: "./auditing/auditing?type=" +
														this
														.type
												})
											}, 1000)
										}

									} else {
										uni.showToast({
											title: res.message,
											icon: 'none'
										})
									}
								})



							} else {
								if (res.message) {
									uni.showToast({
										title: res.message,
										icon: "none"
									})
								} else {
									uni.showToast({
										title: "提交失败，请完善信息重新提交",
										icon: "none"
									})
								}

							}
						})
					} else {
						applysSalesManApi.applysSalesManIn({
							token: this.token,
							name: this.name,
							card_front: this.card_front,
							card_reverse: this.card_reverse,
							phone: this.phone,
							sex: this.sex,
							age: this.age,
							card_province: this.province_id,
							card_city: this.city_id,
							card_county: this.county_id,
							address: this.address,
							reason: this.reason,
							card_id: this.card_id,
							card_name: this.card_name,
							start_date: this.start_date,
							end_date: this.end_date,
							//下面这个字段 代理商入驻需要提交
							phone_business: this.phone_business
						}).then(res => {
							console.log(this.userList)
							console.log(res)
							if (res.status == 200) {
								uni.showToast({
									title: "提交成功",
									icon: "none"
								})
								setTimeout(() => {
									uni.reLaunch({
										url: "./auditing/auditing?phone=" + this
											.phone_business + "&type=" + this.type
									})
								}, 1000)
							} else {
								uni.showToast({
									title: res.message,
									icon: "none"
								})
							}
						})
					}

				}

			}
		}
	}
</script>
<style>
	page {
		background-color: #FFFFFF;
	}
</style>
<style scoped lang="scss">
	.list2 {
		background-color: #FFFFFF;
		height: 87rpx;
		display: flex;
		justify-content: space-between;
		align-items: center;

		.left {
			margin-left: 30rpx;

			font-size: 26rpx;
			font-family: PingFang SC;
			font-weight: 400;
			color: #333333;

		}

		.right {

			font-size: 26rpx;
			font-family: PingFang SC;
			font-weight: 400;
			color: #999999;
			text-align: right;
			margin-right: 30rpx
		}
	}

	.main-box {
		input {
			font-size: 28rpx;
		}
	}

	.main-top {
		height: 150rpx;
		background-color: #F5F5F5;
	}

	.top {
		display: flex;
		margin: 0 auto;
		justify-content: space-between;
		width: 650rpx;
		height: 150rpx;
		font-size: 24rpx;
		align-items: center;
		background-color: #F5F5F5;

		.img {
			margin: 0 auto;
			width: 60rpx;
			height: 60rpx;

			image {
				width: 60rpx;
				height: 60rpx;

			}
		}

		.top-txt {
			margin-top: 6rpx;
		}
	}

	.step-line {
		width: 68rpx;
		height: 2rpx;
		background: #3FA3DC;
		margin-bottom: 30rpx;
	}

	.mid {
		padding: 0 30rpx;
	}

	.top-txt-right {
		font-family: PingFang SC;
		font-weight: 400;
		font-size: 26rpx;
		color: #999999;
	}

	.add-detail {

		font-size: 26rpx;

		color: #999999;

		input {
			width: 685rpx;
			background-color: #FFFFFF;
		}
	}

	.right {
		text-align: right;
	}

	.btm {
		height: 300rpx;
		background-color: #FFFFFF;
		padding: 0 30rpx;

		.btm-text {
			position: relative;
			width: 690rpx;
			height: 200rpx;
			background: #F5F5F5;
			border-radius: 10rpx;
			padding: 10rpx 20rpx 0;
			overflow: hidden;

			text {
				width: 100%;
			}

			.theTextarea {
				width: 100%;
				height: 100%;
				margin-right: 60rpx;
			}

			textarea {
				background-color: #F5F5F5;
				font-size: 26rpx;

			}
		}

		.btm-reason {
			height: 75rpx;
			line-height: 75rpx;
			font-size: 24rpx;
		}
	}

	.xbtn-blue {
		margin: 20rpx auto;
	}

	.txt-num {
		position: absolute;
		right: 10rpx;
		bottom: 10rpx;
		font-size: 24rpx;
		color: #999999;
	}

	.sex-choice {
		display: flex;
		align-items: center;

		image {
			width: 36rpx;
			height: 36rpx;
		}
	}

	.sex-box {
		width: 85rpx;
		display: flex;
		align-items: center;
		justify-content: space-evenly;
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
	}

	.mask {
		.tabact {
			color: #4794FF;
		}

		.popup-box {
			height: 500rpx;
			width: 100%;
			background-color: #FFFFFF;
			padding-top: 10rpx;

		}

		.popup-box-title {
			line-height: 60rpx;
			height: 60rpx;
			font-size: 36rpx;
			font-weight: bolder;
			display: flex;
			justify-content: space-between;

			.title-left {
				width: 560rpx;
				display: flex;

				justify-content: space-evenly;

				text {
					margin-right: 30rpx;
				}
			}

			.title-right {
				margin-right: 30rpx;
			}
		}

		.popup-box-content {
			margin-top: 20rpx;
			height: 400rpx;
			overflow: auto;
		}

		.pbc-item {}

		.pbc-item-list {
			height: 82rpx;
			line-height: 82rpx;
			font-size: 36rpx;
			margin-left: 46rpx;
		}
	}
</style>
