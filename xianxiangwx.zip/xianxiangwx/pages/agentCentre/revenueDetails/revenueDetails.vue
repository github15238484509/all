<template>
	<view class="box">
		<view class="banner">
			<view class="banner-h">
				<image src="../../../static/money.png" class="img"></image>
				<view class="num">
					66666.00
				</view>
				<view class="date">
					第04/12期
				</view>
			</view>
			<view class="banner-f">
				<view class="item">
					<view class="item-l">
						订单编号
					</view>
					<view class="item-r">
						15165161613311
					</view>
				</view>
				<view class="item">
					<view class="item-l">
						扣款时间
					</view>
					<view class="item-r">
						2021-02-22 16:33
					</view>
				</view>
				<view class="item">
					<view class="item-l">
						扣款方式
					</view>
					<view class="item-r">
						花呗
					</view>
				</view>
				<view class="item">
					<view class="item-l">
						交易单号
					</view>
					<view class="item-r">
						6556616516516516515
					</view>
				</view>
				<view class="item">
					<view class="item-l">
						分期详情
					</view>
					<view class="item-r" style="color:#4794FF">
						查看分期详情 >
					</view>
				</view>
			</view>
		</view>
		<view class="footer">
			<view class="name">
				<view class="name-l">
					会员昵称
				</view>
				<view class="name-r">
					伍六一
				</view>
			</view>
			<view class="phone">
				<view class="phone-l">
					会员手机号
				</view>
				<view class="phone-r">
					12345678910
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				user:""
			};
		}
	}
</script>
<style>
	page {
		height: 100%;
	}
</style>
<style lang="scss" scoped>
	.box {
		background-color: #f5f5f5;
		width: 100%;
		height: 100%;
		overflow: hidden;

		.banner {
			width: 690rpx;
			height: 730rpx;
			background-color: #fff;
			margin: 0 auto;
			margin-top: 30rpx;
			margin-bottom: 20rpx;
			border-radius: 10rpx;
			.banner-h{
				width: 50%;
				margin: 0 auto;
				overflow: hidden;
				.img{
					width: 100rpx;
					height: 100rpx;
					margin: 0 auto;
					display: block;
					margin-top: 40rpx;
					margin-bottom: 50rpx;
				}
				.num{
					
					font-size: 52rpx;
					font-family: PingFang SC;
					font-weight: bold;
					color: #333333;
					text-align: center;
					margin-bottom: 22rpx;
				}
				.date{									
					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #333333;
					text-align: center;					
				}
			}
			.banner-f{
				margin-top: 100rpx;
				.item{
					display: flex;
					justify-content: space-between;
					margin-bottom: 20rpx;
					margin-left: 22rpx;
					margin: 22rpx;
					.item-l{						
						font-size: 28rpx;
						font-family: PingFang SC;
						font-weight: 400;
						color: #999999;						
					}
					.item-r{			
						font-size: 30rpx;
						font-family: PingFang SC;
						font-weight: 500;
						color: #333333;					
					}
				}
			}
		}

		.footer {
			width: 690rpx;
			height: 140rpx;
			background-color: #fff;
			margin: 0 auto;
			border-radius: 10rpx;
			overflow: hidden;
			
			.name{
				display: flex;
				justify-content: space-between;
				margin-top: 20rpx;
				margin-bottom: 20rpx;
				.name-l{
					font-size: 28rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #999999;
					margin-left: 22rpx;
				}
				.name-r{			
					font-size: 30rpx;
					font-family: PingFang SC;
					font-weight: 500;
					color: #333333;		
						margin-right: 22rpx;
				}
			}
			.phone{
				display: flex;
				justify-content: space-between;
			
				.phone-l{
					font-size: 28rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #999999;
					margin-left: 22rpx;
				}
				.phone-r{				
					font-size: 30rpx;
					font-family: PingFang SC;
					font-weight: 500;
					color: #333333;		
					margin-right: 22rpx;
				}
			}
		}
	}
</style>

