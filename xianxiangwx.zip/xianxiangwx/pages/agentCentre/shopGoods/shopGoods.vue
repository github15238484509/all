<template>
	<view style="padding: 30rpx;">
		<view class="header">
			<view class="businessImg">
				<img :src="$imgUrl(commercialList.goods_merchant.merchant_logo)" alt="">
			</view>
			<view class="businessCore">
				<view class="businessName">{{commercialList.goods_merchant.merchant_name}}</view>
				<view class="businessTime">
					营业时间:{{commercialList.goods_merchant.merchant_worktime_start}}-{{commercialList.goods_merchant.merchant_worktime_end}}
				</view>
				<view class="businessDue">年费到期时间:{{$timeConvert(commercialList.goods_merchant.expire_time)}}</view>
			</view>
		</view>
		<view class="Tradeshow">
			<view>
				<img :src="$imgUrl(commercialList.goods_icon)" alt=""
					style="height: 276rpx;width: 100%;border-radius: 10rpx 10rpx 0 0;" mode="scaleToFill">
			</view>
			<view class="fontstyle-Bold" style="margin: 21rpx 30rpx">
				{{commercialList.goods_name}}
			</view>
			<view style="margin: 20rpx 26rpx;">
				<span class="fontbig" v-if="commercialList.goods_type==0">￥{{$returnFloat(commercialList.goods_cost)}}</span>
				<span class="fontbig" v-if="commercialList.goods_type!=0">￥{{$returnFloat(commercialList.each_issue)}}</span>
				<span  v-if="commercialList.goods_type!=0" class="fontsmall">X{{commercialList.goods_type}}期</span>
				<span  v-if="commercialList.goods_type!=0" class="font">￥{{$returnFloat(commercialList.goods_cost)}}</span>
			</view>
		</view>
		<view style="border: 2rpx solid #F5F5F5;border-radius: 10rpx;margin-top: 20rpx;padding: 0 30rpx;">
			<view style="display: flex;align-items: center;height: 90rpx;">
				<img src="../../../static/detailsIcon.png" alt="" style="width:34rpx;height:34rpx;margin-right:20rpx ;">
				<view>服务说明</view>
			</view>
			
			<text  disabled style="width: 100%;height: 200rpx;margin-right: 30rpx;"  placeholder-class="placeholderStyle" maxlength="-1" class="font-input">{{commercialList.goods_intro}}</text>
<!-- 			<view style="font-size:26rpx;font-family: PingFang SC;font-weight: 400;color:#333333;margin-left: 20rpx;">
				{{commercialList.goods_intro}}
			</view> -->
		</view>
		<view style="width:100%;" v-if="showstastus==0">
			<view class="butStyle">
				<view class="buttonadopt" @click="buttonadopt(0)">通过</view>
				<view class="buttonadopt" @click="buttonadopt(1)" style="margin-right: 60rpx;">驳回</view>
			</view>
		</view>
		<view style="width: 100%;margin: 20rpx 30rpx;" v-if="showstastus==4">
			<view style="font-size: 26rpx;font-family: PingFang SC;font-weight: 400;color: #FF4848;">
				驳回原因:{{commercialList.refuse_reason}}
			</view>
		</view>
			<u-modal :mask-close-able="true" v-model="modalShow" :title-style="{color: 'block','font-size':'30rpx','font-weight':'bold'}" title="请输入驳回理由" @confirm="pass()">
				<view class="slot-content" style="display: flex;justify-content: center;z-index: 999999;">
					<textarea v-model="textCoent"  class="textareastyle" placeholder="请输入" />
				</view>
				<u-toast position="top"  ref="uToast"/>
			</u-modal>
	</view>
</template>

<script>
	
	import agentBusunessApi from "../../../api/agentCenter/agentCenter.js"
	export default {
		data() {
			return {
				modalShow: false,
				toke: "",
				commercialList: {
					goods_merchant:{
					 
					},
					merchant_logo: "",
					merchant_name: "",
					merchant_worktime_start: "",
					merchant_worktime_end: "",
					dueDate: "",
				},
				goods_idIndex: "",
				textCoent: "",
				showstastus:"0"
			}
		},
		onLoad(e) {
			this.token = uni.getStorageSync('xxytoken');
			// 调用商品详情
			this.goods_idIndex = e.id
			agentBusunessApi.getCommodityDetail({
				toke: this.token,
				goods_id: e.id
			}).then(res => {
				if (res.status == 200&&res.result!=null) {
					this.commercialList = res.result
					this.showstastus=res.result.goods_status
				}
			})
		},
		methods: {
			pass(){
				if (this.textCoent != "") {
					console.log(this.textCoent)
					var potList = {
						token: "",
						type: 1,
						goods_id: this.goods_idIndex,
						refuse_reason:this.textCoent
					}
					potList.token=this.token
					agentBusunessApi.changeAgentType(potList).then(res=>{
						if(res.status==200){
							uni.navigateBack({
								delta:1
							})
						}
					})
				} else {
					// setTimeout(() => {
					// this.$refs.uToast.show({
					// 	title: '驳回内容不可为空',
					// 	type: 'error',
					// })
					// }, 500)
					this.$refs.uToast.show({
						title: '驳回内容不可为空',
						type: 'error',
					})	
					this.modalShow=true
				}
				// this.modalShow=true
			},
			buttonadopt(e) {
				var potList = {
					token: "",
					type: e,
					goods_id: this.goods_idIndex,
				}
				potList.token=this.token
				if (e == 0) {
					agentBusunessApi.changeAgentType(potList).then(res => {
						if (res.status == 200) {
							uni.showToast({
								title: "审核通过",
								icon: "none"
							})
							setTimeout(() => {
								uni.navigateBack({
									delta:1
								})
							}, 500)
						}else{
							uni.showToast({
								title:res.message,
								icon:"none"
							})
						}
					})
				} else {
					this.modalShow = true
				}
			}
		}
	}
</script>

<style scoped>
	.font-input{
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #333333;
	}
	/deep/.placeholderStyle {
		text-align: end;
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #999999;
	}
	.butStyle{
		display: flex;
		justify-content: space-between;
		position:fixed;
		bottom: 30rpx;
		width: 100%;
		box-sizing: border-box;
	}
	.textareastyle {
		background-color: #F5F5F5;
		border: 1rpx solid #CCCCCC;
		border-radius: 10rpx;
		margin: 30rpx;
	}

	.buttonadopt {
		width: 330rpx;
		height: 90rpx;
		text-align: center;
		background-color: #4794FF;
		line-height: 90rpx;
		color: #FFFFFF;
		border-radius: 10rpx;
	}

	.Tradeshow {
		margin-top: 20rpx;
		border-radius: 10rpx;
		border: 2rpx solid #F5F5F5;
	}

	.fontstyle-Bold {
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #333333;
	}

	.font {
		margin-left: 20rpx;
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 400;
		text-decoration: line-through;
		color: #999999;

	}

	.fontsmall {
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #85B8FF;
	}

	.fontbig {
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #4794FF;

	}

	.header {
		background: #FFFFFF;
		display: flex;
		flex-direction: row;
		border: 2rpx solid #F5F5F5;
		border-radius: 10rpx;
	}

	.businessImg>img {
		margin: 60rpx 31rpx;
		width: 139rpx;
		height: 140rpx;
		border-radius: 6rpx;
	}

	.businessCore {
		margin-top: 60rpx;
	}

	.Carousel-more {
		margin-right: 30rpx;
	}

	.businessCore .businessName {
		font-size: 33rpx;
		font-family: PingFang SC;
		font-weight: bold;
		color: #333333;
	}

	.businessCore>view {
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #999999;
		margin-bottom: 20rpx;
	}
</style>
