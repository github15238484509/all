<template>
	<view class="box">
		<view class="header">
			<view class="header-l">
				<image :src="$imgUrl(user.photo)" class="img"></image>
				<view class="text">
					<view class="name">
						{{user.name}}
					</view>
					<view class="phone">
						{{user.phone}}
					</view>
					<view class="header-r">
						<image src="../../static/place.png" class="img"></image>
						<view class="text">
							{{userMerchantRevenue.city}}
						</view>
					</view>
				</view>
			</view>
			<view>
				<img src="../../static/退出登录.png" alt="" style="width: 200rpx;height: 70rpx;" @click="log_out">
			</view>
		</view>
		<view class="banner">
			<image class="img" src="../../static/lb.png"></image>
			<view class="page-section swiper">
				<view class="page-section-spacing">
					<swiper class="swiper" :autoplay="true" :interval="3000" :vertical="true" :circular="true">
						<swiper-item class="swiper-item" v-for="(item,index) in title" :key="index">
							<view class="swiper-text" @click="goNoticeList(item)">{{item.title}}</view>
						</swiper-item>
					</swiper>
				</view>
			</view>
			<view class="swiper-link" @click="goNotice">
				全部>>
			</view>
		</view>
		<view class="money">
			<view class="money-t">
				<view class="text-t">
					可提现金额(元)
				</view>
				<view class="text-c">
					<view class="num">
						{{$returnFloat(userMerchantRevenue.cash)}}
					</view>
					<navigator url="./cash/cash" class="text">
						提现
					</navigator>
				</view>
				<navigator class="text-f" url="balanceRecords/balanceRecords">
					余额记录>>
				</navigator>
			</view>
			<view class="money-b">
				<view class="text-l">
					<image src="../../static/money2.png" class="img"></image>
					<view class="text">
						年费剩余套数：{{userMerchantRevenue.left_year_num}}套
					</view>
				</view>
				<view class="text-r" @tap="open">
					充值
				</view>
			</view>
		</view>
		<view class="keep">
			<view class="keep-t">
				<view class="item-l">
					商家营收记录
				</view>
				<view class="item-r">
					<navigator class="text" url="records/records">
						查看所有记录
					</navigator>
					<view class="icon">

						<image src="../../static/right.png" class="img"></image>
					</view>
				</view>
			</view>
			<view class="keep-b">
				<view class="keep-item">
					<view class="num">
						{{userMerchantRevenue.day_money}}
					</view>
					<view class="text">
						今日营收
					</view>
				</view>
				<view class="keep-item">
					<view class="num">
						{{userMerchantRevenue.month_money}}
					</view>
					<view class="text">
						本月营收
					</view>
				</view>
				<view class="keep-item">
					<view class="num">
						{{userMerchantRevenue.all_money}}
					</view>
					<view class="text">
						累计营收
					</view>
				</view>
			</view>
		</view>
		<view class="line"></view>
		<view class="footer">
			<view class="footer-t">
				功能管理
			</view>
			<view class="footer-c">
				<view class="item" @click="gotoSalesmanList">
					<image src="../../static/man.png" class="img"></image>
					<view class="text">
						业务员列表
					</view>
				</view>
				<view class="item" @click="gotoList">
					<image src="../../static/seller.png" class="img"></image>
					<view class="text">
						商家列表
					</view>
				</view>
				<view class="item" @click="gotoManage">
					<image src="../../static/goods.png" class="img"></image>
					<view class="text">
						商家商品管理
					</view>
				</view>
				<view class="item" @click="gotoAdd">
					<image src="../../static/addSeller.png" class="img"></image>
					<view class="text">
						录入商家
					</view>
				</view>
				<view class="item">

				</view>
				<view class="item">

				</view>
			</view>
		</view>
		<view>
			<uni-popup ref="popup" type="center">
				<view class="dialog">
					<view class="dia-t">
						提示
					</view>
					<view class="dia-c">
						请联系平台充值
					</view>
					<view class="dia-f" @tap="close">
						我知道了
					</view>
				</view>
			</uni-popup>
		</view>
		<view>
			<u-mask :show="showNews" @click="showNewsFun">
				<view style="position: relative;">
					<view class="noticePopup" @click="goNoticeList(alertNewsList)">
						<view class="alertNewsTitle">
							{{alertNewsList.title}}
						</view>
						<veiw class="alertNewsTime">
							<view>
								时间:{{$timeConvert(alertNewsList.add_time)}}
							</view>
							<view>
								发布人:{{alertNewsList.edit_user}}
							</view>
						</veiw>
						<view  class="noticeContent">
							<rich-text :nodes="alertNewsList.url_content"></rich-text>
						</view>
						<view class="alertNewsBtn" style="border-top: 2rpx solid #F5F5F5;margin-top: 20rpx;">
							查看详情
						</view>
					</view>
					<img src="../../static/closeNews.png" alt=""
						style="position:absolute;width: 50rpx;height:98rpx;top:990rpx;left:350rpx;z-index: 999999;margin: 0;">
				</view>
			</u-mask>
		</view>
	</view>
</template>

<script>
	import loginApi from "../../api/login/login.js"
	import agentCenterApi from "../../api/agentCenter/agentCenter.js"
	export default {
		data() {
			return {
				token: "",
				userPhone: "",
				user: {},
				title: [],
				userMerchantRevenue: {},
				alertNewsList: {
					title: ""
				},
				showNews: false
			};
		},
		onLoad(e) {
			this.token = uni.getStorageSync("xxytoken")
			console.log(e)
			this.userPhone = uni.getStorageSync("userPhone")
			loginApi.welcome({
				phone: this.userPhone,
				token: this.token
			}).then(res => {
				// console.log(res)
				this.user = res.result
			})
			//轮播
			loginApi.news({
				region: "3"
			}).then(res => {
				// console.log(res)
				this.title = res.result
			})
			//营收记录
			agentCenterApi.merchant_order_branch({
				token: uni.getStorageSync("xxytoken"),
				page: "1",
				count: "10"
			}).then(res => {
				console.log(res)
			})
			// 查询代理商余额
			agentCenterApi.user_merchant_revenue({
				token: this.token
			}).then(res => {
				if (res.status == 200) {
					console.log(res)
					this.userMerchantRevenue = res.result
				}
			})
			// 查询用户强制弹窗
			agentCenterApi.get_alert_news({
				region: "3",
				token: this.token
			}).then(res => {
				if (res.status == 200 && res.result != null) {
					this.alertNewsList = res.result
					this.showNews = true
					if (res.result.title.length > 27) {
						this.alertNewsList.title = res.result.title.substring(0, 27) + "..."
					}
				}
			})
		},
		methods: {
			// 新闻弹窗展示
			showNewsFun(){
				agentCenterApi.get_alert_news({
					region: "3",
					token: this.token,
					id:this.alertNewsList.id
				}).then(res => {
					if (res.status == 200) {
						this.showNews = false
					}else{
						this.showNews = false
					}
				})
			},
			// 点击新闻详情
			goNoticeList(e) {
				uni.navigateTo({
					url: "../newsDetail?url=" + e.content + '&title=' + e.title
				})
			},
			// 退出登录功能
			log_out() {
				loginApi.logout({
					token: this.token
				}).then(res => {
					if (res.status == 200) {
						uni.removeStorageSync("xxytoken");
						uni.removeStorageSync("userPhone");
						uni.reLaunch({
							url: "../login/welcome/welcome"
						})
					}
				})
			},
			open() {
				// 通过组件定义的ref调用uni-popup方法
				this.$refs.popup.open()
			},
			close() {
				this.$refs.popup.close()
			},
			gotoList() {
				uni.navigateTo({
					url: `./shopList/shopList`
				})
			},
			gotoManage() {
				uni.navigateTo({
					url: `./goodsManage/goodsManage`
				})
			},

			gotoAdd() {
				uni.navigateTo({
					url: `./myAdd/myAdd?userPhone=` + this.userPhone
				})
			},
			gotoSalesmanList() {
				uni.navigateTo({
					url: "../salesmanCenter/salesmanList/salesmanList"

				})
			},
			// 去公告页面
			goNotice() {
				uni.navigateTo({
					url: "../newsList?status=3"
				})
			}
		}
	}
</script>

<style lang="scss">
	.noticeContent{
		font-size: 28rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #999999;
		margin-top: 30rpx;
		width: 480rpx;
		height: 360rpx;
		overflow: hidden;
	}
	.alertNewsBtn {
		font-size: 32rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #4894FF;
		text-align: center;
		width: 100%;
		height: 90rpx;
		line-height: 90rpx;
	}

	.alertNewsTime {
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #999999;
	}

	.alertNewsTitle {
		height: 70rpx;
		font-size: 32rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #222222;
		margin-bottom: 30rpx;
	}

	.noticePopup {
		position: absolute;
		left: 105rpx;
		top:300rpx;
		width: 480rpx;
		height: 640rpx;
		background: #FFFFFF;
		border-radius: 10px;
		padding: 30rpx;
		border-bottom: 2rpx solid #F5F5F5;
	}

	.box {
		.header {
			width: 100%;
			height: 170rpx;
			display: flex;
			justify-content: space-between;
			align-items: center;

			.header-l {
				display: flex;
				justify-content: space-between;
				margin-left: 30rpx;

				.text {
					margin-left: 23rpx;
				}

				.img {
					width: 120rpx;
					height: 120rpx;
					border-radius: 50%;
				}

				.name {
					font-size: 30rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #333333;
					margin-bottom: 10rpx;
				}

				.phone {
					font-size: 24rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #999999;
				}
			}

			.header-r {
				display: flex;
				justify-content: flex-start;
				align-items: center;
				margin-left: 10rpx;
				margin-top: 10rpx;

				.img {
					width: 30rpx;
					height: 30rpx;
				}

				.text {
					font-size: 24rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #999999;
					margin-left: 8rpx;
				}
			}

		}

		.banner {
			width: 750rpx;
			height: 80rpx;
			background: #DAEAFF;
			display: flex;
			justify-content: flex-start;
			align-items: center;

			.img {
				height: 32rpx;
				width: 32rpx;
				margin-left: 40rpx;

			}

			.swiper {
				height: 80rpx;
				width: 568rpx;

				.swiper-item {
					display: flex;
					justify-content: flex-start;
					align-items: center;
					
					.swiper-text {
						width: 480rpx;
						white-space: nowrap;
						text-overflow: ellipsis;
						overflow: hidden;
						word-break: break-all;
						font-size: 24rpx;
						font-family: PingFang SC;
						font-weight: 400;
						color: #333333;
						line-height: 66rpx;
						margin-left: 10rpx;
					}

				}

			}

			.swiper-link {
				font-size: 24rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #999999;
				// margin-left: 50rpx;
			}
		}

		.money {
			overflow: hidden;
			width: 100%;
			height: 350rpx;
			background-color: #F5F5F5;

			.money-t {
				width: 690rpx;
				height: 200rpx;
				margin: 20rpx auto;
				background: url(../../static/bg1.png) no-repeat;
				border-radius: 15rpx;
				overflow: hidden;

				.text-t {
					font-size: 24rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #FFFFFF;
					margin-top: 30rpx;
					margin-left: 30rpx;
					margin-bottom: 15rpx;
				}

				.text-c {
					display: flex;
					justify-content: space-between;

					.num {
						font-size: 48rpx;
						font-family: PingFang SC;
						font-weight: 800;
						color: #FFFFFF;
						margin-left: 30rpx;
					}

					.text {
						width: 135rpx;
						height: 50rpx;
						background: #F5F5F5;
						border-radius: 25rpx;
						color: #4794FF;
						text-align: center;

						font-size: 24rpx;
						font-family: PingFang SC;
						font-weight: 400;
						line-height: 50rpx;
						margin-right: 30rpx;


					}
				}

				.text-f {

					font-size: 24rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #FFFFFF;
					text-align: center;
					margin-top: 10rpx;

				}
			}

			.money-b {
				width: 690rpx;
				height: 90rpx;
				background: #4794FF;
				border-radius: 15rpx;
				margin: 0 auto;
				display: flex;
				justify-content: space-between;
				align-items: center;

				.text-l {
					display: flex;
					justify-content: flex-start;
					margin-left: 30rpx;

					.img {
						margin-right: 10rpx;
						width: 36rpx;
						height: 36rpx;
						vertical-align: bottom;
					}

					.text {

						font-size: 30rpx;
						font-family: PingFang SC;
						font-weight: 400;
						color: #FFFFFF;


					}
				}

				.text-r {
					width: 135rpx;
					height: 50rpx;
					background: #F5F5F5;
					border-radius: 25rpx;
					color: #4794FF;
					text-align: center;

					font-size: 24rpx;
					font-family: PingFang SC;
					font-weight: 400;
					line-height: 50rpx;
					margin-right: 30rpx;
				}

			}
		}

		.keep {
			width: 100%;
			height: 205rpx;

			.keep-t {
				height: 68rpx;
				display: flex;
				justify-content: space-between;
				align-items: center;
				border-bottom: 2rpx solid #EDEDED;

				.item-l {
					font-size: 30rpx;
					font-family: PingFang SC;
					font-weight: bold;
					color: #222222;
					margin-left: 30rpx;
				}

				.item-r {
					display: flex;
					justify-content: flex-start;
					align-items: center;
					height: 60rpx;
					margin-right: 28rpx;

					.text {
						font-size: 24rpx;
						font-family: HiraginoSansGB;
						font-weight: normal;
						color: #999999;
						margin-right: 10rpx;

					}

					.img {
						width: 17rpx;
						height: 28rpx;
					}

					.icon {
						margin-top: 4rpx;

					}
				}
			}

			.keep-b {
				display: flex;
				justify-content: space-around;

				.keep-item {
					.num {
						font-size: 30rpx;
						font-family: PingFang SC;
						font-weight: 500;
						color: #333333;
						margin-top: 25rpx;
						text-align: center;
					}

					.text {
						font-size: 26rpx;
						font-family: PingFang SC;
						font-weight: 400;
						color: #666666;
						margin-top: 8rpx;
					}
				}
			}
		}

		.line {
			width: 100%;
			height: 20rpx;
			background: #F5F5F5;

		}

		.footer {
			.footer-t {
				font-size: 30rpx;
				font-family: PingFang SC;
				font-weight: bold;
				color: #333333;
				margin-left: 30rpx;
				margin-top: 30rpx;
			}

			.footer-c {
				margin-top: 50rpx;
				display: flex;
				justify-content: space-around;
				flex-wrap: wrap;

				.item {
					width: 160rpx;
					text-align: center;
					margin: 0 40rpx;
					margin-bottom: 50rpx;

					.img {
						width: 44rpx;
						height: 44rpx;
					}

					.text {
						font-size: 26rpx;
						font-family: PingFang SC;
						font-weight: 400;
						color: #333333;
					}
				}
			}
		}
	}

	.dialog {
		width: 500rpx;
		height: 300rpx;
		background: #FFFFFF;
		border-radius: 10rpx;
		overflow: hidden;
		position: relative;

		.dia-t {

			font-size: 30rpx;
			font-family: PingFang SC;
			font-weight: 500;
			color: #333333;
			margin: 30rpx auto;
			text-align: center;

		}

		.dia-c {

			font-size: 26rpx;
			font-family: PingFang SC;
			font-weight: 400;
			color: #999999;
			margin: 0 28rpx;
			text-align: center;


		}

		.dia-f {
			position: absolute;
			bottom: 0;
			left: 0;
			width: 100%;
			height: 90rpx;

			font-size: 26rpx;
			font-family: PingFang SC;
			font-weight: 400;
			color: #4894FE;
			text-align: center;
			line-height: 90rpx;
			margin-top: 25rpx;
			border-top: 2rpx solid #f5f5f5;

		}

	}
</style>
