<template>
	<view class="box">
		<!-- <view class="header">
			<view class="header-c">
				<image src="../../../static/search.png" class="img"></image>
				<u-input class="ipt" v-model="value" placeholder-style="color:#c9defc;" :border="border"
					:clearable="false" />
				<view class="btn"><text>搜索</text></view>
			</view>
		</view> -->

		<view class="nav">
			<u-sticky >
				<div class="content-nav">
					<div class="nav-item" :class="{active: current=='1'}" @click="currentChange('1')">
						<text class="text">平台审核中</text>
					</div>
					<div class="nav-item" :class="{active: current=='2'}" @click="currentChange('2')">
						<text class="text">审核失败</text>
					</div>

				</div>
			</u-sticky>
		</view>
		<div v-show="current == 1" class="content">
			<view v-if="current == 1&&shopList.data.length>0">
				<view class="score-item" v-for="item in shopList.data" :key="item.merchant_id" @click="go1(item)">
					<view class="left1">
						<image :src="$imgUrl(item.merchant_logo)" mode="aspectFill"></image>
					</view>
					<view class="right1">
						<view class="rline1">
							{{item.merchant_name}}
							<image src="../../../static/phone1.png" class="img" @click.stop="makePhone(item.merchant_user_phone)"></image>
						</view>
						<view class="rline2">
							{{item.merchant_address}}
						</view>
						<view class="rline3">
							<image src="/static/time.png" mode="aspectFill"></image>
							<text class="line-txt">{{item.merchant_worktime_start}}-{{item.merchant_worktime_end}}</text>
						</view>
						<view class="rline4">
				
							<text class="line-txt">审核中</text>
						</view>
					</view>
				</view>
			</view>
			<view v-else style="text-align: center;margin-top: 300rpx;"><img :src="cdnUrl+'XianxiangUapi/static/datanull.png'" alt="" style="width: 480rpx;height: 360rpx;"></view>
		</div>
		<div v-show="current == 2" class="content">
			<view v-if="current==2&&shopList.data.length>0">
				<view class="score-item" v-for="item in shopList.data" :key="item.merchant_id" @click="go1(item)">
					<view class="left1">
						<image :src="$imgUrl(item.merchant_logo)" mode="aspectFill"></image>
					</view>
					<view class="right1">
						<view class="rline1">
							{{item.merchant_name}}
							<image src="../../../static/phone1.png" class="img" @click.stop="makePhone(item.merchant_user_phone)"></image>
						</view>
						<view class="rline2">
							{{item.merchant_address}}
						</view>
						<view class="rline3">
							<image src="/static/time.png" mode="aspectFill"></image>
							<text class="line-txt">{{item.merchant_worktime_start}}-{{item.merchant_worktime_end}}</text>
						</view>
						<view class="rline4">
							<view class="refuse">
								<view class="fff">
									审核驳回
								</view>
								<view class="ml" @click.stop="go1(item)">
									点击查看原因>>
								</view>
							</view>
						</view>
					</view>
				</view>
			</view>
			<view v-else style="text-align: center;margin-top: 300rpx;"><img :src="cdnUrl+'XianxiangUapi/static/datanull.png'" alt="" style="width: 480rpx;height: 360rpx;"></view>
		</div>
		
		<view class="payment" @click="goPay(2)">
			<text>录入商家</text>
		</view>
	</view>
</template>

<script>
	import agentCenterApi from "../../../api/agentCenter/agentCenter.js"
	import login from "../../../api/login/login.js"
	export default {
		data() {
			return {
                cdnUrl:"",
				//激活的tab栏
				current: '1',
				// 用户电话
				userPhone: "",
				//商家列表
				shopList: {
					data:[]
				},
				//input
				value: '',
				border: false,
				pageIndex:1,
			}
		},
		// 滚动加载更多
		onReachBottom(){
			if(this.pageIndex<this.shopList.last_page){
				this.init()
			}else{
				uni.showToast({
					title:"没有更多数据了",
					icon:"none"
				})
			}
		},
		onLoad(e) {
            this.cdnUrl=this.$cdnUrl
			console.log(e)
			// 取出带过来的手机号
			this.userPhone = e.userPhone
			//tab栏
			this.init()
		},
		methods: {
			// 拨打电话
			makePhone(e){
				uni.makePhoneCall({
					phoneNumber:e
				})
			},
			// 跳转
			goStatus(){
				uni.navigateTo({
					url:"../../salesmanCenter/ApplySalesmanStatus?phone="+this.userPhone
				})
			},
			// 跳转至录入商家页面
			goPay(e) {
				uni.navigateTo({
					url:"../../salesmanCenter/addSeller/addSeller?id="+e
				})
			},
			//切换tab栏
			currentChange(e) {
				this.shopList={
					data:[]
				}
				this.pageIndex=1
				this.current = e
				this.init()
			},
			// 请求代理商录入的商家列表
			init() {
				agentCenterApi.agent_merchant_list({
					token: uni.getStorageSync('xxytoken'),
					type: this.current,
					page: this.pageIndex,
					count: "10"
				}).then(res => {
					if(res.status==200&&res.result!=null){
						if(this.shopList.data.length>0){
							this.shopList.data=[...this.shopList.data,...res.result.data]
						}else{
							this.shopList=res.result
						}
					}else if(res.status!=200){
						uni.showToast({
							title:res.message,
							icon:"none"
						})
					}
				})
			},
			//跳转到审核页面
			go1(el) {
				uni.navigateTo({
					url:"../../salesmanCenter/ApplySalesmanStatus?phone="+el.merchant_user_phone
				})
			},
		},
	}
</script>

<style lang="scss" scoped>
	.box {
		.payment {
			width: 750rpx;
			height: 90rpx;
			background: #4794FF;
			color: #fff;
			font-size: 30rpx;
			font-family: PingFang SC;
			font-weight: 500;
			display: flex;
			justify-content: center;
			align-items: center;
			position: fixed;
			left: 0;
			bottom: 0;

		}

		// background-color: #F5F5F5;

		.header {
			display: flex;
			// justify-content: space-between;
			align-items: center;
			height: 90rpx;
			width: 100%;
			background-color: #4794FF;

			.header-c {
				display: flex;
				align-items: center;
				justify-content: space-between;
				width: 690rpx;
				height: 70rpx;
				background: #9ec5fa;
				margin: 0 auto;

				border-radius: 10rpx;

				.img {
					width: 32rpx;
					height: 32rpx;
					margin-left: 50rpx;
					margin-right: 20rpx;
				}

				.btn {
					background-color: #4794FF;
					color: #fff;
					width: 120rpx;
					display: flex;
					align-items: center;
					height: 60rpx;
					text-align: center;
					justify-content: center;
					margin-right: 10rpx;
					border-radius: 10rpx;
				}
			}

		}

		.banner {
			width: 750rpx;
			height: 80rpx;
			background: #DAEAFF;
			display: flex;
			justify-content: flex-start;
			align-items: center;

			.img {
				height: 32rpx;
				width: 32rpx;
				margin-left: 40rpx;

			}

			.swiper {
				height: 80rpx;
				width: 568rpx;

				.swiper-item {
					display: flex;
					justify-content: flex-start;
					align-items: center;


					.swiper-text {
						width: 502rpx;
						font-size: 24rpx;
						font-family: PingFang SC;
						font-weight: 400;
						color: #333333;
						line-height: 66rpx;
						margin-left: 10rpx;
					}

				}

			}

			.swiper-link {
				font-size: 24rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #999999;
				// margin-left: 50rpx;
			}
		}

		.nav {
			background-color: #fff;
			// margin-top: 20rpx;
			height: 70rpx;

			.content-nav {
				background-color: #fff;
				display: flex;
				justify-content: space-around;

				.nav-item {
					.text {
						width: 76rpx;
						height: 25rpx;
						font-size: 26rpx;
						font-family: PingFang SC;
						font-weight: 400;
						line-height: 66rpx;
					}
				}

				.active {
					border-bottom: 4rpx solid #4794FF;

					.text {
						color: #4794FF;
						font-weight: 500;
						font-size: 30rpx !important;
						line-height: 66rpx;
						font-family: PingFang SC;
						// height: 29rpx;
					}
				}
			}
		}

		.content {
			padding: 0 30rpx;
			background-color: #fff;
			margin-bottom: 100rpx;
			border-top: 1rpx solid #f5f5f5;
			
			.bottom {
				width: 690rpx;
				height: 60rpx;
				background: #E0EDFF;
				border-radius: 4rpx;
				margin-top: 20rpx;
				padding: 0 100rpx;
				font-size: 26rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #333333;
				display: flex;
				justify-content: flex-start;
				align-items: center;

				.img {
					width: 50rpx;
					height: 50rpx;
					border-radius: 50%;
					margin: 0 20rpx;
				}

				.name {
					margin-right: 20rpx;
				}
			}

			.score-item {
				width: 690rpx;
				height: 200rpx;
				background: #FFFFFF;
				// border-bottom: 1rpx solid #EEEEEE;
				border-radius: 10rpx;
				display: flex;
				align-items: center;
				justify-content: flex-start;
				flex-wrap: wrap;
				margin-bottom: 30rpx;
				margin-top: 30rpx;

				.left1 {
					width: 179rpx;
					height: 180rpx;
					border-radius: 10rpx;
					margin-left: 11rpx;
					overflow: hidden;

					image {
						width: 180rpx;
						height: 180rpx;
					}
				}

				.right1 {
					margin-left: 22rpx;
					width: 458rpx;
					height: 100%;
					display: flex;
					flex-direction: column;
					justify-content: space-evenly;
					border-bottom: 1rpx solid #f5f5f5;

					.rline1 {
						font-size: 30rpx;
						display: flex;
						justify-content: space-between;

						.img {
							width: 44rpx;
							height: 44rpx;

							border-radius: 50%;

						}
					}

					.rline2 {
						font-size: 24rpx;
						color: #666666;
						white-space: nowrap;
						text-overflow: ellipsis;
						overflow: hidden;
						word-break: break-all;

					}

					.rline3 {
						width: 500rpx;
						font-size: 24rpx;
						display: flex;
						align-items: center;

						image {
							width: 28rpx;
							height: 28rpx;
							margin-left: 1rpx;
						}
					}

					.rline4 {
						width: 500rpx;
						font-size: 24rpx;
						display: flex;
						align-items: center;

						// padding-left: 5rpx;
						image {
							width: 20rpx;
							height: 27rpx;
							margin-left: 6rpx;
						}

						.refuse {
							display: flex;
							align-items: center;
							justify-content: center;

							font-size: 24rpx;
							font-family: PingFang SC;
							font-weight: 400;
							color: #FE5E5E;

							.fff {
								border-bottom: 1rpx solid #FFF;
							}

							.ml {
								margin-left: 10rpx;
								border-bottom: 1rpx solid #FE5E5E;
							}
						}
					}

				}
			}

		}

		.footer {
			// z-index: 99999;
			position: fixed;
			left: 0;
			bottom: 0;
			display: flex;
			justify-content: center;
			height: 90rpx;
			width: 100%;
			background-color: #4794FF;

			.add {
				display: flex;
				align-items: center;
				font-size: 30rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: #FFFFFF;


				.img {
					width: 36rpx;
					height: 36rpx;
					margin-right: 20rpx;
				}
			}
		}
	}

	.line-txt {
		// width: 311px;
		// height: 23px;
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #4794FF;
	}

	.rline3 {

		.line-txt {
			margin-left: 10rpx;

			color: #333333;
		}
	}


	.dialog {
		width: 500rpx;
		height: 400rpx;
		background: #FFFFFF;
		border-radius: 10rpx;
		position: relative;
		overflow: hidden;

		.dia-t {
			text-align: center;
			margin-top: 50rpx;
			margin-bottom: 40rpx;

			.title {
				font-size: 36rpx;
				font-family: PingFang SC;
				font-weight: bold;
				color: #333333;
				line-height: 34rpx;
			}

			.img {
				position: absolute;
				top: 28rpx;
				right: 28rpx;
				width: 36rpx;
				height: 36rpx;
			}
		}

		.dia-c {
			font-size: 24rpx;
			font-family: PingFang SC;
			font-weight: 400;
			color: #333333;
			line-height: 23rpx;
			margin-left: 60rpx;

			.pic {
				display: flex;
				align-items: center;
				margin-bottom: 20rpx;

				.img {
					width: 70rpx;
					height: 70rpx;
					border-radius: 50%;
				}
			}

			.name {

				margin-bottom: 20rpx;
			}

			.level {
				display: flex;
				align-items: center;
				margin-bottom: 20rpx;

				.text {
					margin-left: 48rpx;
				}
			}

			.phone {
				// margin-top: 20rpx;

				display: flex;
				align-items: center;

				.img {
					width: 44rpx;
					height: 44rpx;
					margin-left: 50rpx;
				}

				.blue {
					color: #4695FE;
				}
			}

		}

	}
</style>
