<template>
	<view class="box">
		<view class="header">
			<div class="nav-item" :class="{active: current=='1'}" @tap="currentChange('1')">
				<text class="text">按年</text>
			</div>
			<div class="nav-item" :class="{active: current=='2'}" @tap="currentChange('2')">
				<text class="text">永久</text>
			</div>
		</view>
		<view class="red" v-if="current=='1'">
			<view class="red-l">提示:</view>
			<view class="red-r">当前账户剩余年费套数{{merchantYearList.left_year_num}}套,每开通一年将会从账户内扣除{{merchantYearList.year}}套</view>
		</view>
		<view class="red" v-else>
			<view class="red-l">提示:</view>
			<view class="red-r">当前账户剩余年费套数{{merchantYearList.left_year_num}}套,开通永久将会从账户内扣除{{merchantYearList.years}}套</view>
		</view>
		<view class="years" v-if="current=='1'">
			<view class="title">缴纳年数</view>
			<input maxlength="10" class="uni-input" type="number" placeholder="请输入" v-model="yearNum" />
		</view>
		<view class="years">
			<view class="title">实际收入金额</view>
			<input maxlength="10" class="uni-input" type="number" placeholder="请输入" v-model="yearMoneyNum"/>
		</view>
		<view class="content">
			<view class="top">
				收款凭证（最多上传5张）
			</view>
			<view class="banner">
				1.建议图片大小不超过5M
			</view>
			<u-upload ref="uUpload" :custom-btn="true" max-count="5" :action="action" :auto-upload="true" width="130rpx"
				height="130rpx" @on-list-change="imgChange1">
				<view slot="addBtn" class="slot-btn" hover-class="slot-btn__hover" hover-stay-time="150">
					<image src="../../../static/upload.png" class="img" style="width: 130rpx;height: 130rpx;"></image>
				</view>
			</u-upload>
		</view>
		<view class="line">

		</view>
		<view class="text">
			备注信息:
		</view>
		<view class="btm">

			<view class="btm-text">
				<textarea class="theTextarea" v-model="reason" value="" @input="getNum" maxlength="500"
					placeholder="请描述申请缘由，最多输入500个字。" placeholder-style="font-size:24rpx;color:#999999" />
				<view class="txt-num">
					{{iptnum}}/500
				</view>
			</view>

		</view>
		<view class="btn3" @click="to">
			<text>提交</text>
		</view>
	</view>
</template>

<script>
	import agentApi from "../../../api/agentCenter/agentCenter.js"
	export default {
		data() {
			return {
				current: "1",
				//上传地址
				action: this.$uptImgUrl,
				reason: "",
				iptnum: 0,
				merchantYearList:"",
				token:"",
				merchantId:"",
				yearNum:"",
				yearMoneyNum:"",
				imgUrl:"",
			};
		},
		methods: {
			//切换tab栏
			currentChange(e) {
				this.current = e
				console.log(this.current)
			},
			imgChange1(e) {
				console.log(e)

			},
			getNum() {
				this.iptnum = this.reason.length
			},
			to(){
		
				let files = [];
				// 通过filter，筛选出上传进度为100的文件(因为某些上传失败的文件，进度值不为100，这个是可选的操作)
				files = this.$refs.uUpload.lists.filter(val => {
					return val.response.result;
				})
				let arr = []
				arr = files.map(el => {
					return el.response.result
				})
				let imgs = arr.join()
				if(this.current==2){
					this.yearNum=-1
				}
				agentApi.merchant_recharge({
						token:this.token,
						merchant_id:this.merchantId,
						type:this.current,
						money:this.yearMoneyNum,
						year_num:this.yearNum,
						cert:imgs,
						remark:this.reason,
					}).then(res=>{
					if(res.status==200){
						uni.redirectTo({
							url:"../agentCentre"
						})
					}else{
						uni.showToast({
							title:res.message,
							icon:"none"
						})
					}
				})
			}
		},
		onLoad(e) {
			this.merchantId=e.id;
			this.token=uni.getStorageSync("xxytoken")
			agentApi.merchant_year({token:uni.getStorageSync("xxytoken")}).then(res => {
				if(res.status==200){
					this.merchantYearList=res.result
				}else{
					uni.showToast({
						title:res.message,
						icon:"none"
					})
				}
			})
		},

	}
</script>

<style scoped lang="scss">
	.box {
		.btn3{
			width: 690rpx;
			height: 90rpx;
			background: #4794FF;
			border-radius: 10rpx;
			color: #fff;
			position: fixed;
			bottom: 30rpx;
			left: 30rpx;
			display: flex;
			align-items: center;
			justify-content: center;
		}
		.btm {
			height: 300rpx;
			background-color: #FFF;


			.btm-text {
				position: relative;
				width: 690rpx;
				height: 200rpx;
				background: #F5F5F5;
				border-radius: 10rpx;
				padding: 10rpx 20rpx 0;
				overflow: hidden;
				margin: 0 auto;
			}

			.theTextarea {
				width: 100%;
				height: 100%;
			}

			textarea {
				background-color: #F5F5F5;
				font-size: 26rpx;

			}

			.txt-num {
				position: absolute;
				right: 10rpx;
				bottom: 10rpx;
				font-size: 24rpx;
				color: #999999;
			}
		}

		.text {

			font-size: 24rpx;
			font-family: PingFang SC;
			font-weight: 400;
			color: #333333;
			margin-top: 30rpx;
			margin-left: 30rpx;
			margin-bottom: 20rpx;
		}

		.line {
			width: 750rpx;
			height: 20rpx;
			background: #F5F5F5;
		}

		.content {
			height: 283rpx;
			width: 100%;
			margin-left: 45rpx;

			.top {

				font-size: 26rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #222222;
				margin-top: 30rpx;
			}

			.banner {

				font-size: 24rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #999999;
				margin-top: 20rpx;
				margin-bottom: 33rpx;

			}
		}

		.years {
			box-sizing: border-box;
			width: 100%;
			height: 100rpx;
			border-bottom: 2rpx solid #f5f5f5;
			display: flex;
			justify-content: space-between;
			align-items: center;

			.title {

				font-size: 30rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #333333;
				margin-left: 30rpx;
			}

			.uni-input {
				width: 100rpx;
				margin-right: 30rpx;
				font-size: 30rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #999999;
			}
		}

		.red {
			width: 100%;
			height: 90rpx;
			background: #FFD1D1;
			// padding: 17rpx 30rpx;
			display: flex;
			justify-content: flex-start;

			font-size: 26rpx;
			font-family: PingFang SC;
			font-weight: 400;
			color: #FE4040;

			.red-l {
				width: 90rpx;
				margin-top: 11rpx;
				margin-left: 30rpx;
			}

			.red-r {
				margin-top: 11rpx;
				margin-right: 30rpx;
			}
		}

		.header {
			height: 70rpx;
			width: 100%;
			display: flex;
			justify-content: space-around;
			align-items: center;

			.nav-item {
				width: 90rpx;
				height: 60rpx;
				display: flex;
				justify-content: center;
				align-items: center;
				box-sizing: border-box;
			}

			.active {
				box-sizing: border-box;
				width: 90rpx;
				height: 60rpx;
				border-bottom: 4rpx solid #4794FF;
			}
		}
	}
</style>
