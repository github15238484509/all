<template>
	<view class="box">
		<view class="header">
			<view class="text">
				<view class="text-t">
					营业执照照片
				</view>
				<view class="text-b">
					<view>
						1、需文字清晰、边框完整、露出国徽
					</view>
					<view>
						2、拍复印件需加盖印章，可用有效特许证件代替
					</view>
				</view>
			</view>
			<u-upload :custom-btn="true" max-count="1" :action="action" :auto-upload="true" width="130rpx"
				height="130rpx" style="margin-right: 30rpx;" @on-success="getBusinessLicence">
				<view slot="addBtn" class="slot-btn" hover-class="slot-btn__hover" hover-stay-time="150">
					<image src="../../../static/upload.png" class="img"></image>
				</view>
			</u-upload>
			<!-- <upimgSingle upload_img_wh="width:130rpx;height:130rpx;" :upload_count='1' @change="getBusinessLicence" :url="$uptImgUrl" style="margin-right: 30rpx;"></upimgSingle> -->
		</view>
		<view class="header1">
			<view class="header1-l">
				法人代表/经营者
			</view>
			<view class="header1-r">
				<input class="uni-input" placeholder-style="font-size:26rpx" @input="onKeyInput"
					placeholder="请输入经营者真实姓名" />
			</view>
		</view>
		<view class="header2">
			<view class="header1-l">
				营业执照有效期
			</view>
			<view class="header-c">
				<image v-if="!isChang" src="../../../static/yuan.png" class="img" @tap="Change"></image>
				<image v-if="isChang" src="../../../static/yuan2.png" class="img" @tap="Change"></image>
				<view class="text">
					长期
				</view>
			</view>
			<view class="header-r" @tap="isShow">
				<view class="item">
					<view class="text" v-if="validDate==''">
						请选择
					</view>
					<view class="date" v-if="validDate!==''">
						{{validDate}}
					</view>
					<image src="../../../static/down.png" class="img"></image>
				</view>

			</view>
		</view>
		<view class="header" style="margin:20px 0">
			<view class="text">
				<view class="text-t">
					许可证照片<text class="red">*</text>
				</view>
				<view class="text-b">
					<view>
						1、需文字清晰、边框完整、露出国徽
					</view>
					<view>
						2、拍复印件需加盖印章，可用有效特许证件代替
					</view>
				</view>
			</view>
			<u-upload :custom-btn="true" max-count="1" :action="action" :auto-upload="true" width="130rpx"
				height="130rpx" style="margin-right: 30rpx;" @on-success="getLicence">
				<view slot="addBtn" class="slot-btn" hover-class="slot-btn__hover" hover-stay-time="150">
					<image src="../../../static/upload.png" class="img"></image>
				</view>
			</u-upload>
			<!-- <upimgSingle upload_img_wh="width:130rpx;height:130rpx;" :upload_count='1' @change="getLicence" :url="$uptImgUrl" style="margin-right: 30rpx;"></upimgSingle> -->
		</view>
		<view class="header">
			<view class="text">
				<view class="text-t">
					法人代表身份证人像面
				</view>
				<view class="text-b">
					<view>
						1、人像面需清晰
					</view>

				</view>
			</view>
			<u-upload :custom-btn="true" max-count="1" :action="action" :auto-upload="true" width="130rpx"
				height="130rpx" style="margin-right: 30rpx;" @on-success="getPortrait">
				<view slot="addBtn" class="slot-btn" hover-class="slot-btn__hover" hover-stay-time="150">
					<image src="../../../static/upload.png" class="img"></image>
				</view>
			</u-upload>
			<!-- <upimgSingle upload_img_wh="width:130rpx;height:130rpx;" :upload_count='1' @change="getPortrait" :url="$uptImgUrl" style="margin-right: 30rpx;"></upimgSingle> -->
		</view>
		<view class="header">
			<view class="text">
				<view class="text-t">
					法人代表身份证国徽面
				</view>
				<view class="text-b">
					<view>
						1、国徽面需清晰拍出有效期等文字信息
					</view>

				</view>
			</view>
			<u-upload :custom-btn="true" max-count="1" :action="action" :auto-upload="true" width="130rpx"
				height="130rpx" style="margin-right: 30rpx;" @on-success="getNationalEmblem">
				<view slot="addBtn" class="slot-btn" hover-class="slot-btn__hover" hover-stay-time="150">
					<image src="../../../static/upload.png" class="img"></image>
				</view>
			</u-upload>
			<!-- <upimgSingle upload_img_wh="width:130rpx;height:130rpx;" :upload_count='1' @change="getNationalEmblem" :url="$uptImgUrl" style="margin-right: 30rpx;"></upimgSingle> -->
		</view>
		<view class="header">
			<view class="text">
				<view class="text-t">
					法人代表手持身份证件照
				</view>
				<view class="text-b">
					<view>
						1、人像面需清晰拍出人物五官和文字信息
					</view>
					<view>
						2、不可自拍、不可只拍身份证
					</view>
				</view>
			</view>
			<u-upload :custom-btn="true" max-count="1" :action="action" :auto-upload="true" width="130rpx"
				height="130rpx" style="margin-right: 30rpx;" @on-success="getInHand">
				<view slot="addBtn" class="slot-btn" hover-class="slot-btn__hover" hover-stay-time="150">
					<image src="../../../static/upload.png" class="img"></image>
				</view>
			</u-upload>
			<!-- 			<upimgSingle upload_img_wh="width:130rpx;height:130rpx;" :upload_count='1' @change="getInHand" :url="$uptImgUrl" style="margin-right: 30rpx;"></upimgSingle> -->
		</view>
		<view class="btns">
			<u-button type="primary" class="btn-l" @click="open">提交</u-button>

		</view>
		<!-- 时间 -->
		<u-picker mode="time" v-model="show" :params="params" @confirm="getTime"></u-picker>
		<uni-popup ref="popup" type="center">
			<view class="dialog" style="width: 500rpx;">
				<view class="dia-t">
					请输入服务费比例
				</view>
				<view class="dia-c">
					<input class="ipt" maxlength="3" v-model="value" :type="type" placeholder="请输入" />
					<text>%</text>
				</view>
				<view class="red">
					提示：商家每成交一笔订单,平台将以该比例收取服务费
				</view>
				<view class="dia-f" @tap="close">
					确定
				</view>
			</view>
		</uni-popup>
	</view>
</template>

<script>
	import upimgSingle from "../../../components/upimgSingle.vue"
	import salesmanCenterApi from "../../../api/salesmanCenter/salesmanCenter.js"

	export default {
		components: {
			upimgSingle
		},
		data() {
			return {
				//真实姓名
				inputValue: '',
				//上传地址
				action: this.$uptImgUrl,
				//时间选择器
				params: {
					year: true,
					month: true,
					day: true,
					hour: false,
					minute: false,
					second: false,
					// 选择时间的时间戳
					timestamp: true,
				},
				// 时间遮罩层
				show: false,
				//服务费比例
				value: '',
				type: 'number',
				border: true,
				height: 70,
				//长期有效
				isChang: false,
				//有效期
				validDate: '',
				//营业执照
				businessLicence: '',
				//许可证
				licence: '',
				//人像
				portrait: '',
				//国徽
				nationalEmblem: '',
				//手持
				inHand: '',
				item: {},
				isLong: false,
				isSort: false

			};
		},
		onLoad(option) {
			const item = JSON.parse(decodeURIComponent(option.item));
			console.log(item)
			this.item = item


		},
		methods: {
			//input
			onKeyInput: function(event) {
				this.inputValue = event.target.value

			},

			//遮罩层
			open() {
				// 通过组件定义的ref调用uni-popup方法
				this.$refs.popup.open()
				// console.log(uni.getStorageSync('xxytoken'))


			},
			//遮罩层
			close() {
				//判断有效期
				let indate = ''
				if (this.isChang == true) {
					indate = '1'
				} else {
					indate = this.validDate
				}

				salesmanCenterApi.setTlement({
						token: uni.getStorageSync('xxytoken'),
						phone: this.item.phone,
						merchant_industry: this.item.industry,
						merchant_name: this.item.storeName,
						merchant_province: this.item.province,
						merchant_city: this.item.city,
						merchant_county: this.item.county,
						merchant_contacts: this.item.name,
						merchant_tel: this.item.merchant_tel,
						merchant_worktime_start: this.item.start,
						merchant_worktime_end: this.item.end,
						merchant_desp: this.item.desp,
						merchant_longitude: this.item.longitude,
						merchant_latitude: this.item.latitude,
						merchant_address: this.item.merchant_address,
						merchant_logo: this.item.merchant_logo,
						merchant_image: this.item.license_image,
						license_image: this.businessLicence,
						license_indate: indate,
						other_card: this.licence,
						real_name: this.inputValue,
						front_image: this.portrait,
						reverse_image: this.nationalEmblem,
						person_image: this.inHand,
						merchant_percent:this.value,
						video_pic: this.item.video_pic,
						video_url: this.item.video_url
					})
					.then(res => {
						console.log(res)
						uni.reLaunch({
							url: '/pages/agentCentre/auditing2/auditing2'
						});
					})
				this.$refs.popup.close()
				
			},
			//获取有效日期
			getTime(res) {
				// console.log(res)
				let day = res.day
				let month = res.month
				let year = res.year
				let str = `${year}-${month}-${day}`
				this.validDate = str
				this.isChang = false
			},
			// 获取营业执照
			getBusinessLicence(res) {

				this.businessLicence = res.result
				console.log(this.businessLicence)
			},
			//获取许可证
			getLicence(res) {
				this.licence = res.result
				console.log(this.licence)
			},
			// 获取人像
			getPortrait(res) {

				this.portrait = res.result
				console.log(this.portrait)
			},
			//获取国徽
			getNationalEmblem(res) {
				this.nationalEmblem = res.result
				console.log(this.nationalEmblem)
			},
			// 获取手持
			getInHand(res) {

				this.inHand = res.result
				console.log(this.inHand)
			},
			isShow() {
				this.show = !this.show
			},
			Change() {
				this.isChang = !this.isChang
				if (this.isChang == true) {
					this.validDate = ''
				}
			}




		}
	}
</script>
<style>
	page {
		height: 100%;
		background-color: #f5f5f5;
	}
</style>
<style lang="scss" scoped>
	.box {
		padding-bottom: 20rpx;

		.header {
			width: 750rpx;
			height: 200rpx;
			background: #FFFFFF;
			display: flex;
			justify-content: space-between;
			align-items: center;

			.text {
				margin-left: 30rpx;

				.text-t {
					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #333333;
					margin: 5rpx 0 20rpx;

					.red {
						color: #FD635E;
					}
				}

				.text-b {
					font-size: 22rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #999999;

				}

			}

			.img {
				// margin-right: 30rpx;
				width: 130rpx;
				height: 130rpx;
			}
		}

		.header1 {
			// width: 100%;
			height: 100rpx;
			display: flex;
			justify-content: space-between;
			align-items: center;
			background: #FFFFFF;
			margin-top: 2rpx;
			padding-left: 30rpx;

			.header1-l {
				font-size: 26rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #333333;

			}
		}

		.header2 {
			// width: 100%;
			height: 100rpx;
			display: flex;
			justify-content: flex-start;
			align-items: center;
			background: #FFFFFF;
			margin-top: 2rpx;
			padding-left: 30rpx;

			.header1-l {
				font-size: 26rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #333333;

			}

			.header-c {
				display: flex;
				justify-content: flex-start;
				margin-left: 120rpx;

				.img {
					width: 36rpx;
					height: 36rpx;
				}

				.text {
					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #333333;
					margin-left: 15rpx;
				}
			}

			.header-r {

				.item {
					display: flex;
					justify-content: flex-start;
					align-items: center;

					.text {
						font-size: 26rpx;
						font-family: PingFang SC;
						font-weight: 400;
						color: #999999;
						margin-right: 30rpx;
						margin-left: 150rpx;
					}

					.date {
						font-size: 26rpx;
						font-family: PingFang SC;
						font-weight: 400;
						color: #222222;
						margin-left: 100rpx;
						margin-right: 20rpx;
					}

					.img {
						width: 26rpx;
						height: 15rpx;
					}
				}
			}
		}

		.btns {
			display: flex;
			justify-content: space-around;
			margin-top: 160rpx;
			margin-bottom: 50rpx;

			.btn-l {
				width: 690rpx;
				height: 90rpx;
			}

		}
	}

	.dialog {
		width: 500rpx;
		height: 350rpx;
		background: #FFFFFF;
		border-radius: 10rpx;
		overflow: hidden;
		position: relative;

		.red {
			margin: 0 auto;
			width: 395rpx;
			height: 56rpx;
			font-size: 26rpx;
			font-family: PingFang SC;
			font-weight: 400;
			color: #FF4747;
		}

		.dia-t {

			font-size: 30rpx;
			font-family: PingFang SC;
			font-weight: 500;
			color: #333333;
			margin: 20rpx auto;
			text-align: center;



		}

		.dia-c {

			font-size: 26rpx;
			font-family: PingFang SC;
			font-weight: 400;
			color: #999999;
			margin: 0 28rpx;
			display: flex;
			justify-content: flex-start;
			align-items: center;

			.ipt {
				margin-left: 90rpx;
				width: 260rpx;
				height: 70rpx;
				margin-right: 15rpx;
				// margin-bottom: 25rpx;
			}

			.ddd {
				width: 419rpx;
				height: 157rpx;
				background: #F5F5F5;
				border: 1rpx solid #CCCCCC;
				border-radius: 10rpx;
				margin: 0 auto;
			}
		}

		.dia-f {
			width: 100%;
			height: 90rpx;

			font-size: 26rpx;
			font-family: PingFang SC;
			font-weight: 400;
			color: #4894FE;
			text-align: center;
			line-height: 90rpx;
			margin-top: 25rpx;
			border-top: 2rpx solid #f5f5f5;
			position: absolute;
			left: 0;
			bottom: 0;
		}

	}
</style>
