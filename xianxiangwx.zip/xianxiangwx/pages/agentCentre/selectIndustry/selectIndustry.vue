<template>
        <view style="padding: 0 30rpx;" >
                <view class="navgation" >入驻行业</view>
                <view style="display:flex;flex-wrap: wrap; justify-content: space-between;">
                        <view  :class="selectIndex ===item.scope_index?'dustry clickdustry ':'dustry'" v-for="(item,i) in dustryList" :key="item.scope_index" @click="selectDusty(item)">{{item.scope_name}}</view>
                </view>
                <view style="width: 100%;position: fixed;bottom: 130rpx;padding-right: 60rpx ;box-sizing: border-box;">
						 
                         <button type="primary" style="width: 100%;background-color: #4794FF;" @click="next">下一步</button>
						 
                </view>
        </view>
</template>

<script>
        import getselectInDustryApi from "../../../api/salesmanCenter/salesmanCenter.js"
        export default {
                data() {
                        return {
                                dustryList:{}, 
                                selectIndex:"",
								//电话
								phone:'',
								//行业
								trade:'',
								item:{}
                        }
                },
                onLoad(option){
                        getselectInDustryApi.getselectInDustry().then(res=>{
                                this.dustryList=res.result
                        }),
				       
						this.phone=option.phone
						   
                },
                methods: {
                        selectDusty(e){
                                this.selectIndex=e.scope_index;
								this.trade=e.scope_name;
								
                        },
						next(){
							// console.log(1)
							uni.redirectTo({
								url:`../shopEnter/shopEnter?phone=${this.phone}&trade=${this.selectIndex}`
							})
							// uni.navigateTo({
							// 	url:'../shopEnter/shopEnter?item='+ encodeURIComponent(JSON.stringify(this.item))
							// })
						}
                }
        }
</script>

<style scoped lang="scss">
        .navgation{
                height: 110rpx;
                line-height: 110rpx;
                font-size: 26rpx;
                font-family: HiraginoSansGB;
                font-weight: normal;
                color: #222222;
                border-bottom: 2rpx solid #F5F5F5;
        }
        .dustry{
                width: 216rpx;
                height:60rpx ;
                line-height:60rpx;
                text-align: center;
                margin-bottom:20rpx;
                background: rgba(153, 153, 153, 0.15);
                border-radius: 6rpx;
                font-size: 26rpx;
                font-family: PingFang SC;
                font-weight: 400;
                color: #999999;
        }
        .clickdustry{
                background: rgba(71, 148, 255, 0.15);
                border-radius: 6px;
                color: #4794FF;
                background-image: url(../../../static/buttonSelect.png);
                background-size:44rpx 44rpx;
                background-repeat:no-repeat;
                background-position:100% 100%;
        }
</style>
