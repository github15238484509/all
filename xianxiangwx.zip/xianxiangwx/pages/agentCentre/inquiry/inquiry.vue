<template>
	<view class="box">
		<view class="header2">
			<view class="header1-l">
				开始时间
			</view>
			
			<view class="header-r" @tap="show = true">
				<view class="item" >	
					<view class="text" v-if="startDate==''">
						请选择开始时间
					</view>
					<view class="date" v-if="startDate!==''">
						{{startDate}}
					</view>
					<image src="../../../static/down.png" class="img" ></image>
				</view>
				
			</view>
		</view>
		<view class="header2">
			<view class="header1-l">
				结束时间
			</view>
			
			<view class="header-r" @tap="show2 = true">
				<view class="item" >	
					<view class="text" v-if="endDate==''">
						请选择结束时间
					</view>
					<view class="date" v-if="endDate!==''">
						{{endDate}}
					</view>
					<image src="../../../static/down.png" class="img" ></image>
				</view>
				
			</view>
		</view>
	
		<u-button type="primary" class="btn" @tap="goto" >查询</u-button>
		
		<u-picker mode="time" v-model="show" :params="params" @confirm="getStime"></u-picker>
		<u-picker mode="time" v-model="show2" :params="params" @confirm="getEtime"></u-picker>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				show:false,
				show2:false,
				//时间选择器
				params: {
					year: true,
					month: true,
					day: true,
					hour: false,
					minute: false,
					second: false,
					// 选择时间的时间戳
					timestamp: true,
				},
				//开始日期
				startDate:'',
				//结束日期
				endDate:'',
			};
		},
		methods:{
			//获取开始日期
			getStime(res){
				// console.log(res)
				let day = res.day
				let month = res.month
				let year = res.year
				let str = `${year}-${month}-${day}`
				this.startDate=str
				this.start_time=res.timestamp
				
			},
			//获取结束日期
			getEtime(res){
				// console.log(res)
				let day = res.day
				let month = res.month
				let year = res.year
				let str = `${year}-${month}-${day}`
				this.endDate=str
				this.end_time=res.timestamp
				// console.log(this.endDate)
				
			},
			goto(){
				
				uni.redirectTo({
				    url: '../details/details?start_time='+this.start_time+`&end_time=`+this.end_time
				});
			}
		}
	}
</script>
<style>
	page{
		height: 100%;
	}
</style>
<style lang="scss" scoped>
.box{
	.header2 {
		// width: 100%;
		height: 100rpx;
		display: flex;
		justify-content: flex-start;
		align-items: center;
		background: #FFFFFF;
		margin-top: 2rpx;
		padding-left: 30rpx;
	
		.header1-l {
			font-size: 26rpx;
			font-family: PingFang SC;
			font-weight: 400;
			color: #333333;
	
		}
	
		.header-c {
			display: flex;
			justify-content: flex-start;
			margin-left: 120rpx;
	
			.img {
				width: 36rpx;
				height: 36rpx;
			}
	
			.text {
				font-size: 26rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #333333;
				margin-left: 15rpx;
			}
		}
	
		.header-r {
			
			.item{
			display: flex;
			justify-content: flex-start;
			align-items: center;
				
				.text {
				font-size: 26rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #999999;
				margin-right: 30rpx;
				margin-left: 300rpx;
				}
				.date{
					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #222222;
					margin-left: 338rpx;
					margin-right: 30rpx;
				}
				.img {
				width: 26rpx;
				height: 15rpx;
				}
			}
		}
	}
}
.btn{
	margin-top: 200rpx;
}
</style>

