<!-- 领取成功页面 -->
<template>
	<view>
		<view class="one">
			<image :src="cdnUrl+'bashi/image/moneySc.png'"></image>
			<view>提现申请提交成功</view>
		</view>
		<view class="check" @click="examine()">返回我的余额</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				money:'',
				cdnUrl:'',
			}
		},
		methods: {
			// 转跳到门店页面
			examine(){
				uni.navigateBack({
					delta:2
				})
			},
		},
		onShareAppMessage: function () {
		    return {
		      title:'乃小星',
		      path: '/pages/index/index?scene=' + '1-'+uni.getStorageSync('phone')
		    }
		},
		onLoad(options){
			this.money=options.money
			this.cdnUrl=this.$cdnUrl
		}
	}
</script>

<style>
.one{
	text-align: center;
	font-size: 30rpx;
	font-family: PingFang SC;
	font-weight: 500;
	color: #343434;
	padding-top: 150rpx;
}
.one image {
	width: 146rpx;
	height: 185rpx;
	padding-bottom: 50rpx;
}
.check {
	width: 690rpx;
	height: 90rpx;
	background: #3EA4E1;
	border-radius: 45rpx;
	line-height: 90rpx;
	text-align: center;
	font-size: 30rpx;
	font-family: PingFang SC;
	font-weight: 500;
	color: #FFFFFF;
	margin: 50rpx 30rpx;
}
</style>

