<!-- 绑定银行卡页面 -->
<template>
	<view style="height:100%" >
		<view class="pages" v-if="pageshow==1">
			<view style="padding: 0 30rpx;" class="bindCard" >
				<view class="content" @click="showModel">
					<view class="">请选择开户行</view>
					<view class="">
						{{value}}
					</view>
				</view>
				<view class="content">
					<view class="">开户人姓名</view>
					<view class="">
						<input type="text" value="" placeholder="请输入开户人姓名" @input="getName"/>
					</view>
				</view>
				<view class="content">
					<view class="">银行卡账号</view>
					<view class="">
						<input type="number" value="" placeholder="请输入银行卡账号" @input="getNum"/>
					</view>
				</view>
				<view class="content">
					<view class="">确认银行卡账号</view>
					<view class="">
						<input type="number" value="" placeholder="请再次输入银行卡账号"  @input="getNum1"/>
					</view>
				</view>
			</view>
			<view class="sureBind" @click="confirm">
				立即绑定
			</view>
		</view> 
		
		<view  class="pages1" v-else>
			<view class="cardMsg">
				<view class="">
					<image :src="cdnUrl+cardMsg.cardLogo" mode=""></image>
				</view>
				<view class="card_word">
					<view class="card_name">
						{{cardMsg.bank_full_name}}
					</view>
					<view class="card_type">
						储蓄卡
					</view>
					<view class="card_num">
						{{cardMsg.card_number}}
					</view>
				</view>
			</view>
			<!-- <view class="link">
				
			</view> -->
			<button type="default" class="link" plain="true" open-type="contact">更换银行卡请联系客服</button>
		</view>
		<view class="chooseModel" v-if="visible" @click="cancel_choose">
			<view class="showModel" >
				<picker-view    @change="bindChange">
				    <picker-view-column>
				        <view class="item" v-for="(item,i) in cardList" :key="i">{{item.text}}</view>
				    </picker-view-column>
				</picker-view>
				<view class="btns">
					<view class="sure" @click="cancel_choose">
						取消
					</view>
					<view class="cancel" @click="sure_choose">
						确定
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default{
		data(){
			return{
				cdnUrl:'',
				bind:true,
				visible:false,
				render:false,//网络是否请求成功
				value:'请选择',//显示的开户行
				cardList:[],
				showChange:false,
				cardName:'',//传的开户行
				name:'',//开户人姓名
				num:'',//银行卡账号
				num1:'',//确认银行卡账号
				cardMsg:{},
				pageshow:"",
			}
		},
		// 这个方法设置该页面是否可以转发
		// onShareAppMessage: function () {
		//     return {
		//       title:'乃小星',
		//       path: '/pages/index/index?scene=' + '1-'+uni.getStorageSync('phone')
		//     }
		// },
		onLoad(e){
			this.pageshow=e.id
		},
		methods:{
			//获取银行卡
			// getCard(){
			// 	let self = this
			// 	self.request({
			// 		url:'bashi/api/app.php?c=card/user_bank_list',
			// 		data:{
			// 			token:uni.getStorageSync('token')
			// 		}
			// 	}).then(res=>{
			// 		 if(res.data.success){
			// 			if(res.data.data.length==0){
			// 				self.bind = true
			// 				uni.setNavigationBarTitle({
			// 				    title: '绑定银行卡'
			// 				});
			// 				self.getCardName()
			// 			}else{
			// 				uni.setNavigationBarTitle({
			// 				    title: '我的银行卡'
			// 				});
			// 				self.bind = false
			// 				self.cardMsg = res.data.data[0]
			// 				self.cardMsg.card_number=self.cardMsg.card_number.replace(/(\d{4})\d+(\d{3})$/, "$1 **** **** **** $2")
			// 			}
			// 			self.render =true;
			// 		  } 
			// 	},rej=>{
			// 		console.log(rej)
			// 	})
			// },
			// getCardName(){
			// 	let self = this
			// 	self.request({
			// 		url:'bashi/api/app.php?c=card/getBankList',
			// 		data:{
			// 			token:uni.getStorageSync('token')
			// 		}
			// 	}).then(res=>{
			// 		 if(res.data.success){
			// 			self.cardList=res.data.data
			// 		  } 
			// 	},rej=>{
			// 		console.log(rej)
			// 	})
			// },
			// showModel(){
			// 	this.visible = true
			// 	this.showChange = false
			// },
			// cancel_choose(){
			// 	this.visible = false
			// 	this.showChange = false
			// },
			// bindChange(e){
			// 	let i = e.detail.value[0]
			// 	this.cardName=this.cardList[i].text
			// 	this.showChange = true
			// },
			// getName(e){
			// 	this.name=e.detail.value
			// },
			// getNum(e){
			// 	this.num=e.detail.value
			// },
			// getNum1(e){
			// 	this.num1=e.detail.value
			// },
			// sure_choose(){
			// 	this.visible=false
			// 	if(this.showChange == false){
			// 		this.value=this.cardList[0].text
			// 		this.cardName=this.cardList[0].text
			// 	}else{
			// 		this.value=this.cardName
			// 	}
			// 	console.log(this.cardName);
			// },
			// confirm(){
			// 	let self = this
			// 	if(self.cardName == ''){
			// 		uni.showToast({
			// 			icon:'none',
			// 			title:'请选择开户行'
			// 		})
			// 	}else if(self.name==''){
			// 		uni.showToast({
			// 			icon:'none',
			// 			title:'请输入开户人姓名'
			// 		})
			// 	}else if(self.num == ''){
			// 		uni.showToast({
			// 			icon:'none',
			// 			title:'请输入银行卡账号'
			// 		})
			// 	}else if(self.num1==''){
			// 		uni.showToast({
			// 			icon:'none',
			// 			title:'请再次输入银行卡账号'
			// 		})
			// 	}else if(this.num1!=this.num){
			// 		uni.showToast({
			// 			icon:'none',
			// 			title:'两次输入的银行卡账号不一致'
			// 		})
			// 	}else{
			// 		self.request({
			// 			url:'bashi/api/app.php?c=card/submitBankCard',
			// 			data:{
			// 				token:uni.getStorageSync('token'),
			// 				card_holder:self.name,
			// 				card_number:self.num,
			// 				card_bank:self.cardName
			// 			}
			// 		}).then(res=>{
			// 			 if(res.data.success){
			// 				uni.showToast({
			// 					title:res.data.msg
			// 				})
			// 				self.bind=false
			// 				self.getCard()
			// 			  }else{
			// 				uni.showToast({
			// 				  	title:res.data.msg
			// 				})
			// 			  }
			// 		},rej=>{
			// 			console.log(rej)
			// 		})
			// 	}
			// }
		},
		onShow() {
			// this.cdnUrl=this.$cdnUrl
		},
		created(){
			// this.getCard()
		}
	}
</script>

<style lang="scss">
	page{
		height: 100%;
	}
	.pages{
		background-color: #f5f5f5;
	}
	.pages1{
		width: 100%;
		height: 100%;
		background-color: #333333;
		padding-top: 30rpx;
		box-sizing: border-box;
	}
	.bindCard{
		background-color: #fff;
	}
	.content{
		padding: 30rpx 0;
		border-bottom: 1rpx solid #f5f5f5;
		display: flex;
		justify-content: space-between;
		font-size:26rpx;
		font-family:PingFang SC;
		font-weight:500;
		color:rgba(51,51,51,1);
		input{
			text-align: right;
		}
		image{
			width:17rpx;
			height:32rpx;
			vertical-align: middle;
			margin-left: 20rpx;
		}
	}
	.sureBind{
		width: 690rpx;
		height: 90rpx;
		background: #3EA4E1;
		border-radius: 45rpx;
		margin: 50rpx 30rpx 0;
		line-height: 90rpx;
		text-align: center;
		color: #fff;
		font-size: 30rpx;
	}
	.chooseModel{
		width: 100%;
		height: 100%;
		position: fixed;
		bottom: 0;
		left: 0;
		background-color: rgba(0,0,0,.5);
		z-index: 22;
		.showModel {
			width: 100%;
			height: 700rpx;
			position: absolute;
			bottom: 0;
			left: 0;
			z-index: 111111;
			background-color: #fff;
			border-radius: 10rpx 0 0 10rpx;
			picker-view{
				width: 100%;
				height: 600rpx;
			}
			.item {
				line-height: 34px;
				text-align: center;
			}
			.btns{
				display: flex;
				view{
					width: 50%;
					height: 100rpx;
					line-height: 100rpx;
					text-align: center;
				}
			}
			.sure{
				border-right: 1rpx solid #f5f5f5;
			}
		}
	}
	.cardMsg{
		width: 690rpx;
		height: 204rpx;
		background: #FFFFFF;
		border-radius: 15rpx;
		margin: 0 30rpx;
		display: flex;
		padding-top:38rpx;
		box-sizing: border-box;
		image{
			width: 66rpx;
			height: 66rpx;
			margin: 0 20rpx 0 80rpx;
		}
		.card_name{
			font-size: 30rpx;
			font-family: PingFang SC;
			font-weight: 400;
			color: #333333;
		}
		.card_type{
			font-size: 24rpx;
			font-family: PingFang SC;
			font-weight: 400;
			color: #999;
			margin: 5rpx 0 10rpx;
		}
		.card_num{
			font-size: 36rpx;
			font-family: PingFang SC;
			font-weight: 400;
			color: #333333;
		}
	}
	.link{
		text-align: center;
		margin-top: 100rpx;
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #FFFFFF!important;
		border: none!important; 
	}
</style>
