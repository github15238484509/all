<template>
	<!-- 总体 -->
	<view class="Trade">
		<view class="searchstyle" >
			<view class="searchInput" style="padding-left:30rpx;">
				<view style="width: 100%;height:70rpx;display: flex;align-items: center;justify-content: space-between;">
					<img src="../../../static/search.png" alt="" style="width: 32rpx;height: 32rpx;margin: 0 20rpx;">
					<input  type="text" placeholder="请输入商品名称" v-model="searchValue" class="fontsmall" style="color:#FFFFFF;opacity: 0.6;flex-grow: 1;" placeholder-style="color:#FFFFFF;opacity: 0.6;">
					<view class="searchButton" style="" @click="searchGood">搜索</view>
				</view>
<!-- 				<u-search shape="square" placeholder="请输入搜索内容" placeholder-color="#FFFFFF"
				 v-model="keyword"  bg-color="none" search-icon-color=" #FFFFFF" ></u-search> -->
			</view>
		</view>
		<!-- 导航栏 -->
		<view class="navgation fontstyle" style="position: fixed;top:90rpx;width: 100%;background-color: #FFFFFF;">
			<!-- 三元运算 -->
			<view :class="nav===index?'active':''" v-for="(item,index) in tileList" :key="index" @click="select(index)">
				{{item.title}}
			</view>
		</view>
		<!-- 待审核 -->
		<view style="margin-top: 200rpx;">
			<view v-if="nav==0&&goodsListGet.data.length>0">
				<view class="Tradeshow" v-for="(item,index) in goodsListGet.data" :key="item.goods_index">
					<view>
						<img :src="$imgUrl(item.goods_icon)" alt=""
							style="height: 276rpx;width: 100%;border-radius: 10rpx 10rpx 0 0;" mode="scaleToFill">
					</view>
					<view class="fontstyle-Bold" style="margin: 21rpx;">
						{{item.goods_name}}
					</view>
					<view style="margin: 20rpx;">
						<span class="fontbig">￥{{$returnFloat(item.stage)}}</span><span class="fontsmall" v-if="item.goods_type!='0'">X{{item.goods_type}}期</span>
						<span class="font" v-if="item.goods_type!='0'">￥{{$returnFloat(item.goods_cost)}}</span>
					</view>
					<view class="bottomBar">
						<!-- :class="btn===item&&btn1==index1?'bottomBarIteam':''" -->
						<!-- <view  v-for="(item1,index) in buttonList" @click="selectBtn(index)" :key="item1">{{item1.title}}</view> -->
						<view @click="selectExamine(item)" style="width: 100%;border-radius:10rpx;">查看并审核</view>
					</view>
				</view>
			</view>
			<view v-if="nav==0&&goodsListGet.data.length==0"  style="text-align: center;margin-top: 300rpx;"> <img :src="cdnUrl+'XianxiangUapi/static/datanull.png'" alt="" style="width: 480rpx;height: 360rpx;"></view>
		</view>

		<!-- 已通过 -->
		<view style="margin-top: 200rpx;">
			<view v-if="nav==1&&goodsListGet.data.length>0">
				<view class="Tradeshow"  v-for="(item,index) in goodsListGet.data" :key="item.goods_index">
					<view>
						<img :src="$imgUrl(item.goods_icon)" alt=""
							style="height: 276rpx;width: 100%;border-radius: 10rpx 10rpx 0 0;" mode="scaleToFill">
					</view>
					<view class="fontstyle-Bold" style="margin: 21rpx;">
						{{item.goods_name}}
					</view>
					<view style="margin: 20rpx;">
						<span class="fontbig">￥{{$returnFloat(item.stage)}}</span><span class="fontsmall" v-if="item.goods_type!='0'">X{{item.goods_type}}期</span>
						<span class="font" v-if="item.goods_type!='0'">￥{{$returnFloat(item.goods_cost)}}</span>
					</view>
					<view class="bottomRefuse">
						<view @click="selectExamine(item)">查看</view>
					</view>
				</view>
			</view>
	<view v-if="nav==1&&goodsListGet.data.length==0"  style="text-align: center;margin-top: 300rpx;"> <img :src="cdnUrl+'XianxiangUapi/static/datanull.png'" alt="" style="width: 480rpx;height: 360rpx;"></view>
		</view>
		
		<!-- 已拒绝 -->
		<view style="margin-top: 200rpx;">
			<view v-if="nav==2&&goodsListGet.data.length>0">
				<view class="Tradeshow" v-for="(item,index) in goodsListGet.data" :key="item.goods_index">
						<view>
							<img :src="$imgUrl(item.goods_icon)" alt=""
								style="height: 276rpx;width: 100%;border-radius: 10rpx 10rpx 0 0;" mode="scaleToFill">
						</view>
						<view class="fontstyle-Bold" style="margin: 21rpx;">
							{{item.goods_name}}
						</view>
						<view style="margin: 20rpx;">
							<span class="fontbig">￥{{$returnFloat(item.stage)}}</span><span class="fontsmall" v-if="item.goods_type!='0'">X{{item.goods_type}}期</span>
							<span class="font" v-if="item.goods_type!='0'">￥{{$returnFloat(item.goods_cost)}}</span>
						</view>
						<view class="bottomRefuse">
							<u-modal v-model="show" :content="content" title="拒绝原因"></u-modal>
							<view @click="selectExamine(item)">查看</view>
						</view>
					</view>
				</view>
				<view v-if="nav==2&&goodsListGet.data.length==0" style="text-align: center;margin-top: 300rpx;"> <img :src="cdnUrl+'XianxiangUapi/static/datanull.png'" alt="" style="width: 480rpx;height: 360rpx;"></view>
			</view>
			
	</view>

</template>

<script>
	import agentBusunessApi from "../../../api/agentCenter/agentCenter.js"
	export default {
		data() {
			return {
                cdnUrl:"",
				// 搜索框的值
				searchValue:"",
				merchantId: "",
				show: false,
				content: '',
				// 导航栏状态
				tileList: [{
						id: '1',
						title: "待审核"
					},
					{
						id: '2',
						title: "已通过"
					},
					{
						id: '3',
						title: "已拒绝"
					}
				],
				// 用于判断导航栏当前处于什么状态
				nav: 0,
				// 用于判断按钮当前处于什么状态
				btn: 0,
				btn1: {},
				// 接收返回的商户商品信息
				goodsListGet: {
					data: [],
				},
				// 商品当前页面数
				pageIndex: 1,
				// 商户商品列表请求需要的参数
				goodsListPos: {
					token: "",
					type: "1",
					page: "1",
					count: "10",
					goods_name:""
				},
				// 用户的token值
				token: "",
				// 商品详情需要的参数
				goods_id: "",
				showModalContent: "您确定要下架该商品吗?",
				keyword:""

			}
		},
		// 进入界面加载前执行的函数
		onLoad(e) {
            this.cdnUrl=this.$cdnUrl
			// 获取用户登录时存储在本地的token值
			this.token = uni.getStorageSync('xxytoken');
			console.log(this.token)
			this.goodsListPos.token=this.token
			// this.merchantId = e.id
			// 调用APi得到商品信息
			// this.ajax(this.goodsListPos);
		},
		//页面展示时
		onShow(){
			this.goodsListGet.data = [];
			this.ajax(this.goodsListPos);
		},
		// 滚动页面时执行的方法
		onReachBottom() {
			this.goodsListPos.goods_name=this.searchValue
			if (this.pageIndex < this.goodsListGet.last_page) {
				this.goodsListPos.page = ++this.pageIndex;
				console.log(this.goodsListPos)
				this.ajax(this.goodsListPos)
			} else {
				console.log(this.goodsListGet.data)
			}
		},
		methods: {
			searchGood(){
				this.goodsListGet={data:[]}
				this.goodsListPos.goods_name=this.searchValue
				this.ajax()
			},
			// 切换至点击的导航栏
			select(index) {
				this.searchValue=""
				this.goodsListPos.goods_name=""
				this.nav = index;
				this.goodsListPos.type = ++index;
				console.log(this.goodsListPos.type)
				this.goodsListGet = {
					data: []
				};
				this.goodsListPos.page = 1;
				this.pageIndex = 1;
				this.ajax();
			},
			// 跳转至查看审核商户商品详情
			selectExamine(e){
				console.log(1111)
				uni.navigateTo({
					url:"../shopGoods/shopGoods?id="+e.goods_index
				})
			},
			
			// 调用商品信息接口
			ajax() {
				agentBusunessApi.getAgentGoodsDetail(this.goodsListPos).then(res => {
					if (res.status == 200&&res.result!=undefined) {
						if (this.goodsListGet.data.length > 0) {
							this.goodsListGet.data = [...this.goodsListGet.data, ...res.result.data];
						} else {
							this.goodsListGet = res.result;
							console.log(this.goodsListGet.data)
						}
					} else {}
				})
			}
		}
	}
</script>

<style scoped>
	.searchButton{
		width: 120rpx;
		height: 60rpx;
		line-height: 60rpx;
		text-align: center;
		background-color: #4794FF;
		border-radius: 10rpx;
		margin-right: 5rpx;
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: bold;
		color: #FFFFFF;
	}
	.Trade{
		overflow: hidden;
	}
	.searchInput{
		margin: 0 30rpx;
		width: 100%;
		border-radius: 10rpx;
		background-color: rgba(245, 245, 245, 0.5);
	}
	.searchstyle{
		height: 90rpx;
		position: fixed;
		top:0rpx;
		width: 100%;
		background-color: #4794FF; 
		display: flex;
		justify-content: center;
		align-items: center;
	}
	
	.font {
		margin-left: 20rpx;
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 400;
		text-decoration: line-through;
		color: #999999;

	}

	.fontsmall {
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #85B8FF;
	}

	.fontbig {
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #4794FF;

	}

	.navgation {
		display: flex;
		justify-content: space-around;
	}

	.navgation>view {
		text-align: center;
		height: 90rpx;
		line-height: 90rpx;
	}

	.fontstyle {
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #333333;
	}

	.fontstyle-Bold {
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #333333;
	}

	.active {
		border-bottom: 4rpx solid #4794FF;
		font-size: 30rpx;
		color: #4794FF;
	}

	.Tradeshow {
		margin: 30rpx;
		border-radius: 10rpx;
	}

	.bottomBar {
		background-color: #3699FF;
		display: flex;
		height: 90rpx;
		line-height: 90rpx;
		text-align: center;
		justify-content: space-between;
	}

	.bottomBar>view {
		width: 50%;
		height: 90rpx;
		line-height: 90rpx;
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #FFFFFF;
		background-color: #3699FF;
	}

	.bottomRefuse {
		height: 90rpx;
		line-height: 90rpx;
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #FFFFFF;
		background-color: #3699FF;
		text-align: center;
	}

	.navgat {
		height: 28px;
		font-size: 30px;
		font-family: PingFang SC;
		color: #FFFFFF;
	}
</style>

