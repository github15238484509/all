<template>
	<view class="box">
		<view class="header">
			<view class="searchInput" style="padding-left:30rpx;">
				<view style="width: 100%;height:70rpx;display: flex;align-items: center;justify-content: space-between;">
					<image src="../../../static/search.png"  style="width: 32rpx;height: 32rpx;margin: 0 20rpx;z-index: 10;"></image>
					<input  type="text" placeholder="请输入查询商家店铺名称" v-model="searchValue" class="fontsmall" style="color:#FFFFFF;opacity: 0.6;flex-grow: 1;" placeholder-style="color:#FFFFFF;opacity: 0.6;font-size: 26rpx;">
					<view class="searchButton" @click="searchShop"><text>搜索</text></view>
				</view>
				
			</view>

		</view>

		<view class="nav">
			<u-sticky :enable="enable">
				<div class="content-nav">
					<div class="nav-item" :class="{active: current=='0'}" @tap="currentChange('0')">
						<text class="text">已录入</text>
					</div>
					<div class="nav-item" :class="{active: current=='1'}" @tap="currentChange('1')">
						<text class="text">即将到期</text>
					</div>
					<div class="nav-item" :class="{active: current=='2'}" @tap="currentChange('2')">
						<text class="text">已到期</text>
					</div>
					<div class="nav-item" :class="{active: current=='3'}" @tap="currentChange('3')">
						<text class="text">待审核</text>
					</div>
					<div class="nav-item" :class="{active: current=='4'}" @tap="currentChange('4')">
						<text class="text">待平台审核</text>
					</div>
				</div>
			</u-sticky>
		</view>
		<div v-show="current == 0" class="content">
			<view v-if="shopList.data.length>0">
			<view class="score-item"  v-for="item in shopList.data" :key="item.merchant_id" @tap="go(item)">
				<view class="left1">
					<image :src="$imgUrl(item.merchant_logo)" mode="aspectFill"></image>
				</view>
				<view class="right1">
					<view class="rline1">
						{{item.merchant_name}}
						<image src="../../../static/phone1.png" class="img" @click.stop="makePhone(item.merchant_tel)"></image>
					</view>
					<view class="rline2">
						{{item.merchant_address}}
					</view>
					<view class="rline3">
						<image src="/static/time.png" mode="aspectFill"></image>
						<text class="line-txt">{{item.merchant_worktime_start}}-{{item.merchant_worktime_end}}</text>
					</view>
					<view class="rline4">
			
						<text class="line-txt">年费到期时间:{{DateToStr(item.expire_time)}}</text>
					</view>
				</view>
				<view>
					<view class="bottom" v-if="item.referrer_rank==2">
						<text>业务员：</text>
						<image :src="$imgUrl(item.referrer_photo)" class="img"></image>
						<text class="name">{{item.referrer_name}}</text>
						<text v-if="item.referrer_phone!=''">({{item.referrer_phone}})</text>
					</view>
					<view class="bottomview" v-else></view>
				</view>
			</view>
			</view>
			<view v-else style="text-align: center;margin-top: 200rpx;"><img :src="cdnUrl+'XianxiangUapi/static/datanull.png'" alt="" style="width: 480rpx;height: 360rpx;"></view>
		</div>
		<div v-show="current == 1" class="content">
			<view v-if="shopList.data.length>0">
				<view class="score-item" v-for="item in shopList.data" :key="item.merchant_id" @tap="go(item)">
					<view class="left1">
						<image :src="$imgUrl(item.merchant_logo)" mode="aspectFill"></image>
					</view>
					<view class="right1">
						<view class="rline1">
							{{item.merchant_name}}
							<image src="../../../static/phone1.png" class="img" @click.stop="makePhone(item.merchant_tel)"></image>
						</view>
						<view class="rline2">
							{{item.merchant_address}}
						</view>
						<view class="rline3">
							<image src="/static/time.png" mode="aspectFill"></image>
							<text class="line-txt">{{item.merchant_worktime_start}}-{{item.merchant_worktime_end}}</text>
						</view> 
						<view class="rline4">
				
							<text class="line-txt" style="color: red;">年费到期时间:{{DateToStr(item.expire_time)}}</text>
						</view>
					</view>
					<view>
						<view class="bottom"  v-if="item.referrer_rank==2">
							<text>业务员：</text>
							<image :src="$imgUrl(item.referrer_photo)" class="img"></image>
							<text class="name">{{item.referrer_name}}</text>
							<text v-if="item.referrer_phone!=''">({{item.referrer_phone}})</text>
						</view>
						<view class="bottomview" v-else></view>
					</view>
				</view>
			</view>
			<view v-else style="text-align: center;margin-top: 200rpx;"><img :src="cdnUrl+'XianxiangUapi/static/datanull.png'" alt="" style="width: 480rpx;height: 360rpx;"></view>
		</div>
		<div v-show="current == 2" class="content">
			<view v-if="shopList.data.length>0">
				<view class="score-item" v-for="item in shopList.data" :key="item.merchant_id" @tap="go(item)">
					<view class="left1">
						<image :src="$imgUrl(item.merchant_logo)" mode="aspectFill"></image>
					</view>
					<view class="right1">
						<view class="rline1">
							{{item.merchant_name}}
							<image src="../../../static/phone1.png" class="img" @click.stop="makePhone(item.merchant_tel)"></image>
						</view>
						<view class="rline2">
							{{item.merchant_address}}
						</view>
						<view class="rline3">
							<image src="/static/time.png" mode="aspectFill"></image>
							<text class="line-txt">{{item.merchant_worktime_start}}-{{item.merchant_worktime_end}}</text>
						</view>
						<view class="rline4">
							<text  class="line-txt" style="color:red;">年费到期时间:{{DateToStr(item.expire_time)}}</text>
						</view>
					</view>
					<view>
						<view class="bottom"  v-if="item.referrer_rank==2">
							<text>业务员：</text>
							<image :src="$imgUrl(item.referrer_photo)" class="img"></image>
							<text class="name">{{item.referrer_name}}</text>
							<text v-if="item.referrer_phone!=''">({{item.referrer_phone}})</text>
						</view>
						<view class="bottomview" v-else></view>
					</view>
				</view>
			</view>
				<view v-else style="text-align: center;margin-top: 200rpx;"><img :src="cdnUrl+'XianxiangUapi/static/datanull.png'" alt="" style="width: 480rpx;height: 360rpx;"></view>
		</div>
		<div v-show="current == 3" class="content">
			<view v-if="shopList.data.length>0">
				<view class="score-item" v-for="item in shopList.data" :key="item.merchant_id" @tap="go3(item)">
					<view class="left1">
						<image :src="$imgUrl(item.merchant_logo)" mode="aspectFill"></image>
					</view>
					<view class="right1">
						<view class="rline1">
							{{item.merchant_name}}
							<image  src="../../../static/phone1.png"  class="img" @click.stop="makePhone(item.merchant_tel)"></image>
						</view>
						<view class="rline2">
							{{item.merchant_address}}
						</view>
						<view class="rline3">
							<image src="/static/time.png" mode="aspectFill"></image>
							<text class="line-txt">{{item.merchant_worktime_start}}-{{item.merchant_worktime_end}}</text>
						</view>
						<view class="rline4">
				
							<!-- <text v-if="item.merchant_status==1" class="line-txt">审核中</text>
							<view class="refuse" v-if="item.merchant_status==4">
								<view class="fff">
									审核驳回
								</view>
								<view class="ml">
									点击查看原因>>
								</view>
							</view> -->
						</view>
					</view>
					<view>
						<view class="bottom"  v-if="item.referrer_rank==2">
							<text>业务员：</text>
							<image :src="$imgUrl(item.referrer_photo)" class="img"></image>
							<text class="name">{{item.referrer_name}}</text>
							<text v-if="item.referrer_phone!=''">({{item.referrer_phone}})</text>
						</view>
						<view class="bottomview" v-else></view>
					</view>
				</view>
			</view>
		<view v-else style="text-align: center;margin-top: 200rpx;"><img :src="cdnUrl+'XianxiangUapi/static/datanull.png'" alt="" style="width: 480rpx;height: 360rpx;"></view>
		</div>
		<div v-show="current == 4" class="content">
			<view v-if="shopList.data.length>0">
				<view class="score-item" v-for="item in shopList.data" :key="item.merchant_id" @tap="go4(item)">
					<view class="left1">
						<image :src="$imgUrl(item.merchant_logo)" mode="aspectFill"></image>
					</view>
					<view class="right1">
						<view class="rline1">
							{{item.merchant_name}}
							<image  src="../../../static/phone1.png"  class="img" @click.stop="makePhone(item.merchant_tel)"></image>
						</view>
						<view class="rline2">
							{{item.merchant_address}}
						</view>
						<view class="rline3">
							<image src="/static/time.png" mode="aspectFill"></image>
							<text class="line-txt">{{item.merchant_worktime_start}}-{{item.merchant_worktime_end}}</text>
						</view>
						<view class="rline4">
				
							<!-- <text v-if="item.merchant_status==1" class="line-txt">审核中</text>
							<view class="refuse" v-if="item.merchant_status==4">
								<view class="fff">
									审核驳回
								</view>
								<view class="ml">
									点击查看原因>>
								</view>
							</view> -->
						</view>
					</view>
					<view>
						<view class="bottom" v-if="item.referrer_rank==2">
							<text>业务员</text>
							<image :src="$imgUrl(item.referrer_photo)" class="img"></image>
							<text class="name">{{item.referrer_name}}</text>
							<text v-if="item.referrer_phone!=''">({{item.referrer_phone}})</text>
						</view>
						<view class="bottomview" v-else></view>
					</view>
				</view>
			</view>
			<view v-else style="text-align: center;margin-top: 200rpx;"><img :src="cdnUrl+'XianxiangUapi/static/datanull.png'" alt="" style="width: 480rpx;height: 360rpx;"></view>
		</div>

		<!-- <navigator url="./addSeller/addSeller" hover-class="navigator-hover" class="footer">
			<view class="add">
				<image src="../../../static/add1.png" class="img"></image>
				<text>录入商家</text>
			</view>
		</navigator>
		<uni-popup ref="popup" type="center">
			<view class="dialog">
				<view class="dia-t">
					<view class="title">
						代理商信息
					</view>
					<image src="../../../static/close.png" class="img" @tap="close"></image>
				</view>
				<view class="dia-c">
					<view class="pic">
						<view class="text">
							用户头像：
						</view>
						<image :src="obj.photo" class="img"></image>
					</view>
					<view class="name">
						用户昵称：{{obj.name}}
					</view>
					<view class="level">
						<view>
							等
						</view>
						<view class="text">

							级：代理商
						</view>
					</view>
					<view class="phone">
						<text>
							手 机 号：
						</text>

						<text class="blue">
							{{obj.phone}}
						</text>
						<image src="../../../static/phone1.png" class="img"></image>
					</view>
				</view>
			</view>
		</uni-popup> -->
	</view>
</template>

<script>
	import salesmanCenter from "../../../api/salesmanCenter/salesmanCenter.js"
	import login from "../../../api/login/login.js"
	export default {
		data() {
			return {
                cdnUrl:"",
				//激活的tab栏
				current: '0',
				// 用户电话
				userPhone: "",

				//商家列表
				shopList: {
					data:[]
				},
				//input
				value: '',
				border: false,
				enable: true,
				// 请求列表的页数
				pageIndex:"1"
			}
		},
		onLoad(e) {
			// salesmanCenter.getMerchant({
			// 	token:uni.getStorageSync('xxytoken'),
			// 	type:'1'
			// })
			// .then(res=>{
			// 	console.log(res)
			// })	
			// console.log(uni.getStorageSync('xxytoken'))
            this.cdnUrl=this.$cdnUrl
			console.log(e)
			this.userPhone = e.userPhone
			//tab栏
		},
		onReachBottom(){
			if(this.pageIndex<this.shopList.last_page){
				++this.pageIndex
				this.init()
			}else{
				uni.showToast({
					title:"没有更多了",
					icon:"none"
				})
			}
		},
		// 在对应的show和hide页面生命周期中打开或关闭监听
		onShow() {
			this.enable = true
			this.currentChange(0)
		},
		onHide() {
			this.enable = false
		},
		methods: {
			searchShop(){
				this.shopList={data:[]}
				this.init()
			},
			// 拨打电话
			makePhone(e){
				uni.makePhoneCall({
					phoneNumber:e
				})
			},
			//切换tab栏
			currentChange(e) {
				// console.log(e)
				this.current = e
				this.pageIndex=1
				this.value=""
				this.shopList={data:[]}
				this.init()
			},
			//弹出层
			// open() {
			// 	// 通过组件定义的ref调用uni-popup方法
			// 	this.$refs.popup.open()
			// },
			// close() {
			// 	this.$refs.popup.close()
			// },
			init() {
				salesmanCenter.user_merchant_list({
					token: uni.getStorageSync('xxytoken'),
					type: this.type,
					page: this.pageIndex,
					count: "10",
					merchant_name:this.searchValue
				}).then(res => {
					if(res.status==200&&res.result!=null){
						if(this.shopList.data.length>0){
							this.shopList.data=[...this.shopList.data,...res.result.data]
						}else{
							this.shopList=res.result
						}
					}else if(res.status!=200){
						uni.showToast({
							title:res.message,
							icon:"none"
						})
					}

				})
			},
			//处理时间戳
			DateToStr(e) {
				if(e==0){
					return "暂未缴纳年费"
				}else if(e==-1){
					return "永久"
				}else{
					return this.$timeConvert(e,0)
				}
			},
			//即将到期判断
			dataChangeColor(date) {
				const itis = Date.parse(new Date());

				date.forEach(element => {
					if (element.expire_time - (60 * 60 * 24 * 1000 * 30) <= itis) {
						//即将到期
						element.color = false
					}
				})
			},
			//跳转到商户详情
			go(el) {
				console.log(11111)
				console.log(el)
				var id = el.merchant_id
				var img = el.referrer_photo
				var name = el.referrer_name
				var phone = el.referrer_phone
				uni.navigateTo({
					url: `/pages/agentCentre/shopHome/shopHome?id=` + id + `&name=` + name + `&img=` + img +
						`&phone=` + phone
				})
			},
			// 跳转到商家信息页面
			go3(el) {
				var id = el.merchant_id
				uni.navigateTo({
					url: `/pages/agentCentre/shopAuditing/shopAuditing?id=` + id
				})
			},
			go4(){
				uni.showToast({
					title:"平台正在审核中",
					icon:"none"
				})
			}

		},
		computed: {
			type() {
				return Number(this.current) + 1 + "";
			}

		},
	}
</script>


<style lang="scss" scoped>
	.bottomview{
		padding: 30rpx;
	}
	.searchButton {
		width: 120rpx;
		height: 60rpx;
		line-height: 60rpx;
		text-align: center;
		background-color: #4794FF;
		border-radius: 10rpx;
		margin-right: 5rpx;
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: bold;
		color: #FFFFFF;
	}
	.searchInput {
		margin: 0 30rpx;
		width: 100%;
		background: #9ec5fa;
		border-radius: 10rpx;
	}
	
	.box {
		// background-color: #F5F5F5;

		.header {
			display: flex;
			// justify-content: space-between;
			align-items: center;
			height: 90rpx;
			width: 100%;
			background-color: #4794FF;

			.header-c {
				display: flex;
				align-items: center;
				justify-content: space-between;
				width: 690rpx;
				height: 70rpx;
				background: #9ec5fa;
				margin: 0 auto;

				border-radius: 10rpx;

				.img {
					width: 32rpx;
					height: 32rpx;
					margin-left: 50rpx;
					margin-right: 20rpx;
				}

				.btn {
					background-color: #4794FF;
					color: #fff;
					width: 120rpx;
					display: flex;
					align-items: center;
					height: 60rpx;
					text-align: center;
					justify-content: center;
					margin-right: 10rpx;
					border-radius: 10rpx;
				}
			}

		}

		.banner {
			width: 750rpx;
			height: 80rpx;
			background: #DAEAFF;
			display: flex;
			justify-content: flex-start;
			align-items: center;

			.img {
				height: 32rpx;
				width: 32rpx;
				margin-left: 40rpx;

			}

			.swiper {
				height: 80rpx;
				width: 568rpx;

				.swiper-item {
					display: flex;
					justify-content: flex-start;
					align-items: center;


					.swiper-text {
						width: 502rpx;
						font-size: 24rpx;
						font-family: PingFang SC;
						font-weight: 400;
						color: #333333;
						line-height: 66rpx;
						margin-left: 10rpx;
					}

				}

			}

			.swiper-link {
				font-size: 24rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #999999;
				// margin-left: 50rpx;
			}
		}

		.nav {
			background-color: #fff;
			// margin-top: 20rpx;
			height: 70rpx;

			.content-nav {
				background-color: #fff;
				display: flex;
				justify-content: space-around;

				.nav-item {
					.text {
						width: 76rpx;
						height: 25rpx;
						font-size: 26rpx;
						font-family: PingFang SC;
						font-weight: 400;
						line-height: 66rpx;
					}
				}

				.active {
					border-bottom: 4rpx solid #4794FF;

					.text {
						color: #4794FF;
						font-weight: 500;
						font-size: 30rpx !important;
						line-height: 66rpx;
						font-family: PingFang SC;
						// height: 29rpx;
					}
				}
			}
		}

		.content {
			padding: 0 30rpx;
			background-color: #fff;
			margin-top: 30rpx;

			.bottom {
				width: 690rpx;
				height: 60rpx;
				background: #E0EDFF;
				border-radius: 4rpx;
				margin-top: 20rpx;
				padding: 0 80rpx;
				font-size: 26rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #333333;
				display: flex;
				justify-content: flex-start;
				align-items: center;
				margin-bottom: 50rpx;

				.img {
					width: 50rpx;
					height: 50rpx;
					border-radius: 50%;
					margin: 0 20rpx;
				}

				.name {
					margin-right: 20rpx;
				}
			}

			.score-item {
				width: 690rpx;
				// height: 200rpx;
				background: #FFFFFF;
				// border-bottom: 1rpx solid #EEEEEE;
				border-radius: 10rpx;
				display: flex;
				align-items: center;
				justify-content: flex-start;
				flex-wrap: wrap;
				// margin-bottom: 20rpx;

				.left1 {
					width: 179rpx;
					height: 180rpx;
					border-radius: 10rpx;
					margin-left: 11rpx;
					overflow: hidden;

					image {
						width: 180rpx;
						height: 180rpx;
					}
				}

				.right1 {
					margin-left: 22rpx;
					width: 458rpx;
					height: 100%;
					display: flex;
					flex-direction: column;
					justify-content: space-evenly;

					.rline1 {
						font-size: 30rpx;
						display: flex;
						justify-content: space-between;
						margin-bottom: 10rpx;
						margin-top: 10rpx;

						.img {
							width: 44rpx;
							height: 44rpx;

							border-radius: 50%;

						}
					}

					.rline2 {
						margin-bottom: 10rpx;
						font-size: 24rpx;
						color: #666666;
						white-space: nowrap;
						text-overflow: ellipsis;
						overflow: hidden;
						word-break: break-all;

					}

					.rline3 {
						margin-bottom: 10rpx;
						width: 500rpx;
						font-size: 24rpx;
						display: flex;
						align-items: center;

						image {
							width: 28rpx;
							height: 28rpx;
							margin-left: 1rpx;
						}
					}

					.rline4 {
						width: 500rpx;
						font-size: 24rpx;
						display: flex;
						align-items: center;

						// padding-left: 5rpx;
						image {
							width: 20rpx;
							height: 27rpx;
							margin-left: 6rpx;
						}

						.refuse {
							display: flex;
							align-items: center;
							justify-content: center;

							font-size: 24rpx;
							font-family: PingFang SC;
							font-weight: 400;
							color: #FE5E5E;

							.fff {
								border-bottom: 1rpx solid #FFF;
							}

							.ml {
								margin-left: 10rpx;
								border-bottom: 1rpx solid #FE5E5E;
							}
						}
					}

				}
			}

		}

		.footer {
			// z-index: 99999;
			position: fixed;
			left: 0;
			bottom: 0;
			display: flex;
			justify-content: center;
			height: 90rpx;
			width: 100%;
			background-color: #4794FF;

			.add {
				display: flex;
				align-items: center;
				font-size: 30rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: #FFFFFF;


				.img {
					width: 36rpx;
					height: 36rpx;
					margin-right: 20rpx;
				}
			}
		}
	}

	.line-txt {
		// width: 311px;
		// height: 23px;
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #4794FF;
	}

	.rline3 {

		.line-txt {
			margin-left: 10rpx;

			color: #333333;
		}
	}


	.dialog {
		width: 500rpx;
		height: 400rpx;
		background: #FFFFFF;
		border-radius: 10rpx;
		position: relative;
		overflow: hidden;

		.dia-t {
			text-align: center;
			margin-top: 50rpx;
			margin-bottom: 40rpx;

			.title {
				font-size: 36rpx;
				font-family: PingFang SC;
				font-weight: bold;
				color: #333333;
				line-height: 34rpx;
			}

			.img {
				position: absolute;
				top: 28rpx;
				right: 28rpx;
				width: 36rpx;
				height: 36rpx;
			}
		}

		.dia-c {
			font-size: 24rpx;
			font-family: PingFang SC;
			font-weight: 400;
			color: #333333;
			line-height: 23rpx;
			margin-left: 60rpx;

			.pic {
				display: flex;
				align-items: center;
				margin-bottom: 20rpx;

				.img {
					width: 70rpx;
					height: 70rpx;
					border-radius: 50%;
				}
			}

			.name {

				margin-bottom: 20rpx;
			}

			.level {
				display: flex;
				align-items: center;
				margin-bottom: 20rpx;

				.text {
					margin-left: 48rpx;
				}
			}

			.phone {
				// margin-top: 20rpx;

				display: flex;
				align-items: center;

				.img {
					width: 44rpx;
					height: 44rpx;
					margin-left: 50rpx;
				}

				.blue {
					color: #4695FE;
				}
			}

		}

	}
</style>
