<template>
	<view class="box">
		<view class="header">
			<view class="searchInput" style="padding-left:30rpx;">
				<view style="width: 100%;height:70rpx;display: flex;align-items: center;justify-content: space-between;">
					<image src="../../../static/search.png" style="width: 32rpx;height: 32rpx;margin: 0 20rpx;z-index: 10;"></image>
					<input style="color:#FFFFFF;opacity: 0.6;flex-grow: 1;" placeholder-style="color:#fff;font-size:26rpx" v-model="searchValue" placeholder="请输入店铺名称" />
					<view class="searchButton" @click="searchShopRecords">
						搜索
					</view>
				</view>
			</view>
		</view>
		<view v-if="agentGoodList.data.length>0">
			<view  class="content" v-for="(item,index) in agentGoodList.data" :key="item.merchant_id">
				<view class="item">
					<view class="item-c">
						<image :src="$imgUrl(item.merchant_logo)" class="img" style="border-radius: 50%;"></image>
						<view class="text">
							{{item.merchant_name}}
						</view>
					</view>
					<view class="bind" @click="goDeduct(item)">
						查看明细 >
					</view>
				</view>
				<view class="income">
					<view class="income-item">
						<view class="num">
							{{item.day_money}}
						</view>
						<view class="text">
							今日营收
						</view>
					</view>
					<view class="income-item">
						<view class="num">
							{{item.month_money}}
						</view>
						<view class="text">
							本月营收
						</view>
					</view>
					<view class="income-item">
						<view class="num">
							{{item.all_money}}
						</view>
						<view class="text">
							累计营收
						</view>
					</view>
				</view>
			</view>
		</view>
		
		<view class="footer" v-else style="margin-top: 300rpx;text-align: center;">
			<img :src="cdnUrl+'XianxiangUapi/static/datanull.png'" alt="" style="width: 480rpx;height: 360rpx;" >
		</view>
	</view>
</template>

<script>
	import agentCenterApi from "../../../api/agentCenter/agentCenter.js"
	export default {
		data() {
			return {
                cdnUrl:"",
				searchValue:"",
				token:"",
				agentGoodList:{
					data:[]
				},
				pageIndex:"1",
				
			};
		},
		onLoad(){
            this.cdnUrl=this.$cdnUrl
			this.token=uni.getStorageSync("xxytoken")
			this.ajax()
		},
		onReachBottom(){
			if (this.pageIndex < this.agentGoodList.last_page) {
					++this.pageIndex;
					this.ajax()
				} else {
					
				}
		},
		methods: {
			// 点击搜索返回搜索的代理商商户营收列表
			searchShopRecords(){
				this.agentGoodList={data:[]}
				this.ajax()
			},
			// 点击跳转至商户营收明细
			goDeduct(e){
				uni.navigateTo({
					url:"../../salesmanCommercial/deduct/deduct?id="+e.merchant_id
				})
			},
			// 得到代理商商户营收列表
			ajax(){
				agentCenterApi.agent_merchant_lists({
					token:this.token,
					page:this.pageIndex,
					count:"10",
					merchant_name:this.searchValue
				}).then(res=>{
					if(res.status==200&&res.result!=null){
						if(this.agentGoodList.data.length>0){
							this.agentGoodList.data=[...this.agentGoodList.data,res.result.data]
						}else{
							this.agentGoodList=res.result
						}
					}else if(res.status!=200){
						uni.showToast({
							title:res.message,
							icon:"none"
						})
					}
				})
			},
		}
	}
</script>

<style>
	page{background-color: #F5F5F5;}
</style>

<style lang="scss" scoped>
	.searchInput {
		margin: 0 30rpx;
		width: 100%;
		background: #9ec5fa;
		border-radius: 10rpx;
	}
	.searchButton {
		width: 120rpx;
		height: 60rpx;
		line-height: 60rpx;
		text-align: center;
		background-color: #4794FF;
		border-radius: 10rpx;
		margin-right: 5rpx;
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: bold;
		color: #FFFFFF;
	}
	.box {
		background-color: #f5f5f5;

		.header {
			height: 80rpx;
			width: 100%;
			background-color: #4794FF;
			display: flex;
			align-items: center;

			.header-item {
				background-color: #9ec5fa;
				width: 690rpx;
				height: 70rpx;
				margin: 0 auto;
				border-radius: 10rpx;
				display: flex;
				justify-content: flex-start;
				align-items: center;

				.btn {
					width: 120rpx;
					height: 60rpx;
					background: #4794FF;
					border-radius: 10rpx;
					text-align: center;
					color: #fff;
					line-height: 56rpx;
					margin-left: 210rpx;
				}

				.img {
					width: 32rpx;
					height: 32rpx;
					margin-left: 50rpx;
					margin: 20rpx;
				}

				.uni-input {
					height: 25px;
					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #FFFFFF;
					line-height: 66rpx;
				}
			}
		}

		.content {
			width: 100%;
			height: 220rpx;
			background-color: #fff;
			margin: 20rpx 0;

			.item {
				display: flex;
				align-items: center;
				height: 70rpx;
				justify-content: space-between;
				border-bottom: 2rpx solid #f5f5f5;

				.item-c {
					margin-left: 31rpx;
					display: flex;
					justify-content: flex-start;
					align-items: center;
				}

				.img {
					width: 52rpx;
					height: 52rpx;
				}

				.text {

					line-height: 28rpx;
					font-size: 30rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #333333;
					margin-left: 22rpx;

				}

				.bind {
					margin-right: 20rpx;
					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #999999;
					line-height: 25rpx;
				}
			}
			.income{
				display: flex;
				justify-content: space-around;
				.income-item{
					.num{					
						font-size: 30rpx;
						font-family: PingFang SC;
						font-weight: 500;
						color: #333333;		
						margin-top: 38rpx;
						text-align: center;
					}
					.text{			
						font-size: 26rpx;
						font-family: PingFang SC;
						font-weight: 400;
						color: #666666;		
						margin-top: 8rpx;
					}
				}
			}
		}

		.footer {
			width: 100%;
			height: 186rpx;
			display: flex;
			align-items: center;
			justify-content: center;
			margin-top: 200rpx;
			.text {


				font-size: 26rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #999999;


			}
		}
	}
</style>

