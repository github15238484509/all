<template>
	<view class="box">
		<view v-if="userCashList.data.length>0">
			<view class="box-item" v-for="(item,index) in userCashList.data" :key="item.index">
				<view class="item-l">
					<view class="top">
						{{typeToValue(item.type)}}
					</view>
					<view class="bottom">
						{{$timeConvert(item.time)}}
					</view>
				</view>
				<view class="item-r" v-if="item.type==1||item.type==20">
					+{{$returnFloat(item.amount)}}
				</view>
				<view class="item-r1" v-else>
					-{{$returnFloat(item.amount)}}
				</view>
			</view>
		</view>
		<view v-else style="margin-top: 300rpx;text-align: center;"><img :src="cdnUrl+'XianxiangUapi/static/datanull.png'" alt="" style="width: 480rpx;height: 360rpx;"></view>
	</view>
</template>

<script>
	import agentCenterApi from "../../../api/agentCenter/agentCenter.js"
	export default {
		data() {
			return {
                cdnUrl:"",
				userCashList: {
					data: [],
				},
				token: "",
				cashPotList: {
					token: "",
					page: "1",
					count: "10"
				},
				pageIndex: 1,
			};
		},
		onReachBottom() {
			if (this.pageIndex < this.userCashList.last_page) {
				++this.pageIndex;
				this.cashPotList.page = this.pageIndex
				this.ajax(this.cashPotList)
			}
		},
		onLoad() {
            this.cdnUrl=this.$cdnUrl
			this.token = uni.getStorageSync("xxytoken");
			this.cashPotList.token = this.token
			this.ajax(this.cashPotList);
		},
		methods: {
			// 请求余额列表数据
			ajax(e) {
				agentCenterApi.user_cash_change(e).then(res => {
					if (res.status == 200&&res.result!=null) {
						if (this.userCashList.data.length > 0) {
							this.userCashList.data = [...this.userCashList.data, ...res.result.data]
						} else {
							this.userCashList = res.result
						}
					} else if (res.status!=200) {
						uni.showToast({
							title: res.message,
							icon: "none"
						})
					}
				})
			},
			// 将type转换为提现方式
			typeToValue(e) {
				if (e == 1) {
					return "商家分润"
				} else if (e == 11) {
					return "提现银行卡"
				} else if(e==13){
					return "提现微信"
				}else{
					return "提现驳回增加"
				}
			},
		}
	}
	
</script>

<style lang="scss" scoped>
	.box {
		padding: 0 30rpx;
		.box-item {
			height: 120rpx;
			width: 100%;
			display: flex;
			align-items: center;
			justify-content: space-between;

			.item-l {
				.top {
					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 500;
					color: #333333;
					line-height: 25rpx;
				}

				.bottom {
					margin-top: 20rpx;
					font-size: 22rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #999999;
					line-height: 18rpx;
				}
			}

			.item-r {

				font-size: 26rpx;
				font-family: PingFang SC;
				font-weight: bold;
				color: #333333;
				line-height: 20rpx;

			}

			.item-r1 {

				font-size: 26rpx;
				font-family: PingFang SC;
				font-weight: bold;
				color: red;
				line-height: 20rpx;

			}

			.red {

				font-size: 26rpx;
				font-family: PingFang SC;
				font-weight: bold;
				color: #FC4950;
				line-height: 20rpx;

			}
		}
	}
</style>
