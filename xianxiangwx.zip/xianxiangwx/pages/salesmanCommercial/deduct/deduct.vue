<template>
	<view v-if="deductList.data.length>0">
		<view class="box" v-for="(item,index) in deductList.data" :key="item.time">
			<view class="banner">
				<view class="header">
					<view class="item">
						<view class="date">
							{{item.time}}
						</view>
						<view class="num">
							(共收入{{item.money}})
						</view>
					</view>
					<!-- 判断索引值只有第一列才有日历图片 -->
					<image src="../../../static/date.png" class="img" @click="goDateSelct()" v-if="index==0"></image>
				</view>
				<view class="banner-list" v-for="(item1,index1) in item.list" @click="goRevenueDetail(item1)"
					:key="item1.freeze_index">
					<view class="list-l">
						<image :src="$imgUrl(item1.photo)" class="img"></image>
						<view class="text">
							<view class="name">
								{{item1.name}}
							</view>
							<view class="phone">
								{{item1.phone}}
							</view>
							<view class="date">
								{{item1.need_pay_time}}
							</view>
						</view>
					</view>
					<view class="list-r">
						<view class="num">
							+{{item1.amount}}
						</view>
						<view class="date">
							第{{item1.branch_num}}/{{item1.all_num}}期
						</view>
					</view>
				</view>
			</view>
		</view>
	</view>
	<view v-else style="padding: 30rpx;text-align: center;margin-top: 300rpx;">
		<img :src="cdnUrl+'XianxiangUapi/static/datanull.png'" alt="" style="width: 480rpx;height: 360rpx;">
	</view>
</template>

<script>
	import getOrderListApi from "../../../api/commercial/orderListApi.js"
	export default {
		data() {
			return {
                cdnUrl:"",
				// 储存跳转至该页面时的系统时间
				dateNow: "",
				// 查询的营收记录的页数
				pageIndex: "1",
				// 存储接收的营收记录数据
				deductList: {
					data:[]
				},
				// 调取营收记录接口需要传的参数
				potList:{
					token:"",
					merchant_id:"",
					page: "1",
					start_time: "",
					end_time: "",
					count: "10"
				},
				token:""
			};
		},
		// 列表滑动渲染
		onReachBottom() {
			if(this.potList.page<this.deductList.last_page){
				++this.potList.page
				this.ajax(this.potList)
			}else{
				uni.showToast({
					title:"没有更多了!",
					icon:"none"
				})
			}

		},
		// 页面加载时执行的方法
		onLoad(e) {
                this.cdnUrl=this.$cdnUrl
				this.token=uni.getStorageSync("xxytoken")
				console.log(this.token)
				this.potList.token=this.token
				this.potList.merchant_id = e.id;
				this.dateNow = (new Date()).getTime();
				this.potList.page=this.pageIndex
				if (e.time) {
					var a = JSON.parse(e.time)
					this.potList.start_time = a.start_time
					this.potList.end_time = a.end_time
				} else {
					// this.potList.end_time = this.dateNow;
				}
				this.ajax(this.potList)	
		},
		methods: {
			// 点击日历图片跳转至时间选择页面(不用带参数)
			goDateSelct() {
				uni.navigateTo({
					url: "../dateSelect/dateSelect"
				})
			},
			// 点击某一项的订单数据跳转至营收明细页面
			goRevenueDetail(e) {
				console.log(e)
				uni.navigateTo({
					url: "../revenueDetails/revenueDetails?deductId=" + e.freeze_index
				})
			},
			// 访问营收记录的接口接收参数为posList
			ajax(e) {
				getOrderListApi.getOrderBranchList(e).then(res => {
					if (res.status == 200&&res.result!=null) {
						if(this.deductList.data.length>0){
							this.deductList.data=[...this.deductList.data,...res.result.data]
						}else{
							this.deductList = res.result
						}
					}else if(res.status!=200){
						uni.showToast({
							title:res.message,
							icon:"none"
						})
					}
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	.box {
		background-color: #f5f5f5;

		// height: 100vh;
		.banner {
			.header {
				height: 50rpx;
				display: flex;
				justify-content: space-between;
				align-items: center;

				.item {
					display: flex;
					justify-content: space-between;
					font-size: 22rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #333333;
					margin-left: 32rpx;

					.num {
						margin-left: 26rpx;
					}
				}

				.img {
					height: 34.5rpx;
					width: 34.5rpx;
					margin-right: 35rpx;
				}
			}

			.banner-list {
				height: 168rpx;
				width: 100%;
				background-color: #fff;
				border-bottom: 2rpx solid #f5f5f5;
				display: flex;
				justify-content: space-between;
				align-items: center;


				.list-l {
					display: flex;
					justify-content: space-between;
					width: 315rpx;
					margin-left: 31rpx;
					display: flex;
					align-items: center;

					.img {
						width: 80rpx;
						height: 80rpx;
						border-radius: 50%;
					}

					.text {
						.name {
							font-size: 30rpx;
							font-family: PingFang SC;
							font-weight: bold;
							color: #333333;
							margin-bottom: 9rpx;
						}

						.phone {
							font-size: 26rpx;
							font-family: PingFang SC;
							font-weight: 400;
							color: #333333;
							margin-bottom: 9rpx;
						}

						.date {
							font-size: 24rpx;
							font-family: PingFang SC;
							font-weight: 400;
							color: #999999;

						}
					}
				}

				.list-r {
					width: 130rpx;
					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 500;
					margin: 33rpx;

					.num {
						color: #666666;
						margin-bottom: 13rpx;
					}

					.date {

						color: #999999;
					}
				}
			}
		}
	}
</style>
