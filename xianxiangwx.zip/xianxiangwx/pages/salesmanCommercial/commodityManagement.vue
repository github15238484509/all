<template>
	<!-- 总体 -->
	<view class="Trade">
		<!-- 导航栏 -->
		<view class="navgation fontstyle" style="position: fixed;top:0rpx;width: 100%;background-color: #FFFFFF;">
			<!-- 三元运算 -->
			<view :class="nav===index?'active':''" v-for="(item,index) in tileList" :key="item.id" @click="select(index)">
				{{item.title}}
			</view>
		</view>
		<!-- 销售中内容 -->
		<view style="margin-top: 110rpx;">
			<view v-if="nav==0&&goodsListGet.data.length>0">
				<view class="Tradeshow"  v-for="(item,index) in goodsListGet.data" :key="item.goods_index" >
					<view>
						<img :src="$imgUrl(item.goods_icon)" alt=""
							style="height: 276rpx;width: 100%;border-radius: 10rpx 10rpx 0 0;" mode="scaleToFill">
					</view>
					<view class="fontstyle-Bold" style="margin: 21rpx;">
						{{item.goods_name}}
					</view>
					<view style="margin: 20rpx;">
						<span class="fontbig">￥{{$returnFloat(item.stage)}}</span><span class="fontsmall" v-if="item.goods_type!='0'">X{{item.goods_type}}期</span>
						<span class="font"  v-if="item.goods_type!='0'">￥{{$returnFloat(item.goods_cost)}}</span>
					</view>
					<view class="bottomBar">
						<!-- :class="btn===item&&btn1==index1?'bottomBarIteam':''" -->
						<!-- <view  v-for="(item1,index) in buttonList" @click="selectBtn(index)" :key="item1">{{item1.title}}</view> -->
						<view @click="selectBtn(item)" style="border-radius: 10rpx 0 0 10rpx;">编辑商品</view>
						<view @click="selectOFF(item)" style="background-color: #8FC6FF;border-radius: 0rpx 10rpx 10rpx 0rpx;">下架</view>
					</view>
				</view>
			</view>
			<view v-else-if="nav==0&&goodsListGet.data.length==0" style="text-align: center; margin-top: 300rpx;">
				<img :src="cdnUrl+'XianxiangUapi/static/datanull.png'" alt=""  style="width: 480rpx;height: 360rpx;">
			</view>
		</view>

		<!-- 导航栏审核中内容 -->
		<view style="margin-top: 110rpx;">
			<view v-if="nav==1&&goodsListGet.data.length>0">
				<view class="Tradeshow"  v-for="(item,index) in goodsListGet.data" :key="item.goods_index" >
					<view>
						<img :src="$imgUrl(item.goods_icon)" alt=""
							style="height: 276rpx;width: 100%;border-radius: 10rpx 10rpx 0 0;" mode="scaleToFill">
					</view>
					<view class="fontstyle-Bold" style="margin: 21rpx;">
						{{item.goods_name}}
					</view>
					<view style="margin: 20rpx;padding-bottom: 20rpx;">
						<span class="fontbig">￥{{$returnFloat(item.stage)}}</span><span class="fontsmall" v-if="item.goods_type!='0'">X{{item.goods_type}}期</span>
						<span class="font" v-if="item.goods_type!='0'">￥{{$returnFloat(item.goods_cost)}}</span>
					</view>
				</view>
			</view>
			<view v-else-if="nav==1&&goodsListGet.data.length==0" style="text-align: center; margin-top: 300rpx;">
				<img :src="cdnUrl+'XianxiangUapistatic/datanull.png'" alt=""  style="width: 480rpx;height: 360rpx;">
			</view>
		</view>
			<!-- 审核失败中内容 -->
			<view style="margin-top: 110rpx;">
				<view  v-if="nav==2&&goodsListGet.data.length>0">
					<view class="Tradeshow" v-for="(item,index) in goodsListGet.data" :key="item.goods_index" >
						<view>
							<img :src="$imgUrl(item.goods_icon)" alt=""
								style="height: 276rpx;width: 100%;border-radius: 10rpx 10rpx 0 0;" mode="scaleToFill">
						</view>
						<view class="fontstyle-Bold" style="margin: 21rpx;">
							{{item.goods_name}}
						</view>
						<view style="margin: 20rpx;">
							<span class="fontbig">￥{{$returnFloat(item.stage)}}</span><span class="fontsmall" v-if="item.goods_type!='0'">X{{item.goods_type}}期</span>
							<span class="font" v-if="item.goods_type!='0'">￥{{$returnFloat(item.goods_cost)}}</span>
						</view>
						<view class="bottomRefuse">
							<view @click="selectRefuse(item)" style="border-radius:10rpx;background-color: #3699FF;">查看拒绝原因</view>
						</view>
					</view>
				</view>

				<view v-else-if="nav==2&&goodsListGet.data.length==0" style="text-align: center;margin-top: 300rpx;">
					<img :src="cdnUrl+'XianxiangUapi/static/datanull.png'" alt="" style="width: 480rpx;height: 360rpx;">
				</view>
			</view>
		<!-- 已下架中内容 -->
		<view>
			<view v-if="nav==3&&goodsListGet.data.length>0">
				<view class="Tradeshow"  v-for="(item,index) in goodsListGet.data" :key="item.goods_index" >
					<view>
						<img :src="$imgUrl(item.goods_icon)" alt=""
							style="height: 276rpx;width: 100%;border-radius: 10rpx 10rpx 0 0;" mode="scaleToFill">
					</view>
					<view class="fontstyle-Bold" style="margin: 21rpx;">
						{{item.goods_name}}
					</view>
					<view style="margin: 20rpx;">
						<span class="fontbig">￥{{$returnFloat(item.stage)}}</span><span class="fontsmall" v-if="item.goods_type!='0'">X{{item.goods_type}}期</span>
						<span class="font" v-if="item.goods_type!='0'">￥{{$returnFloat(item.goods_cost)}}</span>
					</view>
					<view class="bottomBar">
						<!-- :class="btn===item&&btn1==index1?'bottomBarIteam':''" -->
						<!-- <view  v-for="(item1,index) in buttonList" @click="selectBtn(index)" :key="item1">{{item1.title}}</view> -->
						<view @click="selectBtn(item)" style="border-radius: 10rpx 0 0 10rpx;">编辑商品</view>
						<view @click="selectOFF(item)" style="background-color: #8FC6FF;border-radius: 0rpx 10rpx 10rpx 0rpx;">上架</view>
					</view>
				</view>
			</view>
			<view v-else-if="nav==3&&goodsListGet.data.length==0" style="text-align: center; margin-top: 300rpx;">
				<img :src="cdnUrl+'XianxiangUapi/static/datanull.png'" alt=""  style="width: 480rpx;height: 360rpx;">
			</view>
		</view>
		<img src="../../static/addsalesman.png" alt=""
			style="width: 113rpx;height: 113rpx;position: fixed;bottom: 200rpx;right: 0rpx;" @click="goCommercialAdd()">
	</view>

</template>

<script>
	import getCommodityApi from "../../api/commercial/commodityManagementApi.js"
	export default {
		data() {
			return {
                cdnUrl:"",
				// 商户ID
				merchantId: "",
				// 导航栏状态
				tileList: [{
						id: '1',
						title: "销售中"
					},
					{
						id: '2',
						title: "审核中"
					},
					{
						id: '3',
						title: "审核拒绝"
					},
					{
						id: '4',
						title: "已下架"
					}
				],
				// 用于判断导航栏当前处于什么状态
				nav: 0,
				// 接收返回的商户商品信息
				goodsListGet: {
					data: [],
				},
				// 商品当前页面数
				pageIndex: 1,
				// 商户商品列表请求需要的参数
				goodsListPos: {
					token: "",
					merchant_id: "1",
					type: "1",
					page: "1",
					count: "10"
				},
				// 用户的token值
				token: "",
				// 商品详情需要的参数
				goods_id: "",
				// 弹窗显示的内容
				showModalContent: "您确定要下架该商品吗?"
			}
		},
		// 进入界面加载前执行的函数
		onLoad(e) {
            this.cdnUrl=this.$cdnUrl
			// 获取用户登录时存储在本地的token值
			this.token = uni.getStorageSync('xxytoken');
			this.goodsListPos.token=this.token
			this.merchantId = e.id
			var typestatus=this.nav;
			this.goodsListPos.type =++typestatus;
			this.goodsListGet = {
				data: []
			};
			this.goodsListPos.page = 1;
			// 调用APi得到商品信息
		},
		onShow(){
			this.select(this.nav)
		},
		// 滚动页面时执行的方法
		onReachBottom() {
			// 
			if (this.pageIndex < this.goodsListGet.last_page) {
				this.goodsListPos.page = ++this.pageIndex;
				this.ajax(this.goodsListPos)
			} else {
				console.log(this.goodsListGet.data)
			}
		},
		methods: {
			// 点击查看商品审核拒绝原因
			selectRefuse(e) {
				uni.navigateTo({
					url:"commodityStatus/commodityStatus?id="+e.goods_index
				})
			},
			// 切换至点击的导航栏
			select(index) {
				this.nav = index;
				this.goodsListPos.type = ++index;
				this.goodsListGet = {
					data: []
				};
				this.goodsListPos.page = 1;
				this.pageIndex = 1;
				this.goodsListPos.token=this.token
				this.ajax();
			},
			// 上下架按钮点击事件
			selectOFF(e) {
				var merchantype = 0;
				if (e.goods_status == 2) {
					this.showModalContent = "您确定要下架该商品吗?"
					merchantype = 3;
				} else if (e.goods_status == 3) {
					this.showModalContent = "您确定要上架该商品吗?"
					merchantype = 2;
				}
				var a = {
					merchant_id: this.merchantId,
					token: this.token,
					goods_id: e.goods_index,
					type: merchantype
				}
				console.log(a)
				uni.showModal({
					title: "提示",
					content: this.showModalContent,
					success: (res) => {
						if (res.confirm) {
							getCommodityApi.getCommodityPut(a).then(res => {
								this.goodsListGet.type = merchantype
								this.goodsListGet.data = [];
								this.pageIndex=1;
								this.goodsListPos.page = 1;
								this.ajax();
							})
						} else if (res.cancel) {}
					}
				})
			},
			// 点击跳转至添加页面
			selectBtn(e) {
				uni.navigateTo({
					url: "./commercialAdd?id="+e.goods_index
				})
			},
			
			// 跳至商品添加页面
			goCommercialAdd() {
				uni.navigateTo({
					url: "./commercialAdd"
				})
			},
			// 调用商品信息接口
			ajax() {
				console.log(this.goodsListPos)
				getCommodityApi.getCommodity(this.goodsListPos).then(res => {
					if (res.status == 200&&res.result!=null) {
						if (this.goodsListGet.data.length > 0) {
							this.goodsListGet.data = [...this.goodsListGet.data, ...res.result.data];
						} else {
							if(res.result!=null){
								this.goodsListGet = res.result;
							}else{
								
							}
						}
					} else {
						
					}
				})
			}
			
			
		}
	}
</script>

<style>
	page{background-color: #F5F5F5;}
</style>
<style scoped>
	.font {
		margin-left: 20rpx;
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 400;
		text-decoration: line-through;
		color: #999999;

	}

	.fontsmall {
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #85B8FF;
	}

	.fontbig {
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #4794FF;

	}

	.navgation {
		display: flex;
		justify-content: space-around;
	}

	.navgation>view {
		text-align: center;
		height: 90rpx;
		line-height: 90rpx;
	}

	.fontstyle {
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #333333;
	}

	.fontstyle-Bold {
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #333333;
	}

	.active {
		border-bottom: 4rpx solid #4794FF;
		font-size: 30rpx;
		color: #4794FF;
	}

	.Tradeshow {
		margin: 20rpx 30rpx;
		border-radius: 10rpx;
		background-color: #FFFFFF;
	}

	.bottomBar {
		display: flex;
		height: 90rpx;
		line-height: 90rpx;
		text-align: center;
		justify-content: space-between;
	}

	.bottomBar>view {
		width: 50%;
		height: 90rpx;
		line-height: 90rpx;
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #FFFFFF;
		background-color: #3699FF;
	}

	.bottomRefuse {
		height: 90rpx;
		line-height: 90rpx;
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #FFFFFF;
		text-align: center;
	}

	.navgat {
		height: 28px;
		font-size: 30px;
		font-family: PingFang SC;
		color: #FFFFFF;
	}
</style>
