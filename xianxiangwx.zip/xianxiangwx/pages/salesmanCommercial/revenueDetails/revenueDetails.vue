<template>
	<view class="box" style="overflow: hidden;">
		<view class="banner">
			<view class="banner-h" >
				<image src="../../../static/money.png" class="img" style="padding-top: 20rpx;" ></image>
				<view class="num">
					{{revenueDetailsList.price}}
				</view>
				<view class="date" v-if="revenueDetailsList.used_pay_type==0">
					暂未扣款<br>
					共{{revenueDetailsList.pay_type}}期
				</view>
				<view class="date" v-else>
					第{{revenueDetailsList.used_pay_type}}/{{revenueDetailsList.pay_type}}期
				</view>
			</view>
			<view class="banner-f">
				<view class="item">
					<view class="item-l">
						订单编号
					</view>
					<view class="item-r">
						{{revenueDetailsList.out_order_no}}
					</view>
				</view>
				<view class="item">
					<view class="item-l">
						订单提交时间
					</view>
					<view class="item-r">
						{{revenueDetailsList.add_time}}
					</view>
				</view>
				<view class="item">
					<view class="item-l">
						扣款方式
					</view>
					<view class="item-r">
						花呗
					</view>
				</view>
				<view class="item">
					<view class="item-l">
						商品信息
					</view>
					<view class="item-r">
						{{revenueDetailsList.goods_name}}
					</view>
				</view>
				<view class="item">
					<view class="item-l">
						分期详情
					</view>
					<view class="item-r" style="color:#4794FF;margin-bottom: 20rpx;" @click="goOrderBranch(revenueDetailsList)">
						查看分期详情
					</view>
				</view>
			</view>
		</view>
		<view style="display: flex;margin-left: 30rpx;align-items: center;">
			<view style="width: 4rpx;height: 26rpx;background: #3699FF;margin-right: 10rpx;"></view>
			<view class="memberInfo">会员信息</view>
		</view>
		<view class="footer" >
			<view class="name" >
				<view class="name-l">
					会员昵称
				</view>
				<view class="name-r">
					{{revenueDetailsList.name}}
				</view>
			</view>
			<view class="phone">
				<view class="phone-l">
					会员手机号
				</view>
				<view class="phone-r">
					{{revenueDetailsList.phone}}
				</view>
			</view>
		</view>
		<view v-if="memberInfo">
			<view style="display: flex;margin-left: 30rpx;align-items: center;"  >
				<view style="width: 4rpx;height: 26rpx;background: #3699FF;margin-right: 10rpx;"></view>
				<view class="memberInfo">购卡信息</view>
			</view>
			<view class="footer" >
				<view class="name" >
					<view class="name-l">
						姓名
					</view>
					<view class="name-r">
						{{revenueDetailsList.user_name}}
					</view>
				</view>
				<view class="phone">
					<view class="phone-l">
						手机号
					</view>
					<view class="phone-r">
						{{revenueDetailsList.user_phone}}
					</view>
				</view>
				<view class="phone">
					<view class="phone-l">
						性别
					</view>
					<view class="phone-r">
						{{revenueDetailsList.user_sex}}
					</view>
				</view>
				<view class="phone">
					<view class="phone-l">
						身份证号
					</view>
					<view class="phone-r">
						{{revenueDetailsList.user_card}}
					</view>
				</view>
			</view>
		</view>

	</view>
</template>

<script>
	import getOrderDetailListApi from "../../../api/commercial/revenueDetailsApi.js"
	export default {
		data() {
			return {
				token:"",
				orderindex:"",
				memberInfo:false,
				revenueDetailsList:{
					
				},
			};
		},
		onLoad(e){
			this.token = uni.getStorageSync('xxytoken');
			console.log(e)
			if(e.deductId){
				this.orderindex=e.deductId;
				console.log(this.orderindex+111111)
			}else{
				// ????为什么memberInfo没变？
				this.memberInfo=true
				this.orderindex=e.id;
				console.log(this.orderindex+222222)
			}

			// this.token = uni.getStorageSync('xxytoken');
			getOrderDetailListApi.getOrderDetailList({token:this.token,order_index:this.orderindex}).then(res=>{
					console.log(res)
					this.revenueDetailsList=res.result
					this.revenueDetailsList.add_time=this.$timeConvert(res.result.add_time)
			})
		},
		methods:{
			goOrderBranch(e){
				uni.navigateTo({
					url:"../deductionDetails?id="+e.order_index
				})
			}
		}
	}
</script>
<style>
	page {
		height: 100%;
	}
</style>
<style lang="scss" scoped>
	
	.memberInfo{
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #999999;
	}
	.box {
		background-color: #f5f5f5;
		width: 100%;
		height: 100%;

		.banner {
			width: 690rpx;
			background-color: #fff;
			margin: 0 auto;
			margin-top: 30rpx;
			border-radius: 10rpx;

			.banner-h {
				width: 50%;
				margin: 0 auto;

				.img {
					width: 100rpx;
					height: 100rpx;
					margin: 0 auto;
					display: block;
					margin-top: 40rpx;
					margin-bottom: 50rpx;
				}

				.num {

					font-size: 52rpx;
					font-family: PingFang SC;
					font-weight: bold;
					color: #333333;
					text-align: center;
					margin-bottom: 22rpx;
				}

				.date {
					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #333333;
					text-align: center;
				}
			}

			.banner-f {
				margin-top: 100rpx;

				.item {
					display: flex;
					justify-content: space-between;
					margin:  22rpx 22rpx 0 22rpx;

					.item-l {
						font-size: 28rpx;
						font-family: PingFang SC;
						font-weight: 400;
						color: #999999;
					}

					.item-r {
						font-size: 30rpx;
						font-family: PingFang SC;
						font-weight: 500;
						color: #333333;
					}
				}
			}
		}

		.footer {
			width: 690rpx;
			background-color: #fff;
			margin: 0 auto;
			border-radius: 10rpx;

			.name {
				display: flex;
				justify-content: space-between;
				margin-bottom: 20rpx;

				.name-l {
					font-size: 28rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #999999;
					margin-left: 22rpx;
					margin-top: 20rpx;
				}

				.name-r {
					font-size: 30rpx;
					font-family: PingFang SC;
					font-weight: 500;
					color: #333333;
					margin-right: 22rpx;
					margin-top: 20rpx;
				}
			}

			.phone {
				display: flex;
				justify-content: space-between;
				.phone-l {
					font-size: 28rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #999999;
					margin-left: 22rpx;
					margin-bottom: 20rpx;
				}

				.phone-r {
					font-size: 30rpx;
					font-family: PingFang SC;
					font-weight: 500;
					color: #333333;
					margin-right: 22rpx;
					margin-bottom: 20rpx;
				}
			}
		}
	}
</style>
