<template style="height: 100%;">
	<!-- 当会员到期后除了缴纳年费功能页面所有逻辑不可交互 -->
	<view :class="notclick===false?'notClickAll':''"  @click="notclick===false && popInfo()" style="pointer-events: auto;">
		<view class="header">
			<view class="businessImg">
				<img :src="$imgUrl(commercialList.merchant_logo)" alt="">
			</view>
			<view class="businessCore">
				<view class="businessName">{{commercialList.merchant_name}}</view>
				<view class="businessTime">
					营业时间:{{commercialList.merchant_worktime_start}}-{{commercialList.merchant_worktime_end}}</view>
				<view class="businessDue">年费到期时间:{{dueDate}}</view>
				<!-- 判断用户年费是否为永久,如果是则缴纳年费功能不可用并显示为灰 -->
				<view :class="commercialList.expire_time==='永久'?'notclick payAnnualFee':'payAnnualFee'"
					style="pointer-events: auto;" @click.stop="goPayAnnualFee()">续缴年费</view>
			</view>
			<view   style="margin-top: 50rpx;">
				<img src="../../static/退出登录.png" alt="" style="width: 199rpx;height: 70rpx;pointer-events: auto;margin: 0rpx;" @click.stop="log_out">
			</view>
		</view>
		<view class="page-Carousel">
			<img src="../../static/公告.png" alt="" style="width: 32rpx;height: 32rpx;" >
			<swiper class="swiper-item" :indicator-dots="false" :autoplay="true" :duration="500" :vertical="true" circular>
				<swiper-item v-for="(item,i) in carouselCoreList" :key="i" >
					<view class="carousel-swiper-item" @click="goNoticeList(item)">{{item.title}}</view>
				</swiper-item>
			</swiper>
			<view class="Carousel-more">
				<view style="font-size: 24rpx;font-family: PingFang SC;font-weight: 400;color: #333333;" @click="goNotice()">更多>></view>
			</view>
		</view>

		<view class="revenue">
			<view style="border-bottom: 1rpx solid #EDEDED;">
				<view class="revenue-Statistics">
					<view class="fontstyle">营收统计</view>
					<view @click="goDetails()" style="margin-right: 30rpx;">查看所有记录 &nbsp></view>
				</view>
			</view>
			<view class="revenue-number">
				<view class="revenue-item">
					<view>{{revenueMoney.day_money}}</view>
					<view>今日营收</view>
				</view>
				<view class="revenue-item">
					<view>{{revenueMoney.month_money}}</view>
					<view>本月营收</view>
				</view>
				<view class="revenue-item">
					<view>{{revenueMoney.all_money}}</view>
					<view>累计营收</view>
				</view>
			</view>
		</view>

		<view style="background-color: #FFFFFF;margin-top: 30rpx;">
			<view class="fontstyle" style="padding-top: 20rpx;">功能管理</view>
			<view>
				<view class="Function-management-row">
					<view class="Function-management-cloumn" @click="goshopManagement()">
						<img src="../../static/修改_f.png" alt="">
						<view>资料管理</view>
					</view>
					<view class="Function-management-cloumn" @click="goshopAptitude()">
						<img src="../../static/二维码-色块icon 拷贝.png" alt="" >
						<view>查看资质</view>
					</view>
					<view class="Function-management-cloumn" @click="goqr(0)">
						<img src="../../static/二维码-色块icon.png" alt="">
						<view>店铺二维码</view>
					</view>
				</view>

				<view class="Function-management-row">
					<view class="Function-management-cloumn" @click="gocommodityManagement()">
						<img src="../../static/商品管理.png" alt="">
						<view>商品管理</view>
					</view>
					<view class="Function-management-cloumn" @click="goOrderList()">
						<img src="../../static/购买记录.png" alt="">
						<view>订单记录</view>
					</view>
					<view class="Function-management-cloumn" @click="relationBind()">
						<img src="../../static/可用分润.png" alt="" >
						<view>分账授权</view>
					</view>
				</view>

				<view class="Function-management-row" style="padding-bottom: 20rpx;">
					<view class="Function-management-cloumn" @click="goQrBase()">
						<img src="../../static/可用分润 拷贝.png" alt="">
						<view>支付授权</view>
					</view>
					<view class="Function-management-cloumn"></view>
	<!-- 				<view class="Function-management-cloumn">
						<img src="../../static/拓客.png" alt="">
						<view>拓展客户</view>
					</view> -->
					<view class="Function-management-cloumn">
					</view>
				</view>
			</view>
		</view>
		<view>
			<u-modal v-model="qrShow" :content="content" title="请使用支付宝扫码" :content-style="{'text-align':'center'}" >
				<img :src="goQrBaseList" alt="" style="width: 200rpx;height: 200rpx;">
			</u-modal>
		</view>
		<view>
			<u-mask :show="showNews" @click.stop="showNewsFun" style="pointer-events: auto">
				<view style="position: relative;width: 540rpx;height: 700rpx;">
					<view class="noticePopup" @click="goNoticeList(alertNewsList)">
						<view class="alertNewsTitle">
							{{alertNewsList.title}}
						</view>
						<veiw class="alertNewsTime">
							<view>
								时间:{{$timeConvert(alertNewsList.add_time)}}
							</view>
							<view>
								发布人:{{alertNewsList.edit_user}}
							</view>
						</veiw>
						<view  class="noticeContent">
							<rich-text :nodes="alertNewsList.url_content"></rich-text>
						</view>
						<view class="alertNewsBtn" style="border-top: 2rpx solid #F5F5F5;margin-top: 20rpx;">
							查看详情
						</view>
					</view>
					<img src="../../static/closeNews.png" alt="" style="position:absolute;width: 50rpx;height:98rpx;top:990rpx;left:350rpx;z-index: 999999;margin: 0;">
				</view>
			</u-mask>
		</view>
	</view>
</template>

<script>
	import commerciaCentreApi from "../../api/commercial/commerciaCentreApi.js"
	import loginApi from "../../api/login/login.js"
	import agentCenterApi from "../../api/agentCenter/agentCenter.js"
	export default {
		data() {
			return {
				alertNewsList:"",
				showNews:false,
				merchant_id:"",
				commercialList: {
					merchant_name: "正在加载",
					merchant_logo: "",
					merchant_worktime_start: "正在加载",
					merchant_worktime_end: "正在加载",
					expire_time: "正在加载",
				},
				qrList:{},
				carouselCoreList: "test",
				// 营收金额
				revenueMoney:"",
				dueDate: "正在加载",
				notclick: true,
				goQrBaseList:"",
				qrShow:false,
				token:"",
				goodsPhone:""
			}
		},
		created() {

		},
		onLoad(e) {
			this.goodsPhone=uni.getStorageSync("userPhone");
			this.token=uni.getStorageSync("xxytoken");
			// 查询轮播图信息
			commerciaCentreApi.getbanner({region: 4}).then(res => {
				if(res.status==200){
					this.carouselCoreList = res.result;
				}
			});
			// 如果商铺ID存在去获取商铺的信息
				commerciaCentreApi.getCommercial({
					phone:this.goodsPhone
				}).then(res => {
					console.log(res)
					switch (res.status) {
						case 200:
						this.merchant_id=res.result.merchant_id
						// 获取商户营收记录
						var that=this
						commerciaCentreApi.businessRevenue({merchant_id:res.result.merchant_id}).then(res=>{
							if(res.status==200){
								that.revenueMoney=res.result
							}else{
							}
						})
						var dateNowTime = new Date().getTime();
						dateNowTime = parseInt(Number(dateNowTime) / 1000);
						this.commercialList = res.result;
						if (dateNowTime < Number(this.commercialList.expire_time)) {
							this.dueDate = this.$timeConvert(this.commercialList.expire_time, 0)
						} else {
							this.dueDate = "暂未缴纳年费";
							this.notclick = false;
						}
						break;
					}
				});
			// 查询用户强制弹窗
			agentCenterApi.get_alert_news({
				region: "4",
				token: this.token
			}).then(res => {

				if (res.status == 200 && res.result != null) {
					this.alertNewsList = res.result
					this.showNews = true
					if (res.result.title.length > 27) {
						this.alertNewsList.title = res.result.title.substring(0, 27) + "..."
					}
				}
			});
		},
		methods: {
			// 点击消除弹框
			showNewsFun(){
				agentCenterApi.get_alert_news({
					region: "4",
					token: this.token,
					id:this.alertNewsList.id
				}).then(res => {
                    console.log(res.statu)
					if (res.status == 200 ) {
						this.showNews = false
					}else{
						this.showNews = false
					}
				})
			},
			// 点击新闻详情
			goNoticeList(e){
				uni.navigateTo({
					url:"../newsDetail?url="+e.content+'&title='+e.title
					})
			},
			// 去公告页面
			goNotice(){
				uni.navigateTo({
					url:"../newsList?status=4"
				})
			},
			popInfo(){
				uni.showToast({
					title:"会员已到期,功能暂不可用.请点击缴费按钮进行缴费",
					icon:"none"
				})
			},
			// 退出登录功能
			log_out(){
				loginApi.logout({token:this.token}).then(res=>{
					if(res.status==200){
						uni.removeStorageSync("xxytoken");
						uni.removeStorageSync("userPhone");
						uni.reLaunch({
							url:"../welcome/welcome"
						})
					}
				})
			},
			// 请求分账授权
			relationBind(){
				var that =this
				if(this.commercialList.is_bind==0){
						// uni.showToast({
						// 	title:res.message,
						// 	icon:"none"
						// })
						uni.showModal({
						    title: '分账授权',
						    content: '是否进行分账授权',
						    success: function (res) {
						        if (res.confirm) {
									commerciaCentreApi.relation_bind({merchant_id:that.merchant_id}).then(res=>{	
										uni.showToast({
											title:res.message,
											icon:"none"
										})
									})
						        } else if (res.cancel) {
						            uni.showToast({
						            	title:"取消分账授权",
						            	icon:"none"
						            })
						        }
						    }
						});
				
				}else{
					uni.showToast({
						title:"已绑定,请勿重复绑定",
						icon:"none"
					})
				}

			},
			// 获取支付授权二维码
			goQrBase(){
				if(this.commercialList.app_auth_token==""){
					commerciaCentreApi.alipay_get_url({merchant_id:this.merchant_id}).then(res=>{
						if(res.status==200){
							this.goQrBaseList='data:image/png;base64,'+res.result
							this.qrShow=true
							
						}
					})
				}else{
					uni.showToast({
						title:"您已授权,无需重复授权",
						icon:"none"
					})
				}

			},
			// 跳转至店铺二维码或支付授权页面
			goqr(e) {
				this.qrList.id=this.merchant_id
				if (e == 0) {
					this.qrList.title = 0;
					uni.navigateTo({
						url: "./storeQr?con=" + JSON.stringify(this.qrList)
					})
				} else {
					this.qrList.title = 1;
					uni.navigateTo({
						url: "./storeQr?con=" + JSON.stringify(this.qrList)
					})
				}
			},
			// 跳转至订单记录页面
			goOrderList() {
				uni.navigateTo({
					url: "./orderList?id="+this.merchant_id
				})
			},
			// 跳转至商品管理页面
			gocommodityManagement() {
				commerciaCentreApi.merchant_auth_status({merchant_id:this.merchant_id}).then(res=>{
					if(res.status==200){
						uni.navigateTo({
							url: "./commodityManagement?id="+ this.merchant_id
						})
					}else if(res.status==100){
						uni.showToast({
							title:res.message,
							icon:"none"
						})
					}
				})
			},
			// 跳转至缴纳年费页面
			goPayAnnualFee() {
				uni.navigateTo({
					url: "./payAnnualFee?id=" + this.merchant_id
				})
			},
			// 跳转至营收记录页面
			goDetails() {
				uni.navigateTo({
					url: "./deduct/deduct?id=" + this.merchant_id
				})
			},
			// 跳转至商家资质页面
			goshopAptitude(){
				uni.navigateTo({
					url:"./qualification/qualification?id="+this.merchant_id
				})
			},
			// 跳转至商家资料页面
			goshopManagement(){
				uni.navigateTo({
					url:"./shopManagement/shopManagement?id="+this.merchant_id
				})
			}
		}
	}
</script>
<style>
	page{
		height: 100%;
		background-color: #F5F5F5;
	}
</style>
<style scoped>
	.noticeContent{
		font-size: 28rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #999999;
		margin-top: 30rpx;
		width: 480rpx;
		height: 360rpx;
		overflow: hidden;
	}
	.alertNewsBtn {
		font-size: 32rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #4894FF;
		text-align: center;
		width: 100%;
		height: 90rpx;
		line-height: 90rpx;
	}
	
	.alertNewsTime {
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #999999;
	}
	
	.alertNewsTitle {
		height: 70rpx;
		font-size: 32rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #222222;
		margin-bottom: 30rpx;
	}
	
	.noticePopup {
		position: absolute;
		left: 105rpx;
		top:300rpx;
		width: 480rpx;
		height: 640rpx;
		background: #FFFFFF;
		border-radius: 10px;
		padding: 30rpx;
		border-bottom: 2rpx solid #F5F5F5;
	}
	.header {
		background: #FFFFFF;
		display: flex;
		flex-direction: row;
		justify-content: space-between;
	}

	.businessImg>img {
		margin: 60rpx 31rpx;
		width: 139rpx;
		height: 140rpx;
		border-radius: 6rpx;
	}

	.businessCore {
		margin-top: 60rpx;
	}

	.Carousel-more {
		margin-right: 30rpx;
	}

	.businessCore .businessName {
		font-size: 33rpx;
		font-family: PingFang SC;
		font-weight: bold;
		color: #333333;
	}

	.businessCore>view {
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #999999;
		margin-bottom: 20rpx;
	}

	.businessCore>.payAnnualFee {
		height: 50rpx;
		font-size: 24rpx;
		font-family: PingFang SC;
		color: #4794FF;
		line-height: 50rpx;
		text-decoration:underline
	}

	.swiper-item {
		height: 80rpx;
		line-height: 80rpx;
		font-size: 24rpx;
		font-family: PingFang SC;
		color: #333333;
		flex: 1;
	}
	.carousel-swiper-item{
		width: 480rpx;
		white-space: nowrap;
		text-overflow: ellipsis;
		overflow: hidden;
		word-break: break-all;
		padding-left: 20rpx;
	}
	img {
		height: 32rpx;
		width: 32rpx;
		margin: 30rpx 37rpx;

	}
	.page-Carousel {
		background:#DAEAFF;
		display: flex;
		flex-direction: row;
		align-items: center;

	}


	.revenue {
		display: flex;
		flex-direction: column;
		margin-top: 20rpx;
		background: #FFFFFF;
	}

	.revenue-Statistics {
		display: flex;
		flex-direction: row;
		justify-content: space-between;
		height: 68rpx;
		line-height: 68rpx;
	}


	.fontstyle {
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: bold;
		color: #333333;
		margin-left: 30rpx;
	}

	.revenue-Statistics>view:nth-child(2) {
		height: 23rpx;
		font-size: 24rpx;
		font-family: HiraginoSansGB;
		font-weight: normal;
		color: #999999;
		line-height: 66rpx;
	}

	.revenue-number {
		display: flex;
		flex-direction: row;
		height: 136rpx;
		justify-content: space-between;
	}

	.revenue-item {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		margin: 0rpx 58rpx;
	}

	.revenue-item>view:nth-child(1) {
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #333333;

	}

	.revenue-item>view:nth-child(2) {
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #666666;
	}

	.Function-management-row {
		display: flex;
		flex-direction: row;
		justify-content: space-between;
		margin: 0rpx 30rpx;
	}

	.Function-management-cloumn {
		width: 28%;
		display: flex;
		flex-direction: column;
		align-items: center;
		font-size: 26rpx;
	}

	.Function-management-cloumn>img {
		width: 44rpx;
		height: 44rpx;
	}

	.notclick {
		pointer-events: none;
		background-color: #82848A;
	}

	.notClickAll>view {
		pointer-events: none;
	}
</style>
