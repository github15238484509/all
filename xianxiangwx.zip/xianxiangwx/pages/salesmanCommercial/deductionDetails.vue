<template>
	<view>
		<view class="navgation">
			<view class="smallfont margin-left">
				账单总金额(元)
			</view>
			<view class="bigfont margin-left">
				{{price}}
			</view>
		</view>

		<view class="deductionText"><span class="margin-left" style="color:#999999;">扣款详情</span></view>
		<view v-for="(item,index) in deductionDetailsList" :key="item">
			<view style="display: flex;justify-content:space-between;height: 120rpx;align-items:center;margin: 0rpx 30rpx;border-bottom: 2rpx solid #F5F5F5;">
				<view>
					<view class="mouthMoney" style="margin-bottom: 10rpx;">￥{{item.amount}}</view>
					<view class="mouth_date">第{{item.branch_num}}/{{item.all_num}}期 扣款日{{$timeConvert(item.need_pay_time)}}</view>
				</view>
				<view v-if="item.pay_status==0" class="font">待扣款</view>
				<view v-else-if="item.pay_status==1" class="font">未扣款</view>
				<view v-else-if="item.pay_status==2" class="font">已扣款</view>
			</view>
		</view>
	</view>
</template>

<script>
	import deductionDetailsApi from "../../api/commercial/deductionDetailsApi.js"
	export default {
		data() {
			return {
				token:"",
				orderindex:"",
				deductionDetailsList:{},
				price:""
			}
		},
		onLoad(e){
			this.token = uni.getStorageSync('xxytoken');
			console.log(e)
			this.orderindex=e.id
			deductionDetailsApi.getDeductionDetail({token:this.token,order_index:e.id}).then(res=>{
				if(res.status==200){
					console.log(res);
					this.price=res.result.data.price
					this.deductionDetailsList=res.result.branch_list
				}
			})
		},
		methods: {

		}
	}
</script>

<style scoped>
	.font{
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #999999;

	}
	.mouth_date{
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #999999;

	}
	.mouthMoney{
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #333333;
	}
	.margin-left {
		margin-left: 30rpx;
	}

	.navgation {
		height: 176rpx;
		display: flex;
		justify-content: space-around;
		flex-direction: column;
	}

	.smallfont {
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #333333;
	}

	.bigfont {
		font-family: PingFang SC;
		font-size: 56rpx;
		font-weight: bold;
		color: #333333;
	}

	.deductionText {
		height: 50rpx;
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		background-color: #F5F5F5;
		line-height: 50rpx;
	}
</style>
