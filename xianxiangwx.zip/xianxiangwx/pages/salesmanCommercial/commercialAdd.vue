<template>
	<view>
		<view style="width: 100%;">
			<view class="navgationText font">
				<sapn>填写商品信息</sapn>
			</view>
			<view style="background-color: #FFFFFF;">
				<view class="commercialAdd commercialInput">
					<span class="font" style="color: #333333;">商品名称:</span>
					<view style="text-align: right;">
						<input type="text" placeholder="请输入商品名称" class="font-input" v-model="getcomaddPotList.goods_name" placeholder-style="font">
					</view>
				</view class="commercialAdd">
				<view class="commercialAdd commercialInput">
					<span class="font" style="color: #333333;">价格:</span>
					<view style="text-align: right;">
						<input type="number" placeholder="请输入商品价格" class="font-input" v-model="getcomaddPotList.goods_cost" placeholder-style="font">
					</view>
				</view>
				<view class="commercialAdd" style="border-bottom: none;">
					<span class="font" style="color: #333333;">是否支持分期</span>
					<view class="commercialInput" style="text-align: right;" @click="show = true">
						<input type="text" :placeholder="mouthMoney" disabled placeholder-class="font-input" class="font">
						<u-icon name="arrow-right" color="#999999"></u-icon>
						<u-select v-model="show" :list="list" @confirm="selectConfirm"></u-select>
					</view>
				</view>
			</view>
		</view>
		<view style="margin: 22rpx 0;background-color: #FFFFFF; padding: 20rpx 30rpx;" >
			<view style="display: flex;justify-content: space-between ;border-bottom: 2rpx solid #F5F5F5;margin-top: 22rpx;padding-bottom: 35rpx;">
				<view>
					<view class="font" style="color: #333333;margin-bottom: 20rpx;">请上传商品图片</view>
					<view class="font" style="font-size: 22rpx;">1、建议尺寸690*275，图片清晰</view>
					<view class="font" style="font-size: 22rpx;">2、大小不小于500KB</view>
				</view>
				<view>
					<view>
						<u-upload :custom-btn="true" ref="uUpload" :action="action" @on-success="getImgSuccess()" width="130rpx"
							height="130rpx" max-count="1" :file-list="uptImgUrl">
							<view slot="addBtn" class="slot-btn" hover-class="slot-btn__hover" hover-stay-time="150">
								<image src="../../static/addImg.png" class="img" style="width: 130rpx;height: 130rpx;">
								</image>
							</view>
							</u-upload>
					</view>
				</view>
			</view>
			<view>
				<view class="font" style="color: #333333;margin-bottom: 20rpx;padding-top: 30rpx;">服务说明</view>
				<view>
					<textarea value="" placeholder="请输入商品的详细描述" placeholder-class="placeholderStyle" maxlength="-1"
						style="width: 100%;height: 150rpx;" v-model="getcomaddPotList.goods_intro" class="font-input"/>
				</view>
			</view>
		</view>
		<view style="position: fixed;bottom: 30rpx;width: 100%;padding: 0 30rpx;box-sizing: border-box;">
			<button type="primary" style="width: 100%;background-color: #3699FF;" @click="sumbit()">保存</button>
		</view>
	</view>
	</view>
</template>

<script>
	import potCommercialApi from "../../api/commercial/commercialAddApi.js"
	import getCommodityApi from "../../api/commercial/commodityManagementApi.js"
	export default {
		data() {
			return {
				mouthMoney: "请选择",
				show: false,
				list: [{
						value: '0',
						label: '否'
					},
					{
						value: '3',
						label: '分 3 期'
					},
					{
						value: '6',
						label: '分 6 期'
					},
					{
						value: '12',
						label: '分12 期'
					}
				],
				getcomaddPotList: {
					goods_name:"",
					goods_cost:"",
					goods_icon:"",
					goods_intro:""
				},
				comaddPotList: {
					token: "",
					goods_name: "",
					goods_cost: "",
					goods_intro: "",
					goods_type: "",
					goods_icon: ""
				},
				uptImgUrl: "",
				action:this.$uptImgUrl,
				goodsID:"",
			}
		},
		onLoad(e) {
			this.goodsID=e.id
			this.token = uni.getStorageSync('xxytoken');
			if (e.id) {
				console.log(1111)
				this.comaddPotList.goods_id = e.id;
				getCommodityApi.getCommodityDetail({
					token: this.token,
					goods_id: e.id
				}).then(res => {
					console.log(res)
					this.getcomaddPotList.goods_name = res.result.goods_name
					this.getcomaddPotList.goods_icon = res.result.goods_icon
					this.getcomaddPotList.goods_cost = res.result.goods_cost/100
					this.getcomaddPotList.goods_intro = res.result.goods_intro
					this.getcomaddPotList.goods_type = res.result.goods_type
					var a = [{url: ""}];
					a[0].url = this.$imgUrl(res.result.goods_icon);
					console.log()
					this.uptImgUrl = a;
					var mouthtype = res.result.goods_type;
					if (mouthtype == 0) {
						this.mouthMoney = "否"
					} else {
						this.mouthMoney = "该商品支持分" + mouthtype + "期"
					}
				})
			} else {
			}
		},
		methods: {
			sumbit() {
				console.log(this.getcomaddPotList)
				if(this.getcomaddPotList.goods_name==""){
					uni.showToast({
						title:"请输入商品名称",
						icon:"none"
					})
					return
				}
				 if(this.getcomaddPotList.goods_cost==""){
					uni.showToast({
						title:"请输入商品价格",
						icon:"none"
					})
					return
				}
				if(this.mouthMoney=="请选择"){
					uni.showToast({
						title:"请选择是否支持分期",
						icon:"none"
					})
					return
				}
				if(this.getcomaddPotList.goods_icon==""){
					uni.showToast({
						title:"请选择商品图片",
						icon:"none"
					})
					return
				}
				if(this.getcomaddPotList.goods_intro==""){
					uni.showToast({
						title:"请输入商品描述",
						icon:"none"
					})
					return
				}
					this.comaddPotList.token = uni.getStorageSync('xxytoken');
					this.comaddPotList.goods_intro=this.getcomaddPotList.goods_intro
					this.comaddPotList.goods_name=this.getcomaddPotList.goods_name
					this.comaddPotList.goods_type=this.mouthMoney
					this.comaddPotList.goods_icon=this.getcomaddPotList.goods_icon
					this.comaddPotList.goods_cost=this.getcomaddPotList.goods_cost*100
					potCommercialApi.potCommercial(this.comaddPotList).then(res => {
						if (res.status == 200) {
							uni.redirectTo({
								url:"./commodityStatus/commodityStatus?id="+res.result.goods_id
							})
						}
					})
				
			},
			getImgSuccess(res) {
				if (res.code === 0) {
					uni.showToast({
						title: res.msg,
						icon: 'none'
					})
					this.getcomaddPotList.goods_icon = res.result;
					
				} else {
					uni.showToast({
						title: res.msg,
						icon: 'none'
					})
					this.getcomaddPotList.goods_icon = res.result;
				}
			},
			selectConfirm(e) {
				if (e[0].value == 0) {
					this.mouthMoney = "否"
					this.getcomaddPotList.goods_type = 0;
				} else {
					this.getcomaddPotList.goods_type = e[0].value;
					this.mouthMoney = "该商品可分" + e[0].value + "期"
				}
			}
		}
	}
</script>

<style>
	page{background-color: #F5F5F5;}
</style>
<style scoped>
	.font {
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #999999;
	}

	.navgationText {
		margin-left: 30rpx;
		height: 50rpx;
		line-height: 50rpx;
		background-color: ;
	}

	.commercialInput {
		display: flex;
		align-items: center;
	}

	.commercialAdd {
		height: 90rpx;
		line-height: 90rpx;
		display: flex;
		justify-content: space-between;
		margin: 0rpx 30rpx;
		border-bottom: 2rpx solid rgba(245, 245, 245, 0.7);
	}
	.font-input{
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #333333;
	}
	/deep/.placeholderStyle {
		text-align: end;
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #999999;
	}
</style>
