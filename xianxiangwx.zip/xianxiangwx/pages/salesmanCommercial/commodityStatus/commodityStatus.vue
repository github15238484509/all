<template>
	<view class="main-box">
		
		<view class="content" v-if="isShow">
			<view class="content-top">
				<view class="dot">
					
				</view>
				<view class="">
					<view class='line1'>信息提交成功,等待审核</view>
					<view class='line2'>{{$timeConvert(goodsDailList.goods_add_time)}}</view>
				</view>
				
			</view>
			<view class="content-btm" v-if="isFail==4">
				<view class="dot">
					
				</view>
				<view class="">
					<view class='line1'>信息审核失败</view>
					<view class='line2'>{{$timeConvert(goodsDailList.submit_time)}}</view>
					<view class='line3'>
						失败原因：{{goodsDailList.refuse_reason}}  
						<text style="color: #4794FF;margin-left: 10rpx;" @click="goGoodAdd">重新提交</text>
					</view>
				</view>
				
			</view>
		</view>
		<view class="btm">
			审核时间为1-3天，如有疑问请联系客服
		</view>
	</view>
</template>

<script>
	import getCommodityApi from "../../../api/commercial/commodityManagementApi.js"
	export default {
		data() {
			return {
				//这个页面设一个isShow 如果拿到数据 才显示页面  如果拿不到 给个弹框 页面就不出了
				isShow:true,
				isFail:"",
				token:"",
				goodsId:"",
				goodsDailList:{
					goods_add_time:""
				},
			}
		},
		onLoad(e){
			this.token = uni.getStorageSync('xxytoken');
			this.goodsId=e.id;
			getCommodityApi.getCommodityDetail({token:this.token,goods_id:e.id}).then(res=>{
				if(res.status==200){
					this.goodsDailList=res.result
					this.isFail=res.result.goods_status
				}
			})
		},
		methods: {
			goGoodAdd(){
				uni.redirectTo({
					url:"../commercialAdd?id="+this.goodsId
				})
			},
		}
	}
</script>

<style lang="scss" scoped>
		.btm{
			width: 100%;
			position: fixed;
			left: 50%;
			bottom: 20rpx;
			transform: translate(-50%,-50%);
			font-size: 26rpx;
			text-align: center;
			font-weight: 500;
			color: #999999;
		}
		.main-box{
			overflow: hidden;
		}
		.content{
			margin-left: 60rpx;
			position:relative;
			margin-top:50rpx
			
		}
		.content-top{
			display: flex;
			align-items: center;
			margin-top: 50rpx;
			font-size: 24rpx;
			color: #999999;
			.line1{
				font-size: 26rpx;
				color: #333333;
			}
			.line2{
				font-size: 24rpx;
				color: #999999;
			}
		}
		.content-btm{
			display: flex;
			align-items: center;
			margin-top: 65rpx;
			font-size: 24rpx;
			color: #999999;
			.line1{
				font-size: 26rpx;
				color: #333333;
			}
			.line2{
				font-size: 24rpx;
				color: #999999;
			}
			.line3{
				font-size: 24rpx;
					color: #999999;
			}
		}
		.dot{
			width: 20rpx;
			height: 20rpx;
			background: #4794FF;
			border-radius: 50%;
			margin-right: 16rpx;
		}
		.dot-line{
			width: 2rpx;
			height: 80rpx;
			left: 10rpx;
			top: 30%;
			background: #4794FF;
			position: absolute;
		}
</style>

