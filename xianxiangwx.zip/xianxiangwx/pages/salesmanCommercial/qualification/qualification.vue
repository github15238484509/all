<template>
	<view class="box">
		<view class="header">
			<view class="text">
				<view class="text-t">
					营业执照照片
				</view>
				<view class="text-b">
					<view>
						1、需文字清晰、边框完整、露出国徽
					</view>
					<view>
						2、拍复印件需加盖印章，可用有效特许证件代替
					</view>
				</view>
			</view>
			<img :src="$imgUrl(goodsQualificationList.license_image)" alt="" style="width: 130rpx;height: 130rpx;margin-right: 30rpx;">
		</view>
		<view class="header1">
			<view class="header1-l">
				法人代表/经营者
			</view>
			<view class="header1-r">
				<view style="font-size: 26rpx;">
					{{goodsQualificationList.real_name}}
				</view>
			</view>
		</view>
		<view class="header2" style="justify-content: space-between;">
			<view class="header1-l">
				营业执照有效期
			</view>
			<view class="header-c" style="margin-right: 30rpx;">
				<view style="font-size: 26rpx;">{{effectiveDate(goodsQualificationList.license_indate)}}</view>
			</view>
		</view>
		<view class="header" style="margin:20px 0">
			<view class="text">
				<view class="text-t">
					许可证照片<text class="red">*</text>
				</view>
				<view class="text-b">
					<view>
						1、需文字清晰、边框完整、露出国徽
					</view>
					<view>
						2、拍复印件需加盖印章，可用有效特许证件代替
					</view>
				</view>
			</view>
			<view>
				<img :src="$imgUrl(goodsQualificationList.other_card)" alt="" style="width: 130rpx;height: 130rpx;margin-right: 30rpx;">
			</view>
		</view>
		<view class="header">
			<view class="text">
				<view class="text-t">
					法人代表身份证人像面
				</view>
				<view class="text-b">
					<view>
						1、人像面需清晰
					</view>
				</view>
			</view>
			<view><img :src="$imgUrl(goodsQualificationList.front_image)" alt="" style="width: 130rpx;height: 130rpx;margin-right: 30rpx;"></view>
		</view>
		<view class="header">
			<view class="text">
				<view class="text-t">
					法人代表身份证国徽面
				</view>
				<view class="text-b">
					<view>
						1、国徽面需清晰拍出有效期等文字信息
					</view>
				</view>
			</view>
			<view><img :src="$imgUrl(goodsQualificationList.reverse_image)" alt="" style="width: 130rpx;height: 130rpx;margin-right: 30rpx;"></view>
		</view>
		<view class="header">
			<view class="text">
				<view class="text-t">
					法人代表手持身份证件照
				</view>
				<view class="text-b">
					<view>
						1、人像面需清晰拍出人物五官和文字信息
					</view>
					<view>
						2、不可自拍、不可只拍身份证
					</view>
				</view>
			</view>
			<view><img :src="$imgUrl(goodsQualificationList.person_image)" alt="" style="width: 130rpx;height: 130rpx;margin-right: 30rpx;"></view>
		</view>
	</view>
</template>

<script>
	import upimgSingle from "../../../components/upimgSingle.vue"
	import salesmanCenterApi from "../../../api/salesmanCenter/salesmanCenter.js"
	
	export default {
		components: {
			upimgSingle
		},
		data() {
			return {
				goodsQualificationList:{
					
				}
			};
		},
		onLoad(e) {
			console.log(e)
			salesmanCenterApi.shopHome({merchant_id:e.id}).then(res=>{
				if(res.status==200){
					this.goodsQualificationList=res.result
				}
			})
		},
		methods: {
			effectiveDate(e){
				if(e==1){
					return "长期"
				}else{
					return e
				}
			}
		}
	}
</script>




<style>
	page {
		height: 100%;
		background-color: #f5f5f5;
	}
</style>
<style lang="scss" scoped>
	.box {
		padding-bottom: 20rpx;

		.header {
			width: 750rpx;
			height: 200rpx;
			background: #FFFFFF;
			display: flex;
			justify-content: space-between;
			align-items: center;

			.text {
				margin-left: 30rpx;

				.text-t {
					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #333333;
					margin: 5rpx 0 20rpx;

					.red {
						color: #FD635E;
					}
				}

				.text-b {
					font-size: 22rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #999999;

				}

			}

			.img {
				// margin-right: 30rpx;
				width: 130rpx;
				height: 130rpx;
			}
		}

		.header1 {
			// width: 100%;
			height: 100rpx;
			display: flex;
			justify-content: space-between;
			align-items: center;
			background: #FFFFFF;
			margin-top: 2rpx;
			padding:0 30rpx;

			.header1-l {
				font-size: 26rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #333333;

			}
		}

		.header2 {
			// width: 100%;
			height: 100rpx;
			display: flex;
			justify-content: flex-start;
			align-items: center;
			background: #FFFFFF;
			margin-top: 2rpx;
			padding-left: 30rpx;

			.header1-l {
				font-size: 26rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #333333;

			}

			.header-c {
				display: flex;
				justify-content: flex-start;
				margin-left: 120rpx;

				.img {
					width: 36rpx;
					height: 36rpx;
				}

				.text {
					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #333333;
					margin-left: 15rpx;
				}
			}

			.header-r {
				
				.item{
				display: flex;
				justify-content: flex-start;
				align-items: center;
					
					.text {
					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #999999;
					margin-right: 30rpx;
					margin-left: 150rpx;
					}
					.date{
						font-size: 26rpx;
						font-family: PingFang SC;
						font-weight: 400;
						color: #222222;
						margin-left: 100rpx;
						margin-right: 20rpx;
					}
					.img {
					width: 26rpx;
					height: 15rpx;
					}
				}
			}
		}

		.btns {
			display: flex;
			justify-content: space-around;
			margin-top: 160rpx;
			margin-bottom: 50rpx;

			.btn-l {
				width: 690rpx;
				height: 90rpx;
			}

		}
	}

	.dialog {
		width: 500rpx;
		height: 350rpx;
		background: #FFFFFF;
		border-radius: 10rpx;
		overflow: hidden;

		.dia-t {

			font-size: 30rpx;
			font-family: PingFang SC;
			font-weight: 500;
			color: #333333;
			margin: 20rpx auto;
			text-align: center;
			


		}

		.dia-c {
			
			font-size: 26rpx;
			font-family: PingFang SC;
			font-weight: 400;
			color: #999999;
			margin: 0 28rpx;
			display: flex;
			justify-content: space-between;
			align-items: center;
			.ipt{
				width: 260rpx;
			}
		}
		
		.dia-f {
			width: 100%;
			height: 90rpx;

			font-size: 26rpx;
			font-family: PingFang SC;
			font-weight: 400;
			color: #4894FE;
			text-align: center;
			line-height: 90rpx;
			margin-top: 25rpx;
			border-top: 2rpx solid #f5f5f5;

		}

	}
</style>

