<template>
	<view>
		<view style="padding: 30rpx 20rpx;background-color: #F5F5F5;" v-if="getOrderList.data.length>0">
			<view v-for="(item,index) in getOrderList.data" :key="item.order_index" @click="goRevenueDetail(item)"  style="margin-bottom:20rpx;background-color: #FFFFFF;border-radius: 10rpx;height: 240rpx;">
				<view class="navgation">
					<view class="memberimg" style="display: flex;align-items: center;"><img :src="$imgUrl(item.user_photo)" alt="" ></view>
					<view class="font" style="margin:0rpx 17rpx 0rpx 10rpx;">{{item.user_name}}</view>
					<view class="fontsmall">({{item.user_phone}})</view>
				</view>
				<view style="display: flex;justify-content: space-between;margin-top: 30rpx;">
					<view class="fontsmall infonation" >
						<span>产品名称:&nbsp{{item.goods_name}}</span><br>
						<span>购买时间:&nbsp{{$timeConvert(item.gmt_trans)}}</span><br>
						<span>订单编号:&nbsp{{item.out_order_no}}</span>
					</view>
					<view style="display: flex;justify-content: center;flex-direction: column;align-items: center;margin-right: 20rpx;">
						<span class="font" style="font-size: 30rpx;">共￥{{item.price}}</span><br>
						<span class="font" style="color: #999999;" v-if="item.used_pay_type==0">暂未扣款</span>
						<span class="font" style="color: #999999;" v-else>第{{item.used_pay_type}}/{{item.pay_type}}期</span>
					</view>
				</view>
			</view>
		</view>
		<view v-else style="padding: 30rpx;text-align: center;margin-top: 300rpx;">
			<img :src="cdnUrl+'XianxiangUapi/static/datanull.png'" alt="" style="width: 480rpx;height: 360rpx;">
		</view>
	</view>
	
</template>

<script>
	import getOrderListApi from "../../api/commercial/orderListApi.js"
	export default {
		data() {
			return {
                cdnUrl:"",
				memberName:"111",
				memberPhonNumber:"188888888",
				memberImg:"/static/logo.png",
				productName:"1111",
				buyTime:"2222",
				orderNumber:"1111111",
				orderMoney:"5000",
				stageNumber:"04/12",
				orderList:{
					token:"",
					page:"1",
					count:"7"
				},
				getOrderList:{
					data:[]
				}
			}
		},
		onReachBottom(){
			if (this.orderList.page < this.getOrderList.last_page) {
				this.orderList.page++
				this.ajax(this.orderList)
			} else {
				uni.showToast({
					title:"已经到底了!",
					icon:"none"
				})
			}
		},
		onLoad(e) {
            this.cdnUrl=this.$cdnUrl
			this.orderList.token = uni.getStorageSync('xxytoken');
			this.ajax(this.orderList)
		},
		methods: {
			ajax(e){
				getOrderListApi.getOrderList(e).then(res=>{
					if(res.status==200){
						if (this.getOrderList.data.length > 0) {
							this.getOrderList.data = [...this.getOrderList.data, ...res.result.data];
							console.log(this.getOrderList)
						} else {
							if(res.result!=null){
								this.getOrderList = res.result;
								console.log(this.getOrderList)
							}else{
								
							}
						}
					}
				})
			},
			goRevenueDetail(e){
				uni.navigateTo({
					url:"./revenueDetails/revenueDetails?id="+e.order_index
				})
			}
		}

	}
</script>

<style>
	page{background-color: #F5F5F5;}
</style>
<style scoped lang="scss">
	.infonation{
		margin: 0 20rpx 0 20rpx; 
		display: flex;
		flex-direction: column; 
		justify-content: center;
	}
	.memberimg>img{
		width: 60rpx;
		height: 60rpx;
		border-radius: 50%;
		margin:0 20rpx 0 20rpx;
	}
	.navgation{
		border-bottom: 2rpx solid  #F5F5F5 ;
		display: flex;
		align-items: center;
		height: 80rpx;
	}
	.font{
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #333333;
	}
	.fontsmall{
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #999999;
	}
</style>
