<template>
	<view class="main-box">
		<view class="top">
			<view class="top-txt">
				<view class="xline-bet">
					<view class="top-txt-left">
						门店名称
					</view>
					<view class="top-txt-right">
						<input type="text" value="" v-model="goodsList.merchant_name" placeholder="请输入门店名字"
							placeholder-style="font-size:26rpx" />
					</view>
				</view>
				<view class="xline-bet">
					<view class="top-txt-left">
						联系人
					</view>
					<view class="top-txt-right">
						<input type="text" value="" v-model="goodsList.merchant_contacts" placeholder="请输入联系人姓名"
							placeholder-style="font-size:26rpx" />
					</view>
				</view>   
				<view class="xline-bet">
					<view class="top-txt-left">
						联系电话
					</view>
					<view class="top-txt-right">
						<input type="number" maxlength="11" value="" v-model="goodsList.merchant_tel" placeholder="请输入联系人电话"
							placeholder-style="font-size:26rpx" />
					</view>
				</view>
				<view class="xline-bet">
					<view class="area">营业时间</view>
					<view class="timeFrame">
						<view style="display: flex;justify-content: flex-end;">
							<picker mode="time" @change="bindDateChange"  :start="startDate"
								:end="endDate" :class="taking=='开始时间'? 'unact' : 'act' " style="margin-left: 200rpx;">
								{{ taking }}
							</picker>
							<text style="margin-left: 5rpx;margin-right: 5rpx;">—</text>
							<picker mode="time" @change="bindDateChanges"  :start="taking"
								:end="endDate" :class="takingend=='结束时间'? 'unact' : 'act' ">{{ takingend }}</picker>
							<u-icon name="arrow-right" size="28"></u-icon>
						</view>
					</view>
				</view>
				<view class="btm">
					<view class="btm-reason">
						店铺简介:
					</view>
					<view class="btm-text">
						<textarea class="theTextarea" v-model="goodsList.merchant_desp" value="" maxlength="200"
							placeholder="请简单介绍一下门店，最多输入200个字。" placeholder-style="font-size:24rpx;color:#999999" />
					</view>

				</view>
				<view class="xline-bet">
					<view class="top-txt-left">
						门店地址
					</view>
					<view class="top-txt-right" style="display: flex;align-items: center;" @click="choiceAdd">
						<text>{{goodsList.merchant_province_name}}&nbsp{{goodsList.merchant_city_name}}&nbsp{{goodsList.merchant_county_name}}</text>
						<u-picker mode="region" v-model="isChoiceAddShow" :params="params" @confirm="addConfirm"></u-picker>
						<u-icon name="arrow-right" :class="address==''? 'unact' : 'act'" size="28"></u-icon>
					</view>
				</view>
			</view>
		</view>
		<view class="content">
			<view class="add-box">
				<view class="add-box-top" >
					<input type="text" value="" v-model="goodsList.merchant_address" placeholder="请输入详细地址"
						placeholder-style="font-size:26rpx;text-alien:left" />
				</view>
				<view class="add-box-content">
				<map style="width: 100%; height: 288rpx;"
				@tap="getaddress"
				:latitude="latitude"
				:longitude="longitude"
				:markers="position"
				:enable-zoom="false"
				></map>
				</view>
			</view>
			<view class="shop-box">
				<view class="shop-box-left">
					<view class="theline-1">
						店铺logo（1张）
					</view>
					<view class="theline-2">
						1.建议尺寸：500*500
					</view>
					<view class="theline-3">
						2.为保证图片质量，大小不小于500KB
					</view>
				</view>
				<u-upload :custom-btn="true" max-count="1" :action="action" :auto-upload="true" width="130rpx"
					height="130rpx" @on-success="getImgSuccess" @on-remove="removeLogo" :file-list="logo">
					<view slot="addBtn" class="slot-btn" hover-class="slot-btn__hover" hover-stay-time="150">
						<image src="../../../static/upload.png" class="img" style="width: 130rpx;height: 130rpx;">
						</image>
					</view>
				</u-upload>
			</view>

			<view class="" style="padding: 0 30rpx;">
				<view class="xline">

				</view>
			</view>
			<view class="environment-box">
				<view class="environment-box-top">
					<view class="theline-1">
						环境照片（最多上传5张）
					</view>
					<view class="theline-2">
						1.建议比例：5:2，建议尺寸大小：690*275px
					</view>
					<view class="theline-3">
						2.为保证质量，单张大小不小于500KB
					</view>
				</view>
				<view class="environment-box-btm">
					<u-uploadd ref="uUpload" :custom-btn="true" max-count="5" :action="action" :auto-upload="true"
						width="130rpx" height="130rpx" @on-remove="removeArr" @on-success="getImgSuc"  :file-list="environmentalScience">
						<view slot="addBtn" class="slot-btn" hover-class="slot-btn__hover" hover-stay-time="150">
							<image src="../../../static/upload.png" class="img" style="width: 130rpx;height: 130rpx;">
							</image>
						</view>
					</u-uploadd>
				</view>
			</view>
			<view class="" style="padding: 0 30rpx;">
				<view class="xline" style="margin-top: 10rpx;">

				</view>
			</view>

			<view class="uptVideo-box">
				<view class="uptVideo-box-left">
					<view class="theline-1">
						上传视频封面 （选填）
					</view>
					<view class="theline-2">
						1.建议比例：16：9
					</view>
					<view class="theline-3">
						2.为保证质量，建议大小不小于500KB
					</view>
				</view>

				<view>
					<u-upload :custom-btn="true" max-count="1" :action="action" :auto-upload="true" width="130rpx"
						height="130rpx"  :file-list="videoImgPic" @on-remove="removeVideoImg" @on-success="getImgSuccess2()">
						<view slot="addBtn" hover-class="slot-btn__hover" hover-stay-time="150" class="slot-btn" >
							<image src="../../../static/upload.png" class="img" style="width: 130rpx;height: 130rpx;">
							</image>
						</view>
					</u-upload>
				</view>
			</view>
			<view class="" style="padding: 0 30rpx;">
				<view class="xline" style="margin-top: 20rpx;">

				</view>
			</view>

			<view class="uptVideo-box">
				<view class="uptVideo-box-left">
					<view class="theline-1">
						上传视频 （选填）
					</view>
					<view class="theline-2">
						1.建议比例：16：9
					</view>
					<view class="theline-3">
						2.为保证质量，建议大小不小于20M
					</view>
				</view>
				<view class="uptVideo-box-right" style="position: relative;">
						<view slot="addBtn" class="slot-btn" hover-class="slot-btn__hover" hover-stay-time="150">
							<image src="../../../static/upload.png" class="img" style="width: 130rpx;height: 130rpx;" @click="upvideo" v-if="videoUrl==''&&loadingShow==true" ></image>
							<video
								v-if="videoUrl!=''&&loadingShow==true"
								:src="$imgUrl(videoUrl)" 
								controls
								style="height: 130rpx;width: 130rpx;"></video>						
						<u-icon v-if="videoUrl!=''" name="close-circle-fill" color="#333333" size="30" style="position: absolute;bottom: 100rpx;left: 100rpx;" @click="delVideoUrl"></u-icon>
						<u-loading style="position: absolute;" mode="circle"  v-if="loadingShow===false"></u-loading>
						<view style="width: 130rpx;height: 130rpx;background-color: #FFFFFF;" v-if="loadingShow===false"></view>
				</view>
				</view>
			</view>

		</view>
		<!-- <u-picker mode="region" v-model="isChoiceAddShow" @confirm="addConfirm"
			:area-code="[city,city+county,city+county+address]"></u-picker> -->
		<view class="xbtn-blue btn1" @click="modify()">
			保存
		</view>

	</view>
</template>

<script>
	import commerciaCentreApi from "../../../api/commercial/commerciaCentreApi.js"
	export default {
		data() {
			return {
				videoImgPic:"",
				imgArr:[],
				params : {
					province: true,
					city: true,
					area: true
				},
				logo: "",
				videoimg: [],
				environmentalScience:[],
				merchant_id: "",
				goodsList:{},
				goodsPotList: {
					merchant_id:" ",
					merchant_name: "",
					merchant_tel: "",
					merchant_contacts: "",
					merchant_desp: "",
					merchant_worktime_start: "",
					merchant_worktime_end: "",
					merchant_address: "",
					merchant_logo: "",
					video_pic: "",
					video_url: "",
					merchant_image: "",
					merchant_longitude: "",
					merchant_latitude: "",
					merchant_industry:"",
					
				},
				//上传地址
				action: this.$uptImgUrl,
				//店铺名称
				storeName: "",
				//联系人
				name: "",
				//会员手机号
				userPhone: "",
				//商户分类
				industry: "",
				//联系电话
				phone: "",
				//店铺简介
				textareaValue: "",
				//省市区
				address: "",
				//区
				county: "",
				//市
				city: "",
				//省
				province: "",
				// 区ID
				countyid: "",
				//市ID
				cityid: "",
				//省ID
				provinceid: "",
				//详细地址
				addressDetail: "",
				// 店铺图标
				shopLogo: "",
				//环境照片 数组
				envimgs: "",
				//视频路径
				videoUrl: "",
				taking: '开始时间', //营业时间
				takingend: '结束时间',
				open_time: '', //营业时间(集合)
				startDate: '',
				endDate: '',
				isChoiceAddShow: false,
				//文本域的内容
				textValue: "",
				//纬度
				latitude: "",
				//经度
				longitude: "",
				//接受数据的对象
				item: {},
				// 定位点
				position: [{
					latitude: "",
					longitude: "",
				}],
				loadingShow:true
				
			}
		},
		onLoad(e) {
			this.merchant_id = e.id
			commerciaCentreApi.getCommercial({
				merchant_id: e.id
			}).then(res => {
				if (res.status == 200) {
					this.goodsList = res.result
					var a = [{url: ""}];
					a[0].url = this.$imgUrl(res.result.merchant_logo);
					this.logo=a;
					if(res.result.video_pic!=""){
						this.videoImgPic =[{url:""}]
						this.videoImgPic[0].url = this.$imgUrl(res.result.video_pic)
					}else{
						this.videoImgPic=""
					}
					this.latitude=this.goodsList.merchant_latitude
					this.longitude=this.goodsList.merchant_longitude
					this.position[0].latitude=parseFloat(this.goodsList.merchant_latitude)
					this.position[0].longitude=parseFloat(this.goodsList.merchant_longitude)
					this.city = res.result.merchant_province
					this.county = res.result.merchant_city
					this.address = res.result.merchant_county
					this.taking=res.result.merchant_worktime_start
					this.takingend=res.result.merchant_worktime_end
					this.videoUrl=res.result.video_url
					this.goodsPotList.merchant_image = res.result.merchant_image.split(",")
					var c=[{url:""}]
					if(res.result.merchant_image!=""){
						var b=res.result.merchant_image.split(",")
						this.imgArr=b
						for(var i=0;i<b.length;i++){
							this.environmentalScience.push({url:this.$imgUrl(b[i])})
						}
					}else{
						this.environmentalScience=""
					}
				}else{}
			})
		},
		methods: {
			// 删除店铺LOGO
			removeLogo(){
				this.logo=""
			},
			// 删除视频
			delVideoUrl(){
				this.videoUrl=""
			},
			// 获取地区选择的位置
			getaddress() {
				var that=this
				uni.chooseLocation({
					success: function(res) {
						that.longitude=res.longitude
						that.latitude=res.latitude
						that.position[0].longitude=res.longitude
						that.position[0].latitude=res.latitude
						that.goodsList.merchant_address=res.address
					},			
					fail:function(res){
						console.log(res)
						if(res.errMsg=='chooseLocation:fail auth deny')
						uni.showModal({
							title:"请授权位置信息",
							content:"检测到您未打开地理位置权限,请前往开启",
							confirmText:"前往开启",
							showCancel:false,
							success:(res)=>{
								uni.openSetting({
									success:(res)=>{
									}
								})
							}
						})
							// uni.openSetting({
							// 	success:(res)=>{
							// 	}
							// })
							
					}
				});
			},
			//删除图片
			removeArr(index){
				this.imgArr.splice(index,1);
			},
			// 删除视频图片图片
			removeVideoImg(){
				this.videoImgPic="";
			},
			// 上传商家logo图片成功的回调函数
			getImgSuccess(res) {
				this.logo=res.result
			},
			
			// 上传商家环境图片成功的回调函数
			getImgSuc(res) {
					this.imgArr.push(res.result)
			},
			
			// 上传视频封面图片的回调函数
			getImgSuccess2(res) {
				this.videoImgPic=res.result
			},
			
			// 上传视频的方法 具体参考wx API文档
			upvideo(){
				this.loadingShow=false
				var that = this;
				// 选择文件
				wx.chooseVideo({
					sourceType:["album"],
					success(res){
						// 上传文件
						wx.uploadFile({
							url:that.action,
							filePath:res.tempFilePath,
							name:"file",
							success(res){
								console.log(res)
								that.videoUrl=JSON.parse(res.data).result
								that.loadingShow=true
							},
							fail(res){
								that.loadingShow=true
								uni.showToast({
									title:"视频上传失败!请重新上传",
									icon:"none"
								})
							}
						})
					},
					fail(){
						that.loadingShow=true
					}
				})
			},
			
			// 点击保存出发的事件
			modify() {
				if(this.loadingShow==false){
					uni.showToast({
						title:"视频正在上传，请稍后",
						icon:"none"
					})
					return
				}if(this.goodsList.merchant_name==''){
					uni.showToast({
						title:"请输入店铺名称",
						icon:"none"
					})
					return
				}if(this.goodsList.merchant_contacts==''){
					uni.showToast({
						title:"请输入联系人姓名",
						icon:"none"
					})
					return
				}if(this.goodsList.merchant_tel==''){
					uni.showToast({
						title:"请输入联系电话",
						icon:"none"
					})
					return
				}if(this.takingend==''||this.taking==""){
					uni.showToast({
						title:"请选择营业时间",
						icon:"none"
					})
					return
				}if(this.goodsList.merchant_desp==''){
					uni.showToast({
						title:"请输入店铺简介",
						icon:"none"
					})
					return
				}if(this.logo==''||this.logo==[]){
					uni.showToast({
						title:"请上传店铺LOGO图片",
						icon:"none"
					})
					return
				}if(this.imgArr==''||this.imgArr==[]){
					uni.showToast({
						title:"请上传店铺环境图片",
						icon:"none"
					})
					return
				}if(this.goodsList.merchant_address==''){
					uni.showToast({
						title:"请输入店铺详细地址",
						icon:"none"
					})
					return
				}
				else{
					//修改商户需要传的参数
					this.goodsPotList.merchant_id=this.merchant_id
					this.goodsPotList.merchant_industry=this.goodsList.merchant_industry
					this.goodsPotList.merchant_name=this.goodsList.merchant_name
					this.goodsPotList.merchant_address=this.goodsList.merchant_address
					this.goodsPotList.merchant_contacts=this.goodsList.merchant_contacts
					this.goodsPotList.merchant_desp=this.goodsList.merchant_desp
					this.goodsPotList.merchant_latitude=this.goodsList.merchant_latitude
					this.goodsPotList.merchant_worktime_end=this.takingend
					this.goodsPotList.merchant_worktime_start=this.taking
					this.goodsPotList.merchant_tel=this.goodsList.merchant_tel
					this.goodsPotList.merchant_latitude=this.goodsList.merchant_latitude
					this.goodsPotList.merchant_longitude=this.goodsList.merchant_longitude
					if(this.provinceid!=""&&this.cityid!=""&&this.countyid!=""){
						this.goodsPotList.merchant_province=this.provinceid
						this.goodsPotList.merchant_city=this.cityid
						this.goodsPotList.merchant_county=this.countyid
					}else{
						this.goodsPotList.merchant_province=this.goodsList.merchant_province
						this.goodsPotList.merchant_city=this.goodsList.merchant_city
						this.goodsPotList.merchant_county=this.goodsList.merchant_county
					}
					// 处理拼过https头的图片(该参数为商户logo和视频封面)
					if(typeof(this.videoImgPic)=='object'){
						var videoimgType=this.videoImgPic[0].url.toString()
					}else{
						var videoimgType=this.videoImgPic
					}
					if(videoimgType!=""){
						this.goodsPotList.video_pic=this.$delimgUrl(videoimgType)
					}else {
						this.goodsPotList.video_pic=""
					}
					if(this.logo[0].url){
						this.goodsPotList.merchant_logo=this.$delimgUrl(this.logo[0].url)
					}else{
						this.goodsPotList.merchant_logo=this.$delimgUrl(this.logo)
					}
					this.goodsPotList.video_url=this.videoUrl
					// 处理商户环境图片
					var shopimgs=this.imgArr
					this.goodsPotList.merchant_image=shopimgs.toString()
					// 发送ajax请求
					commerciaCentreApi.saveCommercial(this.goodsPotList).then(res=>{
						if(res.status==200){
							uni.showToast({
								title:"修改成功!",
								icon:"success"
							})
							uni.redirectTo({
								url:"../commercialCentre?merchant_id="+this.merchant_id
							})
						}else {
							uni.showToast({
								title:res.message,
								icon:"none"
							})
						}
					})
				}

			},
			// 开始时间
			bindDateChange(e) {
				console.log(e)
				this.taking = e.target.value;
			},
			// 结束时间
			bindDateChanges(e) {
				this.takingend = e.target.value;
			},
			choiceAdd() {
				this.isChoiceAddShow = true
			},
			// 选择城市列表确认的回调函数
			addConfirm(e) {
				this.goodsList.merchant_province_name=e.province.label
				this.goodsList.merchant_city_name=e.city.label
				this.goodsList.merchant_county_name=e.area.label
				console.log(this.goodsList)
				this.county = e.area.label.replace(/(省|市|自治区|自治州|县|区|辖)/g,'')
				this.city = e.city.label.replace(/(省|市|自治区|自治州|县|区|辖)/g,'')
				this.province = e.province.label.replace(/(省|市|自治区|自治州|县|区|辖)/g,'')
				commerciaCentreApi.getCityId({city_name:this.province}).then(res=>{
					if(res.status==200){
						this.provinceid=res.result.region_id
					}
				})
				commerciaCentreApi.getCityId({city_name:this.city}).then(res=>{
					if(res.status==200){
						this.cityid=res.result.region_id
					}
				})
				commerciaCentreApi.getCityId({city_name:this.county}).then(res=>{
					if(res.status==200){
						this.countyid=res.result.region_id
						console.log(this.provinceid)
						console.log(this.cityid)
						console.log(this.countyid)
					}
				})
				
			},
			//点击获取经纬度
			dianji(res){
				console.log(res);
			}
		}
	}
</script>

<style scoped lang="scss">
	.u-list-item {
		margin: 0;
	}
	.main-box {

		// background-color: red;
		.top {
			width: 690rpx;
			margin: 0 auto;
		}

		.timeFrame {
			color: #999999;
			font-size: 26rpx;
			display: flex;
			align-items: center;


		}

	}
	.xbtn-blue {
		width: 690rpx;
		height: 90rpx;
		background-color: #4894FE;
		color: #FFFFFF;
		text-align: center;
		line-height: 90rpx;
		font-size: 36rpx;
		border-radius: 10rpx;
		margin-top: 30rpx;

	}

	/* 白底按钮 */
	.xbtn-white {
		width: 690rpx;
		height: 90rpx;
		background-color: #FFFFFF;
		color: #4794FF;
		border: 1rpx solid #4794FF;
		border-radius: 10rpx;
		text-align: center;
		line-height: 90rpx;
		font-size: 36rpx;

	}

	/* 高度90 between对齐 带下边框 */
	.xline-bet {
		height: 83rpx;
		display: flex;
		align-items: center;
		justify-content: space-between;
		border-bottom: 1rpx solid #F5F5F5;
	}

	/* 高度90 between对齐 不带下边框  用于末尾元素*/
	.xline-bet-end {
		height: 83rpx;
		display: flex;
		align-items: center;
		justify-content: space-between;
	}

	.xblack {
		color: #333333;
	}

	.xgray {
		color: #666666;
	}

	.xline {
		width: 100%;
		height: 1rpx;
		background-color: #F5F5F5
	}

	.xline20 {
		width: 100%;
		height: 20rpx;
		background-color: #F5F5F5
	}

	.xline20fff {
		width: 100%;
		height: 10rpx;
		background-color: #FFFFFF
	}

	.xbt {
		display: flex;
		align-items: center;
		justify-content: space-between;
	}

	.xev {
		display: flex;
		align-items: center;
		justify-content: space-evenly;
	}

	.xal {
		display: flex;
		align-items: center;

	}

	.xflex {
		display: flex;
	}

	.top-txt {
		text-align: right;
	}

	.top-txt-left {
		font-size: 26rpx;
	}

	.top-txt-right {
		font-size: 26rpx;
	}

	.timeFrame {
		font-size: 26rpx;
	}

	.area {
		font-size: 26rpx;
	}

	.unact {
		color: #999999;
	}

	.act {
		color: #333333;
	}

	.btm {
		width: 690rpx;
		height: 300rpx;
		background-color: #FFFFFF;

		// padding: 0 30rpx;
		.btm-text {
			text-align: left;
			position: relative;
			width: 690rpx;
			height: 200rpx;
			background: #F5F5F5;
			border-radius: 10rpx;

			overflow: hidden;

			text {
				width: 100%;
			}

			.theTextarea {
				padding: 10rpx 20rpx 0;
				width: 100%;
				height: 100%;
				font-size: 26rpx;
				font-family: PingFang SC;
				font-weight: 400;
			}
		}

		.btm-reason {
			text-align: left;
			height: 75rpx;
			line-height: 75rpx;
			font-size: 24rpx;
		}
	}

	.content {

		.add-box {
			.add-box-top {
				height: 103rpx;
				padding: 0 30rpx;
				display: flex;
				flex-wrap: wrap;
				align-items: center;
				font-size: 26rpx;

				input {
					width: 690rpx;
					overflow: hidden;
				}
			}

			.add-box-content {
				width: 730rpx;
				margin: 0 auto;
				height: 288rpx;
			}
		}

		.shop-box {
			height: 196rpx;
			padding: 0 30rpx;
			margin-top: 30rpx;
			display: flex;
			align-items: center;
			justify-content: space-between;

			.shop-box-left {
				height: 100%;
				display: flex;
				flex-direction: column;
				justify-content: space-evenly;
				text-align: left;

			}

			.shop-box-right {
				width: 130rpx;
				height: 130rpx;
				background-color: pink;
			}
		}
	}

	.environment-box {
		// height: 315rpx;
		padding: 0 30rpx;

		.environment-box-top {
			height: 156rpx;
			display: flex;
			flex-direction: column;
			justify-content: space-evenly;
		}
	}

	.theline-1 {
		font-size: 26rpx;
		color: #222222;
	}

	.theline-2 {
		font-size: 24rpx;
		color: #999999;
	}

	.theline-3 {
		font-size: 24rpx;
		color: #999999;
	}

	.slot-btn {
		// width: 329rpx;
		height: 140rpx;
		display: flex;
		justify-content: center;
		align-items: center;
		// background: rgb(244, 245, 246);
		border-radius: 10rpx;
	}

	.slot-btn__hover {
		background-color: rgb(235, 236, 238);
	}

	.uptVideo-box {
		display: flex;
		justify-content: space-between;
		align-items: center;
		margin-top: 20rpx;
		padding: 0 30rpx;
		height: 130rpx;
		.uptVideo-box-left {
			display: flex;
			height: 100%;
			flex-direction: column;
			justify-content: space-around;
		}

		.uptVideo-box-right {
			// width: 130rpx;
			// height: 130rpx;
			// background-color: pink;

		}
	}

	.btn1 {
		margin: 80rpx auto;
		margin-bottom: 20rpx;
	}

	.slot-btn {
	}
</style>
