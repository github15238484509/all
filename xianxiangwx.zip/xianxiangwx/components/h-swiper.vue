<template>
	<view class="hswiper">
		<swiper class="swiper" circular :indicator-dots="true" :autoplay="false" :duration="duration" indicator-active-color="#ffffff":style="{height:swiperHeight+'rpx',width:swiperWidth+'rpx'} " @change=swiperChange>

			<swiper-item v-for="(item,index) in swiperList" :key="index">
				<view class="swiper-item ">
					<!-- 如果containVideo为真 第一条显示视频 -->
					<video :src="item" v-if="containVideo&&index==0" loop='true' :enable-progress-gesture="false" id="theVideo" :poster="coverImg1"></video>
					
					<!-- 如果containVideo 为真 index为0的图片不显示 -->
					<image :src="item" mode="aspectFill" v-if="containVideo==true&&index!=0"></image>
					
					<!-- 如果containVideo为假 上面一条不生效 图片全部显示-->
					<image :src="item" mode="aspectFill" v-if="containVideo==false"></image>
					

				</view>

			</swiper-item>




		</swiper>

	</view>
</template>

<script>
	// 适用于第一个是视频 其余是图片的场景   只处理了轮播宽高 数据引入   其余轮播点样式之类未处理  
	//处理了轮播滑动后 视频暂停
	//swiperList  swiper列表 里面要有src 例如
	// swiperList: ["src","src","src"],   第一个是视频
	//swiperHeight 轮播高度  传值不能加rpx  例如 ：swiperHeight=300   默认值275
	//swiperWidth 轮播宽度  传值不能加rpx  例如 ：swiperWidth=690   默认值750
	//coverImg 是视频封面图
	// 传值的时候 传一个containVideo=“isContainVideo”  在data里声明一个isContainVideo  默认值为false
	//对视频地址进行if判断   如果有地址 把地址push进数组  并且把isContainVideo变为true
	//在if判断过添加视频后 下面对图片数组进行foreach 把图片地址用cdn拼接以后push进去
	
	export default {
		
		props: {
			imgList: {
				type: Array,
				required: true
			},
			videoSrc:{
				type:String,
				default:""
			},
			//swiper高度  默认275
			swiperHeight: {

				default: 275
			},
			swiperWidth:{
				default:750
			},
			//视频封面图
			coverImg:{
				type:String,
				default:""
			},
			//默认没有视频
			
			//containVideo 是否含有视频 如果有视频还是传第一个是视频 剩下的是图片的数组
			//如果没有视频 只传图片数组
			// containVideo:{
			// 	type:Boolean,
			// 	default:false
			// },
			// cdnUrl 路径
			cdnUrl:{
				type:String,
				default:""
			},
			test:{
				type:String,
				default:""
			}
		},
	
	
		created() {
			
			
			
			
			
		},
		data() {
			return {
				
				duration: 500,
				isConttainVideo:false,
				//拼接过的 图片和视频数组
				swiperList:[],
				//用于暂存数组
				arr:[],
				// 是否包含视频
				containVideo:false,
				coverImg1:"",
				imgList1:[],
				theNum:111
			
			};
		},
		methods:{
			swiperChange(e){
				let swiperIndex=e.detail.current;
				//如果下标不为0   拿视频上下文对象 暂停视频
				if(swiperIndex!=0){
					uni.createVideoContext('theVideo').pause()
					 
					 
				}
				
			},
			
			imgUrl(url){
			  let str = RegExp('http');
			  let newUrl;
			  //通过三元运算符进行判断该图片是否含有http域名，没有就拼接上去
			  str.test(url) ? newUrl = url : newUrl = this.cdnUrl + url;
			  return newUrl
			}
		},
		 watch: {
			 //如果有视频链接  从最前面插入 组成新数组   如果没有视频链接 swiperList就是图片数组
		  
			
		    imgList:function (e){
					this.imgList1=JSON.parse(JSON.stringify(e))
				if(this.videoSrc){
					this.imgList1.unshift(this.videoSrc)
					console.log(233)
					this.swiperList=this.imgList1
					this.containVideo=true
				}else{
					this.swiperList=this.imgList1
				}
				// 如果有cdn 拼接cdn 
				if(this.cdnUrl){
					
					this.swiperList.forEach(ele => {
						let newUrl= this.imgUrl(ele)
						this.arr.push(newUrl)
						
					})
					this.swiperList=this.arr
					this.coverImg1=this.imgUrl(this.coverImg)
				}else{
					this.coverImg1=this.coverImg
				}
				console.log(this.swiperList)
				
			}
			  // deep:true //true 深度监听
		  },
	}
</script>

<style lang="scss" scoped>
	.swiper {

		

	}

	.swiper-item {
		
		height: 100%;
		display: block;
		width: 100%;

		text-align: center;

		image {
			width: 100%;
			height: 100%;
		}
	}
	video{
		width: 100%;
		height: 100%;
		border-radius: 10rpx;
	}
</style>
