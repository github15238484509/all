<template>
	<web-view :src="src"></web-view>
</template>
<script>
	import registerXy from '../../../api/login/login.js'
	export default {
		data(){
			return {
				src:''
			}
		},
		onLoad(){
			registerXy.app_agreement({
				type:"1"
			}).then(res=>{
				 // console.log(this.$cdnUrl + res.result.agreement_content);
				this.src = this.$cdnUrl + res.result.agreement_content;
			})
		}
	}
</script>

<style>
</style>
 