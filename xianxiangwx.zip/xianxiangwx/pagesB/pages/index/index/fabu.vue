<template>
    <view class="box">
        <textarea v-model="reason" value="" placeholder="请编辑您要发布的内容" placeholder-style="font-size:24rpx;padding:20rpx"
            style="width: 690rpx;height: 300rpx; margin: 0 auto;margin-top: 20rpx;background-color: #fff;border-bottom: 2rpx solid #F5F5F5;" />
        <view class="kkkkk" style="margin-left: 25rpx;margin-top: 22rpx;">
            <u-uploadd ref="uUpload" :custom-btn="true" max-count="9" :action="action" :show-progress="false"
                :auto-upload="true" width="220rpx" height="220rpx" @on-success="imgChange1" @on-remove="removeArr"
                :file-list="envimgs">
                <view slot="addBtn" style="box-sizing: border-box;width: 220rpx;height: 220rpx;" class="slot-btn"
                    hover-class="slot-btn__hover" hover-stay-time="150">
                    <image src="../../../static/addImg.png" class="img" style="width: 100%;height: 100%;"></image>
                </view>
            </u-uploadd>


        </view>
        <view class="xbtn-blue" style="margin: 0 auto;position: fixed;left: 30rpx;bottom: 30rpx;" @click="fabu">
            立即发布
        </view>
    </view>
</template>

<script>
    import indexApi from "../../../../api/index/indexList.js"
    export default {
        data() {
            return {
                reason: "",
                src: '',
                imgArr: [],
                //上传地址
                action: this.$uptImgUrl

            }
        },
        methods: {
            imgChange1(e) {
                console.log("得到的返回值")
                console.log(e)
                // this.files = this.$refs.uUpload.lists;
                this.imgArr.push(e.result)
                console.log(this.imgArr)
            },
            removeArr(index) {
                this.imgArr.splice(index, 1);
            },
            fabu() {
                if (this.reason == "") {
                    uni.showToast({
                        title: '请编辑您要发布的内容~',
                        icon: 'none'
                    });
                    return;
                }
                this.imgArr = this.imgArr.toString()
                indexApi.addTokerCircle({
                    content: this.reason,
                    image: this.imgArr,
                    video: ""
                }).then(res => {
                    console.log(res)
                    if (res.status == 200) {
                        uni.reLaunch({
                            url: "./releas_success"
                        });
                    } else {
                        uni.showToast({
                            title: res.message,
                            icon: 'none'
                        })
                    }
                })
            }
        }
    }
</script>

<style lang="scss" scoped>

</style>
