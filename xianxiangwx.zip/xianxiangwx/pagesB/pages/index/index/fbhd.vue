<template>
	<view class="box">
		<view v-if="list.length==0" style="text-align: center;padding-top: 207rpx;"> <img
				:src="cdnUrl+'XianxiangUapi/static/datanull.png'" alt="" style="width: 470rpx;height: 345rpx;"></view>
		<checkbox-group @change="checkboxChange" style="padding: 0 30rpx;margin-bottom: 15rpx;">
			<label class="uni-list-cell uni-list-cell-pd" v-for="(item,index) in list" :key="index">
				<view class="card">
					<checkbox :value="item.merchant_id" color="#4794ff" />
					<view class="card-c">
						<view class="left1">
							<image :src="$imgUrl(item.merchant_logo)" mode="aspectFill"></image>
						</view>
						<view class="right1">
							<view class="rline1">
								{{item.merchant_name}}
								
							</view>
							<view class="rline2">
								{{item.merchant_address}}
							</view>
							<view class="rline3">
								<image src="../../../static/time.png" mode="aspectFill"></image>
								<text class="line-txt">{{item.merchant_worktime_start}}-{{item.merchant_worktime_end}}</text>
							</view>
							<view class="rline4">
								<text v-if="item.merchant_expire_type=='2'" class="line-txt" style="color:red;">年费到期时间:{{$time(item.expire_time,0)}}</text>
								<text v-if="item.merchant_expire_type=='0'" class="line-txt" style="color:#4794FF;">年费到期时间:{{$time(item.expire_time,0)}}</text>
								<text v-if="item.merchant_expire_type=='1'" class="line-txt" style="color:red;">暂未缴纳年费</text>
							</view>
						</view>
					</view>
				</view>

			</label>
		</checkbox-group>
		<view class="btn" @click="go">
			<view class="">
				确定
			</view>
		</view>
		<u-loadmore v-if="list.length!=0" :status="status" :load-text="loadText" @loadmore="clkloadMore" style="margin-bottom: 86rpx;"/>
	</view>
</template>

<script>
	import indexApi from "../../../../api/index/indexList.js"
	export default {
		data() {
			return {
				list: [],
				ids: "",
				//一页多少条
				count: 10,
				//当前页数
				page: 1,
				status: 'loading',
				totalPage: 1,
				loadText: {
					loadmore: '上拉或点击加载更多',
					loading: '努力加载中',
					nomore: '没有更多了'
				},
				cdnUrl:""
			}
		},
		onLoad() {
			this.cdnUrl=this.$cdnUrl
			this.init()
		},
		methods: {
			go(){
				if(this.ids==""){
					uni.showToast({
						title:"请选择商家",
						icon:"none"
					})
					return
				}
				uni.navigateTo({
					url:"./fbhd2?ids="+this.ids
				})
			},
			init() {
				indexApi.user_merchant_list({
					type: "1",
					page: this.page,
					count:this.count
				}).then(res => {
					console.log(res)
					if (res.status == 200) {
						this.list = res.result.data
						//最大页数
						this.totalPage = res.result.last_page
						if (this.totalPage > this.page) {
							this.status = "loadmore"
						}
						if (this.totalPage == this.page) {
							this.status = "nomore"
						}
					} else {
						this.shopList = []
						this.status = "nomore"
						uni.showToast({
							title: res.message,
							icon: 'none'
						})
					}
				})
			},
			clkloadMore() {
				this.reachBtm()
			},
			//下拉加载更多
			onReachBottom() {
				this.reachBtm()
			
			},
			
			reachBtm() {
			
				if (this.page < this.totalPage) {
					this.status = 'loading';
					this.page++;
					indexApi.user_merchant_list({
							type: "1",
							page: this.page,																					
							count: this.count							
						})
						.then(res => {
							//如果有数据 重新赋值  如果没有 清空
							if (res.result) {
			
								//最大页数
								this.totalPage = res.result.last_page
								this.list = this.list.concat(res.result.data)
			
								this.status = "loadmore"
			
							} else {
								this.status = "nomore"
							}
			
						})
				} else {
					this.status = "nomore"
				}
			
			
			},
			checkboxChange: function(e) {
				console.log(e);
				var items = this.list,
					values = e.detail.value;
				this.ids = values.toString()
				console.log(this.ids);
				for (var i = 0, lenI = items.length; i < lenI; ++i) {
					const item = items[i]
					if (values.includes(item.merchant_id)) {
						this.$set(item, 'checked', true)
					} else {
						this.$set(item, 'checked', false)
					}
				}
			}
		}
	}
</script>

<style lang="scss" scoped>
	.box {
		.uni-list-cell.uni-list-cell-pd {
			width: 100%;
			height: 180rpx;
			
			.card {
				display: flex;
				justify-content: flex-start;
				align-items: center;
				margin-top:30rpx ;
				margin-bottom: 20rpx;
				.card-c {
					height: 180rpx;
					display: flex;
					justify-content: flex-start;
					align-items: center;
					.left1 {
						width: 180rpx;
						height: 180rpx;
						border-radius: 10rpx;
						margin-left: 11rpx;
						overflow: hidden;
					
						image {
							width: 180rpx;
							height: 180rpx;
						}
					}
					
					.right1 {
						margin-left: 22rpx;
						width: 380rpx;
						height: 100%;
						display: flex;
						flex-direction: column;
						justify-content: space-evenly;
					
						.rline1 {
							font-size: 30rpx;
							display: flex;
							justify-content: space-between;
					
							.img {
								width: 44rpx;
								height: 44rpx;
					
								border-radius: 50%;
					
							}
						}
					
						.rline2 {
							font-size: 24rpx;
							color: #666666;
							white-space: nowrap;
							text-overflow: ellipsis;
							overflow: hidden;
							word-break: break-all;
					
						}
					
						.rline3 {
							width: 500rpx;
							font-size: 24rpx;
							display: flex;
							align-items: center;
					
							image {
								width: 28rpx;
								height: 28rpx;
								margin-left: 1rpx;
							}
						}
					
						.rline4 {
							width: 500rpx;
							font-size: 24rpx;
							display: flex;
							align-items: center;
					
							// padding-left: 5rpx;
							image {
								width: 20rpx;
								height: 27rpx;
								margin-left: 6rpx;
							}
					
							.refuse {
								display: flex;
								align-items: center;
								justify-content: center;
					
								font-size: 24rpx;
								font-family: PingFang SC;
								font-weight: 400;
								color: #FE5E5E;
					
								.fff {
									border-bottom: 1rpx solid #FFF;
								}
					
								.ml {
									margin-left: 10rpx;
									border-bottom: 1rpx solid #FE5E5E;
								}
							}
						}
					
					}
				}
			}


		}

		.btn {
			position: fixed;
			background: #3798FF;
			left: 0;
			bottom: 0;
			width: 100%;
			height: 86rpx;
			display: flex;
			justify-content: center;
			align-items: center;

			view {

				font-size: 30rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: #FFFFFF;
			}
		}
	}
</style>
