<template>
	<view class="main-box">
		<view class="swiper-box">
			<swiper :indicator-dots="true" :autoplay="false" :interval="3000" :duration="1000"
				style="{height:276rpx,width:690rpx}">
				<swiper-item v-for="item in  BannerimgList">
					<view class="swiper-item">
						<image :src="$imgUrl(item)" mode="aspectFill"></image>
					</view>
				</swiper-item>

			</swiper>
			<!-- <hswiper swiperHeight="276" :cdnUrl="theCdn" :coverImg="coverUrl" :imgList="BannerimgList" :videoSrc="videoUrl"
			 :swiperWidth="690" :test="test"></hswiper> -->
		</view>
		<!--店铺是否收藏按钮  -->
		<view class="shopinfo-box">
			<view class='left'>
				<image :src="$imgUrl(shopObj.merchant_logo)" mode="aspectFill"></image>
			</view>
			<view class='mid'>
				<view class='line1'>{{shopObj.merchant_name ? shopObj.merchant_name : ''}}</view>
				<view class='line2'>
					营业时间：{{shopObj.merchant_worktime_start ? shopObj.merchant_worktime_start : ''}}-{{shopObj.merchant_worktime_end ? shopObj.merchant_worktime_end : ''}}
				</view>
			</view>

			<view class='right'>


				<view class='right-top' v-if="focus==0" @click="tofocus">收藏</view>
				<view class='right-bottom' v-if="focus==1" @click="todelfocus">已收藏</view>

			</view>
		</view>
		<view class="xline" style="height: 20rpx;">

		</view>
		<!-- 店铺简介 -->
		<view class="addr-box">
			<view class='line1' style="position: relative;">
				<view class='left' >店铺简介：</view>
				<view class="right1">
					{{shopObj.merchant_desp ? shopObj.merchant_desp : ''}}</view>
			<!-- 	<view style="position: absolute;right: 10rpx;color: #007AFF;bottom: -30rpx;" @click="checkShowText">
					{{showText==1?'展开':'收起'}}</view> -->
			</view>
			<view class='line2' @click="toMap">
				<view class='left'>地 <text style="margin-left: 50rpx;">址：</text></view>
				<view class='right1'>
					<view class="">
						{{shopObj.merchant_province_name ? shopObj.merchant_province_name : ''}}{{shopObj.merchant_city_name ? shopObj.merchant_city_name : ''}}{{shopObj.merchant_county_name ? shopObj.merchant_county_name : ''}}{{shopObj.merchant_address ? shopObj.merchant_address : ''}}
						<image src="../../../static/map.png" mode="aspectFill"></image>
					</view>



				</view>

			</view>
			<view class='line3' v-if="isPhone">
				<view class='left'>联系电话：</view>
				<view class='right' style="margin-left: 50rpx;" @click="call">{{shopObj.merchant_tel}}</view>
				<view class="pic" @click="call">
					<image src="../../../static/phoneblue.png" mode="aspectFill"></image>
				</view>
			</view>
		</view>

		<view class="xline" style="height: 20rpx;"></view>
		<view class="goods-box" v-if="goodsList.length>0">

			<view class='line'>
				<image src="../../../static/box-blue.png" mode="aspectFill"></image>店铺服务
			</view>
			<view class="goods-item" v-for=" (item,index) in goodsList" @click="toDetail(item.goods_index)">

				<view class='line2'>
					<image :src="$imgUrl(item.goods_icon)" mode="aspectFill"></image>
				</view>
				<view class='line3'>
					{{item.goods_name}}
				</view>
				<view class='line4'>
					<view class='left'>￥{{item.stage}}</view>
					<view class='mid'>x{{item.goods_type}}期</view>
					<view class='right'>￥{{item.goods_cost}}</view>
				</view>
			</view>
			<view class="more" style="margin: 20rpx 0;">
				<u-loadmore :status="status" :load-text="loadText" @loadmore="clkloadMore" />
			</view>
		</view>
	</view>
</template>

<script>
	// import hswiper from "../../components/h-swiper.vue"
	import shophomeApi from "../../../../api/shop/shophome.js"
	import goodsListApi from "../../../../api/index/indexStoreList.js"
	import collcetApi from "../../../../api/shop/collect.js"
	export default {
		// components: {
		// 	hswiper
		// },
		data() {
			return {
				showText: 0, //控制店铺简介展开收起
				videoUrl: "VlianShopMapi/module/202101/4e20c9f9917a55b183e5419919467ad286af2685.mp4",
				coverUrl: "VlianShopMapi/module/202101/fe368eae53d0c21d59976b8f4836b187d0de034f.png",
				imgUrl: ["VlianShopMapi/module/202101/aa00c7efa554449e3c7f0d40a07ec746a7233f7c.png"],
				theCdn: "",
				shopObj: {},
				BannerimgList: [],
				test: "111",
				longitude: "",
				latitude: "",
				//商家手机
				merPhone: "",
				//是否关注
				focus: "-1",

				token: "",
				//商家id
				merchant_id: "",

				goodsList: [],
				//每页多少条
				count: 10,
				//当前页数
				page: 1,
				status: 'loading',
				totalPage: 1,
				loadText: {
					loadmore: '上拉或点击加载更多',
					loading: '努力加载中',
					nomore: '没有更多了'
				},
				//防止请求还没返回 就又再次触发触底发送请求
				reachFlag: true,
				isPhone:false
			}
		},

		onLoad(options) {
			this.theCdn = this.$cdnUrl
			this.merchant_id = options.mid
			//商户id
			// this.merchant_id=options.merchant_id

			this.token = uni.getStorageSync('xxytoken')

			shophomeApi.shopHome({
				//这里写死先
				merchant_id: this.merchant_id,
				token: this.token,
				phone: 15136482690
			}).then(res => {
				if (res.status == 200) {
					if(res.result.is_own==1){
						this.isPhone=true
					}
					this.shopObj = res.result
					this.shopObj.merchant_desp.length > 60 ? this.showText = 1 : this.showText = 0
					console.log(res.result.merchant_image)

					let newArr = res.result.merchant_image.split(",")
					this.BannerimgList = newArr
					console.log(this.BannerimgList)


					console.log(this.test)
					this.videoUrl = res.result.video_url
					this.coverUrl = res.result.video_pic
					this.longitude = res.result.merchant_longitude
					this.latitude = res.result.merchant_latitude
					this.merPhone = res.result.merchant_tel
					this.focus = res.result.focus
				} else {
					uni.showToast({
						title: res.message,
						icon: "none"
					})
				}

			})


			//拿店铺内商品列表
			goodsListApi.goodsList({
				// token: this.token,
				merchant_id: this.merchant_id,
				// type: "1",
				page: this.page,
				count: this.count
			}).then(res => {
				if (res.result) {
					this.goodsList = res.result.data
					this.totalPage = res.result.last_page
					if (this.totalPage == this.page) {
						this.status = "nomore"
					} else if (this.totalPage > this.page) {
						this.status = "loadmore"
					}
				} else {
					this.status = "nomore"
				}


			})
		},
		onReachBottom() {
			this.reachBtm()

		},
		methods: {
			// 点击控制店铺简介是否展开
			checkShowText(){
				this.showText=!this.showText
			},
			toMap() {
				console.log(1111111111)
				uni.openLocation({
					longitude: Number(this.longitude),
					latitude: Number(this.latitude),
					name: this.shopObj.merchant_name,
					address: this.shopObj.merchant_address
				})
			},
			call() {
				uni.makePhoneCall({
					phoneNumber: this.merPhone,
					success: () => {
						console.log("成功拨打电话")
					}
				})
			},
			toDetail(goodsId) {
				uni.navigateTo({
					url: './goodsDetail?goods_id=' + goodsId,
					// url:'./goodsDetail'

				})

			},

			todelfocus() {
				collcetApi.collect({
					merchant_id: this.merchant_id,
					token: this.token,
					type: 0

				}).then(res => {
					console.log(res)
					if (res.status == 200) {
						this.focus = 0
						console.log(this.focus)
					} else {
						uni.showToast({
								title: res.message,
								icon: "none"
							}


						)
					}


				})
			},
			tofocus() {
				collcetApi.collect({
					merchant_id: this.merchant_id,
					token: this.token,
					type: 1

				}).then(res => {
					if (res.status == 200) {
						this.focus = 1
						console.log(this.focus)
					} else {
						uni.showToast({
								title: res.message,
								icon: "none"
							}


						)
					}
				})
			},
			reachBtm() {


				if (this.page < this.totalPage) {
					this.status = 'loading';
					this.page++;
					goodsListApi.goodsList({
							// token: this.token,
							merchant_id: this.merchant_id,
							// type: "1",
							page: this.page,
							count: this.count
						})
						.then(res => {
							//如果有数据 重新赋值  如果没有 清空
							if (res.result) {

								//最大页数
								this.totalPage = res.result.last_page
								if (this.totalPage > this.page) {
									this.status = "loadmore"
								} else if (this.totalPage == this.page) {
									this.status = "nomore"
								}
								this.goodsList = this.goodsList.concat(res.result.data)



							} else {
								this.status = "nomore"
							}

						})
				} else {
					this.status = "nomore"
				}


			},

			clkloadMore() {
				this.reachBtm()
			},



		}
	}
</script>
<style>
	page {
		background: #FFFFFF
	}
</style>
<style lang="scss" scoped>
	.main-box {}

	.swiper-box {
		margin: 0 30rpx;
		margin-top: 21rpx;
		border-radius: 10rpx;
		overflow: hidden;
	}

	.goods-box {
		margin: 0 30rpx;
		background-color: #FFFFFF;

		.goods-item {

			margin-top: 20rpx;

			border: 1rpx solid #EEEEEE;
			box-shadow: 0rpx 2rpx 2rpx 0rpx rgba(38, 86, 165, 0.06);
			border-radius: 10rpx;
		}

		.line {
			height: 36rpx;
			display: flex;
			align-items: center;
			margin-top: 30rpx;

			image {
				width: 34rpx;
				height: 34rpx;
				margin-right: 10rpx;
			}
		}

		.line2 {
			width: 690rpx;
			height: 276rpx;
			margin-top: 20rpx;
			border-radius: 10rpx 10rpx 0rpx 0rpx;
			overflow: hidden;

			image {
				width: 100%;
				height: 100%;

			}



		}

		.line3 {
			padding: 0 16rpx;
			height: 76rpx;
			line-height: 76rpx;
		}

		.line4 {
			padding: 0 16rpx;
			display: flex;
			align-items: center;
			height: 69rpx;
			line-height: 69rpx;

			.left {
				font-size: 30rpx;
				color: #4794FF;
			}

			.mid {
				font-size: 26rpx;
				color: #85B8FF;
			}

			.right {
				margin-left: 18rpx;
				color: #999999;
				font-size: 30rpx;

				text-decoration: line-through;
			}
		}
	}

	.addr-box {
		margin: 0 30rpx;
		background-color: #FFFFFF;
		font-size: 26rpx;

		.line1 {
			display: flex;
			justify-content: flex-start;
			margin-top: 20rpx;

			.left {
				// width: 166%;
				// margin-right: 10rpx;
			}

			.right {
				overflow: hidden;
				display: -webkit-box;
				-webkit-box-orient: vertical;
				-webkit-line-clamp: 3;
			}

			.right1 {
				width: 70%;
				margin-left: 50rpx;
			}
		}

		.line2 {
			margin-top: 40rpx;
			display: flex;

			.left {
				width: 180rpx;
			}

			.right1 {
				width: 500rpx;
				// display: flex;

				// flex-wrap: wrap;
				line-height: 30rpx;

				image {

					width: 50rpx;
					height: 36rpx;
				}
			}

		}

		.line3 {
			display: flex;
			height: 30rpx;
			margin-top: 20rpx;
			align-items: center;
			margin-bottom: 20rpx;

			.left {}

			.right {
				color: #4794FF;

				text-decoration: underline;
			}

			.pic {
				margin-left: 10rpx;

				image {
					width: 26rpx;
					height: 26rpx;
				}
			}
		}
	}

	.shopinfo-box {
		margin: 0 30rpx;
		display: flex;
		justify-content: space-between;
		margin-top: 20rpx;
		background-color: #FFFFFF;
		margin-bottom: 30rpx;

		.left {
			width: 119rpx;
			height: 120rpx;
			border-radius: 6rpx;

			image {
				width: 100%;
				height: 100%;

			}
		}

		.mid {
			margin-left: -100rpx;

			.line1 {
				margin-top: 8rpx;
				font-size: 36rpx;
			}

			.line2 {
				margin-top: 6rpx;
				color: #999999;
				font-size: 26rpx;
			}
		}

		.right {

			text-align: center;
			line-height: 47rpx;
			display: flex;
			align-items: center;

			.right-top {
				margin-top: 10rpx;
				width: 118rpx;
				height: 47rpx;
				background: #4794FF;
				border-radius: 24rpx;

				font-size: 24rpx;
				color: #FFFFFF;
			}

			.right-bottom {
				margin-top: 10rpx;
				width: 118rpx;
				height: 47rpx;
				background: #FFFFFF;
				border: 1rpx solid #4794FF;
				border-radius: 24rpx;

				font-size: 24rpx;

				color: #4794FF;
			}
		}
	}

	.swiper-item {

		height: 100%;
		display: block;
		width: 100%;

		text-align: center;

		image {
			width: 100%;
			height: 100%;
		}
	}
</style>
