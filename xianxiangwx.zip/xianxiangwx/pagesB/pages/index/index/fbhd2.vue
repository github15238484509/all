<template>
	<view class="box">
		<view class="header">
			<view class="card" v-if="isOne">
				<view class="left1">
					<image :src="$imgUrl(oneObj.merchant_logo)" mode="aspectFill"></image>
				</view>
				<view class="right1" @click="goDetail(oneObj.merchant_id)">
					<view class="rline1">
						{{oneObj.merchant_name?oneObj.merchant_name:""}}

					</view>
					<view class="rline2">
						{{oneObj.merchant_address?oneObj.merchant_address:""}}
					</view>
					<view class="rline3">
						<image src="../../../static/time.png" mode="aspectFill"></image>
						<text style="margin-left: 15rpx;"
							class="line-txt">{{oneObj.merchant_worktime_start?oneObj.merchant_worktime_start:""}}-{{oneObj.merchant_worktime_end?oneObj.merchant_worktime_end:""}}</text>
					</view>
					<view class="rline4">
						<text v-if="oneObj.merchant_expire_type=='2'" class="line-txt"
							style="color:red;">年费到期时间:{{$time(oneObj.expire_time,0)}}</text>
						<text v-if="oneObj.merchant_expire_type=='0'" class="line-txt"
							style="color:#4794FF;">年费到期时间:{{$time(oneObj.expire_time,0)}}</text>
						<text v-if="oneObj.merchant_expire_type=='1'" class="line-txt" style="color:red;">暂未缴纳年费</text>
					</view>
				</view>
				<image src="../../../static/right.png" style="width: 17rpx;height: 32rpx;margin-left: 40rpx;"></image>
			</view>
			<view class="card1" v-if="!isOne">
				<view class="left" v-for="(item,index) in logoList" :key="index">
					<image :src="$imgUrl(item)" class="img"></image>
				</view>
				<view class="right" @click="goAll">
					查看全部>>
				</view>
			</view>

		</view>
		<view class="xline20">

		</view>
		<view class="top-txt">
			<view class="xline-bet">
				<view class="top-txt-left">
					活动名称
				</view>
				<view class="top-txt-right">
					<input type="text" v-model="activityName" placeholder="请输入" placeholder-style="font-size:26rpx" />
				</view>
			</view>
		</view>
		<view class="uptVideo-box">
			<view class="uptVideo-box-left">
				<view class="theline-1">
					活动主图
				</view>
				<view class="theline-2">
					1.建议比例：1：1
				</view>
				<view class="theline-3">
					2.为保证质量，单张大小不小于500KB
				</view>
			</view>

			<view class="uptVideo-box-right">
				<u-upload :custom-btn="true" max-count="1" :action="action" :auto-upload="true" width="130rpx"
					height="130rpx" @on-success="imgChange6" @on-remove="removeVideoImg" :file-list="activityImg">
					<view slot="addBtn" hover-class="slot-btn__hover" hover-stay-time="150" class="slot-btn">
						<image src="../../../static/upload.png" class="img" style="width: 130rpx;height: 130rpx;">
						</image>
					</view>
				</u-upload>
			</view>

		</view>
		<view class="header2">
			<view class="header1-l">
				结束时间
			</view>

			<view class="header-r" @tap="isShow()">
				<view class="item">
					<view class="text" v-if="startDate==''">
						请选择结束时间
					</view>
					<view class="date" v-if="startDate!==''">
						{{startDate}}
					</view>
					<image src="../../../static/down.png" class="img"></image>
				</view>

			</view>
		</view>
		<view class="top-txt">
			<view class="xline-bet">
				<view v-if="oneObj.merchant_expire_type=='2'||oneObj.merchant_expire_type=='1'"
					style="font-size: 24rpx;">
					<view class="top-txt-left" style="text-align: left;">
						单客户金额
					</view>
					<view v-if="rank == 8">
						<image src="../../../static/danger.png" style="width: 24rpx;height: 24rpx;">{{" "+payment_cost}}
					</view>
					</image>
				</view>
				<view v-else class="top-txt-left">
					单客户金额
				</view>
				<view class="top-txt-right">
					<input type="number" v-model="dmoney" :placeholder="lunum" placeholder-style="font-size:26rpx" />
				</view>
			</view>
		</view>
		<view class="top-txt">
			<view class="xline-bet">
				<view class="top-txt-left">
					客户数量
				</view>
				<view class="top-txt-right">
					<input type="number" v-model="knum" placeholder="请输入" placeholder-style="font-size:26rpx" />
				</view>
			</view>
		</view>
		<view class="top-txt">
			<view class="xline-bet">
				<view class="area">客户年龄段</view>
				<view class="timeFrame">
					<!-- @click="gettaking" -->
					<view style="display: flex;justify-content: flex-end;">
						<picker mode="selector" @change="bindDateChange" @cancel="quxiao" :value="taking" :range="array"
							:class="taking=='最小年龄'? 'unact' : 'act' " style="margin-left: 200rpx;">
							{{ taking }}
						</picker>

						<text style="margin-left: 5rpx;margin-right: 5rpx;">—</text>

						<picker mode="selector" @change="bindDateChanges" @cancel="quxiao" :value="takingend"
							:range="array2" :class="takingend=='最大年龄'? 'unact' : 'act' ">{{ takingend }}</picker>
						<u-icon name="arrow-right" size="28"></u-icon>
					</view>
				</view>

			</view>
		</view>
		<view class="top-txt">
			<view class="xline-bet">
				<view class="area">客户性别</view>
				<view class="timeFrame">
					<!-- @click="gettaking" -->
					<view style="display: flex;justify-content: flex-end;">
						<picker mode="selector" @change="bindDateChangess" @cancel="quxiao" :value="takingend2"
							:range="array3" :class="takingend2=='请选择'? 'unact' : 'act' ">{{ takingend2 }}</picker>
						<u-icon name="arrow-right" size="28"></u-icon>
					</view>
				</view>

			</view>
		</view>
		<view class="top-txt">
			<view class="xline-bet">
				<view class="top-txt-left">
					体验课费用
				</view>
				<view class="top-txt-right" style="display: flex;justify-content: flex-start;align-items: center;">
					<input type="digit" v-model="tmoney" placeholder="请输入" placeholder-style="font-size:26rpx" />
					<text style="margin-left: 10rpx;">元</text>
				</view>
			</view>
		</view>
		<view class="top-txt" style="border-bottom: 1rpx solid #F5F5F5;">



			<view class="btm">
				<view class="btm-reason">
					体验课收费说明：
				</view>
				<view class="btm-text">
					<textarea class="theTextarea" v-model="textareaValue" value="" maxlength="200" v-show="areaShow"
						placeholder="请简单描述收费说明，最多200个字" placeholder-style="font-size:24rpx;color:#999999" />


				</view>

			</view>

		</view>
		<view class="top-txt" style="border-bottom: 1rpx solid #F5F5F5;">

			<view class="btm">
				<view class="btm-reason">
					活动说明：
				</view>
				<view class="btm-text">
					<textarea class="theTextarea" v-model="textareaValue2" value="" maxlength="200" v-show="areaShow"
						placeholder="请简单描述活动说明，最多200个字" placeholder-style="font-size:24rpx;color:#999999" />

				</view>

			</view>

		</view>
		<view class="top-txt" v-if="!look">
			<view class="rtext"
				style="margin-top: 150rpx;font-size: 24rpx;font-family: PingFang SC;font-weight: 400;color: #FB4848;text-align: left;">
				提示：结算时优先扣除押金（采用多退少补的方式结算）
			</view>
		</view>
		<view class="top-txt" v-if="!look">
			<view class="btn" @click="go">
				<view class="">
					发布并支付押金
				</view>
			</view>
		</view>
		<view class="top-txt" v-if="look">
			<view class="btn" @click="go">
				<view class="">
					确定
				</view>
			</view>
		</view>

		<u-picker mode="time" v-model="show" :params="params" @confirm="getStime" @cancel="quxiao"></u-picker>
	</view>
</template>

<script>
	import indexApi from "../../../../api/index/indexList.js"
	import taskApi from "../../../../api/task/task.js"
	export default {
		data() {
			return {
				lunum: "",
				payment_cost: "",
				rank: "",

				areaShow: true,
				id: "",
				ids: "",
				isOne: false,
				logoList: [],
				oneObj: {},
				//上传地址
				action: this.$uptImgUrl,
				//活动名称
				activityName: "",
				//活动主图
				activityImg: "",
				//反显活动数组
				// activityImgList:[],
				show: false,
				show2: false,
				//时间选择器
				params: {
					year: true,
					month: true,
					day: true,
					hour: true,
					minute: true,
					second: false,
					// 选择时间的时间戳
					timestamp: true,
				},
				//日期
				startDate: '',
				// 日期时间戳
				startDateString: "",
				//单客户金额
				dmoney: "",
				tmoney: "",
				//客户数
				knum: "",
				taking: '最小年龄',
				takingend: '最大年龄',
				takingend2: '请选择',
				array: ["不限",  "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16",
					"17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32",
					"33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48",
					"49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59", "60", "61", "62", "63", "64",
					"65", "66", "67", "68", "69", "70", "71", "72", "73", "74", "75", "76", "77", "78", "79", "80",
					"81", "82", "83", "84", "85", "86", "87", "88", "89", "90", "91", "92", "93", "94", "95", "96",
					"97", "98", "99", "100"
				],
				array2: ["不限",  "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16",
					"17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32",
					"33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48",
					"49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59", "60", "61", "62", "63", "64",
					"65", "66", "67", "68", "69", "70", "71", "72", "73", "74", "75", "76", "77", "78", "79", "80",
					"81", "82", "83", "84", "85", "86", "87", "88", "89", "90", "91", "92", "93", "94", "95", "96",
					"97", "98", "99", "100"
				],
				array3: ["不限", "男", "女"],
				textareaValue: "",
				textareaValue2: "",
				rwObj: {},
				look: "",
				exr: "",
				single_money: ""
			}
		},
		onLoad(e) {
			
			console.log(e);
			this.ids = e.ids
			let this_=this
			if (e.look) {
				this.look = e.look
			}
			indexApi.referrer().then(res => {
				console.log(res)
				if (res.status == 200) {
					this.rank = res.result.rank
					this.lunum = res.result.lunum
					this.payment_cost = res.result.payment_cost
					this.single_money = res.result.single_money
					if (this.ids.indexOf(",") == -1) {
						this.isOne = true
						indexApi.merchant_detail({
							merchant_id: this.ids
						}).then(res => {
							console.log(res)
							if (res.status == 200) {
								this.oneObj = res.result
								if (this.oneObj.merchant_expire_type == '1' && this.rank == 4) {
									uni.showModal({
										title: "提示",
										content: "您的年费已到期，缴纳年费后使用拓客功能有优惠，是否缴纳年费？",
										confirmText: "立即缴纳",
										confirmColor: '#3898FF',
										cancelColor: '#999999',
										success: (res) => {
											if (res.confirm) {
												console.log('用户点击确定');
												console.log(this_.ids)
												uni.navigateTo({
													url: '../../../../pages/salesmanCommercial/payAnnualFee?id=' +
														this_.ids
												})
											} else if (res.cancel) {
												console.log('用户点击取消');
											}
											
										}
									})
								}
							} else {
								uni.showToast({
									title: res.message,
									icon: 'none'
								})
							}
						})
					} else {
						indexApi.merchant_logo({
							merchant_id: this.ids
						}).then(res => {
							console.log(res)
							if (res.status == 200) {
								this.logoList = res.result
							} else {
								uni.showToast({
									title: res.message,
									icon: 'none'
								})
							}
						})
					}
				} else {
					uni.showToast({
						title: res.message,
						icon: 'none'
					})
				}
			})

			if (e.task_id) {
				this.id = e.task_id
				taskApi.taskDetail({
					task_id: e.task_id,
					lng: e.lng,
					lat: e.lat
				}).then(res => {
					console.log(res)
					if (res.status == 200) {
						this.rwObj = res.result
						this.activityName = this.rwObj.name
						let a = [{
							url: ""
						}]
						a[0].url = this.$imgUrl(this.rwObj.picture)
						this.activityImg = a
						this.exr = this.rwObj.picture
						console.log(this.activityImg);
						let str = this.$time(this.rwObj.end_time, 0)
						let str2 = this.$time(this.rwObj.end_time, 4)
						this.startDate = str + "-" + str2
						this.startDateString = this.rwObj.end_time
						this.dmoney = this.rwObj.single_amount / 100
						this.knum = this.rwObj.customer_num
						this.taking = this.rwObj.start_age
						this.takingend = this.rwObj.end_age
						this.takingend2 = this.rwObj.gender
						this.tmoney = this.rwObj.experience_amount / 100
						this.textareaValue = this.rwObj.experience_explain
						this.textareaValue2 = this.rwObj.activity_explain

					} else {
						uni.showToast({
							title: res.message,
							icon: 'none'
						})
					}
				})
			}

		},
		methods: {
			quxiao() {
				this.areaShow = true
			},
			isShow() {
				this.areaShow = false
				this.show = true
			},
			goAll() {
				uni.navigateTo({
					url: "./fbhd3?ids=" + this.ids
				})
			},
			
			go(e) {

				if (!/^\d+$|^\d*\.\d+$/g.test(this.tmoney)) {
					uni.showToast({
						title: "请正确输入体验课费用",
						icon: "none"
					})
					return
				}

				if (!/^\d+$|^\d*\.\d+$/g.test(this.dmoney)) {
					uni.showToast({
						title: "请正确输入单客户金额",
						icon: "none"
					})
					return
				}
				this.dmoney = parseFloat(this.dmoney)
				this.single_money = parseFloat(this.single_money)
				if (this.dmoney < this.single_money) {

					uni.showToast({
						title: "请正确输入单客户金额",
						icon: "none"
					})
					return
				}
				if (this.activityName == "") {
					uni.showToast({
						title: "请输入活动名称",
						icon: "none"
					})
					return
				}
				if (this.activityImg == "") {
					uni.showToast({
						title: "请上传活动主图",
						icon: "none"
					})
					return
				}

				if (this.startDateString == "") {
					uni.showToast({
						title: "请选择结束时间",
						icon: "none"
					})
					
					return
				}
				let timestamp2 = new Date().getTime()/1000;
				if (timestamp2>this.startDateString) {
					uni.showToast({
						title: "结束时间需在当前时间以后",
						icon: "none"
					})
					return
				}
				if (!/^[1-9]\d*$/.test(this.knum)) {
					uni.showToast({
						title: "请正确输入客户数量",
						icon: "none"
					})
					return
				}
				if (this.taking == "") {
					uni.showToast({
						title: "请选择最小年龄",
						icon: "none"
					})
					return
				}
				if (this.takingend == "") {
					uni.showToast({
						title: "请选择最大年龄",
						icon: "none"
					})
					return
				}
				if (this.takingend2 == "") {
					uni.showToast({
						title: "请选择客户性别",
						icon: "none"
					})
					return
				}
				if (this.textareaValue == "") {
					uni.showToast({
						title: "请简单描述收费说明",
						icon: "none"
					})
					return
				}
				if (this.textareaValue2 == "") {
					uni.showToast({
						title: "请简单描述活动说明",
						icon: "none"
					})
					return
				}
				let tmoney = this.tmoney * 100
				let dmoney = this.dmoney * 100
				console.log(tmoney, dmoney);
				if (this.look == '1') {
					if (this.exr !== "") {
						taskApi.updateTask({
							task_id: this.id,
							supplier_id: this.ids,
							name: this.activityName,
							picture: this.exr,
							end_time: this.startDateString,
							single_amount: dmoney,
							customer_num: this.knum,
							start_age: this.taking,
							end_age: this.takingend,
							gender: this.takingend2,
							experience_amount: tmoney,
							experience_explain: this.textareaValue,
							activity_explain: this.textareaValue2
						}).then(res => {
							console.log(res)
							if (res.status == 200) {
								uni.navigateTo({
									url: "../../task/taskInfo/taskInfo?id=" + this.id
								})
							} else {
								uni.showToast({
									title: res.message,
									icon: 'none'
								})
							}
						})
					} else {
						taskApi.updateTask({
							task_id: this.id,
							supplier_id: this.ids,
							name: this.activityName,
							picture: this.activityImg,
							end_time: this.startDateString,
							single_amount: dmoney,
							customer_num: this.knum,
							start_age: this.taking,
							end_age: this.takingend,
							gender: this.takingend2,
							experience_amount: tmoney,
							experience_explain: this.textareaValue,
							activity_explain: this.textareaValue2
						}).then(res => {
							console.log(res)
							if (res.status == 200) {
								uni.navigateTo({
									url: "../../task/taskInfo/taskInfo?id=" + this.id
								})
							} else {
								uni.showToast({
									title: res.message,
									icon: 'none'
								})
							}
						})
					}

				} else if (this.look == '2') {
					if (this.exr !== "") {
						taskApi.updateTask({
							task_id: this.id,
							supplier_id: this.ids,
							name: this.activityName,
							picture: this.exr,
							end_time: this.startDateString,
							single_amount: dmoney,
							customer_num: this.knum,
							start_age: this.taking,
							end_age: this.takingend,
							gender: this.takingend2,
							experience_amount: tmoney,
							experience_explain: this.textareaValue,
							activity_explain: this.textareaValue2
						}).then(res => {
							console.log(res)
							if (res.status == 200) {
								uni.navigateTo({
									url: "../../task/taskInfo4/taskInfo4?id=" + this.id
								})
							} else {
								uni.showToast({
									title: res.message,
									icon: 'none'
								})
							}
						})
					} else {
						taskApi.updateTask({
							task_id: this.id,
							supplier_id: this.ids,
							name: this.activityName,
							picture: this.activityImg,
							end_time: this.startDateString,
							single_amount: dmoney,
							customer_num: this.knum,
							start_age: this.taking,
							end_age: this.takingend,
							gender: this.takingend2,
							experience_amount: tmoney,
							experience_explain: this.textareaValue,
							activity_explain: this.textareaValue2
						}).then(res => {
							console.log(res)
							if (res.status == 200) {
								uni.navigateTo({
									url: "../../task/taskInfo4/taskInfo4?id=" + this.id
								})
							} else {
								uni.showToast({
									title: res.message,
									icon: 'none'
								})
							}
						})
					}
				} else {
					indexApi.addTask({
						supplier_id: this.ids,
						name: this.activityName,
						picture: this.activityImg,
						end_time: this.startDateString,
						single_amount: dmoney,
						customer_num: this.knum,
						start_age: this.taking,
						end_age: this.takingend,
						gender: this.takingend2,
						experience_amount: tmoney,
						experience_explain: this.textareaValue,
						activity_explain: this.textareaValue2
					}).then(res => {
						console.log(res)
						if (res.status == 200) {
							this.id = res.result
							uni.navigateTo({
								url: "./pay?pay_type=3&id=" + this.id
							})
						} else {
							uni.showToast({
								title: res.message,
								icon: 'none'
							})
						}
					})
				}

			},
			bindDateChange(e) {
				console.log(e)
				// this.areaShow=false
				let index = e.target.value
				this.taking = this.array[index];
			},

			bindDateChanges(e) {
				console.log(e)
				// this.areaShow=false
				let index = e.target.value
				this.takingend = this.array2[index];
			},
			bindDateChangess(e) {
				console.log(e)
				// this.areaShow=false
				let index = e.target.value
				this.takingend2 = this.array3[index];
			},
			//获取日期
			getStime(res) {
				this.areaShow = true
				let day = res.day
				let month = res.month
				let year = res.year
				let hour = res.hour
				let minute = res.minute
				let str = `${year}-${month}-${day}-${hour}:${minute}`
				this.startDate = str
				this.startDateString = res.timestamp
				
			},
			imgChange6(e) {
				console.log(e);
				this.exr = ""
				this.activityImg = e.result
				console.log(this.activityImg);
			},
			removeVideoImg() {
				this.activityImg = ""
			},
			goDetail(nid) {
				console.log("跳转店铺详情" + nid)
				uni.navigateTo({
					url: './shopHome?mid=' + nid
				})
			},

		}
	}
</script>

<style lang="scss" scoped>
	.hidden {
		visibility: hidden;
	}

	.card1 {
		width: 100%;
		height: 120rpx;
		background: #FFFFFF;
		border: 1px solid #EEEEEE;
		border-radius: 10rpx;
		display: flex;
		justify-content: flex-start;
		align-items: center;
		position: relative;

		.left {
			display: flex;
			justify-content: flex-start;
			margin-left: 10rpx;

			.img {
				width: 100rpx;
				height: 100rpx;
				border-radius: 10rpx;
				margin-right: 20rpx;
			}
		}

		.right {
			font-size: 26rpx;
			font-family: PingFang SC;
			font-weight: 400;
			color: #999999;
			position: absolute;
			top: 45rpx;
			right: 20rpx;
		}
	}

	.header2 {
		// width: 100%;
		height: 100rpx;
		display: flex;
		justify-content: flex-start;
		align-items: center;
		background: #FFFFFF;
		margin-top: 2rpx;
		padding-left: 30rpx;
		border-bottom: 1rpx solid #F5F5F5;

		.header1-l {
			font-size: 26rpx;
			font-family: PingFang SC;
			font-weight: 400;
			color: #333333;

		}

		.header-c {
			display: flex;
			justify-content: flex-start;
			margin-left: 120rpx;

			.img {
				width: 36rpx;
				height: 36rpx;
			}

			.text {
				font-size: 26rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #333333;
				margin-left: 15rpx;
			}
		}

		.header-r {

			.item {
				display: flex;
				justify-content: flex-start;
				align-items: center;

				.text {
					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #999999;
					margin-right: 30rpx;
					margin-left: 350rpx;
				}

				.date {
					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #222222;
					margin-left: 300rpx;
					margin-right: 30rpx;
				}

				.img {
					width: 26rpx;
					height: 15rpx;
				}
			}
		}
	}

	.box {

		.theline-1 {
			font-size: 26rpx;
			color: #222222;
		}

		.theline-2 {
			font-size: 24rpx;
			color: #999999;
		}

		.theline-3 {
			font-size: 24rpx;
			color: #999999;
		}

		.uptVideo-box {
			display: flex;
			justify-content: space-between;
			align-items: center;
			margin-top: 20rpx;
			padding: 0 30rpx;
			height: 130rpx;

			.uptVideo-box-left {
				display: flex;
				height: 100%;
				flex-direction: column;
				justify-content: space-around;
			}

			.uptVideo-box-right {
				width: 130rpx;
				height: 130rpx;
				// background-color: pink;

			}
		}

		/* 高度90 between对齐 带下边框 */
		.xline-bet {
			height: 90rpx;
			display: flex;
			align-items: center;
			justify-content: space-between;
			border-bottom: 1rpx solid #F5F5F5;
		}

		.top-txt {
			text-align: right;
			padding: 0 30rpx;
		}

		.top-txt-left {
			font-size: 26rpx;
		}

		.top-txt-right {
			font-size: 26rpx;
		}

		.xline20 {
			width: 100%;
			height: 20rpx;
			background-color: #F5F5F5
		}

		.area {
			font-size: 26rpx;
		}

		.timeFrame {
			color: #999999;
			font-size: 26rpx;
			display: flex;
			align-items: center;


		}

		.unact {
			color: #999999;
		}

		.act {
			color: #333333;
		}

		.btn {

			background: #3798FF;
			border-radius: 10px;
			color: #FFF;
			width: 100%;
			height: 86rpx;
			display: flex;
			justify-content: center;
			align-items: center;
			margin-top: 30rpx;
			margin-bottom: 30rpx;
		}

		.btm {
			width: 690rpx;
			height: 300rpx;
			background-color: #FFFFFF;


			// padding: 0 30rpx;
			.btm-text {
				text-align: left;
				position: relative;
				width: 690rpx;
				height: 200rpx;
				background: #F5F5F5;
				border-radius: 10rpx;

				overflow: hidden;

				text {
					width: 100%;
				}

				.theTextarea {
					padding: 10rpx 20rpx 0;
					width: 100%;
					height: 100%;
					color: #999999;
					font-size: 26rpx;

				}
			}

			.btm-reason {
				text-align: left;
				height: 75rpx;
				line-height: 75rpx;
				font-size: 24rpx;
			}
		}

		.header {
			padding: 30rpx;

			.card {
				height: 180rpx;
				display: flex;
				justify-content: flex-start;
				align-items: center;

				.left1 {
					width: 180rpx;
					height: 180rpx;
					border-radius: 10rpx;
					margin-left: 11rpx;
					overflow: hidden;

					image {
						width: 180rpx;
						height: 180rpx;
					}
				}

				.right1 {
					margin-left: 22rpx;
					width: 380rpx;
					height: 100%;
					display: flex;
					flex-direction: column;
					justify-content: space-evenly;

					.rline1 {
						font-size: 30rpx;
						display: flex;
						justify-content: space-between;

						.img {
							width: 44rpx;
							height: 44rpx;

							border-radius: 50%;

						}
					}

					.rline2 {
						font-size: 24rpx;
						color: #666666;
						white-space: nowrap;
						text-overflow: ellipsis;
						overflow: hidden;
						word-break: break-all;

					}

					.rline3 {
						width: 500rpx;
						font-size: 24rpx;
						display: flex;
						align-items: center;

						image {
							width: 28rpx;
							height: 28rpx;
							margin-left: 1rpx;
						}
					}

					.rline4 {
						width: 500rpx;
						font-size: 24rpx;
						display: flex;
						align-items: center;

						// padding-left: 5rpx;
						image {
							width: 20rpx;
							height: 27rpx;
							margin-left: 6rpx;
						}

						.refuse {
							display: flex;
							align-items: center;
							justify-content: center;

							font-size: 24rpx;
							font-family: PingFang SC;
							font-weight: 400;
							color: #FE5E5E;

							.fff {
								border-bottom: 1rpx solid #FFF;
							}

							.ml {
								margin-left: 10rpx;
								border-bottom: 1rpx solid #FE5E5E;
							}
						}
					}

				}
			}
		}
	}
</style>
