<template>
	<view class="box">

		<view class="top-txt" v-if="see" @click="select()">
			<view class="xline-bet">
				<view class="area">拓客商家</view>
				<view class="timeFrame" @click="select()">
					<view style="display: flex;justify-content: flex-end;">
						<view :class="kmerchantname=='请选择'? 'unact' : 'act' ">{{ kmerchantname }}</view>
						<u-icon name="arrow-right" size="28"></u-icon>
					</view>
				</view>

			</view>
		</view>

		<view class="hint">客户信息</view>

		<view class="top-txt">
			<view class="xline-bet">
				<view class="top-txt-left">
					姓名
				</view>
				<view class="top-txt-right">
					<input type="text" v-model="kname" placeholder="请输入" placeholder-style="font-size:26rpx ;" style="font-size:26rpx ;"/>
				</view>
			</view>
		</view>
		<view class="top-txt">
			<view class="xline-bet">
				<view class="top-txt-left">
					联系电话
				</view>
				<view class="top-txt-right">
					<input type="number" v-model="kphone" placeholder="请输入" placeholder-style="font-size:26rpx ;" style="font-size:26rpx ;"/>
				</view>
			</view>
		</view>
		<view class="top-txt">
			<view class="xline-bet">
				<view class="top-txt-left">
					年龄
				</view>
				<view class="top-txt-right">
					<input type="number" v-model="kage" placeholder="请输入" placeholder-style="font-size:26rpx ;" style="font-size:26rpx ;"/>
				</view>
			</view>
		</view>
		<view class="top-txt">
			<view class="xline-bet">
				<view class="area">客户性别</view>
				<view class="timeFrame">
					<!-- @click="gettaking" -->
					<view style="display: flex;justify-content: flex-end;">
						<picker mode="selector" @change="bindDateChangess" @cancel="quxiao" :value="ksex" :range="array3" :class="ksex=='请选择'? 'unact' : 'act' ">{{ ksex }}</picker>
						<u-icon name="arrow-right" size="28"></u-icon>
					</view>
				</view>

			</view>
		</view>
		<view class="top-txt">
			<view class="xline-bet">
				<view class="top-txt-left">
					体验课类型(选填)
				</view>
				<view class="top-txt-right">
					<input type="text" v-model="ktype" placeholder="请输入" placeholder-style="font-size:26rpx ;" style="font-size:26rpx ;" />
				</view>
			</view>
		</view>
		<view class="top-txt" style="border-bottom: 1rpx solid #F5F5F5;">
			<view class="btm">
				<view class="btm-reason">
					备注说明(选填)：
				</view>
				<view class="btm-text">
					<textarea class="theTextarea" v-model="textareaValue" value="" maxlength="200" v-show="areaShow" placeholder="请简单描述备注说明，最多200个字"
					 placeholder-style="font-size:24rpx;color:#999999" />
					</view>
				</view>
		</view>
		
		<!-- 底部审核按钮 start -->
		<view class="footer">
			<view  class="but" @click="subMit()">提交</view>
		</view>
		<!-- 底部审核按钮 end -->
	</view>
</template>

<script>
	import taskApi from "../../../../api/product/product.js"
	export default {
		data() {
			return {
				areaShow:true,
				task_id:"",//任务id
				kmerchantid:'',//拓客商家id
				kmerchantid2:'',//拓客商家id
				kmerchantname:'',//拓客商家名称
				kname: '',//客户姓名
				kphone: '',//客户联系电话
				kage: '',//客户年龄
				ksex: '请选择',//客户性别
				ktype: '',//客户体验课类型(选填)
				textareaValue: '',//客户备注说明
				array3: ["请选择", "男", "女"],
				see:false,//是否显示拓客商家可选框
			}
		},
		onLoad(e){
			console.log(e)
			//解析判断是否是单商户.判断是否显示头部可选
			console.log(e.supplier_id.split(",").length)
			if(e.supplier_id.split(",").length > 1){
				this.kmerchantname = e.merchanname
				this.kmerchantid2 = e.supplier_id
				this.see = true
			}else{
				// console.log(e.supplier_id,6666666666666666);
				this.kmerchantid = e.supplier_id
				this.kmerchantname = '请选择'
				this.see = false
			}
			
			this.task_id = e.taskid
			console.log(this.task_id,22222222222222);
		},
		onShow(){
			var that = this;
			let res = that.kmerchantid;
			console.log(res)//为传过来的值
		},
		methods: {
			quxiao() {
				this.areaShow = true
			},
			bindDateChangess(e) {
				console.log(e)
				let index = e.target.value
				this.ksex = this.array3[index];
			},
			select(){
				uni.navigateTo({
					url: "/pagesB/pages/index/index/select"
				})
			},
			subMit(){
				let that = this;
				if (that.kmerchantid == "") {
					uni.showToast({
						title: "请选择拓客商家",
						icon: "none"
					})
					return
				}
				if (that.kname == "") {
					uni.showToast({
						title: "请输入客户姓名",
						icon: "none"
					})
					return
				}
				if (that.kphone == "") {
					uni.showToast({
						title: "请输入客户联系电话",
						icon: "none"
					})
					return
				}
				if (that.kage == "") {
					uni.showToast({
						title: "请输入客户年龄",
						icon: "none"
					})
					return
				}
				if (that.ksex == "请选择") {
					uni.showToast({
						title: "请选择客户性别",
						icon: "none"
					})
					return
				}
				// if (that.textareaValue == "") {
				// 	uni.showToast({
				// 		title: "请填写备注说明",
				// 		icon: "none"
				// 	})
				// 	return
				// }
				// console.log(that.task_id,22223332222222222);
				if(this.kmerchantid2){
					taskApi.add_client({
						task_id:that.task_id,
						supplier_id:that.kmerchantid,
						name:that.kname,
						phone:that.kphone,
						age:that.kage,
						gender:that.ksex,
						type:that.ktype,
						remarks:that.textareaValue
					}).then(res => {
						console.log(res)
						if(res.status == 200){
							uni.reLaunch({
								url:"./addCommerSuccess?supplier_id="+this.kmerchantid2+"&&task_id="+this.task_id
							})
						}else{
							uni.showToast({
								title: res.message,
								icon: 'none'
							})
						}
					})
				}else{
					taskApi.add_client({
						task_id:that.task_id,
						supplier_id:that.kmerchantid,
						name:that.kname,
						phone:that.kphone,
						age:that.kage,
						gender:that.ksex,
						type:that.ktype,
						remarks:that.textareaValue
					}).then(res => {
						console.log(res)
						if(res.status == 200){
							uni.reLaunch({
								url:"./addCommerSuccess?supplier_id="+this.kmerchantid+"&&task_id="+this.task_id
							})
						}else{
							uni.showToast({
								title: res.message,
								icon: 'none'
							})
						}
					})
				}
				
			},
		}
	}
</script>

<style lang="scss" scoped>
	.box {
		
		
		.hint {
			background: #F5F5F5;
			color: #999999;
			font-size: 24rpx;
			padding: 14rpx 30rpx;
		}

		.top-txt {
			text-align: right;
			padding: 0 30rpx;
		}

		.top-txt-left {
			font-size: 26rpx;
			color: #333333;
		}

		.top-txt-right {
			font-size: 26rpx ;
		}

		.area {
			font-size: 26rpx;
		}

		.timeFrame {
			color: #999999;
			font-size: 26rpx;
			display: flex;
			align-items: center;
			height: 100%;
		}
		
		.unact {
			color: #999999;
		}
		
		.act {
			color: #333333;
		}
	
		.btm {
			width: 690rpx;
			height: 300rpx;
			background-color: #FFFFFF;


			// padding: 0 30rpx;
			.btm-text {
				text-align: left;
				position: relative;
				width: 690rpx;
				height: 200rpx;
				background: #F5F5F5;
				border-radius: 10rpx;
				overflow: hidden;

				text {
					width: 100%;
				}

				.theTextarea {
					padding: 10rpx 20rpx 0;
					width: 100%;
					height: 100%;
					color: #999999;
					font-size: 26rpx;

				}
			}

			.btm-reason {
				text-align: left;
				height: 75rpx;
				line-height: 75rpx;
				font-size: 26rpx;
				color: #333333;
			}
		}

		.footer {
			width: 690rpx;
			position: fixed;
			bottom: 30rpx;
			left: 50%;
			margin-left: -345rpx;

			.but {
				font-size: 30rpx;
				color: #ffffff;
				background-color: #3699FF;
				text-align: center;
				padding: 30rpx;
				border-radius: 10rpx;
			}

		}

	}
</style>
