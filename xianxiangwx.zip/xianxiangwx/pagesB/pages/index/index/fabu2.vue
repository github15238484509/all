<template>
	<view class="box">
		<textarea v-model="reason" value="" placeholder="请编辑您要发布的内容" placeholder-style="font-size:24rpx;padding:20rpx"
			style="width: 690rpx;height: 300rpx; margin: 0 auto;margin-top: 20rpx;background-color: #fff;border-bottom: 2rpx solid #F5F5F5;" />
		<view class="kkkkk" style="margin-left: 25rpx;margin-top: 22rpx;">
			<view class="uptVideo-box-right"  style="position: relative;">
				<view slot="addBtn" class="slot-btn" hover-class="slot-btn__hover" hover-stay-time="150">
				<image src="../../../static/addImg.png" class="img" style="width: 130rpx;height: 130rpx;"
					@click="upvideo" v-if="!videoUrl&&loadingShow==true"></image>
				<video style="width: 130rpx;height: 130rpx;" v-if="videoUrl&&loadingShow==true" :src="$imgUrl(videoUrl)"
					controls></video>
					<u-icon v-if="videoUrl!=''" name="close-circle-fill" color="#333333" size="30" style="position: absolute;bottom: 90rpx;left: 100rpx;" @click="delVideoUrl"></u-icon>
					<u-loading style="position: absolute;" mode="circle"  v-if="loadingShow===false"></u-loading>
					<view style="width: 130rpx;height: 130rpx;background-color: #FFFFFF;" v-if="loadingShow===false"></view>
				</view>
			</view>

		</view>
		<view class="xbtn-blue" style="margin: 0 auto;position: fixed;left: 30rpx;bottom: 30rpx;" @click="fabu">
			立即发布
		</view>
		
	</view>
</template>

<script>
	import indexApi from "../../../../api/index/indexList.js"
	export default {
		data() {
			return {
				reason: "",
				videoUrl: "",
				//上传地址
				action: this.$uptImgUrl,
				imgArr: [],
				loadingShow:true,



			}
		},
		methods: {
			// 删除视频
			delVideoUrl(){
				this.videoUrl=""
			},
			upvideo() {
				this.loadingShow=false
				var that = this;
				wx.chooseVideo({
					sourceType: ["album"],
					success(res) {
						wx.uploadFile({
							url:that.$uptImgUrl,
							filePath: res.tempFilePath,
							name: "file",
							success(res) {
								console.log(res)
								that.videoUrl = JSON.parse(res.data).result
								console.log(that.videoUrl)
								that.loadingShow=true
							},
							fail(){
								that.loadingShow=true
							}
						})
					},
					fail(){
						that.loadingShow=true
					}
				})
			},
			// removeArr(index) {
			// 	this.imgArr.splice(index, 1);
			// },
			// imgChange1(e) {
			// 	console.log("得到的返回值")
			// 	console.log(e)
			// 	// this.files = this.$refs.uUpload.lists;
			// 	this.imgArr.push(e.result)
			// 	console.log(this.imgArr)
			// },
			// test: function() {
			// 	var self = this;
				
			// 	uni.chooseVideo({
			// 		count: 1,
			// 		sourceType: ['camera', 'album'],
			// 		success: function(res) {
			// 			console.log(res);
			// 			self.src = res.tempFilePath;
			// 		}
			// 	});
			// },
			fabu() {
				if (this.reason == "") {
					uni.showToast({
						title: '请编辑您要发布的内容~',
						icon: 'none'
					});
					return;
				}
				if(this.loadingShow==false){
					uni.showToast({
						title:"视频正在上传，请稍后",
						icon:"none"
					})
					return
				}
				indexApi.addTokerCircle({
					content: this.reason,
					image: "",
					video: this.videoUrl
				}).then(res => {
					console.log(res)
					if (res.status == 200) {
						uni.reLaunch({
							url: "./releas_success"
						});
					} else {
						uni.showToast({
							title: res.message,
							icon: 'none'
						})
					}
				})
			}
		}
	}
</script>

<style lang="scss" scoped>

</style>
