<template>

	<view class="main-box">
		<view class="big-box">


			<view class="bgc-box">

			</view>
			<view class="content">

				<view class="search-box">
					<view class="left" @click="toCityPick">

						<text v-if="!isGetLocation">请选择</text>
						<text v-if="isGetLocation">{{nowCity}}</text>
						<image src="../../../static/pull.png" mode="aspectFill"></image>
					</view>
					<view class="mid">
						<view class="vline-blue">

						</view>
						<view class="search-icon">
							<image src="../../../static/search.png" mode="aspectFill" style="margin-bottom: 20rpx;">
							</image>
						</view>
						<view class="ipt-box">
							<input type="text" v-model="merchant_name" placeholder="请输入商家名称"
								placeholder-style="font-size: 26rpx;color: #FFFFFF;" />
						</view>

					</view>
					<view class="right" @click="toIndexSearch">
						<view class="btn-box">
							搜索
						</view>
					</view>
				</view>
				<view class="swiper-box">
					<swiper :autoplay="false" class="theSwiper" :interval="3000" :duration="1000"
						@change="swiperChange">
						<swiper-item v-for="(item,index) in swiperList">
							<view class="swiper-item">
								<!-- 如果containVideo为真 第一条显示视频 -->
								<video :src="$imgUrl(videoUrl)" :poster="$imgUrl(coverImg1) " :autoplay='false'
									v-if="containVideo&&index==0" :loop='false' :enable-progress-gesture="false"
									:object-fit="fill" id="theVideo"></video>
								<!-- <image :src="$imgUrl(coverImg1)" mode=""></image> -->

								<!-- $imgUrl(videoUrl) -->
								<!-- http://clips.vorwaerts-gmbh.de/big_buck_bunny.mp4 -->
								<!-- :poster="$imgUrl(coverImg1) " -->
								<!-- 如果containVideo 为真 index为0的图片不显示 -->
								<image :src="$imgUrl(item.banner_pic)" mode="aspectFill"
									v-if="containVideo==true&&index!=0" @click="picJump(item)"></image>

								<!-- 如果containVideo为假 上面一条不生效 图片全部显示-->
								<image :src="$imgUrl(item.banner_pic) " v-if="containVideo==false" mode="aspectFill"
									@click="picJump(item)"></image>

								<view class="url-box" v-if="videoUrl&&index==0&& item.banner_type != 1 "
									@click="videoJump(item)">
									<image src="../../../static/videoLink.png" mode="aspectFill"></image>
								</view>


							</view>

						</swiper-item>

					</swiper>

				</view>
				<view class="swiper-box1">
					<view class="left">
						<image src="../../../static/news.png" mode="aspectFit"></image>

					</view>
					<view class="vline">

					</view>
					<view class="mid">
						<swiper :autoplay="true" :interval="5000" :duration="1000" :vertical="true" :circular="false"
							@change="tochange">
							<swiper-item v-for="(item,index) in newsList">
								<view class="swiper-item" @click="tonewsDetail(item.content,item.title)">{{item.title}}
								</view>
							</swiper-item>

						</swiper>
					</view>
					<view class="vline1">

					</view>
					<!-- @click="tonewsDetail" -->
					<view class="right" @click="toNewsList">
						<image src="../../../static/more.png" mode="aspectFit"></image>
					</view>
				</view>
				<view class="score">
					<view class="top">
						<view class="left">
							<span :class="selectGood==0?'type1':'type2'" @click='changeGoodsType(0)'>拓客商户</span>
							<span :class="selectGood==1?'type1':'type2'" style="margin-left: 60rpx;" v-if="isSelf==true"
								@click='changeGoodsType(1)'>拓客动态</span>
						</view>
					</view>
					<view class="score-box" style="margin-top: 20rpx;" v-if="isShow">
						<view class="score-item" v-for="(item,index) in shopList" @click="toShopHome(item.merchant_id)">
							<view class="left1">
								<image :src="$imgUrl(item.merchant_logo)" mode="aspectFill"></image>
							</view>
							<view class="right1">
								<view class="rline1">
									{{item.merchant_name}}
								</view>
								<view class="rline2">
									{{item.merchant_address_whole}}
									<!-- {{item.merchant_address}} -->
								</view>
								<view class="rline3">
									<image src="../../../static/time.png" mode="aspectFill"></image>
									<text
										class="line-txt">{{item.merchant_worktime_start}}-{{item.merchant_worktime_end}}</text>
								</view>
								<view class="rline4">
									<image src="../../../static/location.png" mode="aspectFill"></image>
									<text class="line-txt">{{item.distance}}</text>
								</view>
							</view>
						</view>
						<u-loadmore :status="status" :load-text="loadText" @loadmore="clkloadMore" />
					</view>
					<view class="kkq" v-if="!isShow" v-for="(item,index) in kkqList" :key="index">
						<image :src="$imgUrl(item.photo)" class="img"></image>
						<view class="kkq-r">
							<view class="title">
								<text class="t1">{{item.name}}</text>
								<text class="t2">{{item.rank_name}}</text>
							</view>
							<view class="text">
								{{item.content}}
							</view>
							<view class="imgs" v-if="item.image.length>0">
								<image :src="$imgUrl(item2)" class="imggg" v-for="(item2,index2) in item.image" 
									:key="index2" @click="toBig(item.image,index2)"></image>
							</view>
							<!-- <video src="" controls v-if="item.video.length>0"></video> -->
							<video :src="$imgUrl(item.video)" :autoplay='false' v-if="item.video.length>0" :loop='false'
								:enable-progress-gesture="false" id="video1"></video>
							<view class="bot">
								发布于：{{$time(item.add_time,0)}}  {{$time(item.add_time,4)}}
							</view>
						</view>
					</view>
					
					<!-- 占位用 tabbar的高度 -->
					<view class="theEnd">

					</view>
				</view>


			</view>
			
			
			<view class="mask">
				<unipopup ref="popup" type='top'>
					<view class="popup-box">
						<view class="popup-box-item" v-for="(item,index) in sortList" :key="index"
							@click="sortChoice(index,item.scope_index,item.scope_name)">
							<text class="box-item-txt">{{item.scope_name}}</text>

							<view class="box-item-icon" v-if="actIconIndex==index">
								<image src="../../../static/popupicon.png" mode="aspectFill"></image>
							</view>
						</view>


					</view>

				</unipopup>
			</view>


		</view>
		<view class="tabbar" style="z-index: 999;">
			<image src="../../../static/tabbarbgc.png" class="bgc"></image>
			<view class="box" v-show="tabbarAct==0" @click.stop="goTab(0)">
				<image src="../../../static/tabbarSel1.png" class="img"></image>
				<view class="text" style="color: #1576FF;">
					首页
				</view>
			</view>
			<view class="box" v-show="tabbarAct!==0" @click.stop="goTab(0)">
				<image src="../../../static/tabbar1.png" class="img"></image>
				<view class="text">
					首页
				</view>
			</view>
			
			<view class="box1" v-show="tabbarAct==1" @click.stop="goTab(1)">
				<image src="../../../static/tabbarSel2.png" class="img"></image>
				<view class="text" style="color: #1576FF;">
					任务
				</view>
			</view>
			<view class="box1" v-show="tabbarAct!==1" @click.stop="goTab(1)">
				<image src="../../../static/tabbar2.png" class="img"></image>
				<view class="text">
					任务
				</view>
			</view>
			<view class="box2"  @click.stop="goTab(5)">
				<image src="../../../static/backups.png" class="img"></image>
				<view class="text" >
					发布
				</view>
			</view>
			
			<view class="box3" v-show="tabbarAct==2" @click.stop="goTab(2)">
				<image src="../../../static/tabbarSel3.png" class="img"></image>
				<view class="text" style="color: #1576FF;">
					客户
				</view>
			</view>
			<view class="box3" v-show="tabbarAct!==2" @click.stop="goTab(2)">
				<image src="../../../static/tabbar3.png" class="img"></image>
				<view class="text" >
					客户
				</view>
			</view>
			<view class="box4" v-show="tabbarAct==3" @click.stop="goTab(3)">
				<image src="../../../static/tabbarSel4.png" class="img"></image>
				<view class="text" style="color: #1576FF;">
					我的
				</view>
			</view>
			<view class="box4" v-show="tabbarAct!==3" @click.stop="goTab(3)">
				<image src="../../../static/tabbar4.png" class="img"></image>
				<view class="text">
					我的
				</view>
			</view>
		</view>

		<view class="bbb" v-if="showT">

		</view>

		<view class="beijing" v-if="flage1" @click="isFlage">
			<view class="dw">
				<view class="m1" @click.stop="go(1)">
					<image src="../../../static/m1.png" class="img"></image>
					<view class="text">
						发布拓客活动
					</view>
				</view>
				<view class="m2" @click.stop="go(2)" v-if="isSelf==true">
					<image src="../../../static/m2.png" class="img"></image>
					<view class="text">
						发布拓客动态
					</view>
				</view>
				<view class="m3" @click.stop="go(3)">
					<image src="../../../static/m3.png" class="img"></image>
					<view class="text">
						录入客户
					</view>
				</view>
			</view>
			
			
		</view>
		<view class="beijing2" v-if="flage2" @click="isFlage1">
			<view class="card">
				<view class="gray" @click.stop="this.flage2=true">
					<view class="text">
						请选择您要发布的动态类型：
					</view>
				</view>
				<view class="ngray" @click.stop="go2(1)">
					<view class="text">
						视频动态
					</view>
				</view>
				<view class="ngray" @click.stop="go2(2)">
					<view class="text">
						图片动态
					</view>
				</view>
			</view>
			<view class="btm" @click.stop="isFlage1">
				<view class="text">
					取消
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import unipopup from "../../../../components/uni-popup/uni-popup.vue"
	import bannerApi from "../../../../api/index/banner.js"
	import newsApi from "../../../../api/index/news.js"
	import merchantScopeApi from "../../../../api/index/merchantScope.js"
	import indexListApi from "../../../../api/index/indexList.js"
	import getNowCityApi from "../../../../api/index/getNowCity.js"
	import proApi from "../../../../api/product/product.js"

	export default {
		components: {

			unipopup
		},
		data() {
			return {
				tabbarAct:0,
				flage2: false,
				flage1: false,
				imgsList: [],
				kkqList: [],
				showT: false,
				//tabbar数据
				list: [{
						iconPath: "/static/tabbar1.png",
						selectedIconPath: "/static/tabbarSel1.png",
						text: '首页',
						pagePath: "/pages/index/index/index"
					},
					{
						iconPath: "/static/tabbar2.png",
						selectedIconPath: "/static/tabbarSel2.png",
						text: '任务',
						pagePath: "/pages/task/task"
					},
					{
						iconPath: "/static/backups.png",
						selectedIconPath: "/static/backupSel.png",
						text: '发布',
						midButton: true,

					},
					{
						iconPath: "/static/tabbar3.png",
						selectedIconPath: "/static/tabbarSel3.png",
						text: '客户',
						pagePath: "/pages/custom/custom"
					},
					{
						iconPath: "/static/tabbar4.png",
						selectedIconPath: "/static/tabbarSel4.png",
						text: '我的',
						pagePath: "/pages/mine/mine"
					},
				],

				current: 0,
				selectGood: 0, //选中的是拓客商家还是拓客圈
				title: 'Hello',
				videoUrl: "",
				coverUrl: "",
				imgUrl: ["VlianShopMapi/module/202101/aa00c7efa554449e3c7f0d40a07ec746a7233f7c.png"],
				theCdn: "https://cdn.jianyunkeji.net/",
				//控制遮罩层启闭
				// isMaskShow:false
				//点击分类 激活的下标
				actIconIndex: -1,
				nowCity: "",
				the_banner_type: "1",
				swiperList: [],
				//是否包含视频
				containVideo: false,
				//公告
				newsList: [],
				sortList: [],
				//行业分类id
				merSort: "",
				//分类名称
				scopeName: "",
				longitude: "",
				latitude: "",

				token: "",
				//首页店铺列表
				shopList: [],
				nowCity: "",
				newsListIndex: "-1",
				coverImg1: "",
				//是否获取到定位
				isGetLocation: false,
				//是否从选择城市返回
				isBack: false,
				//一页多少条
				count: 10,
				//当前页数
				page: 1,
				status: 'loading',
				totalPage: 1,
				loadText: {
					loadmore: '上拉或点击加载更多',
					loading: '努力加载中',
					nomore: '没有更多了'
				},
				reachFlag: true,
				merchant_name: "",
				//是否展示商户
				isShow: true,
				isSelf:false



			}
		},
		//下拉加载更多
		onReachBottom() {
			this.reachBtm()

		},


		onPullDownRefresh() {
			this.page = 1
			this.init()
			this.getIndexList()
			setTimeout(function() {
				uni.stopPullDownRefresh();
			}, 1000);
		},
		onLoad(e) {
			// // #ifdef MP-ALIPAY
			// 			my.setCanPullDown({
			// 			canPullDown:false
			// 			})
			// 			// #endif




			// if(!this.token){
			// 	uni.navigateTo({
			// 		url:'../login/welcome'
			// 	})
			// 	return
			// }
            if(e.selectGood) {
                this.selectGood = e.selectGood
                this.changeGoodsType(e.selectGood)
            }
			this.init();




		},
		onShow() {
			// 选择完城市以后 再刷新一遍
			if (this.isBack) {
				this.getIndexList()
			}




		},
		methods: {
			toBig(arr, index) {
			
				let imgs = []
				arr.forEach(el => {
					el = this.$imgUrl(el)
					imgs.push(el)
				})
			
				console.log(imgs)
				// let img =this.$imgUrl(url)
				// 预览图片
				uni.previewImage({
					urls: imgs,
					current: index
			
				});
			
			},
			goTab(num){
					if(num==5){
						
						this.flage1=true
					} else if(num==0){
						this.tabbarAct=0
						
						
					} else if(num==1){
						
						uni.reLaunch({
							url:"../../task/task"
						})
					} else if(num==2){
						
						uni.reLaunch({
							url:"../../custom/custom"
						})
					} else if(num==3){
						
						uni.reLaunch({
							url:"../../../../pages/my/my/my"
						})
					}
			},
			//选择发布拓客动态
			go2(num) {
				if (num == 2) {
					uni.navigateTo({
						url: "./fabu"
					})
				}
				if (num == 1) {
					uni.navigateTo({
						url: "./fabu2"
					})
				}
			},
			go(num) {
				//发布拓客活动
				if (num == 1) {
					if(!uni.getStorageSync("xxytoken")){
						uni.showToast({
							title: "你还没有登录",
							icon: 'none'
						})
						return
					}
					indexListApi.referrer().then(res => {
						console.log(res)
						if (res.status == 200) {
							if (res.result.rank == 7) {
								uni.navigateTo({
									url: "./fbhd"
								})
							} else if (res.result.rank == 4) {
								// indexListApi.merchant_detail({
								// 	merchant_id:res.result.merchant_id,
								// 	phone:res.result.phone
								// }).then(res => {
								//         console.log(res)
								//         if (res.status == 200) {

								//         } else {
								//                 uni.showToast({
								//                 title: res.message,
								//                 icon: 'none'
								//                 })
								//         }
								// })
								uni.navigateTo({
									url:"./fbhd2?ids="+res.result.merchant_id
								})
							} else {
								uni.showToast({
									title: "你没有该权限~",
									icon: "none"
								})
							}
						} else {
							uni.showToast({
								title: res.message,
								icon: 'none'
							})
						}
					})
				}
				//发布拓客动态
				if (num == 2) {
					if(!uni.getStorageSync("xxytoken")){
						uni.showToast({
							title: "你还没有登录",
							icon: 'none'
						})
						return
					}
					indexListApi.referrer().then(res => {
						console.log(res)
						if (res.status == 200) {
							if (res.result.rank == 7 || res.result.rank == 6) {
								this.flage1 = false
								this.flage2 = true
							} else {
								uni.showToast({
									title: "你没有该权限~",
									icon: "none"
								})
							}
						} else {
							uni.showToast({
								title: res.message,
								icon: 'none'
							})
						}
					})
				}
				//录入客户
				if (num == 3) {
					proApi.get_add_client().then(res => {
						console.log(res)
						this.flage1 = false
						if (res.status == 200) {
							uni.navigateTo({
								url: "./lrkh?taskid=" + res.result.task_id + "&supplier_id=" + res.result.supplier_id
							})
						} else {
							uni.showToast({
								title: res.message,
								icon: 'none'
							})
						}
					})
				}
			},
			//弹窗
			isFlage() {
				this.flage1 = false
			},
			isFlage1() {
				this.flage2 = false
			},
			//切换前的回调
			beforeSwitch(index) {
				// 只能切换偶数项
				console.log(index);
				if (index !== 2) return true;
				if (index == 2) {
					this.flage1 = !this.flage1
					// this.showT = !this.showT
					return false;
				}

			},
			// 切换选中的是拓客圈还是商户
			changeGoodsType(e) {
				// let this_=this
				this.selectGood = e

				console.log(this.selectGood);
				if (this.selectGood == 0) {
					this.isShow = true
					this.getIndexList()
				} else {
					this.isShow = false
					indexListApi.toker_list().then(res => {
						console.log(res)
						if (res.status == 200) {
							this.kkqList = res.result.data
							console.log(this.kkqList);
							this.kkqList = this.kkqList.map(el => {
								if (el.image) {
									el.image = el.image.split(",")
								}
								return el
							})
							console.log(this.kkqList);
							// for(let a=0;a<res.result.data.length;a++){
							// 	this.kkqList[a].img=this.kkqList[a].image.split(",")
							// }
							console.log(this.kkqList)
						} else {
							uni.showToast({
								title: res.message,
								icon: 'none'
							})
						}
					})
				}
			},
			init() {
				this.token = uni.getStorageSync("xxytoken")
				//拿轮播
				this.theCdn = this.$cdnUrl
				bannerApi.banner({
					region: 1
				}).then(res => {
					console.log(res.result)
					this.videoUrl = res.result.video.video_url
					this.coverUrl = res.result.video.video_cover
					this.the_banner_type = res.result.video.banner_type
					//如果有视频 就把视频拼到前面 
					//这里等后台加了视频 再测
					if (res.result.video.video_url) {
						this.containVideo = true
						this.coverImg1 = res.result.video.video_cover
						this.swiperList.push(res.result.video)
						console.log(this.swiperList)
						this.swiperList = this.swiperList.concat(res.result.data)
						console.log(this.swiperList)

					}
					//如果没有视频 图片数组 就是轮播数组
					else {
						this.swiperList = res.result.data

					}









				})
				//获取经纬度
				let that = this
				uni.getLocation({
					// type: 'wgs84',
					success: (res) => {
						that.longitude = res.longitude
						that.latitude = res.latitude
						this.longitude = that.longitude
						this.latitude = that.latitude
						getNowCityApi.getNowCity({
							lng: this.longitude,
							lat: this.latitude
						}).then(res => {
							console.log(res)
							if (res.status == 200) {
								this.isGetLocation = true
								this.nowCity = res.result.city

								this.nowCity = this.nowCity.slice(0, this.nowCity.length - 1)
								this.getIndexList()
							} else {
								uni.showToast({
									title: '获取城市失败,请检查网络'
								})
							}

							// this.getIndexList();
							// uni.setStorageSync('xxyNowCity',this.nowCity)
						})

						// this.getIndexList();
					},
					fail: (res) => {
						uni.showModal({
							showCancel: false,
							content: '获取定位失败，请打开手机定位',


						})
						this.status = 'nomore'
					}
				});

				//拿首页新闻
				newsApi.news({
					region: 1
				}).then(res => {
					console.log(res.result)
					this.newsList = res.result
				})


				merchantScopeApi.merchantScope()
					.then(res => {
						if (res.status == 200) {
							this.sortList = res.result
						}
					})
			},
			//去新闻详情页 其实就是webview里 套链接

			swiperChange(e) {
				let swiperIndex = e.detail.current;
				//如果下标不为0   拿视频上下文对象 暂停视频
				if (swiperIndex != 0) {
					uni.createVideoContext('theVideo').pause()
				}
			},

			reachBtm() {

				if (this.page < this.totalPage) {
					this.status = 'loading';
					this.page++;
					indexListApi.indexList({
							longitude: this.longitude,
							latitude: this.latitude,
							merchant_industry: this.merSort,
							page: this.page,
							city_name: this.nowCity,
							count: this.count,
							token: this.token
						})
						.then(res => {
							//如果有数据 重新赋值  如果没有 清空
							if (res.result) {
								if(res.result.status==1){
									this.isSelf=true
								}
								//最大页数
								this.totalPage = res.result.last_page
								this.shopList = this.shopList.concat(res.result.data)

								this.status = "loadmore"

							} else {
								this.status = "nomore"
							}

						})
				} else {
					this.status = "nomore"
				}


			},
			tonewsDetail(url, title) {
				uni.navigateTo({
					url: 'newsDetail?url=' + url + '&title=' + title
				})

			},

			toCityPick() {
				uni.navigateTo({
					url: "./choiceCity?currentCity=" + this.nowCity
				})
			},

			clkAll() {
				this.$refs.popup.open()
			},

			sortChoice(index, sortIndex, scope_name) {
				this.scopeName = scope_name
				this.actIconIndex = index
				this.merSort = sortIndex
				this.getIndexList();
				this.$refs.popup.close()
			},
			//拿首页商户列表
			getIndexList() {
				indexListApi.indexList({
						longitude: this.longitude,
						latitude: this.latitude,
						merchant_industry: this.merSort,
						page: this.page,
						city_name: this.nowCity,
						count: this.count,
						token: this.token
					})
					.then(res => {
						//如果有数据 重新赋值  如果没有 清空
						if (res.result) {
							if(res.result.status==1){
								this.isSelf=true
							}
							this.shopList = res.result.data
							//最大页数
							this.totalPage = res.result.last_page
							if (this.totalPage > this.page) {
								this.status = "loadmore"
							}
							if (this.totalPage == this.page) {
								this.status = "nomore"
							}
						} else {
							this.shopList = []
							this.status = "nomore"
						}

					})
			},
			toIndexSearch() {

				indexListApi.indexList({
						longitude: this.longitude,
						latitude: this.latitude,
						merchant_industry: this.merSort,
						page: this.page,
						city_name: this.nowCity,
						merchant_name: this.merchant_name,
						count: this.count,
						token: this.token
					})
					.then(res => {
						//如果有数据 重新赋值  如果没有 清空
						if (res.result) {
							if(res.result.status==1){
								this.isSelf=true
							}
							this.shopList = res.result.data
							//最大页数
							this.totalPage = res.result.last_page
							if (this.totalPage > this.page) {
								this.status = "loadmore"
							}
							if (this.totalPage == this.page) {
								this.status = "nomore"
							}
						} else {
							this.shopList = []
							this.status = "nomore"
						}

					})
				// uni.navigateTo({
				// 	url: './indexSearch?nowCity=' + this.nowCity + "&longitude=" + this.longitude + "&latitude=" +
				// 		this.latitude +
				// 		"&merchant=" + this.merSort
				// })
			},
			toShopHome(id) {
				uni.navigateTo({
					url: './shopHome?mid=' + id
				})
			},
			tochange(event) {

				this.newsListIndex = event.detail.current
			},
			clkloadMore() {
				this.reachBtm()
			},
			videoJump(e) {


				//跳页面
				if (e.banner_type == 3) {
					uni.navigateTo({
						url: e.jump_parameter
					})
				}
				//跳外链
				else if (e.banner_type == 2) {
					let jUrl = e.url
					jUrl = JSON.stringify(jUrl)
					uni.navigateTo({
						url: 'newsDetail?jurl=' + jUrl
					})
				}
			},
			picJump(e) {

				console.log(e)


				//跳页面
				if (e.banner_type == 3) {
					uni.navigateTo({
						url: e.jump_parameter
					})
				}
				//跳外链
				else if (e.banner_type == 2) {
					let jUrl = e.url
					jUrl = JSON.stringify(jUrl)
					uni.navigateTo({
						url: 'bannerLink?jurl=' + jUrl
					})
				}

			},
			toNewsList() {
				uni.navigateTo({
					url: './newsList'
				})
			}





		}
	}
</script>
<style>
	page {
		/* background-image:url("../../static/indexImg.png");
		background-size: 100% 100%; 
		background-attachment:fixed; */

	}
</style>
<style lang="scss" scoped>
	/* 弹窗 */
	.beijing2 {
		position: fixed;
		width: 100%;
		height: 100%;
		left: 0;
		top: 0;
		background-color: rgba(0, 0, 0, .5);
		z-index: 999;

		.card {
			width: 690rpx;
			height: 270rpx;
			position: absolute;
			bottom: 138rpx;
			left: 30rpx;
			background-color: #FFF;
			border-radius: 10rpx;

			.gray {
				width: 100%;
				height: 90rpx;
				display: flex;
				justify-content: center;
				align-items: center;

				.text {

					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #999999;

				}
			}

			.ngray {
				width: 100%;
				height: 88rpx;
				border-top: 2rpx solid #F5F5F5;
				display: flex;
				justify-content: center;
				align-items: center;

				.text {

					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 400;

					color: #333333;

				}
			}
		}

		.btm {
			width: 690rpx;
			height: 90rpx;
			position: absolute;
			bottom: 28rpx;
			left: 30rpx;
			background-color: #FFF;
			border-radius: 10rpx;
			display: flex;
			justify-content: center;
			align-items: center;

			.text {

				font-size: 26rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #333333;
				// line-height: 36px;
			}
		}
	}

	.beijing {
		position: fixed;
		width: 100%;
		height: 100%;
		left: 0;
		top: 0;
		background-color: rgba(0, 0, 0, .5);
		z-index: 999;
		.dw{
			width: 100%;
			position: absolute;
			bottom: 200rpx;
			left: 0;
			display: flex;
			justify-content: space-around;
			align-items: center;
			.m1 {
				width: 185rpx;
				height: 136rpx;
				display: flex;
				justify-content: center;
				flex-wrap: wrap;
				
				.img {
					width: 100rpx;
					height: 100rpx;
					margin-bottom: 10rpx;
				}		
				.text {		
					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 500;
					color: #FFFFFF;
				}
			}
			.m2 {
				width: 185rpx;
				height: 136rpx;
				display: flex;
				justify-content: center;
				flex-wrap: wrap;
				
				.img {
					width: 100rpx;
					height: 100rpx;
					margin-bottom: 10rpx;
				}		
				.text {
			
					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 500;
					color: #FFFFFF;
				}
			}
			.m3 {
				width: 154rpx;
				height: 136rpx;
				display: flex;
				justify-content: center;
				flex-wrap: wrap;
				
			
				.img {
					width: 100rpx;
					height: 100rpx;
					margin-bottom: 10rpx;
				}
			
				.text {
			
					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 500;
					color: #FFFFFF;
				}
			}
		}
		

		// .img1{
		// 	width: 70rpx;
		// 	height: 70rpx;
		// 	position: absolute;
		// 	bottom: 70rpx;
		// 	left: 330rpx;
		// }
	}

	.bbb {
		position: fixed;
		top: 0;
		left: 0;
		background-color: red;
		width: 100%;
		height: 300rpx;
	}

	.main-box {
		position: relative;

		.tabbar {
			// border-top: 1px solid #999999;
			position: fixed;
			left: 0;
			bottom: 0;
			// background-color: #FFF;
			height: 121rpx;
			width: 100%;
			display: flex;
			align-items: center;
			justify-content: space-around;
			z-index: 99999;
			.bgc{
				position: absolute;
				left: 0;
				bottom: 0;
				height: 121rpx;
				width: 100%;
			}
			.img {
				height: 44rpx;
				width: 44rpx;
			}

			.text {
				width: 44rpx;
				height: 21rpx;
				font-size: 22rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #666666;
				// line-height: 66px;
			}

			.box {
				height: 75rpx;
				width: 44rpx;
				// position: relative;
				position: absolute;
				left: 80rpx;
				bottom: 10rpx;
			}

			.box1 {
				height: 75rpx;
				width: 44rpx;
				// position: relative;
				position: absolute;
				bottom: 10rpx;
				left: 215rpx;
			}

			.box3 {
				height: 75rpx;
				width: 44rpx;
				// position: relative;
				position: absolute;
				bottom: 10rpx;
				right: 215rpx;
			}

			.box4 {
				height: 75rpx;
				width: 44rpx;
				// position: relative;
				position: absolute;
				bottom: 10rpx;
				right: 80rpx;
			}

			.box2 {
				// height: 75rpx;
				// width: 44rpx;
				position: absolute;
				left: 340rpx;

				bottom: 16rpx;

				.img {
					height: 70rpx;
					width: 70rpx;
					position: absolute;
					left: 0rpx;

					bottom: 24rpx;
				}

				.text {
					margin-left: 12rpx;
				}
			}
		}
	}

	.bgc-box {
		position: fixed;
		top: 0;
		left: 0;
		width: 100%;
		height: 100%;
		background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAu4AAASyCAYAAADpgW58AAKC/ElEQVR42uy72VobyRIt7GfqZp7n0cxgbF6orQlJSGgGv+F/9R9/37nah26DXcqKYUVklsDdXGRvI1VlxrBixYqE/eGPr//7//7863//58+v//v/pfUH8/MfxHeW9cdfvxb8TsR5/6y/mP/9DRca//C5P1LEMRvPvxLFk9qriPz89Tbz/geTGy1f0fkN40HlICa/z+//8fK/TvxxflrqYOy9Z1ti8PDH19+XP1JhVsTTX3x8/yiirl/h/T8Uf1ic/hXH64Utrub/mhz/Weq68H6RyB93/N/6kvpHxJ5ZfvZoRa2v5mL9l/LZV+CzIuL465z/87dm//D0w/99Wv97zfWUiH/WRM7763l9/W+tP77+93z+nXP16vkqok7eUO39Ecb5P8oL7zz7duv6j/cc+mx+r6F3/y319xdx1l/C+UXm5S/AtifN/rdw//5OqpNZU+92Fm7nlMGPqXdsFXb+1H8Eg6/t19S/1Pep/zhOJF+L4LWp/0AtTf2HcTT1rrMKPzO7irT16Z3vP4R7KV2xTzkKZqqEBSVlUU4Z9w8ntykH2U6hQqeUWU4wTEXESgOhB6Be/MSS7VQC/ML7l/D9vPU2VSqQqEpOkVWKw5rp85IuZqbA+FMcMFWyYXuKweyU8J3IRSWsFqgz/gB4JqbJZHEyZaxbK4dLOJ+KxNefAL956n8qou7QnHl61lTKIbxk4znPIGaunZKtNjmMTQl7T0m1VYrrzZZ6jalRqy2WHmHGIoihKTS3JUxnJavZr/h5aG1N4Zz2JNxLP27cp6RklmRxQhV0tgFagRk2rylA4Ge/ZwmuxH8+BRDkH2FzL+Xtm+IKqCQTxRRTIBYRrdnCDgdAk5Tim6KBT5X0Zj2l+Vui84osc6N9sTeMHzgEcwKRJSO0nkqyAGfFf8kn+sh3SnbBk7XrD4LkzYNkSWjoQb3nSL8UnF0K8FVShpiMHyEuxUGvNH5m9n+h+hRyG9o3xdTfFCVuMmuqZKulKUWQTQX+ZnOR5cxcDQj/loYx1f4SKCRLNL/8qQyAU8gwXzIOmiV8H02gohcTyOA7pQmTEi6+w3rkdAYsokKsKWdqAyVbP1n/SjR+OB7+yYclYXAt8XaymC7x+B3zpYTFG7rsI4bTKWAIQHrkVCnfJ1BhDV/+Ab1E0klsjg2Deub77x+eNvk+FRAlRX5/Bs1Lu6GjmlVOVGbBwzRIinQpsTfFDACIwKP2CZvZWBOniIqKTUkm2ZxQKCliU7NFuDmc4nJbCsiFEgJMDrh8TEm2lfihgovRn4wAIs8CGrMUpz8B/EH7AkMKeW6JHvxUohQEBzkEhkJJiO2fUg6k/FLE/5X3m8x9Sb8JnyrRSxsepwJhPCXZR3EX07ilXE9RQhr5rRfVbBlhy/FO9vsp4XKAvJWU6kLie4rTGA7iLmvUOisp/mucwQl34JmcQCoBtitiiMUW1x8IHJOXcSX50grBHtfH2ZiWZO7nBC+Jj5KCD0UQsRduoZhl+PnPks61U0rd/alcik5JPCT0PFWIO/qWpJugPlwCxD5xCTZVYi4kSoJGLdH1MPUVwLfh1j/kgNxZnL609POSorN+CndKMGsELYkbScCVhGdKwM2KRowlEHjPP09Tvkg+lABfSoDtX5khhTuPeH+6BIopremVQN+1OJeMpGDFCLOmS0CzeH5uWsKylF8tbl8Nz1mI0PjeNIcpLScS7rQaoezQfjsF+EzmS/Lnr+clXQKUgrqx1jkawxKRD1D0mrgI4Yvg39MlkG++6rGbVnI8/TXzTEnhYaSfEH5PfzXEtyRwZ8nRUzSO+erkNy5uxPfT6FCiDDy5uCDYCN/7CvaPFDgvMVzj2Rt9/yvWm9W9tHr9GmC7ZIwhqH9MfOT1Xeu1qAYp4QObyqlfjT1fu7iQekXJeHmga8eMcP8qCKGvQMNjyH2aIvsSQMgooX0lzvnKiDmqYQA+oL5DexFJmf5Kx4k9J/P8tEVcEnmZFr6DQPyVFtHTJV0kTHMNj4n/NGP/dIhZxr+x5whMTXM/lzCRCWPlq4CNr4zfXwVRSsRtWrBp+qt/WJoGSHUaHQC/jsd6mrKfqFeWU5y1zeJNiU2Ip+nSODdNC4MUJTanM/Hj4iEOMyAHw1yDCHdAAGh5mC4ZcPiX7s80wIdUv2Ax9zWoP6LnTGdx/NXGl9MC32m5Et/NDk6C+OL6CVJjLJcTeZj+il0ChHlA8DPt4GDu/WlLXSCDvZVLv45jCr0kkAbraY+u4i6EvjLx+prnPxITTFwsGmhK0AvTwqUexw3ThNCe/gpgkNHJpDZh6inLHVIvzfjyS7hPA2KINUognT+F5EyDQhIlNMq2PxkbLIJwGhhANMGk+e1twFOAvargBfa0CjsrflBxMW2w7U/leS6WVlxATdQYR8RvuNmCNWsd7KYBP5GGOu0Y+ln8CkQ7DcZSEs0eDpo25HLKgFdrnaP+Wfyh4i9dRCB2W2I8BQpbazw8v7Hx9A2PjUjfsQjEP0FuRvkcwZe1PlhOCAcPAX/ThksW6VyLfrDicgqsd7R+0fjDixj0PHrK+j3aZ1TO+RoMtE47LAO0RTOC/n7/8PTD9+mIAE8XAJRUJJwV7oh49ZDmtNKQPAXnJe1Ua8qRJzY+X235m4osdA9mpgyDRIzAixlGUufQMiikqEP0NzxIw59Cmksie6ccfBAj3N/CiuFrb3xSYyqpcDf89tWCkSKE+7RRVEyX0vDz9AS5dpr4DSJV/6mH6lQcYB3wLHtNJczV78BDUxPmG88FzJQjX8oZ3z/MKML9fb2v90WvmfCzMvBe+T1u76uA9Y6r9/W+/tt1Wf6Xxu+d22jhPqMJkgIDPZM9r5w5vzz+8wwFTOFn1qcy/TNSBDOlvE0zQsxm3gigZ4D3NFtnyj4bxTiXQUGMkhV6RhmMZVm3KYytGKeyM3ZgDGZeY3ApF9xMykItK2fNlJw8VLLHfhrhJ6s95Tw2tZjPGGz3xhXet+wYficlVMp+mwvjpSIvFYTPZphLiBkv7yfycSbhczOvxY+xPbv8hgVu2eFT2aa5yOfL2MWZxG8zoC5y51zRFDOEtpqxCPfwT2VyYrSMibeZTLOZIZygBHpu77IsmsT3gYKVxPwMBYCynOiZMp0AVsRZRGQZEL5cDMp20a0R2wzhH2X7DICLMQCXbcJtpuy86aYGiTJeaFxhzoSEVMbF9Yw2KJUJ/8Pzy+O/Wpspjy8Kp2HDHnseEHeSD7l9yvm8SQICwZQW3ymONzhcloUhN0ZkluW6mgEayoxhoKPqcybgsxnlIgIZ2sn8crVJ1MaM0NA1PpgRfFCHp7I+fFJYmCnj4hce5MtMvZQAoVLGuHwGuSATsD5Ttg8/M9Z6KNuF2EwZ4yiNa2fKWJ1OI71R0T+SIKUELYkppUZmQF1m6cEzmf4xEzEQIdiYVi5wVV3I7VnG+tiMcgk2Aw4EUJ8qK/Uoc8i4cCebuaGYySYYCJwZSdBYEkQBqmwQBNx7ob1lhZTLSiMs04kIxV4otqaJHMxQqywPKTPgDTdHEpxtZBMt46TGTtICBmZKssDksMrZGOZXKkIKC2zcMrmn3iGxGea6TOAsrK/M3v8Id4Zg4XgJPrLDavhdmRlAJQ5g+GKawyTzM9esZ7i4EfxBniU1duo3cETtUIMdO+Qovy2bUcRKrlYkjgp5tKw0DoIfpxVxMMNdRihD6jQhWGYoLAkDqsRfkPAXxMtMiDGOQ8r5mzWytyoid0aoE9LesjxYzCi/gZ1RxDyJrRJ2uccKqrJtOJoh+D3HYWWh1hVhqv3meEbizjI2COT6vrDfTPjbOOkSryzrH25w5M6bKdN/CTEjYY/qf2XgMqjMX5Jyl05jeSY+D+uK7HPIECOI7hnpNy1U3yEGuBmCG4M8Pf2pTPnpT2U457nASAt9z7O3UpBRdpcj7SkTgsDit+STJ5YSiWnxkoijLAhYCw7Q77VCRQoZsduyfwnApYNYTHGS7CkVUHslBWeMIE6C71jeQfJXdtYampvYeoipf40bLPyUKm+WfGg1WDJgtARyi5V/S07/ShGYKkec6+WCUqI8l5Q68fIFitNJ6QRL3/XY6Ol/nj5Tisx9yn5Tcvbm1Hm09hNUz+h7KcI98/Os0dHZiCDNEj9r+82WireL3KOUZk9LLLTvZsGYRYmTIpp5DHF5/GXsn/Xa+pW3d7YgLMyWjQNQQnvUvUpKvX6V8VwklmYBX7gaiq2rWWNszdxbeo5vSeYPj08Sz84WyXdKfcFcwIjH2Yi4z6YUKCWlp0xIcCK4mS2C3194IYarSnouZ8uT7dta/cwCnDFrEJUezmBtUbiExQaD1dnU/AEMabMl+3mzoS8RNTgb2QcC3ArCnQD5LPPZrPJsMtArzRS1z/PejPOZmYg9ELGOivZZgyiZNQgKa65S7K0WGRFfUyOO+H42Mo8zBvtny3bhO2tszh5h6amf2YQXArMgV8w6BEtR3MbV8QzgAxfPWaMImwVwN+vE/axQm+Gfslgwrw1dsyD2ZgUOsdalh99nE9TjbKL8SvGdBmI96+ALK8+8Rnw9vBfznIbrWeCyAcH7jLPGZ50c4M1jzLlWXTtj7E0I384m0mNjwt0jEmYjyGomQvTPGsE1a5i8Zw1DggZ+i3ixPut5JhURIvFFihQZqBBhgjQmi8i1DnszBsFgJUpLk7UK1tlETXPWSdIo9meUoSxWuGs1nKIxzzgxP+OMoxX7nrqZdYoiMT8V+2VRzAWGR9R6nnP9dsMY71kHl1prcTozXM0YbVNvaJ3YRGtUfK9C2FCxD0nevuStOc+FJcIVsyCXp66rmOHIo9eKysds5BnKu98//P0f9oGK8FmF+d6yV9Gr8krnSjYUFbNKYpsnGZ+izq28QUxOKpa/g68Vx+eVV47jW4xfpUD/Yp+tMHmr/Aa5em2bK0L8/k04fmtcGRu7ilMj/Ns1UqXg8ysgV1Yic5WipuN8fRLuFV64zzH/dhlSKb6Y5ryBRIi64iDZSkSDrTDvVV5pgKgkzhfh25yUT0/sKwYxW5ng4FFxxIrA5lxFxthcClsqBdQukZu5lOQo1XPlDYr9ikMsxjb7iiNnwvdzFnuLjlVF6REVG/7nlDpE8jEH+jGnPQusOW/PReNZSVBrAG/OlQvitMRrLsxdTLwEHM1F+DInxX1C4nXOyEtzKS8yKg4tWonAkjQoeLXpr3fzN+5zXMAq9OdzjKB4WZbGMWcVChVekM5VeD+gya+iFFcY2Of/AwS3jxiPShrCyZIG1aDmKobGX1EaHlhYcxWfIJxzNpy5ABdzTkL/ieEwjxr+mf1DPHINeo4jWkroVuR8zQX7hviYk5pG1l9puMrsHcZrjrIVGNTmQntLPNewseKaPhfHbP0S+VUvMSo8JubKCiYrEVyHioTKOBeN4aSi43lOqSWR8wNOmqvwoneOwwXDr3MV48WH8s6cJz9lw6BAcVRF77+ioBdyPkfgj+tr2sAAcx0o+OYUW+aAfedC7HEcbRgcNd0wp1w8zJWFvhvuWZJzOFce51dqqAzt4XgOEf5zBB41fCFx1QbSOWSoFrgph2GQG+e4/lFS/LDwthZLjk85HfF02f5hLiPc58p0gye/B8TtXEUQKBU5cXMV4JZCAhQo3Oc4IkHBQAl3hlznKjaCJ4VE0ADnAvJiRRhxxpx0S53g11qUmAvJhgLoXEUmdQ6Lcwz+qMZM5XSulBFqzGA5VwGGMWYPqhFJz2SHB3YgqcgEM1cGBknGHqp+5yr55+cqPKHNCcJ1JhT+oXCXzqow4oQaICp0LOYY4T6nCfeKIqIqxPBXwYf6OYnTKjonapwwJwiyMB9zwpAUPjcnxaZC9wf2AifEc2m8Pmel84iBaa6sN9AcvspCH6vwWNcG9Bx2AYE1xvuB7xJfzjF2SbiZrcgXa2JvVTDM4k4a3BHhLjw7V2Z+O0ldqFDapMJcikmXhkSfCG/m//nsGdcIj3PClu3rkrbhLngqxCCP/CZJ4DXO/zBXXD+dky6Uid7AXpIA9Tgr1DDVl6Q8UBjXLlbmlAvQX8L96T854q3kJ1l1WZ+X9iGEXcw+rvessSg7YsU1viLjmzI+SpG6Y2LNUdnxbDlxXLR9ykTeOfvKic+rCHZY9ysLNgvnk+Ko7Ki3cgF4p74LfwVu4QdKyFbGOY2tGxCH6vtcnJn3QyFZGH8g+EpxfrkAznyFvdk8RazZisLbFbBOI/BXaF9LYTeybyUiHjG6KsIX6jdkr7nM9qTMaYX+bc1cOTKfFDbKRp0i1+P3D/NPwn1eAcM8+FnsmqcCWbHZNeZgyWkHkrxUZFAuJna/65r/zeyZj2kCr2FbOe6MeWcDnlVq4FXzXjYKyTfS+GZf+f1C6kLpQ/OvZOv8G+ay+UnUhxH785MadF7jfOd+8wVi+C330/nUvTCiZ8wjwv21ehDuw48b93kFZPMGUKZ6jhUOEcPEvLOo5h1xmQf2TGWvlxDmHaQzCXE5nwBf80LeUmBmHrRv3mjvvDE20jup8jUPxsNSq9r5sfn25NDqnxSfFDU5n7Am540cN2f0NfdsVedqDx9b8zAH8jlSY/OG+p2fkHBC+GA+8XnWvueJ55yDZ2IEK8q/HjzPg33Cipn5RJw/F6FvUtRbShx68BMzwGv1loLDie+f/1RGEILzAkA04TjvcIw8ryoAtDr+/TwgBOYLEO4sGKp6zOaB5oe8n9uLiktVyE0VLOiqHON5hWTHvq/KuJnP2JaCGD1rrgqKhGo+33MO2yyNZV7DSPXXM/MRTTA8yzIYWYYLS11YuIr8dxCbFMNpiJf5isxPIVfMG5vCvFGszUdcGqA5D/ka6hHVX1yu5XWeOUuqj5jexXHfPHHGvGG48QrQ+YhB3nWZweRmTuH9eUf9z1m1RtVWE/PAGVzPnHMK2XnjYDVv1BzWC1aujnJ9uWrTSvNOYevhJIsAnzfaPh8xqFouDedA3US8//SnMtUfN+7wqkaIoGqid6rAv702VIXPqw5fYp+rxolOJE6hcMj5XHWeUeX3HGu41Xgf2OfLjD0IDqoJfHbmjxuYovBfNeK66sRpNSFupbOqxmfR3MTGoArYitpeTfQMF4tqgnhXE+a8qmCpasB31cmt1QhO52yvOjCA8HE1QU+rAjFEagvJawqccFxeZE+uTkjvFNX/rfxQSairqs7arSbkSgv+qoa9i+4p9Poh3BeqgHGaE1Xw31UjiVmaoUV4VyJ80MCd+fdCFQBCNQFxRDw7ZxVxKYqEyetCDAlQ9pftAmDBIvSqici+ahh8vIOCdxCpJMaqx86qU7h4hUmMyIiNoVdYo5xbTdRwq2C8qoAQRX221GMVEJjVoO6tg2fV+LNDgCxovbBqEPxVRXgjuS5jNbvA5Geh+j/b5Zwm6DyaogoKtNhBo+ocUJF+rPXqspFDqhGxjLjEU3tf1YBtTYdVwbhWjfzm3dcQx0zdfP+w8Pw37rAAqQZByGy6EFMQ1TyJLsQ206pCGCExCjclCxSxV3VCCUXgAvHcQoWJL5rYqtD0gVgtoO8RzyxUFYCigquqN4GFMIdSs9CKj7FroYphjcQnUKALXPyq/hxQ77D1E3y+wNU1hVVmkRg3NAnKzoVKMMQJ3LIgxGzBGT9WfAQxJvmhjAvxhWq+/uc1f5g9Fqx+vrzH1MoCkL8FZdDS/Fuo6tjI+rcQ7OvyuwIMNkI/W2BqasF60VWl91yogr3J2OfmUe7R6r2K9doFhqcXKko8pf4S9IM5z4Wh0BsWmFiE+ibsRQtZTL5cGJXxOmRjr2A1VwdVwl4BCwtUPxAE80IF4HdQAC948mGNY8bmBQTP3t5L1V+V6CGCDloQNGg27guScA8Lb6HKExoXmIWKTOwLQtNd4G5BBCelJr1QZRocRy5UoaI3pMF5UiNgCc4w/CxYAQ6S5jwST6EYFhTyXwCbQIiXbBOnCEsS5QsCQS9Ifmni0lHUFEZYDBE+IvFfUKb+BQrvkihmRHcYuwXrTZMBQwtVGZPs8GIRsxVC1DK8J4pywZ8FtE4CjqW4KKwJyM8q7QPHlVTtLHDDjnDGgiQsmHcXKIwZh2ExdlWFVytEjCsEXsKhh8Jt8PNChb88CM/T6pqrY+k5ajCSYrmAiGCuz1fooVe7GOSee/nb+4VKfhDl+HlBuJSQhDvqfyjcF4A6tA6ZCyF+OC4HxPMCehlI1XfFeBGlYcvA1dazFgT8c7fbCxXlokPgFHIQd/gTcvHTz0/C/flPZd7q4oTVvNAE34K9nve0pm6OGfiMJvyK9PvfuLz5Qt/9nfA+z9g8L3z31n2ehJ3W+IQ3fgvckPiGYvTOF3bOQIbAFDmI5vMKM2z9Bnw1/wp2FHVuYf5MOL+p/Jh/Lf73xou4GF+o/QbCfQEUBm9tLSYG1HwBIOUmvfdG+kbJ8jeNxXscio3h4hvgr3fh/l5j79z9vkyr9l4rLvtD4b6oEPgiQO6LNSPx18YTuDiBZhL6tCjYtuiwg3tnUQEt9B73fA1/b0E4ZzH8ufYrp5INL4S3GK5afm+3gKjJuKHOWQRzh+SHfL9Gvw9hpCaT2WLNbveiU5Bl8+WpOS7Hi5q9NaLeavpeHFYXHDlcDJ+v5feXcrdI5S6D/RR1SX5eY2qspvPJImOjWDs1mS80LFDxY+Nj8IHKpZW/JP/FnlRT8lmzi5RFh8hZZLhp0coJtTixtSjZH9pT47mU+57LeSi4F6U6lfyoYT6K9ajVjbZ/zdEjDToKqdEFhtM8vXtRi7PlDOLZxRqjBwg+X6zaNd2iUF8iPgR9sihpAI33//5TmSfnvr84OF+VCytH8lSjqhmNqfmAJBF3rNiASLkmiwhVpNV0ASaJ1kXumRpO2FqzXuTESS0vFrLCPUdCNeLnGtYUQnty+KrJ8VtUhjBJpOTyH4iArD2LgKBYrAHDYW08xmPkFsRukRNiNV6ULTLNbbFGNJ4aLYYXhaGdIiZyeKspw0ltXMiP/cz5wog0eMANz1QuJ6TBhxPSXGNfRDkhjGeNbwaLQnzH8qPgdBEd7LK1wDTLRS6+Aa+Ig19tnFfZuqvRMdCeZ8VmgEEK25S/6CWCdoG0CAwyLGciIqqmiNga1lOkyxuJaxFhzGH5n/4j6JNQ6JF5YwQg1+sXuPoUeuCiVyQy3Gu9uCEvOmrC8C31EGBoXXQKeO0imRXBNWKQqQlahuMMw2WBqE2pvlWjMbjA9Lqx93+893Tj/rdw55oC1RxqgmCgjFdEzaLizCJABtr76rvUdzXwXdQOgOQXGOElPls1rJrRnxoTF83GFHYh+yAxrjnsQc9kRNSC9j61BJEH47aGCXmTPzUDRjy1KL2X/d/K8+JiVwP3EkQly0kKR+TqsebET1XmwAW0Zi38VnNwXY1p/jWDj1buQO20xrdmrPcqX7smn2pg7VWNPoD9jxyUhD25IQ61Yey8GuC/FYdSj0IwUovAYw342aIhDFy5UHX0wJrClzVi0KkaOD/7fZa3U/iP9rmajRetlyOLVUDn1gz6rhb0OfnsQLiDSYWAX8NEDiR2a05wWpJfAwi5BggwZG+EEGoAmdWM4rDmE6JQnGuOYa8KFBqKDSRvlQgxX1Oad0x+PcLLGr8YrFUjBLhVxHLLItyf/r2EDpg14DKhijW5KDFsGTSp7yuGoSpFfWnYrzixifKdpwdZh8uao2ZqQqyQsy09JTW/1hTRa/mc2GvBe8FQc+iFmlKP6BBmzVMVuCyoAUIWtceaDwv3ogMRyttoLtCBzYrn2v98F4m1SG2M4jMU7sz7S3/fuP/9nyUD+S1xP9eMAj8UVC9GVX8sOBHMeUtVonlXjaRbGwtWzu8lj2g3CqrwjKV8Em35MK4l4d9LRGyXOPGU3aNKglEWX4B9JA4oe2vA/kr+liT/QEwsxQ4s1PkMWcN1VSWel3KiNLSlGvC9A4vS90sCbsWYAfYtKflHfFgyXAgsGWqSxICBW1LxhFQnSzUFR4Ycm+zK4Fqr61wsYy4UPCLZE3tkIK76zlkqopcQuFyqOYb6qs7rS4lsT91bEUxM/EwrDoJ8LTk0xZIUX6L3LIF9mNzXovUS8p3085L97GfhDry0VCMaf1V2QLudWSL2XaphgWWTXXWIP0bULCkFu2RI8pJxKECTjCZ9KQExI6BcQn8Ohh8KL0tKLixFsmTBkJPQl4zDwFJBw9US19gVcbsUCv2gmS5xwokZZpdCoRox/CwZ6nFJaQ7IMLykvGetvbE9jIJuydE8uGF40iLFXB+1+GFZ5YSqj9+K4FPJ9yWjiFjK1iHVA6tYf/UOzCj+lyQ+zF66BT4s1SIvmCKGbUtulqx8YBzMoy+RUl6eVIkhF9QFS0Z/lxR+Rp6NvhA05t5SGwZ+/yXclwQnJ7HQSTnlWeizSICXwElSuoFaeoV4vy88f9Y9Fo1nvIZf/6WcLjrEuGXvxQnaHJNf6fYawfziK/BIkXy5+Bvh2JrvHLZv3y6/FsmX5B63xWMhFT9wg/Diu06I4lVvHb1WrUDCfeLrNr7wUp6JNLDFV4jFW8zP+7LFajE2prcF5+r2jWHhtjiMLr7RhlUUvxSy7+0brLnbCdh6+5vF77bAuNz+C8XgbbDeyoXJ7X+wl96miYE5J7cTxCzmU0a4P72wbDwg+/xyjXjfQhBSUm5/naHZtUwR1K3wnBIs9LnsecuWZEhnK3aJ52gxu5Vj/vfZy2EMb515vGXiWbNhbpmLEbFe7F9OTYC3cbldvhXyZ60Ti7i+NZIiUjfOOC7XHLZw9XCbgBhvlXq/dZ4XvLcM8gfFxcs1As/A85Lvy1Rd38r2LWsC8FbhnlumbmNwE9aTsu/yrSLQUMF2K/dE1R8mP8tgfFVM3xriKfD2MsMDy0Gslm+FXmzg/OVbPw6o55Zr+d4QXa8Apy6j+TLkbxmsUwsOsvWz7MhX9OAIxmNZ4EtJoy7fYvGB+CWiBy1L2ozjHtruceG+pJEfQWbLWaHHCSqiIJdvAZF3GwTslkgC1WSJAlwOxNyyIFaz6ydgCCG4HDTUZaYQlrl4KAJu+VYXK+Eey1ozVwg1jNGy0NRVgr1lznA25WVE/HCiBCDH5VvdTrKIb3k8SIPKcg3AgjA4LRNn52pTIy1DQydtvOWJfpnAAJLD5Vt+OMv5fEuICar+qcYcxvCWEYHMMMvGgvg+h2GCz1j7JRxy9jBCio1tLR8nitOoelpmBlQ0P2HsxJq5Hd+brNkwvrdy3FRxdMvzKMXzy8pQtMzkjrTvlq4PiSuWLT/f5uuJ6pHLQv9QLyGoixVhn+VbeXDhcme56BJ7661+4bREDC7UULqMxqRmsL1GX1AtC4KUwwz5udJrxB7DxDqX91slNzUBc4I2XRYuDJYZTmAvRJChKdRbnAa51WOcqwHCvud8f//w939CIgyF27IQTPFzaQlC0bykdwkypMieFKzImbV8IyFjeRsUHDHlkk2YsYMiQVfcb4UcS3mSfK9F5owhJUqYSIu8gedylHiFNqpYssaqZniOIFHp3aWYuq0J/MFhFcWcxR6tHmsCnpGYVp8Xwg81go+0PFp8RGKj+VfDeUKsq1uhJ3B+I/E0ckuOI2qGmEjP1Zh6ES5/1J6K9NZbhftqkZxWM+6h6YBbI2cHfZDt44odnFCD+t4tyLO3Tt1TU+whPiMvGbhLB6omFf+g+NScGLH0gRpYC2AfIgcbpY4hfqwZ6k14T9UlssbOCHdPEmKE+yQXUrAeAvSAGG2sNVyYJiHuVKK2VnAeKYKvGRvBW8RpwY136a3kUMpXNYE9CA/VEtiPCM1b52Bbcwx2kUI3KRY14U792zIIRV7kmAfCWkQObh25rznFbcyFWFGcmHDfJfCspUn3I8M5S5YLh7fQf2qR3Fmb0DtVw5D1Gr0wxdnkjbtzrSiLe4f6eQU8b/kNrhWDjSsFnVu0X9bzVhLvR+EuVXxWQHut5xeZS8neFSbWmt0riW1deQV8TbomUu254sDbyhvnjxTnWzBi6TvLxme9+Fox9E9kn5WI3rOcmG9XEva7SfRNq70rifvJW9UsRXPBCtGbViYYx5VXxl1ijUQL9xUDuawIQF+JJNcVI0mtRAi6lYQiQbSr/mOtMGCOFT0pCWMFyIeEjxXDoBdjU0xBrhTYlFM0lRVHs1gRfFsxCp8VJVYxw9OKkS9WHPywEikYLdiOFYMrjjpfMTRLKUYpLx5WjPj2cPOKoV5WjHsg8UpRvyvOXugR7isJMLsSgZmYS4eVeprhZMXBYyuJhfEKgLsV0O6YYTBWe1h8QvCDYnklQpDH1MZKRN/yYEbpu98/rATCHWkSSEND3llBbu7rzL+NKxfMuu03BqRd9Ui/6rIdEqFJMVELue4jEsi3uiMW4G9vUr5nWvV4m5apvNX9/sX4vWytO+ZsyyDmrrNXyF+R+FueFGYT+KU257rfxzcVB+oipY4NiyYM1IHvA15ABHNMfJe1HmeIGWrPz/5Tj8RJHXtOwqqH27XhN5p7uX5hEPyxnIxemri50YGfFSX2kO4rin/qxfaZYP0S7oUZXo8gtXrk/nX+vZ833/UIokfJoO6L35jAriv/GzynDl/1gppq3RAnb5OrF9Cw6wkwnAr3wWCX+lyoGQIiYxmI19hZ9VcUZvWInNYTkLWXEyhs1o1+1418mRFVy1ptaPiqOzkjBWbQeq4zMZbiVzf2L8tndSw3KynEaF0Rtin6H4GJ5VjurBvqsi7gMbK2rUPbMvGbBM5mFYuei4O64SKtTp+9bIlR3RhXQc94MLIcqzPqCXpMbK/J7/tDuK9aSYV4blUDXPYZBhSrdT0gq1RD8zQtwqbVW6CQMmevauQfPKfuH3k7s4LYc0vbBjWNegFCuu5odLHvS/EIcajkJZvbVSTudVvzWI0V7sr7q3UGByAPrNaJ+nfglDt/VeCLlRSxqRswhcZKI2+LD3WGn8IaBkX6KjqwAtwJX7TUacyJja6O72caUBA/Y27P6gxOqFqu8zkl96sLtZF9v2YUpUxdrd7q8V8N7JB0wCrXb6ycBfan1bpQN1Y76hFi1di7VrUhvR75M2CX1ANXNbvqCfv3LWFLPYPxom7GCQ23qvDw2HPZn1G9fEvUXz2PjdW/b9yf/vF9ta6TltQcVrObKrcTq8JeP9+v0yJqFRDJuWHAAJLVUIjUZbG7HDy3yhT/KkWGYIMIB4ufq04PNauhCAVEG0dOq3UFrLcKkVsHo9iJWBPdSuGG2GNv4YT4SbW0Gn4PEG2I/1Vg4FutB7UkYGu1rjQlNF7ob1zqAYYFIcJyRT2iUdZlgbV6y/MPKQ5uaUGWrZ9VDVvheXUhX4R9q1KTu83YUWcEFlO7JOdwNnF+3xI8xJ3P1N0q+Fu8VaWprtQV0VfX40HFZSX0l7kYCjGzCtSVhA31osDzW8u6wtf1fH2uMvW5qgwfqxKHC8PUKnABkMvHLZZXQiTl8my5GIwWk+Bl5piwrBN1KQ0fAk+Lg7fxNzGrdSKudX2AWK0LF63Gi5xV4fJtReCoVWDoXSUwnLWf2y/Xr/XafxLutz+Eu7RWgO+pG7gsQVHPrwbNh3se3gN8boX6niAiSwyi7Q4JPfG5qk1U/G+JnBqwsMLEmhRvXHwC4UGeyQhvUtjc0jElf/tjiF/M92EMcsR7ywiiWzoG0Lm3wue3ug9a/XHCT8K7CeuhaHK8S9U6UpurhABb5bB1S+eNE/erdaIBG7hyBfAXqrPbfP2vgPGihJi1NrL2LYf8c+vIuaUWufgw9UYKPWt/Ywa8VYSTqEEN7UPUEALwktjXmEugFaAf5nSEwHlIflci+zQ1IJPDszXehr4J2cnUL8zr3G9OUNze4nauEHhbEfARXjxQOgnuecwNPuTfraG31J09CXmunrlxjyW7Va4R/E7r9je1O4FwL2I/iZQnaj/Y8FcmNCh58LiiCO+VCeTVZX/9P1JTt2nz+ZZ5bcU4vCe/7ChYuFv3mQRvrBTpHyiG1wrCimnQvp1sX5xonTrxVGRfXSmCX8DLodW30o8ngTvbGePCnSvMNaBw15yF7X2Pss/7fczzKewvaq0VuN/ab+bfWmIsraXASSON/Zbv1iZcSzG4eS0+kc5fS5ibVHhfC/yOzflaQbyyxuSpqPitEfFZI+Jlwc2a83xrLi37pe6fa2+Ib1PV/VrCvp66ptdA+9Ym2Ost+669Mb2zltgvb37WisPz9w9rjXHhTpHZ0zM//1cjYrV4GnyjoYTNy/PkGQ1eTGWfSdXM15jkaGIO/rxhSF7jV3w8gsJLZqtAfn/+3MhjxiyAG/a4UuIYFgkNTGwgzZTC4FpwjrQ/9xxac2vg82uehtWIbE6Ncd/WmFrSxJbELxomLHZ7OC+b6zXLeQ2fcBdxZBCR7ouOhk1grBmE6lqKga4h4yrFUOuJ7xrHoRIXNQw82FDqv6HEt+EcbhqRA3UD+xwZXKEYNX71LLHnNIScUTY24sSmxI3aICzu29Djs6ZgAuUXC3dZeCnssauARvNejnDYXq3bY7Em1F+u/+Xr6IdwZ4mswZAdQIDIWqX2bwBnUeK/ESzGH04soD5qooQ9t66ItwZgT2N8iEJzJgGC+nlVs70B+FaniXDNQjwNJn8Mwa41QPxI9hKDI9UsyeG2wZB6XY/DmjIEhjFXcSvEntzTUG+wLfWE7zUYImsA5yDcIA0ODaAeeZLF/W0ANa/ZotTAqoerOc5E+MiCAyQ/jGjK8UBMX5JqCqnLhoFvGnxvXEX9aQiXbiDO1Mu7BL0euYRJcn4j0TNa/C18pnB2GB/Ufu9vlCz9KObZ1Zj65HhL03ENYiBD4tNIjDGwl4m8QXM5I9wbTEOQEtkwNBPJ8OzPt2DR1A3NGbGp7tin4RwCGkBCI8XTqjQYNEBQoULGS6JekWIVP9ZiRAeB7Oe3DpsZu1mB0ACFKkeoqOhqOIbpBihCvSTYMOSjYcAMui+Qx9VYUm8AC7Wv4cB8AxxaGo7hJlsjDaCxEfkkfyN8axwkGkAvsvBbI5LHw9oP/bxNKCQsNiW4vEsyBFj6bCPye4PoVmvB03vrPk2hYsgw5MOfWzVEw5nbkF9jub+h9IFbpaYbzj5m2Ys++1m4N8BGwQRiva47tw6Q5HrDUBAv72R+XkeanJDI9boh0Q2Q6AE7sn6vN0DCZ+xd1/xpKEK5AcRSiytCmMT56w2DyOVymMWk0PjhfCmEsi7ZIax1EG/cPusN/mzTwNzAmwCJjdDWukF4Wkmx4agrY15Iv8Cb9vWgnjlelGyg8rr+bPe6Ep/1BsMrEi/XFS5Af5vTwET3evj8rcxz6x48aXkTOJOL7zrFzUIOc/iJuQSrC+c0DP0TxLEmgNZRQeQRMgL/rBM5ob5fRy+7NN5oAJyv2GQdstepPgEMkOtCzNatusQYr1xulD5hEqponWh8BmrS9XqCfsXhRsMdokNfhPuT8d+RRrKOCvcGRjKUaAvPWQcEpOl5SehqNtaFBiskZL2BDxXrTLMmi1cjHMNaR/IM5mLdY0ddyadBdK0bbFs3+CQ1S4ocU8VqHcQx1xDWnbnknlnn7OcGT05gGHKGCl81vwbhvo5wjDBk5d4Jane9DoqiLL/WbbxnxbaFN8WYamITFTGGy4f1hsztsT3Ewmvrnnfr9qF3XRFOURxcN/JXPfICSOulIb9wwp0SsZKwY/K/HuB7HeAZETeCuIZqBhgq1j17NGhtsV5ndEHd18uz+VuPwOs6wQtiL63jXLZu6E0QLxJDlYgVXD/8Eu7a4kSe9Pz6G15ril9rwPurwrNrzP/GxtXjJwVMyQ5OqK0lyi1CgIgfqeKINtlYrKWI1WvVSCwPIGIYrdO135h3JpHntd/Q95j4rP3GmEAvF7y8OEmOXnf20bV/YX0W/fw6wIvIYLquiNa3xnUWDlhLXJOvidvgPFC4N8cDsfEaxdPMrDdWyGvNhI0rs9fGJBt5c8KNumk/f6INuvkjr/+sooq0+YaaU3PythYlOIqO1cbvIISbr4iVRoFcTfBGEhw1fTneKEi4/y7D/UT5o/nGhHszkV3Nt8V9ReFpI6OX1pyabu0NXSa8og74Jdw3QALeyDy74SG6Jp7kDYGsUcf/Pi/ch7J/zMfm+Ocbgn3/7N9kiplrBs/fbTR5O3763/xlw0boT0zym4mGhKbvPOveGyEmIhvpWHyVBs5hlvy8KfswhquYZheSXpOumw2kvjg/m35xs2HEFGmPkTc2hJhtNOQ4kfVHxI/1q0ns0zTisyn7syEIhw2qRhyNkYpLGHsJJz9jxtTRRsOexw0pTgBXW/iJ5OQG0zcYfKw3MS7i+ijKCxtKn91ojl+2SRwq9VtXHTd9/M/ir2njnQ2Fb7k4bwi6ZsPRs1LwoqU/unpiJD8ge2maK0Y3bGj+crzalPGBxm+D2DvUyRuCnRv2/PM37mTDauYFa/YzRAxuGIQeKVaDxvrzuTDwnG1NWShsAM04t68kvilANIl/N/ONbUMYIjaIOK1rhNOkgYuSyQZQFOsEYC2FutG0CcENYaBSfWmON4XsextIs2sSA1+THtKoXGw0cfLhxBIieDccDTdX7w2a6DaazEDfBIcTwpeNJnNBkKl3Sixy+Vtv6LVP8g4jIjeYywGNPza0CxKKa5uCKGnSnJKr76bMaSTnNPODARcjCqcbTVkYrzd03iIvi5r5frDB1RfKa0ovswjFDYkjmCF7AxgYqRoj6yI4++X2lLJxg8HdutKDcivkfWWPDVQ4N8dzI+2nXSySAq6pC2BRiBF6Ax3MyHeb+EWEaSBoAoMoI2Q3tKGoyfMcmV+Ce8b8b+qDMDKUUWew2GnKYp3q6xsNRZcxvZ46e6MpXFLSfn3/8PTD9w1C6JJCHRDv5D4NZV9qSTY0lM8oe5uEfdJ5TcY+6ZwmTcqqvYiPTcJ2KeZEg1sXniHj0QR94Gzh/i3sTTZTKV/c800jzgzPrDeBnHANWasNJD/cb34s9dYQcN4Q8tnAsMr9ZmqDGqCbmM8qLzWFuhW+X28qzzflmhftaRh8awaXEQ2Fs5oGrmsoHGapB4Ub1xtGzg6EoMZ/6828wN2wcq4U7waIBSteGgDOwD4D56th7B0aZkGeFHlcw10DwJ0llkg8AH82Gkbu1mIK6CdJFIt9WsHTuqQLEM6qPy9UtzVprcTxAMUp6w2Dn80IfDUS1WgD30PUCXm7noW7BO7MC5tNY9FoYGgmCmDTsX8zsvAbCXwI41J3EqVyHvWbguhmhJKEMW/r3qY5idw37U1jvWkkN0RkocLEW2+ITRE1TP75l8fGemQT9wh373cWcZVC+Fn3T8W9FmHGDHUmDCMXHsglRQRnJRMCXq5JzX0e4d5wXqY0/NyaREc0fuiaTcvw5eVZ64DVMPbvZgEDJ7c44Y5ehhovcdcbkXivF1gjjcloicz6/uEJsN9D0G4G/2aBTXyee3aSYjrh2lR+Tn3WS3F6z9102rjZnJDYTdB0NgvOcRF7bEbsuznBuKPnbTprZZPgFa/fm4njuZkgHyJPZgh+0xH3TeGsTSAnm8De3F6bSl8w8+hLDF65LiexNifUWyb9/qbjuc0EcSrSn02nX0Vjb3NC/GbloxyfB9y2mQDvmyB2NiP75aaT74vSloC/snBHg7JZcHPdBJr/pnWgMNq8aSSATQNBhMJ9M0K8bRpE0aaBXNG9Nw359JB2TJPZNIqPTYY8Nm1FNvGmvKmIvTGyBZrXppELNpV3Y4fTzYSkiNi74fSdEu+acN802IzwpXYZswnU7yaIBdSXTafgSzlcbih+pBRPmyAvefC1mWjY3XTUckrhvpko7puAL+hZm06huGmMFdqzU+iXTaMmMJ3FCHdvH7bwgIV7ECxYLqwRnbBh4HgAD7+Eu3Vpjdm87hLuVZA/EtmoPt05fLwj9mi+r8Ji8Ybiu+H87i3VyzsmXz8/G6/hZ2QcNu7S4nPjDed24z+Kz0lhKZVdZC3dRfLlez9/fVzf/YY1kxXuW6FQzPx7i3FowyM+DUHZCvfQRGzms627gpOACnEiplt3uv0uICHf3TExBvfbujPGJ8QRg6ktzZaUw9EdmKuUBX3H4DjVe3fjcdxqOrCp+LbV5J/dArGvnnUn+A98vtW0Pa/W4R3oZxOsrzsGs9k64c6/s2HjbwG8cedsYHcRNdR0YN1TFzF7WerRwNVbdz5ehW28S9gvpDi89KpI3ttKYRvyWcwFGcCbZuF9V7Cu8GChaNvuDDlsgvyM1p+iD7e8dt/pGgrqhZZL2TvVpsyNe/DiPyBu/HB46268kHNLIcAtRAAGBLKV+d+tQJBvAQQT2s0R1NadHqwcGd85QHfHCBnKP2QYycYnyBsbh0A8q8QtCIdcfLNnNgIcNQmfiLxtCXnYuiNiwxDv1h0gPptyTjeeB9Mtav/sOU0e81JdbN3RGN0ChVGuDrgaMhLzVjgAEBgj/Qljkt3njn6Ow/oWQ7zkPkSNhJzEvbfF7MteXISD913ehi1kEG0IIu8u4IFGxicB99TAsMXhUsDi1p3cRLaCGG9xXB7WdOOXL4j9It8GeCXzYWjIW2FfkoQswdciPxP53TIKky1liNsCB9pczRB52yJELCtqGTu2GE7ZZPhzi8OZMAxvNYXe0iD25/blLpiadO4pe7eI90leEfbP8uEWcy4n+LbCuiTyvBXWIqEhtoQLW6ifCRpvi3uGqz9J0N4p+Q944ee5d3xdbnGX14x/Ir/f6QMi2Q9BfP64cX9S71sSGMJGqzS6LUaMhgAjJ6IwsAGoxLOFYHDiTxsKwuYfCmBWjN4JjYUrfsEeLgdUQx/7nHhuq0kPNJRAo87LPX9HF/WWILY5H7a4W0dmL7a53MkkvyU11uefN57F+5ZEjAKmSR/vlKFXGo6bTL7uePG90cxjhCS8O3oY2ZJwQZC2iDkJm3eKeGSaDGczd8PP+cuRJjUEkML9TuZKarDeCniROpMlda5BCzmm4ivFfkvCJGFbOHTlbGv8uggiMXxH40n7DU+ON6jGeCdfMm0JwpyrOWq/LYb72VoDBtbNptzDNtHeEPQ9Do9SzXLxEgUcyGkkN4S8KuzDDfE5DaJpAkY8srwp9PhNZmgjxatwEcNe8iDxaOaFORt7Rg+EWCe10B3fW7c04X4n3Fwreo/i7i1JdBO9k+Pv3GAmaCPxMkwT7ly/aNL5HhPu7GpijdbTnKNWM+EZzVc8O1Uc3oo9k8gr+kxMrpry8Bi1378hZ5O0vzlhf5oR5zcTx6v5G/DPa+Ov+cbx3HxFe5oJcdiM6ENNJ+8J4uZN9tnmG6mPt8IFKfvmW+5jEr6babHwz5/KbGnC/Tdf2/+xc1/Tvu0E328naITb/xGi3H4DZ28n3G/7P5S79/W+3jJ/bb+hWLwGL2w7es92ovPeOfB9KSsv3LcZEG0nLITtCRXbNlD821bRyJ3T+rGsfm4L/94ugNC0WGj2bycS7dugaN82nB+D1SKagzV+2xE1tF3gMLYdWS9oPW5H1Dj6zPaEhAaKz21jjmMw5sXLdgSHePnaiqFtQ91YcOfxk92vZffPyoGWWKB9Ylv5fDtSwG6DOduO1Bzb4H7biQed7TcwoGwXwAuevoXi1aJ/tgvq09vAuduR/OKsw/E/ldk2CCiKlLZbyvMtWuB6G9a2o/FtGxvndstgXyuuSLcFYbStLLShbBuEU9Z/b2y3vaTxjCdpsNlqBe8z71gG0W3jQCU1mE2j2Jb22gYF03aQu21D/ikMZ/dB8CfmtqXs18pjABESFq5QbW45aq+Vxx8adxJbraD+WgwWhPO8jXSbqkPF5i1AIG1z9d2ycYWlnjVOkjCP5t502dLCMZCC39HBdRupl5bcC7aRoaqF2bLtzCNycRf6hORgy5nXLQMXWbg99iLTWi+evGi9fauF9UB08Np2XDxstez1hmocFl8t/tntFjxMPt24t/73fRsEVPLVYpo592+DkKAam3uP2LMsz1ni4I259XvUppbhrJbDp9Q5o+wIMdkqID+T8MOb6zsgp60C6iWydsJGYPVtyxLHViTftRLxJtJ4rPVs5VvDMJYkpi3nM6lif1cgb6V4r2XwNbVdLSNntAwYvCugt7QALfJaeYzh+JYS81YB+E/to7c3KQORq3ZTvdMy8Knw2S/h/vzFTvDgTtNZjC+fN8FG3zI0k5ahubYiEhAQ4A4iWqnnGBt3JNubBQnfJggey/CDfH/nbPyciG4R/liGIID0djRyiBGwrQRCpRXRwJt8/naQJtFyNofM+zstQyxBfG6lHNxeVhNoEs942bEKBeuwxC3pOQ0PLUC4tCIGw1ZkLO4AexHfPXXYNIpL4vMdVIww3+1k69UqQGNFD7MX1eOyn+3c8bnZoXpf63++y7ZUl3Itgy6xYNrJaTstg2hvOcRjK6KGkZ9TXB5ZY+/p+a3/pb1oaen52lH4aQew+2/NPibckUaxExwe/hw+qzWdnbCJZxzYkcijRZBii3iPsWeHC2K2eEA/xwLfGi+8HUYEvti5IyXTervdMggSzY87YAgJmuiOct6ONoW2ZOG4A9gc5msH8Z/xa4cTq0Ch7mj7tzAy3gHxSgnvHUCYi3i90+sCFoiZs3fQ32y0CHuo/S24M4piiu/C83eEfO8Qduzc2epwDM/N8WHhb1G302LiyXEkKuhbivBs8UMMZ4M2EJMCsJUXNVn+31Hyp+b8jtmf600twp/wO6YOd4j477SEehXwwXHbjiSU7wLMIqJOENw5vkH6g9KnWQ1BDQJEX9kR8LnD8Q/Vo6m+TvVJ4mJkh8MJ0u85vcP0zxy+gN9ocPHf0fLInX+HcbkUzx2GD3Za4DBF8bV0ocKdq/Dyzh2zv8AzO8HaFnh5h9G6mc+/f9gOhPsOQxY7gmhHhDv33A5BgDvc3oGNO4qNkr07SlNGhPsOkJhsIe0EydkBhpwd7hZf8o8gDSomO2jTYMRe9qwd4haVOguJ+86dLDy2iViHmOBisc3FK8TenY6fbcHfbYlMgQLnamGHIkFG7FDCY6cFLqZxaNyg8UEOMyFJ3yn2UIOZ4WJBbB6AXzsAj2QJfQe8+NgRms4O4y/3PVX7CM/tgD/vCDjbsbwXxkjgGSQnIi8LvLkt4Q54buz7BJgK95NE+fadzrNhnHOcp/gl4lwRJGTtteQLMjZ2Wp7uCCGlDNk7jLCWBNZ2i9chO0LtW7URO7wpWon0z5DDHWkYIITuTkvvYVCOw4sKrd4ErJO1TumEu/G1fadrvh2ttyPxvWO4hfmNVYDJH8J9x9Gk3tf7el/v6305V/s9Bu/rHSfvMX5f78t8QUQI9ycQ72Z+3m3JP2ufh9/vAobtCsW1W1AwULtyPrTzMSty7Ro+33W+V2QMU56F4GlXwHEMDqRzNHvhs9vKM219712wMe0CGGJtbNM2a8/uGvKT86Ptr19LbncdeZ5EjYj5Bs76510Pb7Xx+BbFOVau3tXy1p4Q17Vt9r7kCLVj11K3r8THHpt2jX1wl4p3W8lDG8hT28cZaq9oF5urXaCHTEojqDFt+7BUSGwie8lOrOalen37Wbg/ffD9Z/Daz2QeAqmdF/WcgGVJXEtIOy/Od6VC4c4LxUyb318McDtYBKio88b8pYQXCMzd4Fk1ocyAxdn78muaXUH47TJFhdpM5cktUrPnt2kxt0vYIv2piafwOLHDCl9AfLN4bjPPMoPsrhQzZYhQSZupH0lY7Lb5wVvD5q4wpGRJjMUuODTtekUhFY+2jOVChutMLMRLhAwfScIwzNnfz2y3eaGhCeRdpdaRmHCC9mf+2/LQqvWdXYFjuCFTEhu70pDdpu0VRXdb3neXGYJVwSbhtK0LD5Lng77H9UWtVi1DITnUt3mBzOoKQQftCv1l1zn87SgCXtyzbROG0qUDgmuqP+3E6huGD7a1S9q2bcALuXGX4EWtF4mXyG3lUoriSwJfYv8bt+VJuLd+CfcxsdCmgTXmZHu8ge0wwpkKDBfMXYYQdkHhnhOPhDDaFQoxe26OZLOfBcXN7pf1sU03H0387rYE/9vEeVrDo/LZJkib2l9pWqEQRUhiVxN04TAk3KQgMdaa8S6DFbLhtpWG2x7HutgUqNoJ66jNNNa2INzbshDYYYQcWedtZpDRyKmtiK9Wng+kmtpt6YvjBtJOKi5tXhBQGKEGHK4pWPlRHGbDmm7xNpP10ZJzJF2o7Eqc1cbyoV46tEEBH9rWBkR1m65nDWsqZzMXGJStuxyPcDjS/o3Y3cb4Eq0r8tKhLdsqXbiEedSG9F1goKFqN4zFDqUDuIGFs0kaTBiRh1zChRcDXPy5oYriNxXXjM05/tE4uU3z+w5wESX9Fmq3DQx8bWGgMNQ4yxtCveQ0I8G7ZF9qi/z1/cPe039EQmxjpEw+3zaQS1v4jDsDWSiptWWh6z4z5v2W8Tt0Py2HLWO+tHijZ7QADLQi89HSCUY8Q7v5awu4B+3aa4H5s8QCyTlSf2i9IvZIcdPi6MGhp960Z6z4bRvwZ6lZa85bBvHXNtRLS8mvpZ5aRvyifNIy2IPwhaV3WHqOZVD19Lc2kG9rT0GGC6RXtI3x8dR927Fvy4gbxN+2MVctR19vOXgT1Taa/muB77WAfqD5hvA1WscefvDGpYX3x5/Cfa8NEKIhaXuZaWHv5ecW/Qz5GVBwe8LneygYCH/2WvpZe8Tne44hY4/zBSiePSEGVDzQ56MHJSA3/yyq+O4yzwY/u4cWyoZWcD4gYvdihB/3fog37iwOp8KZe4CIYzGBNPY2VlN7Cia8WEIwnxy/TuzttUBRFeKA4SOtxihM7hnF7B7SsNpyzuEYOy4i9rhaavGcg9qzJzTobN3lfLgThm8it1xc2ZwH+dQ4aa/liLfxsirrB3XhIPZTI7e+1MOelDcPb6BxlfJK1VzL1gs8/LQH1ABn+x5X5wn6fGzP3tM41zuAtIA6orgz5BOqbr2xIvhTwuHOy9+4WwXeHiK+BYG7pwhihJg4e/dQQBkKA7F/T4gHZ+du25fsHW+DZH7eSyic9lDhruDNGs9Y3KC48jYHa1w0nFjFiKe57RltDe1Fz9oziizEvz3Af2u97FkbKcBPe8Z69XJZKt7adYimPUNd7Bm+RzC2p/Alu18w3O4Be1lwo4lDKv7oBdLY5YSxnndB/O45a92KD7Qn7AJ2ov56dI/G6yl8RfXOnrGuiuijqfrvnkGPpdIJqGbac8ZzL0JnPH/3dOPOCPc95wHSM3vOtQsUptb8rQI/1tbdhO96RABCWnsOYeEtFi+29hTwW8Qvips9R6z2HHnfNRTybiJfY0Wmxxckj1bs7IJiYs/RFPYMosWL+11QbMTUy24kj3uFB4Jfa269+EZwZ+lXsTVpratUnLobyVVeXrQOX7uJRJrFZkttSpcNnsueWK5LxXOey0v17Pti9ZK3/1iE+15Ene0m1L174xe3P4T7zyDfRxZvuMc98d098x631z2zT+bZ/Rh7tc/uFfvaeVv2rWdy+90n8Cf7+b3xfc0/Sz6D78k43dtxuC/l7B7I42svtF6s9iOxvBdiqsX77xzeO/zy4FKLB2KHYs9+1p+Y/Si7LLFw5HMf5WTv2e1I/pD4WsOp4fN9lC+8Pt2P81eSnnMf0ZusviLYtnLwvXH/Nl97++2E/e7egVepr9w742PtPxG87e4L91gs9x3n7hvs2gdt3kdxcR/HFSZ83Tt1pKVWf537/cP+38L9JSkMMPeVZrzPHPSzGJlGqRXJPiPw9tv0OWOioj2+SNsyYNlnABKK1H2iiPcJYbsviPn9Nv3eGDBDO+6NAvYeJ4X9lh1s+xKJxQh3bfi5Z+J8L9gHPM8V4z7Y2PazZ7Z5TIS4378XGoNArvttoP4CnGfP2yfE6j46tAU+7hNLIqZ9tGEAWNu/57lErRsuFu0M/xA42QfFzz7a8O6FJnZP52lfwcM+wb/7xHf7TN2NxeR+/M83OD5l8WgQPCS/MnvvC9ijOPSnnS2god8z+GH6Uq6u2zLHsT2U8E3tuff8gIEIhX0tv/eAuLjn+Zvj3f2wF9//ulkk9xAuGvbDusjac0/z//49H499JK73NDfu38scx+FjXxoMQw4X6p+9RLznc8L122xucri//5/9AvaesSvMxz2TD8UvScNwvEfGRhPn9wIXC3ylYoDqA3n8/rhx3w8aBJWofeV7MtFUsAjhvC8AZF8SDwp57zHF+hLoXYN/OZFPEM4etR/zM1dIXHOlBIq0xAJsA35r53FDFbd/5tld5vZ2Xxi4JJxJ54r23/8YWkg7GOHFNmsFj1nf1Rzf8/aw8efq8l7BFpNv9nwF11QOx2pHEHy55sURJSWkmbjtEaS6f8/wB5WLlvIbiHtGYNwTTZwQxnttuV6gOqWEw/24cDfxnMQRxHCSe48YMrjhlRLr+/dyPWp8tqfEaF/qG/fM8MPh5z4f35DfKBGyL1zQ7N/z/Y4bzNn6EG4195lhc/8e+I2ydHEl8Pl+W+BbCaOt5yXknMKPNLCyOkLD6z1zCcP4qfbINs9fZF0a6zX8X27A3xcGVO5ig+Npcqhq8Vwi9riwHwM4EnWmkGfOXjZmXM+m6pO4WGR1w72Qx+yfyuwnEO5q0d7jgpEkYqTBMU1RIzqkKe4LTXbP4p92c3Rvi49qZ9uYU+1Z7RylSVLgJUEq2STFnroB53xpEYRCCHePiGKH27ZAyIpwoch7Txi897S8Sc9bFtBI9qic3RtjIdhPxWwPiacyuHoGXg2z8J7IwGXBJYgpza49S73eK4IpMkeuurTw1z2Pt33iNo8U1twN5j12QUP9Nha6eCF+g7jPiHQ1Z2j/BfrGnrUvKTztHtjubZd2e1pdC/pgD8CU2Y97n67aE/K4J9S3OFxwv+mWLjDvwUtFi4YELpEgPBh53nzZdU9fAqv8/M+fyjz95+XLA4ORB+Bn+849DxLvbd3nIMHesT6k8nkiyyloDgo+9yAxLt/COngj+x78G3D7huw9MPDqgdH+g4J4+b+23JzuHfjeGr4T+PEPzoV9JLwf/Mu4JIUeOfiXaYmkGs1zKfpG+oiw3y/hfkA0jgOhqRwkBNeB0iAOnA0mhgAOIovjgDjLE7MD59B0wOx1AJ5zEDnAHIDPHBRcvAcFialU/hw4hwwvPg8MmNsD7D5I2Eis8TsA7DgAYqHVxUHksHIA5v0gAuMx56e6qDlwiP8DI+8dJBowUl3MHDjjvw9icz+xsDsA8XYA9H9pr5hh88BpTyx/v8aF34FDD3l6z0HE0HkQObwfGP59kJAbD5Rh06N5vDpqP+L5vXyvy9+4W5elsKWEWM85cBKfek5H9gf17+cznedlaH7k6ihx6fjsRfJpyYflOfX9jq0JpcSvt3lT++4BDejAKKy5OGr77t3r+PbEz9rQkX09OWRz1WFq0yHSpXgh/BOF5U4a3Eu+53gls7JxPEAGpI5v+D0wcCwby45+xr6zT1BnWIebA+MQZ+l7Ut8Ra6Zjry1rrmL7Bvt8R/4TGog7Omn7nNhDOn7s7cf0+o5tCI3ND4v3jn4+x32W4deiu9w8EPrXsQ0qRt7//uFAEu4dR6PogA25wzS7DrNPRxevSLIhMUwULxqHMTB2aAIVxXcnsmF3IkRth27GElFqNprykWg4NPnbEZpihyluS4w7tFg8KKB5IXtrwnXfirkO9p3IMUCOTHzUEf7dydflPugbifl7rAZYDukIn0vx0HxMMdR2EgxxHf1SQayPDo+lfanOgvrW8Kc2645+gaJxvLU+UBFB8hFRNzkcdoj30dpwCtpUFy5UbWpDGTfQkHFIbJ/Ka9Z9tF7b0bWU5q+kpzzDrYjbjj+e0gBgwmzHKdzDeqGG5k7c5VSwfgh3laBQ8HQUwntah0YRihKnS2gI9h7G3nChDbkTL4q4dai8d8g9cw8MTx3g3Y4x7p344QX159ArcDoR+WT8PCzqVtWIy0Oj3RBOtPfbkXyDilatUXacg0Hq5t5RuDNioGdj1XmuB4QXXt5rP6+O0jc6aWN06MF2ymFUOPcwiKOL42Lwr/RedEA89Mank46fDj046kwg16+xOnFYPuw4uEfb02D/obVWE/KGS8d5bOsofbxj5Op2pjfmtcv3D4fPwj108LAjk+dhhqiyP+eEUefXvw8Z0ReKqMOAbA47OukdCo2J2u+QIloq2ZS46vxqblyTOySezRVS6B/VOJXh4hAE0yEjWsbyRPg55muQS034H3Zk0XCo3R7eE5i4l8WuFg8OUyQGCcxT54xhoYM19kNqkECGHur5l/3agX3tIK8dpTF2GNx1+NtqkrQ6/PuHYazbAL6ZfQ8pHtGEC+P/oeXm+8W+Ns9Nh+jFQUfxD6hPiqsOASH3z/7tPA9wDW8MR+2M//d0LR8SuRyzq83j/JDh+rHeQ3E1OJwdchzSIepY6DmHwG8IWP8EHB92BH6gehFyGULk4rAj9y62Djne9QjpjsBDTJwPKe7pMIK1LQxVjP+Hhl6f6xGacAVFYdiztX0Ow4vRNn5Jddjha04drEJ72gJPoxd0HTqfh4S/h4yPh4DPZH47Sn6ZvnKo6Z8O0Y8ZLTYm3PPvPd24P/2HErNvZbFim/n8kBosXtHOcLD5HdaB5k/COJnPufflGTrnXt9j4vH+zbCD+ArlGM0vN1QmtC95PfzLcjppDkl11sHvnIv73xtHXmykwlQ0Pn/z+Kv23xt5+K3iyGk/d+n2Rvx7unF/+s+/VgC8r4mS6r89jwevsfd/Ubi/Mb+T18P9O4+8hbMOOv8C8fXer941RFHC/T/MMdRfi7yh9f3Dx6f/fHRu8JFZ1vfDz5DnreeMfdalv/+ovPvRcAYVj4/Ccx4fuXc/RoDin/e7ss/WnB2Cdn10fufCgCP/4vtdZw100/l4CODLusdHRw1r2PlowLkpJ938zx8jcfQRxAmMua4eD6l+LPX4kYqJo5Y/OjB32PW/z8a7S+dU40RvbVn2our4I8AzbL1243qyiONufM41/z8a7X0RSqqm6P6KDYyzrswJKXpITL2k6l+HETpM0x+xvGntE4cJe+HHSO34MaJWJHx7+vSzPvsl3P8uvI9dWuR+BAKSW93xovkYEPBHQdz+JIJu/v2x/buCHYSQOmCE6ccgwKzw7uabyBiJKM34I7jI57tgwWVsOkBFaRcYvrr8zx+VweUntrq6mBPFRHd8sfnViKNLN0fKxo9Co/7YxfOZfXYMt11d9FuGno9BIyXrQRIFgv8HTNNnY95VcMHlvEvjkxM3YW5/vtNVhqpuPjcfuzjXHXaw9z8S8VDrvyvHFREiH6ma7fIiG8Ufh3vJ5rA+Dwk/xUYf1n2X7wFjNnYZ+7sCr4Mc+RG4QCE/7yo46vJYPVQEOCJQONs/UvFALue69gun0Ofw5pSNQ4cX7mwv6tI1aBZpXeb7ru/SIlcH3Xxux2zu2i5Q0UtC6+Lq+pDpdR8ZfBwonAiJ6659eCB1Yhfn5EMGX+xZT98fdOXBVNNQAX9khDviHLLCQNwH4g1tgt284INs6jJ7MELSBeAuYANiD+JXF/BD+kyLUxe44dD8knxH8ubJsyXuqA0d51mI71weFXyabewa8oPs2dWx4ooz6mMXjHGXWR5e60bGTOOKbgSPebkQqVvk866BY7R3uHyhNlts6joxYuWXrmEvTwxjcOit35T1EFOD3pijce6C8UNw5smDt0d1E/bMjqNnd53469rrLbx8cGsOC0d36MvCZLrRysf//KnMk3ofE9ndCAHfdYIpFIddQIh0QaEhAaabnwiPnlcS4a6JtK7BDy/BW0gmOJMEazeyCXr87UYMbd4C0fIVIy4s/nWNoq9rECrIEOkZABCMoANBjCCzDkldw5nWAa5r5BHvAKIJ4a5xyHz++ShGuCN81o0Y5jp2AXHU9Q3rR10jB3ad+QUuoI48QrPj4LSYyyHL0IDUroenLHxk5f5upB3eWom5YLHwI9pnhOePOkbfhc/Iv8KIuaRBOZwT7l2GIyxc1TUPE98/HD0Ld4qQsgYcCcmGyExqKB6xoZx7FGNXluADP4+YuBx17OdxMT2i4koA7ogaNKQ8Mue64qS91/kVkyNFWBwJWJLePaIEhrS/EKcjgmCOqAaP4jGDj6OOL55Hhne8OT3iRBmHTebMo26ARQuOOoB/Gr6JJoy8izTBo864f0eEz0dc3So5OVJwfdTlhfQRIUaPOphwP+ow8SFE4VFH6AOar0qfOHJyzJF1SAtiEfaHo46AH9C+I4pvkb4lfK9yI8FfR9qQbOWhjszBWu0fKXk6In4+Ai+XWH9BHjoCefjI0wOteqTj1z1HRJ+PWoooPuoG/Z3BTDJt0cn3eTEnwmB3JMUu0AFHTC8gNQdTq0dafgG8BDb+EO5HQrM4kpp9lxC0wh6HXbrxH2Vuvo8kgmLOPBKK7Uiw70ix/RB87wi0J8a2I+K3AkfOASXMwZFjCJLsJn3I/EaHappIHLiz4TxozUfZ00PkR4Z4W/Py0fiMmMeOXL9afI8I8YDiylKblEiS8vcRwA95kymIEwrbR8oQBcVP8E/LGcLBrB8deWA+6tJ+WwZJyaaPXX/9W4XTkfDzRyMGPyo5U+MLNmxvD/lo6HciRzCXV0fK5YaFM48AEWqN2aFzMDwCL0JQgX9k6KHWnnIEYPljRB4ssfJoMitParWr7a32oA7PY15+PwI5CdaX4Y37f2L1ftO9IwaGSb//vt7Xv6am39f7esdgcb3o39iPe/7LufdVDP7+ZX5hwv3YC97eOIiPmb2PtT2MNh1r9nB79p5X+FnCQrbudRzYf9yTSeKYmICPE5HOcTZfXCx7su/HSJ4ysddyJWHluKdgw0Hsx7E4CGw+fqVmdFxQI0T21TCcjc2xtn8PsKsn41nloXCfHv/OcS+okxTcEdTacZc+49jBV8cGf6V3WXu0fQO/IBt7Cv/06PxKe2djd9wD49XLcGFMTRtydezogcdFCVMwTpR4OgbjdczlSuDyY0WHHPWU75HY9Wi7pJ7sFpI9MNY93Xao/6G9vUiMpehpPT7WUl6PewXZ1YvXXs/Pff/wZOR3riGQTaGnCDmw6KhAheeGTfCYarY9uWlkxfhxPgBjxEGSSe+XgBzzvzduA2mPIlqPGTI6ZgQOF+esqBdjRYiiY6VAs83suCf7kfO7Rwsv0o4usX9PBvixNFhI9lExCO3rEcMBhc9OMPT18vYfU3tz+e8xIrBHky4VexbvQI1zWCCfD3w+7uXFzHFPFrY5e3tyc86ekYtLj44ni5Meg4tenvdIIg3yfazlpEfgh+K/HlBbzCB0TNjNYTjHMz26LsNLjRCjXEzIntEbrwESaz156GPzwfQDEf89eTgcy10We4wfZA/oGRt1j+Fghreo8+E+KPXtnj6MUZyAitHjLrZyIrlH9GihL1BcTvJSD6g5SjP08j34SHjvmBkkjrsg7pXLgWPhEu2YwNOR0EOoC8xjiQ+QgYHhFumCU9qX1A09+aI4l98ez/fHXD6YvkzGD7gMpTB/TGP1h3AnyZZrPFTzzDrfo2+q2WD1eLKnhIFoV2h/R9iDSFaOzEP7ekyB95TGFYJTsk8RNaR47unEg8SXa1aq/10BP5IQ7SnipsfcvFIiSFpMztTnQ7KkbO4IwwcaLwlLTCGjTQ9tjKQIZ2ruqKfEtMeIlx6DFQVbRx1Q9HfleKtihhuAe/iAJD7L4Z/jC4kzX+LSA+LQI8QDY5+aI4ErxVwKnHPMXUD0GJ7u2S5pUF5EBrtjRriL/EH0RA7v/9zKant2aMECxUHAt3SZcoTyTo8X8uI5Bq7+Gc8OoEsUjjnqYv3d9L0i+LlLRPbSUunDOSHcYXKBYKRrqN8e0P9BbiR/O4/wOBUPaRjR/OrmL6FE/PeEPorgBrEzf1mVEe6I8FSas5m4n9YJ6mwv8VIC5X7/Layuw76uw/cuE7OuoWmkiKNmz1vKJ9hETbWAEFTXWLep4kY0kqjz0feQS4CesSF18WZqboKp6kHi6l6iGuk6B/vX4L9J2DDJ/lREfXYL6B+WwbVrsLObOPbdN9q7i6qF1PY5cXKSQqd1I3sj8qx3oEnRv/jvBeGeCOwn3R+LEuzZJYp6Y4C4vU+QQaELPts1DB6MXSfKEAPFJmKdoDEJz+0q/hvEzUkikkJiegLu4T0f3q+btqBPgHelmih8cOna6uVEWWgevNg6SXD58MJ7J5Ei6sRY+yqHdCPi8TKEdfQzjx15OHH6q/F0WB8nhth5eCQFn3h5OvvcCZpTp7g6cfAciUciPzBHdSP7YddWT4VxYXc87icpMZRYuJ90bXhk89i11aC7TozCPevfCfqbFxRDWuy6ENeM/6nMCRh8pJlSBCKJqxOQoDVQS/ZJYv5EsFkiHmQ4ODF8p8VIips1N1Isjg0DhoadE+Xfx0p+jh1i/AT8txYz6yCA7Kf9HCNqkcHwxHGuhuUTAMsnhkEWzdkxwDMori31bsmtNV8noJiV3jlW8h9TKwj3HDuF5onR/5jLES3eJ2DMTxz16hla4Isuw2XCibEuEVydGLHqqSXrc8dg37XiDNUV1oHgBLDRwneIjjox9mULf2m8cGLI54khJtYLLEm3WjXmCVDLaP8J3v0h3FGxgTYdk6jo42Int/rKGX3Ajr5NAKH7HIPDgfXMWFFgKYasT5C46fvFJfRc30e2bpz2I3He92EtRa5d8TUM2K9hT5QNfcez/QJ8jNzTMhy+nHUs1JO4Tz8y132bWDt2cp+nTxXxvCdux30GN31/3q2i3PqMG4+vsI4BnRFj93GsbX17TU0irjDv9xPwRIG67eSVeldM/wSe//7h9G/hbhEYfUcT7CtCRjn/tO9Mfj8tKE77jnP7iYCM+qOd3RfsjLG7n2i46jvf7wOx60f4008Yk14Bcf4bn6nEVt+Ah346YVo46Vuw2MfPO53EQNFPlAOUHzh8IfzUj/SjH5GXfsHx7hsx1jfmA+X6fkTt9SP53MKnMX3Y6r+3tvtgH+8LtZ8KF4nwe9qfEL/2E9nfj9RVfcLnfsH+9/9X3OWRrJd/CPdTAxBPFQI/7RsKuK+Ijz7dGE+9YpN59jRj+2noax9sXOB3MU0+F/u+3mBOCT+yxX3aJ2IR2H4q5bovDGlaMwca/Cnnf585o5+38RQgtNM+0CAkQdvP23faBxtgxjc1v32cAE+JOJ2COD7t4/jSGtcpIgD7QHPsOYaWvn4RcGoRlv04kXuasNlRmDmVnvGc0wdzh8RE4l/UBqofKDzH2UDGSup7Id5BQaL1RI6bIZ4HRNtpH+AJpuchQoqr79M+w1l9m6g+RUVZ3zmgRgyaXL88leIC1LHIHX2gDxN9nquRU0p3CXV+arwcOeV0R1C/7HAoaJfTftDnQV4Re5KCt1PmvBAXp2EvtQyFFEf0gxv3HLkHST7t0UE6JUCRPeiUED2n/Xzgs2dkHT1lzjrpM6Td498hf8761CMEDvVeaBuzToTPT7TnqTMJIjtl7MwVdJ/2IUc0TH6pAjvlVp8fDk4ZHxlw5uwMxfgplX8KK6F4Fc7P2Sdhi7GBEmi5fCtCmcwx81lIFqc9QBD0mfhp8WBIV4oZxQk57Avx1GorxHG2wVD7kvb0+DNPKDsEvJ0KOcw1ay6/3Oox/lN1JHFVTzlX40/peYYzT5g+c0LVI1M3FF+QseyN753LOSHITwkxRvKvwM8Uxk4EvuYGEKqmRU6i+nBPwQA10Pfzl2Oc0CP3Y3jvhOtxPSM+kdrsC3Wp4JTrkyqn9eheyolAsY76iq4KB4c+2KuIixYWFxz+hbqU8MX1E2m4kHglp1+I/LJ9gPnrg1ALSrhluYC7MOvb+gfVszKfPwn3p2t3uGmAojXm3ZMJ2WIR1UWfy5K7077TvgA8rpl67WNI01Lcp4hQtRQBMzCcWHPXU8g9JJUuIIAFUjuJxRbYxAqrA0GMnnjs79lF7WkPq6cTT/x6cXGNfg/AURTeU9nHXXYYuOYE/P6kjw9BJxF+koN/ivwx4uWkhw9FyfuQcgmXzIYC/YBz3/P3ghMrjnuT9Vm8+CxYx6n1jMaxh2F1ovEABrCTYnMqC/ez4N9nEwDZGfNv7VnPOWcOm7hzz4yfp/TFYmdMfCx+nBWIC89zZ4nwl7oOYvYroj6s9hT1bBF4icHzJH06C/JQJK+cFcQjqbjoLAKvZ2BdW7mhqPo/S8x5RfTMSbx3VhCOzgqu4bMEOD4DddfZK/WJs4QYStVfz16Rw88S4uPMItzPlBv3M6eAPwML8MzwTqxIOwOE6ZlQRJTtkxZ6P88ZZJYUwwEW3zNEuA/SFMFZgsb/8+cBhtMz5LMB/72VWFE8nkUSwJkg9jy2aRghMTHA68BVCwPb+2cRvGSx24I5hFdCLJ959pBsGvAiwZp3y5Av2jzQa+sMFDso7lAe1PBuxfSZEWNnkUMRF2trXZ4Zhe9ZRO1b6jOFyDsDtcqZQZyjdermCQdnWWoklgtOwV7kiVfIZdah6QzUOt7LWOvwZrEnJ9zPKEIaMEAaCN8Fz51y7wPvnhGiAGpmA8LWgeHdAS9GxOctDXfga85nBmEpnjHIEPkAtGnAFPhAiT+AnVPgrFMk10BuT7XzBv48xeRZxRljW05QSPF1YNUjJjU/Rcw48nxqyMVpynwOQF8GSi6171LxzMDJxZxQDbExwPCUw/vAwOXenFm4zppLAt+5eh4Y/RqAcbF8P3Dy08DRd1PaDbzL4gnEzSnQh0yaI1Hvh/vEwPnzAMA5wr2DBP2yiLhw38dw6cBRdwNnLdHrWbgPwKYyiCgyC1AGNhF1Dopw1pYB0OgHRl9fVo+wcaCIAG54eBGfLw2zZxAQQSxfbutNhW59xooZofhPrftZxSOCU88QaLFJwy2DDTN5GMjidBBBzAPDQJetkYFT+HpFA5rnQaSfxosPkc8GRtsGNMecD/xDACmWBgYhzfnWs4mHZBgcKPEe2PJy2o/gkoFvcEgiyFPw9iBB/qwCPMsjA5BLCQ4+z2IwNnYeLlL2gAaUgeEiIFbb9RPup9WhdCEw4HvFqYeXB4o9lnx6ap/P55NwHzwL9wFG5udSYTy/ez5wJkDYkyxMi3Cn9hrIgTofKASuB/hXPAi7zhV7z9FGEr4Dvn8+GCer80Egnl7e7z3nfeBsdJR9IdmC8T4HcHTOEMO5QhDnwbNUHZwjQyOV6wHWTM6NxHKuCInzAeHPABesmt3nVP33AWwgOeJw1jOSImUzStgDm8g9p2LYz+Mgy6PnAxpH55oQGfBY5zBPcikquCz5zfqp3TYT/eM8iBUbXwSzfdBWhpeyeDsn4hHiUcoX0rzP+7pduT4T4izAF8dPuX5O2EfxxjnVSwcCh6FDp8AzUu+Q+tH5QOj3xPfnUk8F6uTcOpwI+aX60LlykXbel7Fl8ZflH45nBuCFjHWgHjB9OdvjerzdlA6z6Jlzoa+fZ+uI4HDqHEknn+ui/vuHp4e+n3OCjxGD5wrhSmLlfAAWp0b8Az445+DZ5wMCyMw754yPmig5D84JyeccaGJnoA3nSiOi9ssJ90FA+EHBnA/yYvvcMVSg+DlHhDvlK/XvvoA/jiAG+aH1vE/XChkvIf5njMhTY8oMF+d9Hb/iEEUNloINYe2cUwTZF3JNNKFzqnYIwSkJhnN0KCNI/bzP1xlnN5VjjnzPDUPo+QATt9ywjuT8vJ+3/4wb4okhg8P3ORcL7tZfEu6Kz9AwCfawM5BDzwUxcC7xWt8oJAnMqXU5yPed3NA6AIW7EP9z5tKFrW/lUumcqQkyhn0lXmDf1HrMOSXckb7VF3iiL2PmbKAIbeqiTcEfu59WG306p+dcj2UuYc4ZMXzel7HOcTfJDcqF67nUp4RBJuxNCO9Kg4aKMWEQeN5/XLhPap1N+Lz39b7+7UtrYjH7va/39V+qo/c4TJav3tf7eseZafHC/UL4+QLY/EL5+efnwzcanCFmfxFnoesiY9eF8syFMV/W72OXx/6LAs+/0M4fYnGdVDwRgrow1ukZgdGLlH4ObXZeRGAXfneovD/E6uoC5DkXrof0zxccvw6xuFwQ+ObOSoHvi1juHb4N7rL46+p33hwmjEVM3VM+nw3te18UkF8qflqeLhxcmqLfp+yPF4pdXL9T9xo6fR5G4CvBIP7a+sYu3IdPwn3IAHjIA+Tl+yzQxxbzDrnf0ObIhZUUh3byzPkxzDfvc+FztsCGxPlDwcdhhAAP8zAEGsKQb54XQ4ysUDK54Pwd8j6wnzF5vxjIi7P7Ja9nWfuG8uBEvY8QrtTkLpizSVyhmBLyTwnOC0E8XDhFeQ5PQx7rVI2Jw9SQFncXYMPm8nExtA3MYe1omKCep3Ag1SHLR0O6HnLNeqjUqbKHVVCwfDGU+8JYPDTxNOTr6QIRMRKWh/IQfzHM5z9X40PZ5lwshjyHnQvxvBgCgzHTv0X+FHAmcv8QHNSGMv9faPzP2TNU+tiQH5Q1PtG4j8qL1IvUHj/M85OEzwuHqBTF/FAZMIfAJY4hrhfKMKHxDTusDAUusOjUITMIDQHc6bl4vnEnAH4x4D+jGp0m3LU9w/d+JlJoeORZQ0WMDYOCDM8ZMjZpAtLo91jjkMTRkGj+Q0LoDJUzh0JxDwQfGTGRe3bID3TniFgOc8ENhEO5cV0MZVu49xFhfz5kBCYz5F2AfktCcazZD2mhcsEJ7YE8eHNima2ZoSBMmHhIQ0ZumB0yNRWcL9bZMC9eRW6Sfib2Oh/SIoesE45bhgA2AC4l9xfsJWuTqBcxx0iPGNIcQApewh5RpGlnKeLywoKfIW1vzvYhfzEjYe5cuATLnU09O9Q5TKu/c7AfS5+fK/6Kw+VAGEqGdB2ilzHnTO+QBnEpJ+GwKNbBkBlEh4omkWodsWMoP3Mu9E1qoLwQLlIupCEiFKpDPhaslhpivVW7KKJ6y7nhQoHjUrbHMlrmnBmMz4eCNqBj/f3D0xffEdGhCqghSIhD4WdQaLHfIYIPFecIeIZgnAaAYEB+czEEnh0K+Rg6zhk61wDAhxZX63mK7ZfAEKBiT/I1e87AgT+lYaix1mpJOwMZPL35GIJDPFqn2nNGWy8tdTeIqINBBh8DY/wsmLXER+Pn2PobAJxvsXsAnIEOZ5afrfaidmoCDMWjFQuDCB7X8o5gwOPXALskcdcymn+t13pz4uAT1/tDA/cODBwycPDFMKLvanH21DxyCZoyv/b3M8KdEDaXg+cFNL1LC+n2QUElrMuhX1RexohRQqRdEkVxOaTF3Fg8B78+Mw8qQ9qOcEm+555h/NNieWmI6eXwVwwuBeF7GZkXzk7Wr8we1HeXA9yuSzQuAwxfWl6kc37aPfi1OCLO7vPyDkpMl0DOpQZ7KdRUTK0jtrJ1ksUEV6cW3A7y/pA1i9ah0lQvjTG59NQexwMDW/xRvoKHY6LhXvZpsXAZ1LlUH5o/lwxXXzryYeG5S5CrIb7z9sjBuB64tAzO4UCbjXufrh3yfaTuCA66pOIx8A+xVJ+/GBawwAsqV+8L+t6loQ4sPfsS7OuXw0TDj9VezVaDnWQerH5mhfulIgAlYr10vKeRuEZIl4gYM+znSfaloQFywI9tmFouOPvRXF0C+1sb76XSkC32W/FoFXGXwZ9qoIOM9rP0uWXf2PrUzrfuzw4BmXVuwOIliCFLDVxEYB7lB63eUXyhNSrF98KBR/eAZqwxjkuy358rcUTrzVPzl6Ag8tSGp2deRvS5SyHm0n6XhguQGB7jYnYuxPoSzMWFkZctdYFqEZSjLHyN6ppLZw1b7bt0aAuPPrPoqZhzPf0T0auXcdwxLtwvHU3U8g5CqJegQPSIzMtEgtVb/DE2XTqL6CLBuSmF+2UBcbswCsBLh+DUGldM7C8KyGHKOkidNy9/XCTGeCphFVPH5PcjZu+RrWmktPPCISasGIKH+lE6TrsomKtTCfdLA/969ynqexRTqfnmArxImAifjorRCJ5LF0/OLibcrxH+S8JRI55XLwrq3Qli+P3D3/9JAqKR41kiaOw+I+UZ7/lF+xoTi9Q5GRW076TWKPEeIyLuo4j8pcZD0XkUcHeVKjejN4ar0QT2GBVnN5WXqxhMjgxYHPnyeTWy428iuUzZUyz7WvYevUINFIHvUXyfuioiP28x/mjNjRL2GK0utX4k5OzK008mrc9GBeujkZEbJFsenoT7VSjcpSSMmOIh3rkKDPyZPE2sj/JEf8XYdxXsP/Y8E7yrrC9BcVxJomXE+6qSz+iXXz/PDT6DBeQo7ydVGFeAXVeZnF4Rto7FeZQvxqQDxYgvem6fK4YYxnCaFQ8jPj5XI1vDCrF3NQpsJny84s4fZf4OfZSvGST+SD6uiNoK/b9isEPabsUqQWBXGscoNlwR9a/iB/UF4MIQd5dcbUs2hHsNGD4bjePscsT4SfDJVZD/K43Lwu+D86VBguoDVyPeb7Z/KHG8GvK9goqZ5ucV2kBHTI0M6fxQdnP98orLJ8DpV0LuOd+vhNpUezAw8F8x/f1KeSbE9tVIrmWul7FaYqQMlIK/OcyOCB5gYk1iK9QHQj6urJdPI6wXXI34mEL5pmId4PZKE/cjw8USpd9GilajcAecd6X0TnbIHDF1xulYgX+D93/cuIegvwoLJgDV2OdD7LvQAW7/S6b5XTEJztlO7RcU/lUgWEIAU/5yYMj5GtrEACosfjaGhD1hMbA5GDI54Z6RJmUuf0MGH9IaKHYKxXw1BHAknE0Vv2ir0lBZXI4UoSzlWYox08hYf0f04MjF+4Jp+qQ/lA0jBi8M/i5GtBDK1d/zrxh/vsMMNJdEvqi85EShJL6DJnZFDWSj8SFOwhOJ7We/uHr/6ddA4B+Nu0f67fcVJZoDPCF8zd0cinwwyjf5q8yvlq9G+UFH6zOc0Kf8uhwp3Dui8XXJ5exlL8Y/tvZHfB2LHE/1A+Ji6IqIBYXnK67XjYRhgahbid8vg/xeDRl7pfgTQz8Xa0k0Shwc/qkDV3OkiBsQ/YLBsKYrLqW8j3QdIfIGU/NXI0A/SLpL048M318OlXxTA5sk9DU9pHA15DszQF8peCMH6sz3F9n9/r5x//s/VuIniUYRnSogiEYlAmbksJcjwhFDwNItORqfEXGzJAl3ZG9E9I2cuRxijUkVziNQfFpwhGJUwcmlRIDE3pcI5oc6YVE32whW4e+H+gCpxetS85eKyVDYY6iflxOoSu2xQ/2IiO9QrmfKT21/0dahsUZGwnA1YnzinrXwoYJzcXAhYoj8VhHls8sR/xuNK4CjORHADeIsHoTBR4vzJeKfRdQM9aFF4idWuCv5urTkUcCHlu9LMB+X3OUKozU44X7luTzhtMlI/o2ASVwPAR7Q+N5RI2R9a33aqk3Q94PLTunyUvKfHVJGYM6tQwfAQ+zz0oV4WIP//KnMi3B/Xp+Cf38iDvkkfBezPiV6pkg7EL8/JTzLcm5qvz8xn10VlKcQV5+cNsfYERvzT5HxjamzInLzSYmPZf9Y+z4VWL9abj4VjP2Yc2Iw+0nI66cIDEj19CmR/178aPZ/Uuz6VEDtpuCwSeDzNXoyh6FPr2DvpwJ4NebfqfjzE1gvk+rBnwznfIrUGVdG3fEpoVb95IlfVrh/AhyiAoa+Z/nuChwYPgGN9xMAhEvHwCLt/UnxUSP3T4azimhsCKA+Kbaq4HzQyUnaWxMtnyKFuwW/VxG148Ever6GX1ScaHmnagnJJXXuJWgfSvAIXj4BjQvBowX/V4b4XDntY+P3gGPpU6R4+vQA+vmg2xPLcZYh4hMQj08A139yCutP4IBm7aue/uQRQld5seHK1ycH9sy9KHz+AecTlNsR/kPe82DXYjtyLpofrSd7dNanUdzFliXW6AXDJZgjLx5z62/h/vd/iC+kl+TvU68Hw3cPBdj74Hw+PPdhQvF5YEDzUICvFNAeDHZPEkeU3Q+R2HtIjLOHCdcPUkMPIL6LtPUhOO9Bf1clQSF/V4p9V8YGXTj3PDi4qUDOIXPm4fPEXAXXwyTskPZ5EOL3GrixCAtjD74quoYc+Ye4IzW3cTgoMg4PBemPB2Pvie2jSJ/mVor8TTrej4xwv0YOR51/iBBIHvH7kJhcHwxJeVDI2JrchzTEe4XmwiFGrxITx7UFO9a4PxixKZHQgwNrD4lqwCKuY3Ly4KitB8B2q68OP65C3BtifvXwP9eNj0ugoc3MG/MUfCz8fJ0CQ7EYA/a71mL7oNT0AyAIRjyfXSu4uPYOSDE9y/DvKOEuxFf9zdHzO9dADJMNpkauuUbyZxluY/SPJd8pBPJDItyGnPJg4LcHPT9JOcUyfHuG8QcVB7+Euwg+JOl/ByizfhZc8DMlhq6tAc7uMXxeL0l/YMTfQx4c1xRoFPLWfKHOvWYS9tPWh/EYjr0X2kvk41qzL2xe4bMM+eXsC5uM4P+1gJ9rSrBnzqOaneQ/Emtqj+sHxucHptFnY/n8zBVhP5n/l/Mf8nlg7Scwdj1Svn/I45qMI7PP9Uiu2+sHPl8iAT/kMZXda6xBM2eGe14TP5PnMT7+s4aKYHjI1+u1FHuu3pi4XzNn5fjAwolSbQRi4+ohjwuSv4U9rxl+DTFN5Ttry1guFR6/Rhrmg4APgoc5/MA3icre1xIvjPg4XjN945oZRHI8quCDxF1wnnkQFISKhAepD1yP8jyh8T3X666Z4YAVf1IfH9E8eP3AD7fXHA+M8jVBaioCz1yvpjB8rfh3Lei+MUxzsSV4hdxL4Xup3q5HTDwe9NxK9cO9fz0Csc71LGE4uJYuLgMevn4R7j+TMMTEdy5RDxErEDSUuLkOCnXs3RfhHg4OI1oMh4AaO3tI2MU1oAew4TLPXwtx+8QUKfUc9/61kDfpu0+WoYuLq4ChayJebG5HNIH9zMuQ3/+aaH7Xo7wwVXNANNWsHS9/vwnlMfjuypg/6XMKW58ULJG1PZKxydVw1p9PBKkj72vDf85uJp9SzHM+D3/V/acHms9CnkOGLm5guB7JvEpxFyueR/SQcj1S7Mv4c/WSN0ZAIli+poYWA2ZZvEhYDAYh1KZrqokD/CvdsJP8xPQ4ss4YYR9iRuwDI+HcEVDjRDw4/rwW/oTtWrq44mxE9MFI7s3cJYXWg8P8Uzfp10h/GSn8M6L3o2qc1ENSPVEDKJPLT0QexdrhRCTiM4MtSWdcK/truuGT1FNGdE1cU31+xF8AXY9ovEvaltJO1w/y0Mjl4x/hfv309zJRwjvB+vzK5098jX5v+9Em/r7e1/t6X+/rfb2v9/W+0mjlz48G4f45WB7R/dnx3WfBhs/KHp8FP67B79hnH/l4fI7cG7H12ni2FE/VnsdfPoefa/n5rOTCmysUm59tBQG98xn4LLufNZ8I5sLcoP5+jsXlox+vaOxy5z368onGNfZiIQUHarwW5j4KRwa7P0vrUa85K74+G2ND4fGzsrz8itaTJZaePvE5AaYt+2n99rPTpp/95NEew2tjfX9OpEeKiK+lJ1rOismNlbfUunnE9Ne1g9c+G577XHD+LZoF7avXed79IdxDEcoKr6wQeW6onx9lAtdI8+e7z/uICX7MNx2UADUwhw0pFKqfCbEu7vlIgwS1Cx1cEHuuLXl51Ie0z4I4lcTBZ8P3qCgX4/BIiwwyV9Qg9mjAjGbvIy96Pj8I5z9iA8bnB6w2kOYbnmXBkzrkPwJi8FEegj5zvMMIgNx+j6AQeByPAYvhxwwfMnkXRR6Bsyy/akPmZ6Ixfgbq+Zp4lxzQBSxfE3aPxetREPqPyvD/KODzka4RMtaPOj41Ljf1tUdZRIgC4pHxUeCJMTsf5QsIpL9cC9yo9qVH+7CUO+cRGHYeCS55xIYPSOsQlwcxYvjzY77eLXaw9QNcVHxG++gjf05Yx6ImoPhaqF9K3F8rfUr63KNF0TpBtZZl/88PmIYaE+6fQ+EONlbx2UdAHD3SgkkSU7n3gj1YItD2fXTYD95EqXHU7HmkhTJsS7YgRoCNFoELiIfPoHC95uIAxEYkv0clpxIeHw318MgTHBI7KB+PwD6A7axAfcDqzdMMrx8VHiB+tpzxWfgNBCmmH/lhQY3fI9P0HrHccYLjmnkPEe7kMPPoyI8QD1UYPAK89ojng8uBdHFE9YNrFOdWDmd+EwLh5lG/ZGL5A+UyhZdVgcNxDccDaHwf6WHXxF+PxpwZYyZdJmocqV2CmTQC6IN28WDqa48O3Sf1JbDur71ayqJdHxz9HT0XwQmq12St8CzcETBbnH7ERYAosFER8wiIOsWmL+ig8PL56Hk92sQk5fsXoOF9QWyyirxHMK5Mzr9Y4vXoiFXw3JcHEDePoJh4ND6vEDyJIyW2X7KxjBkuPOT8aCDxR0AwPmKC0jqAWcSEyi8cbzwCnIJwooXzkJghMX1UmvWjwR4u515bQ3wTtn5Bcibxgjce1rig/OLBm6XPoRcBgJ1fIi7Wvnji8sjweRYriNh6BPsZ2oudl1VuYejQCXBtPALcLfDYF4vO8vKw9YL3IWIIeTTkwqJPvX1Lee+L3ksywv3RUSSPRvATgvVLUMhfEPJ/GH//i0WkPuTJ6otGZtY4CMn+IsVAIekvD4Btwh5fYvZ4pIX7l0fDPpnnvxAk/uWRHwa+KAPOF+aZLxROGP+/BCLgi1Uka0MYMrAp2PiCvC9h3jDQkLWF+KQ0xi8hnh+Fpm0YXL48+GKK4JXFlJLXL+B+XHw8OPpixJm4H4UHgc9Y3lH444t3YH6w+WatwZ92AkLFG/cvYK/gBp1cD32wnc314S+W34hLmEU44oER72hP0gYE9CLk4X9xv4XltIRXaKYY+h+Z/Dj7kocvLYPdl0d/T+V6jTa0ftFqRMDFF+B96+XhlwdRr/4Q7l8EoROSK/ez9B5EGOD5UhP+YrH/gRaTmh/I3prtXxwLKQxVZBS0JGxo4t0S5+zggeCNssWTLwmzXH5i4ofE5bNSE1ptafgxDULGvH4G/fPE57Nx2EFj8RmIkcR7Mb544ofG/7OTMzwc/MXJ/R7uRDgAxYulhlG8fDEMdRpXSNhI1Qcs+PLUaWq8WTHtxTOqU7TLmC8GrMTWx+cE+U4VDy3uWgzR/Fn6oLWvenQNdxkCPv/9w5dn4T4pgfc5ElCpbXmNM9/qfkUL+9/F3i+/qb1WPz5PmMQn7Wes3THDemzzfy0u/Jx44HyLPFwUXlKL3knnIvUFzr+dV2MvOOE4fHtbeU7d+z+/4T6f++7bZPCs7EcL95vgf13rm/27m8i9b8JnvjHvfQNszOx5A9pijdcNt983MI6TWIp/NzE4SGibFXc3jwI+DPmMyfkNd+Y3Bs8avj1YS5kD5343Be79RYuhxc5vCbCg+HST2Ga0bqA6/ob1hptHjGdvUvaU2H6VukclsPMGfedbPAffCPx+Y8DxTZbDvuHYv0F54JV6n+W5m8Q48PB9lE/fIvQQwZc3jwXUraM33Dg55Qbc78bLrfZ8yMJda1Y3QDOTDLmRhIpACmPrmyIuv/kT/vfeN98w319+vtFE+DfC3280CG48xfwtaJjfFP8Me96AIL9Bh5Bv4yvMbegLG1+LgP9G4ybc/4bLyTescG+QQVLaj4q5It5vrIPUNyIuj3y9oTm9+YblJlfDHA6y+fmWcJADifUGxNiNUnM33xhcEPmThuQbxYabbwQffcNq4kbDKPHMDXiBQvl+YxWe38bjeAPytXgeeFlyk+AC5sZ6QaXVkmdIDXPC9IEbyR6Jg77ZxArKqazuCG34hmsYMXZMzWs4y9UdKPBvvin5+ua7JL35xv98w/EQ0QvH+Ov/sW+lC20kSdOvuQMGc5obgzkMNub2W3wDugAhoQMhiX0x/s6Hx2B3V+cRWVUtsFc/ahak7qqszMiIqMJ7pviCM+ECyrkEyGgPiPe//qbX18z2XwEmXupjjp//8jj4/SXh6Ltxf/ziIfXgGS0w7mTkz9LvlKhI42/l/b+V77g5pfjOhPnPmD1q+9PiPhPiRvf3tzFfUp7+Vubk8obUh3r//57GmbL3v4G9nQGYpMygNt+ZPrdLQOh7bPxnHvXSMI3McwbEb8HjGfD9GbA28v3fymdMHv7zN4g/6mChcczfYK0UPkyKpIT5/5wZ+uRM4TkB/ynRPgPeO1NwCvSsiDdlP/+hTMiZQSfOjNpl0UVE9yx87avLUk/9rWDZiB8r/uH3Qp/z9BbU4Zz6+T9GXVHzo7znHmpV3v1bWd/y/ZnCN2egnzsDc35m9Jmolzgz6ujfSj4R73bG8/vjSBh3KoD/M5ptLUn/5//+yNOACdZiyv4GAcZ8PoIaEYtIWgXVYpzOIszHxDaSrBdSm/+jnxk5A4XrDBRy4vv/RMjPSIy8Mjn0qf2I1TxFft9EmGeRRmh/oBcH6PuW/VlzocTznzPj5YBPHv+OWLe/I+NFMldnOdVE2NMI8OxIYI5GBtEzEcYzp4+cGXL0EiOR85GY2vC3x0HHt67MXyuD6xejT9za/23Q+kHU3piHkcH31qNxf/xPSKAjwvMjoAEfAeYdcd4fAeIaiXVAEOYaEeIfMRCtdV1LXC9B0COGulPP+eYjVl1jv//XC9dpBFxrxIMLRoxcMWLY94iCD+scIxHyNQLOPeJ50LLymJTj55+fb8hHjPOPBJpFpP4jAo+G4s9S5xGPORCeHwnst5EI+BkBP4/JS6guWvM/EqArvhxn/d2i/yE+CdFRCVf/AfM44oELie9HBE83krMX+cvQH9b5RwJ8zYiPcQ8xwiMGYRsxAB1JwAhI4iOAodTm1g4RI8Y4pfHzuXNctCwGh5t7xBCfD6BRoUWbCYlxBCQPS62RffrMh4jviBGrI1bMGY3ziGcdkLVHjLX+yxML5t5Bxejcv/8txl0b/zHk9K/AZ31zPGLgakv/WbBn1cERgzb4ivyI8RA6EqlfLZo9YuTwERALf3k+jz77VwR+GwnkphFP42s9OIx41MVaUzbG717j3I/nffqfPOyc++siesCKiRVhzw9vHhP6kBQXdZwzP1O/c59ZvrfGNMjnYu4hz31z7yL1OhfWeal9o3s6V2I8j7CX8wHVOAS758p355FxeP5KeuYc5J/zAffhuScWz3Oow0vyUAhOziPm++yV9r6L0fNXohuDqnEee39NWmXNw2vzSSivnr+ifMeKa5Aal8V/wrgnvhy1gEszS4mfR7nfz3EB+v7O6PmPkfw9FfcZsQ93f8k5kX0LeRh1fwYbMBnv6HmEg5OR/EfP+e9HA81EMpejhlhHfYmAyHty3VEOF0ajMHpmwMp5uDkZpdY37H9UmtOtu8ABo2gOz4k1FB4YofrgHOyLc/o9NR4md6Pas1ofnnvknOHNnzx3/ut3ktcEHIxSOPA5OJwLfWrgodGn/+8LdAl0Tu8HiWOUwz/Yf6OaHv0t54rC7ajClaNaTc6Z3kYwy+jyKNXL5xgPjZ6HmWxI/8496kP18TnAOWeCNp7pnDbKxDmKHEbOsbyLPXnu4QFc7jz36GefCwTOJ557ail6+HM4d9THOJ/rfoPLDek9z5WL1Ow6D28eX3wYZUSCM3ajglC57z030Chj1EedZ8QkUfElfh6ljAu3r+RezmkCG3WHGychEhphjDLmwG18k+hQ+TljhgNarvFGmQNWJn+IcJ4TBp6ogSsKmbpJBtCtI2dEEdMNEOuoQNYjZ9m4R8+yeeP6QcwhRdZODyTzN6qYnVFGKCBjkKhJ8nm2558//5vHC2sQCfNKxU726d/ZA//IOS1Yo4DAkYdSCsvnRB3OaQ4YZQz5v7lyDm2p96XDOJcbt15ndH+NMPXjsEitl/md0I5MjxBiPioc+BBdSfEJoxHsIZnjlfMs1kcpnmREepQ7KJ8LFyACT4wIOkxq2jltoEfPhUuLc4GniJxkNIXI56iGpzP50MH6EU6vic/ZeIm8UD3/l5R3hrOlw6rE31y8FE5HmctOknc5fyf4MbYvuP4XDh1cfim+kC7WoLxQPX+u+C5XW89/8PMo1dvCQWeUuljQfEz6naxxHxVMQKaw5zQ5cuaBMnzUeyNn2Thg406BHxlULOeCeZeMO2NIKePOGWsy98qhZASJndmzdONAAp4iFkbM3BtE7vCUAq1QqxECI5xRpshPOqBSNRw9kw8X3AFJxRYh8JwgavsX12DEmTvUUsZ7lLkNFnOg4I6tmfBXk1EBRyMAzkdBbhgx1A/iGwkXXL4Esclw6lnWDJIHeWYOEV9U3c+In6X5gR6Ac8pcNKC94P6lZpTBoIY3y16kCySKJ8m6CRciXH9TZoDSslHuEHNGXHKdE3/1VrA7EtAP3F+C1RqfKZ+d89o9QuHcgNfMxQrDvaNnGK+K5s/D53AHgFHhL32kPko6T13kWHvpjMcPeUjnuFPgvxFB60UPc8Z4W5RPtB7hvZ1u3N9aDTA43uY49+80XmUOzv6APQzHcAwxOxx/GE7evkatOBti4n+Nh94O43vJ8fDmcYMProl+azTdb5nBJrLgzFOQ56XWCSnaW+6zgvK9MT9SrOwzBT5/3DtSvG8HBGxLTkaBur411B/do7Z+SP3UmAo6dt8C++bWRXI3quWjgNX357MFrP///b3g5MFZK/O7EU8+PMVeIhQG2w/IPhBcv7X2SEHHxlugH2F8gf09atSXt+D8ox66hsaL9Kl17rzNitav2j5GAMxZOY/NWYHhUoWz3hbialwsrI169P2oUecs+hmK/VEKMwV7T1h1a1TgDDRnbz375a1HTclnC6A//fVz2rhTiSaDLtgK8/PZAvNOQXiH+d3S+Kn1ud8t+yno8Zk+s+bR8J5LdObhE2shYP4Yzzs50gymF8kUjHktRNh3wfC55zzJP4fDuCsErqvsgyTPgkcOPbgJwo4lFwVA6AoGvizY16d+D+EJiIsLIG8WDHyN9ljBUKsYfFRQTHDBz+SPGGMQ1ykoeSlE5h1jTkcJruVMj4jBQk4aY5yD5JFCXMxZ+3WU4YEMfs8De6/gkWsQd+6hjs3/OXY5/HwhZYq7kHjvHODwgr2+zgGFMe6FdEBmg+1DWCipnwU0kZRYK9EVhPl88lIQPj8X4gdvY38+m8zfGbj3QZl7Tdw9SdhEmgXQ3CENfuZv7syHX+vcAvlnTAeC64LH4bJgFK+Q/grBYgwxJwRHNOyc+BXixWA2elbjXgjoLy03PvuLZdIK2OFj9DwnY4tqU+GfeJcrIf1A5GoMMUOCCYb1oOB5yCm8nMmHeqTwj+1ShMrfuafGFgBvMiisnzNeVfmroRTnqOdFwGjBky/sGHt4M1b452Hs6Ysx6cYn8fsYISzfG3HseY4CWNzkfMwYE5p0zPncJYMxhyjGEOOONsdTbGOJGMekOdx9nf8a0tpjTi7Ed9yaCGAZ0+qQyPHYOVNvZQ3RgGikVEjn2M1BBovMvsa4uRjzOFYQsF7AcDvm5g84eYv9o/RT8t3UzwUMJ9z8bu3HuNo4348x+aX2N4b0/7nARedMz0j1JOJL9dU5379jTP4pUzJWYHoNvFAYY/BE9Q21xliBzzk5H2WoClifkuZMqq+27yQGz5i9cdxK6ESKbx3NksR5jNIaxLgTeR1zeCqjuwJGSB5mYhsr2PlK5HKkXxP9MybE53IVxX1jElcR2OJ0i4t3jOofyl9Qmsnto0D7D1E/JZ0kvh9jcEXyRQHTVrinOQ5n+pf0KcAhfQzoJc6LcXqg+cnUO2dPfCP0+BjFHUrOOV+SyZOEi6Rxf/tk3LmGHGPMU/LGcUwYkgGTCGVMI34qAWdCcynzsY1+DphpZc/sIOLj1kLzweZGIPEx5hDiGl3ue5aEuPnPGYJEjTs1H2Gq2P0w5nasIJAgEJvWN2z+BXP8VhIeRkS0XqTiZ8XvjK79qNI3Y4jIAnlG39P6T1oPzRcndpyYjRWyhytKLNS9n9MHZUt9xXwQ84n4Aw/EYxq3FpTDlcCT0qUJ2efERUlSM8YKvKiOCRcIkpHh3qeM6piQ5zHODCnxvTUa+rGCjE+LZj/fmGfqdo7poFVPqUMdh9ExBe9vmYOttj6bE+2QwNWFM3vMxcQYwRvu+2MOf5sPdgCfa37nLXoZK/gP6r0x4OJ1TNnXv3p3Jh9OLAdjFMvSoYfA168b9+EYjuF4vQM+DA7HcAxxOxzDMRxDvvlTx9C4D8fLjfH/oT2ND+v9+kdxmIO8xHSYh5z5sujx7hDvQ44ejt/fuI874GVNSBFrgnHt+yIxV1FupnF3FG3rjhF7HC/6C/04N3cRI8ZkvONU/MXs72NSXYqGmKm5i3K+n7+nsOLWxY1nXHiPrXeRrif3OTlv0Y+gxz2eHTeIwbhVSD3EWe3poi2+8UK2pmPG+mg9L+Uz9XyR54hnLI8bauZi3MfcZPJTlPc/rsSV4YKiHbPjTHzjRgyNA59JPO5iYrygc5u2l/GCP87Guf8t6vUYp+IpGvSvaNAnlLeKNAZJHkj0BxeLiIUijXtuvnFwP+OodwC9iponi4Ev6r6E4yFpnfEY6xezejce+VAzbslvUfYdqM5JPTdewHKLxJ3yKkXcS3jpfLJGSZ9UdDSIr+Mv4z5epI3XuAOMVOMW6X+bNk48P5YMjggQEQfOHJLfFxVBpUxm4nZonDHj1Nrjwr7dvb6lni0yOTt3ilnIrjlGmQ4iz+PFbAMhojAOCDcpysVsjsa1OrhxFuXDDBXbWyYf41w+BNM57giSikvOmBSzZo7ar3soymCtKAsbiT/u8MXlBeyTMcLsjCumM7mm+7kYL0Oyb4v0AQGJd0zLqyS4xfQgTRPz/RjDHRQuxrUedMwXaTCL+uGbOshnTGjRWY/jhKJgfBXj7r47bjDu7PwcH3OYK/I5krh/TPlOM1nSfsYdQzwuHcCKhBlg+C/DQ9pBp6hwBLHOWJHWwtSaRTp/rg6oeVLM4M9/J+z0ZqYHpJwROOd4eTzJd0pPjBsvLlKxCYYvgzWCg8eVw8B4Ebt0G1O0gKs5Z6DHC+n8jSvxihpYBPxZgc4Np4/jwkFhXNNErh+LTF+k6//w5vGhB3JTTz+/K/4YYkKKmBFV3y/wG2E/174vAETtM19BBidSQPXZIk8Y41Tzcr8T4x0TzzvlPTVvRWEPSK19cqvVqyjkEsVNESAEy9D2j7wn7VfDS0H5Ha19QckxWmdr3iz1Yp59p/DSOwsHaLkvgN8XwPef+fn8KVYULwVn/yhXopgqePBE0cBfMfjW0pccVoqJvFt1xaKD1j0WBTwUAA707csQfisE4KcIxGvJsxYHqkcW3ix4+p9CBN9UtGH1nS82Yvs6Sx0LBr1C9dbHBxUDfGM63oc3756Nu3sCLf4y7UkSeFcESYISSuZ9GKSu+SwajaYH4Ny9v0OFjTAB7yix9Gkkbd8FLD9UbZF3LJ9rh4d3ANm+o2Ij8PHOYgKIQ8o7H0xZ8cP0hc+hS8yHFlMh7LDwDsRU8tl3RbBmvmYPqP+7ImZ23jlxp7ChiCVn+Kl6vQPi4jD1LiR/HPYKxrwL71N9+87YMyie33mYA64fKbF859aX4owCzysiBj3ND1d/lMO451BMSHz5TroMEvT9ncde3gn+ADnUZOonHdKKHsa9SPcFfJFSBPb27C+K/rrA1sGtpeIRox/StQMY05shQ90X50us/Jsc4EH03b/GvfTPwzvFxGmfvwsc0nrjkdZ4p5iod4LpQOccB94fB+awxBM7P2je0Nr71lB7B8kxZRyRuMcDco4ejsY98zceUIsYdWEP8x794sMHMbnlnec6obkbB2pm5T/rnvLk83cR9WM8EAfjYL6tGArtrxgYtHBZnnv18Q+D1i3r+uOB+mZ53yee8Yha5qt54zloxjjwvFbPcWMPjgdqu28fBOD/ybiX8m+gdzmQHztK8dYf5LvjJR04ee/ZGu8gxIDbbyzy9TkY5LWutNc8DsyxjPu/MZYYHJZywEQJ+L5EY9RUu1J+9R2k6Rp/JVz+kusOdP0ShqUouSq9rA6wa5Zet4cYf+FDqSWGDNfG6L1ShMuW0uuoM4y/UtzDh3cspaB9/PinMtTDEyWQEIAAJgKemXj6buLpZ2iTpewcbqwTeQCkFKF4JSJmbv9OfSaI3Ln5mIhFrCUlp75ALRmfZd5D6jsBxGXBiQ+mJooBefL9jOkJy/tcTCpvlMCccfUsERgRfqZ4ZULbg2H/ExpeS0xfF5W+KaUxaopZw1cpkuCWcIxPcHspge9z/AbGyOpHScZK6vuiUEstpyUPXkB0pZT4JxLOXiY4fiwJHBBqyDywNaHpWYmpT0nAN8dNFvyUBA4rMZxUknud0swJjf9KTE25/Zb0XrD4pgkP/c2NV0o5zVHCPYHqe0pKXUp2P+Tg5OHN4y8PE74GRCPFANKfYOadIIa40eTvoLGb4IBcoveMmKAJl2QpAJT0Q86EFB9xAJrQAIYaoiIusL6NahL0koE4HExMMIbLxdOEgu3nek0E9MWEJqCBBwPR9Gk5tNYfMdUl4bBOmPUJtz8Asy4d4CYk41hyjKLSjxOCqXQNA3n5UJKxPyEYfbTXYhzUJ4ziPEHVN5HLCZAzJpgck30JXO6QmlDEDnrmXrbwiBQng9kJrf8Sh2juQDKBGLrYl1wKjicA8zSBGl6i/8TLwhJ4CCkZ8SbpNdLHjBmcKAIm0bOerM9CLlFd/Em8Vgo43DB1Sl32lmzGe4LLMXo5zHGJx4XJRIk5uJa+G/fSD+PuissEIWAUMSQTNEGIlNswE+kARCPu3rZn1uC+k54nYpP2Cb9PxUDNr8X2/EzhaUg5LvExvBPml74Tnymmm5HMQVHJnU88nJBrOSyBz6FYK4GYsmCE2dc7JpcpMdf6T8EIdytH7Yc0q6WwHnO54F3JI+/S/MK6mcOX8p57AUD+r3OYN+9BwATLidr+lD2+k/BSwvNKHmhLDGaKyn6FwzbCfeT+Sng/iM8WGX3gNKwkXEAhaxVprnwn5RfBFcKbRl2ZEA5Dpp7V8lHU8wTVvyR4DoWr1HoVlf2AWHtHeS5qz45foIyvBb8Qpgx8q2pBkeEGi04XAS0oCvMWAd9WlH2JdIE6YcUN/96TcTcKpbfAGsx+lDXyGj7GyTq/a9xf+ygOoH7FwLyGmvxQIx9jPyE5EA6pyIHrXejaL4hHE4cVPQ5+FnPkYRQnSqBxLw6oXwTzrj6riWfJU5A9zZG5HkUjfpgbS9i8C/h9F4LXvLgGyVFMDMbAechclnctl4olxWSXeONuzlMxR74YpPYXI/EZyinKYeJdoE4xw8+4Tzo/TwLPhawRK67JnPaRx/6ROULzO5lTzGjOJnPCwOQrIBqf/U3mnPNQ7E565HnSed5an0lDvJMDyNlkhPcnjd9PGjgsBl9OArW08NOkEVcTOfJp7FpPevTTS/R5TN3UcOvbI1IckxF1OKSHJyPogZUHffKi9dHzYSC2XlI876sbk8Z18tbrvH3HpMm4l/95sCZhMnZDlAM2WWYAXX4aPiJTtoOIa8jJ0q84nn9GgDhpME+TOQpRaPP6PjPpQdYUOYp1LIc14aQHwUwasDNhNNVWcUAE28coT4L7nzTiYFKp4WROIqwZZ599/Bt3mcbgJLGvJM+h4jHpWeMQTtH6w2oMJ43GbRLsD9/P0b1NGoyX9VCqmSMNqz6aMikcwlGOQzGnclkZ5MGyEE/Zfsk0GeCLUh7A09tMBhxorIdnCPdl5t2yEnM5Hj+HmncrlkO0cjLewePHjTsZcBnblGtK2d/LxvnLYAzlCHNY94y8UxbWL3uuXSb+t2yoB5LvMrCnkucoe+a6HKFeZQWP6B6lPZRBnJeN+P0+ik+jbMhTWakxGn85oE4+e9XqUgbqEBIHF09Z6UefupQj9g9au7KS97IBMyG4KHvGbMlzGcyb1helnHmv7Ml75Qg8WTZqaujetTxbNcvqS0J1KTY+fPdajqzJPu+VI+l3OQB3ZY/3yznUwzc2o4f4ftn+ZvLJuE89jeTDz79POZOlPnc+oxal3k+NxPdTDJG677gx/vxZEIIp57MpwbROOQmdopq76MzjxkbEP0nt152fExMqRipvyTwxgJlS8j1ZouvFPlfWG3FKMARTILCnqHg4Y6fF5/w85eallP58CjBhU+5cRC5RI5PKd5HGWwpPZeVQ5zw7ReRdqpFamzJ4eFDenSoKHCL0s/hZOb3WlPLdFIMfijOmylk8uv0yZTVgHG7KnqYOwKyLd4l7qPmmylkdmeIMW5nQGiefFi4QOcDFezmrXVOKcE4ZDyVTZV6nqHenyhjmyTmKRG8rxmCK0p4iw1EI9xGYmSoL3qAs9JRieqYYfp3SLmmKNiM6JeCO4xPtkmiqhOsc1/uk9pXANcp4DMEXB6ghLxN4l3DmaPUkxx3lf/wumYqA1pQZfWf8o+RhOe7nPMQP415OGHeG7LzIjxDCqTId2BSwJvW/k2VGaMvp4k6VeBJnBxOfu38tfuoZaZ0pIS9k/CV+Dalpku9rIjdZ1o17MhbK1FCk4Yo1SYbASJk+Kg+KaclgtJTFJ4c9yihIsU9xB1KGCLg4qd6YYvBB1l3B7hSHIcb0a/FNMod9su+U/pmU+qQkmHCixyjjzeFhsizwpGOEuPnI3qSMTpmvu8aXMMcBdUxhqMjrwfOYIMzYlHJIl/h3sizryVRZ74+pEj0nyb9MvblLninKMLtzlZmLKmZ9Ep+W/uAOAyW576ck7nD2QxlJKjZSr5waTAj4l/R0SjBXUyVd26YErp7SLg4lLgJzPaWYQ84ETpVAPAmXjlLNpqRLA6aebP+5h5CyzJ+s32JwPKn4BupCWsKupqPcc9zByOorWb5PH45/GHeRKLTJDWQ6BTahZUNonL6ChuwHnR8y7kBOJoH8w7GVDHslRAzJDQtWoQmmyrh5t5oSag3qnamSP359MBRjTComaEoxgygOrTFNRtrbJIhz9dBcsudoEvzMtC/m9n5y0HnWeEj4iw23/0n0d4ADp0p+WsNxnYqjUhz9mDTENOXB6yz+SwK+jJiYNOQJrQF6yTWJ4r6E5QzJoXf/KHmZBDRq0sA1Km64yyfBsMbSK07jTZwM6g+11qTHgd4HP2SvlML6mjXu5YRxn/5u3CObh+kBGJQY8UwnRt77mQafmQ6c97Xlfjjw+kxHmHs6UlzTL5SDl6rB9AvXflDrTv+Pc8WQH/24ZDqn/E3/xrl5qZxMR87t9LBncveZkS/nfhj3aYP4T3uS//SAADgtmZDK0++J/6X2M+1RkNQalWw8mWcrNClOe5h9qHYVJZ5AsKFxT1dwwzgtxDzl1DQPYzttMNrTbq4BHITEp803HSg+0wGH22mgztwa0+ABJ9lD00ajEe2QUqHXmRbWRes/bcQfWutp68VFBavLtFLPKAfRStgBVeX6SjgPTFVA7ajQGhDjkD0dyIvTii6xMVcE3a0Y8FvxwHuFyEMl4iG9YvdBJg6uRNCdAR4Upn1wWmH2VpHxMw32nDkvFSf3Sk/6eGMOgzDeKs4clcQ/lfm5QOXXdbxEatNlzPCKm6owcxPJcw3cFCBCrnik5qjQ8ybzIL4vfEeaZOldYl3f0z9HBFNCHJnnkFip9Su/hnZYmGbMHRerhVCngPrD+60ozcsdLCp4HjWckHmm8FKh46HinTL0yRRg+si+UWJRn6MOPckDd0WujyTa08ohH8FL5hKAwDRZL4QbKkJ8lWxs05HHlILHacUcTQs9buqBCsi3VN0rAM4qfn3JHj4FA5GqfwU4RLkH/wpwSK8YLkGEeFTeFw5zlvcmGQ5V6+JRN+2SxxeLbl+Kelvx4/9p4UJwyqLPgk9AfRCFySh9xeBzSjj8ec1J9FOGqyogPyK8VqHxJ8ZekXGcunEnRUe52Z1mTo4sMVXkZ72MLmFYpiQDbjDQ07EMWCVAOCv6jRHUuJJ58Gy8KUXctEPXNHWiZPL+s3ErPJGR5AYSLirWmdhDTBJgdqeQQyVXa0v9mDWmyv4xTQcS/JRGypppNIi6SWAqaZ6ZYgSRrG/Fr8+mhAN6EH8yB2+UmyizacaCdKipBOCpgl+4ROtRpEYVOZ8SrlCMTCE9XiH0DjQg0HyxeDHQH0xTN6wV/N2gGKRLFwsfVNKXBSq3gLFOefTSlKevMXNshcf0lOdFWGYv2oVuBdSlSgCPV8xzPbyZqfy6cZ+pGIiV+GymopCCMMeM+zMR8IwS00wihpnESO7v3+HOW/n1v24cyXdmBIKbQU5MTq4y8TD5mHb2QP0+w6w7w5DrDLEGVb8ZS701Mq8Y//ohzaPErb7r4CWDuwp9kJspp3Myk6j9TAU86TO/Z95H9qblS4iD6vcZov9mKvzBdobDlItPdy/JnuFwh9S9rPQih1+i1jNOH80w9ZqpMLkBek7sC2f+mTKDyTL/PPW7m4MZiYuo3ihnv5N6bQbEO5mjMrFmheFLok9nnPhmOG2hcIj0EfO7myuNR2c4PdO0lMKwcLjhNHOGykWF2FM5y3malswARn7GGdNWDif4e1rhohAdces1w8QzjRhBkAckfzSj8BKXr2TeZiqyjswwfDtj0RohDp98zFgOiojnTNa3QvSO279lQJuBg9SMZf/ZeZ+MeyVL3jMEsU9zplZo3hnwWbLxXWFhQJc01tQapBknQMyZ9mkmbvbPoJS4A/mYqWC51owAtyeNbGeE9TLCrrxjqXsGb4z4xhjTQj1nYg+n9lMMJqeFvkHwqJkVTrQpo5Z8d6pM95UkJkhOpz1rNW19lzBXWt5YfJQNazOGGO1jlIdnyjgOn2+XRIPO8OyMchECmyDj5cGMUjfy/bKRXwXTM+O5jxmEXxWO1jQBMcyuOUZ7iNLV6QrYJ1q8ZYwTULxMg7mLpRsI94k+xUfPfTiD+96Dz9mDs3Ef4mWgsl8KA1MSZsv6fDNWfSrLfTujeM3pMuiDnDxOZZ/5YdxncgL7cAzHcAwHOy6GORiO4fgte2TYu8MxHC814hv32aeR/N3yruXzn99dxI0fJadZ97kXJrPZ33z+UCwExXqRGC+4f8sa0wMQ49nIwj17keaJ2Qt5/tlB99CFzGuznjWbNdRg1hjb/4yhuojL31Kuo8d78RuZ5Yvf85Aw+wJ8EcLvs68optkcdGo20FvNxtzbRX58Mzvg/pn9bty//ycpoq44uBufTYjI7IVjXi8ScyQF+oIWwOSmZwkjnPk+Gd9Fgngvss+473JAIuNN7tEpxKxQsFlHEGal5y7o+X4aG2KO2QvBUDD7yBgloh5kzi/S+0jV8oJ+buaCjktqRDIWyrxdZIV2tiLjysXL7AVRywveLLpYmmUwwOFgViESssbUHirEoYKoD5kXt2cqcr4zdb3g+zWTN5cTlBpn8HiRnZfjj2R8M1IdL7L5JjFzQff+bIXuqUxOLmg8zAIiIuWWzTdzsJm9UA4XCY52e3mW46cL4pKC+J3jLvK5C+wCRNoL1RcUdlnur/C85eJa5BmKQ4k8uThn844eoC9kHphR4mQ5l6v3RXYeTu9Tn11k8zCrHYYvaA1BzDDFK5zWcbot5XBWeH+G4KZZomdnhT6frQh4vMj2Ejlc/RB8W+b5i6xHmtF03NE1ko8uaL7nuFbKAdmDF8T6lSyPkT5N4G+qn2clL6jV/YLRgAtZmxLPPRl3ovBU81CmaNYVxgvhWU78LmxrketR61/QRoky7uT6CjHNckRDEc8FbXDEnEjfC007I+Xdfa9Miw40GFEQ16aww5iyTJNeAPFxgOfqfME0q7JXrtFnPOol5ojAEPc+d5ibpQ4tF0JcYP1IA+Gud4GRImmguVpphKvgVutXyLhznFFmBEUy7ggGLmjxnSUuTbhDhSTUSO054z4riNKsIsQsvjWTIPWBhjtAn2a4eQQ+nSFwNqPhRdFE7dJDip3DlWbC2QPuhcJl1GVD8vcy4xPKuBbOIJxc1i/lZqTDd1nGI8zr1CFZ0jNE76mLkgujJl44l3AGHzVbAXRRW/uC2L/Ewxw3I3Vw8SB5FYGHZyo8/2oxpHyM5jkAH/CvcX9/QRt36CTnMd4PaB13rfe+cby2ESEvucRTwYQIMsQhMeSRV1/S9okLnTdP/CBi8tI4tuIsJr7z7usB9Ph7K059e1r7vWI0DjHyHLlu7/8kfpcNQ/59YLkAjOw9uO/fV3L2PYPksYvhyNQ2BrZj5LcC6O3zP5UxG/cAsL7P0+gT771W4/5+QO+/V3ICkZav6agYDlIG0L8HyP19xDzORCTLaHFV9Hr6zP3eIjQ+AsgM355+vql4Dz4fW/TeG+OVcv1dQN4T4v0+x/7/+btVsEBcv+e+H7CJeP+K538f4WDxPs+9VAZ3efeeMVap3sjrABbpwPfel4cq/jzoy8O+GvE+J79G6UQsTEO5CLw8fF/B139vPaymLwp+GHdKSN8rBlgT4ffKM++BZ0ziA8wZEu+s8plkUmY9zMp7JfeoMbLUYxasvbY/9LBkiWUWiPN9IAZmjXXV5vKth5aTWcOa1vUQMtXy57tPKQaUH5BDgg8vSPl9D/YD11sW/LwPxE4I3743HsKQ92Y99CDG97NGLKDYnPXkDR9dQXDja3JQvQrVWZTnkb5H8eazLzS/vpoUu+7QuPS/TLHkx7evZz3626IbPjidBbyylZfNWLn8btwvs8Y9VdRLXWxUcFwmbpUucSDN/gr0x8+X/POzPqC9fJr7Egd08hnNzKONkcz1rMFwRDHul0r8l0IzXGKxzhoMlPVwOHuZwBhVx4rduIsYu8Qwy+VnVuoPK8lpa7tzX4KEcilzAWr+zHNcCn12KT+T6eXLcPEic3kZIMqXGOelnr/0jDXZHxrOtO8CjHvy/dkIRoJ89lLB2WUkzTAK7qykXbIwp2oCH26ItWYNuZ+VuINa58KvHxCPwfLZRVavZxOfwT7lkuCNS12bZrWeuQT1FsAn2h+zbk4uPf0Zsxf4klDSu0vcR72/sNdy1tLfl/bcaAfBWaN2zF4CWOGxk7hxT0w8x7wwlxhIQ8xJJudSB+mcBLBLWcTJ34nn/93PJZ/guUvFyLjPO/mZ0+LU9sXVxHl+zs23ExO7PyF/c4n8cPPPuetfAgAW6pTJnRunEL/77pxgQudcPLv4Z/aRygnzvVTPOQW/7pxzWv2T+wWM5ZyQuzmDaZ9TcDwnESWAdyknZJ4kLDv4pPCcyh9q0gEBoNZJ8c4FwHMOtp6xN8fUdM6Qpwz/cZih+jzJ8w7ni70hHCrZvmLmniN4kFwvmS9mbyLXOv01587ncBu7hsunin5A+ubsi9LdVF4veT7UsD7HcZTWN1S/cfkFdHFO6cc5pt4Sl85RcVD7vxQ09iLdn66+zDkaksEwUz/rAWlO8QyqT7lkeIKIX+X+S+XyRuMfzTdd0nWZu4hwiXNJey1WZyiek2pEzSf56Munfyrz+OHDnGvALniRdgV+TgD8nGAe5y5pwZm7FEB+ySdqjjGyc4KpdN/jnuFIyzWHc4TZTRnSS3nMXeoiqRknyoBRhMjljRQwDkCciF8QB71LwpxTwg+YvjkBp3MXhDgShnuOapxLwfBfZA0TR4Ycbl1yIeMjzAp1uKAIfo4gYPZgc0HXLpMPZo45wti7uX1/KawrmMI54bDhxjBH5G6OqrfLBwKJUs9ytRUPftQcl8SBmKnve4ZnKW6UMMdyrPN7hicv+TxTZpU6VLwn9uxihqyBcDkxdyGYc+6wJuGDOnwIgs29z+GLPLxdMprJ9Aupj0JM7EXMJagHDKfMKT0saYBr9EjzCB7wU7iVOFjTF4EDKDzMUXzE1FC8+OJ6m4h7juN84SJyTjC+c5fYJezcha6d76lDKcETc4ohzmAc8BkktxMHRfe7zKXHJXgZeiH7FIt+vlcOdtLF07837v8a90uBgIZjOH73cRHw3oXn+xcB68aMM484Brk33/q+thh/9/65COyl3w1Tw/Ey/Zs3DgaFs7z7Ja99XkTSzuHwqwP2vJ9xnwe+nwfnmfd4dz5ycucH8M78KwHSfKT35o3zz7+Sfby0oZyPkGNtvXlDD8bY1zzx8/zvWK8ccTkfuedi8k9IreYj1PcnXi9eng9CeY3ru/lXxnnzOWE/hHvmX3E/zkfmtHmnd+Zzzu0g+G4+cq19n5kfYG/MB/RIQHwPb+Yd4z5/ZQORVMR5oAHmwfcsIjRveC613hX/vSXOeW29K3leLyBc/RhafO8DBGYexMC8Z12RvPsSGUq884G4i4WbeY9mnw88mFFiMm/EtjepX+GH+nmPeOaV/Eq4mgeMGlL3UFHIzHGF9UOSb2ILHxnjFZZ38pkrD16/Sq8t1X8eWJurG9SHVwmOvYqjH/OBBpN87iq+EZwH+duiexbuj8nnKE/4mjUVm1eY/oYeGK0HEmQdim/gPriy+8J5j4OS2wshl87zRl8yb+zbedK4X/0y7vNE4qyNM4+SJGAW5gViDVl/PvDZOUSkr9JmWjPuqPCje8nMc5UYYP44QzXnk19kz1fG+oDiM28wcxY8zAmEY8Facj+ImXSfnTMedOaA95EeU9+9Ekj8KmztGAPOdaLG0NzJfV/Z9+Su5d3zymFkHjTaofH79ERUTABmXsQq0Htz2mHqyn4pofFypp5X/H5i9IP10Mvm/Ao3OD71Dvmr1bxR+5HLFWsN5rVD5JVNW8hLPs8cWms8Z1xvXjrIcH2sXDZLHIz2ZXS9udJ9sLD2jxv3VKNfAQJ0ZTBeV8bP0bWsBvAKJDNpbS4/V4qAXwFzaO9fCfFcGfdgNdNXBjF4emZByy+ay6twQYJyexkBZ2j8IXu78ug1nz358gGH2Ssjb1yCaz+OhSsh3kshHi3+EFz51FTJ5QKCBQtnSdws/XwF8JTGTcDhBuZFpAd9LguuAvTqSul9LXeh8VsweGXkfK2uWq2uFC3Q8H0VcEGE9udVoL+5jKC7xssAaH8+fHRlzI3BJ3jNL72P/I5oqdW/WDCD+gNmv49692TcmSQsXGaFY+FZKInJFxLvL1Bm7urHv2OkAl5w5l+4ct5LzsmssSCYwgUDCS4IxLuAEu5VJtmZ/XDfU58vULG472lNdJHeY6aWDBjJ2C+JGlwysTJ4kva+QGAns9eLBHae8XPBN+jCJV+/BW4/CHEQ+KdM5cIVRooLzFoLQoMvUP0q1IKqzQKHw+Tcl0IsF7pRW7gSsMfxDjUulf7m+k6qA7VnhucWKK68pE3KgtQvTv7n3f1dpXO18JTnZD0WqFoL/cXxxoJ2WBC4bgE17sI6C+hFC1Mrcl/APJmaXBC8kcSPE+sCk2Outxe0fAEHMlLPLowHGua7BYSPeFOBH+I5/RJ6CdJd1CxS/kLQOvSwssDo8ILl8uaK5n9Y75VBahWnN1cEfi8BT3PJY4qM4wL0V8KeFpQ9U7qxIHhK1bcofmDB0TyObxeusAuRhWfj/v0/SBIWmCGBKkN4lKgBA2nYn0W54kUfMdhiga500Eh58dnrgrEeC0rxKQO0IJhupBmQ5lkQnkfyGfqcZk45k8vllqu1hK8FRTQWlBuuBaAuJPYueRFA+9rNz4JAaOiepbjQXkPWWgDwuiCYfC1PMCcS4kHFPEccpqC6CDnh4p0H+kbKu9vXlKCT3MS9b8TTghETC5dGPDAHcLR3tDVMuqvErpk7icdYvrzkL1YWwL+2LFzaLrUWLGbsUtf9BQOvIBicBzVM9CuEcVsw6vyCB49Tl7AIjyB8rPX7AtDzC+DvVs41mXvQ4/jWQvIH4P5+GfeFSAM1VRRoLGZ2wSOJFnB4JDNK4yHGQZ330pbfBcHALhjyM2+N0wM76Ny+9ZsH8ofuG8YtsR5L7pd2XLvvzUfo8YVLjxh8eOIKF+WY2FgYFCdWBcMTKfbQCxJz7+RpOIwHq4UrvwspqZ8XAnXBOy+XeGyZg7thvhQHXkbAF3Nrazkkiybq0sb5MTAp/jVdOqhd+unzQEbV7m98uXYe5ZOIHGK9CJyPrBvzgh4b5/1h3KXiJccisYlF5/vFwGQvUj8rMS0q8yB7U99F4vSYa5GJb1H4Lvm9d86rxlirdFxS/c2xVbEaLSaeXazasIXklcRXVc7hoieuFj36Y9HzXTSef0fVf90MBqpyzRcD418k4kN4wbd/FpURu05SvjRskhxaZfZd9eAsgA8Xjdy9APLQQoR+yrxfxeq36OR2kckpgodFZ21Rr6qe2lWNUzMWkw53c/kw4auav1ldBPR70ZdXq3SOrbyzCMYp4Vh9v4phYTEGP7jarfmeKuM/qkCuqno9FyPpZkwekmq/+NO4JxqPMzeLDsEkjftiVQeIa7YWJRNadQxE1SGH6q/Dw8/1q7yYLSLNWM3G4JJQhpSq6RgXGYJedJu4Su95vvprL4vMM6RxYIRjkRODKv2cCPqqbGol87SoiNIiQfwasSy6OKoK+ZHyVdVN3WJVEDnmALHIiFumrlWcoBeJWi2Az3I5YntUwOoiaKrmtYMPYyLZulR5XlkE4uRyTcXn5pjEfpXBFjA/atAXHWO0yHwvYr/KH44XHTEVxdnBOtsf1O9Vnt9dnrde1rjcOM+YazdPZD6qcu9TzyxU6R5aELicxKJmtqrGg0uV7h1XWzN7qQq8KZixxapyiKnqepB8b17zCciBWsiZqPdV/RJjETWpyIVPVT8ULTK5Wrxi/IlyucD1sMs7FIYRk8muR/V8Vakfhasq7ROSQ/Iii55Ge5HhHQmrGX6t8v0EeJeHN9//Q5k/zhQuEg0oLgIKm2RYxXiqylpVwzNVZR3t2aohb0juBLNHfl8NqIP7++XTQPZTVea15MeCJxSHSE4teOdyXzUeGq5AvF15Dt/5qkCuLH14ZeQIqae0/kZ6Q+ut0D1ZMWjtdS5G4Xvy0FsF56964Na3/lVDX0g5fOYvH8617k/ixaoB2z6/V431tHChRUNi8B+Ke2tNLT1v4XwkD76aE0M3qkZ9uDJwZdWDo6tMn1p4zlKjqoe+VQP9gI/W2fmPMO4oEVcDyAX8fqkKJt1QoCWnkZeeP0t+L/yuCmwIOfsa91CjrpDikq+puAJMVdWDwDzJZonY59KVp9BJxuHKeMi7ChBg1GRYzZrPAdaKiStPvhDwslQ19oiPYfIk3SUfw4XWzXqpYN1vyIWF0ktLMYz7FWjcr/6xXRxVPQyClZ99asnpVMiBz9c0WrWIGEshPOhzqNE4pPqP30VGdYC6GJMbQg6FIcZdwzXik6zr+R48NH9lvXi0eoJf3z0Zd8fELgnkgHwPEQzx2RLzM/es9M4SY8K1z5aA2Hz3jrwXOo9v/ZYMcy8ZYrLsEz00LUV6ftGwLyRvS+B3Sx71XBJyKO1Be8ey35AesNRqCey/JWOcMXoL5bMlEHcInpaMfWXtTZ8cLRnik/JoiX/Jg2eQeJ/N2pKRp5ZAfCwpBsKKj5DPrT285MHjix4+AOGpJSPGrVy9FIBHCzdbe3YJwCH6fageIHheBD3eojFfFh33wbmPj1gy4j7U1z2NtHFHxDCP75dijmvsuSgxXccxT+iwmjzLeouBJBSyPxR30bESaJAlEfN5ThOtqD1zbeuJJaNBQTDme0ix5HcxALfWXMfiQh8uXgowb5Z4fPjGB7OLnvxlqcdCTnwQEutiJB6PEY/PZUHu+u5psheNPmDQ+7BwY96eyof3XqLusXg5hH9CLisDdPHhzff/xDbF0d7zWec6Qjx5znE9gBy81PvXL1j715K/QeUr8Lll7blrQz+hcV3/RjW+HgBurgfYT1w9r3Os0XUOOQqIbzn5/jXQEzG05iX45/oV82nMPrn+DfY/iNxev6CXGgQur/3iWubej72XwWveo3G/Thj3a3sQy4gRuObfXfZJPhPbsmBSlgOTlST95SpghgIPB14xX3uKUAyAonU07HHZrX9EMlmWsBuhCZcHTN7LeRxmrw37e1pnWTGLeeRl2Qef17K5Xbb0lpDj5WuCQ679e3bZiLNlJ5blkP6+zk+klxk+eI45mMOvdeNuOoDGwhqHC19TdR3fAEXlueswXXvW+WWp739D476McPq1Hw60eZZRfb2We9WCv+UQPF3TmEA1cVnRy+Vrhistfu3acGlm5cVHz/7m8YOHTOGI4JevneFOSgh08vPUO9fZ4ZK0K6LL1/y77ncSmFNxE+9nEpaIXyUQ5/lMbO7aVeF74oYotT/i9yQpcnVL7c+dj2iu5Wvnea6G7ufO+8mY3bgoQsgMt8ZVel+ZuRxCouZZcuajCI1qIPJ7Yr/LRA2luiwR2Mz0A1fD62zfZerN4ZHq/2shl857y9c0Qbt7IjHN7d/ty++fXTH9y2GGMoMOt7mxLDOCQPLEdXZNDh8UPt39UfnNxFxlauXy8LU+yP4j4mL7/Jq+yEl9z+2rSvQPs07GgF8zuiDw05KCmSVpL0zu3Dwsa3ipZrHG6albE7avGF1Z4niZ6RM315l+prS/KvMaq7lSPNJz1wzOgH5bYnRsian1EsGLSy4erwUeVTSNe26J0n6B10RtonSSOcwvGwdpdK8JTnV5n4uxKvuJJcLzkDxQVX4XdI2aW/LHbN9dO5zO6VyV51Um5ifjrom21EhXWeNOmd7la6A5KUG5xp5dFkwqdZJavraPJcaUpQRIirkKHD4Y4li25KHKv7tUBd4ziL6ljkto7FUFzDHwIryzxOWfIJslQxxL6L61WJnnQrCiiSSaZ+9+d7hEzClqAiTzf22MrWrr56VrYS/c4QLFcZUwDla8ScZdq6liiJe4/IMYXYrY38tA7BkBNx56lkHNXEIMKWhaIexql24avq4Fc4XmR4q96pkHDmcB/Lpk3JeJB5U4lq6Vw5tgRpeYix7OAyxdCxcYSG20Q5iHD1iyeLoAP+jjV5Z8tFXTceRQIY+HNyuP/1l5+mAl8eXK03gOfsX53h0rzM/Lyns+zy8b45HmXHHGsiHWFWEuNE4txpVA07zi+c6Kx7srxnwNYqxEnCdGfVYixBsrpyuBz6xEnk/b38oAMbQSCS8rkWtPPb8SsK8V4/yxeNR3PyuGvK8ovKR9vhKgKT7PxcZviA6tGPOWF/etDDhnob254smDFO5WBrTPlYh66JPfmByJ+MKVnPe5bOQVj3r9MO4cea4YhGglB0HSCrxiSPIKQPIaaWtkuKIJWY1/xyL0aCw+IF4RBNt6eENj+vlZzSbG1j2vGHO6bMTbygCIR8OtlahDcyZxx0pNjtGHY57n9TX6IfsVRw3DuWZ0V3ISUAQzXH+x+6iF1cDnwkDj6xVDflcM+EJqiuhCXpcKMMcaeHAl5mG0hh+k4Plrugm2XLqsGPpXNOA1v8vHlWv/i7OQQ9mK4bC2YsyvhpcVwSstB/D3iodHZOeq6Ty6YsTxiocurKRu3GuPN+41OSBy1BKDEWlojpjP15gYtc9eOm7lueVY+cijTjXj7wiWfOarCfNKv/vsH82HhL1axDWp50IxHjMPMfBh+TnPvq4F9BXx7rJPXmtG3KF8UPPAVs2DV4Hnfpq9mpHLQmN7KS6tBWhvXv2dBy+E5gjZey2H/dYiYsAQD2IYzbqXh3bknZvrAfJ7TA9ynUNeapxxr+lmavVpPH+2WgPBXgMJtaYYLeG91Zoyh1GgVkEBWzWa6tVEfG4+fWJerWXnDTKZHBYS8frGvKp8vlpj8p/M2dN3qzXQuEv7qvkbmlX0kFgD81AzCLenaK76HmBqHqaaW1OrD/qsh3lYjWHA3Z6Qnq8C5jeJpWsBpzWGb1Hjk1hr1XLxQfy8qmGx5h/fMpWfmodG1GwmeNXA5aLWKPtejW2aa56Hv5pRF61rCHOvWuaugfwl9Qe6Ts3fAK9aDF6N6fvAC0LXm63W+BhXmbhWPS4jVl1eAft/9Vrh0RqR25och/WSDcHMaujFcg3wldIlX+3JuD8G+7BaIwxIjVnINZqcYbzOigxFcquMgf1pyKrZAq8KhaNIdxUQQu77VSYvq25zXPMCu1rjDbsrMKs1IcaaIL414dAiGWBOVIiD2SpzSFitMSagxsRHPe/WOIkbQwNL+1cxAOYbFYTVGnYINolEjTCfKIEJB+1VgbhWgb8W/MQHJQQM5lepPqNiZngF6ttrmj+S8ZJ7BbHicueqFq8Rb25+Xa7UDjSr7iG7xnPFqsLz5LzXOLYpnVi9JtZxardK4dSdS/h+tUbUnXqeupSg4pX4zeEwidNXEb1ADD93icId8mp6fck+UuJcRTXsWtHDa0dfa2lDSPaBlA/lkLyq1UXJ5ypw+FmVLruY/lwRNJf1Q8Q6lE+TMCleiCGaxviSVeWvZ5yPXFUOmz/nrep+1d37ck2+dFll8i3xg+Sjkxwk+unr7KXwKmXcV5WGW2XGivA5B4ZVYN5V5j1KwFaYd1iTKTQpt/4Ksp6StxXggLOq5HrFkB80z1KdXMFbJUSJJCUk9hpNDqvXcoykgErYq+mHRa1enPivCuaEy+8KEKOII0EQVrm/RtSyNWQPSzXmL0g1Zs1rxhghIkHNwWBA4hikL8W5rnGyZ9cSsLOi4A3hWi0nK26vAv0O8zBX/2uhhkjeBD3J/GXtGtQaz72E8HCmxyLEKGnpyrWuHVzfmzEhce21HVcrFg0y8AJcP4nzjDVZVXpc8zUr1tyA9UQ5YxXgM21P2iFlVehpr74QdM06H2Xc2dwa8i36ScA/U5emiXezxn04huO1jA/DHAzHEOfDfQ5zHRz3kEuH/TDM9x8T6w/j/uHpwQ9154X60yTO5x+URT7U6Oc/uN/VnXWUgD84c0mbVWOsp+P5IMTxoU6/S+0vs16dj/MDsSe2FkwuMjlL1Gy17uypzrzDrB+jGT5wuCBqL2FotS7kqsbvC9kPt5Z1n9Q6LE4VzH9gavYByZWGlTrWv1J+PxgwQe6v7mC8rq/H9amUGyQ/HD+k3ld6JxQ7MN/V44jCBy0/dR4TGlZXjXVIYuGDgtsPdT4e6X23lqu++ayDn0lx1Zk4GU78IOTvA9j/aJwajj8ofuADwD9a36qf1zEe/FALqLPUl3VZo7X9cL3GPleX67QqaMwHQBOSPoHCywew9ioWhH18qEc2t4zv0bwYp9M+xh/RbQ5fit98ePPh2bjXMTP7gSpkXWlKynTVdXMizacBQ2z6unHduvFzovHQuVLi4gpMHSCvurPPOlgjri51oeZ13ESLa9X94lkVDjzJHLK5J/bn5pnFP9cvjHmX+ko65HC9QpEsWysp33XmcFRPE/8H7UBRtx+koFiJ3KrcUffsc6p/LPhEcVK38wgbHzGXZLrZ3NWdfgF5XV0D3W8d4wgERyxO6vZck3xgrVfdiAcLxuoy3lluqCsaUQfWqdl1G9IWn7z66Hg9MH7HIHuvy2B4BTisWfMoGUMoH3VMpyhjnlyHNaxKf8H9V1dqxhzkTb7OwGGrRvyyfg417h8k0+sJyGARrCs3znXMdGrrrV2D5qAO7rmOH0jY5uJuoiShQAS/ZjD8dccY17Eb2lCCVI05I7zmtetCbjXj75igVYBUV+uGHNUFDNRBoyDVpy4fatB+pA53qwZcibWsgyZQywf6bh2cy5KfGOasDpjeum7W1WE46H6ogSbQ2v91p78AvHjnXjr41QPNNqgZZt0Svl9FD07WOHxMt6ab6LwS/uuAP7FcOIZqjLU/PC78rPXJGFUUV3Wn7+vgAVXpp1WtbnXncqFu7LFa9uBguTQStQE4RK16XOwIF84Pb9bqP4z74/+mRjKwNUE4/n2e2czzd2to4xKDi2VNARi3jzWDMK3VsJjEz4B9r9UNIloHzQWQZ2ndtZC4BEJZc/Ly/PNa4mfv+JN1q/G4/JBcU8MnEe9aHc8jSVjIe4mcrCnGek3A0hpo1NZqTGygAK8x9XmuwZqnWWT5xcIVwDsu96HYX5Nyx+3HrU0ih+Y8ofvT8F3n8YnMr3Jxst/q2T2v1dK6Ae+zZsxNTc71Wk3mC7c3M7l1eO0DwC9QXj0wsOaDGeQCqJ7l1zWG6038WMvqg4/WrRn8BcVfa3W7T+HywuXG1cM1Rq/WfHlPMKTu92vaLXUg7iQvgWID8iM1f9/j7Xc8Ljs+OF5nzc7bP4y7a9rXCEFDxI5LBDfXWj27gTVFTNc48wcUg/r9A7AHLh/cYWcNPECsKXO4n68K60D7qGFrIzGuAYOqD/lsDYuHwgmSO2R/1sZEegDFwAcAW+L+aukc+s6n5kYQnw8AfpDvpLnRun4wzr8mmP01sGZrNZ0DOOxnjLtH7HANA+okfl7j+ZjD6RpjltF4NZ5We6/m18eZfRCmzzXuazW9JlZO0rCJ5CvkgLgmmMU1QM8zc9SwHvfR8g8AN/oeelROqunapeXmg8H8cjos5oI4cK0CGEHw5nOwtM65Bq5j5TkrvtB+WwM0S8itbNx/h/HBYCSHYzgsmPrwQu8Px2/CAzc5PTscwzEcf7RGDMdwBIzXbdzXwQZ6NTHfDOidl9zfjW0/60MjiOfud83bjSemb37Dvb3wWuuBc60zz64Pgq9v4mLfJxfrr6nvbn4TXA5g7+s3/lz5W+bvZvCYW1c44FXk8ibeXtcHiJv1wWIsbdzdza5rxXab7oYWBGogoF2Xfr7BkiWtt54kiBu5+Gz8xBzrDHDUeG94s8cBUazZTfbz53glYK8zzZ58F8nR8zvrNwB2uDU1fNxksbZGxPzzmeeRfNbNsXL4WOdq4uSHq42bm3UCS+sERtzarjOHg5/x3WRFcJ3oS22fa3X+fZXEbtLzrTP1XTeYSgt/kFi94bG2rvTpOoJFCss3AC/c6N+tEzhZd74T57vJ1oRaa43B4voNrQlk3m702lD7Xb/Re8vVHXa+G1qPuLpRmrdexzSCM0epuiXzeIMbjnWGz9dumM8V88HVEZrvxqbV64pZXZd64Ib5TMmvZLDWBX7TeE7iEA7b6wYjvQ4eLiU+4eaXdDrFcZwPuSHyzBy2EF5nNZTxUuuCL1oXesXVRfRguH5D8x6keTc8Jqgcritas54x7jePxv3GAcMNby4oEV6/cUZdmE/4nWrEdcGQrTOFJ9dA98WYWwpA7p6TAGFNrFs4IneZPN8w62vjBqsPafJvwDmRGG4cE3mT/Zx7RzP9VBxrjFlaZ97JmMobGqNrHN4FISFrheBDwjuHCaQnBQIRDxY3+pxsHbV9O7giyZ06ANQwHFI9lqm3YBq5+VnxknJa13HmcgknYmitM2aRyqubgxpQM7CuKfOl9VWdrs/aDX9pkukbxmSsK5ywZsjvmoZzat0b+RCX4aUb4uIE6VHFTML9yxwG1wguXLvh+Y+8pFCM+zpxyFiv6xeDlAaL/FbXDZZ0+ZjBaZ3nEjUeai8+fa7gkpuHuwygNJsy05Kurd0w/Ej1zY3CjVztJd0VfNqadAF2w1wM3PCXUdQ7krdBMLye7r2HN49fPqxropz4/SMngtrnIHjY70PfQ03t0/joDOp76feo+xEK/9Ew98eAdyHTaZ3TOD7egFhL1k0TYWr+ukf9hFxw2Pjou86g8/vS64E96xvDR+BQtB7aO9zvdVsOPlr5zrrGTcK414B8ILx+o88D7ct57yPIux+BOn68EQ7HQvwffXkU4M9nXH6sD7APwYuYj6h+Ee8hOvQxlk9w8LJO5Fd8znoJYY27HsnfcDmr58ynHj5H8lVkfeqDwQfaEx99+j5unz68efzl4SNI/h/rDNEJTTko84C891EQPgpMHwWigYx7wP4+SqaCI3mLUVFIU8pHCg8KMX68iY+Pj1RjMbF/NDTzR6NB/kjkJGMauBw7zY+SWR7GXVtbw7v080cPTGr4+RiJF8j6Rc5TzIOYNZ/cgOYX+jra/uoYz3IxfQTygl6+wDmrY/wJXerUMeP10dAXHz0wo8anmG9VJzx6fd1Tdzn+/8hcpHys65j7GNG0hvLGRysP1f16L1Ys60hfe3o6ZP/qBWzdo1/r4f2GcjPDcT9u3D8CZBAy2PkafnNBm2/E3UOMHKwLOZCaIWTe33X4CmwM/OS9L/N7DX6OdWBe7TCW+rnx9HMjMQbdE4FY+WgwOXnVbGA4a9hzkwd+1xUsvnTfIXtaj7R/qTaDysNrzreUz98lbmu+1434Wg/gnWC9MRzyXzzvjRz09vX3X9a4p8S6ESAiDeB76fc8DWgjhzkayrMN4DMNeMQ761TOGwPMRQPYO/eOgjXzAawR0YQ18snXOoebBrhmI0cBbTB9KWGrAcQq9XUD/BzdewMQsYahjxv+lwDreXKW8WAVdGBspC8YYIz6cENefAX00DrKyw2Q7xse70bc8zr6fsMzh56alsxP7pdOjQicDnDRemjcDaPeNjz5YhDeqhGon4Y51huRMHATjgGvvnj6bsMQx8bzP5XZUBbZcH7e0Iw+YCA3Gj8GvDlunkQ8G4GGbIMo8PP8G47Z/PkZAI4NZ40NZK+SiXJjdovfyNZpg8nPBhUrsjYzvzvcPGpG/mc8T/8MZ8PJRyZeAavk/FJ8DeZQgdQn1Hg3QJPQIPrvRu4zgAjYeTY4vBNzbBAxZeqX7H+qZo3EPyNCTL1Sr40GUe8GjZUNZr4NS50aTl8S/UHl96P1UCHw9MYNbpg3mHxx2N8QeDiVM6a+G25eG+kaIbFuNJh+lTTA4Y8NhpM2bmz97+oYpwlcf5AYboB6C5i1DYUDNqQ+APlr44bhwobBmDUw07Oh9WOD1j9X07lck73aYHpW678G/c5Gw2CkG3zONxq8Bm4Q3OJic6Oh+wPYmAo8mBoc/oS6UT26/nShstHgtWjD0iNM3TL5Jrhmw5fPGT5k1//1/cObxxcfNijzIpjbjYYAxAZ4KmSM+8aN0qgMQBHgbTiCopECWVACiMi6ZAE080EYctdobjSIg0Yja1jYRiaEbKPBG0a1Fj7G/YYntOT+KJxRe2ANnlBP94BF1ZvD+AZD/u4hdYMje5e0GrQpgY27UmP4BoLAkXQI35DWd3tHypWDww2Gd1TOaaQPHpzoZtaTDr0NgkuIQ1wyVqoXWZERRMPtd642G9SlBoFB7vC60VD6260n8+4GYRg2pB5qKMJH4II0yA2+/0ieahD1aAh5vGHMSIPAjdTz0kGE06SGwts39MFCwhx8gSYYH6rvuQODpKfs5RRjqjlN2GgwXI8Y9wZ4uXWDGWby8MhcJG0ghxniMlC73EvhoCHwB5c78KDpHm4z3E0dpBg+4TzT88/r1MVtQ/GNzOXDBnPA/9gQLm+J23Ku3zlO2SC4meSv9O+/jPtwRBxUUdxDxp+ytxtayMjPhtiIX4dhLv78et0Erhfj/ZsXxNzNK8f7zSvTmiG/5J/XIf8OJh9/cp5vvJ+njfvmAILefCXJ23wlcW3mNOfmANawgHJzgPn5GHHPg+yJzT+InDZznmMz53q9Zj7YHDRX37wCk/oKarT5gnNTNd/MsS6bf4jO/6+axs3fuAZ5eqLN15C3G+89ZI37JrW5pvNy8+n7pjHxTfq7n/M09Xk2m7qQp+JvZtfdVPab2lczsV83B00D4Jp+IN30BNb37z42PUDYxL7zAnaT+azJz7eZ+PMRamY+GmJMYa+pYE/Y0yaD902ghpvcPE0wdirmpnww3STwu4kQXFPvaYkckYPypgFvmwpXeB3UlXU3DYdjLX+byuFNyummARMqtzQVHjUeolx8bVKjGSi+TZofNhmdoHL587nmL07fZHrTagA2NS5s0n3o4oqKYbMp58/VP/h5q7FqBuTAqB1cL27maADhvDR1TjNpfBPXWyT/m9TFUJP3O6hvkbQJNckbTZ13vPTXcjnWxH2VyX9KOtIE/VF2nYc33937JkesXBKbDvE1ZVOcJFPKqLHNeCOQPmDCte82BeNO7WuTaQQOCJR4kYVs0nNtNtMCJMYsHLq0OFhjQJnqptxYCGgtBldc9yaLrc0m34SUsdhUDPSmQkIaNjYJ7G8QBkM0Ss1srtzDs9h3jGnSDLbpnSbQXxQWm5gh+vn5jVOjplBjl3OaWL7FA0xTz6m0n0y8TZybUA4kzRvKlU09JqpnJZyIOGrKvKodKFwsuTjbNPI/OT9yCFH4I2mSyL03sb7bEA4VYs8571CHnE2EN933mPlVE9uU97XJ9RrH28TclK5sOpdFG4yhQnmT5YumfljdlDiiSfsRrfZIn3NY5i6PyJ5s8l6AqhXqgSi8bwDeizzoNj05s6lr4QZYc1KnBG4C/8XEk3F/nGQrscD3n3+OJtEwTWJwn3PPCg255Xy+1aTFX1p/iyJJ6vnEd1tSjE2adJ9j3WoK6zWUHDQZQXM+32qCotgUYmZi2ELjFeoEvZfI85Yy/6YiED9j57DSALDZADDSxPLB5sStnSIMW4l6bzm12aL2COKI7CufnHDzIJhrEjEJed9qMP0KCGSmNlQeGS6A+Ibggi1N6LX8Nvn9bTF8uNVUeKqp9IMWD2C62T6nMGLhDQt3NgkNUPa01bRx1iaR+62mo5dIPZr2Q9uWhJ+GvN+tZhb/ydxtub2I6ubN02goGmXNi4CzLZRfUJ/SMMQBxLnlxhmin02btsLPWA7W1B65XiMwu6XgYMugr5uMjm4p/LSlaaWQ4y1fHnUwu4XW0PHiBIc+GvfmPw9UU28Rzb7ZJAiLeAb6/en0sOUYOXdONg4hZmszU4S25SbdIelNh6zJ75U1uKaiTMVWkzGmjay52xTqxplKblCiQInVloFIqRprhoGLzRWcLaIuIiYbcsNuNeVakqQNYlUyPMgQ33+6nc7Umagj9ftWg8/XVkPBGrVft1cEo8txy5ZA8pQ4uD0p5pPo5U0En8Qcm0rcbkyQUDd0ftxyhJTDL8uXYP63CBHfUvp7izHNYp0FflN1SqsHwRHuAWxLylND2SPF49zBpkGvy3EgqxuCnqhGXuAuUccTxt3lpi0gDq2v3UP8FoA3dd4mfuAh4+B4WOg97hJGy6/rKTiN2gL0ltXWBnFZi2oY9R0xL5U/990NQmfYnDRoXuQ0eatB60BUT+kcXrcSe5L0RcLbFnG5vPXduG8ljPtwxB+ayITMuZlDXMMxmPr/qfEPMTUcw4Hx9eZvxg+byGH0BWKKyW/Ifix128xJy/+X9X/zN507Yn2Gxn1o3IbDe7T+fDO7+ZsS32vEwXD872rAn9AbsbVs+5UYrc1IB7GXuoT7X+2nXLH2ujldNu7fN7vdEr5LbrDlfO78zCVxW0n2tpDA799tG+YzF67F7/u52TJrt5hYWrZ1EABuN+n9bxtzsa3Mzz7f0p/VYt10c9PSGyi43i0+X9st+VkXf9q8PvXYaun5ROu9zfSJGzP5vRIH+jmZt1Z67S00Ty1bzbeFWmwDa6WebdF7227ZYtlS6oV+n5mzpeSnZROzbY2nWgK3PcfScnJN6IXY5y1b/2wbOXWb2Oe2hLUWMEcSEy0MH16c1nJq09J52YTfVnY/HE/4GKntQOO1jXqISKZsO+9DSSvNNZyvMHEC1/stXEe2KawpegJrRcvDQLds+qN6m5asC9tNmx5TPMlpx5ZSK/e97Wfjvv1k3LcZod9uZcn15/cNZtMthRhav8R72yVbh4BUQ+gIw3aL2aybDKIxNjXwJo278zxF0NvOelScbiNIgNkkCJQzJhS4t10z0mLeVYiEfUYzsUR+Npu8Odpk8Cc2KWh6t4W6SKYv82yLMAstOrfbglHYFvK+LRCY+9x2i+jJFr1XrhdSz7eyRojby6Z0eHjeQ8NP7LZB0mY5QcO8mweuhlT/uflCDF6Lj0c6ZHD4lHJDrisd+qU9EqY8w1/J76ncNNPfS32rHpqY2iOXMlQva/ne4nhciIHrPenyaRvhvhYd/xanES0BP63sjea2sBa5P+Wgu83EvCnoHoXVzRbPx1xPcniXDnnbrTDjvu1h+raFPCEGdps7DDt50Dh9u8n0dJPXOOmw6F4ubBF8gBzUEB7jLtsk7ud6b1vxL9vORVSGR4g8bTL8zepDFgs/jHvmgZahIaj3WobRVN5t8hvQkuw1BMGC8iK93wTWbIHzo/E3ldxoedPeaYH7tazTjPB+y4CLpkdekTwheWhiffGvwLUEsZLiRHqiqRjJVgCuW8Z6Nz14IQSvWp/49I+29+efGyBfofhD94D2A8eDHC9anrH2i08ekLy2lLiahmHlk5ahbhbs+vBtyxMjCPcYjLUX1jUuR/vD7cmmhy+wcJCVR9C+tviV5z03AP1oeuBby2/T0y+2PPJp9U1WzDc9+Rvhp18/Pxr3R/eefPCTxcwknzd+JwX5yWowAhLzyfp90yDKIWCMeQBBCI3bvxH4nywxSblDGyfE0BG1FvEMrP/JGk+TiQHM+6eWh0ho2CfI6BO3f+f3Ty3QwBLxfQrBd0gv+JhelNCVuJL99YniX4uZpmpFYTcPkdEOWi3bYZLToU/IwU6J/VMAX3/yOQhpvKrM9Sn0UkPCnm9fWQ4rvodF5KKwFaYRnyJpSBKXn8CLjE9C3J+0g3JLx77J2zz9Cwoo3xaMtHLgfoVPPrXsB2nI96IHwlC90nL43bh/ejLuSdH45JgI6ndpcGaI+55L4ifFYH0yPoPsZVvZ+zawv09CHJ+YXFveR77T9rttzMO28DkS/7Yhj9Zacrj55LnvTwo2tXk5bH8CD4qfDJhH+9HSq2hvI3v8ZMQ4imtr3S252QZ6DOGgbYAvtj341PLOJyN+t5XfufnRPvKJb9sT22h/fgrM7ydAv3z7Zxvsw20P7H/y0Nttz3p/8tQ6Xzxb9d16wWfV6G3w/W2jn9j26O9tTzwj+0FrZtULi+9AfEmorvriL3Q8rfvDuJuIsJ0YIBn4kqG7xs/v24NP2CdPYxAjj9Qz24GA2vYUxG3rHj1iQIgxLwxst/i6bIeu33bIo+1/QIuSg/bLkI8v+bn9P9DY2/mQ+fYAuMrncBAkTm3lwqQ9+Bxte+gRjIc2xmcaprZD8dSOq2/bsXSyHV5jCJdtYnDrt8H5fPUpkP+2I10yhK63HTindrlpxnrb/wI29NA3KN4G1s4a9+TYkRInNQbx+w7XZFZD2/41345CCDtCw+4AhLIjgGfH8nlLIZS2kpu2EFub3/NOy3N/yTw7seyEikdbqTGHFRQ/IfG1aXzscHlvC1hrK33QNhzuDPvYcUYGH4l4d5A8tnXDImFqp40dUqV13Tl22n613SHqqeFtx6m5Gf9CL++0HKy10/ym9cVOS8CnGz/Ap1x8LPalob1rqb+hv5/3+yzObj9kcN828gPRAzttD75qM5rUAj6ncA3EvaP8zuazreyjzXPADqinJv+g9PFO21ML2jjHQgeGFug/2gZd5vqbyMVOW9cjVrtauHbtCP2xI3mztoAzTmcpfWvLOdlhPkvGu9MCfQfgA3YM+eVi4vb3lLeEcW8Tm22zL8pgbMvmQSQAhohIAm4T4KTilwDoCDpb9LbeMGqjcI0mmETONLKxtoniWw41ConsEIeDnZZBkJI1a2Pmj9xP21bz53/3ix6CdhgDuZPAzE5LJjMSN0S8O4wY7zCmwO2DzGeC6aQwu0OZuDZzKGzjhyeOjHdaAtm5mCbysNPWRX6npazbZnqO6R+YGyiTQRzYd9q0CO1wYtU2CBLDISQfawexdjYnn5j67RAaQK2brCnXszstvwuI5/m22/RhbYerj8Afrg7uOCZxpx3v0G06kDq6uyPN51x47RhM4Q5jNKGLH+HSYKdliyPTO22+/tYcwpeGQl/ttPleJfu1DWhzm7mMc3RI5Ip2Nu9ivtq8p/skmXfqog+53BFys9PmsbSj9VKbz6F7eBe9kqKbO9w8jHHnOGOHOXTtZD3Iw5vHhx4oM5z5vR32fYbkLXO5z7aE9aTvqfW5zywxofEpBxA21ha4bjsgZjRfITlpRcyjde8tQ40D4nRNn2l/KCZQzLQ862+s1aeQelow4tOXFp5CeCUUay3P/rPgtWXMrYZFX75uReCSFpPPEH5pRcQPx++oLvlytcZnvnzbAtZtK9hoKXG2AR1E8W/klcxlgMtfLc/8I1zaItZtGbkv1De0PPVY44mWIX8xODWGNhjqxcbaiugdcT57NO7tJ+Pe/k1G65XPZxX0l47pJfb9Bw9UBHZ9DLNHDnd9v8+5XruDJOdYGH38frcF7MdwuNz9Hfqz9cL9/7vwx4Dj3LUe4AYVP2rkhH4aJH4+vaRWAEZ6N3b9Yplcz/l2ffWq9Xq8527ys2Y67t1Qfm8xa2WMu7OQRex3ld9jmAskvhjr7kaMdzdQlKV95r0/rq47Oex7N6f8aevlhVNrnnaFz31M967n/kPzsUvMvZuzWdk1EGWseELn31XmiIm5XSVnu8B+dmMIEYh9at1dD9HfBTAj7XM3cv/vRsD4TmC/+uBukIdKlPd2gfruemrBbjvO4TrEP+3k5GN2I/q2WB5k18hjvgeB3Zx8y64Rm5b1JP7dTRp3hKhDCPfnuOVBswsmxvIdOectbzZSz976i5c1xl3Dc6nPbnnxef5ux0iKuwYSsNRy14AZJBY1b7e/8MaueavXwooxq0hZRmaOW2fu2/B1UQOlPY/UdtcjV0htdo1mcNfjcCcdVnaBvO949I2W9x2C39hYbv3iRPt6JwTXhuch3rzN7lfc8y2tWbtGQ7QDCrzlwsSSnx3gYLILHGR817M+E6IT0P5v9fd2FQ7QLiksB+JdQ/4tGoXmmu3jWydXt/aDsPVQuut5MLH4Us4zxcQiqis+evVUi4c33937bqCZYMct89mt8kzIerdADL6xx5znNod5bpU83wbMN8icheT4dsBr3cbPx+dB9l8e2PbF/u0L9qmULy6Htzn2dZ58dPsC66Kc/Vr459bQR7evkBO59W9z5rjbHLXwNpJecjEPwivE2Osg+uIW1I3bHPTl9hX2hKU2t7n7l4c3nx/d++NIm4XvvxPjOajPt9lnnw3H58Tin4F5Umvf/vg3b58dgfn5TPKzdnq+z4mEUe/v3jJzttPz7RKffSb2k4wj9Z2Tg0y+2un1fw7nuc8Mobj73r1l5nCFxc2ju3b7R+7dfWf23GZiIupOgTi151YiD7cM9trMnG6ub4l9tdK4zuyjxRgaqpZEzVM4SeaBWus2W+MMDpyfdxlsuOvuttN5dHHlYoTaj8sBbhzswULoSQojn29pnH4m6v65zdfPnYfklefRcvBxmz0cZWK+lTHxmTBumbq5OWwx/crwIslVidrvtmgjTsWYwRWBbw6fu078ZL/d8gdPt78pbv58i+GcEj2q3tR8VJ/uUrjkLj0oLaG4msFhhgsZA8H1aoYnGF4mtY0wFdRedhmOYDVL2k+b9gkZ3qTmbvM+QzuIsj6D0Qmyvm5dk1wrxcBptZSjW4ZXQaPH1ZHs4basBWQ8hF/7LPUUwe27SN+0GT65dfzCLaEFDA99FvzMZ+aAyvYf4++SusKum4hf9E5txhen108bd2mDqQAMz+/eAnMOcHAiJR0qco0JyCNJoK8gh1wsO1TDtuXDnCU/oXmw5nJXe7/N11ESD6Q/dj3w8pkhH1N/tPmDAGVyo/ZL28BH4P5csbDMH6uP4fc54m/b6ubibCen/mDjAGsWq5998CWa7IgxWvcTqx5euWsrh+pB9MOANWsX4GqTFisG0KIBlP/ijHvuvQP6O+6CdLf9uvzg54jaxeHHJ+/U5XHi3YRx99ncb2rcTfG1fw/ieek8IqDczVNsXvDw50tsoXnOva5t/bkMEbcHT6JwLpPGXRhf/kAhsfZMSI/tDuidWO/vvjKe2X0l2Nt9hfqdZ153Y/dGG9PvGNjdfSH+gntHwdOXPxRju4H9x6whG/cvxuR+CRRDab0viWF5/0snOwfy/hcjmHye5+b4Epi3kPElcL4vOcT6xRDrF2s9O3i+zf3Q4esckhtf7Hwh9h6CDTQO6x5C8x6Kzy9GXvDZyxdi+PbSF2tPdIz17PjnP6R2CH6/DEr8O3R9n83IF6YeCKf41Dm2foXqdma9Trx1v4B998Wjn5H9fHkBzbPg4YtP/J34fu5LZKx9CfSOXwRdjMXj7GcdDF9fAOx/zvL3k3HvpAmdI0XRcHScYDpZE+MKBpvcDvEdNX/H2Vwn/fO/v3ccAHSYpCqxaaAg3+nQYs3lLxmvBDgOgLtMnl0RtgKayxGbj46cB4tAIsBPrUtg+Iuwd/Iz5zvNKP3EXTsRf4fJZQfYW4dYu0N//nOdTnb/VC9KBv/7u7sdRjip+TtEHol9JzH5mZiHjFfp0c9PsZL7ceKiPkf6HyFSpC8tXEHO0RHW0GrbIfqjI89J9llHf049VDB15w68X5A8M3E9f74rHKBZXqF4hMHrv8a9o2hGR79QEC8WQC7hDmUul2k6qhqLjvNeR9dwif/MutTJ6h7SmxxXobqumUQIV54XGkiMqdp3eG3zPgh3lAuIDuMTOoqZ7tAHCa1GVv6V5v3M6a7kATuyf4AOhh2e+4R1H958/88XQIRho6NsRpy3I/zOxajNj8SD7K+j7A/5HMlPB5zXOp7naIPzdjzqj8TfMc7fAffWUWpkxW37aXQUPHaMuLPsX5s79GDicYiB1rf0gWVNa5wWfuko794qtUQwlUe/3Ro4MoSfbwN48dZjPq2/tfU7BOZC8tAx8KaEeYtexNYp3/p0AFxLHNwx9kbH2J/a/jtGHe0E/N7x5KdbDzx0BB7y9Su3wFqW/rsF+7nj6Qk6IOdZPQPKD9bnfHxuFs+Pxv32ybj7JkbYyPcTwp4FkFaCuA1IbAeIAyEYi5nSCtc2Ckzi873nXMcSXEBs9jqGAwDx3F4ssr4FCcBC1m2jEN8axezWKKydQGPocUDcCzFYt4qJMuIvhW9f4ewYydy3h4jP924xk7/na7ZR7ibm2fO5ZLFwVCeCcb/1MA6oqbEcOqw93HF4sqPPv+dzCLUeciwHYg0zHaMZ8zH+HSOPdQwc7MPLyF5uIx8YfA9vkXzUnk8/dox45XrBcMGx56NT4GXBXifhaTs2H7h364FJ+ruHN4+TPezdZslljyIcV1yABpHm3QPe3TM24p6SoD1D0vaE993YtPztOSMz361e2D2lYch43eZj4qAIZ0+oyZ6wR6RWpjmejRtl/DsetVZqZOmDzPdM8+0peOJyS2Lsln/3C/CZWM/bdL73wLyqMRuwoz2DzG/6/laoZyd9+bDXwTnii4HrLDziw5F7Rnwn+WgP0QOFK9E973kasT1gj3tgb2SeZ4z4nlAT958l7SnDykka3pDaI5zgE9ee1ZQw66LcuGf0F3uADsK+A4jLynd7Hjqi+QBNg/ZcLiQwv2fgpS8RcopwV8b/Obxl9ZR7Rk3OXM6AeNoD9i7g+9G4P/5nzwjsPUGc8hyWxtkDn9kzzmkh373Ev1unnv3sMZ9EEnseANyLsHeJdD8bSBidP/Q5n/eQ/vjcoQ3vXmCdUbLfC8Svj7nYi7C/2PmJ9T3KdT6HDfRQbz0IWQ9VvnUyHQZ96nJrF9s90FCa+/+WjgfhQdS470Uw9xY+/xLQz4Pszy8RcvbZqIUo738ZkO+Jza9wr95mL9ksF0x7HfyS6ouRV9n5bvED/EvU5Usc/P8y7tT4Sn1+R/x+Z9jQnTEBdy/fGEHx3uW4j7sX3Ndrjzd2/WLV0/DeV+p3S7+9ZM1ee5/fCRz3u2H17jfpm7uIsd69bu74Ghq7oce/+uT6zqjzwDNf73LETaTafx0k9u6MdZPevxvwHgeVB4TX7iLFkDNnfB3QOqpxT4Lg+/9+vRXARJDF18Rwk5f5jnue+D63pAME99Uhqq9SA97FaaavUn7v/PPzlTOHgsnhBjkHZY7u/Pb/c68CfuB5EHIk4vy31sl6cKSg9YiUy6dnuL09x0DujfruDsvTVyE/X5HcEXhE8EYa6Tum3zjekHLiCOXXZN+i+LkTeuSOFwnT/ILZ+grWTMz/nW6KEK7+rgFf78IOZhJ3pPDGmVICF3tUna2m5i5hqO7SdaRMxVdHH1mcu3i+s+Ptq2LMKW70NmEhRvkO7HuCMznsar36FYzxq3QhYsn3HdCHnpr/FTCyX33m4eK/M851R/DtncCDvusABvwrp293tC6GGuuv3HwOfhG8st/dQTV4ePP4wUPSgLqkmSTPr4wA7t1ln6fmENdh1iU/d0leWrMDxkK902HEnvhsryM811H22wFz0wFjJgCmziUYAfGZO0Ns2h65+O7AOCx7RLDaMQ6tFij+7tK95Qo0iR+GMNi1BDy6xlOMvwP0CydoBKGKNfThF3QPXH8zOWbzS8yb2htB/EjsrkET64nUwzdvHQVPHQUXTN+TQkvEtqft7444dAD9ouJJ6CN2LYQjOx58hayB8L+SR6iXUf3uYBjZ6zD6jnKshZsB7d/rMP3myeNqrFId74zvWnjU2hNKvd36pfZv3buUzzuPfXcALuwYsdIB8nlnxOJd1lc+7Zkw7kKifL77vuj+08L7PualYyBSK/ka55HiT4r4vk/8d4op6xhz4XtQIW7X4EOXpYbC/CJObgPJqxOABdS8dwLWtPSWcgjauwtcN8LBY/8OqA+31w520DAdKu7icQR6YbEn1GLPydX+Xc581zHMHatfACztReRw0rgjlwaeeRQPnb69Y8U3YrxDDyoJLfeZ45kL9u8MBxzkMkg7tN4ac9AZsO/w4bbY++n8E3bZSVysevEMuPc9wHeaL5w8a7ef7Is8vemv8Wjc79LGnRKPfaQhle/cefcNzb5v+F2LyySOhvf2nb3Gmn8fzK/PuvuBdbeu8Zr26/vMfsB8+xHzFHPPIevtM++jfboP5Mm35vue+5Ti5/bnW3903zFxvR9PQEw5tGDIsvZ+aM48L2u+GvGN4Gc/cn0s+NgP6PlQvduP0LdfjV4gts7tgzwYm7O/GnttH9D7QeuO1RfsA3waC7tonqC5GJO/b5v34c1+wrjvg4LmY6z3AZFChHLfSILIfNz+9w2AssyNrG15xwLafSDfWi5CsGDFCVpTlJh8DqH7RnLbB5vcgqevRix+DcSwtp99Q/73AR7YN/SuxSD65HjfUIeQS4Z9ILdivN04PRBiTn15VdxbF8OT1ZiIeOngHGPdu6Yv+57m6iugVUjP+PBMiCnfB7TIZ27UuPtwooVD9iP5HnRPmm9hY+7i/QwZ766tZ74a9d8XrzGNu0WfWTx0gvHxaNy7/zzsdwFj3AW+7wLP+cyNPIvuoZtDTOgcMebMY66XGt1XsF7XEx+h++q+QO5eIt9557T7QrmUMBSarxhcHLuGdwPkw0HyZDdC7F3jnrp/AL93/2C96YL1t+h7d0B4d+fs5qBX3YD+7r4ivX+tvSDpZvfZuD/+5/sHBzGTkvjuIDFgIegymzAYgQPnmQNijweGhB10bc1wIAHZU0wOiGcOuKZyv++agKGuf6DFx9QhFV/Xk9i6WYxRz7l7T8by/eeDLlBDgIS5fR8oODhQ6nsQo/G1XpJwdSfnmN1fYq3n7w+6cq8ddDFROLgT9qZh7I7nBGl9spZOng66GC6Quh0APXDA7Pegy/QBhSutB7Q8dm3vHHQNGI0gfKm6Kf1xYDhoutxx0JW5yq3JQTeC2RJwc6AYLZj3uphGHQBzvgqTxnDegYbBLoiPrt8Fxk+cdv+JcgF40AW5gKunzwFEyqEQD9RDUh6p3HQiXwx0FYyF+DohxoxH6TLG/YAwuAddWpQyYqUY7INEgx90BRBRzdUl4hAMdgq4d1mBJQndmTcl6u67XeH5rgNUpcBSfjUQHEjkxIjkAWNEDjiTz5DbASPEybkPFAPGiiq1n8dmPOhk83jAGc6ufACixI3FxR0j7l1ivW76z1sHBHkdcE0p5buLHTYy8Tl10cTggIhZwtQBg0sXTwddOQckLgnCZ3uFWIfiKHedAwKzGaPb+fVPUyguSM4lxcbla/9O4COXBx2xT+LyALgFPOgS86EHui5zeO/qHHXACK7Wvwd3DHY5bGg9x11wcDgg1mZ7mLrcMN7UHqCHKe2wzV2eURdaXR1/B9TFB4FJkmspP8Dk+4AzMO5zUk21PHbp2A66fNzsfMjliDt/FzuYiwdP8LBN1Y3kSs63CDxwIPiXTP46wiUP4MsOhAumg+f5O6LZpf0O4wPYiw7Ftx6A8yAXzwd8nX78Uxmyibq0Uc0IbZd/ljIO5LNEIqVYqHc1UuXm4PZIAfOg6zEPZSYU8lHJzJ2DMkpcY3QV4+LGLpCYOIj4DyQivlNylzTujAk/oIwnZwYYk0vWnjlksXUn6puZP/n5nSBOd3yuOGzuI7XoErdODBlLOKf+90DIAZe3gzsh79x+Oa6i3lO4hMo79ZcPdh7EpEi8JNX2julPYU/kgf0OywXVD9TtMXf4F+e/w2rE9eT+Hca37Od3Nt5CesE1//vMYfTgjs/rvoQrSrzd29U7HLMSJva1vgC+l/RPzbe1b6k9MfPvE5cJBwr/U8ad1Upg39LFBavtlJ+SePKO6DfmAkWM/w7sGYYXOK7K/IWoyxt3jaNTP3cYv+oYd1QLuYuOgztZm/a5Pd7RF32aZhI5e3hz+GjcD5lCHBrM6kFOcxwm5jjMeb1DY0yHOe/dN08x6nUYcc5c9nSHk3porWPOQe3p8BXk1sIBh5ExF7uHD5m8a/s/9MjToTFng+7nAyNPHUaM8TBibQ9fiR7l3ZMWnA1KNw5/wxwfDuC9wwHFezigXBwKPH8wHK+JJ34Z98Ne4sue09Q9uqD7Pdrg/fys50e4h4xJ1szFPvE8N1dyT4c9eZ1DJSZqfc38Zj7rKfEqnydryL7Tw2M6VMT3EMjLQaAQaTU/vHsaXVv9LLii6vQ8tDxqeERNJGKykTolsS/uu4fVV9xTT9/vodFEoyb7UDvw9/R3DpTPDnr+fJHp+x52MXCI7L/Hc9rzZyjHHgL5OTA873swsF4iHAJ1CLmQsRyGDyMY98OczfkhgAPLYfnQ59DWy2KUzEXPFs9BAO++5EGNrUeP5jEfvFN+T9Ocw8A+ORTiRnk/ZmyHKOf0wj2Ll8ehY0sY9+em6Dmk33O+40RBmoMx8ylx7wnra+v2ZFPBiliPiaknG95MTtD1teeQ3HLgRefuCbXoATnjno8xesBnlly6NfKJX6t91xOTSN/Ezm830v57gfvpYZyQ+4jJJzHWpfDa85izFxB3D8BLKN/GzLfUjwjetNz1ItXVh2N8+BHJey+Av11s3gVi0hcfPc98aLrgy5e9AJ7pBfZbSI8r+1IvbbQ89sKwnvI3PjWwxufDn6GcYc8RY9ytQm0xRHe/njvSTHrPQKrIgaGXPSwcoYSGGrieB4EphToSAHhgaRDNuANAO0o8f9TNiSRjEHM3krFOPHfUi3CIi0kAvQCS8MjjkXLgPUD6tYeZwyOE1HrGnuoZn/UVCN9LjRCj1VPMf88DT2gcPY9Y0Pw/6wQaby/n/jJw5hGKPWttLBzT88AGcAA6Qi5CekpeJK6V8qfEeoTUpReQf7Rfu8aL0F5OFwU+fq7H3GT3DPzSY3rB9yIi4IB/1CP0JdbFVi/gAOGnSY/Gvffrn8o8j6RoHikLut8fJf73KNlExPupZ5y5johkZ57hjD4Tx1EPe45K5FEipiPGUHPzH7nzuN8zxHokzEvOD9boEJiXI7UjJqfcvo6Emrv5PurJeTqk8sa8Tx0ujpKC4GKdM6bCntw+0fIs5UuqbxJ/kFGhBLDH5/+IW7Mr14DFY08QJgsGlZ7lhPzIIeijrsAfCZwcdQkccf0K7CEzn8B3It9yB5petidJvIKG+qjn/JMFcN9HwL64PWp9TunCofJ+5nLB5W6hb0g+ZWpyRPGsoxUZ06DlhHhfu/xI8pqGzyNGm4+ofnD6S+NjrgcgnezS3oPTGumwf2Tkk0PNh1AXGNxBQeJBSf8Z3VHj6gm8Jh0kuw7HE/EdCXyr6VcK/90sV7H4UPQKPUC4Po7jDeu8h4rfOUT1XTH+Sg8/GXdB0DmBP8p7dHnzPbA4HDKk4kMOBtTzPvEfSoeR578gAEb5CDCaoXGqAgGICktawHqkgHWxOqgHsci9cmicQxNzEbegcT9SyCjmfM+fHQA1ObTEpZgaqqcls47W90DAmw9uDpz4jnz6QRDPjHEHOSFmP1h7TuWpLhgH0y8pPuVw55hFS4/DXNuV1+d43lcfDwN54RC9GDDWN5RnDxGNVnwAdTg8MuwHMoBdf79iuag76vnrxBGIW9QzmbSyi3tC6oCC7u8wssdE/c4hwL//Gvfjx/8cDcKID8dwDMdwDMdwDMdwJEd/uK/h+B+rV9haP4z7ccTFjiMGeBw5WcfA98c5rPsqgNQPn/sYyWf/dZHW8e9MDP1892PCej/w/d+g3sd592Sfeb+fL3Z968S9d2zNTT//mh9HqNlx7D5+YQ48HmCc39c67v8GPNCnnzm2aFjf2OuxubPP+CxjvMcvqG/HOXP9sY8f6r8AN/nlj7hx76c3fiwY2p+f99OAOjYGfkyt80QEx+46TuMlCeOYKEBy/ef3qYY95uJw9iWZ12Mnf9Kcx0qRuQMQlW9kPTHXBGjUufrM/H2i7kDO2Rj6wsHKnZci5b58IDsWDm0pLBL4ZPHdl38+loS1L+f4WMnfMSNCx0aMU1hk89EHBaZPi85xn+7Tn+sAYsvFovXBkcRXfXq/Et6PJY7rO//bo/nMxcgx15d9eV8cfo60XujLtdUMWoYn+nyfsDXsZ/n6mJufwCbHIZn9KX1F1Sm1Rp/RgD52EcTWoc/X6hjV0r6OwyOBY1Ud7/M51XhBjauf1vJjt54MP6g16vMY5vosFe/TP7s47st5Ou7LWs71bvIQdCzwucX8Uj7q2GDuub5VPUGf1lKyx4R9Hff59yAe6jN6389i76hnW0fU1T7vC0Xs9QWN/jF+3bgfE+bwuC+YahcI/dTEtMj0+UL9fKYrrN8nEu7Ozxh3qhGOmSZJCWyfOEQIcXHil1qj75BP8rsuQUaS+eoLtaIEqu9h7vuKSaT2wdWlrwBdMDKZ/Tq3PJka95kDIEHgx8StEZm3PtP0VBx9oo59BpN95fseiIE+vcfjPkYwmZpRGGD6QbqFE81kPyt07n5cI50R5r6eL0sfHbn9b+i7zC1OlzHuFN76PJ9mDEOfvrwQ95cUiq6MRxJPXRoj5GWK239dQ//2hdEVxFyo1RHVy32mvxnNOdL4uy+bE0qgOdN33FP0gtKVnlKfvtLLvawWUYdrVT/7WQN+3KP7l+MxUi+SOHZyLvZ5P8sVR1x8jCY99wyFY4mHSD7qK7rb5/VMu9g6Eg4AmbWJw1GmT7pOziluZg4skD/pM32jeRrusNinD2tHgG4eSf2k+Yo+fcnMXf5RuCXX7Wa+fzTuj/8RSfJpnADPWJ6POd8J81lyHHuOk96PwZkjKSbvdRPFPdH237Pl7QRYUxXOkHwCe/XJoQ+eTiI85xtfKC6PI+flROgjn74+YXrxOCCfJ0KPm2qn4Bzds5avE4CfkhxzwpgvM4/1wmoIP/ck6oPAsRhbAG+F6MSJJ/eEcpdlvszPBM+r+CTyc+LOZ+yNkPyeROLpk4j1ZPPj4YVOAnBC+RW3TifMe3nqvuozCM6z+K1YPixPHxHKI4nnHt6cAMZ90JuhSAOd/0QRdomoyc96YSA4AY3HiZEMKJE+AXPBPkcQ+kmA4J0ABi659gkoQIgZPAk43J0Ya+RjsE4AcTzW6hVoTHzwcgLE5mOwfQ78J8w49ogxhuGy9nFm9NI/h+YH7UOUb04YwwzxlMV8RDisHHtwkpXrTgC8n/TDTa2JRwHj7po7K7dS84VorrVfT4zcgdbuxNO7nBgHwqVoT52ge+0peO3pWuR7YXIC6K9af8aXnBh45AS4WLLyzoknp1g8LxHbD+N+4gG+VzXuf/P4/+T93r/gXu6HmPmj8HQ/rGNw/l5JvmDTM6yvvT/uhxwysH3e/4/38rA/88vRPVtrx7jfe5itxM+nKNDvjYJ8/2Pu5PynApBPubiUWE/vE/PcO+8xMZ4aGurUI6fmot97EE+gIUrm+7SP7eMUxYuWp3sPYrsfMGne2/OoPofiRuvp+8ADzn1csaN6/JTqxXt87VNDDKf3OC+danm/d+az4Jbpl1OAa0+52AYlPPcDNEZJbbjHMHV6L/BPpNyEzn0a0GunEvYM81n16tQjd6c+Obu36dqpxp/3/jHDl0T3AdzaI+awxH1P8JVHT1vwdGrRz3tdA+Dc3Ye9p/rUe2Ot7zE/d2rDzsObxxceTjmhowguWcCeY3TvQSPiIfanXPMwgEqS86lkHN3479Mm/jQ5/71gtu5ps/T8/ql7MGDiff6TVeo94fR1Sog60iSUuJ8S35/2gQNUjzAr91nyPBUa292vZuxP3dowRHPaI2p0z2M0tf59Fien3DyJ9TJY6aX3J9ZOIedT1AxaiOceF7Rk3t16fv/9mMkjaYz7fB5d/knVxFnfFSQKP5l4hXW4C4ATYk6KD1K1vhdyf8/Pc9KX+5zlL6V/yD1JXHmfNboSj50oGnDqa8ruMUySFzC9NA6p/KXmuFcO1gL+T/oELom9uPhT+fxemPd5jz3ZrKb68Z45yNxn9fEUuNnn+DxzKUZh+z7b3yruNdN2L/gDpL5ufwHvkj7hnu/DU9S8c5ol5Z/TlnvClwjehtNB9SB0zxyQGV8l8fWpx8Uch6MTCV+Efp4y+gJdpPVl7SAvpji+SMf6aNz/+2jc77MknSFEohinnMHtM2aYSlCfv02TknrKCAsFtlPGcJ4KouUahFPpZosh41PCuGfI8z6bd9LIGp7n/opACpVCXO5tJ2mgmKY8FWpImbBTYX43B+w7hHni9n0qHBjY+KR+EIjwlCCB03v6czc/1GenHKkwvSyZ1RPl0MQZHKq3ud6Veons23usHid9hZ/6PBa57yi+kg4rp30d15a+VfdN4IPtmT7NqbBxuhd6hOgxlccYAcvoiWJgyTnuGZ7o88ad7N97QTPusXU4fuQORtxfLznOy3DLk3E34YmI9+ReNsqingkHqVPpr9YMpk/uFY0gDgScVrL57Su9LumD1KdSrpWDkeat2AsH3ujx+s1xvdbjkk+75y9+T5GaCvGd3PP4OkU4q4/p96mk2YqukH/tcS9W7pWY7nltPkka99c4vvm897ixb337O6pZ67/OHP0WY5i7P358y7GnfXkgCu76w9pF44D+kAuGY6hNL77f/oB7/w/I06saj579zbcn4/7NQOTfBijG3zzmpUZsgftmjIWaxxzff7H1/53zv/H3M4jcUM9I85qw+t/EGKCh+Qbk65tHvr6BOULzGzLHN3D+bx75QuP8lnPNLLhk5/tvlgN8+8NaVyR3MXiArQthGr55xm+tl6WfQvJq0ctvSv0R3H0D+fhbYD1Rvg7taZ+8+NYzFtd/i9CPpx57zsM7hXKLyIv/jbuPbxGwHdrn3zTOy6N+/326cf8GNOmzGWSb47//z76XNbSRJN36z3ezm301mMXsm4F5uEYgEAIhtCPmv/A6F7cBV2XFciIzS+D+eMg2SFWZsZw4cSKZoZ9LrdOsQ1qx/fPOKS/IKXv/VkS8eZ0Kfp0Sv3PPneoDhmqDlqdTZyF5BXKFNHzf58n4Ofa/CG5qIBHjckoPM+y5XL5OsSYm4uDUkOtTEG9gw32Nnye+/gaH4pez/rbwicWuUx2/bBxO7b6ExkhqYH8rzS5ajlw8nYJ7ngJ1wl0wnGYvGv724PMQXCb9ZeN7itXrXz90LkB49i+lPv724chTnN/dPKn915MLuPi7PJSx41Tnj2AdYumHpwwvnAr8f+rJ76fg0Ibw2GlkDYRi0rfOlX1ZoXxqqydTnn4YdOwpmIdTPI5/8fX0dONe+CXcfRvS31SzBhrDX0pD+StARLDiQRNTp7ak9UkC5JQX9X95ile1UBCAOCSp7uNRiC5YxeZ9GtYc/jrNmUBOjaT1/wxDnu/nTJFDdRNiw6mh6SXjcapgwWeASeIXHaYlrEuYNHBbn8KTqig6Jd47DeArzrZTEF8BgwoZg1PwQsQ66Go8eMrE99Q2aP8VUi8v/H8aMLjHHHB8L3ZOjTg8VYboU1mcZ/J2atMmPnrGEpO/IorVv9Czei3Kf3j0tZxx+5ek8yJiQ+ojCB/8FTIQ0L318VPf8437z5f6KCGd+Nn9/ufvfcTBfc47fcKE2ZcUwkwSXt53n+37kdibeL+PaFx9L3smfnaT0fcj+z31fJ/jU59jq+t76mdm/75T/Qz3eyoGfUS8+5I2/nDOIHxwv+PA2ZeYfPuIOLJ4IvbM4IXCo3OG79DVR8Q3he1T+nar75Qv5r4fRGwVf/p+MPXECQ8m/1KdqcOgG9NTOnd9P7L4IbFI5LrvVBfSYrySMRLw2XcK4IjBR5/7/g8Hz6eC0HdixtnQdwoM/BTfajzN1LPLL30SXhnuIH2meO2U5nYuX33U+pGtqT6FU13+TPkriM4+pq/9zdXAD7rnZfCrcFCmn/zg+2DfKcGlPn8tBuqBi1efMASRWKLq/oeMmT6iFqk+KPIcMGS48ewTLnr6HLv6QD5R9YPGv4oYpfjJtTf1L6Ft2L4h4LGPq2vCX07HZXrGD54TKC3H8TIZb003MHlw48tqv/+XvZz6+5TBstAzk3XSp/jcV3gW7n1CQfUJ5Er+nNjjL0LIUs2V20M9X9rHse/vH8Q7VJPnGgoBdqrBI7ZnGqTQlKRnkHP+9v2eK3hHRLy8/xeVb4cc+5RG/ZcimNkB6zRLWJmmTb0rDClcrP4GYvn3qSIeTwXRKwxo1hqVhiFxWPuBYxCNiYhbJh/kACD4aamJjID6Ifuh1SfyPfnc/2MuIgy1/reBE/oMPv7lXmL84PMtYfPvHzwu/zZwnqkfEPz/VwBf/q0NOz+wS6pMoxYupf7m+g8Rv74f2aVxTZ8gIqjhTL00+qH3cY3DJE5hbfkhXBQqZ0v82sdgmBw4qDwAeJVqiusB5DMU/qleptjHDsw//DmGi7vUIyk99zej18x2MMId5drUM//veXGaFNUSPwCd/bL+Ee5P/+kLIPyP9bE+1sf6WB/rYxkvmT7Wx/pYH8u6OOHeH7Bpf4Q9/tTVn1j/Vt9i46RX78XaT4pB7Nz3e+TkLXBh/a4/S0TBZ/a/AR5iY7i/Rznq5xtCz23qL/wZmM0DC73GbP8b9e7+HvBg3x+gO95Tz+uP2Lv6e8Sbb3VeqE6IrZP6fwr3n//pfybtFxLNHFpIJ1tMeCELjv5ngu53yKFfaWL/2FNI791vACRpbyFrT+qZgg6QfuB8d38i+K/PaEKQ+6zf9Yfbr2ADlBsvVKRKn/WD/qRwVGBsKQC5LqSfS9nH5LgfFIj9SrNL5iaDOw2fCpb7lHpka6PAx7m/YKhJpz7JfDo1RnGDZeDtF7ioj4gJywcFGd99YEPrF3LVL/FnQc5jn8KF5DkFHseIfRzfu/XTL/CnGL+C3/f9TA/oRziygA94/UDvEOu9wOeA4um+U5qnNW7uZ3qMxlNc/+sjcCjyl3ROwV9kSbjtE+xD8NDPDKRIP+qjek2B5jGJv/sUbST1yH6h/qlccRzRX8D6G9kHhD7ab+jvpL0CB0iXPP0F+3na5VDK9wKgu4T66RPqB8Fnn56n38JdTLwLnAItHF+TXFDeT55XUEBQ4M8Wg0K9V2DOL+jiyUIWlF8pMVmQ7dGaNZsLF0yFdONDSU4kEC0HBQUrAAn0JezOCK8CRnYINnxJCHpOwptEtgUFzwXZH0rI9ks5LWCkBPNCga4taujqA0QO1Tj7ueZSoMVsf8HINwxfqfxWAPPInEeJqz7hokHlioLc1FkecHkK4GEJE1Q++gpZ3HLnZYaIAlh/lPgoGGqrIPNWnzDkiP2OE89KfPu0GvNYfQR/UBdB/ZqtVrED1iVrH8hJonBH9ECBrjky56fYhQrc0wtGXikIuJMugwp6TvtPDTjzsVHqA5JusnAsNeAXhJoqGH3jhmtFB7g1Jemz/oxwNwjfAYCUuAQNSOAsYAKbBViBOEt6FwDkQAEQJ+7zxHMDru/cvj+UCdrZk3zmh9I8fIqReXYAbRxunIDnBk6zMRswnDMg4HgAECYD0pkaoYLCbUDLiUbIyDrF8UvmpwCKQeK7AddPAr8DCCkncjHg6eeAb9NDcQfYNIDgARwsBlDsGfiLy5G0Bgp8vQ0QWFD5naplh78HEE4HsD6Q2G+ggOd34JToLwXw4ojgngEh1wOnwHmnhlouKPY4uRtALt2AgXbAyluMfwManzvxHEDquoD1TI4HBsAaGgD5m+LEAY4TC9jFw0AB0xXseYA+HDjN9l+trgYs9as9b7kcLvD9V+0VaA84lbGP4sGpy8dPA2f/exwAHBqQAlf4TXzucwMFuoAGiCY8ICwugQOEOB44pZ8ZcJ5JPSv445L7gOAvRYYq8RV44SgKFc4eN8anxD6nfPxVUJ1m42GZeqk8pZpnwRHtgnDj7Kdwo2FTel/DIidW3EY4AOY+1dSJGFtrRWpy5FBVAEQwkbuBQlascXaxNSSdK3GGcx5b+8KzLIcATVrkg1PsYoLDJJlfDlcFWvRyueAuFQaAfEGcXJAH5gGhgYr168ZJyL/akwr8pQvb405lXLMDDrNXP4FNrgf3KxzjxoYSexymBoC+LooSSRgBgnWA6dWkANXwxVwGqVxJYYkT7EgtGgfhAUH4D5yCnCn0NvGCU8gtxAGnNIdmcgAOcmy+iRyx9aDEsJ+4JFTtlQYpYV8rhxJc9CTcz5+EuyKaP9bH+lgf62Phqx8YAD/Wx/pYb1OPH+vPyM9Hzoh19iLcz7JfDiq/k8+fvW6c/V74bgDZG7Dh5ZnBrKNcANjPBsHzpP0HC/6+oucORjiT9OfMw96zfAFrjY0ZK2eBe569E9/jEUT67LNwH97Cj15iVGo6/Yodg3nj6uztMCTm5SxHH84CMXMW74xBD35lcXFmfOfsjXHwlrwFCsBBzx4Yiw8H34AXB305WouPsSb6uffOgPPPesiDZ+9FuD/9hwLs4FlCbAMJfvl98Cwh4s/Swn0wkCQtwn2wkLZjUBtGnOcGmc9ZALn+JuPhxoFp2oNnAeTsOTyI4lXJ2eCZXvCDxAA3iOSDwRdHGINAPgcZnKj5LaRt1uIlnZfBwRnQcLl9z3jsZ+w7Uxr6GZ+vIFLjMJLkGWEPdbhy9hks0Pkg6/NMiBtT44PSpYVT50nbyPfPaJxrvDZQ4DGXung4w+sBHSjYfZ0cDJ7RnJ/h5TM6Z26u+s9+LYojrf5Q8XTtcOM54HAFKmCkHjlIXBRRzwwK30vcPCjg33Q5Q+XXuVCT+G5Q4X21ns7AQeYsfUGI9KcBhv9FUX3mz4EZfhDyOahxqIdOGuSwfoZxjGnAOKNxNuj0lkxfpHoTo5s43cXi6QzXL1LfEOtK6J2D1gGR8vv85X/j7jw0SAhPyslBijyJRsWtAaCwBwWhM3jGC81BonmSjY0jzgIt2Aa5WCl+U+dIZ1ONjyNLrjkOngJN4IwvWgoDg2d8zkjhdMY0AGLAGzyVBx+WyM4wvywrleMzPnbSUMLm6yyLT60BSj6ywzOB98EzncSlYXKQIdpB4NZmkKtDVxid8QNWRghT+D1jBm6u3s/0vA5weaR4ibo0OGPErMAV7IXEmSzcXV4aOBPElybwKBsl+86YOi8Qdpzp+Hn5/uVP6Rm8nmE1LMVx0NL3zphLKkDwccJ9EMAjl78BBu9JXLoYlepQ7QHKkDFA9K7BM733SzEeYETuoCRIzwTOlC5xLHqF4dhMTJk+wXLzmS0P2gAyEODrQIHmL/ISSuAC7mJVxTbBw5ka1i5dtfpX9JamEwY5zHODyRnQl7n/NcvLjfvQk3of5AiVCurTv0NnClEDgudfvThfC3Jc1ecQgXrmGWtEBAPY8DpPs78QIRc++Yrl61lE+/OqoxC8WOMTM79orqRGgcQ1JO6Fd4SnWBgqROL2QmSMa4LAipk8+Owt6zxvXkBjWvDofaF58MGLdb+Q5wSRzPKlj7/cv4V3gCuUp315teBpBxJnDi8WG4FB+admJ4X7kBL0IcOzsUgAOXNI+c7LZmVfac8h8F3NppDzLT5nznkBioc9UFwL9tz52DFExGIoAH9IfIfA/A/5fObUkU/scqlv1AaAB4Y862OI8QHKOWFXaj+j3UOgH0MR+CdG3r1qrxB4XuEXDwwVGJwr+UNwMeRwjRbXIaapDhn6UIzcDBF1ngcPD0bECsV7VPwRfhw6s8V/yMjTQ3lynEc9DxXyr+dQH4Z6fO4QeJFM9YDBQlyNOJRDLCCucAaCf4T74LNwHzIuTaRyz/vsN3SGEbhmLyqkQlboPpLYsPjt/hl/0GgvKkhjxksSOzFjnFrnfNx88sU1BeqsXNe5Xx0PetQXQkxDBjL0tXkI+B3NM2f/EED2Qz5cZciXNw+e//43Vm154eMcF3Co/9Y+E8p3kFgF8CrtPxCBVwcNfsc4xzcPFvus/Y/7fcAwXIde7sXo74hmsQynMfqJNQ8+8db8svg/dGa7fPPlw5ABVX3/5cY9RBwg5BqjCQxGEirRgIyeee4XB4uY94rrubMUOwZDcnCeFg0slhxbBnshbs/Z4oiP2fO4otvbx3O8tgZBP0Th82zD8HlaNA5SMT+3NQzo0uAcr7Uh4/tDOQ61qL2pWJyHYWvQUCdDEYZbkw3Ss+e2Gh8S+HDQMORbMdUrnLD8moM9VO2yWDwnMHBui9nguWL7Ob/voIdf7nmxh28yLuee+2jxj3khFOIvOGy5NTko5HoI5PkgnRmJvwcV+8Re9FO4PzXTx+GnD4YZQffy+bCzOFE2zBAi9T613z+/O/u9/D6MEHHi++GEWEj+/Lr3OQFE13/X/vO0Pa6/7nfDbgyT5xLCefg8HQtEeA0l4yMVF9DEXH81ICZjSOIIaJaZGFLfn9OF6uIpaVdqOTlBiSmZvyFlLypfw0Ziz9TJORGbc2bvRKzIej0n6ozAd6peJJy5sSSeH07adE4QrYbvc+IMZVF+ZbiBy5eQ/0xsXfydE3Fy7B8+z+Zt+FxpjOfZPYe4PJ3TwxKHPRdjw4S9Lp9lcORw27DwfNLfYWGYJ98/l59F6oqsJ2kvwkYqpi4fuFw/LAkOQ/1n8srkcUjoUZm6O+frgcPtsNC/XS0wfM7kgcImg1n3s2EOr1RdUjVzRvMSVy/DnJ4RMElxJhvncyZObi45/qB6pcbVTK8aZvxk9+J0wzmdo0wvPVc0wbneS5PcLGoeSf9R+zLD57DQk4fPiTwJPWiY6BfDZ3Qvf7bpt3AnhfY5T8gvk8EwJ3BdEXAmLGp/RnhJgigj1phFCfHhs2wzVBdBpsOMQB8+I2xw/SNIhCKhjM3MUIQ05CEqD0zOOFHM+S42+TOaiLkBQMoBJaQy8WeGL4pMh8/5/SicDnGxEZpRZhjg6oSwJSNKuRgx8Wbzd04/M8T5L+AXrcMhyU5m0GX3Qc47U/blaprz/4wfelS/lXgMKfhF/ZdqMDPASTiSPi8QFxUAtoal/nBON0FqP7epkhdEFD6BvjQoiUiJg85ocaLm5pwWMCS3MnwyJFzAkD0X4EtxQDtj6uxMrz227ri+yeVUsJfjjyEKS9yQwrw/RFwIQgMuZ5fUA5V9KFwMMrgd4uJGXQxwOuZM5tdhaTACuXIQ4fMzxXaOw87pYZPUUGcA7zIag7xIPsO1qnOR/SzckSJ9L0si93/zemt/Y52v7WM9563i8qfUy/k7ic175I8/pfY+lpyD94a1D6x8rA9NErc2es3B75vzfwv3kbNf6wOQ/4418l5tiF0QZ+8ojme9z9uI8t3IW+BFEe4jf2KDeoc1N5LTmSPvmT/eEQeMfPSZN+G12LaMvJH/Ix/C/d30epLzzt5nHY38FO4//zOSMJxaw8Tvw0UMeCMvzxWfl7OnBuyRok18wPYDpEydze09DD4nnT8CAArZYwSwST2/yMdeev/lHe6cEYE8kbiSthRxsSHGp6jjY0SLY5E+R8ImjIcikSOwBkaUGhhxcq69h8ZlGKg/DicjGnYSnILUywhYb8Mez4+ADYHiUAn3I6DwYPNUTGPbUmcv9exiGsn3sJF/RjQuMsQYiQvC0yMI3yVinPKniNfhiMBBI4a+AD1TxHrjiIfYtdQKgp0RD8EF/SzokBdOQfhyxDDsur1xWOGpYY++gfAzV1smP4xaiuNwtM9rOeXqcITRCimfizg+kfz4xM1y9nBKuBfTzo8UceIRgV2UQQ7vUdQLdEQ4lzzL9bHI7FdUxFdReZ94zsde1gdrPNFmhcTHjU2RWEKOoHgJwm1IiR1Kxty5w5SdRVkEDZ8b64eovWGmwbqEo54hPYPEX8FsJq5FzL8R45DBxrvIDIxFea/McFX0G04ovFieZ/NE5G2YEdDDWr6LBk6k+LGID4XshQ6CE6VpjRT14USMvwWnCO6KTK/k4m3hg6KhjlExVwSxIPgiDSzDTI1bBqmRIj3UQn2+yPACl7dze4yRQW+kaKs5394/YhCQLKcAGmKEwXlGADvciuhBLoeqTiwKeFZ4wqTbikIshXwMGXhA3dPtmcUX4V5kbtyLYHMhkvrZV0wAgIE+9y2MImDLuTEuWjyFOKrPCz58Pg/c51wRE8//06oUQBHSKhobFooLFB/nthx/tmJGi68FYz5YLioNxCBwR6xNrgjipwjE9SX2xWecnQP5tNSRj4grBvCEBf8++D1XsOvu79bvuV+MP2t2cvlDeLAIxL+o4J/4/rMP7osgp/nwEiqeiwH8h/Z1pI6tQ7c1v8KZn30uGX3ryadXF4U8FCPF08c/Ie6fLbguYvxuyrv10qHo0XdQvWjt9T4XXyH89uszWrh/TjZNAQifi3zgPxPvuft+RovZfT/x3WdjcX5+Pvezu9/5/+w3mEUlLkVGjEjPFQ3N/ZyP92eDsPxsJaxn4f6ZI1IfAkUbSDFABBRtz35WhpHPRRrDn4sMdhXRkPmew/h5JPKm/CGe/Vz0bB7n/FD32YC3z+egeFGaKpsvy2DCXFS87P25KA+Bn4sG8VS0iZ/PDiezuXSFO4FfFq9FQJyAIuGz1AOKoNiV6oOrR6I2IdGuXIqw+UViZXm2aHz33CAgzmlceZ13DsRf6ZeuWP98bhzEzoVYohczWuyLHuvccIlRdC4yfG0tghyLDo0Mjj9LvAdwNsuniDAv6nWf0ZG+f/Uy6ovPxjx95v1+/PT05WMySOgaCXx+xONMKpncXpTw+OyQeZ5LA5LVn16tkWLvYvRvWe8hXiPvyBbRjnNb7EZ6wE2x37fw02cmRiMR7Qipe19chdj/J3EQF5+RyDjKKx4jYP40O6zfj4DxTA2ShKgLXuf5xn/EF+PnWP2iusGnfkPey4tXe7GnJe8jPear5zP8hXvMNZpYeZEPKtxfbbkIs4krzhGwGD8Hng2vC3shjL4BPnrxjmXf0UACGe1xPPLCy1uQat52v3lzOX+b3FuF+6hi18ifOAhf2OI+4pkjn96Sq/C5iHDeBS5WR3yGtzyEe8484S2mDcId4QovAX6B79+zuF/Qdop7XeTHm6Gi3dOu38LdFaxkEC50Anr9/eJ3wDL7XaQDOprYm3v/xbaUwxe886NUsi6ePxdEeUq0u+cDxJvZ/yIdt1ScL9J+avaPAsPOKJMrN87uOdrwlLI18TN3DnfeZ2H/UQ9gjxbl8zN5uODzR+JFGOwQghkViGfUo7BHFcE0quAlSFBcYHmU/BtV9h0lMCxhc1TZc1Q650LeZ5Q5f5TAEhRPAOOc7y/NYVTggVEhF6nzkcZ2kbV7VOAeri5GHd4fVWpolONL6R0gHql3Of6/wHKYso/ojxo3jEo8JfA1d2kwynAx5wOXV7ZmLuieO3qh+Cb0W61HZOom0Xe0c7X6G73Q4zfK9dIL/VJvtKjzWaYeLuh6/SxpsQuZ9ygNQ+qNC17HcP1Z6oGjvsJc8M/VZSxvX9Calcsnp9PQvini+4I/b5Sr5wu6/p39Hj89/fLIJdk1atQi3KXivOAdYG0RGtwoQI5k45CENUisoxfZ4Lqx4852G4lGRKJNF8Rn53Q+JdHukq0qrqR8XdBx+izkd1RoUCQxXvAxGOUGoAshf0WBMISBioqZZssoOHh8BuqDrIsLprYChMQoWCeIrdDZFwInCE2U5Y8Lh3Cl4Vwh3M8CaXsJ9wuiRl+E+8WvpdYZEwOpVj9TFyIXCh8rtnCNTbsoyHDmBVZDHPdqQnL0AuddCTsZYXghxKCoc6Vag9xF1wXA8xfyUCxy1AUdbyuvJ+0evVC4xTlHFO5cTXM9WOk7ZE1d4FznXtB9FrRVKi9MP4H8F3AvcQxb31x+CN2j6TvWt4v0fhQ+WeF+QVwsFvFLH5Y/LrBaHFUukEYNuvIzMuS+CnfOYGkVPd7hmqXlGcs7RcVuidCLBh+louXOsOxxobxfVOJWBHLH/bXhwq9xi/5bfS8a8ZfYY+zCI38XBpslorP6DIgcU94t9mt+FD3yjfqBNEKf+rkAueLCYBcSa6ufKCa1Gi9GwAVSY9JfJn356MJYQ0VDraHYKQI2+/Qj69kXIBcUA3mtaOS5i0BeSf57/rxCtMOFZ9ws9Y3Whta7NfxY+saFQXSieZVq/cIYC18uQbRKMSJ3+cYZ4XLfvGD19CTcn/7zU9y4AkcTPGPC52Po8z+FlSOuku+PGQXYmPLzmEJcmRgAwB5L7DsGAG0MbSZGH4MbcjFBpAIZjqHFV8QxQ8XS6juJuSL/bmavoozlMSuBG+yk4jVWxGsr5YNCTGMg9k1YVEht7MIojov2mhgj9hvT3qHwXPy939iFQRxY4ij4yfEWi1nDkDZmjWVo8wPOF+sjpOGFikEHv6kcnNM2jhnraMwQz2S+X3GrCN+xYgTB5XEhMMb1iYs4wn3MejFyLouvsaJHHosK9xQNPd6zX3K2jlliGNoDkHz7DNMBemfMJ29ETb72iPOslhhL4GYsQhxHJXscbhorJm7cx4xifYxZoaITHQi081C7xqzDhiT+jM+NCX5pdiHx8Pl+DBG5CtDGDPnS/B1T9kTxKH1v9cOnIFGMjSX+3DcG7KF97otnpI7GgPrk3rHmyXdZzhYHfiVnFj9M4hXE/ajhbAtnoz1AGzaoehsD6sNaT6OePOCzZwjmfHFs7Wujnj3bcv6YkTNCa9iSTx8dMubBhxZ94sMn1gvSMQM/W3SUtUdbB48xT/z44GPUw2+rHvLFqeLX46cxR7jHFEqhyR8zEh8qDEaBc0ITOBYgJq2kltc71sEjtAn9Sesf+y/9yQMSZZfhDU5cl3744P4i8R7zPRqxRtAhxXTWZZxmNBojzi6eL99XneYlDLXcj3rmbfQdxMhnYKF8/FM5ezSwVyJ1NxbhDFTTjPZAL8TQMaoIvfTQIZfvozf4DkdjkXrDq3A3b3b5++dx7jvp8Ms4jc39fjxCYMYv0v6Naf5Zbb4E4so9Hxm444Hfa++OX3jGLxY2mLPHfXNyKcTkMhCLSL4RPF6CGFdiMC5hIhSTXJwu/fI9fpkPhs0+XnqcednDGuDeFewe98FpjjEftz536YercTQel8oZnmePofWXJ7ZQG628dxmAo0uj/5Z+exnOZ2MB3Kr21EvP+ozJhZ44G0ffu2T8RHSkkOugHhGo+cZRbYRj5vHT0weP44ngiJsWf4N73DXg8vf7yUYwThHcJd04tAIfv5TF4DgTFPe9cYZwxy9psaYWuuvvJdZIXu29ZL4vMj4TZDkugGWcAv5lOqbjiPgWxK8W80z+L42FTuWFGCLHGRHtYvxl4h93YsFO+Jdp4T7u+nqZ3WdMwj4VL+fdlN1MMWfyd0ngjWmuo05cyL0vnfoj8ijVHLUojI1LmJFw7H5O1foFPphRuBmXBozL3/8/HXW4o+r/kuE6SdhIWCNsVYfoS6J+kNgJdaKKiEvhd4rPKX+FYXlc4nS3b1nweikPP2TfU0T4+IWAWa7OLvUhQxosxxWRkOnjidiTdSr1VVRgXyrDEHc+tU+RqU+PgWacwIt5eHRxLMRCxIPEn5EuR8cV/0kdhcSP0FuijtTqTvnM7V3wBaOktS75WEvaeZzwZfSS55kMN6f7xm/hngoiR2KX6SLOvEN9fkE8Iz0v7YM8z70n7X+p7EWIF9UfbXGxvvSI5QUQv0vjWZcB72hx94lXyLoQ1qURV+BKDUaXnvG8APblatcHhxa8WvyJGNcg2y4i4u/Cs4bRZ8HYjlltsfDmRcR8IBxxAfBdnnyQN04tMbdydEi9SbFHvrdyO4ePywC8WmJdBPDJ8euFgfMQbCPnXRj2Ca1va35De4fmf0xuvjTogOSgylxoReFLoz3jr8L98km4O5tMeBbHxGUg0cRu+qHnBojNCeazCak5+/rkGZ+J2OKO8HUiQizfpIn+aef8rNsQorPWc07+TgC4nFBq7M2wkhd2jPu+1t6FHp+JPGMTkOPca/ClXoBmOREYqwlDfic84kvm1EfQSnajOL/oHY5C6wmqBcuFVIwB35DziffSL986n9YcXAbkMMIl5EQ4xz9+mij973ECFF4TBIlNaCKNAdqEcga30CYwQdg7YfTRZ38tPpI/SBzQvbmcWZ4fB/M1DuTSiolxAC+o7Vp8ydiUMFwg+LHUAYp3K24nANvGwe+1PKEizeIfyjlanU+AuBo34Ghc4chxIy8iXIPUhRWv1OdjCvdb8mfhNY1fJox1MQHuheIByZsP/sQ6LuF9QxtAJpT6D+mXVi4eB+MdgjMLj6PD7QQYJ0vdIfjyqWNLv/cd7hHd4dsHY9Rr6IURjK+Sv94dx3Tis3AvMeAr/VqUQa8/l9I/J5993avEJKLE/EztIS1XZJVsInUi8WdnBDRBq4SDM3j/EnZebDu8QFwC7GD8yeSyhIm3TJxKPKbGLfuB+Rm34kOokUw8mHN+xma8ZCdXqF7B/MOkVQJwWDLgrWTD8Jjn5YLJfgUf45Zav4y/xjhezOvskifP+J5VwjnwpXZiXZaExm3cd5+SH5+Pl4z7lwQhW8KEile+S2DvKxl4hRJQJbrvhPRV9ZKlBNahhw4YFzhY5akSnW8JG9Dz1pwG8g16oYj6l5OWfBLul7+Fu2vApBa0kiwo/lkXxB5WIV/yFDe+Irbk0aAQYIWKaisRxQC7tGcpQjMqMXEpKbgqKfEsMevS3nwkHyedOpksKfa8vGfFQQnAXen3/0QCsV1ak9pQI8W3BOT45YySPDiZCL2kXDBcKs8AsZ8sgXVc8uQx5HkpXlrdSL5dOn5qNnNxcPcsAZiJxYNonZQM9gMDvsi7JeMeaC8peXCuj5gtyXmfjGEfqgu0egiJuaVfU/qG2WuyxHDrJf6Ol6i16A3h+8lSIFa0OvPFbynCYIrqCV/+Ifb3yi0p3KlmzZGWk9BJoSG8iJpJi3AvgcFAA3wBEmwJEDII8TukPykkZLJEJNFNslX0hgr3UsDkWwooGiJek5dKfBAhgorLS4G0SnSxUfZNWocat0a4hqg1SASTF3jtTF4a6kYTYyUe+5MWQVdy4mUQZJNuvjwvBiaRQTPxO4VfN9+TvkJeicHrUFlKx0HiuEll0Jo0DHGTaDNzbZYGJabOJzVOZOo/iQuqX02WmGFT4UMNo5PoAERdErj7WERqCcSdAXuTJSDWMW5KSwYB5jMcloie7XFJOInoFYUvJw22cD1nksu7USdMgsOG94UlVVuCjiLtKfF6VdNhmZooCZdrGtcpA+zkpVD7gMZ7fv/x09MPj5MUgTlNdVJZ5ucuswQtvkcIqdRybj9dIiaf5ey/TP87AfjjEil13oQQp0zjAn+fIL6fMOZngsn9pNRYwVwj9pLNs2RbXGxRXFLNmxQ9wH4TkWqFOm9CiyV3HkFUk4ywtdQ6aw/TqFQsorFRYj8RgJ0JoN4suRfrBhB4Uj7dnE1Y8Ug0Pd+YIxgJzbcreieZGGh8Zzr3kucIln9dYWvAkBWrkyUdO1bOiJEndlghei15GcgIKI2DJjz8cDmRfR7kSasdGYEH5HEiAm+qeLh0FtOjySET4ArqMgaKMapXneeQvEw6uLPqNEmPTaAcJflx+SLcA4hk0ijmfMXZROT98lghgs2n8CzvTATEbiLAPtjey/DYBwl3pkh8hGD0WgGHIjNeLsNi7dsMJnKIZ6/qOxe7QQEe7T3gciQ2lnsVN+RMM59d+vesicixiCJO36BmJjxinxF1il+x/Jt4Ay7hhrFYvTh6nV3meA4q3HPgotCLmVxz8Pv3J+Feygr3Kc/NTe9d2feZCnB8Kuf3pyLFJuZzUxFyOOX4P/VORJRry1ROuMljH64GpizvXPnV21QkPHjH5ArngdD6nMohf1NGTpuKeNZUD+pf3OPKHtMpi71X4T6hMZqyxuCKj0lPOSNCf57yzdVV3J411YNYvXWP4vyaEjhsSuG3qR7Znde7MXRJSN+YMvbfqdi9OzzOv4X7VII8p654EE0RiwvIK+ERBifPkIA7xSRt6oq2darkfPe8XOEyRRQD0hSmrrBEJ+3InGdIYMYvIf5uE5xyGi0Vh4ywc+L1OulR+brKNlvXzylQ7Ew5eOF85vaYEhrqFOE7iQ/i7Ix9hqYj4XnqirDzSj+Hsp97d1KoL/f5KcDHySs6/xAur5gapWy6YurlSvHJPZuqAc6GK7nO3P0ycRD4QeNL99xJJ6eSn1NCY6E4QOIecr8rpkYN3CWK66ssn08qnEU+w511RWCvxGNf5DMXiwyGKV5DRRn5+1WWH1ML2G/SeVfsv1d07xLrJ8n5VzwfTTI9cFKqKYa7EE1C+ar1UlX7XMn9XNIMk0a+mpT4iOl5UyBHTgnY53A/pQzzU1qtXfHnTDH+WwbIqZJe7y4Gp9x6vnJ4iapnRjtMGvvtJJH/SV1zP356evCRFb+UyCkJzfZKBwYrrhXhra4SJuBJe6V/rwx7+n5fUuznyEYTPxa7Skq+kfxqtl8ZcCH5XGLyaY1fyRNbyJ6WZ68U/5C6uwJr9sr4PprXK0OOEd+1/JfA2vGJLfL8leL/lcIxVqxrNWbhGoRTLNzsU5svn18+rysj9yMcaOFyC8daa9/So0oecfDtlU5+pkue56HccqUMzVcgzyDDN1pHKJ6uIvA3yufWfl0C4oLaX/LgGgsn+/blklGTIfzp01NLYJ60d8M0By3cp52Xpp0Nf/6eXC8bT185JODsMX2FF/W0851EKq+2OOdOO89QP2tr2vHbm2hLvxvUNGG7qUlxNhqIfdrZezpAzE6XEjggCpv1kXieenYa9ZvywzkjZecliAXXT+Rct0aQhnDJY1sbYDL5dH0teWDe2WPaEK9pIg6mZkPkbLpE+OjyUSn7GReDaSV/FB6TZ2oYnUbiU8ry3jSAc44rUzx4BQ4dDD6mFR6ZBsTVNFN3nHCXeHrayHXs85d+vJTiAUD0TRtqTMIPGodpQ12HXpBNC+KEwqAaaweX01dh9km4nC7R3Dl9pYjUhBZx64utObRuUJ5GLlU17rkickNotpQ2MPIbMqROhwytlsvZK3C4AOziakjEN1hz0wqvTidv3J8eenSF+LTWuIQlvTdlFMzS/pSz2nPTHvaj31v9mjII1CngXNQ+5POpCPsmv59UxM20IS7TRrE0DQgfH5yE4GzKY6C0nGvZz5p/ruZ8cRfzO6QmEbxNAbGw8KJFtKGDq29MkJhNewzN0wBWrM+j4tbi13QE7pb2Jt8p5dNPrBdTKO4sHOKDOwsnTRny6NuHp3LWCzH6/HSkGEv7W3CC9LJpj55oxcgU0Mdi6CVUg00ZhuxpQz9yLg944R5roUAJbYLTPVqW5FmLW0v8dDmcSKY9wJ0nBpBYRLdDmLDfEkM+AjZkkM4zj0izDR2WQsQaRZSWGPYaI1M95jlolePxSsychgqd6PuX4vs0ZeDLzOfl8LNj9V5pmHuXuYxU029Z31Oew+1bceOUp06JGVNk6MlLUxExfvw0E1G4zwCEbm0KM9TnZcAGxpaZ5L9lcA/P5gW9W45wRhnMy5XtuZnYjb3siaceCA3fd2fKxucDbJvphRAr52fXTK/8EGyfsXBND+yaSayQ2phh9vbmHAQDCFbKvRdIM+D5MxFirL0/Y6k7LX7lHvFgORJOyr2p65l3MqxGiUs5fi149Zxyj7iXeqes19xM3v0ePasceHaZ8V+uv9/CHRGyr01GI0OJhMp8krhmOlNWSCzx/c9nZzT7pT1LWbDPUM3WCe6MIXEzzp4zxmKfsRBZOS0yX+IzA4oqrQnOlAURW2aagfM5Z8+MURTOKGJlxs0XUyAzLmbKjm9lmwifEeI1o/nEkNhMmX8uVTtKvVJ4ngHIdMYqUMqRhTtH7mWnvspELTO2zVD1ydS4yIFlnSNnpPyXs2dJInKmLA8FJL+XAy8GygSfu3XN+DdD8MoMlQthkJwR/Ji5wt/R+G7G5Zay3shnEn8hnSnjMSb5s5y4sS+D4kzpvzNlXWDNlO1Dw0yZqRGubwgCZUbrk+Us589chV2uqH1VEVQzIP9pA/QMsUwDYZneB47LVZb3Zqx8bO2XZUG4l7P4nTEIaA4jM5KGLDP9s6xjROL1aURP6bX2S7i7gja5NNFHOaktihDFc6+cM9wkloXfpXMocVTONlbSL2YvrvjYeBEiY6bEnE8VMdPkWR+4HLm2cvGTpumyLl5Iu4S4UPEnBfGV4luZiQGXpysgVoK9XBykvLJ+czi5AvYp602BzUGZrz8kT1KdSP6pOKCGgbJgb5n3kcoThbVpZThw+SdF4ACfibyg1Y2GBYSThUGTih+JQ4FPZghhqPKgFIfS8yKEqIgvQRi+fleiB6sZ4nJKrJ0rQ+2Us9imlshFZbnHsfx/BfQ/pY5EnCDDq4Qn5PwrHtczytCs4U+8wAP+IkPqhDI9LMH5vMI5VcRDWeHnK4aflfxPl416hLlUhWrIgEt3mKbwKvKjVvdXOCeSWCrLl2PP60m4l5+EuyJQp68Y8V32E+4zZbDhI6DlbLpSBOuVkWRRf40DEFkQACimyzwo4eFDE/BlvVCmGXzMUDfcVsHB+DAdA38aDlHhLuXoytNGYX9poOJ8mbZiQsO2T5y1JlNWxIV2EWDhFuG5aa0eLHag9mmXGGVFrCCNDM0NGP9pDlfWz3zESDkr3NHhetoyjJcZgWeJ45UHxxCXMupZ1hxr+AYueJDanSYuyGDOR7F5JV+kWbA1DfL/NJpbK99fGerC+hk6+Fl0j5T/Kw8uRrnSglGNiwEOn0Ev83w0bdnM4wnhzqxZ4fdZ4nfuO27vWeDcWcGeGfCcmYhrNuD5pM+xfJkF358FchA7VlbfZgVszBrxOWPEozWe1P7WeM56+OIb+1nBZupcNN6zBnxRhDYr5CdPPM548NWMEKvZHvGPL1ZnI3NZDH6c9fgO6TOzxn42a3wm9AxLbGYD8TXrg3tFaM0K9oXwdCyenAX4TbRFEGCzgf1iNo9++mTn7JVf/afi9OzzrCJgZ0H+pvBkweNsDrw9a+wHMepuNm5//yXcuSKcFQo0E+Br23uzitixDgizRnGL+DtNJG/W6E/m8+tsrGaA92YC7AjJi3vuNPCuRAyzOdiONDtpKJhV7EXFL5lr4PkZAIsUHmedupOalk/9xcRW0v7Uc9fK+9cyvkL4ZVaJ14xR1M0C4sHqh5UboDq+lp+f9sRJCH5mDHVg4SsL96eeubbVq3tbZxE2Vi5S8XQdVsevQlAZ1jXeQ/GLcommD2bL9pyJOLzC6ncWHBgQUehTK+hlEryudDGNcmfKzitbbrQLHsvZswH915fLNMwE9OTHTz//k2qOrrC8ZkT5tS5I2feu8cKfNRJF1H0lX2PZd+2smD5fB/p6HQDg65xslOJ1nc+g4J3XPPa/zgnj1nhfR9q3V3iy1Nk1wHvXAbxx3aPchfC0L19dB+QHzQHSXyz2XefEn1YcX3vmI6+6u86pH18H9FsEv9c97N+hvBZzn+sceL9XmirUnhg1cw3yxHWPtBi/COH+tOaef59zA6Y4NndtbJTOd3PXSrO7/mXTXFk5O/n8dfq7GWJPFBSps9H3rtPvu5MtWiBz1PlSw7r2aCLXuv1zlqZ+nbYffY89h/DpJb9zgQPXHCBO55iYJnMzd5WoG8KeuWsjKYYS3LWMjTnrPgqxzXFxKRNYuKbjaCXoOW4f6hkm/nOEbXM+lxFcnCgevRawWMY4IdqAr9WGYXAWeUqqLTAO0t5zEvdexxEqc5rf13LffOGrV9669uBm66AZIB7mrgHutw5dDHfMIZxvqBELbuYEP+Z8fbxO2zwX46JG4ngrP5SVPoX2bonPjPkh+dvCJcKZc9e6Xpq79vMz9pqj9M0vO56E+/Uv4T6XLIik4L0mRDDx2dw1L565PeaYfbi9kwSSWtfpYYNrvsmkUc3F3WvWiUnSrhQJO4LTPZ/0l9tb8o+wk4tRphik+JaV2ANnzgq4mFVymvGf84X7LFHYmbgxDZfMNeePK0o5PAqx4vAkvU+JRwkbc8gqEwPtNd1Y5jiRISwNL5RwEeN2TcclSeZuPCWumUN4yM0BI9yos+aI+lbrVIjTLJNvKT5sDRCihz2Xq0eunsuyvWx8lTi5jZ/kYkJgkX2BqdlZhb803ptjuJTsi1zdE3EifSxnhSDF1bMcttxhmuA4Kv9ov1fxLfGf0G+lGnJ7wCzBL7NEXbkXfJrInhNElVSj1LkZLlb6iIZPkocorDC2czUwq8WewSHVn8keDXAE2ceviYvma7qPUxqQtVuL3TWPt9myzl9sb0X5pvws3J9+eVTJCCUtrokZl0WEsGAngDRnFaQasDwErrkJlMGB5tqPSODvypj9swE5ZYVCGRhYyga7yhg+OEE665lfWGyXhdgEYgzN9awh37OR6wDhmFnDewjWReGuxCQWHqKssh8fWOt01tcWH7/LxvM5YXWtD4mz15HzcQ0OW0CcrRwwK3G5USCL3C7VBtpjywH9LhK/zF7Lf8VV8YQId08+iDJUWuIQUt9oPZZt9s4iuAMvTMzP5MHV/osW7tSaFz6fj2jU/PW7CU4uaz7HOMwb3p//A2IzHxln8+8Mj/PvGE/zOccL3T/vvM8D/BYztvPvnB/n/6V8+tY2zhv5ude9I1QD9DqvHC/MR85ZyPPzEW2b70Gc5z2fnX/HuuFP0DzzRhyJwn3eUCjz78TpWKQaa//5G38CnA8QuAgg5j3JcD7Hword+PJqljFxR/k4nwOWQ0lxHjzL4sc8mGeujtB8SHU4L9hs8uPmeXnUz7zvwHPjJ3iQi5gYXNRrUWzCP5GveYI/NexZLhgysb/Jp+fNSz5HEsvzofi+iTMozF+HX/DMB/KWlUct51ntsg4z8xH677yVjyMPbNb6Q2tj3tM3tY/c6PYrfjx++vmfeYeo5gWA/fP9DXPADfMs9blz1guRimdz9lh+l/Zg3p1DnkX3vTH647tuPPe+kYHkfTb4udhEfW256a0Pb7Z6YdtNjnuiuDWcPXfTIw7JA4Pa2Td+OVLFxA2Y/xxsY3sG0m8oH28MOKNsKUfsRT7v3QRweYQ+490HbsJs8zr3Bu8ruXLbe+gFPjx0E4Drm0h1AtS9CR83OeXvxoPXtXfwPvT4aeGncAcCt/DyrybcAwTtnCT0b4j3ykrSBUH+048FykfGt/mk/xy5onYHAGHhOmt38v0FKRY3QCO7SZOnWPQIEG/AwryhMTDn7lV28mARhDf+JLfgxtdCejf5CfQFIEcLN4aB3AOjC9r7N2CdWoS78M7CTQ4i3IL9G09xdqP44kH2r7i9yQojTri/5DPJ+QtJzryRbTbV4w2DYWD/OYFjROGucaXLN2Wn1lCcXxOxR7jpJlDo3AD7G86fCx3qKS51+zjRe+ZuPAUPI9ylfRY0vaBw4QKgnVB9snBDcHuvBLoH/y4kOML7LOHdBSJvcz59zHe4uMH03sLN/+Je4tyw+u5JuN/873EhIQhTJH3DCICb7HPcmnfI3yVk7XPT/pSwvXEE703al8w+DFAWnHdI+4XGk2x8GTuJc6j4zzPnk0OJY9fCtdJ4ObuvmXWTJuCFa95eSeQtMEJDxAnVRJlmT+U9mQcxX5y/GmHc8A17gbOTqxeicMk6FfKXIVcuTjcEhtzzrvkms3BD43ThRhFq1zzPzFN5cPEs3QjfMA30hmmQDP9w3CR9Ni9wG4kzpB7d94m6I/mFGeAWBH/mFayKPE/hg+BWLiesPzc0jyN5y4gs6hmAbzNcep393u09FCeJ/RSoWQqvktgg+xYwiC0wtUTVpYYrCscLQv9T9cE1zUlSLSJ6g7pwWyDE1IJSD1yuuJ6v6SVyMLihdc/CDXPhdyMPbxTuRJ6g7FD03TzDvZofVF9fuNEH/gUJ/9dyv15Q/F/gdOQ11gtUnDv9eSEj3I1GQsIaSHzoGWqxI0SpkOUCIfa9liCARRJQSF4SHQuxbXaEHEc8nPgn7QRij4gjaU8JJwgeNIGzwDR5TSDlsbjCF3NswAIp8JV4ungwxYAT7jfEXwOV/M57clyMnM2Hxh+xD833NcifgHCPXV+ZurkOj7k77Ei9yML1KC5M+UHOuRb6gTucgrU5Dw6k88a8xKqdeUNPXQB1h/Xc+Qh8MR+AL1X4XSvcLfl+DdbujT6sof2SyhuJv+t8euZ8xH6MXoZ42/Nr/2fhnqOAiL4qb3v+lxze/5Ljef+G9aXHOfqohf9beDHFuOJv05fQZysfmPuo639nTr98YPrPjuEb9vkvOef2S+z3wm3qjXD/Yvw+07gq6X+/RGqSX5yFPveFScIXzqeKbPsXIplfEPsquL9fIhDZF+BnyccvFeK7iuNnhY+p+zxipwkPFcCXio4RCy4zea6kMfOlQp/7xcVWBfBTqR9YXFZk7LOxqYC4du2pADZU+D1DBr8vFd130rYKjw0tR1+us5zxhdhX5UsHH9p72u/k3kw+v3jyi6XZJevli3UgqjB1Z+BtjaO8BrOKjddRDHIYoPrPKw9WsDr6YuwrX7j+VcH2SPWIilCrAq6pWH0hbEP6oMg5FeH8inJBUOH7EtsTfXSX4XKC5W+JJyv4nj69ltVjFUZnVPwuXTh/Wd6s4Doj831F7HuPn542eKREVarZJhfXiJmmnDGykg0iube7byX9c7KIU88w50pnSM2R85cSpMlkuX6RzeKGbx7iM66ou5H31QrvC5VvJv9c4+TioQq1ijxEfeHyQBGthM8b3i/q3YwoZvCjEnhFrge2XhjCQ2tNzCkQIw0vHNmIOBLwBuOTi5WyH0v8hJ1i/jxt/CLVCyFMyLxUeJHOnZfhI6u9CF4kDqe+rwC8Y8WwUJ8Q9pmYU8PpF2SgoOJ/A9qhxVDre04/knoIN6R8AQUndz6J5wpTVxUDPqk+rdVMBcR4hT8n0y8o7qvIw96XG/6SReRPQJgjfY7UYkoP0zhB1CGAXlzgsFbB6hOq4xue4yHdVZHF+xdloHHxL/YEpQZ/C/fKs3CXAM+Rc8WjGCxFVBGEO9jgvgANmJyaLEXvFK467AhxE28pHeKwNLKFiqHhVcDhokIUYAVo8miz9sWMoYA1OxYqYGOpMPGQsHKjN2mSGCsewqsCiC3jcL5AxQgVc5zQrhjfB98RB6VKVtSYhKxxYJRy6cNrCwgeKmEC9ksF/K4Cik7OvopBtFZA/FeMQ4jEJxVZBIv960bxu+JpawXs0UpvXWCwpN2Uoxck5l5fMQzHVq64MWCnIghgBZfQXx4t2ooYDEx4R7jROECZ+tONsT9Z8VABhkLioifocka65Kx45FfnvmfhXuGDtYgS6MvzxNKe/0I8K727SP1ssBFqBIxf1jhozywQcftiPOuL0a4v4BmLAXtToM7LJ4u91DOLTDNcjBHfG5sQWQyIv4+t2nmLwjuLAOYXAR8XPeoGjd8iWN8UH/lgDvaHsGMxLy64ke011wvD8YueHLhYkZs11E8M9cX2D8v7hr64GJNXc+TvUGxZ87EYyNtwfBX+XYzUz2PYTsVR1Ds3Nl2zaNRBizeJ/njD8xbct2788rGYN/5vaJ5c9MDNYqQ6FOrjl3DniHPxxXCQABeBz7kko89Zhb21MFEffPZAhDsi4BY9xI/kUyi5ck18kSgGJHaWXCHfQXm9wfySzl8EyWyx4l9Tix7i0Ud4WpZWy0idLypxtdjpGxd0r0Ul53D93+i4svKcRShbnl9k3rX67CuIFiOIJ3GBlzWLrni3PG/AocbBSB4XwUuyL57PWTGC5tTCETHqReNzix8+NYzyH4fXRXAAQHSFJPYXlcEa+uwmvUIwuFgJuzheZPh4UfHVMpBZNSPCHUs/hfvSs3A3rVu/Bk++dxtwlq8dOfj7BXw/RCD1NDe3OZ97K3/+BRFHvcr/e1i3ieUhrHtmX2h9R85ptHq7jbNHHrn4x8fbuP6L9fZ/qe56XeMx3r/tMf/fvl1954LP23fAFX/Sub748sXY7TuP0a3eiyXO1hYt3G9zDkgiYUs+Iv+WEDLEfku3v5dZCN16JOTWU0RJ59/EBZ0biyU3B7c5irlbEoC/zydyIYqOl9zeKuR9y/u7RBeFyb9/MMa9T9i3hApfoeEt+eb81tDkbnNs+rcCkd/quA0dZLzrx/351pPbgP3J+qj0aGi77V0ckfMpDJtjcxtxGAX8W6L4NUI9I9hYIupnCeEeY01JXLcUKZZJm5Zu/XSGiYO4OFH8/GKX5Xkg50uBQnWpovS+28C+Z4n1bbYmKJwhWnApDx7jOPuWriMpV0uorhN4mdMoydg92fH46evTf5YowCRA+WJwUgy/JuKWBumS4yj37lKiKCmh7T67xIiT5F6L7jkEoVIEu3Tr2O98tugQ4BL1u+MTF5tFB8SZmFAgv00Xn/vzEuOTG/vFRN7EJpMENRHjxVsnZreEqL1lGtotnlM2r8lY3zyvW5okyDMZ28hBsEI0DqKZLBG4zeSXifkSk8dFCqNKA0XwmzxzURIBt0z+XEJz+aJCN93M9xXnO6WOlqTBiaknh/gyz7M5oLDH4fo2e/7irTJ4VAg+cDGn8NMSgT2u5hYJHs5gl+DtTF0K/CXyBScsb4WGdcsLY6pPUcJK4sZFghfc7xcTPPPPhcot3QekHkfylzAYkvglcCvmS4pXRejbDFaWOH9v5QFhiemHWn65Pq7FKfXubbaXvfxPNaiaXjKI2iWHFxY5nr+VcbLonI++t8T1KWmgE/K7KNT3IoU/7nvmIpWsR0r73WY1xBKnM4RLwCXFH5evKPszPfCW6I+3jNZyex+nQzh+JGL29VW4U4dal5AI8lllP07AUYGjRB5FWKy9gI2Lmu9AfEiBoO19K4hYBgiiPcLARIJVsIFsSrf0XzyWNEKqYEMeG3NKuAsFRYk/VowwQ1UmJxUg/pI4l0QGNzwwNxk+tcsOvbfG4VDDLYelSgDuPc9G62RR4yANtwTm1HhYaroiD4esfZwIUoSZJY6ZxsQ1MwVXbE/QOKrCCzrzcoS7Tx1kzq8QgwD3fMWAacA+tvZ8egtzObSI1HFF6fmWWHNaJGnLS78Q/Hz5i/eSNixwMeL2RrXUDfgecwHp1p8vb5K9nLpc4S5IwfxwF3+W+s70dA9tJXJmaG/RcHmbHUDcPV6F+9cYwv0drq/MZ1/BZ2Oe+1b+/l9dbxqLRHF+BW18L5j5+i/Jx9eI+3z9v1gzlQBx65GTr/+CvHzw79twS1464QM/+dbh13dYq1//jJinb9ytSfhKiI+vQsF+NZzxVdg/pm1WX79GGgK+RrBJE4Jfjeegz/SqgfrgMaQYvwLi4qtR9HwNjNXXHsbTWl95+aDF+C0x6FPvXwP57GuA6A0942sg14bypXb58jXS0PA1oE7y4PIP4W7H69dI+319hyI3Rr3khc/3Jty/BgxmX0HOz7X/VEHh/hUg29Sq8sLwKyggTSvWedV8bUg953mWT9yWIu8vPbMEfm+KT9UY92pOufOM+RJ3VhUYoKq/FhpHrXGJMajacZIZPqo9jHfVvy5QkZUXPqzxeY3zc55Qf9GYvDQDr/hVI8atqp+3FLt/WPGQw/mheHfzF8s+a1xebFwy9pKlyLzA8eabrGqaz6Pri2o4tyxZ+KKaQz346qEqGHemXpYQvqwa+bMq2yPyXFWpnWrWL+IZXriTIuTnqiiCqhpZfFUDG0fV2aNqENtVUJAhZ1gFYRUQgchn1WxDQITcktRgXdK02KbFztdHH9Ko+ola+BwlBhrRLxl8Mwn3qqGpEz4tVz0bT5XJexWrfXhAqv5u7qpdVcMQaR3SfbirysQJjXPVOERWQS6KdUkBxNws3KuY0INjwNVU1bNfhfYFrcarEYaoKnGOUKOI+HBFPlS3FqEcEk8rL6C920fXVO28sFwV+BQZ8JPPVkA+Dsmb1V/DoEEOhlUad0s+Q1PVqCciDoJMvJ+E+9N/lp0HlqUiqwrkW6W/X3a+X64yZ1UjklJSaCR+X751hEdVT9DyLSD83aJi4rJMxMN8m28ZLKpy8SwLZyzf8nlcrmb9XK4CAoQ618HGS4yWDQS4TNir4WfZsX256oE7KY9Vwo+qcQi8DRhKqkR9MTWOxvslRsuVX4vCNxfrZSb2Gl6Wb+V6gvNxy3OUmy+xTtGhuqqfl/GnSmC06o/B5Vv9u2XfRnXLY17kFzd/VYZzBfyxPio2Uly+XM3i0lyzBmEMX1hQ9j1jxL2BT/a1ZTBXy0yvW67K2FyW9rllLveqRsGcrAVXNyT4ehm9mKhmuW5Z65NVvB6WlbwvO/aLe7n9jMDmchXjiGXmoiXVZ335koqjRRtp/Vf4XnzexXSFwJFBqC8jF05KXpcpHhP2yfTLNH4ePy0/C/dlqdkTGywTRbZcpQX+sltsjIBY5gQh00yXkcmuqogFyrdbx2YugMRwsMwJXCK2y45Q1YT3sttsGMHLAoAqgFueEJc5MuWIVCBKbqBbZsT3MiP6lm9lISfFnRWPTHOARQzzvEuOYu0I2CbrgmkMJP6YxgXd5EiDVYX2hRONpA9K7qiYSbhbVriIyrFbH5Qty5KPAA7RHKoN6zY73GbidZv9nq0LDfMcPoR8LisCVqoFroml3pUuGBRxJAlT6K9JDD4z4qqqDG9VYbjn6q6aFe7LnBA1DIdUnzZhWIm79RJGqz+Wp6u0IKKE6bKrLarO4FPlh0wqHstO7lO9jMCMNjBwNlO9ZJnieS5v1azOWVYuSdihA+htknBfruIXHEmep3wWOZnoiSw+qkpPrMqDGaJR1TgJuvT5rGfhXhXA8LE+1sf6WB/rY32sj/Wx/jVr5SMGf2reaOG+4pngFWVp74UAayUAtKmf72z2rAgxsMTLnYhXtDzcOfvdpT9buQsr4hUhRsnfVwz5zJN0VjzwsWLEBptDIhcrnnFYieizFXu9IvkVEHNWvkB9g864U969kzGz4oknsrbdz+7scVsx8OyKUt9IzVh7RixcrUTac8WITzdmKxH9ITF5h9m0bMSbJYYrkeMb8z00VyG552JF1YK1H3uvO399tRJy5p1/Hw59dgXRS4Ye61P3K8b9uDiuYNzy+OkJUI+u0FjhGtWdLMpXHAJIkcsdDd4VRuiscAWgJeROJqIVR5yvOD6uuMt9jokDCiSqKa5QibuTC2LlTgHgHf0MOgysgM15hdgjEy/wvBUF1NTzWgNb0YqBGXY4rKj73/3+9+udHCeSZO+Y/R3csfG7w4apFaa+uXiuMDWNDEdS3XHfc6SW5BIu9isOr2TieyfXB9xs77Ix0fZZQS457mjRJsbxztn7jsEzE78VwbZlhitTeCH2WrmjOcHFMzmUJPF+x7x7R/cRpH9o/kqcoNYs4b876LP2cH0WyTnB/6q4umPic0djBqltsidrvcSA1xVOJN5hPUnsNXdY/9a4jIztHT8UczigdM0K4A+nX9ClDieURrqj+Y7Vf6h9d7x+oHoe4g96/vIdg+07hW/usIGCxYuDd2efX8JdLViqgO7ozxCRRwbHCi7NFk+wsucgpEsQ0cqdXEzLwvDDkYgkKFcY4LCFZiA1dfi55Ycacsi7A8nwLt2soSFMigFXnHcY5l7tvnVI4w6wAfxLBkd8Kj4Dmw43fHFCQbtpttTPikFwsfhgSF+scy7/d0LuhXdTeb8VBIkv13ELrCXtcgKqGaJZs8JSaO5cjqS9JVG/EhJnEH/L2gB7J+AipL9pIv5OH+R865Eb1EP2FHlJ4zspLolaXQZ7nemCAagjVIitaDEw8H2IUA/SSJLmEYZN9kLizhgTikPuMButdbVcBXoCYgMx0Bjizwv3VZToBRFvuWHjin/1Tr8F8Fmr7s9Aca7eKQR4Bww6xFp190eGJup5xeZVAwGu3um3HmKR3TkYqqbzuVoFGhIiUu6U+Envg/u7eYLPuHNwrNWQVg+Ircxnq3fGcxQRt4q+j9osCTbfuHDYrhpxIcXS+Xz1TqgVpa7dmlutMlwl8VIVi88qyo8cpyj9YZWLh2R3CKdr3J2MJzggwLgF8c6erwizDGca47bqE0cO+1Whj1SJni3gf1Xao2rk6aqCV7Smq2AP53pEFYw3E+dVo3Yx1wMy8Dn1YsUH1MOFnK1aLiU8sb5K1KVZF4CD5SpQn6ta7tK/P35a/SncqY20wwQxt+oQ9yoDTo7cVxOTzCpD8pZmtupLWmDRrCrNKykYVpPFXeWb3OodE8M7TECQ+1SVpup+L+QSIhhHfKyiYBaKchUpgCotqFY9Bzs3LpL/HLZX0QGYKXxVAFVtg+oqKP5Xq/7Cj7Wbyw9IcisR1iqYtxUFT6sW+1B+ceqOytsqUBerdx4CWomPJQ+rSv2ueu5r2Y/jwdUqj28OhwgfI/xEit8qzdXqEFS1x8nKI6tAbDKXKVVmYAYvKpD4ryr1acXqqs+wSPxu7ddWzbIawHGrAG5COJYa6lYtfciDs1aNPGXhDKheqsoFh9GO5WpWezn4+nXjvsoUxapQLKtvvFYi7vMe/HnLOK54xMX3vffk80oku1d66Hev4r7i6dfKG/n/3ur8T+MVaYDppV8rb9gL/i/w+nuz673ZGdr3Vv4FuPmTevcKOiy/8/5kXL9u3DNf1N55cmseNtTeOVhretyjnJF3Edf+bxKUV8HWcshn7Z0RUe395G3lDWoo77UWkQPfQ3xW0P0SfPmuxUbt/fLb2juwa6UXtVDrTS5X/iW98b3XkXQz/28emNd+/5sW7mtOoNaIYlgDgis9s1bj91pzfl4DgL8G/O7uy9pZywQou09N9p+z56ffSd/dfdY4nxV/TImvAfYTdq3W8PiuAnFKxlfCA0LOa8mY1+gchAxGaxKJaMK55sS0hpHTmi/R15zY3hnzXaNxaY3PGhCP13qg8lLTz1pjzlnzqJc1tP5q2X/XEP6ohYkDzS7Jfq2eUe5eA2tijco5uC/UF2rZmKxZ9wP8N/e5msA/PngGe+iqpWfX6H1Ue2tGDnDqes3HnxrdI1h+J/zU/Ia5vmavV7VPSPbUMP2zJtV0LdIQUcvmk9pjzWMgXCN69prT1016p+ahj2q6HlR7vKYTXD+cM9cYrLhcl4jN46ef6p10uJYOxGsga45YosSx05zXiM//+b36u3m7wlY6103q2l3W1tUa/VySCJLnu2utlhWHa27QnX3WatmGkrG39nuflTvGvrvsfiSQ3fi67xIAyeSGOqeWjS0ZXyKmLnZWCPJjcVRTclcjnqnRInVNiwcVHwUz7tDHxpPB5FqNiKVDYil8cDliBtI1yS5giOVqFcZkjY9b6qxatp5T9cCdy8RhlTvnTrdnTeCrFeeMlRpfz1zDoc5fqQm5cjmKERqiny7OakxN3Nn4VBqa1phhkR3QiLpz87GK8CLxXWYwJbg9wzMM5/2zqnQtrxF1Q13SrNUEDN4JwqhK9FAhxm5NrABDHcvpNXrQznzucnlSiDE8l8nvy/NVYm8Kq1U5BtKlmcaJmQsXSmRxz1AxcwcOoWevClzGCX6OLyg94saFxIerSxi9wNmaeUbqCTVgUfbVMJ5d5eqaiP1K8rtqOreUTliVdJKjIdc4jcxoiwzvZ+P1JNyf/gMFDQ1wLcd1p5P2t5jn+L57Fzk+eceWKqi88u5TvNZz7yLGLK/YI/ajdXkXSI69rIOYZ9QCYpgXJ1nz9Rb41OwJ2bPWo5gTQo71Je86Vi4Z1OGzF7xi5RsrBxkFWE+0Qi/Pqf1h5/jm4i4H/r4zYuTO4/xe8lNIXrGcyMJ9lRDFkjD+9lbOgvZJz6U+u8P2ID9P2PatB/6abON+7xGov8XGCIHNbwZbYLsFrH17LyR9R9h552/fN6EOvgH+f7Oe9Rb4sdZJYI2iHGPy8073w2r/t5p8GfItcmP8VjPEjcNpL4ZEcM9vdyA/3GH5i4XjZH6/1cDhItb5d56CyzcOkXoaWjvfPPrgNwXzodygcrNvnwH7n5mvfYR7TrbnjpmwgfPx09Mhj9+EZvyNWW5jkN6VyFgS0d+IM6RzvwlnfgOe/xaw1oyx8BXgFlu8hbxRrFljafFpTci/5ZzU53U8vohQ/xahBpDnEVL8ZrBtzVMwhdbBWiB+rE0DaZCIvd8M72v+cO+vReAb7dxvQHx8+gF63pqC92+etbXmyTVIDXwz9pu1wPhZfPTtCd8M3B6S/7UALkD6gLX/vn5e5+2z4kjl5zrInXUs7pbBF82ntQ+G1IVP3/Llm28g7iHtANpr6UfaZ8S+vHAPFbr/fF9//r3uR8jqqtNnwO9y/tTDRLy4N1GovsOGdPaaQYCtufli7HPP8W4kdU8hqJFfHcBTPbvPWs3gY10mfQQ7prjVFTuF79fqcg1ahJE530BdqvvV/TDFvcvh2dIAfGxbQ/iL4s1AXl5jYvQtFv9SHFxPf7Zm8ZupT47bTKKybm/SUB7qij8htQ2eZcWk2OvqgMj0wX7dLn5I3NYj8QUopsV96zSm1ygOrut7hgxmIX0Fzdm3iMIdugyu05wSYyF6zzII+uqjNYDfiPUk3OtPwr0uA3Ld+XxdImHq98Tn64YCcNe69I6T6HVtv5/P1AH70aZbF3y3FBFQ4C/+aXlYtxA9lxuucdQ9C4vCkPL8+stSmr+lsNdDhjRKrCACth7QIAQcq/UB+LruQYzrNRD/yZzXPfyt+4t5d891gN9IXNXx2hT31vKXiBX17jqBp3WBj9YT761r2GT8X697cpdP7qh41OmaW6/L9bZe14fIdcSORBNeB/xYr+m9wbV9XRHTiGhfV/K1XjNwBZO7dQN3rtcEHFl7DzD8aX18ve5x6VfHzluvMbhFchhhGFnX/KkbznNqa13jeEEHrEu4Y+K4ruFDwfd6CN8g+KiDWKwzvFBn+EnQSEkNtK4J93WX8BExQCRhXSjsdeo8QaytS6CtpwXruiSkE8+sC8WwXjcUVh0XPMnYrnOApd6TBBwRh/U60yTqCuDqshiQipkl9zqRd5BE3Dyt14XbvpotDxnb6zThiOKHGazWiXxYiMRb+NX1ZkflUT2zLgzIiujgsJu5GKBwLOQGbbrrdcEurSnWPAZgYnhW66ae5c31mtxE14VBer0u4F4QuOt1utbWgcuJ9VoW/+v1LMbWa4ztCK8pFwnrzIUTK0iYXvKy16twZxqyOCARZ6wLgiGFcUDwZXBTxy5y1iVeY0RhBjs1eihZZ/ody+81Gnsk5gMuPtaBvwqasFmje9q6g9NUL67zfXjdcpFXZ/pYPVCXICLd0JMynKYJ/Tp+AbIu9LJvdeByScCd+ZKIyqF0Ec3xqSDsn+Pz+OnnfzJimRCU5DPEokQjOTkErm/1eHu9x/MyuYi5l9s86vY8q88b9vuWV8xqhvjVAuMc8/2acV+tTmvGd2v6+1SDMsXbiu1a5DoAeewbwHHf3nv99wLbwjNSLP+1q9ZDzNbeHiN/Wn5TQ+Qb2u8Ow978/RZaIga+aj2yL3Z9gPoHxlXN1KcfP208C/eNQFBsSE1McGDjjYT0htGWbx57b0QA3EbEZ78Rz3zrYSH7xoXL1UaO+c47RxsRSGYjsjDb+BPEUA9rCxXu2r4b70VEvvze6H3j+7cJ9403qKuNvIXJW8bqjQQzpVtCesVGHjqm9ufEe6P+fnC48ZYDSy3y82kOfxLujSfh3kiLoQ0lGCSwG78W+14j/V7yd/I8wibKPvT3Daahvq6G81zj10LPz3zeSDfI1PcNfZ+MPVz8G44gbGT3SNlkFMAboHC2PAcVXUPPGVq8bH4kfDQYEdbAcLABCDjRhwbuF1Uv2n5aTbB5bNjjse5Zn1T9cUPQhtJwJbxuEL8jHLFhyY+x3iB7fFYjjGfNGG/Q/pD11giwo8Hkt6EPzT6cwtVnaJ/iuGCjQfcN60WG9BzEZw2hDzXsPLyu1LymI9YV+yjMs5htyJhgeaDB4zvzfQMUmg0ab0ieNxDeNtSwddjf8OC5DQPHrBv7ro+uCarjhsHuhow/5t1n4V7nSdMn4OsI2BOA2miA+zf4faBV8292Pu9pTdF8ToMARUMgi4btDKpZbICERX7WwPzU8MUVhWloQ3xp8OeRNdIgFiI6GjROqCaI1iHUcIy1xMVxvREuJEPeR4ZdlE/WG+D7Db0uYQ6TcN0I5x0zxwAYDuJDZP8GyClGm9cbfvjKC8tIP11vpDEl8h7RExAsSsOvNTapoasREDdBI2T6UQMfri3PrqN+W2qmIXNL5vLNtRngaW8+p+wg8CT1GE3vmPSjEtd1RFsF6B7fPaSLBBRf67i+ffy0+STc2UChoES+I57bRAPUAFbd2PgAYboZ2iA5+yT/rLHQYt4Ac+LbjH2bPGq7NV55DWMNoy9WbCM44oSO+0wDHFgaHjER7N30yZFUzw1DzTaMZzcU8ajlu6HkAD23YRSpdTDfxGeb0rPO2jRgdhMdYhtgbfv0A1++rHvkvJHPRQ+8byPSvpb4+fJhI6AvPn++6dsftbg1wJ5p1Q8ND4xr/c+t99rzajgxQrSARRch+Ue0YyMSfhvAkI9eDjSMOs5HYyH2S72vQfLtL+G+yRVHgyBm9zviXff5TaGYNxsG8DRogZA8f7OhA3Kz7gC9lgX/ZkMQ78nG1nBiUHfigfgCCNR/bK4R8X75rg6QMJGHTQLEm4Ybr02wGW5KMXQ/Y+K3icRLEJMazjfqDC45jFuFuyL4NhWxsEnU0maDsM9KMty7NUPOhVrfrKeXNoy7edpEeKHBi8gMHzUIe+r02W5dbFouEeqKXY0szlR8NZSGIoiRzQZT/w2FR1381eWYbyoYUfPG1a1gN5mzGl0bm0p9bzLxT70nDa8N+hKIOmOT2WNT4dTNhnDRRPS6TbT2CW5h6xC5jEPEqNL/2LhJ9loGbUkgN0CurNv9gvLL9XhCuG8KGo3UKcjAIfDMppLnTYbbSZ3E1UGD1zziuSj+hH6l8ZxYM2CfkzTvJs+VaeFOkaFE7JvEs9I+qUUkxnchAdkEbEb2zuxX123h4rKuAHwT2GfDEBPLc+jeaPzY7wSAk4St7U8NDY2sWNsEfdsI8VcaGiTREZB/bV+qASL1j9SFpbY2jM8i+7BNj4qXgifYvrofV6H1tGHkKB/u3LT6Cw5emwF2+XA1WsfrDX1o8ekJVA1ww0xQbyPOyjR30Cez/QrPuH3Np+4t/LgJ8t9mZFxaMLHh0Z99/Uee3zD0IR++2ugBd1nzGiPf0gC7aezH1vp06i8r3H3EV0zCjSXcNXETrXHUbe9qg89GTuKnV0LKihHpxi76qmMDY952WMgFKWxv4oo8POcZr1DxmVtO672tvc03jPNb2J0Hv8XmzV7E2CJ4N+tvOzjFOHMjYJB/DzW0AeqmDc9B9L2ujT+Y/6yXcpuACM/Jr8dPW80n4d6MvLGw3xa4x5ayzz/fNSPb2szauOXaHcE36vmtAB+od7eazDPNrP+WnMSymcrDloef1n1c+zcQDHrmfAuwcyvA19ccK3vlvbaoOmrasKXVFpvDpl999DQ2Up02emf/FsijWz2KRww8bPXA7i2DrVsN/1rcCqyLIM5s9rYWQt/dCuy3Vp6nzt4K1EU956WmrK+2EF1h/NwXD1sB+25GtmMrNN7N8HrYygj3p/9sSQT0XNTsM81sA9hCRUvz91RCEkdTadhNQrA1AdJrpv3aYoTfVvKcJl/cr3FyBXKTTl4yrly8tlCB0qRjs2UYVMSfPcS7NkhsOfja5HIhCG2WbJ29kphw4/Lz9w0pn01GaDcZX6nmTdlDYGYLGbKc77aI8zJxaWLDTSY2BvLa0vKLDiyO3akcNBWx0cSFDnl+E/dP5ZhmluPY2mniQ16GD5v6/uTvTbmxwAN6ExOxXF9A+kSq1ppp3mfjq5yX6msew6I0pG4BXA3hEsD2VpOp4aYc4y3t8obSAAZ/uPraavK1vqngdCvi4O/GS1oUb7m9CsK1pB2MFxCIVtq09mgCA1tNeWgh+6SgtbjBJ1PHTafPgcOSegnWpLG8BQyIW+gwxA2ETUzQS5yV+Oy3cN9igKl+h37mimXue6mQmow9FnubhC2APW7zUM9qEvs0BT+bgC8N4P0GcJYUj6aeW3IAYhqhat/Pn+t8g4Dy1QQw0wAxYn0esQGpjQY/vKTEYBPIY0OoE59YofhqBtrVBM7U+MDHL234QGov+XNd9lMTkibMoLxixWPTiGmO95oez2uc1PDkdOrcumftNsF6aRri69GXUH6iLtYgbEl4snCRtX818JpVuSMWD/rUQ0gdolxo1UM+fOvLB3WQv5sePcSXGyz5bYJaVuFuciht2jH0rAEE4Y6QaNMQ3Oe1/XOBonEbJUKfIkdFUJOY2BLvbSt7pPwlgLCN+tfEim676dlAmgIgKfAIwHZvxEx4Ut7dfvGxGdgMfMnZIg48hNK2dGNNYGe7aWwcRv+2rQKG8G27gWFvG206ydoTuGO7gWOOOg/F2bZleGkqot2NPXgpsu07/CRytN3Qc7Wt7L9tvXhAcqPgdhvsPSksNhn/HRxuSxcySp1t+/AuOBBsNw3CW+kr200DNzaJukPqSjtP8X2bwaukS7YBvG1T52h6x9pTG4GDDICJbR/hLvmODokW4Q7W/zZ6aQRgfRvQptuGnqNp3Yy+Jf4ys0X8VVa1JX3e46enBx8zgijx+zZRqNtNkHyY/baEvUmBRtij2abtLfm5DTyP2EU9u8V8Jv2s2bntYcsWmFfEDuR5Kwa0z7eV/ZAcbAv5tOR/SzkLqR1rrVnyjGAfsWfbw45tD5xZ8LptiKUln9rP22CMLHUsnbttrBeEL6TPLP758CHC01Lutg28t+XxjoTBbQM/bXk+j9a/hRe3QJ7d9qi5LY9+vW3oQ1sAlrYMfLhtOH/biFMfTeCTV6RetwJqRNJuIfy/BZy77ek/qtd8tey2sX/55lw5NyvctwPEkUQY2j4+YmA7kMBDCDu2fVsRiiPPtRWQ/zxyGWW14vpsfW/L+H4swbEVWINbnjFFG43PUGUd3nyeeys8xMZnXvGJfX5M7t3K8f2tN+Rea1/ZitzrQt7Lu+6s8drysGerB/h6K1y+J/2Rh8YIuWj0wdZWBPuf3/kl3H9+sMM135YucBARBO3BvdfqrWATn2uB9rYAP1o99LuV0z4t8LsY++fhT8C+Oz64bRlx7+nnzlvFpgV+11JyS3y/E1IfrcDnWkqMW55xCMUyck5Lj+9OM0dO1HDZiowzH5+e1k7r7bjEqze0ZN93rHGP7XvLMy+tHsXXittW5P7aioP3HeserXBO2bHmvwWe3/Loo62IGHpLzdWC6/W3cPcWjlJDayRA1cqSSU9Ep0FA7TTjNaAdBFgtubh2WrhNOxF9E+1t+WFlJ1YBtOIIiJcc7QQW+04OWI4hul/qbsdX8LZkm1723Wk5ZN6yYxMV+BkxYhFbUixaciPYadLn7Gh4aOGNZicGhlC+aGXrQMs1N0jtEA19x8ECiZ2WjjFYdLZsYmBHqOWdWJdULXAIbAVemPmKdms9ttIx2kFELijcd4w27Siia8fALTs+tdeS636nV6K/JdRichgVLhJ3rLnxjVfrf94XYDstGd+5Xwi3/odf6rQC+joq3FtPwv0pKI/bLtm20sJGWqmCaRHN1AEP+74LtGRTaRHNukWL251mtoHscEBvZQXIDtPUd5JntRxfW4n9iHeoPdwmscPYRIkN0kfCJjdGbn6Ssdlh7Ntp8jHi8sfFdYcQWyzGWsySvnOfIUQesse2hvsWja2dVrYWMnEhfnfrQyJjLr7kjSGBlW0mH+5ZGdtczDr1QNXwDpV3rQ45HGjYcPdi3tkW/t1uAvlvETznihrOLoYTUnlqZetE9N3NCYHJTN1LtcDVs8Q7hN0ifwn5k3Cz08oKQ6iWWwyOuLg2ad4j+1cL4E8lnpSQ1HBE9o2W8D3Vd4XfUR6mhCCVNzbfDO+4+ebwy+KhSdQU9RcW5l8pXtrgLObvZb38n6FbtN9s/RPDExkfJofusM5yJYM37i9Tkn2if9SA0ZL5kuTMluxTRgdQl06UjmzRPMb13R3h4meHwfc2hfcmkc/fZ/4S7jstW7FR5LWDBrulk4IqfFtgg5TIt4Utkmw93ttGBagQG655oHEU8ynZ1+SF8U4Liwe0pByC2EFj6WVTk47LtjEGMH5A+0lRL2Bu2yP+7PAqDW/AYKX+HJpPVEh44oe8jbQOmi2PvLQCh9sQOzzs2W5i+IjGJSjvgZcE29Z8NHEbtpmhzWt/t+kjw3GT6CsoVpqR+Z4S7pY9ADG6rWFcwUvmoqJpuFAihHsu+Efxbeit29pgaO03AX7BfNukBT5bE0ovFC/liL80ony7jWqvX+vx0+6LcBfWLvP7bg6kuqv8ntc572HtvqMzdv8Qn/4kO5PrrTG1+87wFiMHvXh/N8c47uaMz9034t/dd8b9IfW784ctn9jvvnEcdz1qotdctvuGPOe7727k2tyNXDe775ib8u5vxrpI3Lh7gHbXKFYQ8bL7RgHffWfkn5fI280h1rsCKcTKExUPFUPteOJ5N4Kw0sgvNF67HsJ915PwUYzuBg4zuznUhuW8XaCGdnvAQ7sGft0BcOZTb70eSHZzuCQKyZ0vb4TGY7eHw1poXcUUOb3GhrW3qXlr20SZtT/taj2knZ9wtw5Vu0oPhPdvZ/3KW0/t5qzldo2ifvefG/f2/x5/Amy3ZVhtj2fbwF7uz21g7zZwhlQg4Ptmv7WzrO8w7+445ED6IsW1HeCXtBe1L/dZi/GxDeQg1H7Nl7ZnTbQVf634aAN4b2ebBWSTEXO7BBmrcW0ba03Ki08u8uQ2S+21ArHq6xsa+9D4+vA22hNQe9uGmkf3QmxqB+CpbazPGPv44rIdsSe2cuipkv/tAK3iEwMQKzs+uG8H9D8E6+2I3NoOwEs7Iv7aHhzfjsCZsZ77ZQsj3IVC2EMcawvAAoQHS5ZtT0HaTouMvZZiq1XQIYJL+H2PO7sZLnD23PxJ/jad55A4ub70uikQduw56/XztjIoGOzZS8a2ZWj4zh67bSMhOznc8xEizud7Qlz3lEFpx8WaxhltrNnucfVB2egzQBFrL1kHLWEIbQODp1D3e2055mQ9MfVMYqBtbEJtokbaOH4gTm7T2NpjPs/4iIiXNijcEL639AQiX3shg0Kb54s9l8csFzJE3e9xdeszmLQZLuD4sy3UsUHQ7FmFNIINYw/fBfzd5XpR8gKEwNyehG9EwDfB3pqoSQm/exYtRPWQlsKvSH6FXO21lRiBcdtrYxeKe9YhB+Ee+RLs8dOeduPuCoVE0VGA2mOaSzIYe9znXONvg+KTsocQOtLv3DmpJpMEuOQPs6crJvd8AMb87uZnj/ITaVKS/8L7GdHcpsW0i5M9ZajYA4eQvbbQmChSQppbm2lyEjkrWN0T6mO3JeN1l8iLhiMOpyyxthl7KMKS6p6wz+WPVLNQYqQJ1z2NL1p0vDgRycbTFVFSU3N8ZP2nckkNKdQzbQWvbSKnlsEeXHsg/sifW/x3pL9t7CJkD+DQPSd2MC+6MeQ4x7GfyhPFh8gyiQ+Jz4GLhD1hwN8jcL5LxEfMEyOI9oTal+qGiu9ey8iDRP9X8cFcjOxRFwWC7pGGWwkLLF5aGL7dehD7DKFnuCGT2kfqX2j/S33WdGxuOoNii/G1hfdVSmeZnhPikeGV7HNp4b7H3OxABNKyg0kTtJKAVM9q2chvDwCM5CdCKFzzRgYLUYgb/eSaitZctaFD8o8DMJxPSahreANtoYTEHkdGLVoEIblVMdHCY4PimBLP2sDHxoYhHRibLRuHwBhvBdaFpQ486iqUi/Y8eMXC0wjGdo1cZeLKlh8neNnQ0vFpzX8MzAXhpWWvIXYoaSk49ORzC8drwmjPyqnEYLbnIeJ88s0IMNI+NlcxuKUlx90nd2Tfa+VXFyoHCX2brH13sIvFte24XJwR7ntvRDYf62N9LPvad/79WO8jHx92fayP9YH5j5h9rJzXb+GuJW+/8/Tv89onnt93VrBxnXBgcTZq51Hv7wtnIL7vx7LTfa7D2N6hfYxlnygiO3KsND/3mfhaMCPZ54PRfTAeMcQ2FUsEI/vvlIRT9dFxfOvgNpM+d/ww7Nu89iO/i+65j+C9w7+334NmDcehk+Ytjj/3QVzvG+p2H8RVqvY6uB37EeK078HDbyHc9iM8tx/RLl/+24/Ice9NFO979uBexI2tuU48PFi0psRBVr0Ind/x5oHHT0+k9LjPiPGkSFcTnmga+5b3tALo6A5a9mVt69DBJJPYkYXJvjTcdBSx0aFFzr60iPNcQb/f0Zv/PvH8vo9w6cjxdr+jhNg+ITp2hTy6+SNx15HPhsUngwnOH7R+2OLvZOsAFe7c+XsdGl/osCjisKMIpw7hLyXiO/QZEkftdfhhb18YaqX6QoZAElcdoT4Ta1dqslwMOtgQLV0q7AsYY2Pa0cUvxatu/lRuU/CO+KU1Ze188QKho3CbwDn7Ss1negzDdftt/RKN5fKO3Mcy/MNdGqF82ZHxssfxHsVXQNw5P1Fd4uZN0yH72qUnpxXaII6MC7m8oi5l3eF6H+XJDt1vRf2l8CM17GtxE/HOaB5Jt4nx7Qh4Mbwv6Scm9rxwh4QX0XQhIlPEjHaudqOXSSKVHPAvB5Ybm/2OPBjsd5hnOjzwoJ8pwAiNb58gQ4QIxEbRCSMgrhm6N3T7BpzsG7Gs5p7JHSW01ObeSQ9xUuFTf+mSSGJPGKD323rzowYoNccCvrU6oRqFmmPurI7BZhQDGr91ImGMuvzQ6ty6pJvuDoFZ7XcF1xKGfHFqERBqX+pglwtsnND9pbro6P0ns08EXLPDCXDxRtZxRxnEOF+k/tQ2YF3gAg4HbF/uhNW4GE9NB3SMwyDSl7QLp06aHyxxVn3rCByu8W4bzI9ykbQvXSxa66pjqy+0L0qXpvukcH/65UAI0MHz7weJzw86gtMdXiSTzkjJ7gDvMPsfdITgdYSCajvvtnU/D4hzDiQbEMLoeC5mL9EWLn6WhofYYGhwSUwecPYo77F5ct5n32nz9SDiGfXTSiIaBgUfDhCCArB40DE0ERCzB1q8Nf84O5OY0/DaAXwl9jgA+e/AgIMDREC0I3FJCNcgWGyDGG1jAurAGg+FNw5i11tH7qXJ9w4AYUCdc2AQEgdtY8/ogLhue35m7WVMjz0g4pnxuc1wviaW0UsKiz4A4nhgqNMDrVe1mVo0cpGpvtxeSuTDGr8DS222w3ooejF10HY42nqeb124wp0qhIN2+rMDBlgZMmLE0use7ezz3KL21J7fc/1Q9qZI9QBYrOhACIgjYiFG+2AMDoTcHTDxpOLGFr27HwfuTtafg0Rh7zF2Urii7D9g8kadT+25Z8SRhPsDalBrpeOlFaTobxvD8oFCgAdMXg9ccm3L+dgHuEIj4r0OFpsDrTbbMt4p/Jnrup2tyX3QX6sYQjhXxFWbFzhSPlGuseRI2lvjDzaGbYJP2hh+TDXT5nOscUvm/DaIS+LSiNr3oE3bd9CmL4wOOrrgTfEy2tcTz0v2ovV9YMArhzUKDwdtIr4oltvZQeqAqEOkT1jqi+tTEgZRHjnoKBdcbYfb28aapvqLkS9Z7ZK4kZdwcsD4hNTCfluPncojbZ0j95XYMfz++Onpi8cDUKh+rI/1sT7Wx/pYH+sPXfcfMfhYH/j5w9eTcL9PC/dD4yaHwuf/rB4l+jCxIJDd898f/ksK5dDn+/t4th2+hd/374Rk7j3Ovw+P4WHkmtL8ONTOvO8dB7hxPPxDms5hYB0cvmWzvQ848/798eZhDjV+6GnT4R8inA47b9tH3d5/qPGAZqdvX7v3i9khwqMU7u7D4gXzeGBPpfB/6Nsv7w36LqZeuX9vwv3njft9GuSH90KC79OJOHSAd3j/+3P3+dS7VIHd003/0AUrJXAcW16ec8+kisYtnkOn6CWgH95nAUm9I352Lww797rtyRik9haE4KGSazcOVIFnCPPeseU+ndtDJh9sId0Tg5gTGwl/Uswz+OKevU/vfUjg4hA8LxUDBjeur4ecjx1PO+4JYe7E80DAzqGSo8MOX8OpumSIm8NWKvf3dHwoXBwocXb5jIzXPS0MuPpw7aNiLvrX0fnkoMPwHRWLexk/Yu6IWqD6RWZx3Ow8I4msQ/CS5ZCw17Wd40UKv4dMTg8pbrs3CMv7bM84lNa9XtfkGQL+NZxlavse5ze2vu51YYr6d8Dh+z77u3ruPeYPInrdXifFI1M7koC8ZwaTe4WHqb59r+CNi8+9fbh0/Ty4z9p2KNimXfxAcbzPYv4Q0ElSP0AGLKR3HnJ9UNBzWeHeocn90CmKTEHcC8R9zwurQ5TwO85ezLOa7Rlb7gWipMjqnh4GDtuEfcwQwBHrIQXgl/Pa8r6HjBAX/bjnG+ghuk9HEZT36eYm4YO6JaUaHNUE1N8FO0Wx69qNNFjkeaqhcliQ9rtXMC/YRzXlgw4+HBwQJCziUsjRAdOAISwKAtA9TxRJjKhlf2e48UDCDxijA+USgOWae5qbDzQeoAQPJ/rv5YYkDqVa3u7lYYntGx2dgxCegmuFEglSbu8Z4Y7wUgfAeofn1wNiITwl5hW19+V/n8vEjKyte/oCRurbGR7jMM/E7hBcEg+S9t7L8aHsPJD0ElPDFAezwygo3OG+xvEfpbnu+YFSrC2B2zhNeHBPDxyIZrBgIqXt7vHefKDFTxh6D5PC/emXR9GhRBC+3+ti/d+yvt8DQwYiknv1XicwL4bBSsULchZ3bgx8IfHoMOcZSSu3hYr0UDzF8gmNd14xlMSRZQC9j5R7C/56uTrgZ5Y8dgI5NhQfHX2I6WkdWPzpgNi8f2P+icHFnYg9JNReC1/Fjr1l39g8jor0XuNKq9+QOHQMmEMvBWPt74ffJ+H+9B+SSAmS/d5LwWz8LnTv2D57vdt5m5hzIPreS/HgKyQMOeglhr/HwGdHLu7Y/nz/U8QAKppQnyKLbMsFx3fls++eefqeE8++Yi4CR7D47XjY2aHf+97x46Xvb9TjJF/evC8oefyOcBjng8Ff7vvvHUOc32pwpvzNoR9+N+z1vdf4zql3fAcwJ15Ih/rTCez1OP88fnp64PG7IHKgggGKGHlXIiXtc02kfQcbku+yNMzvgN2WvUXiZPb4rpz3XTkvJG5UTlAMHoJ51c7/3rXtj8b3UIlvKN583j8U8ori69BzCPpuEG3fwdwdGve0xk+yicPuIRjfzOrKdefDY+zZXbnefM63csehIeYh/n/3wN8h4MN3Q9/5HuBPaF+D+nLXvx8eGrTC98D60XCK5MpSzwiPfbcOuoJPPnsjPek7ygsePIl+j/jrK3a/B1wQWOL/PaAeLDrKUP9Z4S4KuS7fdFDhgIjF18+6QPC6oO2J52OLdo0UvxtEicU/r+Lq+vkDg7mLffYzPpwtvqLrMNbw1RUwbxA7Kf+7YNy6fjh/PaNrz/Eh0OAkm0gS7Tq5tuS1ayfLQ5RTLHHper7fBXGL5qmrNKEuxntcbcbkQVUEdfH6PQR51ooXJF+h/HIYwMXwcwb8iGd1w/ocNHx2A/CP2Nx97rldvR4O0b7a9RteNZ5EBncyzigfduNc+hxa66QbYHfX6SPd9KJyw2H70ENPHgbo2+8EVqh+bh3OBRsePx09/efo+YMjIhBH3efPKRJgivGo6yEsqH27vF3U+alzOTtevku+J/h1dO/479pF2eF+1lXsoc6g9vAkZ/IcJp6iTx4i/UghsyMpbr7i12e95KebzT+F3yPNnq4HEXTt7x8JuM7UnGDzEYX1bgDeutl9j4w5O7r3xKCLpS6Ix24aC0dCvI/u9VxIPEnu3+Vrg8sXh5Eja3y7AmclcQ9yAJy7boSBoev5jtPntLgfKfx25MTtyNO3I2N9Sfx+5Hs50NWxd2T1q4vpB6iPGQeBTH4ZvMOXH11DPLtKrLoBtZLI8xHyPtgLWJ7i4th5XgSOjkC8H3WN+qJrjBNlv/VSmoi3ukdX7x0oH6eEe6bRdtNJszTeI6dAuXePiP05YCHNNrlXCnBdWoAfdbGGe0SQ85FACEfUUMAUwBEnEJnYHxF+IU36SBiwyBzcM35T4uZeEDtdZkhinj/ihLKLl64wgHSzzTMTO+K85N7S4HbUFXB/z9hGENmRJL5ceyRh3yXeoWLcZcS0JjAo+90Ya3FnbOHq3rXPPStznutHl8cX14Ayoouynal3aqA76vJ4PWK+P6J44J6Jh8sVHP4Y7jq6F+JP5DLTrJN94p4XDmS+qbje0zh26yNTF11eVGZy1iV4i6t9YkCn9qLqOXO2Iiwo3juyio9uNi/flZ5L9gMEH/fKxZbE/8AFHoWJ765tXaFGqHcdrvhO5JoThUeICKbqE4gllesjaeDhep0ivr9bloR1F/OOcKc00Pd7nlOOiJo+koZTQLgfCb2fuzA54vQH04vc3iNpLao/sX2T4WPHl9837kdd2kF4hbyL7n/PJyLqOd13tu6BuHTfcUyQvFn8uI9o03vM9Xu0y4oVxI/7N7LLYsOfnIsuMCj8KXjS7H9rf+7/fKz8sXxzr9T4n+bHv9He+z8kLn9GHp6F+58oDHLc//id+Hoc8Z3jHp3fs2K4zzfux72OUQ+wc+zx/nGPceyL3+N3nIt3Kdz/MDyjHPCBgX9vLI4jcdtHnN+2Vo8j9YTc8nf//nLuxOxJuHd/CfdjoSCOPYx+fe/heeUsho6dFQKS4wd8f9/nrCILzcNxqLBJ5Mti88+Y+Yin40TMzXl/sMXYEj9UQB5LuDfiJuawccwsxH9fDB/nKNyPwLqjfj+O2IiPA/OB4PE4kPck/B2jNeXB2wim2OcfGC4y1t8RiHmpX1h8suRGFJ4PeN/yGmIf8L7SCwESei6SN/NlxIOO1yMPPaT1RpSHQ+05FnqnpT8dR+J3LQ/oHpAfgq459tQJSF+NqRtp4f7wLFgfbILA0vSPjeIIIdZjw3JBG+obIpa4eB4bBQb3HgI6LY7HQgPhxDEr3JmGf2wQl0ghas3wOPB80r8HOVbHSrO24s1HmLuDEPW5zx6vWHiwDQiULXDdPjB+PNjrP0neVvF2DHIc69+D7GPqwuABE13HkdaRkHdEJB0r4uDowcjNRM6OQfGB5ugIzQ31/kMam9FyQWD9yLC/yBUPAGYfsMEFESpuj0UwhPZ8cRDifHgQuCQ0tlQMH0B7A+oVHSRZ/D/wMZe4wI2xWwswXz7QtqjD/gNTuw9yzSI66thDc7IxfuB5BtKVbq99cP6nMk9fPJoI5YFYFnK6f16AwBC/Q56z2BXjHcoW7Tkklmi8kVha93Gfve9BzLoBPj4on6Hvdo2xflDiZt1Ls+Oljnzx0PXAmiCkg4S4JR6SXQ8Kxh5A37sBeXywDyEmHEnxegBquQtyhBbDB4ZXukYOfFB6ykOgL6H4sGBWw6ZvTh8iYty3jkO/89EMWu4fAH8eAnkwJL4PQn0+RNQoFn7sGmtLq2+tZrS6tvbdPPtY18DRIcP5g8K7OsaehPvDk3B/euikm14iOT8YCOtlv4RwP7kHhOTzZyfJ9yUyUAL7zz4PAcL9Qd+fBa377IPzvFVkPv+b2gdsnicWcURhICHck3slY3vSpX+GidDNe/LsB5lYTx6Y34nnTpiiOqF+7grxfNnvgagdBVcnDtZFfD0wwp2qNQazJ136rBMl7yfWpuAjrFEBZGyqJ25OFVI+AcXTSQJfJ1SDvtdje+JTh46frm8ZLqJqtsvYguT4wbbHCdcLHgCBKgi2pK8nnnx2YhDYZC/qAryqYU6LtRKbEy4HFjEi8ZCQT3W4FbB0IvHWg77PyQM4iDC4OaF6VBfjGKrHQdg26ASzgH0Al3FIOVF+5zTHCcG9knBPPn/ygItvV4eccFzN9dsuoClQfaRpPSDWbF38js9v4Z4SH0QATpgDTqSDgc+5s0URBe578iA0b9AeUvBJ5wHrBACY2yxOHvglxfGkKxfIMRDf4wcsfieGvGoxOwG+97XnGIgbkkMExyeGmzIUP5Z4q351sXiegEsSSCfIvl2bPxaeOiFI/IQQDSdEXJBzT4QGKsX35MGGhxOPGjrxwBfHVyeBmEUwgzTv1GUMV9tdnS/RGkS+O2HyS4kLS368uanL4A3NoSK4EaHHXpwgtev0QEq8o1g6IS4CT7phfEsOzx7aRxrE3FifPPz+n6FJWgntjyeGug35nOPLVJ4Ndp0Afktc6MuHUHxc3dk16k7ucufXZ4+fThThDonDnJZFuLPNtGtsvAECBRUVJwHCCIkX6mssG6xiTxIEsWNw7BEPNMe+GDgRmphPvH1imLp1yKlu3WaZp3D3WsxfGXtRc6w94MWILw6OA7n9WOA0X37x4dBjg33WvBxHsvkkoL5PPIfxGJx9zPRQbUg5AS7AvHi7m7UhiAO5v3ga+5VPL1cvF7pY/ijhfmys9xNQYB8b8BZL38S4TPLVGMcB/p9oA4oxloyO/SXcXz74T/LF/9oC/R/kM2DP//z397P/YfY1r/8mlmT/fyOKgv/SZ2TO+S8e2/8IsVVj9d+wXJ5Qdv/X8C5jx3/+a/CB8PfYEo//GuPyX4/ngGf+k4MI/c8b7fMf5b3/hJz/X2Xv/+Yr7P/z/9n3roU2lqbb/f5vc34yiGRyBqXRKKMsHsC33wEb8KinwqrulhC2LtobpJnuCqtWrWp7W3A0h/ysGWyEuSfQDnafUkA8JX4w2i3aVtJ5fs3QwxCus9r+0aw1bK8pPMw+u4RcswbieS2SnWs+fpTsPXQN6CNrseIbgAEp/mto/X/BWhPys2bhzJLcd7z5vyTjbs1Hd/1+7lW4l16Fe4kAWgk3dk0A4JrTaNccw9cyJLVW4sXpmk8ToBJTUgiYIPesnTODxcfvJb7hfDyz5n4mNCmuWLLxWSvmB5y1Eg9MaGAq/fFLarprzKBD5Y/ynSuYNUDwrjlnfTY6wp+1Et8A1ohCd+O7VsrHfo3DTMlewJZBQiQRAt+W+sjmcq0kx10jIzbvSEMt5WO6xgxra6HCvYQPWe5Zkm9QY6AGee5MIZ/s+SW6XtcEblwrYuJijYt9ibkoKckcskbFoaTjeI26cHnHzP/j4lui8S3hXOJtbWhaU3hhjeDP//e+xPigvbrkxMjSoxR71wxCw43j/ys5fUvAwxrlh6dw5+phrSQL6DXhGU6QrRUZbUDloOT07pJ9EFkrKfkHL9vWKMyXCA1U8ris4bBq7Fmclvi/kl2T/p/j4wxXUNwvxZ3RaxAfl5T+Nxujn/+9/bFW4hOk/s4Uvfq+9nyR2b/ELIbk1H1LvEBjz5Le0X7X4qatEhA3y/fa/hLwSh62l7BmwYkfk99FJWdIniwxkOqgpIi/knJGCYufue6KBhwjOTfGQz0b8VPBgSvc1Lq0+lfSxShUF5Z4FcH8FxnsoFzlg/0SuK9UZyDPQ8+VDHEOrQcUxyWwHxnj515OwHjR4udTK0VhcCsB/R3h3hj1QcWxmL+gY3GExKvIC0EIn0Wwz1s0Syw9R5xDiV+IT5C+IJxHiXFTnIrCf300U8nAGyVs2Pwt3EuOcPdNPNIgkICVjO+h+4XYW/SIzet/1y1xLAFis+iZI8vwUTIOIMXAfBWNdhcjnPndV9EjblaBFNO2kkJoHEE+eeAbGfqLIKaKgXXr0whDY1wyxsbin9HWdWFPlRufIuPTMsBIPhTBGvIQCuvgpc560dDjioHxsvJKUcFj0YDD0P5e9MAzOnSVjMO+oV7WfbSH5QwLfot8za5/YLEYoU+E1o/v+VYbioE9tBhQh3/OxYT7uvNzFmDrWSIhnvUCVsDz68oe6xECivi4bvQFfd7Ht/VAX0Jyt6587i6LLesKNqXzYvgbguf1SLiw4H8djKHFznXwDBRv605TWGcam8nHrOgJzMm6Ib/rBPZYURiwv/a5RQisR+Cc9RjcL4jodSDeaH2se9TfujE+yPcol60H9khfe2L06PUAXkHsjcXXoX173YM71kFf1o2x+3j+40Z63YOjOf5YD8iBFLd1D1yuB/YlTSesz6F/o72NyMfP/97+WAfJbl0RXP8nNKx1oIGhQo46bx0UgxpJrhnEzf8J/q8bE4OABRXCawawrBvB7Cu+1xUxg+BDs2ndw1arqFxXhoZQ4btm9AeJx5qBFLR8WXhhDYyxT/1K9U/uXfSLz5pHs/XBuoWX0HPJz4uymLIOBOuBA06MIdIXP2sGvl4Ha89aC+sAPtDLCWv/RuK4ZnzOUg9W7vIZMiyiH9UN64YcaT5a9l8P6HH/B+qTNYlDLQLfgPc1Qx2se+Bl3UNQW3xFeHyNyMeagTOcNSvc4VX2BFpZ2KMcBuBvucqZ5fvuIvIWQGbfNi9/41n/er2t1r/JsSsbw/tLeQnsL89Bh6zWcuC7/A3sLi9NvH4L943XXzaMm2xQBV52vuMEZlkxsOwh/suBgSkLPgJ7bDh+brj7lPN7b5QDhbi7iktMbuWwQWUj1tBSjheDDWS/8pyIqxxhWEYJqvwbqxtlhQeytcDlbZlIsxwQUypGiyT0sl4jG1/RfMvzw/SGT/2X7Tyz4bnPRogwLhH9RDl3I4RDwXhvWDi5hPGD2IPLnnVZlvktdm1ulMDeUKb1gRlfQkw2gHhszGNw8/CH1D1E30Ds2Fik+C8rsQZ7hEm3lhnMVTI37lRj3hAaxkY2CWWiQFzQZpJDgTh3vnPOx37Z36l3NpRAZN/ZIL7L+Sc0yQ3KNwegG45g3RCIcYNoThtWAhYE1kYJbwYbnK1lnMg3qKIThhttgPyI5wZIoBvGBuZi2c2bm9+Z54qz/xxD9YWLp4DPdRefZX1AXCcwKA0fG4Tw3ijxdbWhNF2JqDli2xCIcoPglY2ycQB39t6wYFaqrzI2HGkXAizvlnUfKf7ZUGpwwzDwzvhZVgY1RRCQ8c/geoOJ8UaR6UVZnmBqRBMgn8+XHS7lBtNyvhduMH5yNm9IjZrCW3kWqxsljO83SoAwLs/ifEPA2YbAF5wd7PdlRRyBwwWHG7e3ST13vYxdTuRipLy3Ybhc2igzgxzVm8qY/1B/LCu92OmHKK42XE3k8Dma8w0E78rAIF1wcPtsKGeTfaDMaDopX2X9En3jTbhvOMJ9o0wX5q//FmfBOvOOC2Ri2tzgxFeZ2csNOHHuhiJmqCaWe1/63glu7rMyXcjafm6BbBDgzsZy4/1GPQuMNZeMqDiW8s0wN2AIz7hDkiRaZvZlYkj9zolylxTI/YiiJIeuMl2EXK7WqfhRcShnxESRbujUYOKS2AYxnGwU877nsC4Mjusl2idOOEjYpxoJ1/REPFMxdcmuzAiiMvNcWSbLDWWYzWFTqiHg93Uu9tRAX6Lt//hnabmhq0zwcZGprZISMy5PQm3mhJZSlzP/zI7AN2ufFM8iwwsah5fpoYDkRq7eKUwXhb5EiDsRPyVeHKr1VORFN9entd5osTtrB8f1Us+jLgW13pHrO1TcisK5pXz+WC4rY3ymCffcPlS9CZqDrAmF03/pBab3rpdl/l4vCfqLwamk17j31ksyh6h6oqyIbgnTTC8gL6/QPle2fb9ekvH0iY1fwv31jw2E/JZobTo/by6hXav1b8Vzc2XDt8rP5ir2Kz5Y5fWvw8fmHHO5+Q9gZ/MfwcIiY7IZ24Y34b75Ltw3GUFMfc59v6k0yk3mfWrvDeWcTeC8DXC/DcGXTcEXaj8OMNx+m0C8LGdsKsBF4oIUwaYRpFLMpfxtGuyw5sRnSPRtEpKvPjGW8IrmfwPErPX9kP188YbkwoI/5L1NQwx96gfhJyQXaEwt3Ljpube12W56NEILHjcNXOhb7zHE3zxE42ZADDcNg/EmEB+kv2961CfSExGbNxXtg/akDTCmm54x8sHZZgTcoPWN+rLh+dkmgAGpvjY9/WM1cMXO9drem7+Ee/V/P1GR+Pl7RRdHuXcrmQUKUvG5Cv0ZGfCK/i7pXwUT0KoPFc/3jEMBQlqbQNP3ycFGNs/U+xXh+Uo+f6a8B+aHbeIVGgtsvCoY8aKiKJbvwuQeZT9oVfLY2IiUP2uMJC4L8YuMTwXLs2lgr4DPVjx9svgO1NbGPG3wsNNUd8q7LN44XFXoPrVhEKEwtoG4WPtA7vdKYB1X/HkoFKcqt1Xi7Q9xbsVeX754CapHRf9x+mrDylUftVIx1EcF8LsSj2M3OK2DcnAFGzqcd37fuHMiOEphVPKJCNlrs6II66wIrMjB3CwRga0Qz1YW31w+PyvRvnsJDCvojIIFyp+UzzKIj4pCcpWI4rfC48siRpEhbsPiu7UZUQIT3afCE42IhwqfM3aoqwjvVoyYrERs6grXsPmsANg1nm8SSxUcf168X/HkGd/zK5FsrNjwLn5X8RByXD4rSu8K4biKXVR9CusKMYRW7KIzeNjwwYMRAzF6K1mzFVpjbFXAHlfGLsWCeSYGR1QMlwfgpZjag8pz0GoVfPAVe59SJyY+f71s/2/r9Y8tZ+OtitAwnc+3Mt9vAQJ7K/tcWflcIANunxk/iHe3sj9XZp/dAoTaVoUoNOX7LctQAhLBFiKcBbLa4vJN7V8xCncHH4j/M/EHgL5lGQQqBsIyNOOtisEmjqQtDRcQs1sGvG0FEL5YrxJflBWukWqPqTcyHpVZO1l8uVxRAYcmhRc3HR7g+GULHM62ynSdkn5oeCyDw2+F2aMMxIHjR6QuJZ6o2HpELsYVZRj05IqtisDJjB9uPmfsNYrRLQIHW9Q56HBbAfoigB8OH1tEj9iiOF7po7n6Fuzg+G7Lh4cNl0eattiqyHWcw0vZ85Kjgj+zJcR/S/ORqg+pv1f4HqPxx5ZxEBGHJIWPthDOpvQgxWFEn9gS+owTvz/CfYsqpgpziPP9FleMrpCtOIWWfSZjGLUP18hy51N7C/a6QnuL2UcSCq4flNjPJYHZN2ebY9eWMCSw/jJCSfp5qyIMJczQxsU5lzMHA+wwyPiS3WcmnogNFeDmXsgvi0vp2bKMQy7OVO5ygzKSR+l3rh4rWG7QnyWu2Kzo9Srx0CZg66bmG0GcW4r93BC/VaEbzZbAjdlaIDFv4DMpTlmxsKXgO2v/ltBYtByx2Hb5LBsHZUjT+IOKr8bbW2Xid+YMDiebZSUWQH2RQlQaVA31yPbmMlZjLO4rfN9DOQXCI+UHIYS5frmp6BeED7eE/rup+VfW+5XWb7YMS6o9ThxyOiPHCUAOpThsAvpKErObQJ0htbOl8a+Qa9bHMh9Dzn8t/5/nVAnh/i1W+ZvsuVpyvJc05pue72yu8rrC42oF19JqrfD4V2mL1fp7+GkZ8KEJ923n521w423gu+0FOLgd6Zkt0B8qRlLctO/Uz6rzj6PVxnnEGIkzcs42VhSmGFj2WYa1/c339+GakFxtL9jv7cDa3P6iPG0vwV7bkepu+y8SJtsRnp1XPLarcThze9HxrC5HzX0Vdrb/0p62vQCsWDQepfd+reRVuO+8/rFdFcRJdbbAtt9/l8QTJa6yv3/sxxUu+V71j1AlxVuVbmbbrv3Z7xk/2OeFpskGvPonhttVJYHuuU7ct6ry+TP7V+3FSMV0myHW7Qqfu22fOAGDyLaES0V0bwOiXyPlbcsgw+R728UFhxffgSFb4FV8+NDwxNY1gYnt6qwfqvgU6kMdehk+2nb2FvdThrVtBh/byEVHVSD0KhGDChOHqpyP7Pfc5cF2FbsI2BZyNGMPVc9VAj/Me2p8pHgpfWZb8Q+trW3ifEl8Iv0vZ0cV4JUqXeMun1B5pLBi5cltAd9iHxJE+7ZQg6rGQDiyivU7xN+gSxyif6t2UPwg1DOaL9avKqZ7WJ6o8rVLnl2Vn7PkicMNhJPqbL/i9AyU9yqPVUhDVBWe/mOnI9yrvMPbShLE96rAflVnMQ2dTApid1WxRftMaD6sr+5zZcVPJGba2RVD3pihCPJT+X5LyhkVoyrv8xaV42qe/Lcd8EO2Ezk2+VvVn+FE1LbW0CUMOs0Azn1VjjUVF2oYkGK8Zak7DR+OAFRzVMljg/Inxy3V/OdcDnxrgs1BVRZW5PlVYB9hGDdxdFXO50fsNi2+I7Gt0rxiiTXMZQZMssKrKvhRFbivovSEKs0TLC96xhbBUVAMmT6hnivoAjM/S7Gq+nO8Nkib9q0K9oXaVInATwzPblWBWvDoreTAhvSxKo7tLSteBM2n8kPFWGdVR1f9unF/Ve9eTQcVRFUPwFQAcVcFC7gKNJ8q+I7PAIIUp7vKQjyqhsZgFW5Vw2BkEH5Q49byquW+CsTLUuCAmIQGLiRfFRBvaIy0PdDBEDnfp8lVwToLrSWLmAqNsYXgq0b8IPxqjZtWG1WPMyz1gMS5Agpbi1DzHSCrnsLWeXYHHWpj8WLFyINWQVj1qPmqMS8+uK4Y6x4VzNolowVDVY9zK0b70XxZ668SQaf5DAxVoxZAn1fO2fEZAKugxkXinvl9Jyvcd5jDdj5WdXa5m+4IAft8vux8xgR8xzcRWTsMzXnHeX+H+NxNnhsXcr/M7zvC75KdO8ozO9JzDNB2JBs+9vUA/06VxxGVEyluPhjYsQqLql/j26kofmpFL7y7IxQ1leudDBaDckjZmsVrRcEiYZNp0DTatlPxxAPlG8VBIDHvAKQtccUMrgSbdyq6H2ocGFzsaH4Acd4h9tnx2IPi2m2FT9WewMRjBxlaq2DeBTGyQ/XTih8vfdahr3CvGsSGIip2wEsglzt2mLUN5t+nr0vCcMfjcmjHMEjsCD2d45kdC2cZL/B2tP4mfL8TgceD+nGM/q/1l6oNSztVLD+sfq5iMf7krey/cd8BSXlHEH47gkjNfr4jBHoH3AexR7JtRxCMLNFX6ST42GmJKWf/DgDcHSC2SBFo+db2luK/Db63AwxDqF9WuyWfNRsstYPa7psHn2FSiw+aM4vQRu3bEWpk2xMfKI/5cpYPv2rc5RtnC841+z7+6daO4fLCijmrjdL5Ppzty/MIf5gGHCXvWp58+6m1jraV/r8TyC/bRj7fNvY+3312nJrYNuqmbaBefPk4Rtx8+SFEg1h4O4bmiqGDfZ+Vev/um3B/+2MnkuAMXsnXnb39l/gRs6H88iP597CwWqu1Wqu1Wqu1Wqu1bCtcuAviandOgm2XE5ZJpLOE/XYRG5MFid8kos+LEtGJRx6+aphIiLOWeZhIPOshJJ6JEq954M1YsxYbdhc0iO4q9u1mltcZScQ6TTzqNBHsSmYa0J94BNi8y2B61+DrrmXvBV5c7M6Td7/6AsWHq5bhkijh7d+NdWYyx3wmkXkwwWrYOzZJXBzvfgWGIvJbTrjvvpPpLkJ6CQ8Et+nsZkg692wiiN3Mouzapd5PwohgN3MWGcCEEPGcaMr898P2XScZu1Ic3HhKfiZ04//MqdsQEvlMMR9VOd/i59kiN4iwXQEbOwTeZs5ycgBOtbSYIuKwKw2UCCYTjOCoeO4CxLzL+COJMipHrJ+JLT87gH+7vhcFRNx3E5AQmTznPnfxnPBxERsdITR3BfHOxX9XEH27iYCDxCDcE8OlBDi8ZfsNPCgQcRT9BwSM9Nwug+XdkAadADVA5NblddIeqhdZB9eEzxOJywS81DJw/W7VsGfiecGhiTkt3wnzXEJrih2iB5vEcWIUwkp/RXp2Tj9INZgINY70IM6+hOeiXUScJ3KP3WU0k/cwpPXfhOYusR9Rwn2XSdCuI2RnCpco5NyziZM4oRlRQjO3J9HcSRuqtOAnz0nyYl19RyAW9Qzp+6pwLiPCJdu4+GT/mcxuFTgvUXJMDDvcfrkBySdeVf18t/GpGEXPp0RdBcQt95kwuIk+AnaLz2nYoeJdlWt5x4cjNBxUQHxX6H2RYRipdZafEP5ihDQpjBK9hncTgEd9bHfwTIlptR9oGLDGuMrjmo1fQvQChDcTjPNVOyWcV/RLIJU/AZztEsMGUsNSXe5UgV6qaYjE0Gc8cbwj5TpRLkGES0Pq8obC3w4x2EhDONs/hf5K7a/qLASfVcJ/RLckgI5gep+YV4EXd4TcIH6a7E4M3MrwhNTXtTxm9OnP//Zqr8I9ARKaYEThFagkwqoqv/vsVzV+T3y2h+7LCKW9JFKcYsY6URq19axqAI6suDCsvXngMgFyz8Ryb4753bPGCxyElwqrSq2RmE7omt6bp59OvveQRqnxki8mqwbe0jCdgJ8huPLFXdUPc3ux+kooJ86jNqrGurfE04ob7czqguK+qNzOi0O1fma9nIjl47LmyxejVYzLYfwCl5N7WeG+RyR3zyhk9iKBa49pkNrPe6CN7uLe3Ysg7vYSuelLP+8p8dmNZN+eEB9uP8S+UFuzdnxM0UiO9gIF1h6YLySOu8b4I77tge/teWJhL9DOPbDm0LpD4+9bU9b87IH4Q+p/1/D7nsJ9aF73QNt3PfK1Z6jFvYj8ZcUtxVN7QN1FH94C+N23zkPP3wvoK1Y79gJqbA/kgBAc7in85pvTmPnbM3LnnoHv9wy85dNvdw1cFbu+LHix+hhkU80R7lKxIYIaFUwauUtNHgEbZ+uO4sOeYAtC9ohNqIDZAwnJcr7WUPc8Vwx/tZxmhfueIkYsdiCi1LLHniCC9zxE7Q5oB0q+ex7CfQ8UN7sBtYAMfztKzWr++wype+AA9cqjs5/X8POQC4Q9hWc/zt/1qIeZc2qy/3tGrtkzcql1r71AjMXiul3mYoFdtfhcg9SFtUZ8L9B2gT7qk2dN7MXqCZbBerdmuxBEe77VrlAdo/WWHQALYp29x2m3hudyF8yRhf/3Igwxe4b90Hij+qPwJtzf/tirgeCuBTxTI76rCe/UlPNqwO81g23u9zXQ33nFy7JHiH3c8on5Im3/ilWL6F9tAfbN47yaR33UgJ8RTohVP7UlxkdN4LLaF2N2HvtZ/asZ81r7Al5YFAfUlogLk8BarkXEkrZ/LdJetQXkvhbAG0mgvgrl93lolUVw9Dx1Ti28V+WFe41V+N5GFT7WR+CreiEVKDKv0cK6YAkuAOwC4r/QXAtZv2vy3oWsr2BjK/gCQRtkYpBrzV7cBYkIBSAXjMVccPYo1MB4ZeNeVWJSJez7qsGvBorBxA8/BeT9qlK/wrkFofl/xHbXUv8Uv4TG1HJJUOP5cSaeNX7vQmCzKCgiGaqJRODsRPms5mDCgPeCZfCrOfE0ioNClpsThneRnmIRizUhZox9Zk6v/S/+hY8Pp9QMNWM4v6D1GS6fDDcVEoNeAM/1EqOEtvAS01JNeGo8t84KNSHOUswy+SsAWCigGEL0QIS+W4h00VGo6XkqpG/C/fUPSZhLDbqQyLe1BacxFTjhTSS7kCHfAtPYP54pZMi6UBMaVG3Wn0IWaC4pUu9oTSFzvmvbZwyy/3VjRBQ9ebZBgBRccVPLiwWREIjnRaKs6bf6BY7YqrwoJ5tpTWi27s+1/Noj8FIQBqYCIW5cXBeEZznSLkjEVpvdU6vP7NkFbdCt6QPOnhBPaVAX64ewM5cbjsjevq/S2Cw45xU4bqoZRHjNybOLO4IPCgkhrmpMbhNZKBaUfQsuPhxu48QMyZtA/RaEXlCgOCch7KzR2C7U6GGN4jDtbws5f7LiwK3RAjXUC7nL8UfC12nOLqrGKTzUmIHE+a6gCFdOkBa4yyAunkoOCgRfFRLe3z3OH1cMcjVc40Vqocb3jr2E5mwqJoUa+LfUNaFHMhxN/l6TBR13kQjxU43uYUgeyUsUooZdztrjxD3BVQVOXwl9nsyDcrmn9UnT4FqjtUdBGVQLHL703vtbuO8p4kMSJ3sC+Rco4mYAVRCEr0sC5DOMMNtLgGeJ8zi797gmR8SBHSw4AS8RAZcHrhgTpakndLPQRHFBi6nU8Gt8Xl2CFUU5F2tGrO/VdKxQ+1Cxp+IvvU+9R2GLJHFp70QRjZwtAsFK/v96pqoLSm7YLDBCTcyPcIPK4Vflg5pye2PFCsNlIo6lnBI8KA3zVtv2aiAfAvhmMVfTh2ZTPA35IS91CHySw7WCFa4P5GKG8hXQi/akPAr+f/xb4oL7e8LbK3FTgRuEEd8UTttDPhcuYjiRKnIxonc8+YAd9BJe27B5l2pe0GAFIM5cLCUu2FP4Old3AlbcoRDVZpJe0XhvL+FjqmIa7DHcJQXZxzh7iUuGDH7+3Liv1mqtVry1v4rBaq3Wv7cS7FJptVZrtVbLa2X/qcx+BGGybxAv+5lVcH4uAO9ZbaTO2hdstp6zr8RhPx98dn/Nrhj52veMq+W5RQnafeBnJE/ovr9+T6ECM+FnX8nTfkBc9+cQ30Xk18fffZCfCh41vm+0fT+NEIPUbvu+wrUxci3GPM3jf9/DxwJQFyEcuD/v4T2leYDMRebZ/S++ONg35m/u9vhgIDXum/JcvB9Jh4Tgj7JV62/7C+J/iXP3Y2mo1L8/7COck+bP21e4Cda9aXgf288K9/36/37uC0nfzxIQtWmaJx5JhOy7QXF+dvcgm086ezYltqVmt1/DCpR8NlUKPs2fLwqz1PE/+26aB9k+F0dmj32wOPYlcKdY7tzPCm6+qJ+FOJH4oHxI8fwWEPspsZMqNiJ7ac1QqB/Sn1SpMYTYU/ozcpBNZSG7L2BaxBMQU4K8/sRK2K/AnMeR975wqcDFKedrSouAfWLoczGhYbNgjR+zZ0Gop88cCXjdd54lhU8K5D8rVlOhzlLHLsn+mswX7l4s3jWeTIXeA+Qpm38LH+07YmCfiSsXJzYeRD8rINyc0pdSZP6InsDxPCfYpDgVmPi4A9S+22dTeQBgeTXleZHlQOVCiOy3KTDcpsaelMp9xa3RLN9JlxTiJVTK51wboPYVXSb1zYKT69zzQA7FeiSwRPUZVU8Bumz/l3B//QNNuEh+VFIkEqPIKhGISBBBJGnVdFHD2VJIBbEs+ZLkibggPM8Kd9cOn6KkCg8USPtKTM3nK0VpFiHMoFRAilnySWq4qWJPimFWbcSpLBw1UcthucCJ1hQjwf2aLKoKEqYpskyBuuJ4ItUbeJaTuNwUajovFQhhMyNY0nz9IwS/n8pcCmHOUCMiTinBLL1DvStxvyRqUyIXSE2lfjVmiieSk5TPL8SPGn6EXOb6X+rBS6lQ70L95XKY6hdeqnhJ5TosaEOdhMlUv/QqUJeHqSDcU8OlWgpcIlgFd+oxtKfYBRPVRyh/RM4gBhyE7yRdVNDwmDKXl1wO3MsAhFdT+SJBG07I80H9tP8h3A9e/ziQCAJx4vX3A/ezxCGizF7qeakRhEKDOQDtdz8/QMjcfRYdUpx3D1LPZuK+S/mbjXuq+ALERRUBCAEZBg7TLX82Lh+N0HnuIOXJyZLHgxQUXB6N05SHGpNz1x/3udQ4VBPPHQC4OEjBRo00V+edg+RPrg+IWiA5RcHvQTrr14Fbp1rNpLYGfODmLGuHxGspw6NZ3HP85NGY0KFLw4Rbf6yfRl45AP04sGA9BftiSuTPMkTVwD6I8EwN9Ec458CCCapXpp5cRnFVBiMHyIBSU/hdGiQkLNbyex2gegSMy4FlcLTUKsVz2Vo15NpSFxQuDiQdkxp0IpIz11+09lJ8ODxI8To8qAGchPHCu3AHSfRAEaAzPyd/GqsrdA4yJHdQ45tLgbHJtfdAeO5AEGYHznNZAXBANJcDwV/p933NRkOhHFhAqwgP1U4l1zOxr+kx0/yRfDuoKaKZej7NDyxcbj+mcQ5TWo4PavkYZAs2iy/plkDL0QFzthSbA8R+hpQOUr1+OGzsK/g6IMToPngGEhcryWv7Hlj2JUib4639mhwvCxdw2HWbjFsfVP1qtXqAcjCDs4MazmEHBB6zYuCgZuB65Rwun9n65cQtwh2WviHGUcHIgaGWLD1F7IE1pR6JwZTqwz6C8gCMxYEx9mgOtFgeEFojpz8ILkf55wDsrQe1fO3kBpLUozaJ4SNX7wDPSH0EyaOkEREtIw50TG5yuiPF83cA9qHPn+tvwr3+W7ibVs34vMdCGoR1v4MlWogw+8p4xYz1/pzt2//CvPk+5yOILLHQiONgtVZrjnzyN/HZASASDr4Jt+1/Uw7YX1KeR+K8/xfEbd5+LCsu9yPruf3AGP96ZpmF+7Ksw8DvF0XKSwH4Oi8Wv0s+F52z/QUTzUq0/9vr0FADXy2897+ziKz/QyK4/k3rof59Bq5/4aLgX/BpP0Zdvgn3w9c/Dl0w143ipy6LosN5Npw6buehoZDVBle3+fdrv/piCe9wjg3+kHqmxvt2aMjRYSSfD+txMSjmMzCX3F6HkZvRYSz8B2Lug6QO3Xfr+H6HhvPf4nvoGb8ZrL/zoxifOl5Ph9R7ddk+t/YOtf2cd31zeVj3uMzQOK8el8NMNVmPOPDUnT5Yz3/m08OWpj/UFa4F+0WMgdIUtzqAE4536/485Gv3oYeOIrFV98fZYSCODgMGqUPPnnUY0L8OPfAO8VAd50cyf5wNrnA/FJxWi7T+pzl+Nsk6sS+QnENCGKmNMnMm588hQayHTqEecn4QBCyuep4cDutOrOrEO+nsd1phHjKN+5A7g3nn0HhOrlFRoqKeF7qHgvg9FAg250udx+khh7W6jjEpJmKciGZg2YMVY3W9Rqi4cEKPtL+u26w1ig+iOqzR4tKtx0/hXs/bCQlAIc4uXskaqOfr7IDhnENOvDP4PkyZ2q7TmOF4kePjQ4n/wJpwcUNxnDZEHQrcAPFNnanlOj8wHSB4rOe546DOnFNjeCml+wibbwp/9Vl8W+vroC58Xs/zLnrJcijkEOUIURfUAfwJYkuqBWq/A4oL68p+jjAi+wDxDOuH5TKqbtARzIUR1ytQ7XRYV3pNne5n6MBxSGDC1YUHaM7q+TwfCPsfaoMypVmpHNX5mHMX1hyvHRo0B6ul6oRwP+SaT11oRJqhdWE/VPyinyPPSu/VBfs1u+senyPnIWfWhXeVojjUBggpZ3XAXgH8iMBRc2C1HxyWRNtS4CwUi3VZ2EF2+NhsqeO6bVCF6qYO4Bi1w+cZCbcoPmKdWzc+h9Qiypd1Bb9obTnrlxhG8FQ3cjlab3WQT+sBdSthx8LFCq+IQs/Ce0hPRuOB8EDdwCN1wF5LL7PkU+O+2vuy9v+6BxenwD51o57w6SGphx6wfJ/9nYovWrdI/0mNGgzVqRZt68N5cp3+/O/oXbgf1UEyJzZ9e/dIeO9ICdRRXWga73u/7fGxPr4/EsB3VCeeI2zk/D7yFR9EDI5Qka6Qz1FKx8Z9/oj5HBEvR2km3jXnnBRsTO50ScWhDuaD8I19noh7FjszuEjzPkPnETk/sgxlXM0QN6A5fzhbBVwdcTEChRBZe07sRNwZBN+Rln/C9iMnLq6vRwzGjpgaOqqDwo/isVTAAoetLD6znwn2uYvj0mxMjpDGWKdr6ii18ciMcFe4imp07nNHrg2pUJNOfo8UX0XOQfGaGvwl7GBzJNwMQiJO8eUoBZ4ThMuRoZcdpR7DWF0YLHyH3JTgBolLBeF+ZO35lE5JiZ6i4OkozfcRjuOPqBzUbUL5SNNwdV5LUf36SBLuHP8xPf+ojuEG6StHhOZEB80jytZUrvUjqWcK2vno48b9qC5veiQ0V+vz3HtIE9fekc5Az1dJ37iPbxxRMZP9/kDJoW8cDkG7jupy8/LBgeX5o4DnjwD7RfEUmEdN3KF7HAExt9al5qdlT6S+fXjiyBAfJE6W/B4JvHGkfO+btyMwXkeeNXMI2uLDU4cR68cH32hcj4xxPfLgM6RfxeBn3/wcesZBq71Q7vPVJb790DqUWfN/5Jl/xD8rPx7NAe8+MUX69ZGnnjmM8P2hZ54OPXSv8/3vG3cxGY3wZM5rhYDtcMHnUUT4XeMeOybf2f/VWhK8rNa3w8DS4qDh8E9jxV9Lv1bxXl5+b6z6QOQFCPdFFFHD47uGBxFrezWWj1iOLc81gHPQ7xtz8KsB2Ngw2knFAI2FpXn72gv4cdzI/HOPRjgWlr6BSqKoAT7TAHDVAOPWmJPg83m+ocSFs7cRsVYbkWLjyevH8xLTEXw4bnjU5BKIyuN6IE//y8NLYwkHi0x+jhvG/t4A+dHIxccW3xvfGDeNAM5H9VADFe7EJsdU0QtJPEYdUww9dkWYY8MxQlCN/D7HWvAUMB1r7xlI/Rj9rKHEzNCMjxsGEDWE2DRs4uiY+P24rmNAFXdOnI4bhnwGirDjD3w1AEwr+xxxwt3B3DElalycN5T4I4MEUpdc3huM/w0Ci4wAP6aeafDiibXfwfxxg8fpseRnAxdFx8SCBZWA3WOXXxsE9hFOcXJH2W6qoQbAr0wNc9g5luJC4R5p/haeFLjxGBAqVB88bgTa5XP5IuBS2oeK/XHdM18NhfcQvm34DSnHSizgPBK5RPUI2dMoneXE+VjpnzPxbxjip3GLBxZzvbAu9xCxzzcIbCjcgugJaY9jgx7T4gjrCGnwasj96Zdwfz3s57EwkR1TgGoIogFtCsznxw4Qjhlgk2RKiI5jynZKeDrPUol1zzl2vnPPOhbIgmtCxwKYySXY6i6kAR83eGAfK0PYMVVMBH6O03w8uYJVb34af/7KjfS5Qcd3ZjX4z1gsNYRhoQEXoJxbolkcc82nIQvTXANv8IR/LBF0g7EbGN7UHDhYoLB9RGDmuMGLTqpWjhu84MzVYUPPn+qnxAvZehEa8TE39Lzh39mD4isKRySPUgJDEmhMw83FPHP2odtbqHO4+uJywXDHjE/A5ccxc4mRyyGFVxe3DUKocrjlcNgQhA434HLDLnF+rl440djga17qr8faO0RcxcGD4RvqfXGglnpog477MYFPVbfUHd6huJSoIW1AzL5/nDKXLIR/n5+lmT5cp4U3wtdkv6Tq3qlFMn8NgbeAHLK9W8krq32Av0k/Bi5ej5U+fNTQB02nPl+Fe+O3cD9ueC5BKMLf1YUESOeiZzLNgCXe0FXX7fr4d15BsbfES4p93SPPMWyPhTcrXuoRcLaIHDW+MN5cfYa8X6ebG4kta/wXGB9OBIt5rHviYF65/cqzpTjUlfzXA30JxXWs+PpwcAzsLpIz6oBgbxhwENqnfPJeF3gL4fr6HGIaAysfwj0Wr0r1PE8OkeJen5PesPCV1AsaYH3k17twb3xxIzGuH9/M3mWPxY8vPP/HN8rtCnerNbcGsFqLq7dVHlb4XvWRqH78WMVwkb7/Ee4/lCD9cAPW/NpA/nDsIu1o0vb/EPzztcMHZGRcDfFEzw55RivOH8L71tj8AMngR6TC/iH48oPxzRqDmESE2Bdi0w8DDyDf/zDiKxZRW/D4I0KefsSIb9MDN83w2P0An4GadBP3X8rPkRW7TX/uQznpx5x6gw/Wfyi8ifJcrIuWGPw3T3EXy7YfkbVLKNf8COQ0sY6bNjt/LFCg+9SH69u8L0J/RKgr9tnmq3B/U+8/FFHwAyCLH833JYDrczXzz+e+BwSKe152qODOO+bOYOw5BoiK3aeJ+yYKs6btO9JeKgbaavLF/MNqL4ePJv2e1hgke4+ovZ0zjrncac2IwdCxJa5gjJAGzdWEWweI+M++q9ZnU4/vkU99NRX8gngV61vKm3LGcZPxn6v7ZhgmyDho7zZ5vJNNq+mcI/jnvvcDGL6lWvrR8IwVg0kU9xxOsjx3zAwRIf3S+/mmR3+g8uq5lzYcmextGPpDA+RrrXZA/vDGXyPMXxHPzCBC4ZasK1/8NRnObwb0N0mnafltGr9v6OcdI/0uIJ9iPVvwPuvrq3B//UMjfZbI3/5bBwIrFVhTbzpqw2oC77q/1xWgaQ2yCRJhA/C3CRaGjwhoLoCQfPPrS2xNW9HCeGoK2EXwoAnbpi0fJ00jPpvhAySUL0vjbxqGlGZEHDY8hXXTb1AJvpxoApzVNNbdPMRJE+AwC3aaIIdZRQ+aDwuXNOWaP7H2BGtdND1qjcpN09ArLQKu6VmbHtyo5hepp5CaMIjOk8jDKXw2ggUtPhx+UNz5DE6xaqcJ9mVL/2gGcq2FJ3n+/PnfiXvj3tTXiRPgE5DQT5p5MXKSIbws8Z24+zfy584QZiOzjwS8pgzKE7AZnTQ9ycY5K2v7iUv+TtGfvPt2ooD1pKnY3wTFYSMTT6WgTpyczfjnxrjpL25PmsTeaJE62D0xxO6EKaYT9x3n/BPBnmw9nDDxPDHeZJxQ9dgEBkT38/rv5dbkiYtV4v0ZnDrxOWmCAoOx80RpuidNJleuHUxOTzQOazBc2ODzfULVE2UHKMBcPjxx4u76e4LgsgHUOcG/JwrfSw39pME/MxMjglNOuFplalTEZyP/O4u3Bo9n0ibqfalu3ZhKcaXy2xD6dYPot1wOCY5SeRLEM1ufVI+VdADDd1SNftxIn0j4FQQTiQlF25D9oUnj4UToMdrFA6kLGkK8m0pOOIxpPZXphydUzTAaDdYGbu+U9hB0HtsvDZd0XH3kejgyOBP1QPj3W7i7JH7SpMmRI8yTpt7wcuAmzpkhFaK55RqUtgfxs+iD0hjIIaPJiwfpeQrMJxwoG7yQZ9/9IKosWF0hRjQxjtx/cPkgGuoPCT8NvbDIZpGx/6RBY0IlJyYPsHBv0DnkcsuR9gnxzAknQJn4UoRGxUUisxNHBM6suoMXxuYTTrgz2D9h4q7WFzfgNmlBdyLhqknH6QQgfUm4n4BD84nCnScMH1H1d9LUheSJwpMcJ5FCk9u/IZzhNCMSow3eXys/n2T+mQFXCxI+TxQxpfVHTmAcE/UsxkXBTc4fhhdPBLxTgxzVoyUeJXHQIOxp0IPmSUPu6W7tnTSZ3tXkh6tjtx8K9cvxyw+lt/0gLixEPmrQcZJq2O3rJ0w8ThqMX8JAbBG/Ui5OFNz9aPIXXtqQ86Op61Q0RyegppVy84MYgt3emBtmm3xP5y6snbNfhfvrHycgyfssSxP5zutb+9ngwfyvr38Fv6u1WqsFcuUqDqu1Wqv1dWv+wv2vXy2/906/yN7Tr9q3tXyxWK3VWq2/b634ZLVWa/E1dbqKyeKE+2lGuJ8CYuvUee40wJHTBQX3lDn31GgDuU+L/+4U2Oe0xe/h5WsLyEmL/v3UmKdTIpY/nH1de3LvtuRz2NwRfp6Cg9YpiGcrJlw8nKJYasUfHE/BmJwK+fSNz2krvweFd586PpX8buE44vY+jd2kWvF47jTCe6fG+j5hYn4qcUsL6yEIV50aeSlGD+I4R/QFxNiJR/wXiZ1TIA+nxufNtQ1yFMKBIXax/NBSzmlF0hag/6dGXHO955The6lPnzLP+OAL4q1WnKHi1KNXuvx22vKPAdrLmXz8Fu6nGYF1yhCr+z0n3E5atDA8bXoKLcKeUySoTLGdcuKBEdCuWDhtYQRCEfopEScpnqwNLnl85K/1Z+/TprEptvjzP/z6wYicU0e4/2jJZCd+lsVbKz/YnLb4pn8KCFESI8yAcSoU+CkhSKn4Q6Tewkg5i91TpUlo8ThRcuDGZab2Wrxg57jkxOWRFu+35EsuVy05lqctffCUVq6uW/IAzw3S7GrxnIkIXc3PmfNbGC4+ualF+NySffnEU4vnFY0XKA5nL0taxNDYwi40uH51Kl3utPT8WsXpqSJIcnFqCbXasgt31Y+WoVYYm1mes3BFS8aqeCkgcHKuLlpyL5/BeIvnaYTXKHyycRAGB0hbtfJ8QAryFlHTLZ03Jd2Ty18LF81a/zltyWJf0zki33ODS0vGroR7kT+xvvQq3Fuvwp16sUUDhhX50nuo0S3P51rAPi3luRbWZE+b4P6I/QoBk/HWfEf3axni1lT2tcTB5z1LfluA/S0mp1J8uHgicdI+a4HF21IwKfnQAnPc8iCXVoS6R+OP5rLpuVog7/jyo8V2hK+0mLUA3rTmvAXURCswHoh9LcAejXdbAQ20FbGvNT1qs2WoqbjCIexdVEf4aIfsINwKyCtSb74Ysva5kLwg/c76vg/uW4E6sWXopS0DN1nsbnnWf/y4/rlxP3tfrqNnzT/fZZ85cw6k3j/7eL85+zMXHPKsZmZfpOG18jadZWw5pWxgivLMOftMERlnRBzOUHGlEMJZUxZlVOxhAlIEwplmU5OOz5n7XeaZMyZ2p0CMOZuy9py1aPLLYkzL4ZmSI65eTgUfyXw16c/PKAwxOTxTMKP5/BkbhjAou9j65fax1gHhGxdf1r8mgHX3nKYdj+xnoL9n4GcsR3gMP2dMIztTGpZaI00e06ivZy2e008ZDjhzzjzzxJskAM6Q/DTlXoRiQK1ZA94gnDaB3tZk+JXrxURfOWvy9pxpcaBwzNUzF0MBm7na0PiW4IozoHedNQk9BOL1jNFKZxJuAE1xZuVixW4tz2ofa9kud0S/Ob2q4Z7A2pmgW7Xh9Eyqixbda4nzfv531vrzT2XOPJZF8Jy18CYmAZISQIg9VrtRf5H4sQUMFDsnUM6U56TPfew9VZ4/A+xYxDqNgF/NNwsuLPFGvz81NnREFJwZ60l79wwULWeAXVYsovtbeQKxAa3fUwOfmLiR+e+ZJ+ehdXLmKToln04V7vSpn1NN5BjtPTXER7Pr1MhxlsEopH+fERdx1v6dGwznhA8rX1r5Aeltp4ZnEc7wxdgpyImnKN8JwwrKxxYdo9WtD65RG0+NfH4G5hC5NFTO+y3cQ8XVqWcDPfVsDmcBAJ7H3mdzEmfzFLanEZ9brXA8++bwdM7vnHkMsbFweBoo0k7nzBOh+6A3jfMeak8XVOvfjU8WzZPQPu3517u6mviFhi82TxfAg8uM41PDMBHTj1ND/n3POf0CPg7F4qlxkEYwHVCff4R7LLIwr7bwWTvCXq/rfIF7nKPPtucYt9j7tiLE1fN86xnnkf09zz7nEd9z6/nt+eVL3ae9BIKpHend15/PrbFte9jXBn729au9hILWhx/bf9Z5zHy0F9iLYn32BXk6j4mz9v/+3suXiL6dfzWe2wE66m+L+7x7zeLXq3Bv/+/nuZPg82wQiAZ4zjSmbNDO24CIbee/P898dkrt0daDeU4A+Px9b4rQPj7/PLsNCnEiXufO4HFO+OULOi7uM/ZyjdXNcTsfD/W9tiOK3JxnYyxhivE5G/9zYhg6b+Xjee7Ydi7E7Jyw8VwaupgzNJHGYf9cGPRc7OXsbutClR04qHqLsZ8Rz+fAwHve5s8/J/By1p7Fo8QT54KP5z7159TDDDbbyv7tfD7OqVy1MdF8Tojk3Ltt+b1ziQPa+j5qfgkfVUw69XHu3vy1dfF83hL4sc30Ia1ftenf4QuI9qxP521+j3OBO1if2wzGCHvJHsz0Qgo7n8+39Zo6B0TtOYEJrX+eS/FoYVx3bhB+uf7jcwnVxn4/V/j1HLmIAbjuXKp5BgNQftpyT8rqs3Nl8OfwOtMHhP4zw9OCXiJrpM1zk9Qnz9tKrF0tqvfrn/+9PvjTLT5XKJ23Z4mXa6LnRIApx84F4j/nxKAganIA4FY7/5wrZLPNhQrmeZuISSsfH5cApUFGi+95mwEeAdRzLu6EoM6dQ9ng2taWsXJGxOFMyy/RnEkMtoVn27zf7F5twn9J/LdpgX2O+NEmGlJb8LEN+NziiUoSuOctpg4kIdVmxIU07Al5JMUTdUnQzjeH85aALSd+Z+18g5N46tytDaqptIV6aMvYdH2lGiGVX/JdBiNnQszOmUHpXOFO7m9Cz7m8OHhzxd15i7+UQTjAjRfV2M+5CyWh7s+FRn/G4PNcwCbMcYTAJvPwYX/z93IHtXOhT7C4bAtDWFv5HsQRd5FypmiMHI6Yy5pcfJTnz7hn24A+4Xxt01x63uYvhc4Y7spdOHL54PLDcAKHA8nXc6Hec32E+ls2TqgLui13cdzmL9KQCxxWR3B6gNOF2uUv5Rd3Udjme5kytP0W7lDjob5vCo2DEMwiSQGNj20WTHGLxCcJJUqAZ/1FYgM09jOJWBXxxxYVMrS4OWx5+uDa3GSaI+pXm2+E0pDEftdWGqWCGRGfyJBhFXgtj3eIQeysJeCrLRAVQT5STLkbHJVHWnRT5ZroOfM9K9zRuLUVH6nV9MiT8hwnKkl/gXPP2ryoJmulpXBPU7nAaRO3tG2Aw5rM30K0/epKzKe17ls8fslb87bhAqJluxwjbW868bNcuLQwTmPzofVj6XKFqmfBprM2yPUA75guS5Q4ifgQ/BNjCg7kKudwF4DKRZeISbAOz4QcQ/a3bfVuvkBpA1oBiCU7EGi+chcUzCUSc2n8878LTri35ydALjz2vwgRR+/2XXi8dyF8foEWkAWcRv8uAsHvHc9lWctuf4BtFws4Y1Hrov2NMQbg7GIVd3vzjP1OxLhcLLLeLMJiUfFfdi5ZgD8Xy1BjkXKn6ZWL9t+BjWXh1TnH849wvzCI1QsFFBeCE1bwXCjguzAG7YLZ8wL090KJA+fvBVhIFwsCGPI5mscLD2Lg8ooMShdgnC6AnF9YhjEQ8xcepG+tKy3mF74D8hybm4XsLiLWgg/Wffy8+OKGaOVPhOcv5ihqrDG/CDgX2esCqEkrn8XA54VH/Vh50FK/F5716dOLUC0Sas9FIFdbcHDh0VsuAvAesxdZ+jaig0J4+sKzzjmeuwD8QjSfhE80JorNr8K987+fF4wTIevXQR35e86xmdWJb9t3W+dajMBnUCE4D/vJvHb4/Gr4uQAIRl3v55+3ZVsuDM10GTAyU+ydjF0dP7zkzurI72bPpmJ6TtS1SKYd4BlBdF4IubvwjIMWA8vzCH6gfHUC6qeDPX8ekbPYPHX0M8/bQt125sOxF23s8ubC0NuQ4crUF0N9Z2J/3omHS5PNncj4C9ETHXyoRS+HyP07ur/nlr7TCeM6Mv4doYd38H56jurIDuhjx57ThfXvSLz0Gg9FuHfmYGjHEOTOEoj5jgcopGbS8SCuzhxBwtnViQ9Ctrg74Odt/vNzBHftwDh3+CZGiogWgOHQ3BJxcUX7uW/eOsqwozWJjrAXKOgvOn+IWyTXjtEHJO8drAmF1gGZI+Lcc9RmTmwhfgIDyDybGFVH522j3RKndQKGEmBg9RkAOX/Ofbi3Y++b51ztgXk/N3Cu++xlB7C5ZYxxB9Aebc8eoYliBo/nHH92DEIZwWMH7BdI3DqCj22lf3sMZSaNgJzXiSzcEXskHur4cSPRG37+d9n+LdwvFaF02QGKDAVLdp9WRuC8ndF+X87Pn4Xu/M7Z4+5jalIdZw9nX/fZS0l8aoIh47f7zKUkWD3ifgnsc9mZXWJTBG67LhEMoAXRyefX3euyg8XDzWvuXcamS8aPHM6sPnM4ZrCu4pKw7VLB56VBlOXy2soPKlAuHJ9Inx1fUOyx9dgB8GwY/i4zdQOJB5eXuHrrOBzg04StsZIaYifPzabLCcCGXE0K9l22CZ7uMH3CxRYiOBwsi/4K3HMp4EbL56VxsMr1D8q+jsB3BB9eCvx5yXE86jOBo0vqwoyqfaXeLztg3yc4iOuNHE4v2jL/XzqaROSajn4+yROgOLxsG/QJ0ItYzuoIPE/VV8fQKxXh7uLzQ5hfCvytYkTgFa5WXZ5neZXR15cdkm9/37jnCppw5rKTJ8vc7xShEkG/dAurlTc8S8SXhDi6JMTSjOh0GyohSC+Zz0h728w7bbkRX7rvt+kYXjqJJweYFjPEMP5cEv5ccsBg9plpPkxsLtu0+Lokbs4uBeF/SdzCUHkh8+zEw206l21DbLh4cvlt5/GWwzLxO0UWubwTBe0OtC5upNxKOLlk4ksSrlujrT/4JIduLe7vt3qXwCKFCDXkd8DB0cWINvB38s+z3MnscdkRBAZRQ1Q9XTJDlMsnYiydWF22mUZCYQIZlgkuuGRyc0k0fq0GL6jaI36fwWBb5nwuRhfMADyDX6oPdeSYcmL4kok9KwIlDue4CHyXHIwY8UHWKcHnZL4IbSGdcdmhuf9SePaC4M9LAhts/XFczVxskLXG5OdC6B+csCVxxvXiDj0AX/IiEdYTOb1CCVOnx3PxtfI/1y8/fj/P6o8Oc+EmadU2oYW4yxuqL6Mc01Zy9Puc1xv3d+H+rZYi0mOsi5i2toF9NR/m4OMil1qQ39W/dmTbv0EcLjrfF4fmHCL5CP0+5Pn2N8dH+y/D0qJ4ZE48cbHKxZfw9oVn7C8WfJ71Imgp4g/UFuxL+4v8mf39LxHuX9wArmII979gXS3hflfztidDClerBrZaS1ZDf0MMrlbib7W+oyZZ4kuUi0jnXsyh9q9i5yBiXV0tgI+A/X/+9/rQT9iQbpgjV5ECY/neGugrD3t999bOulqE8ATPulKev/JsuFfOCvX9yiOHvji6WoBIuwrw78qYL2m/WPlBcGDB55WAIQvevkpsf4VIvYrAq/OIw1WAL1fLIPC7Nj69+qIB6Coibq6+YDi98uhXqJb5+O9X3CZfGeN+taC4x8Cx2j+6dD1fReqb6ntdPx0US1sY+/sf4X6lNMOrLv/MJfHcVVcnWpJcusz5RvEhNWhSDHWxApFson6/BN79PL/LJK1LxKWbIZ8uE98unUNLfMgzu/m4XRlidYUKd2lvg28zccx+1s0X7Mw+XbmIrgCCgewSCnbGhm4+vzC+QBtgsu0S+ELqsRtmXw6PLv67cmzU3HWZphJid3d2IVyF4MSSS4l7rbx1qfDepYHTWb+6OgZEUdeV4+S9GE5ifezauTCHG2GvHEa7OP+Z+kJXxhnVP6+QnqLgRKzfLoOLrlP/3T+9S93//dkP4Y7k7dKSay6H3dmeLtXoFVNjYo10aTsuQcxTwvaKwYAaJ0cnXnWFWuoSdSDwRrYOLi082RVi3rXpUp9LhZy9XbHfzgr36ATXVcihqzTUbjySvXQKMVTskMKx60/+MRuJ1ERixnThvlow135fXeb7rmeTdhtA14iRyPGxDAnwmV2mFlFfuxFrpzvf+HnXhPW9LB5DMbPo+uvOOR9dQzy7xp7TjRCbruf5X8WBiF2xcdiNiEMfLph3Tw05szs/XrlEcx/S+y249u2N0pk+ce96PB+xf0bBJs+7jHB3nLh+/fma+P46A4i3791nrrsAmTpOXaOAQffs4n+bgOx/bWk8QMKumc+uATFzbRGHzsrlxvXP8f/6XXxcd53PuJgYyfCaioGAB/b7jiDcwVxdKzi47BKYcGrBglnJl2uUDIizrxlfOdyY8giQ17VBcF37iqiuUfh3+ZowkbhwLul3Bo/XXSy+19Zm0tVzLMXvGvT3WuLBDmB3V1gaT/qI8S52izeXodQyUEh47IB5C/D/2lBj1z6DQNdjWFf6xfW8Ls58xJ6VhyxDFlM3lx0cJy4/XHf4HgZh3le4g1i57jJ8yeGwq8SM4xbgnNzziha8tmCiK/Npjn/fhPvbH6QQV9ZVl26E5HMdXjReE7+T4pI6V7PPCfY1cx76OTWoXDN2UeAXBxnOf8d+KW7XTMyuDc+zRSzE/4qxGRGc11x8hDOlz6W4XofsS8WzI2DbGcKuAfxKn18DtkENl8IT0wivBcK/7sh4FPPJkLQk+LT4ITG9MnwuxfuaiAObL8V+VXh78BSC5Vz+DZi67jqN34JPKpZdOo5ab5B4nhsOrxHfjHG+AmpXHRq597lB3yPnUM9kYpp997Ij94krtO7QoYXRE9eAVpEwfS0ItGtQb0iDzTXKOx29b8H8wQ11xl5+bcSSlDdNh1lr6rpr05MaD3rj16Avrine7Oia5JrSnVnhfv3FCx0Yro2NWXpvEfZT06Nm31VAPJZ9XYFkG3rGovzg8rusdXO1pHW8bPmFV2eJbQvE9Xflj3n0lUXV+dVfyOc+l0k+Q9wy+Bc7/1eBuL/6Ajxc/8MrNg6YvX4L9+t/PNirtVqrtaTreRWD1VrhZhWD1Vqt1eKFe6bYb4CFHnbDEEl2nxv3eeF303nv/715lu2+Afa68bDFd90YiPnGuufz73hk97pByf4ZwwD5/bPR12dDfIR43Dzrec0+e2PNB/OOa38s/NwQNaXm45nGgaXZ31hr8pmu72sLbji8PUeqxWflu2fnmee8HYg/PrzDYfxGsjVT3zfPgo0LFHY3nnWLxtC3/3D1c4Pg5VmuoZsIdvv2BiuXe/egednuMYhY3wvSGM9gTXbp/mKO0zN9plUnzL22nz20iPbcs1EHKM/dPEfWYQExv/Hb7+d/r078vHGFgEs8hGi9eVYE3XNeHNy4zz3L5H7TFYaIZ+J9qphcsf5MiykKLDdcw6SGm+e8MLp5JsibsPkGsMnNhQZu8nlHROXi+yw3zBsinmyOnm1FzAmVGexJceKaJdhEbyhxBoidm2dFBCgDn0ZKUh6ydXQjCb3njJDjhjjp9y4g+Lv5epMGGQ5XIhY4LjKK2huBT1isP/uTdHaPG0Vg3XAXDI4Iz+35nB9wOB7+/CvdZ1m8auL2WuPrZx4bksBkuetZGFaf+RznGjeDDZKvER58lvugJnDECyuhnm6UoeZG4jFu+H/GeMB9x8RfzDBM/u7wFyloCRxIfM9d4N0YhLOKD6mHC+9dSzHqKr49y/uaL4aeMR6U6v5GuDi6sQ4E3PvPgH555rXfjcC7NwTfXnexuuC0ipb/HDfm93wV7t2McFea180z8cyz8t6z8lyX2RNtrNLnTPOC95UaPLWoZzqCuGKENBsHl7zcsztyExIb/Pv7rlBWfe8S5z0r+OH2o/AC/s0PhEP0ewETGnGqdgvi6uY5AHtSHIEcwmJWaxIK2as57HqsZ6NfPmc9gxjpCOd3BLxp52n5QXn5fX38W0z1bLQ3EBc7sE/PxtgjebXUIhJn7X2j/YgQU896BnFrxQ7Sr6m++uxcRD0z/bZr5B3rs89g3oSLA1cQZi9YJNxzOaXOUf8lAzOE3igXmWpvUy7ZoDp5Nug2JFdWTRdjPdsvcMw47gDcB/JaZojJCHdAtJDiAH0HEf7PwFkW0ecjTlBRbhWRqP2+yxpPpNB8ROM87LcKqm5ke7qe9j4Hiu5uxNyjdYMSKCo4rXs8G57pRqyPrLjuAIJAit8z0Bh8ifw5INfPHsM0iiEfOy39Zl7vhu6viepY/aTrKZ6ewcsCy5Dlw3UG7Nz61LOvfV2DrrHyaTfQXuQyLCRfPr3TqrMC6u5WwzWCd7SvosOG5fNnQz2guuZTuL/9U5lnulhuhUK6JTZ/mwZuwedvuUSBRXOrJPyW2q9L232LAMh9rpvZTxCUnB0xGsqt53ckaXve9t7G9MMCcsP5tx65tr5HEo7zs4hNEBu31tgp/t129TqiMHBrOPtW4AwTpiOJs1unprN+3HZ+L6Ru1FwabLlVmqA1dhQP34byCtD0UDtJvxmcsXjv2nFx68uvHsN3SK3fPkcYZEIGlWcbfm7B+tZ6/W3Xv55upX6txMXUL5//t5jLLJdvGLFnwrTCC7eevfM28iB9K+Wv63fWLaMdbwFdecvE5hYYOCUeMMX7j48//3v98uetYOCtofBuDYm4DRBGqA23QrOOBajbSM1CI3ktfqH7cU311oiBKAUa8bzbwIat4enWww9kvxslPzdGEoDFk8HvW8O+twF59+Uc1O9bIC+hfIDUog8eJBuuDfUeEsNbME8hAzSaLwsf+PSrUF687fnzu6WerHiL3edujTm24OLWyF8+/Dev5XPurRF/87gMRPSbj10xetmN57m3HuL5FughtwFxBeP9R7i/EYoEEPX71QpfPSbWvYD9eovJHUo088BVtikG7d0T3utFym2MOLw1/15grK0+9haTy4XVWW9Oefzu3LNse83rrN6S5LPnydO9OcavN9/csH2iZ4hJL7DP9Yy95fl71QfUj7+qp/WWjL96X5SnnrEm/3z+Ktx7inC3ElwvgnDyFQy9CM27ZxAwPT+xc+cLwJ6wT28Bor7nmbceeD732bPnQAO+e+eJ4TvC5jvt2RjkAz53J+G0R393Jw2PPQGDvcy7AQMJNDz1PHlH820R4q4Xoc56hucpbArP36HYzexN8dCdL7f3wLoz1Hz2+bve/+Z/YRJa0yjP9uL00rveggRnz9iTe7R9d0o87jRe9NE6Hr7fWS8NBH/uMvvd+XKHMc9inBcpan1rqBeRj3sChnrhdt2heu73+z//ezXg5x1liEP47vd31FTcywuiO0Yg3VmbJxDcu54udD9suusp4tF5PtfYso2L8eWuR+yhiKq7Ht8s0c9ue/li18B49/Hv3wj/qSK+Q0Uw9WwPKIbs6gpiwTjo3EnFQuHbfU4Yxu4IMf8R1zsCP3c9HlNIbO4UArmTfu7lMezWxR3x/N0zzwN3PWBYcva/e5b5wuWMO4PQv5MaNyPw7nr4QHwH5AARo6I9Ll9ReOwxMSLwdteT7eB48U4S7j1B/DN5drluJpYKju6YuvuMVXeWF1n8Enx9S/nC2HQH9ByynzhYy/ndU4Zt1x9JwPYw4X4HDlt3wKCn8j/Cwc98f70DbJqpZQnLIUNSTxhgOQHcUwaHniDY3foH/4aCy+9dj47lXYAoljB358OnDNbIPt7Lc/idFN8eERvgAu5Oyf0dc+4do8tc7cDy9B//3oW707hdQiGbeo9oqtT7zzzB3fUYEkNIjhNMUhH3BH9cgmdiQX4PnCOKRkG83QlD0g13PiVCqAav2HpHgbsnDG7Z87vvixnm7qSGIQxZ2XdvOXuV4pAWm18XN4yd7HM9glCIWGo1R/oj4e+ZqUVBuN/1MKEjvSfWiYI3CQd3wJmucLljBJe0390zM/z2GHGgNDsu9pxgQvnkDrg1I3Hu1ivTxLRY3aFc0qMvh+4U4S7VNMllzwqXCfVOXQqg+BPrrycP9lTjFvm/x4sBtveCvCZealFxe6aHebcnk8Mm1Us4fcD0oztmcBR1S0/RGRK/MReXdz1+sKKEHnkxygyyd0Kfd2N1i/QA4Yxb4HtK9Ir91qiXcrXfM+BZ4jmthqnewfGE1A84/xCtq+G+pwl3lLSf5/h8rPVV536FP0jDR4R6aAwzwn2V378cj7F9/1djEyu+PUHEPX9T/HHDqoafGP4+/8M1Ghsrq9r+Xv3mOQJ+YvHZ8xx9pYSzLqC/quf/Ee4fk8O98tL9EgLz3mjjfeD+vvbdz8nfGN99Vd7uDXm8n3PsYsb/fk65vI+Ix2XExf0SnXE/B5vulyDu94Hx+Fb94TnMtvuA+Nz/I/X0L6z7BfLzV+Xufgnr/H6Bff8b5e3nf6+H/LxnhPs9Q0b3HoLs3gCM3Bl92a77wIbJvt+PQ8g+AuBeifW9Eof7SKLFGuN7xpZ78Iz7SALj3lMoxxrq7gPzq8XoPkBU3M+x2WTrxjf+M/b045Dwvad4vhcWZD/Ii1Zc3gdwjWWv+8xfEd8D9XwfqRZjNnPKhzsjP90b6+oe6CuhQx7CtZp993O4FLhXcHYP1Od9BG6NJd4s/cvn+buAHn+/AOF+H0Fz+fQjq25EedaqMe49OP7e0E8+v+vD/eCPcL8HmxT7e19vdEGrn3fs3pCUmX20c5QEIYm0+scmuW+zT3rWKkwQf0RbLfv3bbgj89rXfY6FRbbwOT/6ceJN5ZclLRA71F6qPX2mNvoeOPWoR+n7OynefWxvROBAfNWPy4OmegTyJzbOPt9Avfg7gFe1uppr7wHqBKnNbI1Y/LSKklwP9I1RX+DQvtxzKY64JeoD4U4kHrH6r4YraP++/+cUb0vDgSk+/fnUgmqLdPnSN+ozYz9jn+vzcYculfqzeJ7BcN+OPREb+e9+/vfwJtz7AeK5rzdr9jnf5qbZYUl4X0gs0JQf+kZx0QfPN9gAxaPP/DdWsfrkox+xOKW49D2ElQ+BWGPQx3D+0DPm1hdXfU9ffGrAh3z7hnczzzz0IvOMNReBlwbeXNk3xLIXYV+uBnuetvcjYZdYD7GFi7X/aNjq++fwAcTWQ8+zHsA4P0g8+WyoM4BHH2KKT0vfDMl5H+QMrRb6c8JrP5DHfffvBwwblr7YN2qbvmdN9I09U+/nrzfu/f/9fHgH/oNTbA/M4cjnD1Ix9+nPsudTgvjBXdmzs8XLEMFD3zNZQuIf+swg0pdBPhPrvr4euEbYJ2LrvkvFgYuzG3OlgTxIPmpk1ZftZuMICo8HBqMPPTpmD0xzeyBiqNol2KfWD/deX6+nh55BqHoI4wdEePSVPEg4cXHRE3LSp/dy6+rB2fNBi6cUdw4jPcYPARNcLB+4fCo1nn12xmftfJcX+gLGCLyqHNAjbHFyKQn/B4JzPm64SN7vC/2mn4/pvdKrHggsPFCxd/3tEzjsCRgX+uJ9n4/hvcbnfbn/iryscSQ3PBB9kuNjEv9Cn33oGS/OhHxSfnA+PqAc6WKD6sWCXnmQ+mWfx/MD54+Dz4eeUn89XnvdC73wV12+LzZfPWO+pMuSvlNzQGw5LclekimC+4HrGUx/e2BwYukbpHBnDesTCRSelZrFgzBNsI2pTwv3hz5BDBT4+7zQJoGcAUWWrLPgnznfLdA+QeQ9Zx9XcLjvueDsAyTCCCAXnLli5hoqFf+Pv+ZkRNcDFbueLNAeGD9Jfxn/qMXi6+3nZ70JPDA3Rw8ZorqX8uOSIxXLXl4A3AtDBCcWOQHJDYlaTLO1wWHmARiqOPxJ+Bbt6BO15wxZlHjnuIMc/gVB/sBhry+T8QORe5cLHpjG/6Dk0eXwB4FDuaHpgeEVLt8Pzvf3fXkoo557kMSmgCdKuD9I+Onz+MtxcI/nL4ovH/oyj3PcxnEUKQAVHN1TdvUcDBF+P/R4PiBj0ad50M0DZ6+LCxL/Pbo2uVjkct4XBFWf5lApbu5ZD4TfD8T+1B4f/8zivs+8w9jzoGgi0kfm8lLica4eHxieUYV7XxeoD31B/HJ7Od+zuo0YOCUdScZKyTt56S31NoavuN8f8kPf6z+V+RDu3CKSJInLZV+suPwiP2KcqyWfFVq9r/Mj1O/vhju26K3fffM688HzMtTYAzikPnxDPnz4i1aUXPci1fFfuBbOu39JfO/nwGsr3PyzCxDuqyWux1UMVmtBOHi0njlY5WW1Vmu1Vn1ytVbrL6qZP8L9MbM+Xxz8EQCPgIBwn3n0MXDg59DjgDlvQO/5SJ07sJHNI/jso2S3h9h6XBAhPga++xjhLBJrA/oMVMj6xu8R9BPacxA/rlpsUFsfHfse+zwPPAL+PQ78cu0zvDzGHHyMez96+PAYYOej5bOBjc+seAup68eAmHPYe1wAB8bK02Mofw5s3PGYuQF9jMD7j6GfD+z8Z6m1x8DcPxr6uU8cHz3seQzB8kCPo1qfA7wmHj3qiLVvEE/3hNavdz8ZgHgbsPn4LdzdAJFEP/gjjh+1BA2c/QZ5UfFAgIgTWY+uM4O8U48ZgfCY+esZahj5eDYr9j9/HxD2E0PCTOMS3mFB6MSTajr3TLxzBewOHYp4M5HkwCaqsrlwMYAMVRqpPw78Co+MO4LnAT9gfuJFaT45QT0QxLGDg3sDqT0OeMLMYp71c/DHr4cBQfIDjJg/zrh3YuXmXSM/0gcGnw8CyZPnZT/L2Evh9JF6V7Htoc/HLRtfLZ6PHNkP8nllm9yAxs3jQOaVRxRvBLYfwXq8J2yimtajgNlH5RKH7AHMhY7UV8i8DmTOZGNH9ZSBwFl9PockNrj6erfZLNwHCicPDMJoAGoALicDXBCK/D4wcuuA1klS/7VeJLExBjjhUegjlB6TsOlyFMlfAxq30IAzIDQMmos+X7uSltQGFkmfPRIX2cjFYY7rB7rtj30+ro8fwv3REe6PEtETTcL8vPa70GCghe43YD7rvS/w7JnmOPCwj/qdep7bX/sejctAafADXQCInwsxf9CarFLQJoygceQEPoJ9Zwh016M2VPnUk4SjgQGf1DkDpWYGhviiMffBeB/AMOefZb+B4kPfuC9S/6hPyJ6W/Frqx4evJSFm4VM0n/0Mvw+AfA8UrPrGYsAP2hAOkFqx5o25DDLzUAj/9gPWwGDLQHnf5+yBhz8+fdXKZwOQQwfGHkdd+lh9UOLwMDD0mYFnHfY9+7yHP2Ld4/37VbgPXoX7ADPgyXnuSQH7k1UQDQI+82lymd+fsr/3PAhgEEFoWcSXVowWoufy5drQMwiCAUCOSNMdeDYJpNEiWBoAz/U9bR4YhqpQ4YjGcBAghpEGguRn4DlIoef1Ay8mrDm3DpmWBjUI2HNgHM7ROkLrZmCIvQ9GBgD/IjyKYO793SeQj558uNvCqxY+HAQMyZQvPnWsDZQDQz1ZLgkGxthYz+jr+Hry7VMDYw/rG3NvibXvhVLfsB/auyS/fbnBQ5ybdMXA1K8zwh1w5okgnyf3eyUI1iLXzkQDQNlK/f7k/t4nxP3gj9D9uJX4ePaJs5+J55PgN7VmvmfA9OSI8Sdgmn7SYgvklbMTKo7+rB1mwrWICE/scbiKhfVcjtw8EsLgaSD7/cSJBC0/7iAH5I8b1J/AWD1ZYoY0vgyWcnv36f8+MbWBEjmLfw7v/fyZTx6C48lXsAnN7KnviX2hgT0p5yOxe4pRZyAuJUx5X0AgZwj96ymSCLXUpbXuYq4nz3z4xOvJ6peQ36eIfSZoAOnr/JzDV5+Jb1/HwROCbUnLcH1JyK8a6x5zIYvmJNuDFT35FBPbNGf+/O/1w5+uIQ/EC09Agp4GtJB4UsQoJ1Cl358QQu/7nf00IARkn24s2X/r9ajYSyVe8kWNTZ8RJVnBQtmeAeEDEGtk+HnyyO+DEh9XDD0xOeZyg7zP4eeJK0angC3vS6LuyWNgfTJ+juIrFJ8aLh4HEeoSHMJ9uUYbRnO47WO+UliimhiFsacM5zxJ/Jr5a+YY8Z/h0z54udDn8S41OC2P0nMcRh+APCL5Fi+sBP59AAaRJ0GImHnUow/5XB75XDZZ/EO+5+KBxu3RkPsncF9pcPD2u4/lnX23T8ef9aXP6zop9r5cjfiDXPawNvV+L61PS4NUSO94AvEA2pcX7qu1oDVcxWC1Vmu1Vmu1lqjPrPrSqvev1rLn/ed/xdc/isPFGVN8X8FnDeMHsTiHBBWNMSuG2OIZk+I8gDZUcj2Ufy9GsL84T0wPDfEZOs8PPfE+BPdH4zXM/D4MtGeInWWKt+Yziokh/34xhFeGEepmuBzNvIjWzzCQU4cR6m5e8TLsXeSeH86Be4c0PxaV+ioCPEvZUJxzT4xWY8PwHiV9XrRgmLNniHNa0dC/ikMQF8xnXrbH6IWh74TmfjhncS3EEe6FQ0VDDt9u3IeycHe/KzIBKw4Foh/Swr3oALCoCNrsGUVNcAyJgAnEVhzQ57tncoNI0Y3NUDh3SPvkkkXRQ7AVFTvRgaXIxF/LK0f6RUrID4liVIjexV9RsKM4DBQigAgsKmeKBcyR7DC/L1IjUt2wg9VQaBhDQRwMiXeHcn34NCht4CkSDbbo1IYmTFwfVR7Shs0hMChpDcwz35RPYuMeEkPMEGwyDg6KQ7oeudgUCZ6UaqgIYILE2lDGQ44/iEZbHDr+ZfE/9BS6Q5o7ikBzL3LifUjwtOHirBhpeCuCOoDqCUVEg2TPGgZeLg0V3aDEO4fF4WxOi4pOKioDk8ihTr6LyGWpO5gMdZ2iDSNFgDclLFgFdVHjUUPfIG2SOHA4G7uZXPd/L0qj/YrPx/dDhq+Ggqb5g/eMcB/Sk43rQJEgrCLXrLIGE2CmiFAMinN+VizPCENCGBeH+UIrOmTuBu1XEoY0gClxVRzyhFSUbBrkfVD9G9Kiv8gMV1QzZ4ebITA4DfPgKwICVYoPlcMnLr4EWRSJRkhhZqZAmHhoBFBUFikGhoQ/rn3Zn/v0c8jfUlCDUpEhW1LkDYVGJTTVpyEoGAdyEy8yHPIkcYIjrh6HTlNx4yw04uJQGdAl7BJi8YnI8xPj00xDpp5hcslxCPVukcMlIVC1IfOJEBFFi3AfCjXk5qnP9CIOQ5Q/Qzo+1OD8NKCxReUHEShiDxnKf1tJ2sj0S25AR2LM4aRI8CGJfepvJIZMD6QGZ6p3DgmOQfZTBkGyPwwJfA7lQYnjI5bvBa5mc8hcwhUH8mWh6J8rVIeyxskNN4q/T5y/3JIuQ6ULlMz5j4Q9JM4ZzUppLQ2/n/HvZ/o2UQef33N6mBjiCfy8/lOZd+G+tAsQ7ub9pN9ROwZ64IvCsBIlJgNDHKTnB+B7mn9Dnixgm3zyqjQbKI8heOSahyUH86qbgdEnJD7I3gMjrnyXO9z0gT0R27T6GABYsMZi6FnPwwix9LExlHes/DOYY23EOiMW7geKnRYOpGIt+R/ChxwmkZ9R7PnwOZrvwRfw77x10MADJ7H65TCA12Lwmw8+BhH73Hzi9A2Ee8AqeT5f+gJ7Sl8xDA2+MDeDOYJ+8Hfi+W+qxdLf4tvgf0t7wVFa4S5+fgdxOP+vrYd59TiA20tLWL+lWO8O/m1slMBYlrTaGswfH6X559gm3EuBCSlZAqwkqyTsUTLsXwywD/mspNiL7lUKIPuSsUCs+bUMPNY4lDzzh9r38f3HX4fNq6FqeA15H9mvBJ5lERpo7rmaLIF1bo1XyYgbFD+xRFnJWJMIt3BcU/LAkO/FQwxusdpXilBDvrEoBT5XiiR2SiCmfOwtgbxaGvpflMXKRSmwxkqBOA3h+9JwcZclJQNHWzVEyUNXWWLqy7ex4liKwIclz943I9xfv/yZ22Skk37JAsa3/T6WUliaUEW+Lxne/1wj57/g/jPPjOQGWlL2KAFnlTyISmrocFGNcNuKhrhpAqNkaBalzL9FQ+PFCveRXcyVgAaY82GkF7GLSW0YLgEYzPnj1KeFNHPfjf7gxYpjtAmQcRhlzvdoJqWRXbioOB3JPPQEYAXFcA4nIyIuI4w7rDkRm+4IH6igmhj5CUZTLQD8iebNclFVZC4QKD5C+giaN4pjrH6ide1zoWS9QJLiYfEHGZSyvbFo0CBI/SB6o8hwTa5nj2w9hMXcSO8xMEcZL2lKVP2P8rGgehuiN7i+i1xgWeoR7SO5OPy26VW4j34LdzKwUjGPwO9HxJ4j8DkjSXjbI4l3yc+RMS4jw+8jZiExGHnkS4uhTz6GBvsR+xAcWXwbGc9Ac6XFQXrfBzOjgBoZeewRI1/S9z44HxnwZ6kpNLdDj71D+czC2SF8Mi8fEByOIsUoNL8+do3mEB+t7ww8bR4ZbQntGfPId2jtxML0yKBzYtXaKLDXIXjXtFOoHppXHY2M/of2s5GhX/v17t/CvZzZsKwQQZkghvLo98oe8PmZ1jAoQno/h9rTfe/N3rJB/JRHdABnYpD121KMTDI/bCwLxFF27RjahoUyA9ayrzAfGT5z9srmvfzh/yiPGWk/Fk+ELWX0b1A030fMXtrz2RyDwp+sj6Fh0B3y+1LPlAGSKIP5Lrsx52op83t5BJJYtgZ9hLJW/0O69spDRthLtUntm+WlkWFwk3Ih+EbiTmsSH/w2cOqU4n/FfgpXZc9GXB7R+YEuWxDBMWKErtSAJXuHdO/i8sTVUknaxzJoW2peGgSEd8ojPm9lAQPloVPX0iAt9EfJdxK/I0cfSLVC9SDtYo/SFFqPpvTFkLCfw5zClWWmZsqOXhN1iYLF8igfq1yfHxGYcDmXwyOVuxHB1UJ/KBM8qXIHelEm+AnVL3oBPCLr7v3GPRP0bCMoKwIiJ9CI393FEWjuGcIG8gxKdGtNZcQLqTIBoPKIHgAocVEe0WRVHioC1o37SBimiOJj/SHirAG2LJG00ojLI4bImFyWRzwOsrH45eeAiI2LiSFDFoT4Lw+Z+AwBfDCDA4VRTqyVhzJeyXocEYMC9TuDq/KIF98z32v1yuHVIXGKT8pc42E+Kw918ZTDTFZwczkfOs0MxCZM5iO6OZWFIYvLC7dneZiPMVk/TD7LnM3M4OzGyx0atOGvPKJrr8wMD1y9zfjsNGaqL0iDmyTE3PotEwNTeSiLKCk/Uh9U+45QP6abUIaXyxInU4PjiM6HOxiWlcGKjRn3GRVPSTMAQqkkXPDleHjE4JipLfYCihG/Uq61nkbFp0zpGqJflEZyb2BxMFRy5mCkPOT9JOPN9ElSuHNcPKS1CVl3HLdTuFZ0sST8y0DsP4V75e3GfQQEevTn3xJJwlxbJQY05SFN2mVFWJSHjFCibGdEaRksOKoQygKANIIpC8NJmUkqS/AEuUj55IDLvj9kJnQuJ0xxlIdgYVOxGwokDJJCWRHGZaqBCJiSBA6LpyGNiTJoX1kgDtYPiWyU/Tmik2ob5QGpbtWmD/hWlm6YOMEh1G15RNf5BzdyFwtlYOjhRI3W9GCMgLxcHvGDDIo56L0hvq+IaYOg47iUvBSR6nEIxFLD24gX/mWlFrJ402KkiT6vZRDYUm/g7C4N+dthFccAp5WFfJM9bKjjEtIRBt4saZdUUs8aArlghhUxPgg/BnIR2ktKiq4pa70DqMOSZ81IegHt49yF8ptmzwt3YlVG4YlYrW+6hnEKcbVWa7VWayn5bRWH1Vr179X6JuuXcK8Cwt0V7zkhP44r9ivCZxXDexXlu8p8ggrZ6uNfeY4+VAKfqyxowKsAeV2mIbQC2DwvOyvM+b42aPVVieBLZc55ssShMuezv6JGQzk1Zu1+VZ1Wlogb5vFuxbePzxmvlTnHx9r/Q/2sOPqnsqDaKH9RDan5HOM9cFG1WPniGJUj9sQZ4f5x414Z62B2hcCvd8a0MKk4wK4ENnpKhLj7I4LJfR8RgpWxbaipAOdbllWUhQwyXDwkf8ouJiISVs7OMS8+KsDgpOEBtndsG9TIXAG4rXiSTwiuLLEzCfAxzQ1c86t4nKs1CxbfY6C2xrZLBjh+7zyqCYAKUw9WXpV4GeGDimeDrxBxrBgHcwv/IZxsHXIrgGCpZP5avKLUo8ilHvUV42KAzdfYgyd9uVHYp6JclCG84YtvTgNZuLSC8tQY4xMtbpb4IjVcAbRBaC9iczCOcxlQAfo5ak9u3zHWl311b/VDuFOCqzJWNnFEe4VoJtJz2e/LYyWoWtLHtKCziGZXVCDfozaiAp+MF0GaFUIozwBQGahEW8bAgKbZMuabm1rE4zyGXDL7FDljnBTgQWqcL0AS1wgBjWeFWc72MZiHMU80rvhSc6kI2lzciViXiXhpMRUHuzHNOyQGx7TotTRlbcjTcloZ2epLzJHDg6YBf0zHNoeXsZwLabiqgLivUDVKYWvMN0mNezW8VhhcUj2IfJfhL5ETx/QlVVa4V5C64Pg8y50C9lSOHSviZAxcHjDcLOUAOV/lJJ811i91KgI2ylJsx/xZ1CUTm0etrsd+HEbuM8a4rmLslWxtEbyO9k9uH4knxYvWsYxxLadSvVnqTPV1jPHbL+FeHb8K9zFD6oCIE5NpeX/MnA+eVx37NZsKQ4hmf1F/rPuH+DQOJD+tuY1nwGSzGcmvT+zHHnmSfh4LAmnkgVdrPseY8ILyhtbXGIitTzzHEXAde40NdlqF1zjAHku8kFwZGm4QbseesRh7xHls5BgLV/jGPYRXrZxjqWufnFnxMrYNJdAeY2O9jG2XUKY69eWvMVCPobyF5MLK5+PAXIbGaAzy8xjgg3EEvTQGexlqz9jQT8YzWvdduBNJrBIvVrPL+UwKdNV9LrNvldtjlDnHsevj2aojGqsjwm4BiFXHjqy91JnVEf0dSyBj5VaMEr5IHEd5W9xYUc+4e1edn6sZ36sjJ9fZWBBxrro/M8RQHQu4yU+W2O0ih8HxrE1ZzJqKy4mJOpgSOKoqw0B1zLxPxSpfyGKepQGrSpxXoewm7OBiTg3RVSBHag0JAszlpYpkp5sPrj6cnFcJ/LF8MDL4wcRuJjdcHph6+WX3kM9ttr4p3pUaKcktI5orqJhS9VBV4lUFhEGVq6uxUHNj2naNw389OwQFhvI3IxwOqwZxUwUutqocfsZCHx57XCKM6d7pYrWq4Y3hw1wNSzxJ9ESybwmxrI50fLLcx2gFUgtRfZvTJSOdV6rM5WaViV3uPQF/1RFRy0x9u3jTNB86zFWpGtB6paNjWB0g8FCV0o5avx3Teq06sve+5E24Jx837kyzq4LL8m5FeXfmGVdEEgOEC3jqrJxQHfF2i/aM82KnCuxR4WLiFgHTdNAcVAWBjL4nkbj2viaaqmNdCGr7V5l3pd+lZ6z+VsF4ICK3osTdci7qmxbzigF3mhD0wYdma4znNO6qgL5YMJwTBgbconirjojh3sDj1FAg1Z44iHv4AnGcO9iCsQzF+kx8AW5CYo/WOSU+yPdGWN+MwXNIDaF9PJQXJW2BcmHFAxeIvdWA+PposaohPtZccNoJ6c0+fTskboh9qEZA8Gj114LL3I37m3CvRgRFZYHvVQPJ3xLU0KKsaI1AmUznVaSIjxXP4U0TtL7NYVEEVo18lm9ziGF7ZU51VlEEDWJDLLti8c+8+KgixGsZeJESgVYeqkRoyuY1CstniHBfLbs4WTa8VyIMk5W/LIc+MakY+lTlC/yad/4qc3zWed4R7hNlk8mKnP62laxisForrKzWaq1q5V9ak6/RNitcLGn+vxe3EDfurw4lhFPUZ7+eBQGaZP6b+IJ5kg96ouxN2ZWgiZvo/qDnWgo4mcQlgMTDvxiFYLJxAtozYfI4ySxDXJIYBT0B9/aJ8yRSfIl4JzEazwTDbMLk0DtPLq8A+EkiNtHEmGMu3olnXSZzEAPwnpP5iJRkicR2EsGeZInEROKBmcTn+4l/3LSYm+p3onMNqgVYbgM5L2FikwB7mXKm6JUE6AmxBXHio398amliw3QysdV64lEbku+JoQdme9vb87XJq3B/+8NtQgklkF1RNNEBmBCNK/EhSOddDszZM2bsmTAAneSLl3ufE3mJ0JiTQGFH+muMY8Ll5H1AywEYILGEybsLsAQkJ3bAmyj5JkhxJp8TjFwT4CYmUfKpDaiJdbCkmopSB0jj+8h5AryTKJiUhvOZ+E9m8+nWXTKR4yfWyUSwkcME4UMiDHLJhMdDAhA8EmM3VlWmDpDcJYJgSajmMcF8oHAoCROuJ1DnJVSPQevCyTFyUcGJqITBENdPEkUUUr0mmeSxiPKIdHHl1hmycjUN8EMiicpJ3r9c3Uz0WkXqP5efCc1D5NCc9XMi91OLYM4ODNK+CYURrfYmfPxETE5wbiLjL9Sv1j9zffP9/3VIJrNYQy55NL2TZPavTgQdl9U+Ct7VOpjYOH/G7wnPZyxeJq5wnyjFMGGKb5IX+mjDTwThTJF4whQ6F7CZ5BATDEJwWsEl0vcCabkAYs+c5P3J2T3Jx9LN56/3R3ngJASoRNGn5XLCi6iqIKTcxkbZyQl1UtRqN7DU+4T/iWCXVmC5fDu2VaT3hLpA4+/WMYsfQbAkClYpkTjj+0TJp1SHWTE7YYYqDsccT0wwsUAKPIY3qgTfVAU+JeNHvTdWaoKriwktCnI4cRpYZQLc9E1obhIbEBdnytaJLDhIsaNgO8f7YyXGY4YjJzIXSs2Z7G9uXYJCm+QEri+g30t7KZcyCSeIpd4OiPacyHLjS+GJ6jnuhQHnI8Ol2mBUdXiuOiE+A3SEeEk30fOp/q3oWOht2vA2UXoDcMn46/fR+6L4eaL3t6oy9CQZ4U5dvJA+a75O5H5XZTQt1cPI/AmczQv3cUa4T4CkjfnD4El/4gEWDsBjsNGh708U/yZy4SeK2FMJdaILJbWhG5q9+FyMvcdAXBDffGz19RUUrNoABWER9XvsEVu09rR8jgBch+ZpouDDur8PL3kKZrgex5HqDMGWZQibBMYFPWsCikngcsIbcz5co9XYRBDDE0N/88H3OALPobkZG78fg/hCYm4dTCaBXD8B+rhPrsYG/PvUPGKL5tfI0FPQOMXq28gQ4dOzJx46F/Vv7KmfmHP+3LhPPj8gN6u9v1gTDqwxP1sSWAOTWvNpeGPmfcGumnJWNfsMQijMnlLs3L1roG1vuaqNcF98c5EI9tYCRVyNWcl3WOMwMqtZzzKQZ20cQWB7YkjFeozznFrJ1QVVs2PPAUHjRqd2awAHQBynCRqAQ9jzZpuEKOxqEzuvco20RuRQFZYG/NU8OS+Xs5CLj8A9apFqJSRetRh8NQb0goLR2pjvqzWLbVr9TuQzaiAXf+oopU5q8+5LCF8gXBBRN2g5pPi5ZvFV4GQOn5J+qQl5q6EXskB9UPalb8L97Q+uodQEEZUw/62Bv3PNqyYkEfk+AW3R7KmBJKkVMkooWtwT4PuacZhC/K95NDcJK2ic0CHK1x4fEkFtqIH218A6496pAc0crWnEb6mWUWFRM/AAimvIXpBoa4bfawDWagZcIr4g76B8nRi4WsNMAu6t2YsMd5b3E5ADaoZLm5rbwBX7a0aMqCIGOC8x9lwrvhKwtyZgL7DwX82D1yx9ynJuYsQvyoOhnIDoNoTvUD1SM/SzmiGfPtoU7fk168Cu8E5i7CMB+kAX7jWPJlKLALB5r8T4HUQe0/fPpsr+Uz+yT0DB4EuCNQMZJxEFiXWoQ0UVKqR88Y689xX4TjzykBj3mEdt+za1bF2J+4/9RMui8vLVnFjzFJox7U8iDzKJsX6TSEJ3Zk3jPJt8UV2GYnkR58yrbpIl5YhF1vgiYz7Tk6f6cBXqF3KJBfk6Dah5ezwJ4T6NREAxiW3KfDZd0NnTyCQ9Nb43Beybgs/NO16Lxo5vTKU4xsLDNAI2poYch8Rk6vkcasPU+TkmTjPvpBZ7QjkoJpeFYmka0cZ51K0v/wjvpMvCPTFt/ao8zSFG6bKI0GkkfE4j9dHpnL7z7V3TOfCK1rOmRk6cRuToWHmbRjzf0Bd+/VOZ+vRVuE/pokszxZcyzTEFkpfdI53SiUinSsEzoEgVZ3P2M+ekgi+pEpsZO7L+fqwPW6e0fSkV/6lMhmn2LKlIprN2pUDMZnInFF46lX1Q/ZnO+oKQfcrFgrEv5c6aOjZNZbKbyfnUTqbpNFAgTvNxSidCfhhiSTkynOb9IvM6JfI5BbgAJOwUGVjc/FH5VEg/ZWoWGjxA4k4VjM5geUxgS4hdaonlhMCgxJ9TJadTPgeQeJPOVXxGcpaCzT8F/Uyn+RpMNT+nQH+Rckj0qpTK/1QRTFOmF1qH7giCPHXXVBHFU4/6nBpFpcD3XkP1VNYN0IAzleOn5h3lD7BW3d6ZSpiYKnUOXAqlgD+p05dn+tIUwwPZA6YKz3Lxmua1VTZeKeBXStUc3bsyN+7TWWFNBsQVC1OeENIpL/45EU066AZmmt+bHAwmukBPib1zwhQRNNNZMkqpGGTPID6nhhy2WKd8800J21myFAqCFe6EXW5eagJgU66wmfNSKn9TnERTQeylQpN345Uyq8YQCIlZAp8cZrlYuHWXEvklB0VGqKVTPj85PDvPpYKYzw2snNh08csMKLlGTtWSRrRTR3xNGfwyMUinAllP87FxuYbCC+VDLjYc106Bv9FQhuuU4W2qDlLCJrKeuRoTMFATMJIy+0g8m6svxnaun6RTuhelxHkUBtOJzDUpN6RKg9iUrr+U66NUX5kQ9SbEj7yoQoerCd1L0gkzaHNYmNJ8VGP4L8ZNeWq4tc5xhsO9OR6cMmKcuZBiL1Gn/EUipcvYup7I+GQv1ijhTPAcdaGpDl9TecgnMc9cirKc5jkscUKc5Kkpr2FSUPe6cZ4R7hQ5p4SA4ByZMZwpppx4ndI3iDmynRJky5BoSgmeqSC8hCGDbOiCyE8JQkVXjSFQkoTf/5tIonJKiwSpeadMrKkhJn2/JeRiQhLsVL41czGYaI10Kk/RyZTOI/c3DxSOUiG+uefcBqkI91QSD1O+qSL4J7HFCU/NPglTEyYOU91/qfbFIWkqx87FRqLlhBqiJ4oYc/8WS2imWn4gnhGGfWqQF+OF2PXxtwBT4dJhoohkBdvssDOlRWo64WMBL4H3SO7lMDbBxD8rjpleU2Oeqbn7TYReIfSQlBpGPWJXYzCo5pGJ2ef/ozL981+ypqZE/LmhjblsoC5z0qlwATjlLyyl2Eo2crxIXSxSPTidKJeejH21iYAJSbcwYlftU5zgndCasCYNwhpHSxdj0/y/OkiZv1VIBV2UToG+JOgWpF5JXZ1Zb/9K5r/6q3BPJ3oz8yFI73fnsY8kxKZLtJbRpq+0f+LXYKLb993zslqL5Zi/2T9B2EfbdzKn2szy/vib8KR2YTABRftqrVYM/IUMf4vittA+H0P/TuZTg7+F++sf8w5u/RsAue4szv56JH/q4Pf1wH3rX5zT+pLgqc7kO/TM+hx9qH9hnELjtSh+qM/R//qcuau+BDH6rrxeN+S+vgQ+x6zFr4z5vLFb/4YiuL4k/FgP5Mp6RG1SXxIuq0eqtfoctEE9tnCf2fAFT/hXgLYOiDMLIOuKUK8riaorz9XBPXzJoM7EhNznxd8fZMhJAV/qxqIIIckY4r1ubGb1TKznQfZ1A3alQbQeQbTWtUbwkueUeuavGeuATaF5rIP14kvadWNzqBvqF80n0lC0xZ1vOa8OXorUA5tkKFdqvsfCSx1o8j771wPiifbA1EPYaf3F5wKjHlGgph7+xNZBoXoj9Xg+JfypBwj7urFvq/6+xM23Je/1QH34EdMYekeIN3/j/it4L8znYDK0BGWdfPu5xu37wjeBTztfFEHy8vtZSVB87Ofu755Rd0H2ojdBdz+K3OqAcM99/oI3IvK5F7qgWXtesLzXX7DGSPrzkonTC+97bTr7XP0FEEVELqniy+H/RcH0Cy9+6y+A32i+HBspvFL+uThnB7MXQQy9MATzgonBbC3XhXjWlVjmSPJFaaoIZgm8sXa9YHh298ph9UXmU4gPXmQhXeeGxhcGMy82W2bsf+ExhNZ/XeJhsD7qL8ywDMY7Z/9LnrvrVpEk9VSFO1Gxx9aaZVB54UVIHRAqdSN2SDH5kudi7z4k8ADFo5KY5HhcG7jqYB60fptq3OTRm1MwhmLdT428aPH7hen7wAUHEg/torcu8SZw8SXxIRe/GQ00JTXnq3B//QMNGtXkUNBB31H7oue8KHt6FgscD6v/PvFUGhqUs6nRJvf3iTEvjLiuC8Izih8h+Hzx+MwHZyGYmRrx8jIH/6U4cLVs8YkasGLV+YviQwwus/DKC3DGSwSuDfkZzYOV06aeOX4J4Emf+L544ojiPmvuXoQ6C+UbZF8rn77MiR+nHva+GGIs2fsyxx7+EhD7FyPG562TLByE4OfFo/f5+PkSoANfAvD/Amjg2Xd+37i/fdEgXm4IQrox/b1U8fX+c8MxtvGS+cw9K3s+8657VmMaKPhfBKH5bkt2kecK5zcYu914NYSEp1MhJkjuJkJjIexqTPNnsb5PidhMZp9tTPN5bhgaf8O1ZSIXU+rEvOHEufHCx6Dxkn/3E7MvtkbeQJowWsguVhgcNCxD8YtTj24u3Xy90DXbcGxsuJ85fjQIG3J5kPDJ5KAxZXgHbMYUrzVegMY7pbFW53KCCgipDl+Mol5pDNy+HB5cTLM8jtiq1FXjJc8BuTwbRF1jCggmpvc0CPw1UDEpxVDoq7keYhUOki3TPAdYhvsGwydajyd73wsgZjNnNpB3NV52n5sAOXO47K0fNV5oXmpoPSLzXuOFz3OD4lumRhoS178wHCXUa4PrYdxzL0J+piDWXoC/9SK4pkH0gYY0ELh1MKF7RwMc8MU+PKX1HsVHDYLnGp837gTBasXQ4JqiQt4N5rmGJpSZSYx9jxK5ijivU2KOiUeDALno95QWNS6gGlyBUf5NmYKXSEAhIrcxuec0uCGGIR9kuYXRYPA3Yw8Rt8YLPUxYCKVBCVnNLqWBNgQh0wCFkysW/j87X7retrIru9//De+O59kSRXGepO9bN9mJE6qJoYBuys46+sG9YplsdgOFqgLkc8K9UGT97V3P9Tch9iSRKPlHav4b0hRLNfXO88Ni3wTxkg0K1Vy+L2NLPU8J5iIf8/cQzck3JV4n62o5eCfwocSejZ+S52/Az/81/PxfYj/sICLkgneeu7nBzzfwjNK/v21oI7nI3UYYEDCG478cB4VNOqXLBHdQuiEZBcosf1N4TuJ2iusok6WZ72+Ah+C4C+InwchqcSN9wjszcOHq851v2MlaDgYdFPYkT/cN4AjKr7C+UPJARONF4lUaEgnNzDeiKfvG1CfHA6y/AOIlxeObMPAic0d71+4/3wLj/k1J5jfCQJGdICj03wzPfAN+jwBWA+d/EfF61+NlKQYk/gujZjXISEMAmvVvG/v5vc//NzLv7vdLYiw1i0BzaaoPhrTZ6x1rLL9tlKbxHYy58fcIz0jDg2/g+/+r8cY7/Q0aZ6akZ7+9n79uUl//ZXCM1uH/2/CDBKS5h3mAMu1IM0F8e5YCnx6uQer5v8Y6/yY1kEzjxw4SQnPEfOsoNv6S4X2X36ue2+APLEODtXSK+rZXa6r/C+qxdXCG8ul/jfFXfZEwCKN85Tcknu+6N9SGhh7PYPZ4Hh7h/krhw7h/+0Licbku1+W6XJfrcl2uy3W5LtflWlzdf65mxv1qdv3vs+3s37N7qJ/Dz388+79ro6+hrW25rhIHybIn6t7/nvH93yL2miJO1thcWfc1w9Qa57haCWNoXK5WzM+n1ND2L9prgMmrzd+198/ivH9bHL5C3V39CzH1WfG0cKoU/6sz6cFnaDcXt1g8XhFasKbeXRk+v/rLuOPqNDd/jLtkpMgAb4PPtkvRvhKMFrUuYv6utqdNhbjGFi9QCqxXxDvn573SjOk8Rls/6K429iaIOr/LKAtFfbU9bVD+qwOOji9i8n7haf7OKwED7BoKzhd54+K15de+cpAjVUdXRlGCsLH1Ee7inu3nkN8VtY9tGsHjuO4KbLasP18BObkieOBKEsLtaX64gcoVVZMgX4ox1nhxGyes7L1bPP9XwODgSqifK1CvTvK6lU3MN0NzfxV5P/X7D/4m8W/h2S3GQ1cb3wDom7C/2Cb8aovxtLrvLbPeFsPLlWJwr5T3qjpq0PhvW/uw0MOzlM/6xuhhikZJ9bvb9QZUV4B+X8nv+mncKcNyYo62S6N0FYgAa2S2y+euACN3JZiqq+3SRH+j9kcV8RZ4B/VOorA40Ts59xYwVVva+M2f/33Pli7ykxxs6aK4AgzqFZV/bp3Z/ijjzsXxSjDeGtCvqPhu8ak/d//iXBRGtnixXTGNk4ozyYRul3vRYkyefauLTpj///2dHfN+zchfzf6m74o4xzemGeTipsXgmxGHi6Zuu6w/hKcQruLqUKzTDV1zYjy29PBArMUtP4DQ+OybwvVIsx2aBc2ka/hgcbAVMLBleH9L7Iuo1yvBuF9R72AaOWpd6JxMrriBy8fP//11XRHflEta/U3AgWXAIOkCp1fcXwao3BrieCt/K0zW8YbnwoVWo3y1Fcz6Vsgf498sgyvOU5zwyBbUMcI3ig1yqONh7Lb4ACHksSsAv1wTAfOJNNCWanQje2TOK/6cuG+/G/etMRGcgUOEQbu0+61Ct3E+Q70TCLYYC+l8SMyk2GyA83niZokpGg90r1vg9xsAk1wutsD7tljzKa6dEv9bQwzQvVnqYAPEz4MD9N6t3oxC79JiacHrVon3huGSreEMEk9sQCxvjPW6Bfdv4QEU22hOPTq0MdxnwSrCy1tDLWwd798A8d8keK9XR7Ygj28dDa1V57bGvFrj6cF3ilx41onxDFund7BoZKzfs/LVxqj5Xj6wauPP+39N3IODXAcLXiuCc20wJNezNa81MWPE73rLm+vrrZHAuee28ufWe072vQnOvwUJiwHjtZaTDb0H7tn/fe7I7f/u/3WxMaB+b20OYy+vOeWwGGIZIPBrBR+IIF9vwEbX0/BReZvhwlQTG6PZ1nL3HsRqjlmtJjcAh3marS2O2WuJpzZ2XjHzEoPva26PG7D5CJ6Z45Pi+zAOKne/RzS3W2PDExvjbYQ5tWDOuj+rMfXoHFjbYc1db/znXNSXJ/aGuF9zmhmRi+st4wuCc1zH4HgDcqCSb80vIWtde7Rr46+L6y3OY554XkuagHjmEEcbRjdOJu5CkK8VAboGE03dfy2YmGuQlK6B57TPrzVDZTFfzHu5f3vAfw3GSIsDt46UryvJrBpI3ZLjmHNoOFDPt5X3rMWQy5+2xrVivq43pw1W1B60hlCpW66Org28co2KxobGJ7rGtXE9y/rXQG1beBKpyyvrPRusDrizX2/t8bpWnr9m8qINGywacR3B6yivXoM5ihkSXQv87InPNaiP1079teocwvMWHonmWtBHWHX6WvlvStwg8bB6vmsn514b8nu9seFH0qVrpWnwNC7XgF+7duqAwLs/jfu1keAQ4rgG77cY22tFXK63uCCZBAQwspZnLWSJCCKX9G/KOhbCFvcEFAFCat+Yn68MhuHaKHJXBhPyzWHWrg0iaNk/Qj7XhphZasN6ISYYJWPP+1BxQNe0mN0rR5N87WiOro3CinLxtXGfMZi4dsYrZc1ZmpSrRLWCDoKuDUbakz/roCimFr26axn+XTnx6cWRpQGPiR9qiq+M2ulZw8t7KXTEy1Hzb2WuDQ28Nzfa547zdv+5nhn3y3W5/rVXdonBJeaX64KBy3XBzOW6XOteV+uuHxj3oGBufl1RhZUxP2fCOtknEMGv/dycmURutvR7b7KvT3osPhgsUee6SXGOTM4pmVcHNk7uzQzraPuLyVu2Yi4zOxZvtoYYZWfGawbgNgaTmTM32fnqdS1c3SS47yY1BxnPdbM9jzbdrKFpmVFrM2xvN6hmI1yQJY6lc70bKe+f2URkCo86+QfyNBnOn6thOjLeEhfcOOIK+ZssAScZMXvzw7jfEBP3Gynp1gLJ5LVuFIDcaEZQA08GCnbGA/pGSkpG7+HGAM4TUxvs9YYzi5nP3N8IRHGTgQaWieWNEOOb4Pr4GuiGyPfHZzeZYAQz3VjeCAXFveMGwRRChmD93FhNhYBZ8hxU/WVYrd8E67B5mje+mU3gT+KfLY3CjXBGkisyujbDc4Rng3iMarIz3QDeAEaDq3erCNxsFTxsl/G+Ec41z/ENwxM3AkdcK9x5HaxPNco3YE1fK9xzLeCDrJlMNy83RtG+AfEg6RFr2jNw8JApPJ059DmmmVPicKMNTdBmZIanuf5ce4dnHD4ynXcl/IacfCMMeW62IJ4036AMLW8yueG5kYZQEq4zOx5YvlMazBtNczMc4zeAXt9w3ioz8sWSp78b9+yf7oYxt2FiQuK+2tICSBrlwCSxwkntJRNMYKYbqhti/zcSWWeMuHCCnxEmBiXvuXBlS4NLFcHN7DoxTEDhUQC6UUw3RSo3EulQzU0Qv6vs53WT0UV1A+T6WsrbljYDYXHfZEt8czG92vLm7SbjmxmOlMnYZ7Sw3nCiy3yrIDaDRFylPVD4oOrhZkuIrJC732tsTp9lsUVgPqzdhdEPDCh5NuCbRlLghW9zbjgxRxpJwjRTcePq+IqpnRum6boRYk7y5zbg/4zgeaAeKON+wzRZ0jDohsHrtdIMIWZEalqoNTicsvUuDREybBB2FeoBxedh3WRCo54pTWPAmxatk+65oeJHxYHhuqtMb1o9xp0aJnHaciMMqyhO52r+mhk4XAv8zHmF6wwwnYJxv6E4hxkALPghW/KuNsQkfUqm690NkQvSw3IDi0wZxjJDyxstN5ncINwIAwhGq39O3FkRJsAlCfaNBPIMXI9ZXyyGDNgvcg5tX9I7uXNq8clk487uiXtOO98WjLuEia3hXFJMNwY8ZEp8tiD+tspnW0MckHhm4Dm0GBvr5TeZ/Pr/PMOuh+TWmg/vmbx53jDn2hhq2MJ32VJAUFxxwwczL6J1kjlz760/jp+yOBxJ38ipZ9dqMQN4GdUNj25mRr7NnHy79e/nmmkw4TpCMJgZdBHV0Syyviz6tDVqTBaBEws/ZBGeSeGRBQdazrRNc16qkYZ4KUanjHzBxsnHs6cTdyT4tx5jnDmvGLLKIgk7xTudDcKtJ85Z2jPcZkZTnipOazZhKXNoNSRrnjuL2JeAx9utsba2K/FBTJNoNS+x2Nom4L21+HTNM6XmSdSscU1mtvK1XUmP1noeacq3Z4pdBjZ2MYO5bSJcbuNxfLv9pPr+i69bb3wYHN9+Fl9bz6k1NR8T9+8PdreMWQw/u2U+uxGelda8Fd51w9wTGxxtvVvwXbeG390mTjSXk1sgprcRMbXEC20+kP2juUCwiuZf22fK/N2skA8rlm/BeNwyz9wyn1lr8xbkBW2PtwYMxNQ6+l4LLrg43jpxEZP/1QQY5I1bsI4s3H+bkMu9cUPqxILTWwdfoue/TZxzax0hvH9r5N21uB3VJi//3Cr5+/j9x4T3FuBuJD7enN86/ZOkC7eR+Tg3z90afgbr/I9xt4DsFjDBiMFEEmQ19xZBJdff+RqIW6MY/v58x+8pLLxrh9Ahxus2gkBuwQKxNHaW5u/GaPpvDRi9McTq1nlmD25uHWvdRojMLVDDKC9YeMOa/xvjPlGzrX1+beQZJKeeOKDDkZBf0FiFObs2NHaI4bo15uPWUA/WAcGt8bnYS2s0UuzRGj8rPq0N+G1mG7R5GjELZ986TNQNuL4Yf9BzWHjCYtwt+TzZ586nvVYtsuLZMtC5deAtplm+dXpj1riz1+4PsOYgE+9PQWa7RPd41thFrG15duc7x81K4rF6znaJ19994lnOdH1Wns/+3q+Cjd0XOkPsGrsV87P7JG7fRfLp7hP5ZvfF+DoVnxv0TjSvO+Ln3bpnOxvP7c7IxSnftTP6pr9Vp3Zn5tO467tx33037juwEFFiBAv+zgOGXWIjjZx5d4ZC3oFndQjPHQLIVKZhl1DctfV2Qi53xrU9748lhJ0R6zt/rYlnWcPMxMTqnOY5ptncJcT8xzrbFfhmt0JMd5HcrD2PYn13ZlHdCfyxW8EsOJ+/y4zxk3Adc95dxDl3kQbSqel3a/DN7p+vNwRBNWEHeIYdULNrDHV3CXlr59TtFPuy5Go3n7gHhXpHPyAbw51AbDu6QO4AYrkL1rwzHvbuY587B5HslvG4k+KwI/aegfveBTGhCGUXTxZ3IIEjjdXJ+XZK7FIIkCAkd0HO7ywN226ZL00E7oIz3nkEDayXOy3+TM7E2tkxzxsM1d2OwKVChHfWBnJHnHXnI8q7zNksCTiW9nXn4CnRHFLvkwyXwCXzS+PFO1TQvY3jjtEEzTBTcQMF9Q7BB/X7sKZ22EBAq00NiyHfaAOwO05rM0YPdwCm5uspcb9L0bAgMf3V8N5tjc30zmEOkRwlGobdMboGaQlgVO94Yyjy9R2Dkzsp/0Yje7dj6g4cJt1ZBwY7IZfowIrZx12KAcXp77v/3IXGPSSGnWCGQvISrrtdIBRz4didJuqOARgbBIk0gr3dEQC/o4xIsLe7bDYN253u/TY4w2K/O9qU38wAecfEiDX0O4WEBVBKjcEiD0TTQ52ZNbA7pekgcnNHnXsnN3OLNXanuWTPyewREdU7At/mb1iY+rqTBF7I+11QV+Hadzs+DneCKb7LdNN0x9TanUTqO6LOpHMwuKF4KcTOHWXGmbPeZQq257wUrrOjTTFrkokcUTxAxfduZxBxzhjsaJ66C3JoNlY7rJ7C8568P5N1hcvzYs2doAeKeV/UDle3O7p5WsQzqN07Lr474v1MPu6kgRXVEG0D7RH2eCcZ9x0d6zth6n8nNIJ3CLaoNT6MO9VsWQdIIRcJOiQaRkVzRbyHxp3wPxInc3rL+iyiJm4ymvMWsSB8D9dg3gHDyDvOnzGYutvRXKlx1R0VL6bRvdstPSHaaIue2fIN7p/nfk7cOWKQLu0+jtzcF0UM1O+96wrnEM/rfS+1zo6fhJFkKIhHSAbieTL+ut3RTYyYnwzABSXaGp4yHlPROMt+Er+GZbUuGOPJCeICa4xpoHBA5TdVTND6vmPuW+AwYwgSwM6tYCrvPGfMZNN/l5KvHHGmmgcy31lC/rRwk4H3b1EO3X3edQvqFXSWtfSB26/AJ2ZcZGlyIzVrnjNK8db0gH0/Y1zvMhvetRqThipcwxTqb4weqTnO7LlNoiOoTwD431V/wOdonNkBtcSdmRwnBf/fJ+67U+P+Za/MKViX63Jdrsv1t1wXbrtcl+v/dv1fOOCSP/k6Ne73s2vNF59z/XvlvrXPe/+F1rSe9T5BrO8T5/D+i2IufA8V6/sz7Ps+4plUez5XnGP2e/9F8JIiBhoO/xb+vk/I7bE18Znxuk909vvE+7z/xHjdfyIm19C4r8S192eq+/u/yEfer4jf+3g8fjfu+enE/Z550X1CQN4nFujf/85xQ5LKnC0+z/X9h/s9WSen930PmkNLLjThv1cMNBX3+zMW67333nx5BjFWOS6UJ1eOx+PegX8kP2bxzun4ILjicIzESMrPfQRHcJi9dxon7jI1s7ndHCzOmcu4vCfe+fHsrSG2t4b9pTCVaDNyD9Rv+Bx77iAfFP5YvOZLzHubqHtEXwx1nrJhQGpZ1aFczgukjwL3sfflsk8w8VqCoce9gYsWz+W2OpTwfu/wBSjuLGtoHGtpmu4dDfC9dQiZ4zVwnwPYyLEc3M+N+/eFO5ag5hdHGDkvRPcM2O4pc5rrpEwZqdAc3RsEVgR6fmpiThKRC+tx9+fK3qh7cgOwCSGXzPUiv8L7pfhKJutey0/O/Hsnv5drlKD45nq8qfxrQqHlOdwzFz+W3HPZSLANo4I7tdnNcfOKYGeBv4zJR24gvXzJQ5b9SZ+J6+X6c3cMD97lskFEmwaJu+49eXPk9x4wCWhTdr9z4k3IQ+wZ7yTtM8SEuue3nuVMDQB65sU28rs79Ey5Uh+58RnpHEK9az4D0gbg/jur51DqfRGv7NeVGzQOvDTjeauYV5WHJB7NaVNrwf3vWHrqLxEfkIOEfKnpd7kDc/o5vhv3HWHcc9m8m+8BGgK2oPNIAbYWL0IsOSPauWMdjwgg61uExCka5jV3BpxYBQjZe2ZrVqAc5cT6lhwaBcMUmzxRLtF7coWMNaxaBXTnrIOY93ibwp2TLy38kBv/bTEyOcjdFszmkbhDeSE3YhFdw8LpHl3LE+LVMjzKHefPHfjV4pEZ+TJPYNIttZsbm5jcWNOZodZi44/gVfI9Md7Mog1eHsmNPCr5uDySn3PAe+WKcX/4PnF/CBZ4YP4dZchyEPhWQ+l5LxjsB2VfD/P4IA1AbmhEEhDIg3XSkc/OrQk3YhCY+x/yBOJoBztOJlaMozinJswfWPLsBzGPeWQzkgMNgPL5ww5sdplaeZh99qBg7mFHcNYueC53CKkU21wh5R0oVp6GPOfz/xDg62EH1N4ci7mzRjQ87njsP6BiS+mTUqMPuaFWYoc4BjP5AE6gH4y892BtenJHA+ydwHsHFLmzqctBLiPi9pADjZW3yeR0On4qG9845EAzCXDDg8ARDzuHt8yF+tEuY+weYgbOudEL55hvevj4UxnKqD+ExjQ0rArISAFlrofwuR2xn2Ci+aCI44MgcA+SOAVCNy/eB860f+wpo8H9oBDjXFQfFBA/7ISGituvAr6HnSCAOSEaOUM4BkP2IIkxA/4HI9DZwt6BRgAgEKnpJZu8jJ78P4SYA/bzkDPmhKvVPAGhCOIa1oyKlRww7gAfhfkgsSqtuWP4IldwL8UlB5t4Ko6E6YZFakfESxH88PwP3HuIzx92ek0gmFI5kMHxAzAQemDw88BxM4crYIBC8oHAZw8cVxOYfACbNLbmkEEUVQu7eMP94BnGWYYijJ6KA5IdoS0Bjz3s+AHYA6Xv4XNcnQl5ethhHof1NkA8T+qNyzmzL0grmEHdg4X7dzQ2w3p+QLwl1+QDzeDDDtMoVWsEnUGH47/OK0/cHyIvKZCWoD/kukmSiFkkbWW9e82IKaSN7EltkoR1w+uOec6aswcwvvdW4wrE98Fwfu5897nNWCNxR85sIRTTc0Tz8mAgKy/uHoj9IudC8XRvwLYHt5xJ88TBwwkxa6EYtXIccnZvvhEee8jlBv7ByIEoBz9ErP3g1AHz8CrBvtl1draavXfoJnoesolx1oGVtx+MWH7IsSES946HXXAZeEBrnmM82YMB7w+K0ZRwwu3jwagfXr2N0SMNpwgHc7XIYSEcuhD5/mPc/69f919sL/f/kpjef9E8pTKK9/+SnN3/i3B3Dgzef0He+Oq8di78fQUse5unv0UrrE3H5fp31evl+tRrJeO+vwT3bNcl1pcYnOl6vOTmcv2tOLzw1+W6xPmS6zNwzOM5jPtjYNwfZy9+jA3cng7kY/CuR+LdbBD2eoAembWodR6DPT7++uxxv0z+I5Kc4NlHBVCPs/eqYNsr59diQ50ZAf7+z3US1z1QJHvg3j2ff2hvltjtbYX2SMTrkcjHo1TAewGjFP6YGD/my0vFt5NYHoM9Sc8+aniLJEAkjotn9sKe9jRXcPzzmJ/W56J+9goP7TFcWHK7ODdxpgewzh/3Nu58NGCJOuvjntYBVAQfFZwg+WE5cB8hwkReUF563DuMwd5uHE70zWFyHnOMhx4lL2A1WHsD54D752pP4n1vDTwYfQ18vn28N1PrfQ9owJ7hJOnflHY6vN0j4wkec92DPSoawv57v+QwRJdUXkBq8mfcfk7cHxGyZIzDBwmEQH9kTMjjLMn3hHBQQeFMDGko90vzrBXQYt97xkRJoCcAfgKQ4PePOXMWQvQfUTHeMwSx10HB5XZuVsj87hUC3+tNi0QIFM4g0drrhvKByF94Pk7IHwlz+CiJ657Oz0MuYHUvCAlgth73erN3Ur9K80uRFUl+e9kII6LzKBHZnq8XrWkgc7bnm7DH/ZLPpPVgk7nnif13TtAcB/++1zg7pzk7zPHjHh+yqEMYpsH+8Y57pn6oAVKI10eU4zmBJrj+cQ+YTUJjEDF/2BP1PFvvkRpmhDrH7W+vDM72/NktQ5FHoAF8YHjhIXc0q44BwCOjoVT8HxXD/Kg0utL5TZPZPaPje5lfOW6ifBFltu/3TMz29GANHhLs9bw+UnoLGG6SbzgN52osn/lQwT9yw9zHPeOxFJ8j1dojk/sg3t+N+/6ncSdJnjJO+yVxUPeSxksRkMV/GeMm3s8J3n4JyEdm+i81KGRjQu2BEz8BTFRRkIRPxUM45wOQz8fceUnr7IH7tT1JOc+Fe3I9J+KamuGRmqucKPwc2LuGJaFR+n3vzrDnPZhXxkws8rSXm3rxTHsw/3swx2BdIjkluWQPDDOod+5ArssNOdsrfKnVE8LPTEPx4KgP9R05mF8UY3vlUnL4EPk8WUfamkodP3i5lmniIS3YGzhW0GaEj0KjDGsIcD2geroXPIxSb+KUf2/AN8jXD4zRdL3DinNLTe8NXJkDe0F/Bv2SqD9Wb7AX+Cl3+N0/1/c/lflh3PeOJKYgx9zxDu/79oC5sBo+z37QZ3JQ3FFDgpKyx9ihZmtvKEjOcKTCJUjAKoHujcZ4byz4vS4uJvG2NH4enFvJ3po7L0/tjUYitxkyk+B4OM/S7OagUFjWsBhvZOBied66d62pjNGxvRN3MfnfK0Mur7ag9+6BBnGf4Pe581wxhsoaG6uXSIGd3GFMkbrPQbNqNe8p8O15Pjc001rjn0f6ody4ru36adyfPhb81eU/7SOIKbieGPA9/XrPEyJUwXPu5Bq60CeQhJ72EYW4j1gzWOMJXYcA3RNTfE/WCanFIFmIymvcjfc8xQowE6MnLaZ7Y5O5cm264h07jdwbhG+leLB1odVVWIt54vwY7vvg8qccWCdnasD6rZz1LPP45qc4fEpheA3G/Sk89x6MW6wGJMq9qWn01FCo00ysYhqYJ8VMPVmmrww2n3LcOyD3PQmxfErJUd5hKhHDJ6AOqPc+oXwevOspYUP7ROToSTn3k6WJ0vQ5doA131c8Nrr/PH0Y9z2RYCWQT+Dn3PqeBJMkYtznE7iuJQ5PhnUflZ9dwAfP6TUE2nPSOVIJmYYrS36kvDyBBunJY6qMeEP3b43b0wpGA60zC58g8dRq6EmJI8VL2p9IcDy2lol7MtYjt0crD1r548lRB94aWjOeEnafnLX0FGve9nqThdbcU4L6XpMnpHh7cfkE4v7J0YjOB5FPgel92q/X6D1F8ENsbp4MtfWYCIOedZ5Wfj/icS0+AsD7T+OOih1iPDwXSorIvjhB1gTbem7094/Oc3lMtdcMasUv7Tcm/14sSaZLM3dPyhli9/QYgTMPHqz4jjU4Tw4MPEbiAl0rJlcxMXyKqAnUaCM1KOE4Fbch3GKNjQd3j5FcjmLzUeGSpwj+XpMzPUMED9c/gjh5ctSD9L4UHP1k4NunM11IU53KayGYfjTWC2pUU+Ddo1VazVjuQQZGj5HPM2v+mbiLV7EiWIvzFcVZrn/bef6SK6UgPsbksrjg9t+Apb8yb8UlNv8ndKP4grVt3X/xCZxTnN+IX7zM5Vqhlr8b9+K7cf/+w/OvXzxbhYISjmAzz55NxxBZkSighXGPqYGeJ16Ty0uRKE4FaCQiz/S8EtGQXbp2Hg9OU8R7jXvXOkMB1FeR6ByePReMOS0csSmM+y8icVUYjVARl/dHD4YKh1krEteNJWeF8N4iQh9TYLtw5DC2tlI/XySqbcd7H72DmeJfbmQ/sxksPmHv5xxGp4/Vn4n7DzP0/OtAz5wJIwjsOTBSz8H9i5+L02epdZ8LwTwXTpPwsT/L+6nnhecooXpW1hMbhQK8h7ielfVOzhHm0RHv5xSmUtgfa9oL3eQ/Cz8vcj+rhWfid1ADsddj8ow0yXul/gpbE4M05c/c/RSOjST1vI+oXe68Bb9f2DAXSj4KoNktgDMieCfe8UzxjlY/Adeq+Sb2v8A7YOCerUa2oOviuRA4CYkDaHCfC5+OUOs/h7WSQLDncXg2cp6oowhWC0ODaV0fqWFmrWelOZ7jh8w3EQ+u/p9TmkFpsFnI51nst1CwqzTLz4KWevLG6YOWN9YfFoyHpOKh+DntvE9hvWj1WPC+S9KJZ0SvFLz8evdP4/5c8EIyNzGhsHDE/swIxzNnpAreYHGCFgbw5D6C9KW1n/fEXoulseUCSd0brkudhTrj73sJ803tmdt/WAz/uydfCgG7niAirEATZMOBlV1nHtNCFvJnRWiegaI6OX9+Wrwn7y3omqDO9TybTnK1xe6xoHP0pMQtFOqwZhfY+thTTtQU9b4Q50WA7YLPX1ivz4y4Lt5F3B+e4bmgc3OCxYLGVEiOZG0UvAleNL8FwQnhOdEcM4ad48XnIH4kJ3OmhhioLGIW5qSga+Npz3CyxjFFwBcFH6/FOyR8FUKjFmIkjGFBizuJXe1bBcKYSDpIDXvIfHCDBsnQc3ii6r/g65Mb+nz87lGoy+eCb8qf94qBC7iAMkZUPJ8FDaAGN0+M/of6HNbYE1UjVN0KNUfhVRskkP6HGzAQPPEsNLfPUj1zTZPgBykcPjFrk2ekPGYhn/050E82z/tlXrXfU56N8wzPBXM2ygcX5B67/3z/sHvmjLBA3lxhPCMEQ4Gbu19oItj9FLy5JdfZy4LNiqwWG+6zPRg/5D40/gVvcsS4g/mEc8jlTouDhL2Q9MJCLxS8MaQahX0kPhbsEA0aJ/wsiRU+/IhYL8D6ScUjwGXKd4E1aK76YvL5ZKk5b0z3cmNjxmDhwHLqM3h0qgD4utDxb8XoorlF8S6ZAEkX9kJ8HNhS9VnTzz2Ifa0GpM9iuGe/EpaRWO/1fYjmH43X3sbdT3snx3nu2ytcDODjyZE3DdfkN10JNCnZOj+vpXE/50UF8MVr5izg2ScwtKmEPdZcr5GbVOt7moAUcYxc72l/5jhZcQ2I8VORlnyeisgm7gtwS3JRcubxqRAah5TN+RoYPGd+92Acz81nMVjcJ+SAGCO5xln3WMOVZM39J2IzJt57bM9PHhPsjcea+NivV5tPa+vCuXXdYty/G+XuxfHwi/Lzs+H31rVir5dE90j3vUSsec5ze/OI3PeSeO8vK+c89n0vxdcwrefc48sn5/fli8boZaV3vHyRevpb8Ol99zny8/KXx+/lL+bCF4OW/Y2c/vKF4sv9nHLPLyvv97P4+MUycX8BTN0LQHYvzOZelM8sZEoV4IsQjJdIIUMS/GJsEF4iBUWK84txvZfEhRJTAC8C5l4ce0CL82WlRg7BzYuQJ0RstDWkWL44G1K01l6Y96XMp/auZ5CDXoz50N7vaYBfjLh8iRSKl4S1jOD7Mxq4lwTxtPArohEvK5m2F4cWpNCiFwe3vggxkbjvJWLvL8DvXgSP4fEMLysa4+dIXvRgA9KDEsfHs8MjPhtr8MXJXc+JGxFNd4SY/5y4cwVwsmBpK9QX4dKep96rGYkX8J2ez63i+WIkRVQgXoydoTUvlvsRQn8p7U2GZuxeEMw4LvOeShkv8LvL0/+y+yiB/JS6QXgBhfjF2Oi9fNYVxqXU70Ew/1zY1pnj/fd/Z8+hgruIbYk1Cy+AeHt4L3XtvBDnsgqkx7BA+ysBcS+X+X2e4c6jj6geviQy7rF68Mxw4EvCpkYaLLyUtkbBrQclNsCEBhSlrcEnny99eZs//xLpK6icq3gvbYOaGK5G+cuFk9I+NEK03Pqel/mfyryU/ILP8wXLJcF5TZLVsD0Tgkgeulz+Xg1eqQeObF5KLOjI1IAFU5kurh7QWItcIix1n6XBuJcySbC5Lel8xxr/p1LHkYhXg3Fn1y59OGGbzlJZs2S4o1zJnJeOGJS4+X6WGqsyPvYvJViD5anpT1Wz2vtQgRc1wrKnEshDGfl7RxzCWDwL+aPMyXOJN+svBR7zZ4dpVAcQpW64KI5C8PzMxSe2+StXyv/sTM+lbYj0Gy+MBqHGWdrXs5XvYvmKyrdxWrzwjKnyBQ7V1IFLAWhcoiEjihXl+e4/rx/GHRUY1BhZngkNQAkWauk0plazYTECJSjQXiNQgoagNOYwlSlIYeBK0ODEvL+MMFhlgnOXkbEthSZEy32ZID/Bv19LoaaLRBgI/v2KrrUH8lYauWMN7JeGxqQ08qpl4FEw+fVwYxlZz1q+yoQ8vwf41IPVVLxaJqotlMvKlbUA1b/S+I7SEb9Y7SwdmuHdX+GsqzJC31Ccp9DNUvBHpdNkl4k/K+J86nMh6/er/O5fE/eSFrBXymAG1ysj3K9GYnktGaL/dYhXIrGvpfAe6jwlLeKvBREshfhfy0DMNMJQCu3kjMXSlLwWRE4ksmF+pwBiKdAzLLyWDLisRBWuKcSENIlFkHuBSF6ZGLwSMVZzBZjiV+15al9KXbxSRpWqw5LHzyK3mohK+y+ZfQI8gYrdq0Lqr0ysXw2iKuH3lWuuKdwxPPRqrAXyZ9BQvZaGNRzG5JXI4avBSL9aG6fSYIiJPFH1/VoKfOYQ6FfFhL2Wcu29WmJRKLGV1uP4o8D0isKWqsPE56+c5kkNFpGzV4Hrw4urT03rXwFdeEW0wqG1IicWvIZJ5+U8HoeBV+KcrwzHvlKekTtfKXs/8UxCfZHvJzD2KvgKqIYEvtOGG5xflLzvosZ+7vH7xL36ZdwDguaucKFXxry/Ap1ZuC71Myn+5TLZlNF5IdbWCOrEyAskRYHo5HdaE8L8TIHhtVyCMHzfK5Po14B8XwPj+woIDpcTLg4SuZ3sowz2Ui7PK5niV6LoODKl8uLCecnHmsPJIt7B56ThKBXhYnJBXhIRlAzBheQn1NwLU8OvGk8AxvyVqa85PqhaEPfNGIHXYtkYcrgQ8VEsf17EichNeD9Z64yovijxluLB8eIr0WAvmncGCxwGXyl+KYQzFAS/U+fhzFyp8FNBx5DTQ6repXrjsAl9UypwzKJRDuNZKA0ukV8OPy/C0Oi1AHmUa5gRXyENLJgG7ZXzM4w5ewUvNS8Fcz8xUWX5matFxEyXurYj50CNJKWLr0qj8yoNdkrepGtxpbwO1yy/Sv6sBHxqwZynEPQU9BnhQGihLdUv474gFs9FCITUtb86ikUy7qE5Qg0ZGVRBIChzbjJ/Atm9EMDgDIvVUHDv1kwTGkMuxy+aiCmYEsmVaBZVE13GX8jkRTLuaH7NDUbBYLfQcyGR3yvXwIHNvtqgF1g9cQJswhVgEr3DC7HmCoEzE+ERifcr2Iy+WLm/ALDv1JUUOHPnz9IwoftkmnPv3sS4F6Bug/G35vclrLvCmIcC4IfC7i04cxSDK3Ojz2n53o53CQcI56vaeYZ605pUsbm07KvAzvpirJsXZShj8hLSQHNh3IPrrUwjLJfrcv1fuF4uMbhcl+tyXa7Ldbku11rXb+Ne/THpbyX9769+vX3Ss9Y134if3y7N0pfAzNsnYvCr1cQ59vD2CWd9M675lnAPb38hhj67pv4tPPP2xetnzTOsuf+39Kbor+dCa05T89yn1X3l46KUur+Gpr1Rxv3t+/+8fRy6kgv2zQjEN0Nh/L6/ihfmtwSCHVPcbxEg0eKggeXNAKq3yEKIzcdbdUYBkM5S4STmxrWyDy++34Cm8A1ch7v/zYh96d45tlVeCTjpLVI03oI9iO8Fc/1GYbqi3/lmyBn6+/+do8KFDcHPm4DNxX4qm5B5uRHCVSK9sGoIUjtvYK2/MZy0hh5K2EZ1X1v/LUFz91b58ARpZUXXiIbxV8SrVHbjyMasStdgvTH5ffM0L5UehzcwPkn0v1ry3NvsT1HelP28JeCat0TNzlvF1uh3415/N+6VbCx+/746FSZNtCTBfosx7pXS5VRLY/g2+1OGN0F8qSJ5sxJCRb+DTMTsnpfQQFZ/nnljTA9iSNkYFwChOYzTK7FvKqbSeyADpRmdapmTN9DkvkkYrma5qXTTTp3zTTH1XBG/OUzSG2WGK6Fu5nGoiOclUqv4Wg738CYQ5ZtmairFLFVybue19crE6Y0i80oQ+JLP8eKq6Ly8KRzGcgF1XyXj6E0xDW8S1wY5RIzsybln+3jhGvmKEbBKyHcVaFHFDwtCnhUHCpVSq5WgA8G6b0qMXiuZJzhBt5h8bQ9vRKN78v6KxxKnU+KZCWy/EL6CHTYwXEzlPKwbsu4JX/NG5JFrhiG+BY37W7hOJZteDQekt1AGAG+Mvr8aGjx2MFNhDfGbMnBjtb6aGfeK56U533BN4xvwVylvzNAJmtBXEBb+GHdOVKQiXdzHiVK4DrdWxQNKMrPz66UK3ietI33OAbpaCspbKe+JFe5KeLbiBdj8rpImHWT/bBGF4CbMGJQ3CRcVZnzU+EpYrmzPa6QC71nCo/fMCJYs+DPU9ytQm+Y64fZVRGCgdLy/ijxLlQAr4b+LX1dlWL/CeRv+rEqUU7Aew4ka8hxpBioHVipnfCug3ihNqgw5UbD/SjVcwDqvxjy9WvlO03nUF5Sgv0D0yKLXKbBfCUOWsNmogOe83Fcl4MUKwH+paH7l9ABSfioHb1X+WgwHXCyfId5kue9fxt1DMhZTYDVl3MYrIDklUPwVQJpaQFGASvGwAKlS1kFMs4fsrLG0/IzkxWLM0BimMhmW+qiMxtn6zspRP5UjT6j5qQAMlyB5l4ARsrzPayxSmVC0cZWwEBp3jwghRqoynt8zALIKJdqAV8amtQJy6TF2VYTWILGpEtxnHR4IhuUNHZxVBp2JHYhVRu2onN7GO3iJ5UYPj1QOnq4SNWRSTBBei/ErFYBHaxOIvhfNleyxZhN34sb3AjPh78KL3mfPvgc/m4lKIZt35r53g2i8G975rojaezW75yNOytnew9hWRHyJdd6RvYf5LZm9KQX4XjnErzJexqbj3bMWkbd3i3EpiRwD73xncPkOPm+pm/cKFOnKUXeO6934+/fSsXZQz+9EXZ7UQPhM6Sfe9wpsgpj9LGqsJPhUiieFo2pm9Ll6Fur4vcKboXewWXi3YlbQlvdK0SmLmS39HGTitZhvEZHzCDwTxozSHOs3b6IXoN4j7P+9jIgb+r6YfFVxGHm3ms4yUidB4/meMn6Kt3q3TOQrHVsirxrqhvWQmuco/Vr8jnrc0Li/V4zglHTxv1Pg44SXeHb++bsEZOEZSqjeEfNe2siGej+X2HfC+IXm+F2LacWYfyDh79KaUuyIHL5Xsol9r2SSDXPyrjQZ0mfUvt8sjUpJGBoGG++lcnaioXoHTQd3xjfn81RMX43vn5vb91Jf/53Jyzv6HrDO3oR3sVzA1Op7UONcc/TOCKV0XnFPTF1p+X6f/VkIEoM3AFM/hjD/uxi+e5c4mXtPWOcl8ZmE29Lf4IX8yPJJKQhtwHOvIX64WAExFPFNNTkhF5e02X7X9AkwDZLuvJfK/svg/KWiSQEeKP5+pZ7hmvjA4HNYQ2tN0wVu3+8Eb2pcRHEI2WQr53kN8M3WmTQIEnTfOih5V/jhTfCOKK+/gXtFzL3nnFpdhwPa91KP17viZbih7fsP4/4+M+4xl2YW177ejGbiXUmI9bwx97xX+jcGa8XsLXHsz7Xnc8UIMUfvX+xC9ojE7u0LnzEW52+OJuBceF5rzc+om7Xxa33ec+6UmEipLzHvO7e2WN6nNbVfAZNWzKwR9zfB96TOt/f5twSxTKXXKfGqDXXeK9uwy8R3dULjfrn+RVf9Rd5b/6XnuFx/LwYv1+W6XJfrwp+X6+vm9pdxr/9OMG6U+zdfvYg+Ke6b+ftrIk717DpTLDYJYzJfa/O3YsN77jXzVgPNVZ0w1rVxL58kZhvvfXWC96Vodusvym31F6u7Wni2Xgcz0fVcr3T+2DrXYlh/AVzUX0gn1tKsOh0vnXXQVn8h7a7PtLcamLhv0A3U9kBvPMQUmMzNr397zbv27Ca44CKqhd+HRrkW4mIw3p7i3yDvjhCjjdHYbRhC2RBxhXJTn66xqXWDu0FyHKyzqSNE1yGqm1jxq/H8bhB81xhfnOCtFvZWA2f8wEc9i38NxqsmcFfz924Q/Nb0vzlMwfxXK+eqmWamNvBJvVxrYxX6ytgg1wAn14pxYup3g8ZRMWgbCrscfutIY1+DtWZsWjfcXmta52IbCZGTuRrheJjI/4bLGVfXgLaTuJjV/oaqrTrSE9UOjApatwE4FdLqyqlHiY3r5owN+sbooTa1Ut+1zRNvDIOBWZ6Xxn0OesoAscH59Qf5G6M4kiYMONCGM+/18v6w+Dc1RmjslKzWRYI1o/Wy8djUYENQ0xPljQSsuQGpFZM0j1lNx22jATA02JS41oJAMYS9IciGIg0qv/N7Nwy5S7miBCjE7CI2JS9cJ/9HTcapzsbYNCzEbVaniLghZmJTn+KDEpJNzTdnC9wEIgk30JIhCE1+UBMbTZRqpmlTDMmGwlR9GjOyKawxA6LmD2wC53vZCKJFGmtm35uKzh9V/xJfcrHYAEZ1I/CK9u3cphJ4h2mCN9Lgp5b1bUPhtFL4TdAxtJnaCPG34m0jmUNLY0PhMfQLNa33JFY5A1bLBlj7dmvDrPXxN8kbgT83ig/YAI34RuA71l9Zm7aaiRsXP47/a6b+pcYkWOdN0O8NMgirFV2u8YEXqVWWQTTBce81UI8/jPum+WncKUHZ/BL6TbX8fGG0y9m90mR1/nxNT1DDdyx+5u6pAAEI38+ci32ftI9yKcYn5kCYGofTw00tTO8C8pbOEXRqSzGVzl0LuZFiKRDT/H6OzMjYKdgJYyE1eayxYIwVdR72W4GPZ8oZHqi1id9zZ+UmzJuaNgrU/qlvIBbNGYN1SWhUXFQMMdVK/Yf/ZuLEfRvzXjH1wWDgvZa/zWHrtZabW2pwoa7LTf+Z2LxrtUbhPfz2UsDbhplSbqRLMA0bptmWGrYFb9QMT9aKntQ8vhfmWctnLUxxQewtMF4LvFsBulkt+QHRNlKnHRpNxkTiagAzqh4r+k192wxplJYrwRt8///W97+LM5TS/tWmqJZrT4ov6cVqxZcJsX9nBpHcmlJztqmEup81RFJdUUMVbghI8rWkE0wDzvk4sY5BH8z4u5/GHUpgDV4VWPCIiZbWryJ+Z/19hZkSloQt+0DOjL4LXbtOsIbWdNXGhswajzoRhrRmxJN7BHu1s95ic4i+rwLroDY0g7Ux50hNIIaImQKbMSJcqkBa42qpGdRk1MBgwlPDlVI/4c+lIV81gJ3KWKMWTvbEPKa+teYDGTJZa9MSEysvVIl5ycITHjxbzyMZtMqB3Sqxr6lW0gmLX6wAPrPokreGK+P5Ksfn3jqScNIgxj2lmZtdW+DwW+rn7/dtK+a+BADffvyX2dtWOfe2NgLu1zNbD2Dq+GsLrrO1ikulPOcomm39Jz+W828TY3djmQKlIs61ririMybOW6XmqBrZMuttQaLn7tvGcNQn5WvraSZj8A8a2S3IS9tYc1obGow6oblLyaveWFDx1DTCa9wDrG9jmvpzDooiuHyL6oG3rirZu7iGJBZ9Md6zTZ03raEP9Fw106n0yzuUSdHopNaRH8Z9+/1/trVuIsPPtfuQ+6Wft0KxbEHi3KIGI7h/S5zFIohb8LzWeKGNw9b4vDdfyJlTmZbf6wtN3taZA++ZoTWqP6K4NdSTN5ZbsA5QfGyN590mxEdqvok919ZZX0lMO1DfWzDfW0c+Uty3XbOpicTbNtH+4GbU8ZyH7z052hpjuTXw2da43rsjn9sIft0aa3AN7KbkQWT/W6cfiMHj1jC83Tp4Gt3fNlJbY3TWXefziTt1mHclwVJBaoW6VQzy1iDO0rtQsf0eDPL9nvNswH1sgSLVGpqPfcfEfxMRW49xhnPivDYAjqh9vwMxSGGstXVjcrJxniFmL5vI3IQYtpLuNqJmrU2PJV6ocbaIXWx9bIz8sAWwgtbFNsJ8xHCENZYxRgSNuQd/W6OJ3BownEp/N0JNbkA94eLzbjCdnvxtHOfbRHgTdEi4NTRWKO+Se218/GHhaUtDtzXw8MbhVzx8buWw2LyQ+f/fxL39OXEnk9bYCH61q8GB9XEfZcrN74vZK3Jf43teBMrHuh+T3sawdhN5dsGMmc1cSuw09oZmEa8mooloDHhphLymqqNEjVGyPTWJztOcJz6bM8R70/B43HxCzk3c2xj0oVHuaxLzQnMmzYqtrRRnaT5ZhxPmKda4/m3XZg0d/Ivr4pz73CTwMCvH4NefyjQOw9IQ4tsYANKAJrZxmM9QEBqnmWgMhqExFkezgvEI/qTEZdwteU+49805m77Gkf/GF7NNYzDuzRlIrklgrj/O1ETUlsW4N8BaVq7w4rtRplSNI6eNgRsaY65TxLoBObFh6tlbe80KDWuzUnPYJKix2qg7KRvb5oxxbNIYtE1MLTcrmcTmC5rjJnFsmsS61di9XfK4NMrQZO1hsa3J+vM37vOHMiZYWSOYmwYzqNnH+s2fn61GOauNBrixgS9r6Hdm4X0A2LOG/jcVl+hJpZaftYncYnZTiXODme/M25BFmB4qp1lYBykaVeZcJ3VG4JfNRRNg24OJBs8NWddUHVmNaGMUrwqvlwyslYz7GcRiZuG1huBxoOazOT44TDVMswSsHfNNTNbEPW8esjRgfTWJmjYLHzdMvgjNypp/zIMldQ0lLlnsQMyiGSFOlLXm2M44bUD3GtYZ8WzW6J4o4+Km6UCD6X+21mDHgf1Mq2VNNxqAExvci8G/bwz81ij8rQ1B0M/aX38qkwVAowyqKkChCDQBQBkwZpJxqJZFkGmEIpB+RgQ1m+0jNNnU3hbvrpbvzCThZgo4U4iRixMEhEYwPlq+UXJBpp9GMckUws5qWTSyRjZMIpkguTc2kCc4JtaTTF2m7FE6SyaRU6OclclR1igTEIeByZpZzRM1mClT6GzWEGVMA06dYfEeiddqoRls9D9/yYhBQFhvmTAwoOqQ4maOc7OG5uf5HjJBULmGM1M4hq1HrnYVsxDiI1N4J2OaeLa5BXg1a/BGeFFTyJCHwyejo1kwGCCbLm2fAaaoOsoczdqC++rTeGQc5zEGkPIEGaOZWcM3GhlVk+hQKuCMrOb9QwYMKjKkgQ/iSPqZmt7TtuK1LhO80yK+NfF+ajgb8GZWAXrV8Pwf4jzkUIofuBrJuHpnPOKCHyWuE3guIwbhGTiU+x3X0LhnjVxEGQekmp/0bRs66ZohpfYSFjwpUAIwJONOGbOMOAMp8oJAUAWcCYYwowRy/m5O7Bvmm4hm+by0/21Dg5qc2DL71MQqq4FmhCo+gkgyYapONnwNnc+MwC15H5d/Jh5ikzrHstAoSjgn8xsSQ2Bms4auY5L0Q0wQOM6EbzcyZeKfMVghhYKZEGcNPVw4Efqarpmtkl9SiKj3ccMCoAEn98WIIze4yAJDtDBxSkOaCZxLikfNN0sZJcI1H2+tWc2ECW8W5JjEQ0Pvi8UHUmeN3kywZ5WawJrXHCp+LGY4PZ0NnLKKrleKL1j+Y86Vcd8UCPunciHGs+aHYBKeM4H/qbyo5rHRTaA2caYa56ymTbTEv5n2rR43tKQaD+kvHAyNacZ4rQxojDX8s/XV8F6AHAwqPpFqlJC/HiCbjIbwMLU8/D459w/jngXGne1ygpdk3PR7Rg4bwcxphjbTPlNMcUaZyvqUwEgwEWIgFjoXu1oGmERGWS28o6aFhrufM+4ZMz3jiJN6ZvFzDYqWUIzIFJnNB7deKAI1/jxycaS+Bc+cCcabe88WwQ9CcKHhquiGIQOINPzzNym+W0tsmYZNMm4ffwNL1Q36furbkaxmmj2DwFDfHGU1PbQ4adaFXJKxqZa434Lx30qmhxElrqkhjTvRbHB/riU1zVktG6mslg0h27xrdQaa+gwwpRllIgwYJRtLAYdz447yRYaej2n6t7XBiCF7qpmhyYoX2tyIxl36FqxWMKp5g4ZuPrg/HV3UEtX8VvpAEG10Ve2sdX5GjHsGDGO2TM1p36xqA+hMMO2IVyO/MQ7PIhl39fpIanO5/uqLmtZdrqRk/9fk/3JdrpSY0rBVr/TuSw4u1/+FGvu38Pv/RQ2KOfMP4777/j874OZd8N/557sVD7hL+J4d82/rs577d8q9Kc65i/wc2fNuhdx+5jq7MxTpTsnr7hPOkKpud18MC1nCc33nRnWtXcQ+UmJilzgGa2BjtwKGvTW4S1AfP/CB1njUexJyUMy9a2j9zqDXOwVbUfXSnue8MbHYGeK0+wJ71nxjLB5SeKGdcy8pdGDnzVk4cYeC28ov2ynE5gnMjriyBMK2S5BIUeBbPSE7JXE7g/HbzfKDFL529h24j9/vbfkGZCfk0YIHVEx3ANmnMuM7Q/HtEuDf0ljtKJJoZbxptR9jCDIQYwtsCZ/tAJzv0Aa5xWrbYyJ2yn/Z2LZxAqbWWRtn/KyY30UKqbaeVCsWc7Rj4qOZ2p0hV7uETZhlOJS6IfKasp2BL1Qf0DobyBar879lOLEzcFEqs2zV7l0kP+xAHrAMSXZgvDgdtL7Xok2Br/5j3KUX7jiz2p4aJnKNdmnq2OJsfSZpRzQMO6LJWKzHiPROEXPE/M9NO2U0dg7A7Ih97Lj3tHqjsgMarcXFxOgDD4v9oATaGifTLZ2Xk/e3uHhRObMWO/lci5OUKEItMyVqMUOBYE4jmS1V90BMMwarIV5/N10tk2+mvjOhtk3nb+mfw71KeZvXAbWnnfBzpqyZAVyJChJ1JmHCQ++95bGZGXiFHYRwOWyX+961ukaw9dXScfi9Zos3CxbjfnJOgLd2lka+xQcn5kahJfZsGfI02HNIE74LBkecbopxCjRtgS8CKzswPySHt/5vvMlaa+Umddcusa95nB2IX1abgTizvqG16dcO8K9SPiz6HX5m3RdVR6qfXfLjnz+VCQlZ3Yx0Xwv8GxW0VvmZIFhovy2zN/Q+xNy2xrhZY9MY1/Ksr8RyUYDW96U6RwPEvHXuDTmfVg/C79mmDsl9ixHYqvHV4mGoIZZQLXXYGvHeKuu3DtxS50f5wHJfK5xBO6P3PIxxd+OpNcTBg0Pl3aSQt/KwAtKlNeoqFu9e3ZpftVML24T61TrrnKtPhatDkwUNuFqFj7X3tgBmic+9ZjdrI+JrwY/Hn639nILd3/lHtMDK5xp3Lz/7ZdwRAFEEixZj6xAG9FmvWLXOd8acv52Rnsc0Ig2O9FntAom/QFoQzNY9WRs6lChjC926bsuIIEoOLUCWrdKkWo1V6zBkHgMhCSuCTetgQDOQUiOSslltI+5vFa5OMUBpncOFNqE5szQfqAGxrulpjFoHn7WJYqOtr2m+pYGMGa54eAh8Z55isGQ02FE4bQ017WxIXAMO4rPcojueQZm3HhoQx566QWsGMfWWxrKjjHvwYN4ajfs8kWjAQNDmrZEsKGApoM4t+2X2mLcOoo05/6/PciGWObj//63jENWcww5FntQ7W6NRbBMJUyOco9E/h/PVOJpjKsat0UxLa4ENTq6Zwxn+co+ZFc6SN7iY5e2ypnKl1rT18+a0LnIuH9YJEIX9Ro5zPucXkDfC8+VBnefGbyW1eJqHKAiHWHiqVc4k7anl9yFhnjMBOceVloFPK5hQ5Jttj5m2mOSwNhCD6R20ARyaE/HPG8U7tMYcAFyt1UQu+SZEp1FcW9cQ+CNv5brMQ4xrdeY17u2Sx+CBI9gw5E1kbLU9eBvT9mPi3v0y7kSSFkLRghOeVgi09HxATCQ4CILIARDnoInJW91g5oyY5qFxb21Jzxu5cHOtSWhpUcgbPm5iXiTzyhROHuaQIywLbkCzyeHlBM/OiUhuFR7iffnM7OWtr3vXjEwONElzk51TBk5rfBmByQnTnYdfsQe4zbU1FPLOFTznSr2JpigUCC4XEgYaPj/h7xHjHnKF1lSJmKB4QTCc5Hqg6aKaDspQ5e0pTsizW00r0nxS/N0w9RychcSFYNJzrm5BE0XqDNU4EJhxm9NGr6McNIg5pU9CTkPu5nQrl7iuNWhQgw0ucpRfWqXBaXgvgTTveRPpxxhjnguYyJEBJoojoF5zYe+5Zu6FZpPKVd7aNF4y7mKDwQzAc70O/xh3zZCqE2ZQVFFxzdHiQI20Uhi5cnF72yn/VgUYfK+0X+09CAmg79OILv9l0PLGFmeuuGPyhDY+ORgTcj8NbgY4LKoCZDCpeRtMvxkRk+piZ61bZlKaM0Y854wP8H5rPJF4s2YA2AM6KckbWx16OIHDCYfN7NfvM4HXUD1A+SlnGvO8Yc4LTN+13Fl4V72vAfm8We49l2KA/s2z82LP18Tzq4ZRybghvJ0ZuSBcPwPwszPWUR4Rq1h9ysC1cmOcEVzH/owOVnIFv1yDbfU8KA5QPwANBaghdYNN+X/Va/ef/Ltx9wpG7GUxN2teuzO+Z5fgnbsVcrFWHr/itfZ+d5+M391nYLqRJ0f5v7Ce/83X7gvWNTqYWLsudys8u1OaJ2tcYs9gGe54OEkzyGvWsRUHnoHbV60961l2nxh7S5Od8p1fnp87o3G/XK4gY59drst1uS7Xv43rLme+XJc4XnJ3uVYy7kHw97+uFC/aW5LdYUDYB+vsQbO8D3/f+QG5967RCXuX4t4B9yjP7j2F2GHP7aV8dj687A37JDHbrUhInWP9Tj73Pqam5r/v0pHyPjEH7GNy7tljZ4vjPiGu95Za7GhMJ8FxTB4723tM/J1QZ9g9d2nNxT6os/1XM0RdpAZ7ddCgX6uav86Rz86G1/38OYe+7ZWa36fwWJb9OHC87+I0YL9C/e9RPohcc98Jnq6Lx5u4h4Vx7/DN7ikC6/6AQCK2PQVeLQAcuDtdhPeMYZ7vbx/8G3nPnjG5J2f8FZe5eO45Ye74gt4zl9WASwUkPqMY/z1qboU4WM8UYktaYy/giCIxsIDY505wxeBIImot3/tOub8j9trhzeBijc6W573RnO0dz5Dv0wxbtyRQzXjsO2GtziDS0uChO70kot93PtEWcd3Rv99bzH8n1HAQw72haXU1ZQTveIYAe0Vo951Qw528xwVfzPXT2xRyHP79z9j2jYApC+8pON97hhQdjbffuOvo2kVzaR287BWzHs2tYbw7XWNRLdsDfEx5lcVws5ONPtSQd8Qznb2R3ANDkBCDMI9bh4GcrwX4da/FtwPi8MO47/vvxr2jhZ8T1X1ICCHxd4AgB4b5x8+7jnhPR4CSELq9ZHYIQaQCGQKLWlc1ZuHZlE5zsa/2lKz2QnOhkoEQkzkR7juDAAtGlSSL+fmaP/dxmKCatT2RLzbnnULswft33WlDR5lfyVgvjFer5KyTTVLY6InGlCNIogndMzXAPh/kbvE8cd6c+x1o0rWaWxhd1EwQ5mrf8c2Y1MSL/EDkbt/yMVn8rmM4r2OMpFQPSK0w/MXigWrmmBjM76Nqk1orfA7isZbHLcfJoUDuBTO5qLuO5r19R5j4js6fxrMLDHV6U7PAbLjHj/8D4G7ZqLGc1PG4zzu6RqiY7Tlz2QYaBzQOXLwko816BmXAKA26NL2X8Cfex/gvqnHW/Icac7S+guZpgWfF5LOeqcPe7+arDjhL6Ek7vYlfaKPAyxp/5wKXhjn7Hfv+l3EnD6sYYpK0icmBGnzEoHaMMepwQ5d34Lrc7+bE1ymNA/U76Qyt8dza850OYK0D3BNT9kVTYckdYLj3kpFqQWPMCbf2TQNg3LUYivixPNv6G0c4LhLuUWx1wrOGc+VAXHLAoJne30XmD2mKtRgjuOiIBlZq1DonF6AxQta0cHNHN4FobYvvEfSCHAqg522Xa/3+uQEbJ6lJ6SJqmjNIHT0QyjtM33Opyf44dwPUlJYXcBglmuGW2U8H8kynmzbxG3EgH1YPYjW46P3i/i2614G5b228mnvfbdXeztBstYK36xLqPIefhXHvQNLt/sEn3pJZ6CLMRKc83xkNpCY+mnHX4mMRwY5vHkwFgDYWHWE2OobYLeey4kT4psRkpDp5KmI6U4c3PyaD3oFNLkEocK6t50RzitYQaAxzbX+toaa7BMbdOBRwrY/it2Mm1Z2h1rWBAsrx1rzE3ucx6Q14jhbUMyu/NcweWnmIk6MNstW4U9/keLAvmSjKuKMNsTQF5775a4V4doxx7/zmkR10KX+mmLR5lrDQ+YcOeSw/xQyRgPPmrYNDOuPQ0DOosngvVJOJb27J3/027t9/KDqnsFPE1QLFpVzR+/n+zsIQwCJ8Z6sTjPUchfdsFmFFvsnoEhhwb87Q5q8zNABdRCG18TmGmgstP4jJ635huk1Qn50B3553GhuGAhD8IlXjkXjv5npoDWYawbK18bSe39O0x8YP4LmiTZj32ObiXJiM3UfrWFfjbMv7YrHZJYx9xJBLjKfnG6kUeWUMZdEaajzWIyhrFKlqxjIY64S4pBpsWYZpsdozN+5hcAtD0AvlOavYFd0ZCrhLa0wL4QyF4ZzFJ8auMNxTAHhA9licITdIbArH3uB723RnKs6E8cJ7VmeeijPwQHFmDipSNu6O81l4OdU9KbnL+rOlZqVaLyIwVawQE/Id7dfUx7VqJ1XdFwmaqALkq8KzJjOoKBx6lmoghepmERmPIoFmmJ8P8l8YuKNY0UOKVzhxLxykWJzZIO8jxSn189pkvVB+h4i9pWg/S3QKxTig5iKGANGGoTA2X0XiBi3GJBVKrNAG29NIFRECUjga1iIxZlM0DYWRTwqHGfHkrzD83pInq1n2CnYBYLsAGiDruzzDlMLYLFnzmaqOiwTm4TMGcVZjVBjzHLvvoosY4kQMsAqjYS4iGnSrb+B4CKkD7XyIx7LUSwHUrsewFxEaavKUP4z7j/8pDIbg+/2wCOdgUguQhLTPCyX44fM5sIZUFAjhsqLUg/dxe+ht8dHIERGzXANkH/xXidnecF4kn2j+EdG2YtaawxhSLoT8FA5zVDgaSUveoDP0dkP98XMO8kEBvr8AzQT5jn753z3IJ8hUWOISa45j77fUcApM7R0Y/h2f3nC+Xud9jd8sjQg65EC5G9Uxk94IOJtNAt0NWdGD3zT8eo+Xe5EBBNII7w0NemH0GZaJL1J3ljpHPUNhNO5FBA/AWtb7dG9vrPUiYiBg1aU9fU7BuHNkZxSJwis4fTqh+rJXbHz7yN+f60wWfH1mrHsjBvsvgMn+L8P3Z8Wz/4TzrsFh/RfGxVfioz4BpvpPxlj/f4grvjpn9n95/PpI39F/gXo+B198RVz2lHEfCOPeA4fqEyW3T3CoXgl8n0hsgcny/CrR+PVOIfpkkSktBU6JaO88K/Ou0nnGMpaczm0QUj3XG+u0T9BgB+8uzxGPczZZPRh3rh76CE7tiXd8YLz/GevSK+wRJqFExdHBxSVxf0n8vuxBrehA7VujxntHY9gb+cw6mLDozjka1zUGfF7f0q9g/nqFG1PqSwp8ALgpPWa5T8BTveIJ+vMNDcqP/cx4WN0brwndf6rvxr1UDFYZ/LuUSKQ3CmgPkAQjOuFnJZDskiG5kns+KKRSeg8jLKWFEHsAAALwuL2VgMiR8eqVOPaEKQifj206er1pKIFcLzBFkaTQYJRI09KDTYWEtw48g0M0SpAcSgBrVsEoJfLslTx1PC+E9y04KsBEqeWzF+LQnRJvKYhFuH7JCEmJcIBwblRMy47em4SzEjRjJdOclMQeJPG0NnJlyDHdUq9+Ny5MrZdC/S+Etg+4A6zhMtiL1sgtsDk/Xy/zUvnxZyvK2bQmqFR4AuFMtv56PL/a5yWgtyVXb/2yLiGdD+Pf6wOkkotbj59bNMId489+PPPr/4vKAk89fc6y1xvBEjTNpeebbUaTKCyWggaXGm9YuC9y4FAKmIG/Ifzx2fBr4l7O/masJISyZAhtAUwA6KVkoHpZyEoCmCVzsZOnjjFs3amwkIZAagAUwif3RwBwT8S8VEiBNRGC0Vg8IzVshPhxRu8kNy0hNlL8OrxB0RpHqWEqmQZ03/85Y0nEnYtxqZA01+iWvU5UnIhwdUThjjU5PUNevX5epKGgjGpJNE17JZ+l1uBTddfT031KpJGmuwRMAztR4bitX8a61Cb0/T/4pJSqi54woYLp0fa7EFWNb/olDsuOafS1BpMxlyTncgOGnm46qGfKoM44g841nyXXaBA5KwXMUDEq+9N9U8Zd4+ACMe7IFLTnY0LVZsmZR8YQl4TvoPIbYrzsCQ7o6Uao1DRK0ApJE0rOyPaCAWXyx2lEGXJ4YNxJPewZnQ85m9Ec1miHe6MaJcGgl9wUvxeai55pyKg89MpQSWhukIaq5OIRciEwZPu91g/jXvU/J+4hwXHTiJISX8ZgLsiv5w1WSRVgHxBStyyWkpi0kecg1iVFKVyPORd3/pJ5bmEEeh7EpSQOvSBKvW5USymWgtCx7+Dy3SvrU2KvECoZn+D/MIWMjZLLxfmY6RJlwsueMW+A8Sz7pYnlmi01v8JF1hlBXCw+qN9xU2SidhZ8ItQj9c7fgtMLXNEpWOTO0ANNdseb4VLIaQner9WM2KhQU/6WMKBSbRC8V/RyjZSd8Gc4WvNI4YeLDzHEIEW/BXmIMYQubuwVvhF4XcSdhskerE3id9S3jUUv6xzyTfhC5zujNvR8o8QaWEa/C45HFN5X84r4EK3OkWGjNKzkDLTQULDaZswFa7qptQjjzuJWiXdhxU4P1Ijkc7khZS8PYGH+QAbQvaD//Ydx742F5bl+TWDVoMa+o0t0lk4BWq8bDhVMaAFpguGNk/V3mgHqHLkxEGFSLHYRv4+9f831OidetDx2xhqwEisoOKvVPhofKw8kwEVh4ZguMf46kBvXqj+p2Ziv0f66OuB5zUCk0J9uxfh73m01rL2RKxwmN8qAfVZ9p9JcJs6FhEfmm6PVvVKX0Eet7TF7pz9JiSOLn3TgqRo+/sa9P2NwL9fffXVnLsbLdbku119/VZcYfA3evvD335+/z3r/JQ9fg0tTGfeK+W/sOheBkM9WAfdXKxZwtdY7Ep5Lu5f7XXUGkrSew3tfdaY6qc6A/eqM+63OdE5vDVUr7SX1Wf9GPaiAf6+Jh9hcVz3D093nYBVZqzpDfivnM7F4rFY2z6vrcGc7S5Ww/tY6a/XFvF2VwrhXCoFwpq0ybMxjMqqfG8dJa7CBoFLIj4tDOfy6pKAPWHyZZJn2r5G/JR/IvdWKhMbhrfrEQlLxYKwDNMYe41U56vvcAlpFGukqEr8eQYrBrpbfynClFjNvLlPup0qAlxTnrlY0B57zcLFewxTDZxri+TNmmFH15x+apRqqlEBtxzR6laOGvQ1tlaBO0Sa5MvCl5ZxafVWg3ljOhXi1hXGvv/9PBQTeIpqoWBVSsAebgS4VcyeJSzXoACiJ+zhz/nHfyV4GHUjiNegGtgLBrzVhUEEMepF6TUYFEkEh5KkCjYXnKoOccrWANr+WemI/G3SMiLge+DW0+IVNtTmWA4ZxS+7ChneOCYtBZol08Bnskjh3SdSWaMAGg3gNcj2cYGeQecDTRFfOxhepD0SbvA2zZc0KmNAi2lYO8Vxl0WVrU2jmR2NDZDlDSfHOYMMs0vSXkRphzsFg10IPf6k5Hv7owiKug60ezfEbZC63fCtaKUb45F2DbKxVrR989RnqivZ8LRl3zTRW3oQMS9Mc/c5BFm5xrcHwrgEURcqIDMTPa8V6cK45GOMz+PddAiBNFoMhYSzCuFhjPSg4HBI2GTEYG4y1YcHesCLHADhYfPMVyTXRezdiQuSVVO9G8Q6uv2ikUu7TsIcUOBN53mjOqpRauIZ2pMa5V29TYDHwIGXPeJEhwRkjeff3ICVVnSsDUhcPDivqcwrtWYGfy/4MNaac449xH0DD4REtwrCWA1GAwxlJYgDeze2HAVyJiO+wolFJZSAtRDskbriGMxg3FG/WfPYRNSSIhneSLe4zdq+WJo8Tn9hmeQCN7CCYuFQNxhApdhbjPhiM+wDkxtoYDA4OkQY3Vq4cIk3nAGoDwgsDsF4KUR/+MQ+SXLhMdIYa5QKvuYvAnsgBCGYQTzAQ7xuMmotyagJvtJpxHzCNI+vIgklrXK26OCRuFAZnfBfGvQcDJmy0HhRzOwDCnWKyNChErSVwDdIefAVag+bOVOBDQK7au7xT9mA/9fCP/RuIFAQWrFFzZ0XW74BGsAdwN/t9LbyvRmJP5VD5DMLfwOwBOS/Y/NXDSgQ5+JqEenCY1cEg9hbDbeRTqr7qQZhgSVyIGq7OIFLDP2m+vbOY7t5pBHqHEUCxFWN+vPWGDq9mV+2ZjlsbB68X8DRxg2Ice9A3oNynaesAal7K5m9wxniumyFOLNwHDkprIAb1QHCewrM1OpgYnLWZatileM3lxH0WDNGIDzI45wmuwwQPNJHVDFnUXAdP7KNmCq4OhYYASQiEWjA9dRCvehCKkzBCNUGOi3W06RMXI2b6gdxDCr92DwM28mzCmWtJ3CRi6Jafhe+gzlsHe5zvZ1HkQr7E93LrA8aw7nlM1yG2h6XprIPzkPnxTN3mRE7tibkXMQhQfHoCcwzHVERNVz295zqsweEffLo9CPsAnhfro1dySD2nxLvu5XsWtTMYGjsmjzWiI0rOpZqrB4ZnQVMX8j31LlVjuJ+JmiN1g6lBzkSL9c0N13qCb4X1kYFErehjpfAx2YhK9Q58a4DoeW1poMO8hnuUBjPU2T1TZqC54t5XE5iqpSERgWdOv7k1OazWhL8MvcDC2/SKPwFiWDN6XguNSs1pyFyjBxm/laLl0t4ZH3Jq3DkBsfwNUs0IRdXTxkL7vA4CVDOJE82iNNUc5AKuAxOlmU+ESCSh1hLKmU2yiJj4UsCsmT2yxEdM7KTGi3tPBZiwGjmvIOzUfdx6LAErOdPyUmv1RRluQCThZmRQSEu7n2gQuSaU3a9k+Ln66HnBq5Fp4SBjvwLrzJpr7v56WNbDogELcUvEs5bW6+k1qQk70oAiAscOYAbZBJrMscSpQtMm8rXSzNSMgRExSzQT9cA3yyRvK/hbcFX38+J0YGGcmOFArU2oFX5FarQWDBXJlUqTHGK+FppH0SgBeVAHdb9+//E36qSOSk0+6AO0xiocQtXAYIn7tqH2XIJvIvE4EJzWM/VHNKKk96Qa84HHBzn97+VGoOZ4hvCDnD5ozVuYt2Zu3GvEuIOEok2RycJkTFnNmBKWgAXjXktFqJgVdWqsmE3uv7UmMEIR1wNovGMKMCwipXOknjEbd+5bm4hLa1ZqoZmslBh7Yl0FxK6Zei1u6PoIvtjzKCKLGNka4QtjXNDPqIagHhzNDmB0EbwgdSINAErmLPWgmBhH/mqm4Qn5VWsEKqbZRnmuAvFaRXIF9Y1WLTRYYsyMQwG0sQ+Ne91F8LtB9znOrA3DJ6m5YE1gbC5RnQCe15qZk/8vXUT91Epzrp6nxzFiMu5OXhaNu1WnNd/Yy7yE1G6NfFPJDRHAoWc98HpZOmJ/Ytx//E8daYou1+W6XF/kApuTGGG/XEZzfrku1+W68MLlShrT/6txXc24N8F/L9flulxfpug/5T0XLrjEgL3Gf1/Omtl1iflfmMPx76+X5sKVF+NuDW6jEJr3+a9Gxo2xkeHIvIk0RE2EcWq+gPA0Ix5/FGeLZ0fsPbFx00i2YX7XfBIhNsaYm2M10ms1gCg13gHBaK+ZFHlowmu0r98Y66Q5pyCGcRXy1TCfNcF6TQJMf1wVdc4RPP+IYV/EzejPy4JzR1CHRpxDpfsaULtNdTP6chlTLxadbYjYNIZ3WHiHzDPId1BuR1yDUsb/BDsjEc/REH+Dp/FyWrPi7016NQL8qBn3hlpoBMVpUMzJSItY+Hw12I0VJyApJyKNAGhtv43R5KFn+SiIZtTfR+bzIy8jQwDC2hDpjUCDNgbEZBC9JsTUqJvC8B0n2ARIrJFEYmT+xGSU12qUfbvEcviTP27tZpRxjRJ5gxBOEOdQuBpQRCjCo4RWEkWKt5rZHmvGWKJ8QQqXkrtK2TfKN6KZGE/FVTNvrKEY5WZYND4jwfeAKWo47gu46sdVzdYVdYLhArPxApqQZrQ1vydxJfa5MH6j0hgFXMyZq2bEeLtBtHjUdUzjLsTMNBK3ajxKYIjLY2PdvwM/Ddd0jstGTWpMqfqSGv5GMc4s1kfD8GfUPUQz6hzbKJyL+KcG0KtGa0gU/DcjMLyzeJfQuLfjP10jdIINeo30vyVT2hACoJmlkLAoQFO/ZwWeEp5R/6aAuygDQBGs2A2PRnM8yuaEzdG4NHBiEYx609EYzEBN7QfEQzPQe5ew2CgiqMaOipdEGMbGgJuYNCPTAIx0TLhYqQZAavrQ6eSo5FU4MxfzWskL19A1Gl6GpTmi+KshxIcyOrXS3IemphmXxlP7hgKpVTI2wX4bRSi5QQvXhNXccACoLU1YG9DcqRwx6t+OIM1/I8WYMkkjsMdR4bORbvS0bwnEmI/yPszGR6r1ked/rtFE+LkGtK4WvoWRcEz5AknvQ61rAP+BDPJEzuqB+DBDnGaU8VATjTHM64y/YzVopHVK4qZGqHeKi5pR8bijoNlMM0nGVWqWRuLfI/bcTEd+GXfBlEhJgu9DntfuGZXPR0dj8eO//a9rBN9lOWP4WU+Q8agbC4q861HZH3VR9/aKce4VQwga23o0YAXFRC+TBzvhHU+fr63xG0G8jqdfYzcUmVkb41HA8ig3LSIekIbI2sAz+wuJC87/aOSEwXCOETT7I28Gm8FgNARMsaZl1BsTSNw4PhIMXIMOL7xxtPDraNQVzsxYcG/RB+ZbIbX+LOcb+ZqCuRqJ1YgNrMRcItw3AvU9GmKiDde03IwE5qwepmcGUCOAqREfVtQeT+TRAKBmT4y+ZYBCDSUNDYPqgaQ4CrEPv42Z/xfmHgufaTH//u/2xLhLBmE0FI41gBbjbZiiQYZndIB9MO4XBd5oaJBQc5cCXBajPhpN0+g4w+gkoBEU5l55Ty/cI8XHS0LW5ng0xtWawxEQabR5QL8JGh3YGhQRtjQ+1oZ4MDQfHJFzjTXaUI4RnGH5BsqTD4NIRTVp4z/2QYmmgVYdsOzJYvDHiKZ7tDWDrqYa5ceeNriuGhsdwwXkvSPD/4OB20YDP1nuiakji7EfIzXc8k25JZ+WgfOYSF+tOjyC64yYZv7w7LxxDxZqB4cB/XhuMArNCBzW0/WMjkR4p8EWsedi0TtJyGrcU5mi8R/sz1esJnA0xHV05mtQYs4Zd+veUBJl4tMGn7VW/Mxrc5ytNxqJLpwCIFMqa07DqVWwd7NZGhVjNgK/S4DNdjQa997xTZrFNFqNotXgCXzQcuIETuHbMUHjz607LusN5iiKU9bki5g/a43Bt8e4B/hu+3983xYPEdozgHUu1aM3j9aByyhOX0XNaC1NkHWg4xkSeYci3qbG4gdiv5UeDT5TM/hCXtv537i3XOJDEgsNA3Eft46WpNb5O8mEtJwoAOuTnwlmKYxPCwCypUSC24eQ1BYkj5Yp6kX8rO9gjKWVDNrR9j5V8DlzOc+TYIxVfBsx3Y6+vC1wqxCOpd5M5xr8Narlr7UKt4MvYjgm9moZ/km513agawrGL2UK0AmS8du2NkIPuPva+ZmtAxxp3XkMYwYMknZYOIQajiET01DHQv73NidMvKhvjqx59fJuy+29NxpuZNiB4tfaRDNYdPPQYD97C9RFzPpUPNqBwaNx/dbg7cw8JPBLC+gbVPPEkKIl/8YdSBRr4kdeJNrRJiCt1ewIBIIWQbg/y3sQULfEe+pExdpaBGiwG4gWBB6XZ2TtFsxRDHl5CxbBb+s0zhZx8NZPa8grgoHWuKfWuD4r4gPPUa1R+BFMt0ztcmvVTiGk4tsCdaZxTcoGpY0xWsPSLHLnRLEq5m6wNYcoP6G5sDaSsUYCwUNrOH9rjD0ywGkNXNGCPoTLURtpdlsjl1pqonWcSc03GOfWYXjbCD5BubcFvGOTsFZcDbKiCS31zarBI6A12v34U5kuMO4tQFxIoaBARMUWSWpr2LelQGJF2NIYtMr+1b1MduFB4+gpwNZgbLl1akNMrPegz2lYQn6PkkPraHTROkP22BibTys5NRHnsWC5NTTpVnJtBEOP4MjKrygPthFNYQPGDBV6j160Rgyj/IVgg9tTbTSwrXEQYGk0vfFtjdxsbpSEbwjbyGGX9TyeQZB3cNI66xodqlgGDpreWAZw1qbVew6tfr37QP0cyjdevrY062gdLIx7m+Dymn6rMDURRsq7f897teJKFeuT9SZ7c5VKBFCS0sh5foYU5rqNwGWb+EKb2zCfKRtsTy22kWTeOptCdx2stP/Pxg+5r8nx/slXX2vpRZOgbpsEefCc9+P/G1DraJ5T8VssPtH6gRqRgf7zohT1mrpeYszdWvwbOyxrI5og9NzI3tFJegweLYbdVW9TGm5DvCyiu7+Ne7uiuLiu6Yut8zecefqCsZgi9jBF7nmKPP/0L8JWijN44vkXxaj5y9Yl158+ES9Tos8/C9Mc30zOOliLP6Z/gS5/Fqf/Tfw0fcH1py/CKal4dwI44QviRDfuk3nB8xDTRLzPsU6XghwCwu+49aafv+ssQsLtlxCZblzJqHrWmf6cl1unU87exRZdBB47ZL/Mc91kxJBB4Dvl/g7N5RRc2r3O2ui+SsPI1RNg3LpYbtDyGdk8dpZmdzIaWWHPnZFbO4YjPhMfXUoTM51BG9dsnI081I02fTqjqYkfDE28pkF16NVIRcu6mPPG4Gyyc3o3AXFhNLZTjHMX0ch1Bq7sJgM2gjx1xP67yDx0f/bV/af/btw7AoCaeekogZ4EcE20WetmAtoZCaVTktcxwO8mnlDngOsAse3AJqKjjAJzjo4hiy4AQYeYSLAYYPBqhDIxxkjIVYeYHGYvnUAOJ/GaMPPUGQm5C/c3+/8oROUsyuQG5+3AWFB7+MBHNxoFDDBo3bQkr04jYjQnAnGHjVNn/RaHOV+HmPtJP0OHGscJFPdAKDrNVEyYgek0QZ7hvTOY1E4R+ZPzThg2Fhw8YZwoxkvgsE4zfER9doABs9aYhcc7tKGcGJ4kDEin4WmyGVqL9p/s8TvXdoPMsR0Sd2MOohpFzUwysetSf3ulGWNifwv8T/zgrVM8luo5JsbPKAMGy1BhoVcjfw62gQP4QGq8Os3gL7X758S9C4T/RNAnnvikgmKNL0GMnSTIUkMwMUaECBRnnBfGa1KElgFoR0yRGso8EsXZSQTDTAU7pLnSiBUgp07IZUPEr1NEmSs0zpi3E53zLniOit1CgKlmaJJJVMJAWPRz494hhm4yTv8mmnAkcp/HpCGMOzcxYE2GEK+OahiZGHaAWey4NTl8SDU8Lk0h+T5qejLJU+Jukuu1Y6ZKHfhtG9ocIwLRKY1Tx3DnST6YvJA1AzYFHTHk6CZ9WNGNPKd2TL2FnLHgo+n03obBMifqHdNMIk2D2jyO9HCN06tOMCqspoT/NxCTwIvSNHlSzBoSDwnHM+O+GBZMgh9BhlsCL5KeKMTWJDd1Yn4nkHsnYQg2yfhhjTAzEOhCjzSrzWbidacjvJU2GAtj2ClNaBcMh7sRHwx1hP/opEZV4o5JGcpxvC7oL2vc++mnce8m5WKMEkvWU0BYxKE7bmJECAP7e8rETbSh4wiVJGxtUkJMnjgxO0nc3NhNQnEIZKjlJZzAdoxZMk+EqTiHe9dywt2v4O638ZQEUtsft8+JaSgBvC6ahiBP4Z+naBgVcTUCdQTWLZsP5LkwZsQ7WbGU4jopWJjohkgST4qnOqmutL1Qz3E5Cr821nImYQr5My2GPyRcUNwN4WBkhjxM3LiJbqdxO8NhHdVYSUMH4b0i9jXOkHSMqGduAtcJUzo1/lK+QgMNchmJK+Q+hk9bRes6Bscdh09qaDSB+Zl+mf0BG36gf3an6Vc7CbHicMQ1pRMzLJsIX8PxmGSaRwAzE4MzQe+4pk3yUay3YOLVKcNM6hs11o8ITYtYx0jDR317NOka2U8fxh0RTCupDYAZmEDSHHViEtcfMfPRIucOnx9kQlsUWxiXwXAeNEfCJRLy6BNtkxHnzhlzLiovY5p4QedDGwckr2NCjCP7Hx3PoPGyvjc1LtCcThhhinxlMXfIGcFGEWp8DEbBlFPrGahnRtBMTo7hkoQpL6+iNW7dI/PtpUn/JoDTJ7C20fq34NQS68EQz8mI49C4WzhiZBpVhS/CAWE0hlFcaMZYaLAhvtFqazJqTQqMWzV7AhqwGM+K8AfxzREXF5txHxMQ3OQ0dCMIjDWv0SBkFtNtJfwUzY8VbFLTM35SPizFZDGDo9NAxsQBwcroNGGjITaTsUGWjK0VX14j5G0KR6PRs4qoxGHe5jZl3Y0J9hTTYI2KqfoKnDI5m+eUxj827wj3e+s/da2m8BvjJ+QebRy+wjk8fmNakY9TxMtzTsvgIoWvSHjZjfvgftH/Lupz13pj3PPI3kzGPW1SFpd7srNyofenXSAbx954/hQxdJvw8XQP/cp7hfaFTLHGX3Ux+siy98RRwGMPnK83Yq5fM64xdSTVyOjEbriG0qz3KeolArv9ZOCAOV4p/jv9Wnh1fu2t7wnyYV4DqFFqvX5SuNjQ8Em41HLYf4HhTb/imv2UoJmP2YcSz37lWPSR5+CwK+27XyPnI1AXc+4aVxxUTEn5uvvP8P1/eiHAHLlpn1PF0DuMs7SeZjp6B/B7ZW3rOSyEbo0DEn/LPnoFpD1Acr2hCHulyPsVxNqSg15Yo3eIXp8iH871euU8ncHIoPnqQROA7MVahz2Yy96IS8QA9gmMdO9oePuVBaQHasRrNlLxpKUeuPv7BPenMlUe7vIOUCw6uObQxctDXkyv1QT0Bj2x5oPCoDdHMb7FOrDrDYPcHvQcMTUk6XrswNHqM9GfTyfuTqLqFYOOCluviHnvJCxUXPuDzVikAom1AUKNZO8glBY0fz1wFitZ9WA8+gizhxZrb3yfB3PWZkVaQ8pH5xRja6xjGg0LR7B7PNjXswoJ9XkbiZGU4mepTU/TgfKNdfjhqduYBsubm9bAEX0El/RGru0Nwt8bDWQqTrYYnd7ZWMXknYsvOnSw/oVByFkqTx98Q5gO0IveYczRgZvX31gaFy9G0f30YO4RX2w9A/XfgTLuFnJPSV6p1rCaqIX4H/4UlGmSdjC87xD8N4Lov+pFEZTnPGRsD1///F6h7cHJdMp68pgkS/4tzeS5+CLV+zoGj678HT6hNoGBRtJ3HpR9HHxxshhW9bMD2CyeM6+HJSei96Y0Nskxd/gcHexS5BV5z8E+FOojGjnoXQBfdQfGVx3W9SOev6pYGx+efa+Ju+H3n8oc8IKPIqWDQRgP8QXj2tNBN/FdSuAezizgh/jmYTWDdUhQhAewOZsS3eeJwQEje+/+upVNnfXcsd9QfOnrgDWnn7KvWIwc/EbajbXDuma4WymeZ8EY0DCGeOyscTjYv8UyY+ewTkw+ZXB4WN9Aro6nAz0s69cw6YdEZvqQIG6W3CUeYLj8zGFu3A8//8bdmlyY1LxGKoYkD8YzHMDzH8DnDvETpLMIxCG9QRjW2juKsUOaZjL5e1Ln9fCFjUaq5vUQaRIOZ9y3J9YxWD2cIddrx/RgrPsD+HnKGorRq5TG1YsvL/cdIpuow8oG/WP9MfH70PgfmCHf4cxardVHDK9MEf4mle9J1QCu2Uge/nEPdcw8+MNjHT6Mu0Y63KFHhTwVsz8cFl8BUN3F8ncTBtRh/i6FkIYD8d7D6Rpq8czeO3ysKcXmENn0TI41EjQzg9XgOjt/SFAOy1yzXzFp+dTMwAjUSUqzh5iTg1IPB6X2EPwcHM1VKqNh2NNANZAaLx0UI3yIN0cqFzDrDLNcDSFfOgzrIBkP/mtZnbu0syDGwmKGD/EiOxyc71L4fDj8Yx8kKTz0O/eW4YWHh5xxHQxaMsQar0OChuHwT9wgR9KDyeGlrJjhau9g1HRLDcc0OBNTF9MKzQaizwej1oQ+Mlhr0Lj0AHIe6DF/GvfvY/cBNYIHvlgH4flhshH3QAUKSNgwYfueX3AjcCCe8XS8YaI5YQU7uXBPQ0THOWhC7yFfIKaa6eHeNVAFFJo4RlgHrQlQ6oDc92hslA7GhogQzPAcA3cG7vnJcD6vYIJkjNbFMOo1OhgNxiAYJLERBwRxmHhuGiYB00wuBol/OQ5g1lnU9kERK844OMwkVWeDxonKuQZqiBLRkA7CAGCBCaK5GpBvKRn8hEOrQeGB4WAzOWFeB8swQzPsQU7VmgzwMKCNBjr8kD4/CPkO4zrOpvyaIT3INcsOHA/KnpQ1BusE+EDjR/r2fF5Xg6QfB7CpTTABHyyN0kEeInMeaAjrbT5YkWJ2EHT+oN83nGrJz4n7QBDcwBQyR+JDIH6hCHL/5giPFW2G9Adm3Z4LrgJKcg1uanUAGpfpdA8cmIYDUUwH2WgPgqnnmoaBI+5QDAIwDhbxU/bOGrWJnjIOirAPQOO4KLaDbKwkoVMLfVKKkmkaoEZsojE/HIRvrgyTmMEyTefwwzUSROOwyPdhKSiLpvvAGypoenwgjI9Qv+qkP8jBQH2bF+LuoH9zIRrug2D+Be6j9jcwxj3EzxDu7bDkDOqbnY93dtI3AEIeuBwOVOM18WdaiC6B114wm5SAo3y1wMHEf5syMHzATf2Gg/LtygHHibiXw/L/Hm4QeIkz7lTtU3lQ/0zqQHPocFAaGmQCHurlePqXBgODzcFh3AflWXGIdVAGE0H9Uto/gN/8hE1rWHdDOFQ8yH9aNBz0uA2MFg/h+cO9SEOUSTg3g9eB8RBkTc0xw3BQOK2nhgGhrv8x7lRSxl/XgRZEKomSGRqUizX0I70+18UNXGekCPQw8WZ2UCZ7gzCpHbjzT3yc2GcZUhuExoUiUW5KNxzkomXX5URJOA9lYLhcDYSoDJypC9dTvuYPp7dUMfXUhG2Sp2TkNyxIswr+TS87GeYEXMAJWceMUC/EViCanqtV6U8/hAnzcDg1fdzVSTxFYYWaYBvrSjT807L+BmYoIRnCQZt+B1PagZkQaZzcC9hiDc0BaPQ4jZjkKf6g1FInNYcH3tgOAL8NXF0xGJLypt7HcDpbj8rUcBAaemn/0qSQxNLEG2bq7Mi3rywmgSaPfNb45xkDFT/gXdI3+lwjQf2s4kjjoIn/K4PBiP8wPwPw51wDoF8D4ItYXeJ8puTfuAaJ4gXpmy2hBtiGV2qKDfj69Rlh3D+u0LgbgARdBIA6KZGA8e+9e0HONQnX4S++vtgZeiCuouH0vBNsLj8lB18gN/1hXbx/evyNOfor9suZic/I1/Tv4acovUtwHmvsYcOUKoeTLV6QWU2BheBPO0S+Tag/auwn5T7DXshvciaHjwL2G7XGivwl4ulv92p/LsG4X67Ldbku1+W6XJfrcl2uy3W5/h7jPv4fD9KYOAajENfxi57/UihfF0/nxsEFD+evl3HFdca/PJaj495/O2bGL8rxo5EjxzO+78JRl3P/Rfv7btyPf4z76DQaY6LPpftGw/PjikQ2Gvdi2f/4iYZw9Ijf0UbCY4LzRp3xuEKBHeOM0bhSY4DgdDQYn9FhpMaI2hyNAj4CdTusxBvjyk1eLH+Nh/UGELE6oeV58dmR4Z5jmvPFctIYieUxktc9PL524zA69DvF/sYzN8VjIt90Nv1O6ImGBLiNee+4gp9yP3f08Z9hH7+M+xELOgJOkqSOS9NkAfrivl/rQcV9xAhhBPeFGoTF+YE4jYEwjUc5wahAjxZBOf6JsRRPVIzIvRyNpu5IFwUaD8TQa6ZexMHRZpgteEONl1YP0HuOcpMzOgzmCOwVqVmt8RsPNG6l92v7RtaCSP5oa3QtdTsADdko5H88+IYlVNPHitYR2+94cA5Qjvz72LMf+ViPwDkX2CD4Gtk7t49R4coUhmVEteVIxMDI4R6dsJwRqucDjsOYRlTD9xjhK2L43TsU8TZCSH1JWo9cUsM+gjw2GAZxqGlH+depBafGfTzKIB4FYoGAcLSJPJfo/+3zCDYPR0Hgj1inaAHg4r4jLyQI0ViBzDVI6PvJ/B55owdNzLRiCI35kRbm0UDYpMk/BlgMcXQEjNxRaWSOchNpyQVZM0cGf4xx4IgOzr1xmqg1gSS5HUFuOdKf90fZbI/gfkemoUObIjJ3R6ZOLFOZY0Q9H3lsjxbzclw2dhYeC2M5CsMMS72f1OWRxz1knEK8HoU9HHl8Io1KWANiwyEMKyhNRY3/eMSaOvI+UD+hOgtwDnkKZHB3ZAYGmkYehcaEwa1m2BDdHRReWNTGkfdg6sDjiA8DRUNJDRiPWP5HoKZPPAEy0JndpxrmI/28hmsNLyHXjoAOaF46eP9P437youPP/2vgkSNexdhxk7qTzR/tXbRozI8EkRGGc0HOCtlLjQBSHFIywpgMitHkYs3tzWT2jRdpbgxxGxAhnMcGaV6OgOABwj4eeTIYj45pzYx0zI0X9eyREeUJNKgcqR2VmB4dWDnKZkzlFo1rCGPJ1o1hXcugAY7NkSbwgYnHcJTNNxK3AbxH4tUTnjwyezkq/KbsmTQBR7zpGjXzChhbLZeLfBz58w2UzgCGn20ECBycDA2OxsHOETA/ACeSTaoxT2RclEaeM8nat2Ym427Qh5O8W9by3HsUmmFrM69Mr6XGkd3vEa8pk984AtzieeeRGBAewQGn5u0k437EtY1oBLr//HDvi4I5gtOvo1F8jyAIj8ZkHB3JOwoBPRoaliN4LskMHcEilQrWAtSjci4tf0eH6Yot4o/3TMw5kDwYidl8trXOjOBo+nWhNXi0NYJJYnN0xvuYnqjh/HtydXDW1lGfUJu49pjASBwFPKbI28FQzyh/a7x1tBt32JAcjYMuS23EcIql3o8Og3Y04PvoiAlieo5gvo4JOMHyvkOE5nr0/Ogw/xaf5200Dg6POCVqCI6Gej0m4FOvWcf8aGDcwWtCTdxRuYjDTggRHB1COH8HIjJHZ+Mxjw94ZpEYjglEzmNkrcZYes4h5hMXD86gWrFwFOId09AdjOcK1puOzqbUOH3hcD5FNM/T0WhGnE3MdIhoOoX8TQeiflMYUW1daxNjMWcU9lAhA945oY3HwYlPj4lzGsxJ4i8AC5P1fJTehetOQhN/dOiixVSmMEpHY6NmwN10/Mc/qDsK3HdwGO6jwfQenabNY0wZfEzoADNyQDNpfkiLxcTUSwreQIeUx2BAJtUz2vgT901HcHDww7hPP/5UBpyAT5qxnm9+fogjQDya8SXIdTrS756IAE2WqQwFkuMS+NMxCPaRNkDTUQAeEYcT8zSdfr54J1MUlEGcAGGd5gYm+Jl6lvy9ZubACd1kmK6FcZnm+1fiM6FNx0EgkaORDICcTAdb8xqe83e9Erg7wa+lITgy+z/ipncS3jchXESckzr3RORrOhCYMQrvNL+4epPMwWFZ05qATWhToPDQdKSxwuLxwPMJ1QxMoDhPWrPIrDVNPy9SnyzDo1BLAKyRsTvoOZyQoQEh4tNR0Vwul0dMP0/Ozp2T0NBJ4fiJ8goHcHBy4Dld1Bhqbxz/AI0PdcbpaGyAmOZvOtIGl2xQjjSup4P+LJkfJVYTakYJ7pwCnp2O/0BD2PB8k8fgS/V3oLkf0fmJ8cFqs2P5E7AD45Up//LxN+4/jPtEdEYTKJALo0QQwAL4R4KYFMKcjkuxlPYWFv4kGD72Gc5QcaY8WHeQ7jnyBSABYDqC4sQ1NEfe6E+CwE1oh8ng4+Nv5bQmZlIap0npoCfDeSlcjkfD+YRpwiRNsrkp3ZFpEA+BEadERaiLSTBbE3WOcKolGKpJaDYsUx3KVGpmKqzt8N0TcX7IaCoNxAQa1YnghBMeOxDN+FH4HWPsFnyq7UkwMhNhCCV+Qo37dOSb1InjewJr0/wbN4pnDE0eEi/yDJJBO/JDL5HLCVyx8Zd4RdFP0ryDOjEJA7SJ2v/BFyvKzEyaJwm/MTvIvoQdgAWcN1Gae8SGjROCIWmAchQaI8u3/Nx7D/y3gaKuGb+FmI700IM07keFV7kBruJdFu9EhgpKDhfDwqNcVyFfksMzhtOD93//U5kfxp3YDHdJB6DEBAGyStbAfpAAey4IvMA6H/8HXhMK0OD30vPoniePMAH5GYUipPCA7FnLM/K8dg5JzNlnDjShoz9PBpNFNa2WOKHNtyeO0jmpb0IQ8STNAJqzg8xDIs4OGCl7+InDLmQkQZxp2EU5eC4sk2HNmN9NyrkmqxE62mtkAngCyW2sviAxQCaOk8C7SDPj/Z1HTyfGXMOY+v/t3euS3LaWJtB+/4ftXzOOsIjL6Iwlu8TEZQNgliSftSIYLakqM0kQ2PgApk9f/cA1yyFfJvNUeE5Y6I9fFvPDzvms5KPmPLNwzS/BONB/omMrmo2+PDTmo3PkbOxHzvck/3z5/lWZnUITCe1fDie3X+F4omjfg/essEaC/5MTSCSMrbTBU/fxz4cG+jv7xJOftzq2vrzxGqM7ul82JqN3L75/pfrx5WAC+KzP/xIMj7/D8edvdr5P1MM/H2ib3TD+5wPnHA0277jHf775PkWD+c64fKIPnbz/7zTW3p0JPnkuWg/uDofD4RBOHb/WRpLD4fivOAR3xxuOrA0cDgHO8f24tIH5yOH4lOCeP7nw5E8uorfru2bnlj/vui4Txvg6ssnhyfa88o//dq3Wgvw5ffH6TQLWZdz+dwbk/MZzy4v1Jv+Ethxd/7c51Nz2i/f7vPjz/Py9uP7ti8TcGR/h4J7/Cu7fX3RNJuZrIdBfkd9ZvOnDgJ3H53BNfv53OM8/Xu9LoHmw416DwdBs+52Onfc62RV534MFzZUWFk4PD+Zr5f0aofbKG22ez68p1Afy+JqvaBvnwzbM40VApD502yzvBafm9eX1/nad9sfcGfN5cJ9uNfjKr68ZLbSuz54cP57jwnyxM/avw/a/ggvSa7SwzbfrHvSXYbvkYJ3NByEix8bK9Y6NrODrr978uLBouWb3KjrPnYbOxRqzmomi53jt9u+NrHHt1tBOnrruc2++5buN81vp88v3Kjo+c6wNro/B/etf/vg7tOcPR2/A5MHAahWY/LqauG6T1JcPn/sld94rTzrp7OJ7n5//6QzXxm7J1ZpoJ9fQO8+rEebvC4trtDq73b/hk4W8NmH1Fg8v9zJSwHL/+q9oIWp95sqg7LX5aBKdTTSNsXLl+fX0zmmlSLfu63KxaF1LZ1xc+Wzy+aHtF3bzr+jiKE8mqzxegC/1wwd3Ua/Z4jEHx2oO9p8830i58vr1X5154+p8X//KwcVf7m9qXNHAOgoHedxeV+6Hnd659freNWnjK8cWqNd9HgouaqPh7BrUyuhiORKKpvUiz0N477pG8/sV3HCIBrRrUpOG9z03ss4tx1yz/pcXw3KezwHdTasc6z/hb3DkzpiffFtiNPauydx1Rc4/d+pjdAGc13bWu3X6r8//Gtz/s+OeO4V7Eo6+tEJg5/dbwejKnR3t2WtzcBd6tnJrHTn2PveA3A3vnUDaDJbXrZM0FgbNYN74eWSB8WcKtP+HBVV3UsvzYnel8W5iaxEQCrx5EnBy/2c/tG9noF95Pklcg778cUE6aufrvniNPl3K81DQDUM5NkldrRDR+PtL37vvCt93lHuL98kis7nAy+37+6XRd//MncVwo0/85/gzjSfK+4bDNVm0vozT1vl0NkJWw8M1mgxzp6blxpPKHBybebCp0Aru+a/j6lxrK9hc+fVcr8a5RhZsV+sJxmCeehmjebJgaD3F7YXu/ON/v3ANFiZX7tf20E5iDi50WnNdZ4PvyvPNvfACpTd/pknNSe0a1FrYXY3rmy0OW587rOWp/dovrc3S3Anu9z/ndpa4VubNwALx6myyXKNzmM3TuRO0Z4v10UZsY3z1nuZfqZ+dWjVilA+u1K8BV5qP93v/HLXZ7Vz/Cu6jAHt1CkO3eOZB2MzzwDv9zDR/n2kwn702L17fZBEwfe/Iuexcz+ge5sZAz6+Bc/a5vR2N0cS61GbRtsqLR7Q/R38euebcL9RXfi2KV++JzuB6X55g5GBbr/THyTV1F7+jcbR6n9LiGMzjgDP8nLxYWwJhJ/T+eeFneXNsrdT7aP+ZfcbKWGtM0svntfC7w7A6a//Wz6/x/foSvW87/XF2nq3xdrW/Djsam82npoG60GyH3Rq0MAeH6tHK/JIC894kv3zJg4240b3rbDp22ycv5pL8ulEyWzhPx18O1IIcv97We70s+vJiNo3Ust2Ms5p3Xt/v21dlVieaaINf84lzGlZyMJitTiizjrbyWZEOsTJAdjry7kImLYSk1VB8n7jS4kS/s1BcPb+VSW3lvuVJX1oZrHlxgbnSn1fG2M6CKC1MPCtttdtX02TyWFmEp4cWRSt1JTIeduvTtbm5sFOj8sHnrC4udvrw6obUSd3PiyEqL2xk7czbK/dqdSNsZXGVg4u9XNc2DVc3HHfq2en8njbnm7wRUqML05Pxler6BmXe+KyTjbzdDdvdhUwkf7Yz8rcd98mHprRZYHYm0NOi++E9UjoMTjkwwT8R6lcXI6sTSXpwAOYHQ+0TYXp3ksmfcM07Azs9XJDyJ9zjyD15aEw/UqBXJrGVxdFu6Ekb57i6sM01vtOVNie5J8fhSWBOi9cf2dV+InR/1rh7erFwEoDe0BfSr1DbA7+b0kJf+6xafVoz0+bCKAXH1mlOSQ+E/dMxf/INgti4DAT37yH4TYM9bRaT1HuPhZ3JjwMr3Y7r9ucrLRSle5s9FNzTpLOnaHt/u/a0USjS7P712vpdE8DhAiQ92Xc755RS+x6MCkhKD4beN7bByfukwWvSz5h4T3bL0v49S2lxgu30+bQwHk9+nlKsDqRAzUj5DZPxh3qYenPMzm7bm8Jp+qQ+ng7aNH1mUBzM1Wmln+/UotMnJx/HyId5Nr2zfYLz9H3eSSttkyZZqPf5q0+onlhcPrVB+sTGXXTDZG1zvBHcF4NyGhTttFAAUud9U+A16fB9Vq71CpxLN/wvXH90EnxHaIre57R4Hiv38vt3v9MnhMfouUb6WeS+rSywdq919WfRvr3bf1Zqx+4iMZ1M2JH3SJuvOzy/6O+kT1jQpYXxsBPU02CSSwv3Mx3Wo/DCvDPRp81NjvRAQDveaHng3GbjI22ModU+lXavLbiQThvBefdc02L/j4zVyNj4Enz/0d/TwRz8dF9t5sEPi6zT/LRznzbm5X+Ce9oMLik40UeLSXRw7gTy3YLx8T94SJsTyGqIS8Gbew+7KXidp4MpBY/Re34ZvG4U3NPGwrBXdNLmJDcKsulgcfjUQiOygN0N3mkyQaTgODsNgddC/0j5uZ2ra6EWpY3FTwrU4xS8z6M+OtpgaF3Dl+CYS2+4D6fjMi2OnVk7nwaPFKz1q+EgLdTHWb95cv7eWbTv9Jt0UHNTPttgXJ1bV9p5VHdX+mva7Ncp0E/TwgIkHY6jlY2ykzEZHV87eWR1QZU+Bvevf/kjBVZLuzcs8rq0caNWg8hoN3wnOK0sbNJC515tmxS4tuiTgJ2FWTq41tP3i4aItPk5K0F4JaymjRX6TjC+Hrg3J+fTGy9psT1Pd/J2nihcm9czC9jRfnayOIrWuhQM8CsBLy0uVlLgHqaDe7YzbncDbXRMnPaHnXoT7ZsrIWJlsb1aX6Pt9eScGX1aujoersX+NPqM1obW6TcbTjdH00IoP80Gp0+Cn3oqfrKzvjovN/r7OLivFJWTRl8daNdm6FoJ7uH2KIO/l3jhPw2UaaO4RYL8O4L7an9bvfbrIKifHlt9KLhr//TiYqXoNf+9HLR/ef/9Xv3303uYHlgorhbyrc8rg98v/9yba7PWXpt9cjf4ro6vp+/J7uLg3TUolf12Xvla48n8ubNQ251zdp8K7iyGn+j/K8E9svju1eBrc3PgiXnpemCTIHo/nxin18Fi5omM909wL/8E97QaUMvBiZ2+/sFgcPwZ5Y3nU36h6139zPLJ510efO/N/nm9u8+Wn3xPHf/+o/yX9I3yk9/vidpeng8HJ+/1y8+nv3L/K7/ZWCnmnM+8vg8Lgm/BvSwEl7LZEaOvKw90pnI7/wcaLu8sYErjnPLg36LvXxo/K4vtWB7oWClwz8tPmvhKpy88sUgtB5NQ+cnBobyhvQbvnX+X4lw2F3LlJ96zp4N3eWis9WpoOVwUlNe+lZ/eSHi6T5XGWBjVykg/K28OXOXB+lAO+mfZOL+nNmpGc+sTG5llI7iX4Pud3N/P3OjaXaiVN8+j7wzj5ZFF3R//87WY/JEXPyC3CtFTIe3D+/yn0N8/I+dB8T5ozNwqrHlQdCPt1BkgORrmyqTYBwbh7Lqmk+PtHPLovAKhPZfFIjSa9Caf1+o/qSz229GEVRbu08Lkm/NmUS+N97j1gzwqnh/+58tymfT9YMjLrespm4vmnT5cxuMrdepLPinUZTK5l3F7tX6Wg22TI+9XbovvNFl0RT57pV2jdXHQZvm2GMiB2pJXx9wDk2/ufX6JB5BcHlhUPRQQm3WlbC7mAwuWPJsvV/PHSugb/G5e3aQq/XGRo7XncEMlRxdD5c2bEOXHuXg1R+aPry+T/rexgMmz+lz2F8V5kFtyb5y9vudfO+6RyWIYmAc3Pw8uoBmqSvvPHxs093b0Ajcwl70dm+b1l04gKoMOUIIT/WnBKuNOMp3Ub6/PvY7VWDjlTifPjYksD55GtM4/j65vYec8dybW0aSSy8LEVPr9Mw+K2XDwlvnknjsT7CyA/31t6ce2yI3FemTM5Ea4+qENSyAANhbms1qV8+vCP5f5U7B8P+73ZNDX8+ApQ+4shnvjOAeKejcI3vr1y2enxqSZAk/OWv24vI7He7/LjYASCe650Sa50y9y43d6c1WvXuRJiIwsYPKkRo42LfLodzv9pTUOe4u4XBafGg+eFOfBJkk4jDfuex7U0hxdAOdng3vOgdrZ6yvldV6Z9f1u/+3NdYPg+kM2KY3+VwbZqbTn2+UnSgsbM7mMNwtbC/McyH25dMZldIFTGvWrNxflznwzyHJ5sFHZnL/++tnXHfePwb0MTiANdi0ngXG2k9IqUs1iGAi+uQwGSnkN3OEdzNLehcytzlbaIXFU7HJjsOXSn1zywUBZWYmuhOO8sDPYLeLRpwS3/+cW0fPMk/vd2+HpFsjIzsLK16/SuA1W27EbEMrkyUmr/5X5E6uc57uKs6dkO08vcpkX7B/GaelPPqNdxDzZxW21b14IBL261/x7CS4KOk/MchlMTJOnOK0wkXv9rPHvrYXSKPzl0lkAruwQd6433+adYa0o468+tjaGRsfWVy/KfOd6tGGQy4/HbFyP2jSPduNL5/MboTSX9pzXDe6bX9+654vRTngabTJtLBxybz4psdflPM9deWGOSLNNlN5mRmvOXMk5rfvfGHu5t6E2mtM6mbA3NsMLwTLZzJiNw04/zpPc1dmw+BDcy6RBUn8XaVSAWzvT+WNI6RXxb7tBLyut1P+KzL0Y5dvjvHwL7t2d3EYHyrcd41wG1zYq7I0Vbb4XsMgqu1PIc6cw5zJ/XNUMdmVwX1uTf2vxNJpEBgEwl8EOZ/qn/6TOoG8Fje7Tgfvvlc7kkseP+fIoJLQWmINdttxZgbcW13m2g9y6X2UQBntPbAZjvtX/UpmMvVbY7u3QdtpnWnNK/1yb/bZ0rin3f/f7fzzUXEB0Ng/uT0hGNSUPxnfu1bjG1w679SG/PmEZ7eDmzhO5bi0f1LhZ2+ZOH8qjJzalv5s+vM+Dzamcx0/g8iiUDu5hc8HcCdvdJxiDe32/nubPJ09uXsZvpy2HbVz6c8xocZg7C5LWz9Okzn3889WZF/JkLu39d3S5jL9JEOp3uf0Ng2Hf6Ww8jTZpuu2WO/PO4PpbNSR3vvrz8pSsVy9G7dRYqOTe5m20nvTG3WQB0lu43u/RaI7qtWkzr5Tbd9x7hbjZ8XInIHdONjc6VB4E6uFNnAWzMgkTgRX/bLIITZ6TSbUV6npHb9LpFoXcmLwHhTBH26FM2iHPw/vsGpd/Hmn33sKrBO5rZMD3wnwZ727NJvRR/x2GyNJ/WjUqfKHwWoKFtgR/J8Wu+77wXeqjkZqSvh2LhT6X8WLn5XWpsciMLhgiwXulli3sEve+XxrqR4OFxfYY7C1my6DeB+tZd/LMjXo8ekoSWDSF2qT0v1Y4nAcXxvSwvq6218KRInX8tE7nwddvRwvNwcZEKuOQ2Pz5bM7M4ydh4TA6eF3qtEcohw0267obOjnQnpH5b9Y/8l5QX8oZpf+Eo3fNL5uao6dMpb9gun3Ga3BvdaDIxadIcS7BsLwTJkaDfWdnZyck5kBb3Xeu8n5nmu4gPXFtm8W8tUs9GmRppchH70kK9IfW728uXFJjJzAa/JfaO68FgeaTmjLYbX5qzEQKcyswj/pHPvjsUb89DO7hcfnhc5aDewlshuwGpxLos6OxOHpdenNwX104zMZLL3RthMTtuabMF+cpH75/ORzTi/V7+/NO6tDJxkR00+5ksyu48XVUf1cWapvzQFodm9GNidNccpqLZmMvuOm0tTnc7wvfvipzGmh/5vE7nvOvev75vCD8V9wzx+99r/MDi3jHz7+HWX1x/Ib9899Uk/JPbrfPvn/5gUXcyoZT+/c+BPeHjvILv678itf1pg5QNn6/TF5XPvG8Prsf/QpH+c3Pt/zC1/8Z51aCP7+Ps/Jg+7/7Osuba9Do30qgZpbfPPCVh+pl+ZfVtnfMB+UXv/5yqxk/+/6Vh8b06rXnB7JJebANS+eI1PzyTBv98T9lI7g/2Uhl80btFKtyOAHtNnx54HwjE1x544RbfpHJqjwYnt4VMGa/Uw4K2FOFqDwwqey8Xzks4JGJrSy8V9m4Z2Wzxj09NsvioqIcLkDKYl0qGzW5BGpvWfjMdy9uIn2mPNgfnqorPyOklsO+uXv/yxsXoOXJBenmfT7NSWUxA71zE+77/Wp9lads1pDP2PRcyWXl8H3LKLiHbmadfxdoFjxOBvOoSJfFUFEWVlirHfjJ8yqDzlAWJt2X36vx630q9O9e/+iayyDYlcD7hhal9bXNToJoCa7qdwvCyhiMjsfea9JCESvBSaU8tKgpi2NzdUytvPaJnfPoLk73vepkjNV+LSiHk9LL79b4zlZ0XJSNHbLVflSCC6udzYnycEAp5ZmNk905eyV4RRZxJ/fyiY2sp96zHLZvCdTY0zobrW2R8TjbjQ4H97p3H0p5bqNypy+uzH2dP3/9qkz9Ftxr/GaVhZVuWdy1Khsd8t27wau7Ae8IuTkYDkpg0htN2jlYLO8Da3dSKZtBpSwWrHRbSD5V8Jd2cOvaRFkOVvRlob3KxkJ59r6lPLPbWxYWaGXj+v/uF3VtMRfpf+9+YjINtAth+OV663zclY1QXMr6xs1qeB8tCnYWAtEAkhfeuyzOb08Eg50d8OF71Pn4m712Z2f7Pv+Exlddv+e5nO2kluBGZ+jz6kL/q/H+Vw4CetmYi/LC4mN37IQ3d+re4qwctMNKThu00dcd96/BvXejp52+thsiXHDrj5NEaXS87UJe1yb2SMdvDaLef10dGjR1/F4rE83/b/vaucbab/vuwJ0UunvgKTVQsGt8N6w02rn7OYGi3Avurb682+dmbba6a1jKXuAogTZZGUdLYaTOJ/K/x+f3Pltjk0uatUftB62Xv9e1CW/p/tbG32t80ZN7tWI0bjqfmVdqcv3xXH+o53U9EJTN0L871oabETU+Jpa+z1oPz3mjPXYXrMv9OjAPbs/NdW+nvwyC+/J4rY0/H9bNv/vE/RprYBOiTmrbpK7kB+akfNJ3An/Og5/nXj3u1L57e+WDGpIf3EAYju16PtbL38H9tNMHCvtbj+Aj3e3zq4FiVgfh/D4p1sYE29rRGQXu+nybDd9z8f6uTJRLbV0Xz68+F67Dr6+bn1c3P6senuPTbVAPf7+0x0feOLdcx/cmP33f6/nYadaJ6PjNB32gdupLPbiOz6pN7xhXZVJ/o/eoLp5LfXMNO70H9WBRVg/m8c5CP9z2T/SnuhB869rr8sOZ5MkNpe26tzKWyn6dP+3juQYWTu+a93uv77dbJ7jXzUFdHxq0o+JYH26YGgiDNbjyrYehZbQyrZP22B1c5U2TQt249vrw4qKu7VocFcy6eI11Y/CP2ujJIF4Pw2VdKEKrhX/x/ueniml9aBystu3qGMofwvsTi7z6YM2dtemsf9fN9q0Phra6GMTr5i5vPaiD7wjtwfbO9dngvl2zInP7UzV/8kRte448XezXh+5p2ajlNTDOV3NkfWjh3hl/x08t6mJujGTTdvvcgnut79tJOd0BKp+zwjzeZTrdIan1fFeuPlzE60MhYDcwnD7hqYthaLfv1b88tuv4VEj/rF3SnUV2PVwURMZdXZzEntik6Bx18Pl1ZWPge0CvB9cabdO6WXvqQR9YCb/1E4PrzsJmp0/Vg8ByulCpDyzKTp8o7d63j+Pi41gpv8lxOq/ujo+VBXqNh+HH22XyvvUdwf9dY291Lq2NHff7Bdfb/10KTpOOU1cew85WcLW/WqnRXfBoUNgNkqs7h5EBXCdHKxQ02qdGd8Hq4iJr8vNafwy6tTcAa+caNkJcreNVcR2Ejto4x17h+Oj+OXV312I15Hw851Yb14cWOa3rfGBirqPCHJl4amC8lMlCK3gNNbgDeO9f98+uK+P/Htxvr6t1Xrtqr60j9/HWp2s04LfGdJ2cQwnWvZXd6rowBib9o66MxWgdX306Uee7fi+1IDJvrrTlx/4wGUt1ND+XYL9ZecpXAwvmzvgYzUnTuaZOQmb0OlZqbGeunc3NtdMGH/ttHdTAGjivGq3nK183nvxO3awFNfL0YJA7mvV99xsSveAe6Ui1jm/kxwFba//EWw1ZAyv4eg8+tT3IaqfD1M411sF/nNUruK2J8WM1mnaylY7VWwANAnnrPIeLs4Xva9ZWAf0WJGrtX2Ot43Byb7RuoRsU8NopFHUW2BrnVxtt2SrydXDfmiG+dw9bbVTar4mEpBosDj/c/w+BsM4WN6Mx2Vqo1Hb79IJFjRS7OlkcN86jNz66fXslyDWuqQbHWG3133s/moWDQb9o1YJa+wu7GggPdRIy6sLGTp3U8VbIrzW4UJjV4t6cVtvzXHRh161lnSctdWWBGwk0nSBWJ/e0njzRXV3w92r2pK7VSMj6UNdqHixmGvN4r02747sXhBttXwdt0quxdWFRMMoTdWGBXDtz1nBjszX+A+fdm0dqI5P1xncdjacaeN1okdK5rtbntnJP6/7VyGLyvtFS7/+rMqvf4avjYtsqEs0gFJkgOp1qWFjLeIVX67jT1DoYWJ0iUWuguHcG6DDwDIJfKYPO3vn32ivivRA5GiDltTBOd53LOBTWzk52KDTc27kEdpJqf1eoNu7bd7n2B3lthP8f2iE3FkR1vvvaCrOjrf77rki9n9v9gvLrfW4VptpbrNf+An1UZLsL8UERraMJvjau/bYDVQfjqwZ2o+sg+NRooKn9EPFy20rg8we7f7UGnkqOwlPvnCbBvf448bz0k+ZY6cwfdfbVtNG9rYO+1Trf2t/saY6h0U5boN1q4MlTb3ezdja6WnV12G9nwaK2F9h18vNSgptawXFTe2Ouvi568/0rNCtPPGs/97xsZA52aevgidjLarr2c1Sr7/R+vwY3CHpzbW/zqs5q56gv1cnGSGs6m4y/e02vdbDB1vmM2RODel88jObqzhOPl3o2mwvabfTX/wOm5o5kr2Fmq/NOsOsFr27D3Rqrjj63Eaoij5nqYMKtg0m5DBYRtRPeZ9cfekzZ+f0a6YSzgRHcVauRR/O1PbENA0NdO3rhKNIOq201CkF1sKNZOwul6H3odpDeTsjgK2jD4hYYh6Md3Drpy91/G4X+Sdga7iQHFhM1WB96XyWL3rfZ+L1/TqSPRPtcty8GFviRWl8Pfrd1PrXOv1JxX3xFxvjoHPMkeJTeQmFQCyJP/XrjuHbuV51tYg02n4bhOjonRsJN4D6E8kLnaXYZPD0efVbtzUdlLR+0wmtp/GLvPGuJBce8UpejgXdUn1o71YM2H4651iKjd7/uC8vX/aNQfwzNn4G5KdL/p1+hHXxGXXn/21x2W/x+C+6BSbwOJuqV8FhrvHOUSYPPzmdnQuu96Sys9BqtlHijRSfDunEP6sF9G+7mzn5nMXBEgsTutdTF9yiTyeG0rcsD59ttv9n9CdzvlUVm9DqP72WJt3cJ/vvo+no7voGuvtQnymGd3a0JZbFOLgz1o+uKtGl5oK+dtnt5oA4s1bHGY/TVtpttPpzW1rLw/qd9b/XEextLx/em8ZR196J2+/4DzbPfLx/+nI/B/bPPZ2f87Nb+1fP8e8f96//943e7qU+cD7+H4p49FtKiheTfMF7eed7lXzzOdsZceUPbPrFZUf7F9+tXHy9qNvrP27w/uLsJ8PsG93/LdQvuv8c1mif0H+AXCO4AAIDgDgAAgjsAACC4AwAAgjsAAAjuAACA4A4AAAjuAAAguAMAAII7AAAI7gAAgOAOAAAI7gAAILgDAACCOwAAILgDAIDgDgAACO4AACC4awcAABDcAQAAwR0AAAR3AABAcAcAAAR3AAAQ3AEAAMEdAAAQ3AEAQHAHAAAEdwAAENwBAADBHQAAENwBAEBwBwAABHcAAEBwBwAAwR0AABDcAQBAcBfcAQBAcAcAAAR3AAAQ3AEAAMEdAAAQ3AEAQHAHAAAEdwAAQHAHAADBHQAAENwBAEBwBwAABHcAAEBwBwAAwR0AABDcAQAAwR0AAAR3AABAcAcAAMFdcAcAAMEdAAAQ3AEAQHAHAAAEdwAAQHAHAADBHQAAENwBAADBHQAABHcAAEBwBwAAwR0AABDcAQAAwR0AAAR3AABAcAcAAAR3AAAQ3AEAAMEdAAAEd8EdAAAEdwAAQHAHAADBHQAAENwBAADBHQAABHcAAEBwBwAABHcAABDcAQAAwR0AAAR3AABAcAcAAAR3AAAQ3AEAAMEdAAAQ3AEAQHAHAAAEdwAAENwFdwAAENwBAADBHQAABHcAAEBwBwAABHcAABDcAQAAwR0AABDcAQBAcAcAAAR3AAAQ3AEAAMEdAAAQ3AEAQHAHAAAEdwAAQHAHAADBHQAAENwBAEBwF9wBAEBwBwAABHcAABDcAQAAwR0AABDcAQBAcAcAAAR3AABAcAcAAMEdAAAQ3AEAQHAHAAAEdwAAQHAHAADBHQAAENwBAADBHQAABHcAAEBwBwAABHcAABDcAQAAwR0AAAR3AABAcAcAAAR3AAAQ3AEAAMEdAAAQ3AEAQHAHAAAEdwAAENwBAADBHQAAENwBAEBwBwAABHcAAEBwBwAAwR0AABDcAQAAwR0AAAR3AABAcAcAAMEdAAAQ3AEAAMEdAAAEdwAAQHAHAAAEdwAAENwBAADBHQAABHcAAEBwBwAABHcAABDcAQAAwR0AABDcAQBAcAcAAAR3AABAcAcAAMEdAAAQ3AEAQHAHAAAEdwAAQHAHAADBHQAAENwBAADBHQAABHcAAEBwBwAAwR0AABDcAQAAwR0AAAR3AABAcAcAAAR3AAAQ3AEAAMEdAAAQ3AEAQHAHAAAEdwAAENwBAADBHQAAENwBAEBwBwAABHcAAEBwBwAAwR0AABDcAQBAcAcAAAR3AABAcAcAAMEdAAAQ3AEAAMEdAAAEdwAAQHAHAAAEdwAAENwBAADBHQAABHcAAEBwBwAABHcAABDcAQAAwR0AABDcAQBAcAcAAAR3AAAQ3AEAAMEdAAAQ3AEAQHAHAAAEdwAAQHAHAADBHQAAENwBAADBHQAABHcAAEBwBwAAwR0AABDcAQAAwR0AAAR3AABAcAcAAAR3AAAQ3AEAAMEdAAAEdwAAQHAHAAAEdwAAENwBAADBHQAAENwBAEBwBwAABHcAAEBwBwAAwR0AABDcAQBAcAcAAAR3AABAcAcAAMEdAAAQ3AEAAMEdAAAEdwAAQHAHAADBHQAAENwBAADBHQAABHcAAEBwBwAABHcAABDcAQAAwR0AABDcAQBAcAcAAAR3AAAQ3AEAAMEdAAAQ3AEAQHAHAAAEdwAAQHAHAADBHQAAENwBAEBw1w4AACC4AwAAgjsAAAjuAACA4A4AAAjuAAAguAMAAII7AAAguAMAgOAOAAAI7gAAILgDAACCOwAAILgDAIDgDgAACO4AAIDgDgAAgjsAACC4AwCA4C64AwCA4A4AAAjuAAAguAMAAII7AAAguAMAgOAOAAAI7gAAgOAOAACCOwAAILgDAIDgDgAACO4AAIDgDgAAgjsAACC4AwAAgjsAAAjuAACA4A4AAIK74A4AAII7AAAguAMAgOAOAAAI7gAAgOAOAACCOwAAILgDAACCOwAACO4AAIDgDgAAgjsAACC4AwAAgjsAAAjuAACA4A4AAAjuAAAguAMAAII7AAAI7oI7AAAI7gAAgOAOAACCOwAAILgDAACCOwAACO4AAIDgDgAACO4AACC4AwAAgjsAAAjuAACA4A4AAAjuAAAguAMAAII7AAAguAMAgOAOAAAI7gAAILgL7gAAILgDAACCOwAACO4AAIDgDgAACO4AACC4AwAAgjsAACC4AwCA4A4AAAjuAAAguAMAAII7AAAguAMAgOAOAAAI7gAAgOAOAACCOwAAILgDAIDgLrgDAIDgDgAACO4AACC4AwAAgjsAACC4AwCA4A4AAAjuAACA4A4AAII7AAAguAMAgOAOAAAI7gAAgOAOAACCOwAAILgDAACCOwAACO4AAIDgDgAACO4AACC4AwAAgjsAAAjuAACA4A4AAAjuAAAguAMAAII7AAAguAMAgOAOAAAI7gAAILgDAACCOwAAILgDAIDgDgAACO4AAIDgDgAAgjsAACC4AwAAgjsAAAjuAACA4A4AAII7AAAguAMAAII7AAAI7gAAwE8I7n9qBwAA+KX9+Z/g/r9fj//79fg/DofD4XA4HA6H45c7/pPV//f/AYNNOyEUrHqDAAAAAElFTkSuQmCC");
		background-size: cover;
		z-index: -1;
	}

	.main-box {
		// height: 100vh;
		// background-image: linear-gradient(#4190FF, #FFFFFF);

	}

	.content {
		padding: 20rpx 30rpx 0;


		.search-box {
			width: 690rpx;
			height: 70rpx;
			background-color: #ABCEFF;
			border-radius: 10rpx;
			// margin-top: 20rpx;
			display: flex;
			justify-content: space-between;
			align-items: center;

			.left {
				padding-left: 19rpx;
				font-size: 26rpx;
				color: #FFFFFF;

				display: flex;
				align-items: center;

				image {
					width: 24rpx;
					height: 14rpx;
					margin-left: 19rpx;
				}
			}

			.mid {
				width: 400rpx;
				height: 100%;
				margin-left: 16rpx;
				display: flex;
				align-items: center;

				.vline-blue {
					width: 2rpx;
					height: 50rpx;
					background-color: #1677FF;
					opacity: 0.22;

				}

				.search-icon {

					width: 32rpx;
					height: 32rpx;

					margin-left: 40rpx;

					image {
						width: 100%;
						height: 100%;
					}
				}

				.ipt-box {
					margin-left: 21rpx;
					width: 249rpx;
					height: 70rpx;
					display: flex;
					align-items: center;

					input {
						background-color: #ABCEFF;
						height: 70rpx;
						font-size: 30rpx;
					}

					overflow: hidden;
				}

			}

			.btn-box {
				width: 110rpx;
				height: 56rpx;
				font-size: 30rpx;
				color: #FFFFFF;
				text-align: center;
				line-height: 56rpx;
				background: #4794FF;
				border-radius: 10rpx;
				margin-right: 10rpx;
			}
		}



		.swiper-box1 {
			box-sizing: border-box;
			display: flex;
			justify-content: space-between;
			align-items: center;
			margin-top: 20rpx;
			width: 690rpx;
			height: 100rpx;
			background-color: #FFFFFF;
			padding-left: 23rpx;
			padding-right: 32rpx;
			border-radius: 10rpx;
			overflow: hidden;

			.left {
				width: 58rpx;
				height: 60rpx;

				image {
					width: 100%;
					height: 100%;
				}
			}

			.mid {
				// margin-left:30rpx;

				height: 100rpx;
				width: 469rpx;
				line-height: 100rpx;
				overflow: hidden;

				swiper {
					padding-left: 30rpx;
					height: 100rpx;
					width: 469rpx;

				}

				.swiper-item {
					width: 419rpx;
					white-space: nowrap;
					text-overflow: ellipsis;
					overflow: hidden;
					word-break: break-all;
					padding-left: 20rpx;
				}

			}

			.right {
				width: 42rpx;
				height: 34rpx;

				image {
					width: 100%;
					height: 100%;
				}
			}
		}

		.vline {
			width: 2rpx;
			height: 80rpx;
			background: #F5F5F5;
			border-radius: 1rpx;
			margin-left: 23rpx;
		}

		.vline1 {
			width: 2rpx;
			height: 80rpx;
			background: #F5F5F5;
			border-radius: 1rpx;
			margin-right: 26rpx;
		}
	}

	.score {
		margin-top: 18rpx;

		.top {
			display: flex;
			justify-content: space-between;
			align-items: center;
		}

		.left {
			display: flex;
			align-items: center;

			.type1 {
				font-size: 30epx;
				font-family: PingFang SC;
				font-weight: bold;
				color: #1576FF;
				border-bottom: 6rpx solid #4894FF;
			}

			.type2 {
				font-size: 26rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: #333333;
			}
		}

		.right {
			// width: 160rpx;
			height: 50rpx;
			display: flex;
			justify-content: space-between;
			padding: 10rpx 10rpx;
			background-color: rgba($color: #F0F6FF, $alpha: 0.6);
			font-size: 26rpx;

			align-items: center;

			border-radius: 10rpx;

			image {
				width: 24rpx;
				height: 14rpx;
				margin-left: 20rpx;
			}
		}

		.score-box {
			margin-top: 11rpx;

			.score-item {
				width: 690rpx;
				height: 200rpx;
				background: #FFFFFF;
				border: 1rpx solid #EEEEEE;
				border-radius: 10rpx;
				display: flex;
				align-items: center;
				margin-bottom: 20rpx;

				.left1 {
					width: 179rpx;
					height: 180rpx;
					border-radius: 10rpx;
					margin-left: 11rpx;
					overflow: hidden;

					image {
						width: 180rpx;
						height: 180rpx;
					}
				}

				.right1 {
					margin-left: 22rpx;
					width: 458rpx;
					height: 100%;
					display: flex;
					flex-direction: column;
					justify-content: space-evenly;

					.rline1 {
						font-size: 30rpx;
					}

					.rline2 {
						font-size: 24rpx;
						color: #666666;
						white-space: nowrap;
						text-overflow: ellipsis;
						overflow: hidden;
						word-break: break-all;

					}

					.rline3 {
						width: 500rpx;
						font-size: 24rpx;
						display: flex;
						align-items: center;

						image {
							width: 28rpx;
							height: 28rpx;
							margin-left: 1rpx;
						}
					}

					.rline4 {
						width: 500rpx;
						font-size: 24rpx;
						display: flex;
						align-items: center;

						// padding-left: 5rpx;
						image {
							width: 20rpx;
							height: 27rpx;
							margin-left: 6rpx;
						}
					}

				}
			}

		}

		.kkq {
			width: 100%;
			margin-top: 15rpx;
			// background-color: red;
			display: flex;
			justify-content: flex-start;

			.img {
				width: 78rpx;
				height: 70rpx;
				border-radius: 50%;
				margin-right: 20rpx;
			}

			.kkq-r {
				width: 100%;

				// background-color: yellow;
				.title {
					.t1 {

						font-size: 30rpx;
						font-family: PingFang SC;
						font-weight: 500;
						color: #1576FF;
						// line-height: 70px;
					}

					.t2 {
						margin-left: 20rpx;
						font-size: 24rpx;
						font-family: PingFang SC;
						font-weight: 400;
						color: #1576FF;
						// line-height: 70px;
						border: 1px solid #3699FF;
						border-radius: 4px;
					}

				}

				.text {
					margin-top: 10rpx;
					width: 100%;
					// height: 65rpx;
					font-size: 28rpx;
					font-family: PingFang SC;
					font-weight: 500;
					color: #333333;
					line-height: 38rpx;
				}

				.imgs {
					display: flex;
					flex-wrap: wrap;
					justify-content: flex-start;
					margin-top: 20rpx;

					.imggg {
						width: 172rpx;
						height: 172rpx;
						margin-bottom: 20rpx;
						margin-right: 20rpx;
					}
				}

				#video1 {
					width: 100%;

				}

				.bot {
					margin-top: 15rpx;
					width: 100%;
					// height: 23px;
					font-size: 24rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #999999;
				}
			}
		}

		.line-txt {
			margin-left: 10rpx;
		}


	}

	.mask {

		.popup-box {

			display: flex;
			// justify-content: space-evenly;

			flex-wrap: wrap;
			padding: 0 30rpx 25rpx;
			background-color: #FFFFFF;
			box-sizing: border-box;

			.popup-box-item {
				width: 210rpx;
				height: 60rpx;
				// display: flex;
				text-align: center;
				line-height: 60rpx;
				background: rgba(204, 204, 204, 0.15);
				border-radius: 6rpx;
				margin-top: 20rpx;
				margin-left: 15rpx;
				position: relative;

				.box-item-txt {
					// position: absolute;
					// left: 50%;
					// top: 50%;
					// transform: translate(-50%,-50%);

				}

				.box-item-icon {
					position: absolute;
					right: 0;
					bottom: 0;
					width: 44rpx;
					height: 44rpx;

					image {
						width: 100%;
						height: 100%;
					}
				}
			}

		}


	}

	// .swiper-box{
	// 	position: relative;
	// }


	.swiper-box {
		margin-top: 20rpx;

		border-radius: 10rpx;

		width: 690rpx;
		height: 275rpx;

		.theSwiper {
			width: 690rpx;
			height: 275rpx;
			overflow: hidden;

		}

		.swiper-item {
			position: relative;
			height: 275rpx;

			width: 100%;

			text-align: center;

			#theVideo {
				width: 100%;
				height: 100%;
			}

			.img {
				width: 100%;
				height: 100%;
				position: absolute;
				bottom: 0;
				left: 0;
			}

			.url-box {
				position: absolute;
				bottom: 1%;
				right: 1%;
				z-index: 999;
				width: 100rpx;
				height: 30rpx;

				image {
					width: 100%;
					height: 100%;
				}
			}

			image {
				width: 99%;
				height: 99%;
			}

			video {
				width: 99%;
				height: 99%;

			}
		}
	}

	.theEnd {
		height: 121rpx;
	}

	.theTabBar {
		box-sizing: border-box;
		background-color: #FFFFFF;
		z-index: 99999;
		position: fixed;
		bottom: 0;
		left: 0;
		// background-color: red;
		width: 750rpx;
		height: 100rpx;
		display: flex;
		justify-content: space-around;
		overflow: hidden;
		box-shadow: 0rpx -2rpx 0rpx 0rpx rgba(0, 0, 0, 0.06);

		.item {
			margin: 10rpx 0;
			display: flex;
			justify-content: center;
			flex-wrap: wrap;
			width: 60rpx;
			height: 80rpx;
			font-size: 24rpx;

			image {
				margin-bottom: 6rpx;
				width: 44rpx;
				height: 44rpx;
			}
		}

	}
</style>
