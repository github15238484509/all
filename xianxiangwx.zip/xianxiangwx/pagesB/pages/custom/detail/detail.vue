<template>
	<view class="box">
		<!-- 头部任务信息 start -->
		<view class="cardd">
			<view class="card-c" >
				<view class="left1">
					<image :src="$imgUrl(ddetail.photo)" mode="aspectFill"></image>
					<view class="txt">
						<text>{{ddetail.status}}</text>
					</view>
				</view>
				<view class="right1" @click="toTaskDetail(ddetail.task_id)">
					<view class="rline1">
						<view class="hhh">
							<text>{{merchant.scope_name}}</text>
						</view>
						<text class="title" style="margin-left: 10rpx;">{{ddetail.task_name}}</text>
					</view>
					<view class="rline2">
						{{merchant.merchant_address}}
					</view>
					<view class="rline3">
						<text class="line-txt" v-if="rank==6||rank==7||rank==1">预计:</text>
						<text class="line-txt1" >￥{{$returnFloat(ddetail.anticipated)}}元/人</text>
					</view>
					<view class="rline4">
						<text class="line-txt">{{$time(ddetail.submit_time,0)}}</text>
						<text class="line-txt" style="margin-left: 10rpx;">{{$time(ddetail.submit_time,3)}}</text>
					</view>
				</view>
			</view>
		</view>
		<!-- 头部任务信息 end -->
		<!-- 中间客户信息 start -->
		<view class="centre">
			<view class="top">
				<view class="left">客户信息</view>
				<view v-bind:class="[ddetail.audit_status != 3 ? right1 : right2]">{{showstate}}</view>
			</view>
			
			<view class="centre-detail">
				<view class="left">姓&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;名</view>
				<view class="right">{{ddetail.name}}</view>
			</view>
			<view class="centre-detail">
				<view class="left">联系电话</view>
				<view class="right">
					{{ddetail.phone}}
					<image src="../../../../static/phone.png" style="width: 32rpx;height: 32rpx;padding: 0rpx 22rpx;" @click="callPhone(ddetail.phone)"/>
				</view>
			</view>
			<view class="centre-detail">
				<view class="left">性&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;别</view>
				<view class="right">{{ddetail.sex}}</view>
			</view>
			<view class="centre-detail">
				<view class="left">年&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;龄</view>
				<view class="right">{{ddetail.age}}</view>
			</view>
			<view class="centre-detail" style="margin-bottom: 18rpx;">
				<view class="left">体验课类型</view>
				<view class="right">{{ddetail.type?ddetail.type:"暂无"}}</view>
			</view>
			<view class="centre-detail line">
				<view class="left">备注说明</view>
				<view class="right">{{ddetail.remarks}}</view>
			</view>
			
			<view class="centre-detail line2" v-if="showError">
				<view class="left">无效原因</view>
				<view class="right">{{suoyin2}}</view>
			</view>
			
			<view class="centre-detail" v-if="showError">
				<view class="left">原因说明</view>
				<view class="right">{{content}}</view>
			</view>
			
		</view>
		<!-- 中间客户信息 end -->
		
		<!-- 底部审核按钮 start -->
		<view class="footer" v-if="show">
			<view class="left" @click="checkError()">审核拒绝</view>
			<view class="right" @click="checkSuccess()">审核通过</view>
		</view>
		<!-- 底部审核按钮 end -->
		
		<!-- 审核弹窗通过悬窗 start -->
		<view class="window" v-if="seeSuccess" @click="hitCopy">
			
			<view class="particulars">
				
				<view class="top">提示</view>
				<view class="show">您的有效客户数量已达标，是否需要更多客户？</view>
				<view class="buttom">
					<view class="left" @click="hitCopy()">取消</view>
					<view class="right" @click="add()">增加客户数量</view>
				</view>
				
			</view>
			
		</view>
		<!-- 审核弹窗通过悬窗 end -->
		
		<!-- 审核弹窗拒绝悬窗 start -->
		<view class="window" v-if="seeError" @click="hitCopy">
			
			<view class="particulars" style="height: 430rpx;width: 560rpx;" @click.stop="checkError()">
				
				<view class="top">提示</view>
				<view class="fk_list">
					<view style="width: 140rpx;">无效原因：</view>
					<view v-for="(item, i) in fk" :key="i" @click.stop="change_fk(item.id, item.name)" style="margin-left: 13rpx;">
						<image :src="item.id === suoyin ? item.icon2 : item.icon" style="width: 36rpx;height:36rpx;"></image>
						<text>{{ item.name }}</text>
					</view>
				</view>
				
				<!--内容 -->
				<view class="texe_input">
					<!-- <image src="../../static/region_bg.png" mode="aspectFill" class="region_bg"></image> -->
					<textarea v-model="content" placeholder="请说明无效情况" name="textarea" maxlength="-1" class="text" />
				</view>
				
				<view class="copy" @click.stop="sure()">确定</view>
						
			</view>
			
		</view>
		<!-- 审核弹窗拒绝悬窗 end -->
	</view>
</template>

<script>
	import taskApi from "../../../../api/product/product.js"
	
	export default {
		data() {
			return {
				customer_index:'',
				
				ddetail:{},
				merchant:{},
				
				showstate:'',
				rank:"",
				start:false,
				right1:'right1',
				right2:'right2',
				show:false,//是否显示 审核按钮
				seeSuccess:false,//是否显示 审核通过弹窗
				seeError:false,//是否显示 驳回弹窗
				showError:false,//是否显示无效原因
				fk: [
					{ id: 0, icon: '../../../../static/fk_icon.png', icon2: '../../../../static/fk_icon2.png', name: '虚假' },
					{ id: 1, icon: '../../../../static/fk_icon.png', icon2: '../../../../static/fk_icon2.png', name: '重复' },
					{ id: 2, icon: '../../../../static/fk_icon.png', icon2: '../../../../static/fk_icon2.png', name: '其他' }
				],
				suoyin: -1,//拒绝原因id
				suoyin2: '',//拒绝原因
				content: '',//拒绝理由
				nid:'',//任务id
			}
		},
		onLoad(e) {
			console.log(e.id)
			this.customer_index = e.id;
			taskApi.referrer().then(res => {
			        console.log(res)
			        if (res.status == 200) {
			        this.rank=res.result.rank
			        } else {
			                uni.showToast({
			                title: res.message,
			                icon: 'none'
			                })
			        }
			})
			taskApi.get_clent_detail({
				customer_index:e.id
			}).then(res => {
				console.log(res)
				if (res.status == 200) {
					this.ddetail = res.result
					this.merchant = res.result.merchant
					if(res.result.is_audit == 1){
						this.show = true
					}else{
						this.show = false
					}
					
					if(res.result.audit_status == 1){
						this.showstate = '待审核'
						this.showError = false
					}else if(res.result.audit_status == 2){
						this.showstate = '有效客户'
						this.showError = false
					}else if(res.result.audit_status == 3){
						this.showstate = '无效客户'
						this.showError = true
						if(res.result.invalid_type == 0){
							this.suoyin2 = '虚假'
						}else if(res.result.invalid_type == 1){
							this.suoyin2 = '重复'
						}else if(res.result.invalid_type == 2){
							this.suoyin2 = '其他'
						}
		
						this.content = res.result.invalid_reason
					}
					this.nid = res.result.task_id
					
					//console.log(this.nid,"22222222")
				}else{
					uni.showToast({
						title: res.message,
						icon: 'none'
					})
				}
			})
		},
		methods: {
			toTaskDetail(task_id){
				uni.navigateTo({
					url:'./task_detail?id='+task_id
				})
			},
			change_fk(i, name) {
				this.suoyin = i 
				this.suoyin2 = name;
			},
			//拨打电话
			callPhone(phone){
				console.log("拨打电话")
				uni.makePhoneCall({
				    phoneNumber: phone//仅为示例
				});
			},
			checkError(){
				//审核拒绝
				this.seeError = true;
			},
			checkSuccess(){
				//审核通过
				let this_ = this
				uni.showModal({
					title: "提示",
					content: "是否确定审核通过",
					confirmText: "确定",
					confirmColor: '#3898FF',
					cancelColor: '#999999',
					success: (res) => {
						// console.log(id)
						if (res.confirm) {
							taskApi.set_audit({
								customer_index:this_.customer_index,
								type:2
							}).then(res => {
								console.log(res)
								if(res.status == 205){
									this_.seeSuccess = true;
								}else if(res.status == 200){
									this_.ddetail.audit_status = 2
									this_.showstate = '有效客户'
									this_.showError = false
									this_.show = false
								}else {
									uni.showToast({
										title: res.message,
										icon: 'none'
									})
								}
								
							})
						}
				
					}
				})
				
			},
			hitCopy(){
				this.seeError = false;
				this.seeSuccess = false;
			},
			add(){
				//添加用户数量
				//console.log(this.nid,"22222222")
				uni.navigateTo({
					url: './add_client_number?task_id=' + this.nid
				})
				this.hitCopy()
			},
			sure(){
				let that = this;
				if(that.suoyin == -1){
					uni.showToast({
						icon:'none',
					    title: '请选择无效原因',
					    duration: 2000
					});
				}else if (!that.content) {
					uni.showToast({
						icon:'none',
					    title: '反馈内容不能为空',
					    duration: 2000
					});
				}else{
					console.log("提交无效原因")
					this.hitCopy()
					//提交无效原因
					//审核通过
					taskApi.set_audit({
						customer_index:this.customer_index,
						type:3,
						invalid_type:that.suoyin,
						invalid_reason:that.content
					}).then(res => {
						console.log(res)
						if(res.status == 200){
							this.ddetail.audit_status = 3
							this.showstate = '无效客户'
							this.showError = true
							this.show = false
						}else {
							uni.showToast({
								title: res.message,
								icon: 'none'
							})
						}
						
					})
				}
			}
			
		}
	}
</script>

<style lang="scss" scoped>
	.box {
		width: 100%;
	
		.cardd {
			height: 190rpx;
			display: flex;
			justify-content: flex-start;
			align-items: center;
			margin-top: 30rpx;
			
	
			.card-c {
				height: 160rpx;
				display: flex;
				justify-content: flex-start;
				align-items: center;
				margin-left: 30rpx;
				border-bottom: solid 1rpx #F5F5F5;
				padding-bottom: 30rpx;
				
				.left1 {
					width: 160rpx;
					height: 160rpx;
					border-radius: 10rpx;
					overflow: hidden;
					position: relative;
					image {
						width: 180rpx;
						height: 180rpx;
						position: absolute;
						left: 0;
						top: 0;
					}
					.txt{
						width: 160rpx;
						height: 30rpx;
						background: #000000;
						opacity: 0.5;
						border-radius: 0rpx 0rpx 10rpx 10rpx;
						display: flex;
						justify-content: center;
						align-items: center;
						position: absolute;
						left: 0;
						bottom: 0;
						
					
						font-size: 20rpx;
						font-family: PingFang SC;
						font-weight: 400;
						color: #FFFFFF;
					
					}
				}
	
				.right1 {
					margin-left: 22rpx;
					width: 520rpx;
					height: 100%;
					display: flex;
					flex-direction: column;
					justify-content: space-evenly;
	
					.rline1 {
						font-size: 30rpx;
						display: flex;
						justify-content: flex-start;
						align-items: center;
						.hhh{
							width: 130rpx;
							height: 30rpx;
							background: linear-gradient(32deg, #3699FF, #7CBDFF);
							border-radius: 4rpx;
							display: flex;
							justify-content: center;
							align-items: center;
							font-size: 18rpx;
							font-family: PingFang SC;
							font-weight: 400;
							color: #FFFFFF;
						}
						.title {
							overflow: hidden;  /*超出部分隐藏*/
							white-space: nowrap;  /*禁止换行*/
							text-overflow: ellipsis; /*省略号*/

						}
						.img {
							width: 44rpx;
							height: 44rpx;
	
							border-radius: 50%;
	
						}
					}
	
					.rline2 {
						font-size: 24rpx;
						color: #666666;
						white-space: nowrap;
						text-overflow: ellipsis;
						overflow: hidden;
						word-break: break-all;
	
					}
	
					.rline3 {
						width: 500rpx;
						
						display: flex;
						align-items: center;
						.line-txt{
							width: 65rpx;
							
							font-size: 24rpx;
							font-family: PingFang SC;
							font-weight: 400;
							color: #FF3131;
							
						}
						.line-txt1{
							
						
							font-size: 30rpx;
							font-family: PingFang SC;
							font-weight: 500;
							color: #FF3131;
							// line-height: 66px;
						}
						image {
							width: 28rpx;
							height: 28rpx;
							margin-left: 1rpx;
						}
					}
	
					.rline4 {
						width: 500rpx;
						font-size: 26rpx;
						display: flex;
						align-items: center;
	
	
	
						font-family: PingFang SC;
						font-weight: 400;
						color: #999999;
	
						// padding-left: 5rpx;
						image {
							width: 20rpx;
							height: 27rpx;
							margin-left: 6rpx;
						}
	
						.refuse {
							display: flex;
							align-items: center;
							justify-content: center;
	
							font-size: 24rpx;
							font-family: PingFang SC;
							font-weight: 400;
							color: #FE5E5E;
	
							.fff {
								border-bottom: 1rpx solid #FFF;
							}
	
							.ml {
								margin-left: 10rpx;
								border-bottom: 1rpx solid #FE5E5E;
							}
						}
					}
	
				}
			}
		}
	
	
	}
	
	.centre {
		margin: 32rpx 30rpx 18rpx;
		
		.top {
			height: 28rpx;
			width: 100%;
			display: flex;
			justify-content: space-between;
			align-items: center;
			border-left: 4rpx solid #1777FF;
			margin: 13rpx 0rpx;
			
			.left {
				margin-left: 11rpx;
				font-size: 30rpx;
				color: #333333;
			}
			
			.right1 {
				color: #3798FF;
				font-size: 26rpx;
			}
			
			.right2 {
				color: #FF3131;
				font-size: 26rpx;
			}
			
		}
		
		.centre-detail {
			padding: 13rpx 0rpx;
			display: flex;
			justify-content: flex-start;
		
			
			.left {
				width: 135rpx;
				color: #999999;
				font-size: 26rpx;
			}
			.right {
				width: 520rpx;
				margin-left: 23rpx;
				color: #333333;
				font-size: 26rpx;
			}
		}
		
		.line {
			padding: 30rpx 0rpx;
			border-top: 1rpx solid #f5f5f5;
		}
		
		.line2 {
			margin-top: 21rpx;
			padding: 30rpx 0rpx 12rpx;
			border-top: 1rpx solid #f5f5f5;
		}
	}
	
	.footer {
		width: 720rpx;
		height: 100rpx;
		// background-color: yellow;
		position: fixed;
		bottom: 0;
		left: 0;
		display: flex;
		font-size: 20rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #999999;
		justify-content: flex-start;
		border-top: solid 2px rgba(0, 0, 0, 0.08);
		padding: 0 15rpx;
	
		.left {
			width: 50%;
			color: #3798FF;
			height: 70rpx;
			display: flex;
			align-items: center;
			justify-content: center;
			background: #fff;
			border:solid 1rpx  #3798FF;
			margin: 15rpx;
			border-radius: 10rpx;
		}
	
		.right {
			width: 50%;
			color: #fff;
			height: 70rpx;
			display: flex;
			align-items: center;
			justify-content: center;
			background: #3798FF;
			margin: 15rpx;
			border-radius: 10rpx;
		}
	}
	
	.window {
		position: fixed;
		left: 0;
		top: 0;
		width: 100%;
		height: 100%;
		background: rgba(0, 0, 0, 0.5);
		font-family: PingFang SC;
		font-weight: 400;
		z-index: 999;
		
		.particulars {
			position: absolute;
			left: 50%;
			top: 50%;
			transform: translate(-50%, -50%);
			width: 500rpx;
			height: 300rpx;
			background: #FFFFFF;
			border-radius: 10rpx;
			box-sizing: border-box;
			z-index: 999;
			font-size: 30rpx;
			text-align: center;
			
			.top{
				margin-top: 31rpx;
				font-size: 30rpx;
				color: #333333;
			}
			
			.show {
				margin-top: 30rpx;
				width: 440rpx;
				font-size: 26rpx;
				color: #999999;
				word-wrap: break-word;
				margin: 30rpx auto;
			}
			
			.buttom {
				width: 100%;
				height: 90rpx;
				border-top: 1px solid #f5f5f5;
				color: #4694FF;
				position: absolute;
				bottom: 0px;
				
				.left {
					width: 49%;
					height: 60rpx;
					float: left;
					font-size: 30rpx;
					color: #999999;
					padding-top: 30rpx;
				}
				.right {
					height: 60rpx;
					width: 49%;
					float: left;
					color: #4695FE;
					font-size: 30rpx;
					padding-top: 30rpx;
					border-left: 1px solid #f5f5f5;
				}
			}
			.copy {
				padding: 20px 0px;
				width: 100%;
				border-top: 1px solid #f5f5f5;
				color: #4694FF;
				position: absolute;
				bottom: 0px
			}
		}
	}
	
	.fk_list {
		display: flex;
		width: 500rpx;
		justify-content: space-between;
		margin-top: 20rpx;
		font-size: 26rpx;
		margin: 47rpx auto 19rpx;
	}
	.fk_list view {
		display: flex;
		align-items: center;
		justify-content: space-between;
		width: 110rpx;
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: rgba(51, 51, 51, 1);
	}
	.texe_input {
		width:490rpx;
		border-radius: 10rpx; 
		height:140rpx;
		position: relative;
		margin: 35rpx auto 0rpx;
		background-color: #F5F5F5;
		.text {
			background-color: rgba(0,0,0,0); 
			width: 450rpx;
			position: absolute;
			z-index: 2; 
			height:80%;
			color: #969696;
			font-size:24rpx;
			font-family:PingFang SC;
			font-weight:400;
			padding: 10px;
			padding-left: 20rpx;
			text-align: left;
		}
		
	}
		
</style>
