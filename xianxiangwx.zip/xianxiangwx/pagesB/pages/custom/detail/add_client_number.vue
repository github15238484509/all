<template>
	<view>
		<view class="top">
			<view class="left">增加客户数量</view>
			<input v-model="content" class="right" type="number" placeholder="请输入">
		</view>

		<view class="hint">提示：请输入您需要增加的客户数量（原需客户数量20人）</view>

		<!-- 底部审核按钮 start -->
		<view class="footer">
			<view  class="but" @click="subMit()">提交信息</view>
		</view>
		<!-- 底部审核按钮 end -->

	</view>

</template>

<script>
	import taskApi from "../../../../api/product/product.js"
	export default {
		data() {
			return {
				taskid:'',
				content:'',
			}
		},
		onLoad(e){
			this.taskid = e.task_id
		},
		methods: {
			subMit(){
				let that = this;
				if (!that.content) {
					uni.showToast({
						icon:'none',
					    title: '请输入客户数量',
					    duration: 2000
					});
				}else{
					console.log("提交增加客户数量")
					//提交信息
					uni.navigateTo({
						url: "./pay?taskid="+that.taskid+"&number="+that.content
					})
				}
			},
		}
	}
</script>

<style lang="scss" scoped>
	.top {
		height: 25rpx;
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 30rpx 30rpx 30rpx 0rpx;
		margin-left: 30rpx;
		font-size: 26rpx;
		color: #333333;
		border-bottom: 2px solid #F5F5F5;

		.right {
			font-size: 26rpx;
			text-align: end;
		}

	}

	.hint {
		font-size: 26rpx;
		color: #999999;
		padding: 20rpx 30rpx;
	}

	.footer {
		width: 630rpx;
		position: fixed;
		bottom: 30rpx;
		left: 50%;
		margin-left: -315rpx;

		.but {
			font-size: 30rpx;
			color: #ffffff;
			background-color: #3699FF;
			text-align: center;
			padding: 30rpx;
			border-radius: 10rpx;
		}

	}
</style>
