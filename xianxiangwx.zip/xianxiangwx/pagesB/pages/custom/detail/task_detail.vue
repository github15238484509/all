<template>
	<view class="box">
		<!-- 头 start -->
		<view class="header">
			<view class="card">
				<view class="left1">
					<image :src="$imgUrl(oneObj.picture)" mode="aspectFill"></image>
				</view>
				<view class="right1" @click="goDetail(objIf.merchant_id)">
					<view class="rline1">
						{{oneObj.name?oneObj.name:""}}

					</view>
					<view class="rline2">
						{{objIf.merchant_address?objIf.merchant_address:''}}
					</view>
					<view class="rline3">
						<image src="../../../static/time.png" mode="aspectFill"></image>
						<text style="margin-left: 10rpx;" class="line-txt">{{objIf.merchant_worktime_start?objIf.merchant_worktime_start:""}}-{{objIf.merchant_worktime_end?objIf.merchant_worktime_end:""}}</text>
					</view>
					<view class="rline4">
						<image src="../../../static/location.png" style="width: 28rpx;height: 28rpx;margin: 0;"></image>
						<text class="line-txt">{{distance?distance:"0.00m"}}</text>
					</view>
				</view>
				<image src="../../../static/right.png" style="width: 17rpx;height: 32rpx;margin-left: 40rpx;"></image>
			</view>
		</view>
		<!-- 头 end -->
		<!-- 任务信息 start -->
		<view class="line">
			<view class="left">
				<view class="dot">

				</view>
				<text style="margin-left: 10rpx;">任务信息</text>

			</view>
			<view class="right" @click="open2">
				<image src="../../../../static/share.png" class="img"></image><text>分享</text>

			</view>
		</view>
		<view class="msg">
			<view class="msg-t">
				<image :src="$imgUrl(oneObj.picture)" class="img"></image>
				<view class="title">
					<text class="tt" v-if="oneObj.status=='1'">等待接单</text>
					<text class="tt" v-if="oneObj.status=='2'">报名中</text>
					<text class="tt" v-if="oneObj.status=='3'">进行中</text>
					<text class="tt" v-if="oneObj.status=='4'">已结束</text>
					{{oneObj.name?oneObj.name:""}}
				</view>
			</view>
			<view class="sj">
				发布时间：{{oneObj.submit_time?$time(oneObj.submit_time,0):""}} {{oneObj.submit_time?$time(oneObj.submit_time,3):""}}
			</view>
		</view>
		<view class="banner">
			<view class="line-x">
				<view class="left">
					结束时间
				</view>
				<view class="right">
					{{oneObj.end_time?$time(oneObj.end_time,0):""}} {{oneObj.end_time?$time(oneObj.end_time,4):""}}
				</view>
			</view>
			<view class="line-x">
				<view class="left">
					预计金额
				</view>
				<view class="right" style="color: #FF3131;">
					￥{{oneObj.anticipated?$returnFloat(oneObj.anticipated):""}}/人
				</view>
			</view>
			<view class="line-x">
				<view class="left">
					客户数量
				</view>
				<view class="right">
					{{oneObj.customer_num?oneObj.customer_num:""}}人
				</view>
			</view>
			<view class="line-x">
				<view class="left">
					客户年龄
				</view>
				<view class="right">
					最小：{{oneObj.start_age?oneObj.start_age:""}}, 最大：{{oneObj.end_age?oneObj.end_age:""}}
				</view>
			</view>
			<view class="line-x">
				<view class="left">
					客户性别
				</view>
				<view class="right">
					{{oneObj.gender?oneObj.gender:""}}
				</view>
			</view>
			<view class="line-x" style="margin-bottom: 33rpx;">
				<view class="left">
					体验课费用
				</view>
				<view class="right" style="margin-left: 29rpx;">
					{{oneObj.anticipated?$returnFloat(oneObj.anticipated):""}}
				</view>
			</view>
		</view>
		<view class="line2">
			<view class="left">
				<view class="dot"></view>
				<text style="margin-left: 10rpx;">体验课收费说明</text>

			</view>
		</view>

		<view class="text-show" style="border-bottom: 1px solid #F5F5F5;">
			{{oneObj.experience_explain?oneObj.experience_explain:""}}
		</view>

		<view class="line2">
			<view class="left">
				<view class="dot"></view>
				<text style="margin-left: 10rpx;">活动说明</text>

			</view>
		</view>

		<view class="text-show">
			{{oneObj.activity_explain?oneObj.activity_explain:""}}
		</view>

		<!-- 任务信息 end -->

		<view class="share" v-if="show2">
			<image :src="$imgUrl(share_task)" mode="aspectFit" class="share_center"></image>
			<view class="footer22">
				<view class="item">
					<view class="left">
						<image src="../../../../static/wxdl.png" class="img"></image>
						<button :plain="true" open-type="share" class="fx"></button>
						<view class="text">
							微信好友
						</view>

					</view>
					<view class="right">
						<image @click="getImg()" src="../../../static/bctp.png" class="img"></image>
						<view class="text">
							保存图片
						</view>

					</view>
				</view>
				<view class="item2" @click="close2()">
					<view class="txt">
						取消
					</view>

				</view>
			</view>
		</view>

	</view>
</template>

<script>
	import taskApi from "../../../../api/task/task.js"
	export default {
		data() {
			return {
				oneObj: {},
				objIf: {},
				id: "",
				show2: false,
				longitude: "113.60152",
				latitude: "34.746502",
                distance: "0.00",
			}
		},
		onLoad(e) {
			console.log(e);

			this.id = e.id
			//获取经纬度
			uni.getLocation({
				// type: 'wgs84',
				success: (res) => {
					console.log(res);
					// this.longitude = res.longitude
					// this.latitude = res.latitude
					// console.log(222222222222); 
					taskApi.taskDetail({
						task_id: this.id,
						lng: res.longitude,
						lat: res.latitude
						/*lng: this.longitude,
						lat: this.latitude*/
					}).then(res => {
						// console.log(333333333333);
						console.log(res)
						if (res.status == 200) {
							this.oneObj = res.result
							this.objIf = res.result.merchant[0]
                            this.distance = this.objIf.distance
                            if (this.distance == 1000) {
                                this.distance = "1.0km"
                            } else if (this.distance > 1000) {
                                const realVal = parseFloat(this.distance/1000).toFixed(1);
                                this.distance = realVal + 'km'
                            } else {
                                const realVal = parseFloat(this.distance).toFixed(1);
                                this.distance = realVal + 'm'
                            }
						} else {
							uni.showToast({
								title: res.message,
								icon: 'none'
							})
						}
					})


				},
				fail: (res) => {
					uni.showModal({
						showCancel: false,
						content: '获取定位失败，请打开手机定位',
					})

				}
			})
		},
		methods: {
			open2() {
				//分享二维码
				taskApi.shareTask({
					page: "/pages/custom/detail/task_detail",
					task_id: this.id
				}).then(res => {
					if (res.status == 200) {
						this.share_task = res.result.share_task
						this.show2 = true
						console.log(111);
					} else {
						uni.showToast({
							title: res.result.message,
							icon: 'none'
						})
					}

				})
			},
			//保存图片
			getImg() {
				// uni.showModal({
				// 	content: '进到了getimg方法'
				// })
				console.log(this.share_task)
				console.log(this.$imgUrl(this.share_task))
				let this_ = this
				uni.getImageInfo({
					src: this.$imgUrl(this.share_task),
					success: function(image) {
						// uni.showModal({
						// 	content: '进到了getImageInfo'
						// })
						console.log(image);
						let imgPath = image.path
						console.log(image.path);

						uni.saveImageToPhotosAlbum({
							filePath: imgPath,
							success: function() {

								console.log('save success');
							},
							fail: function(err) {
								uni.authorize({
									// scope: 'scope.userLocation',
									success() {
										//1.1 允许授权
										// console.log(error);
									},
									fail() {
										//1.2 拒绝授权
										uni.showModal({
											content: '检测到您没打开获取信息功能权限，是否去设置开？',
											confirmText: '确认',
											cancelText: '取消',
											success: res => {
												if (res.confirm) {
													uni.openSetting({
														success: res => {
															// console.log(res);
															self
																.getImg();

														}
													});
												} else {
													return false;
												}
											}
										});
										return false;
									}
								});
							}
						});
					}

				});

			},
			close2() {
				this.show2 = false
			},
			goDetail(nid){
				console.log("跳转店铺详情")
				uni.navigateTo({
					url: '../../index/index/shopHome?mid='+nid
				})
			},
		}
	}
</script>

<style lang="scss" scoped>
	.box {
		.share {
			position: fixed;
			top: 0;
			left: 0;
			width: 750rpx;
			height: 100vh;
			background: rgba(0, 0, 0, 0.4);

			.share_center {
				position: absolute;
				top: 30rpx;
				left: 127rpx;
				width: 500rpx;
				height: 781rpx;
				z-index: 9999;
			}


			.center {
				position: absolute;
				background-color: #fff;
				bottom: 400rpx;
				left: 127rpx;
				width: 500rpx;
				height: 681rpx;
				background: #FFFFFF;
				border-radius: 10rpx;

				.item1 {

					width: 100%;
					height: 130rpx;
					display: flex;
					align-items: center;
					justify-content: center;

					.img {
						width: 60rpx;
						height: 60rpx;
						margin-right: 30rpx;
					}
				}

				.item2 {
					width: 100%;
					height: 281rpx;
				}

				.item3 {
					width: 100%;
					height: 265rpx;
					padding-top: 27rpx;
					padding-left: 22rpx;
					display: flex;
					justify-content: flex-start;

					.left {
						.left1 {
							width: 275rpx;
							// height: 55rpx;
							font-size: 24rpx;
							font-family: PingFang SC;
							font-weight: 500;
							color: #333333;
						}

						.left2 {
							width: 278rpx;
							font-size: 26rpx;
							font-family: Source Han Sans CN;
							font-weight: 300;
							color: #999999;
							margin-top: 20rpx;
							margin-bottom: 30rpx;

						}

						.left3 {
							width: 72rpx;

							font-size: 28rpx;
							font-family: PingFang SC;
							font-weight: bold;
							color: #FF1C1C;
						}
					}

					.right {
						.right1 {
							width: 160rpx;
							height: 160rpx;
						}

						.right2 {

							font-size: 22rpx;
							font-family: Source Han Sans CN;
							font-weight: 300;
							color: #999999;
						}
					}
				}
			}

			.footer22 {
				position: absolute;
				bottom: 11rpx;
				left: 10rpx;
				background-color: #fff;
				width: 730rpx;
				height: 300rpx;
				background: #FFFFFF;
				border-radius: 10rpx;

				.item2 {
					margin-top: 35rpx;
					width: 690rpx;
					height: 80rpx;
					border: 2rpx solid #EEEEEE;
					border-radius: 10rpx;
					margin-left: 30rpx;
					display: flex;
					align-items: center;
					justify-content: center;

					.txt {

						font-size: 36rpx;
						font-family: PingFang SC;
						font-weight: 400;
						color: #333333;
					}
				}

				.item {
					margin-top: 40rpx;
					width: 100%;
					height: 125rpx;
					display: flex;
					justify-content: space-around;
					position: relative;

					.left {
						position: relative;

						.img {
							width: 80rpx;
							height: 80rpx;
							margin-bottom: 18rpx;
							margin-left: 15rpx;
						}

						.fx {
							width: 80rpx;
							height: 80rpx;
							position: absolute;
							top: 0;
							left: 14rpx;
							opacity: 0
						}

						.text {

							font-size: 26rpx;
							font-family: PingFang SC;
							font-weight: 400;
							color: #333333;
						}
					}

					.right {
						.img {
							margin-left: 15rpx;
							width: 80rpx;
							height: 80rpx;
							margin-bottom: 18rpx;
						}

						.text {

							font-size: 26rpx;
							font-family: PingFang SC;
							font-weight: 400;
							color: #333333;
						}
					}
				}
			}
		}

		.banner {
			width: 690rpx;
			margin-left: 30rpx;
			border-bottom: 1px solid #F5F5F5;

			.line-x {
				margin-top: 25rpx;
				display: flex;
				justify-content: flex-start;

				.left {
					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #999999;
				}

				.right {
					margin-left: 53rpx;
					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #333333;
				}
			}
		}

		.msg {
			width: 690rpx;
			margin-left: 30rpx;
			margin-top: 20rpx;
			border-bottom: 1px solid #F5F5F5;

			.sj {
				margin-top: 20rpx;
				margin-bottom: 28rpx;
				font-size: 26rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #999999;
			}

			.msg-t {
				display: flex;
				justify-content: flex-start;
				align-items: center;

				.img {
					width: 100rpx;
					height: 100rpx;
					border-radius: 10rpx;
				}

				.title {
					margin-left: 20rpx;
					width: 559rpx;
					font-size: 30rpx;
					font-family: PingFang SC;
					font-weight: 500;
					color: #333333;
					overflow: hidden;
					word-wrap: break-word;

					.tt {
						background: linear-gradient(0deg, #1777FF, #569CFF);
						border-radius: 4px;
						font-size: 20rpx;
						font-family: PingFang SC;
						font-weight: 400;
						color: #FFFFFF;
						float: left;
						line-height: 16px;
						padding: 0 4px;
						margin-right: 10rpx;
					}

				}
			}
		}

		.line {
			display: flex;
			justify-content: space-between;
			align-items: center;
			margin-left: 30rpx;

			.left {
				display: flex;
				justify-content: flex-start;
				align-items: center;

				.dot {
					width: 2px;
					height: 30rpx;
					background: #1777FF;
					border-radius: 2rpx;
				}

				text {
					font-size: 30rpx;
					font-family: PingFang SC;
					font-weight: 500;
					color: #333333;
				}
			}

			.right {
				display: flex;
				align-items: center;
				width: 120rpx;
				height: 50rpx;
				background: #F5F5F5;
				border-radius: 25rpx 0rpx 0rpx 25rpx;

				// margin-right: 23rpx;
				.img {
					width: 28rpx;
					height: 28rpx;
					margin-left: 22rpx;
				}

				text {

					font-size: 24rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #999999;
				}

			}
		}

		.line2 {
			display: flex;
			justify-content: space-between;
			align-items: center;
			margin: 30rpx 30rpx 20rpx;

			.left {
				display: flex;
				justify-content: flex-start;
				align-items: center;

				.dot {
					width: 2px;
					height: 30rpx;
					background: #1777FF;
					border-radius: 2rpx;
				}

				text {
					font-size: 30rpx;
					font-family: PingFang SC;
					font-weight: 500;
					color: #333333;
				}
			}
		}

		.text-show {
			// font-size: 26rpx;
			// color: #999999;
			// margin-left: 31rpx;ß
			// padding-bottom: 75rpx;
            
            margin-top: 20rpx;
            width: 690rpx;
            // height: 135rpx;
            font-size: 26rpx;
            font-family: PingFang SC;
            font-weight: 400;
            color: #999999;
            line-height: 36rpx;
            margin-left: 30rpx;
            border-bottom: 1px solid #F5F5F5;
            
            padding-bottom: 30rpx;
		}

		.header {
			padding: 30rpx;

			.card {
				height: 180rpx;
				display: flex;
				justify-content: flex-start;
				align-items: center;
				border: 1px solid #EEEEEE;
				border-radius: 10rpx;

				.left1 {
					width: 180rpx;
					height: 180rpx;
					border-radius: 10rpx;
					margin-left: 11rpx;
					overflow: hidden;

					image {
						width: 180rpx;
						height: 180rpx;
					}
				}

				.right1 {
					margin-left: 22rpx;
					width: 380rpx;
					height: 100%;
					display: flex;
					flex-direction: column;
					justify-content: space-evenly;

					.rline1 {
						font-size: 30rpx;
						display: flex;
						justify-content: space-between;
						white-space: nowrap;
						text-overflow: ellipsis;
						overflow: hidden;

						.img {
							width: 44rpx;
							height: 44rpx;

							border-radius: 50%;

						}
					}

					.rline2 {
						font-size: 24rpx;
						color: #666666;
						white-space: nowrap;
						text-overflow: ellipsis;
						overflow: hidden;
						word-break: break-all;

					}

					.rline3 {
						width: 500rpx;
						font-size: 24rpx;
						display: flex;
						align-items: center;

						image {
							width: 28rpx;
							height: 28rpx;
							margin-left: 1rpx;
						}
					}

					.rline4 {
						width: 500rpx;
						font-size: 24rpx;
						display: flex;
						align-items: center;

						.line-txt {
							margin-left: 10rpx;
							font-size: 24rpx;
							font-family: PingFang SC;
							font-weight: 400;
							color: #333333;
						}

						// padding-left: 5rpx;
						image {
							width: 20rpx;
							height: 27rpx;
							margin-left: 6rpx;
						}

						.refuse {
							display: flex;
							align-items: center;
							justify-content: center;

							font-size: 24rpx;
							font-family: PingFang SC;
							font-weight: 400;
							color: #FE5E5E;

							.fff {
								border-bottom: 1rpx solid #FFF;
							}

							.ml {
								margin-left: 10rpx;
								border-bottom: 1rpx solid #FE5E5E;
							}
						}
					}

				}
			}
		}
	}
</style>
