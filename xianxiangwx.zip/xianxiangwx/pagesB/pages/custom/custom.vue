<template>
	<view class="box">

		<view v-if="isLogin" style="margin-bottom: 70rpx;">

			<!-- 顶部tab 开始-->
			<view class="tuan">
				<view class="nav">
					<u-sticky>
						<div class="content-nav">

							<div class="nav-item" :class="{active: current=='1'}" @click="currentChange('1')">
								<text class="text">待审核</text>
							</div>
							<div class="nav-item" :class="{active: current=='2'}" @click="currentChange('2')">
								<text class="text">有效客户</text>
							</div>
							<div class="nav-item" :class="{active: current=='3'}" @click="currentChange('3')">
								<text class="text">无效客户 </text>
							</div>

							<div v-if="showDown" class="nav-down" @click="down()"> 下载</div>

						</div>

					</u-sticky>
				</view>
			</view>
			<!-- 顶部tab end -->
			<!-- 数据 start -->
			<view v-if="list.length==0" style="text-align: center;padding-top: 300rpx;">
				<image :src="cdnUrl+'XianxiangUapi/static/datanull.png'" alt="" style="width: 470rpx;height: 345rpx;">
				</image>
			</view>

			<view v-for="(item,index) in list" :key="index">
				<view class="data-list">
					<view class="left">
						<view class="name">{{item.name}}</view>
						<view class="content1">
							<view>{{item.phone}}</view>
							<image src="../../static/phoneblue.png" style="width: 32rpx;height: 32rpx;padding: 22rpx;" @click="callPhone('1888888888888')" />
						</view>
						<view class="content2">{{$time(item.add_time,0)}}  {{$time(item.add_time,3)}}</view>
					</view>

					<view class="right" @click="look(item.customer_index)">查看</view>
				</view>
			</view>
			<!-- 数据 end -->

		</view>

		<!-- 未登录显示 start -->
		<view v-else class="no-data">

			<image :src="cdnUrl+'XianxiangUapi/static/customer.png'" style="width: 354rpx;height: 354rpx;"></image>

			<view class="title">登录后才能查看客户信息</view>


			<view class="login" @click="Login()">立即登录</view>

		</view>
		<!-- 未登录显示 end -->

		<!-- 底部导航栏 start -->
		<view class="tabbar" v-if="show_footer">
			<image src="../../static/tabbarbgc.png" class="bgc"></image>
			<view class="box" v-show="tabbarAct==0" @click.stop="goTab(0)">
				<image src="../../static/tabbarSel1.png" class="img"></image>
				<view class="text" style="color: #1576FF;">
					首页
				</view>
			</view>
			<view class="box" v-show="tabbarAct!==0" @click.stop="goTab(0)">
				<image src="../../static/tabbar1.png" class="img"></image>
				<view class="text">
					首页
				</view>
			</view>

			<view class="box1" v-show="tabbarAct==1" @click.stop="goTab(1)">
				<image src="../../static/tabbarSel2.png" class="img"></image>
				<view class="text" style="color: #1576FF;">
					任务
				</view>
			</view>
			<view class="box1" v-show="tabbarAct!==1" @click.stop="goTab(1)">
				<image src="../../static/tabbar2.png" class="img"></image>
				<view class="text">
					任务
				</view>
			</view>
			<view class="box2" @click.stop="goTab(5)">
				<image src="../../static/backups.png" class="img"></image>
				<view class="text">
					发布
				</view>
			</view>

			<view class="box3" v-show="tabbarAct==2" @click.stop="goTab(2)">
				<image src="../../static/tabbarSel3.png" class="img"></image>
				<view class="text" style="color: #1576FF;">
					客户
				</view>
			</view>
			<view class="box3" v-show="tabbarAct!==2" @click.stop="goTab(2)">
				<image src="../../static/tabbar3.png" class="img"></image>
				<view class="text">
					客户
				</view>
			</view>

			<view class="box4" v-show="tabbarAct==3" @click.stop="goTab(3)">
				<image src="../../static/tabbarSel4.png" class="img"></image>
				<view class="text" style="color: #1576FF;">
					我的
				</view>
			</view>
			<view class="box4" v-show="tabbarAct!==3" @click.stop="goTab(3)">
				<image src="../../static/tabbar4.png" class="img"></image>
				<view class="text">
					我的
				</view>
			</view>
		</view>
		<view class="beijing" v-if="flage1" @click="isFlage">
			<view class="dw">
				<view class="m1" @click.stop="go(1)">
					<image src="../../static/m1.png" class="img"></image>
					<view class="text">
						发布拓客活动
					</view>
				</view>
				<view class="m2" @click.stop="go(2)" v-if="isSelf==true">
					<image src="../../static/m2.png" class="img"></image>
					<view class="text">
						发布拓客动态
					</view>
				</view>
				<view class="m3" @click.stop="go(3)">
					<image src="../../static/m3.png" class="img"></image>
					<view class="text">
						录入客户
					</view>
				</view>
			</view>
			
			
		</view>
		<view class="beijing2" v-if="flage2" @click="isFlage1">
			<view class="card">
				<view class="gray" @click.stop="this.flage2=true">
					<view class="text">
						请选择您要发布的动态类型：
					</view>
				</view>
				<view class="ngray" @click.stop="go2(1)">
					<view class="text">
						视频动态
					</view>
				</view>
				<view class="ngray" @click.stop="go2(2)">
					<view class="text">
						图片动态
					</view>
				</view>
			</view>
			<view class="btm" @click.stop="isFlage1">
				<view class="text">
					取消
				</view>
			</view>
		</view>
		<!-- 底部导航栏 end -->

		<!-- 下载弹窗 start -->
		<view class="window" v-if="see" @click="hitCopy">

			<view class="particulars">

				<view class="top">下载提示</view>
				<view class="show">https://test.jianyunkeji.net/XianxiangMapi/api.php?c=user_task/uploadCustomer&user_id={{user.user_id}}.</view>
				<view class="context">（请在电脑端浏览器内打开此链接下载数据）</view>
				<view class="copy" @click="copy()">复制链接</view>
			</view>

		</view>
		<!-- 下载弹窗 end -->

		<u-loadmore v-if="isLogin&&list.length!=0" :status="status" :load-text="loadText" @loadmore="clkloadMore" />
	</view>
</template>

<script>
	import indexListApi from "../../../api/index/indexList.js"
	import taskApi from "../../../api/product/product.js"
	export default {
		data() {
			return {
				isLogin: false,

				task_id: '',
				show_footer: true, //是否显示底部导航栏

				user: {},
				//激活的tab栏
				current: '1',
				//列表
				list: {},

				showDown: false, //是否显示下载按钮
				//客户id
				nid: "",
				//底部tab
				tabbarAct: 2,
				flage1: false, //发布按钮
				flage2: false,
				see: false, //下载弹窗是否显示
				cdnUrl: "",
				testUrl: "",
				page: 1,
				count: 10,
				status: 'loading',
				totalPage: 1,
				loadText: {
					loadmore: '上拉或点击加载更多',
					loading: '努力加载中',
					nomore: '没有更多了'
				},
				isSelf:false
			}
		},
		onLoad(e) {

			this.cdnUrl = this.$cdnUrl
			this.task_id = e.task_id;

			if (this.task_id) {
				this.show_footer = false;
			}

			

		},
		onShow() {
				if (uni.getStorageSync("xxytoken")) {
				
					this.isLogin = true;
				
					taskApi.referrer().then(res => {
						console.log(res)
						this.user = res.result
						if (res.status == 200) {
							if (res.result.rank == 7) {
								//团队长
								this.rank = "7"
								this.showDown = false;
								this.init()
							} else if (res.result.rank == 4) {
								//商户
								this.rank = "4"
								this.showDown = true;
								this.init()
							} else if (res.result.rank == 6) {
								//拓客员
								this.rank = "6"
								this.showDown = false;
								this.init()
							} else {
								this.list = ''
								this.status = "nomore"
								uni.showToast({
									title: "你没有该权限~",
									icon: "none"
								})
							}
						} else {
							this.list = ''
							this.status = "nomore"
							uni.showToast({
								title: res.message,
								icon: 'none'
							})
						}
					})
				} else {
					this.isLogin = false;
				}
		},
		methods: {
			//切换tab栏
			currentChange(e) {
				this.list = {}
				this.page = 1
				this.current = e
				this.init()
			},
			init() {
				if (this.task_id) {
					this.show_footer = false;
					taskApi.goods_list({
						type: this.current,
						page: this.page,
						count: this.count,
						task_id: this.task_id
					}).then(res => {
						console.log(res)

						if (res.status == 200) {
							if(res.result.status==1){
								this.isSelf=true
							}
							this.list = res.result.data
							this.totalPage = res.result.last_page

							if (this.totalPage > this.page) {
								this.status = "loadmore"
							}
							if (this.totalPage <= this.page) {
								this.status = "nomore"
							}



						} else {
							uni.showToast({
								title: res.message,
								icon: 'none'
							})
						}

						// this.status = 'loadmore'
					})
				} else {
					taskApi.goods_list({
						type: this.current,
						page: this.page,
						count: this.count
					}).then(res => {
						console.log(res)

						if (res.status == 200) {
							if(res.result.status==1){
								this.isSelf=true
							}
							this.list = res.result.data
							this.totalPage = res.result.last_page

							if (this.totalPage > this.page) {
								this.status = "loadmore"
							}
							if (this.totalPage <= this.page) {
								this.status = "nomore"
							}



						} else {
							uni.showToast({
								title: res.message,
								icon: 'none'
							})
						}

						// this.status = 'loadmore'
					})
				}

			},
			down() {
				console.log("下载")
				this.see = true
			},
			look(nid) {
				console.log("查看")
				this.page=1
				uni.navigateTo({
					url: './detail/detail?id=' + nid
				})
			},
			Login() {
				console.log("登录")
				
				
				uni.reLaunch({
					url: "/pages/welcome/welcome"
				})
			},
			//拨打电话
			callPhone(phone) {
				console.log("拨打电话")
				uni.makePhoneCall({
					phoneNumber: phone //仅为示例
				});
			},
			//tabbar
			isFlage1() {
				this.flage2 = false
			},
			go2(num) {
				if (num == 2) {
					uni.navigateTo({
						url: "../index/index/fabu"
					})
				}
				if (num == 1) {
					uni.navigateTo({
						url: "../index/index/fabu2"
					})
				}
			},
			goTab(num) {
				if (num == 5) {

					this.flage1 = true
				} else if (num == 0) {

					uni.reLaunch({
						url: "../index/index/index"
					})

				} else if (num == 1) {
					uni.reLaunch({
						url: "../task/task"
					})
				} else if (num == 2) {
					this.tabbarAct = 2
					// uni.reLaunch({
					// 	url: "../custom/custom"
					// })
				} else if (num == 3) {

					uni.reLaunch({
						url: "../../../pages/my/my/my"
					})
				}
			},
			//弹窗
			isFlage() {
				this.flage1 = false
			},
			hitCopy() {
				this.see = false
			},
			copy() {
				console.log("复制链接")
				let str ='https://test.jianyunkeji.net/XianxiangMapi/api.php?c=user_task/uploadCustomer&user_id='+this.user.user_id
				uni.setClipboardData({
					data: str, //要被复制的内容
					success: () => { //复制成功的回调函数
						uni.showToast({ //提示
							title: "复制成功"
						})
					}
				});
				this.hitCopy();
			},
			go(num) {
				//发布拓客活动
				if (num == 1) {
					if(!uni.getStorageSync("xxytoken")){
						uni.showToast({
							title: "你还没有登录",
							icon: 'none'
						})
						return
					}
					indexListApi.referrer().then(res => {
						console.log(res)

						if (res.status == 200) {
							if (res.result.rank == 7) {
								uni.navigateTo({
									url: "../index/index/fbhd"
								})
							} else if (res.result.rank == 4) {
								uni.navigateTo({
									url: "./fbhd2?ids=" + res.result.merchant_id
								})
							} else {
								uni.showToast({
									title: "你没有该权限~",
									icon: "none"
								})
							}
						} else {
							uni.showToast({
								title: res.message,
								icon: 'none'
							})
						}
					})
				}
				//发布拓客动态
				if (num == 2) {
					if(!uni.getStorageSync("xxytoken")){
						uni.showToast({
							title: "你还没有登录",
							icon: 'none'
						})
						return
					}
					indexListApi.referrer().then(res => {
						console.log(res)
						if (res.status == 200) {
							if (res.result.rank == 7 || res.result.rank == 6) {
								this.flage1 = false
								this.flage2 = true
							} else {
								uni.showToast({
									title: "你没有该权限~",
									icon: "none"
								})
							}
						} else {
							uni.showToast({
								title: res.message,
								icon: 'none'
							})
						}
					})
				}
				//录入客户
				if (num == 3) {
					taskApi.get_add_client().then(res => {
						console.log(res)
						this.flage1 = false
						if (res.status == 200) {
							uni.navigateTo({
								url: "../index/index/lrkh?taskid=" + res.result.task_id + "&supplier_id=" + res.result.supplier_id
							})
						} else {
							uni.showToast({
								title: res.message,
								icon: 'none'
							})
						}
					})
				}
			},

			clkloadMore() {
				this.reachBtm()
			},
			//下拉加载更多
			onReachBottom() {
				this.reachBtm()

			},
			reachBtm() {
				
				if (this.page < this.totalPage) {
					this.status = 'loading';
					this.page++;
					if (this.task_id) {
						this.show_footer = false;
						taskApi.goods_list({
								page: this.page,
								type: this.current,
								count: this.count,
								task_id: this.task_id
							})
							.then(res => {
								//如果有数据 重新赋值  如果没有 清空
								if (res.result) {
									if(res.result.status==1){
										this.isSelf=true
									}
									//最大页数
									this.totalPage = res.result.last_page
									this.list = this.list.concat(res.result.data)

									this.status = "loadmore"

								} else {
									this.status = "nomore"
								}

							})

					} else {
						taskApi.goods_list({

								page: this.page,
								type: this.current,
								count: this.count

							})
							.then(res => {
								//如果有数据 重新赋值  如果没有 清空
								if (res.result) {
									if(res.result.status==1){
										this.isSelf=true
									}
									//最大页数
									this.totalPage = res.result.last_page
									this.list = this.list.concat(res.result.data)

									this.status = "loadmore"

								} else {
									this.status = "nomore"
								}

							})
					}
					taskApi.goods_list({

							page: this.page,
							type: this.current,
							count: this.count

						})
						.then(res => {
							//如果有数据 重新赋值  如果没有 清空
							if (res.result) {
								if(res.result.status==1){
									this.isSelf=true
								}
								//最大页数
								this.totalPage = res.result.last_page
								this.list = this.list.concat(res.result.data)

								this.status = "loadmore"

							} else {
								this.status = "nomore"
							}

						})
				} else {
					this.status = "nomore"
				}


			},
		}
	}
</script>

<style lang="scss" scoped>
	.box {
		.tuan {
			border-bottom: solid 2rpx rgba(0, 0, 0, .06);
			padding-bottom: 2rpx;

			.nav {
				background-color: #fff;
				// margin-top: 20rpx;
				height: 70rpx;

				.content-nav {
					background-color: #fff;
					display: flex;
					justify-content: space-around;

					.nav-item {
						.text {
							width: 76rpx;
							height: 25rpx;
							font-size: 26rpx;
							font-family: PingFang SC;
							font-weight: 400;
							line-height: 66rpx;
						}
					}

					.active {
						border-bottom: 4rpx solid #4794FF;

						.text {
							color: #4794FF;
							font-weight: 500;
							font-size: 30rpx !important;
							line-height: 66rpx;
							font-family: PingFang SC;

							// height: 29rpx;

						}

						.icon {
							width: 0;
							height: 0;
							border-right: 5px solid transparent;
							border-left: 5px solid transparent;
							border-top: 5px solid #515151;


						}
					}

					.nav-down {
						height: 34rpx;
						background: #4794FF url('../../static/down_icon.png') no-repeat 22rpx 11rpx;
						background-size: 28rpx 28rpx;
						border-top-left-radius: 25rpx;
						border-bottom-left-radius: 25rpx;
						font-size: 24rpx;
						color: #FFFFFF;

						margin-right: -47rpx;
						margin-top: 11rpx;
						padding: 8rpx 18rpx 9rpx 54rpx;
					}
				}
			}
		}

		.data-list {
			margin-left: 29rpx;
			height: 160rpx;
			width: 100%;
			display: flex;
			justify-content: space-between;
			align-items: center;
			border-bottom: solid 2rpx rgba(0, 0, 0, .06);
			padding-bottom: 2rpx;

			.left {

				.name {
					color: #333333;
					font-size: 30rpx;
				}

				.content1 {
					height: 56rpx;
					display: flex;
					justify-content: flex-start;
					align-items: center;
					font-size: 26rpx;
					color: #999999;
				}

				.content2 {
					font-size: 24rpx;
					color: #999999;
				}

			}

			.right {
				color: #ffffff;
				font-size: 24rpx;
				background: #3798FF;
				padding: 13rpx 36rpx;
				border-radius: 10rpx;
				margin-right: 60rpx;
			}
		}

		.no-data {
			margin: 0 auto;
			text-align: center;
			padding-top: 144rpx;

			.title {
				color: #999999;
				font-size: 26rpx;
				margin-top: 21rpx;
			}

			.login {
				width: 220rpx;

				color: #ffffff;
				font-size: 30rpx;
				background: #3798FF;
				text-align: center;
				border-radius: 10rpx;
				padding: 15rpx 0rpx;
				margin: 109rpx auto 0rpx;
			}
		}

		.tabbar {
			// border-top: 1px solid #999999;
			position: fixed;
			left: 0;
			bottom: 0;
			// background-color: #FFF;
			height: 121rpx;
			width: 100%;
			display: flex;
			align-items: center;
			justify-content: space-around;
				z-index: 999;

			.bgc {
				position: absolute;
				left: 0;
				bottom: 0;
				height: 121rpx;
				width: 100%;
			}

			.img {
				height: 44rpx;
				width: 44rpx;
			}

			.text {
				width: 44rpx;
				height: 21rpx;
				font-size: 22rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #666666;
				// line-height: 66px;
			}

			.box {
				height: 75rpx;
				width: 44rpx;
				// position: relative;
				position: absolute;
				left: 80rpx;
				bottom: 10rpx;
			}

			.box1 {
				height: 75rpx;
				width: 44rpx;
				// position: relative;
				position: absolute;
				bottom: 10rpx;
				left: 215rpx;
			}

			.box3 {
				height: 75rpx;
				width: 44rpx;
				// position: relative;
				position: absolute;
				bottom: 10rpx;
				right: 215rpx;
			}

			.box4 {
				height: 75rpx;
				width: 44rpx;
				// position: relative;
				position: absolute;
				bottom: 10rpx;
				right: 80rpx;
			}

			.box2 {
				// height: 75rpx;
				// width: 44rpx;
				position: absolute;
				left: 340rpx;

				bottom: 16rpx;

				.img {
					height: 70rpx;
					width: 70rpx;
					position: absolute;
					left: 0rpx;

					bottom: 24rpx;
				}

				.text {
					margin-left: 12rpx;
				}
			}
		}

		.beijing {
			position: fixed;
			width: 100%;
			height: 100%;
			left: 0;
			top: 0;
			background-color: rgba(0, 0, 0, .5);
			z-index: 999;
			.dw{
				width: 100%;
				position: absolute;
				bottom: 200rpx;
				left: 0;
				display: flex;
				justify-content: space-around;
				align-items: center;
				.m1 {
					width: 185rpx;
					height: 136rpx;
					display: flex;
					justify-content: center;
					flex-wrap: wrap;
					
				
					.img {
						width: 100rpx;
						height: 100rpx;
				
						margin-bottom: 10rpx;
				
					}
				
					.text {
				
						font-size: 26rpx;
						font-family: PingFang SC;
						font-weight: 500;
						color: #FFFFFF;
					}
				}
				
				.m2 {
					width: 185rpx;
					height: 136rpx;
					display: flex;
					justify-content: center;
					flex-wrap: wrap;
					
				
					.img {
						width: 100rpx;
						height: 100rpx;
						margin-bottom: 10rpx;
					}
				
					.text {
				
						font-size: 26rpx;
						font-family: PingFang SC;
						font-weight: 500;
						color: #FFFFFF;
					}
				}
				
				.m3 {
					width: 154rpx;
					height: 136rpx;
					display: flex;
					justify-content: center;
					flex-wrap: wrap;
					
				
					.img {
						width: 100rpx;
						height: 100rpx;
						margin-bottom: 10rpx;
					}
				
					.text {
				
						font-size: 26rpx;
						font-family: PingFang SC;
						font-weight: 500;
						color: #FFFFFF;
					}
				}
			}
			

			// .img1{
			// 	width: 70rpx;
			// 	height: 70rpx;
			// 	position: absolute;
			// 	bottom: 70rpx;
			// 	left: 330rpx;
			// }
		}

		.window {
			position: fixed;
			left: 0;
			top: 0;
			width: 100%;
			height: 100%;
			background: rgba(0, 0, 0, 0.5);
			font-family: PingFang SC;
			font-weight: 400;
			z-index: 999;
		}

		.particulars {
			position: absolute;
			left: 50%;
			top: 50%;
			transform: translate(-50%, -50%);
			width: 560rpx;
			height: 400rpx;
			background: #FFFFFF;
			border-radius: 10rpx;
			box-sizing: border-box;
			z-index: 999;
			font-size: 30rpx;
			text-align: center;

			.top {
				margin-top: 31rpx;
			}

			.show {
				margin: 32rpx auto 0rpx;
				width: 80%;
				font-size: 28rpx;
				text-decoration: underline;
				color: #1159BC;
				word-wrap: break-word;
			}

			.context {
				font-size: 26rpx;
				color: #999999;
				margin-top: 26rpx;
			}

			.copy {
				padding: 20px 0px;
				width: 100%;
				border-top: 1px solid #f5f5f5;
				color: #4694FF;
				position: absolute;
				bottom: 0px
			}

		}
	}

	.beijing2 {
		position: fixed;
		width: 100%;
		height: 100%;
		left: 0;
		top: 0;
		background-color: rgba(0, 0, 0, .5);
		z-index: 999;

		.card {
			width: 690rpx;
			height: 270rpx;
			position: absolute;
			bottom: 138rpx;
			left: 30rpx;
			background-color: #FFF;
			border-radius: 10rpx;

			.gray {
				width: 100%;
				height: 90rpx;
				display: flex;
				justify-content: center;
				align-items: center;

				.text {

					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #999999;

				}
			}

			.ngray {
				width: 100%;
				height: 88rpx;
				border-top: 2rpx solid #F5F5F5;
				display: flex;
				justify-content: center;
				align-items: center;

				.text {

					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 400;

					color: #333333;

				}
			}
		}

		.btm {
			width: 690rpx;
			height: 90rpx;
			position: absolute;
			bottom: 28rpx;
			left: 30rpx;
			background-color: #FFF;
			border-radius: 10rpx;
			display: flex;
			justify-content: center;
			align-items: center;

			.text {

				font-size: 26rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #333333;
				// line-height: 36px;
			}
		}
	}
</style>
