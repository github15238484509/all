<template>
	<view class="box">

		<!-- 未登录显示 start -->
		<view v-if="isLogin" class="no-data">

			<image :src="cdnUrl+'XianxiangUapi/static/wdl.png'" style="width: 354rpx;height: 354rpx;"></image>

			<view class="title">登录后才能查看客户任务</view>


			<view class="login" @click="Login()">立即登录</view>

		</view>
		<view class="tuan">
			<view class="nav" v-if="rank==7">
				<u-sticky>
					<div class="content-nav">
						<div class="nav-item" :class="{active: current=='1'}" @click="currentChange('1')">
							<text class="text">发布的任务</text>
						</div>
						<div class="nav-item" :class="{active: current=='2'}" @click="currentChange('2')">
							<text class="text">待接单任务</text>
						</div>
						<div class="nav-item" :class="{active: current=='3'}" @click="currentChange('3')">
							<text class="text">我的任务 </text>
							<image v-show="!flage3" src="../../static/down1.png" style="width: 22rpx;height: 22rpx;">
							</image>
							<image v-show="flage3" src="../../static/up.png" style="width: 22rpx;height: 22rpx;">
							</image>
						</div>

					</div>
				</u-sticky>
			</view>
			<view class="nav" v-if="rank==6||rank==1">
				<u-sticky>
					<div class="content-nav">
						<div class="nav-item" :class="{active: current=='1'}" @click="currentChange('1')">
							<text class="text">可报名</text>
						</div>
						<div class="nav-item" :class="{active: current=='2'}" @click="currentChange('2')">
							<text class="text">报名中</text>
						</div>
						<div class="nav-item" :class="{active: current=='3'}" @click="currentChange('3')">
							<text class="text">已拒绝</text>							
						</div>
						<div class="nav-item" :class="{active: current=='4'}" @click="currentChange('4')">
							<text class="text">进行中</text>							
						</div>
						<div class="nav-item" :class="{active: current=='5'}" @click="currentChange('5')">
							<text class="text">已结束</text>							
						</div>
			
					</div>
				</u-sticky>
			</view>
			<view class="nav" v-if="rank==4">
				<u-sticky>
					<div class="content-nav">
						<div class="nav-item" :class="{active: current=='1'}" @click="currentChange('1')">
							<text class="text">发布的任务</text>
						</div>
						<div class="nav-item" :class="{active: current=='2'}" @click="currentChange('2')">
							<text class="text">待接单任务</text>
						</div>
						
			
					</div>
				</u-sticky>
			</view>
			<view v-if="list.length==0 && !isLogin" style="text-align: center;padding-top: 207rpx;">
				<image :src="cdnUrl+'XianxiangUapi/static/datanull.png'" alt="" style="width: 470rpx;height: 345rpx;">
				</image>
			</view>
		</view>
		<view class="xxxxxxxxx" style="margin-bottom: 30rpx;">
			<view class="uni-list-cell uni-list-cell-pd" v-for="(item,index) in list" :key="index" v-if="rank==7">
				<view class="cardd" @click="goInfo(item.task_id)">
			
					<view class="card-c" style="margin-left: 30rpx;">
						<view class="left1">
							<image :src="$imgUrl(item.picture)" mode="aspectFill"></image>
							<view class="txt">
								<text>{{item.status}}</text>
							</view>
						</view>
						<view class="right1">
							<view class="rline1">
								<view class="hhh">
									<text>{{item.scope_name}}</text>
			
								</view>
								<text
									style="margin-left: 10rpx;overflow: hidden;white-space: nowrap;text-overflow: ellipsis">{{item.name}}</text>
			
			
							</view>
							<view class="rline2">
								{{item.merchant_address}}
							</view>
							<view class="rline3">
			
								<text class="line-txt">预计:</text>
								<text class="line-txt1"
									style="margin-left: 10rpx;">￥{{item.anticipated?$returnFloat(item.anticipated):""}}元/人</text>
							</view>
							<view class="rline4">
								<text class="line-txt">{{$time(item.submit_time,0)}}</text>
								<text class="line-txt" style="margin-left: 10rpx;">{{$time(item.submit_time,3)}}</text>
							</view>
						</view>
			
						</image>
					</view>
				</view>
			</view>
			<view class="uni-list-cell uni-list-cell-pd" v-for="(item,index) in list" :key="index" v-if="rank==6||rank==1">
				<view class="cardd" @click="goInfo6(item.task_id)">
			
					<view class="card-c" style="margin-left: 30rpx;">
						<view class="left1">
							<image :src="$imgUrl(item.picture)" mode="aspectFill"></image>
							<view class="txt">
								<text>{{item.state}}</text>
							</view>
						</view>
						<view class="right1">
							<view class="rline1">
								<view class="hhh">
									<text>{{item.scope_name}}</text>
			
								</view>
								<text
									style="margin-left: 10rpx;overflow: hidden;white-space: nowrap;text-overflow: ellipsis">{{item.name}}</text>
			
			
							</view>
							<view class="rline2">
								{{item.merchant_address}}
							</view>
							<view class="rline3">
			
								<text class="line-txt">预计:</text>
								<text class="line-txt1"
									style="margin-left: 10rpx;">￥{{item.anticipated?$returnFloat(item.anticipated):""}}元/人</text>
							</view>
							<view class="rline4">
								<text class="line-txt">{{$time(item.submit_time,0)}}</text>
								<text class="line-txt" style="margin-left: 10rpx;">{{$time(item.submit_time,3)}}</text>
							</view>
						</view>
			
						</image>
					</view>
				</view>
			</view>
			<view class="uni-list-cell uni-list-cell-pd" v-for="(item,index) in list" :key="index" v-if="rank==4">
				<view class="cardd" @click="goInfo4(item.task_id)">
			
					<view class="card-c" style="margin-left: 30rpx;">
						<view class="left1">
							<image :src="$imgUrl(item.picture)" mode="aspectFill"></image>
							<view class="txt">
								<text>{{item.status}}</text>
							</view>
						</view>
						<view class="right1">
							<view class="rline1">
								<view class="hhh">
									<text>{{item.scope_name}}</text>
			
								</view>
								<text
									style="margin-left: 10rpx;overflow: hidden;white-space: nowrap;text-overflow: ellipsis">{{item.name}}</text>
			
			
							</view>
							<view class="rline2">
								{{item.merchant_address}}
							</view>
							<view class="rline3">
			
								<text class="line-txt">预计:</text>
								<text class="line-txt1"
									style="margin-left: 10rpx;">￥{{item.anticipated?$returnFloat(item.anticipated):""}}元/人</text>
							</view>
							<view class="rline4">
								<text class="line-txt">{{$time(item.submit_time,0)}}</text>
								<text class="line-txt" style="margin-left: 10rpx;">{{$time(item.submit_time,3)}}</text>
							</view>
						</view>
			
						</image>
					</view>
				</view>
			</view>
		</view>
		
		<view class="tabbar">
			<image src="../../static/tabbarbgc.png" class="bgc"></image>
			<view class="box" v-show="tabbarAct==0" @click.stop="goTab(0)">
				<image src="../../static/tabbarSel1.png" class="img"></image>
				<view class="text" style="color: #1576FF;">
					首页
				</view>
			</view>
			<view class="box" v-show="tabbarAct!==0" @click.stop="goTab(0)">
				<image src="../../static/tabbar1.png" class="img"></image>
				<view class="text">
					首页
				</view>
			</view>

			<view class="box1" v-show="tabbarAct==1" @click.stop="goTab(1)">
				<image src="../../static/tabbarSel2.png" class="img"></image>
				<view class="text" style="color: #1576FF;">
					任务
				</view>
			</view>
			<view class="box1" v-show="tabbarAct!==1" @click.stop="goTab(1)">
				<image src="../../static/tabbar2.png" class="img"></image>
				<view class="text">
					任务
				</view>
			</view>
			<view class="box2" @click.stop="goTab(5)">
				<image src="../../static/backups.png" class="img"></image>
				<view class="text">
					发布
				</view>
			</view>

			<view class="box3" v-show="tabbarAct==2" @click.stop="goTab(2)">
				<image src="../../static/tabbarSel3.png" class="img"></image>
				<view class="text" style="color: #1576FF;">
					客户
				</view>
			</view>
			<view class="box3" v-show="tabbarAct!==2" @click.stop="goTab(2)">
				<image src="../../static/tabbar3.png" class="img"></image>
				<view class="text">
					客户
				</view>
			</view>
			<view class="box4" v-show="tabbarAct==3" @click.stop="goTab(3)">
				<image src="../../static/tabbarSel4.png" class="img"></image>
				<view class="text" style="color: #1576FF;">
					我的
				</view>
			</view>
			<view class="box4" v-show="tabbarAct!==3" @click.stop="goTab(3)">
				<image src="../../static/tabbar4.png" class="img"></image>
				<view class="text">
					我的
				</view>
			</view>
		</view>
		<view class="beijing" v-if="flage1" @click="isFlage">
			<view class="dw">
				<view class="m1" @click.stop="go(1)">
					<image src="../../static/m1.png" class="img"></image>
					<view class="text">
						发布拓客活动
					</view>
				</view>
				<view class="m2" @click.stop="go(2)" v-if="isSelf==true">
					<image src="../../static/m2.png" class="img"></image>
					<view class="text">
						发布拓客动态
					</view>
				</view>
				<view class="m3" @click.stop="go(3)">
					<image src="../../static/m3.png" class="img"></image>
					<view class="text">
						录入客户
					</view>
				</view>
			</view>
			
			<!-- <image src="../../../static/m4.png" class="img1"></image> -->
		</view>
		<view class="beijing2" v-if="flage2" @click="isFlage1">
			<view class="card">
				<view class="gray" @click.stop="this.flage2=true">
					<view class="text">
						请选择您要发布的动态类型：
					</view>
				</view>
				<view class="ngray" @click.stop="go2(1)">
					<view class="text">
						视频动态
					</view>
				</view>
				<view class="ngray" @click.stop="go2(2)">
					<view class="text">
						图片动态
					</view>
				</view>
			</view>
			<view class="btm" @click.stop="isFlage1">
				<view class="text">
					取消
				</view>
			</view>
		</view>


		<view class="beijing3" v-if="flage3" @click="isFlage2">
			<!--  -->
			<view class="mask">
				<view class="item" :class="{active: topAct=='3'} " @click="currentChange2('3')">
					<text class="txt">我的任务（全部）</text>
				</view>
				<view class="item" style="margin-left: 30rpx;" :class="{active: topAct=='4'}"
					@click="currentChange2('4')">
					<text class="txt">报名中任务</text>
				</view>
				<view class="item" style="margin-left: 30rpx;" :class="{active: topAct=='5'}"
					@click="currentChange2('5')">
					<text class="txt">进行中任务</text>
				</view>
				<view class="item" :class="{active: topAct=='6'}" @click="currentChange2('6')">
					<text class="txt">已结束任务</text>
				</view>
			</view>

		</view>
		<u-loadmore v-if="list.length!=0 && !isLogin " :status="status" :load-text="loadText" @loadmore="clkloadMore" />
	</view>
</template>

<script>
	import indexListApi from "../../../api/index/indexList.js"
	import taskApi from "../../../api/task/task.js"
	import proApi from "../../../api/product/product.js"
	export default {
		data() {
			return {
				isLogin: false,
				rank: "",
				//顶部tab
				current: '1',
				//底部tab
				tabbarAct: 1,
				topAct: "3",
				flage3: false,
				flage2: false,
				flage1: false,
				//列表
				list: [],

				page: 1,
				count: 10,
				type: "1",

				status: 'loading',
				totalPage: 1,
				loadText: {
					loadmore: '上拉或点击加载更多',
					loading: '努力加载中',
					nomore: '没有更多了'
				},
				cdnUrl: "",
				isSelf:false
			}
		},
		onLoad() {

			this.cdnUrl = this.$cdnUrl
			if (uni.getStorageSync("xxytoken")) {
				taskApi.referrer().then(res => {
					console.log(res)
					if (res.status == 200) {
						this.rank = res.result.rank
						console.log(this.rank);
						this.init()
					} else {
						uni.showToast({
							title: res.message,
							icon: 'none'
						})
					}
				})
				
			} else {
				this.isLogin = true
			}


		},
		methods: {
			Login() {
				console.log("登录")
				uni.reLaunch({
					url: "/pages/welcome/welcome"
				})
			},
			goInfo(id) {
				// console.log(id);
				uni.navigateTo({
					url: "./taskInfo/taskInfo?id=" + id
				})
			},
			goInfo6(id) {
				console.log(id);
				uni.navigateTo({
					url: "./taskInfo6/taskInfo6?id=" + id
				})
			},
			goInfo4(id) {
				console.log(id);
				uni.navigateTo({
					url: "./taskInfo4/taskInfo4?id=" + id
				})
			},
			init() {
			
				if(this.rank==7||this.rank==4){
					console.log("团队长");
					taskApi.taskList({
						count: this.count,
						type: this.type,
						page: this.page
					}).then(res => {
						console.log(res)
						if (res.status == 200) {
					
							this.status = ""
							this.totalPage = res.result.last_page
							this.list = res.result.data
						} else {
							uni.showToast({
								title: res.message,
								icon: 'none'
							})
						}
					
					})
				}else if(this.rank==6||this.rank==1){
					console.log("拓客员");
					taskApi.tokerTaskList({
						count: this.count,
						type: this.type,
						page: this.page
					}).then(res => {
						console.log(res)
						if (res.status == 200) {
							if(res.result.status==1){
								this.isSelf=true
							}
							this.status = ""
							this.totalPage = res.result.last_page
							this.list = res.result.data
						} else {
							uni.showToast({
								title: res.message,
								icon: 'none'
							})
						}
					
					})
				}
				
				
			},
			currentChange2(e) {
				this.List = []
				this.page = 1
				this.topAct = e
				this.type = e
				this.init()
			},
			//切换tab栏
			currentChange(e) {
				if (e == '3') {
					if(this.rank==7){
						this.flage3 = !this.flage3
					}
					this.List = []
					this.page = 1
					this.current = e
					this.type = e
					this.init()
				} else {
					this.flage3 = false
					this.List = []
					this.page = 1
					this.current = e
					this.type = e
					this.init()
				}


			},
			//tabbar
			goTab(num) {
				if (num == 5) {

					this.flage1 = true
				} else if (num == 0) {

					uni.reLaunch({
						url: "../index/index/index"
					})

				} else if (num == 1) {
					this.tabbarAct = 1
					// uni.reLaunch({
					// 	url:"../../task/task"
					// })
				} else if (num == 2) {

					uni.reLaunch({
						url: "../custom/custom"
					})
				} else if (num == 3) {

					uni.reLaunch({
						url: "../../../pages/my/my/my"
					})
				}
			},
			//弹窗
			isFlage() {
				this.flage1 = false
			},
			isFlage1() {
				this.flage2 = false
			},
			isFlage2() {
				this.flage3 = false
			},
			clkloadMore() {
				this.reachBtm()
			},
			//下拉加载更多
			onReachBottom() {
				this.reachBtm()

			},
			reachBtm() {
				console.log(111);
				if (this.page < this.totalPage) {
					this.status = 'loading';
					this.page++;
					if(this.rank==7){
						taskApi.taskList({
						
								page: this.page,
								type: this.type,
								count: this.count
						
							})
							.then(res => {
								//如果有数据 重新赋值  如果没有 清空
								if (res.result) {
						
									//最大页数
									this.totalPage = res.result.last_page
									this.list = this.list.concat(res.result.data)
						
									this.status = "loadmore"
						
								} else {
									this.status = "nomore"
								}
						
							})
					}else if(this.rank==6){
						taskApi.tokerTaskList({
						
								page: this.page,
								type: this.type,
								count: this.count
						
							})
							.then(res => {
								//如果有数据 重新赋值  如果没有 清空
								if (res.result) {
									if(res.result.status==1){
										this.isSelf=true
									}
									//最大页数
									this.totalPage = res.result.last_page
									this.list = this.list.concat(res.result.data)
						
									this.status = "loadmore"
						
								} else {
									this.status = "nomore"
								}
						
							})
					}
					
				} else {
					this.status = "nomore"
				}


			},
			go(num) {
				//发布拓客活动
				if (num == 1) {
					if(!uni.getStorageSync("xxytoken")){
						uni.showToast({
							title: "你还没有登录",
							icon: 'none'
						})
						return
					}
					indexListApi.referrer().then(res => {
						console.log(res)
						if (res.status == 200) {
							if (res.result.rank == 7) {
								uni.navigateTo({
									url: "../index/index/fbhd"
								})
							} else if (res.result.rank == 4) {
								uni.navigateTo({
									url:"../index/index/fbhd2?ids="+res.result.merchant_id
								})
							} else {
								uni.showToast({
									title: "你没有该权限~",
									icon: "none"
								})
							}
						} else {
							uni.showToast({
								title: res.message,
								icon: 'none'
							})
						}
					})
				}
				//发布拓客动态
				if (num == 2) {
					if(!uni.getStorageSync("xxytoken")){
						uni.showToast({
							title: "你还没有登录",
							icon: 'none'
						})
						return
					}
					indexListApi.referrer().then(res => {
						console.log(res)
						if (res.status == 200) {
							if (res.result.rank == 7 || res.result.rank == 6) {
								this.flage1 = false
								this.flage2 = true
							} else {
								uni.showToast({
									title: "你没有该权限~",
									icon: "none"
								})
							}
						} else {
							uni.showToast({
								title: res.message,
								icon: 'none'
							})
						}
					})
				}
				//录入客户
				if (num == 3) {
					proApi.get_add_client().then(res => {
						console.log(res)
						this.flage1 = false
						if (res.status == 200) {
							uni.navigateTo({
								url: "../index/index/lrkh?taskid=" + res.result.task_id + "&supplier_id=" + res.result.supplier_id
							})
						} else {
							uni.showToast({
								title: res.message,
								icon: 'none'
							})
						}
					})
				}
			},
			go2(num) {
				if (num == 2) {
					uni.navigateTo({
						url: "../index/index/fabu"
					})
				}
				if (num == 1) {
					uni.navigateTo({
						url: "../index/index/fabu2"
					})
				}
			},
		}
	}
</script>

<style lang="scss" scoped>
	.box {
		.no-data {
			margin: 0 auto;
			text-align: center;
			padding-top: 144rpx;

			.title {
				color: #999999;
				font-size: 26rpx;
				margin-top: 21rpx;
			}

			.login {
				width: 220rpx;

				color: #ffffff;
				font-size: 30rpx;
				background: #3798FF;
				text-align: center;
				border-radius: 10rpx;
				padding: 15rpx 0rpx;
				margin: 109rpx auto 0rpx;
			}
		}

		.uni-list-cell.uni-list-cell-pd {
			width: 100%;
			height: 180rpx;

			.cardd {
				display: flex;
				justify-content: flex-start;
				align-items: center;
				margin-top: 30rpx;
				margin-bottom: 20rpx;

				.card-c {
					height: 180rpx;
					display: flex;
					justify-content: flex-start;
					align-items: center;

					.left1 {
						width: 180rpx;
						height: 180rpx;
						border-radius: 10rpx;
						margin-left: 11rpx;
						overflow: hidden;
						position: relative;

						image {
							width: 180rpx;
							height: 180rpx;
							position: absolute;
							left: 0;
							top: 0;
						}

						.txt {
							width: 180rpx;
							height: 30rpx;
							background: #000000;
							opacity: 0.5;
							border-radius: 0rpx 0rpx 10rpx 10rpx;
							display: flex;
							justify-content: center;
							align-items: center;
							position: absolute;
							left: 0;
							bottom: 0;


							font-size: 20rpx;
							font-family: PingFang SC;
							font-weight: 400;
							color: #FFFFFF;

						}
					}

					.right1 {
						margin-left: 22rpx;
						width: 380rpx;
						height: 100%;
						display: flex;
						flex-direction: column;
						justify-content: space-evenly;

						.rline1 {
							font-size: 30rpx;
							display: flex;
							justify-content: flex-start;
							align-items: center;

							.hhh {
								width: 95rpx;
								height: 26rpx;
								background: linear-gradient(32deg, #3699FF, #7CBDFF);
								border-radius: 4px;
								display: flex;
								justify-content: center;
								align-items: center;
								font-size: 20rpx;
								font-family: PingFang SC;
								font-weight: 400;
								color: #FFFFFF;
							}

							.img {
								width: 44rpx;
								height: 44rpx;

								border-radius: 50%;

							}
						}

						.rline2 {
							font-size: 24rpx;
							color: #666666;
							white-space: nowrap;
							text-overflow: ellipsis;
							overflow: hidden;
							word-break: break-all;

						}

						.rline3 {
							width: 500rpx;

							display: flex;
							align-items: center;

							.line-txt {
								width: 65rpx;

								font-size: 24rpx;
								font-family: PingFang SC;
								font-weight: 400;
								color: #FF3131;

							}

							.line-txt1 {


								font-size: 30rpx;
								font-family: PingFang SC;
								font-weight: 500;
								color: #FF3131;
								// line-height: 66px;
							}

							image {
								width: 28rpx;
								height: 28rpx;
								margin-left: 1rpx;
							}
						}

						.rline4 {
							width: 500rpx;
							font-size: 26rpx;
							display: flex;
							align-items: center;



							font-family: PingFang SC;
							font-weight: 400;
							color: #999999;

							// padding-left: 5rpx;
							image {
								width: 20rpx;
								height: 27rpx;
								margin-left: 6rpx;
							}

							.refuse {
								display: flex;
								align-items: center;
								justify-content: center;

								font-size: 24rpx;
								font-family: PingFang SC;
								font-weight: 400;
								color: #FE5E5E;

								.fff {
									border-bottom: 1rpx solid #FFF;
								}

								.ml {
									margin-left: 10rpx;
									border-bottom: 1rpx solid #FE5E5E;
								}
							}
						}

					}
				}
			}


		}

		.nav {
			background-color: #fff;
			// margin-top: 20rpx;
			height: 70rpx;

			.content-nav {
				background-color: #fff;
				display: flex;
				justify-content: space-around;

				.nav-item {
					.text {
						width: 76rpx;
						height: 25rpx;
						font-size: 26rpx;
						font-family: PingFang SC;
						font-weight: 400;
						line-height: 66rpx;
					}
				}

				.active {
					border-bottom: 4rpx solid #4794FF;

					.text {
						color: #4794FF;
						font-weight: 500;
						font-size: 30rpx !important;
						line-height: 66rpx;
						font-family: PingFang SC;

						// height: 29rpx;

					}

					.icon {
						width: 0;
						height: 0;
						border-right: 5px solid transparent;
						border-left: 5px solid transparent;
						border-top: 5px solid #515151;


					}
				}
			}
		}

		.tabbar {
			// border-top: 1px solid #999999;
			position: fixed;
			left: 0;
			bottom: 0;
			// background-color: #FFF;
			height: 121rpx;
			width: 100%;
			display: flex;
			align-items: center;
			justify-content: space-around;
			z-index: 999;
			.bgc {
				position: absolute;
				left: 0;
				bottom: 0;
				height: 121rpx;
				width: 100%;
			}

			.img {
				height: 44rpx;
				width: 44rpx;
			}

			.text {
				width: 44rpx;
				height: 21rpx;
				font-size: 22rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #666666;
				// line-height: 66px;
			}

			.box {
				height: 75rpx;
				width: 44rpx;
				// position: relative;
				position: absolute;
				left: 80rpx;
				bottom: 10rpx;
			}

			.box1 {
				height: 75rpx;
				width: 44rpx;
				// position: relative;
				position: absolute;
				bottom: 10rpx;
				left: 215rpx;
			}

			.box3 {
				height: 75rpx;
				width: 44rpx;
				// position: relative;
				position: absolute;
				bottom: 10rpx;
				right: 215rpx;
			}

			.box4 {
				height: 75rpx;
				width: 44rpx;
				// position: relative;
				position: absolute;
				bottom: 10rpx;
				right: 80rpx;
			}

			.box2 {
				// height: 75rpx;
				// width: 44rpx;
				position: absolute;
				left: 340rpx;

				bottom: 16rpx;

				.img {
					height: 70rpx;
					width: 70rpx;
					position: absolute;
					left: 0rpx;

					bottom: 24rpx;
				}

				.text {
					margin-left: 12rpx;
				}
			}
		}

		.beijing {
			position: fixed;
			width: 100%;
			height: 100%;
			left: 0;
			top: 0;
			background-color: rgba(0, 0, 0, .5);
			z-index: 999;
			.dw{
				width: 100%;
				position: absolute;
				bottom: 200rpx;
				left: 0;
				display: flex;
				justify-content: space-around;
				align-items: center;
				.m1 {
					width: 185rpx;
					height: 136rpx;
					display: flex;
					justify-content: center;
					flex-wrap: wrap;
					
				
					.img {
						width: 100rpx;
						height: 100rpx;
				
						margin-bottom: 10rpx;
				
					}
				
					.text {
				
						font-size: 26rpx;
						font-family: PingFang SC;
						font-weight: 500;
						color: #FFFFFF;
					}
				}
				
				.m2 {
					width: 185rpx;
					height: 136rpx;
					display: flex;
					justify-content: center;
					flex-wrap: wrap;
					
				
					.img {
						width: 100rpx;
						height: 100rpx;
						margin-bottom: 10rpx;
					}
				
					.text {
				
						font-size: 26rpx;
						font-family: PingFang SC;
						font-weight: 500;
						color: #FFFFFF;
					}
				}
				
				.m3 {
					width: 154rpx;
					height: 136rpx;
					display: flex;
					justify-content: center;
					flex-wrap: wrap;
					
				
					.img {
						width: 100rpx;
						height: 100rpx;
						margin-bottom: 10rpx;
					}
				
					.text {
				
						font-size: 26rpx;
						font-family: PingFang SC;
						font-weight: 500;
						color: #FFFFFF;
					}
				}
			}
			

			// .img1{
			// 	width: 70rpx;
			// 	height: 70rpx;
			// 	position: absolute;
			// 	bottom: 70rpx;
			// 	left: 330rpx;
			// }
		}

		.beijing2 {
			position: fixed;
			width: 100%;
			height: 100%;
			left: 0;
			top: 0;
			background-color: rgba(0, 0, 0, .5);
			z-index: 999;

			.card {
				width: 690rpx;
				height: 270rpx;
				position: absolute;
				bottom: 138rpx;
				left: 30rpx;
				background-color: #FFF;
				border-radius: 10rpx;

				.gray {
					width: 100%;
					height: 90rpx;
					display: flex;
					justify-content: center;
					align-items: center;

					.text {

						font-size: 26rpx;
						font-family: PingFang SC;
						font-weight: 400;
						color: #999999;

					}
				}

				.ngray {
					width: 100%;
					height: 88rpx;
					border-top: 2rpx solid #F5F5F5;
					display: flex;
					justify-content: center;
					align-items: center;

					.text {

						font-size: 26rpx;
						font-family: PingFang SC;
						font-weight: 400;

						color: #333333;

					}
				}
			}

			.btm {
				width: 690rpx;
				height: 90rpx;
				position: absolute;
				bottom: 28rpx;
				left: 30rpx;
				background-color: #FFF;
				border-radius: 10rpx;
				display: flex;
				justify-content: center;
				align-items: center;

				.text {

					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #333333;
					// line-height: 36px;
				}
			}
		}

		.beijing3 {
			position: fixed;
			width: 100%;
			height: 100%;
			left: 0;
			top: 70rpx;
			background-color: rgba(0, 0, 0, .5);
			z-index: 999;

			.mask {
				position: absolute;
				top: 0;
				left: 0;
				background-color: #FFF;
				width: 100%;
				height: 260rpx;
				border-radius: 0rpx 0rpx 10rpx 10rpx;
				padding: 30rpx;
				display: flex;
				justify-content: flex-start;
				flex-wrap: wrap;

				.item {
					width: 210rpx;
					height: 70rpx;
					background: #EEEEEE;
					border-radius: 4px;
					display: flex;
					justify-content: center;
					align-items: center;

					.txt {

						font-size: 26rpx;
						font-family: PingFang SC;
						font-weight: 400;
						color: #999999;

					}
				}

				.active {

					background: #EEF5FF;
					border: 1px solid #1777FF;

					.txt {
						color: #1777FF;
					}
				}
			}
		}

		.11111 {
			z-index: 999;
		}
	}
</style>
