<template>
	<view class="box">
		<view class="tuan">
			<view class="nav">
				<u-sticky>
					<div class="content-nav">
						<div class="nav-item" :class="{active: current=='1'}" @click="currentChange('1')">
							<text class="text">待审核</text>
						</div>
						<div class="nav-item" :class="{active: current=='2'}" @click="currentChange('2')">
							<text class="text">审核通过</text>
						</div>
						<div class="nav-item" :class="{active: current=='3'}" @click="currentChange('3')">
							<text class="text">审核拒绝 </text>
						</div>

					</div>
				</u-sticky>
			</view>
		</view>
		<view class="data-list" v-for="(item,index) in list" :key="index" v-if="list.length>0">
			<view class="left">
				<view class="left-l">
					<image :src="$imgUrl(item.photo)" class="img"></image>
				</view>
				<view class="left-r" style="margin-left: 20rpx;">
					<view class="name">{{item.user_name}}</view>
					<view class="content1">
						<view>{{item.phone}}</view>
						<image src="../../../../../static/phoneblue.png"
							style="width: 32rpx;height: 32rpx;padding: 22rpx;" @click="callPhone(item.phone)" />
					</view>
					<view class="content2">{{item.submit_time?$time(item.submit_time,0):""}} {{item.submit_time?$time(item.submit_time,3):""}}</view>
				</view>

			</view>
			<view class="right1" v-if="isLook=='4'" >查看</view>
			<view class="right" v-if="isLook!=='4'" @click="look(item.user_id)">查看</view>
		</view>
		<view v-if="list.length==0" style="text-align: center;padding-top: 300rpx;">
				<image :src="cdnUrl+'XianxiangUapi/static/datanull.png'" alt="" style="width: 470rpx;height: 345rpx;">
				</image>
			</view>
		<u-loadmore v-if="list.length!=0" :status="status" :load-text="loadText" @loadmore="clkloadMore" />
	</view>
</template>

<script>
	import taskApi from "../../../../../api/task/task.js"
	export default {
		data() {
			return {
				id: "",
				//顶部tab
				current: '1',
				//列表
				list: [],
				page: 1,
				count: 10,
				type: "1",

				status: 'loading',
				totalPage: 1,
				loadText: {
					loadmore: '上拉或点击加载更多',
					loading: '努力加载中',
					nomore: '没有更多了'
				},
				cdnUrl:"",
				isLook:""
			}
		},
		onLoad(e) {
			
			this.id = e.id
			 this.cdnUrl = this.$cdnUrl
			 this.isLook=e.status
			this.init()
		},
		methods: {
			//拨打电话
			callPhone(phone) {
				console.log("拨打电话")
				uni.makePhoneCall({
					phoneNumber: phone //仅为示例
				});
			},

			look(userId) {
				uni.navigateTo({
					url:"./tkInfo/tkInfo?user_id="+userId+"&&task_id="+this.id
				})
				
			},
			init() {
				taskApi.checkApply({
					count: this.count,
					type: this.type,
					page: this.page,
					task_id: this.id
				}).then(res => {
					console.log(res)
					if (res.status == 200) {
						this.status = ""
						this.totalPage = res.result.last_page
						this.list = res.result.data
					} else {
						uni.showToast({
							title: res.message,
							icon: 'none'
						})
					}
				})
			},
			//切换tab栏
			currentChange(e) {
				this.List = []
				this.page = 1
				this.current = e
				this.type = e
				this.init()
			},
			clkloadMore() {
				this.reachBtm()
			},
			//下拉加载更多
			onReachBottom() {
				this.reachBtm()

			},
			reachBtm() {
				console.log(111);
				if (this.page < this.totalPage) {
					this.status = 'loading';
					this.page++;
					taskApi.checkApply({
							page: this.page,
							type: this.type,
							count: this.count,
							task_id: this.id
						})
						.then(res => {
							//如果有数据 重新赋值  如果没有 清空
							if (res.result) {

								//最大页数
								this.totalPage = res.result.last_page
								this.list = this.list.concat(res.result.data)

								this.status = "loadmore"

							} else {
								this.status = "nomore"
							}

						})
				} else {
					this.status = "nomore"
				}


			},
		}
	}
</script>

<style lang="scss" scoped>
	.box {
		.nav {
			background-color: #fff;
			// margin-top: 20rpx;
			height: 70rpx;

			.content-nav {
				background-color: #fff;
				display: flex;
				justify-content: space-around;

				.nav-item {
					.text {
						width: 76rpx;
						height: 25rpx;
						font-size: 26rpx;
						font-family: PingFang SC;
						font-weight: 400;
						line-height: 66rpx;
					}
				}

				.active {
					border-bottom: 4rpx solid #4794FF;

					.text {
						color: #4794FF;
						font-weight: 500;
						font-size: 30rpx !important;
						line-height: 66rpx;
						font-family: PingFang SC;

						// height: 29rpx;

					}

					.icon {
						width: 0;
						height: 0;
						border-right: 5px solid transparent;
						border-left: 5px solid transparent;
						border-top: 5px solid #515151;


					}
				}
			}
		}

		.data-list {
			margin-left: 29rpx;
			height: 160rpx;
			width: 100%;
			display: flex;
			justify-content: space-between;
			align-items: center;
			border-bottom: solid 2rpx rgba(0, 0, 0, .06);
			padding-bottom: 2rpx;

			.left {
				display: flex;
				justify-content: flex-start;

				.left-l {
					display: flex;
					justify-content: center;
					align-items: center;

					.img {
						width: 80rpx;
						height: 80rpx;
						border-radius: 50%;
					}
				}

				.name {
					color: #333333;
					font-size: 30rpx;
				}

				.content1 {
					height: 56rpx;
					display: flex;
					justify-content: flex-start;
					align-items: center;
					font-size: 26rpx;
					color: #999999;
				}

				.content2 {
					font-size: 24rpx;
					color: #999999;
				}

			}

			.right {
				color: #ffffff;
				font-size: 24rpx;
				background: #3798FF;
				padding: 13rpx 36rpx;
				border-radius: 10rpx;
				margin-right: 60rpx;
			}
			.right1{
				color: #999999;
				font-size: 24rpx;
				padding: 13rpx 36rpx;
				background: #EEEEEE;
				border-radius: 10rpx;
				margin-right: 60rpx;
			}
		}
	}
</style>
