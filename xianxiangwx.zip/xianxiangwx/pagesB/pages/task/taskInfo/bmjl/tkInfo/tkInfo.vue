<template>
	<view class="box">
		<view class="data-list">
			<view class="left">
				<view class="left-l">
					<image v-if="item.photo" :src="$imgUrl(item.photo)" class="img" ></image>
					<image v-else src="../../../../../static/user-blue.png" class="img"></image>
				</view>
				<view class="left-r" style="margin-left: 20rpx;">
					<view class="name">{{item.user_name||""}}</view>
					<view class="content1">
						<view>{{item.user_phone||""}}</view>

					</view>
					<view class="content2">{{item.submit_time?$time(item.submit_time,0):""}}
						{{item.submit_time?$time(item.submit_time,3):""}}
					</view>
				</view>

			</view>

			<view class="right" v-if="item.audit_status=='1'">待审核</view>
			<view class="right" v-if="item.audit_status=='2'">审核通过</view>
			<view class="right" v-if="item.audit_status=='3'" style="color:#FF4545;">审核失败</view>
		</view>
		<view class="banner">
			<view class="line-x">
				<view class="left">
					姓 名
				</view>
				<view class="right" style="margin-left: 100rpx;">
					{{item.real_name||""}}
				</view>
			</view>
			<view class="line-x">
				<view class="left">
					联系电话
				</view>
				<view class="right">
					{{item.user_phone||""}}
				</view>
				<image src="../../../../../static/phoneblue.png" style="width: 32rpx;height: 32rpx;margin-left: 24rpx;"
					@click="callPhone(item.user_phone)" />
			</view>
			<view class="line-x">
				<view class="left">
					性 别
				</view>
				<view class="right" style="margin-left: 100rpx;">
					{{item.sex||""}}
				</view>
			</view>
			<!-- <view class="line-x">
				<view class="left">
					客户年龄
				</view>
				<view class="right">
					{{item.age?item.age:""}}
				</view>
			</view>
			<view class="line-x">
				<view class="left">
					客户性别
				</view>
				<view class="right">
					{{item.sex?item.sex:""}}
				</view>
			</view> -->
			<view class="line-x">
				<view class="left">
					累计提交
				</view>
				<view class="right" style="color: #4894FC;">
					{{item.valid_people?item.valid_people:""}}
				</view>
			</view>
			<view class="line-x">
				<view class="left">
					无效信息
				</view>
				<view class="right" style="color: #FF4545;">
					{{item.invalid_people?item.invalid_people:"0"}}
				</view>
			</view>
			<view class="line-x">
				<view class="left">
					联系地址
				</view>
				<view class="right">
					{{item.connection_address?item.connection_address:""}}
				</view>
			</view>
			<view class="line-x" style="margin-bottom: 30rpx;">
				<view class="left">
					详细地址
				</view>
				<view class="right">
					{{item.address?item.address:""}}
				</view>
			</view>
		</view>
		<view class="banner2" v-if="item.audit_status=='3'||item.audit_status=='2'">
			<view class="line-x" style="margin-bottom: 30rpx;">
				<view class="left">
					审核时间
				</view>
				<view class="right">
					{{item.audit_time?$time(item.audit_time,0):""}}   {{item.audit_time?$time(item.audit_time,3):""}}
				</view>
			</view>
			<view class="line-x" style="margin-bottom: 30rpx;" v-if="item.audit_status=='3'">
				<view class="left">
					拒绝原因
				</view>
				<view class="right">
					{{item.reject_reason?item.reject_reason:""}}
				</view>
			</view>
		</view>
		<view class="line" style="margin-top: 30rpx;" v-if="item.audit_status=='2'">
			<view class="left">
				<view class="dot">
		
				</view>
				<text style="margin-left: 10rpx;">拓客数据</text>
		
			</view>
			<view class="right" @click="goLook">
				<text>查看详细数据>></text>
			</view>
		</view>
		<view class="boxxx" style="margin-top: 20rpx;" v-if="item.audit_status=='2'">
			<view class="b-item" style="margin-left: 18rpx;">
				<view class="item-t">
					{{item.task_money?$returnFloat1(item.task_money):"0"}}
				</view>
				<view class="item-b">
					拓客费(元)
				</view>
			</view>
			<view class="b-item" style="margin-left: 120rpx;">
				<view class="item-t">
					{{item.experience_money?$returnFloat1(item.experience_money):"0"}}
				</view>
				<view class="item-b">
					体验课费用(元)
				</view>
			</view>
			<view class="b-item" style="margin-left: 100rpx;">
				<view class="item-t">
					{{item.customer_number||"0"}}
				</view>
				<view class="item-b">
					有效客户(人)
				</view>
			</view>
		</view>
		<view class="ttttt" style="margin-top: 20rpx;" v-if="item.audit_status=='2'">
			本次任务共获得：{{item.total_money?$returnFloat1(item.total_money):"0"}}元
		</view>
		<view class="footer" v-if="item.audit_status=='1'">
			<view class="footer-c">
				<view class="bc" @click="flage=true">
					<view class="txt">
						审核拒绝
					</view>
				</view>
				<view class="bbc">
					<view class="txt" @click="yes">
						审核通过
					</view>
				</view>
			</view>

		</view>
		<view class="beijing" v-if="flage" @click.self="isFlage">
			<view class="m1">
				<view class="t1">
					请输入拒绝原因
				</view>
				<textarea @click.stop="no222" class="theTextarea" v-model="reject_reason" value="" maxlength="200" placeholder="请输入拒绝原因"
					placeholder-style="font-size:24rpx;color:#999999" />
				<view class="ft">

					<view class="ftr" @click.stop="no">
						<view class="ftx">
							确定
						</view>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import taskApi from "../../../../../../api/task/task.js"
	export default {
		data() {
			return {
				user_id: "",
				task_id: "",
				item: {},
				reject_reason: "",
				flage: false
			};
		},
		onLoad(e) {
			this.user_id = e.user_id
			this.task_id = e.task_id
			taskApi.tokerDetail({
				user_id: this.user_id,
				task_id: this.task_id
			}).then(res => {
				console.log(res)
				if (res.status == 200) {
					this.item = res.result
				} else {
					uni.showToast({
						title: res.message,
						icon: 'none'
					})
				}
			})
		},
		methods: {
			goLook(){
				uni.navigateTo({
					url:"./tksr/tksr?task_id="+this.task_id
				})
			},
			isFlage() {
				this.flage = false
			},
			//拨打电话
			callPhone(phone) {
				console.log("拨打电话")
				uni.makePhoneCall({
					phoneNumber: phone //仅为示例
				});
			},
			no222(){
				
			},
			no() {
                
                if (this.reject_reason.length<=0) {
                    
                    uni.showToast({
                    	title: '请输入拒绝原因',
                    	icon: 'none'
                    })
                    return;
                }
                
				this.flage1 = false
				taskApi.auditToker({
					user_id: this.user_id,
					task_id: this.task_id,
					status: "3",
					reason: this.reject_reason
				}).then(res => {
					console.log(res)
					if (res.status == 200) {
						uni.navigateTo({
							url: "../bmjl?id=" + this.task_id
						})
					} else {
						uni.showToast({
							title: res.message,
							icon: 'none'
						})
					}
				})
				
			},
			yes() {
                let this_ = this
                uni.showModal({
                	title: "提示",
                	content: "是否确定审核通过",
                	confirmText: "确定",
                	confirmColor: '#3898FF',
                	cancelColor: '#999999',
                	success: (res) => {
                		// console.log(id)
                		if (res.confirm) {
                			taskApi.auditToker({
                				user_id: this_.user_id,
                				task_id: this_.task_id,
                				status: "2"
                			
                			}).then(res => {
                				console.log(res)
                				if (res.status == 200) {
                					uni.reLaunch({
                						url: "../bmjl?id=" + this_.task_id
                					})
                				} else {
                					uni.showToast({
                						title: res.message,
                						icon: 'none'
                					})
                				}
                			})
                		}
                
                	}
                })
                
				
			}
		}

	}
</script>

<style lang="scss" scoped>
	.box {
		.footer {
			position: fixed;
			left: 0;
			bottom: 0;
			width: 100%;
			height: 100rpx;
			background: #FFFFFF;
			box-shadow: 0px -2px 2px 0px rgba(0, 0, 0, 0.08);
			display: flex;
			// justify-content: center;
			align-items: center;

			.footer-c {
				height: 70rpx;
				display: flex;
				justify-content: flex-start;
				margin-left: 30rpx;

				.bc {
					width: 330rpx;
					height: 70rpx;
					background: #FFFFFF;
					border: 1px solid #1777FF;
					border-radius: 10rpx;
					display: flex;
					justify-content: center;
					align-items: center;

					.txt {

						font-size: 26rpx;
						font-family: PingFang SC;
						font-weight: 500;
						color: #3798FF;
					}
				}

				.bbc {
					width: 330rpx;
					height: 70rpx;
					background: #3798FF;
					border-radius: 10rpx;
					display: flex;
					justify-content: center;
					align-items: center;
					margin-left: 30rpx;

					.txt {

						font-size: 26rpx;
						font-family: PingFang SC;
						font-weight: 500;
						color: #FFFFFF;
					}
				}
			}
		}

		.beijing {
			position: fixed;
			width: 100%;
			height: 100%;
			left: 0;
			top: 0;
			background-color: rgba(0, 0, 0, .5);
			z-index: 999;

			.m1 {
				width: 500rpx;
				height: 350rpx;

				position: absolute;
				top: 360rpx;
				left: 125rpx;
				background-color: #FFFFFF;
				border-radius: 10rpx;

				.theTextarea {
					width: 420rpx;
					height: 155rpx;
					margin-top: 22rpx;
					margin-left: 20rpx;
					border-radius: 10rpx;
					background: #F5F5F5;
					border: 1px solid #CCCCCC;
					padding: 20rpx;
					font-size:24rpx;
				}

				.t1 {
					margin: 0 auto;
					margin-left: 146rpx;
					height: 28rpx;
					font-size: 30rpx;
					font-family: PingFang SC;
					font-weight: 500;
					color: #333333;
					margin-top: 30rpx;
				}

				.t2 {
					margin: 0 auto;
					width: 290rpx;
					height: 25rpx;
					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #999999;
					margin-top: 50rpx;
				}

				.ft {
					width: 100%;
					height: 89rpx;
					position: absolute;
					bottom: 0;
					left: 0;
					border-top: 1px solid #F5F5F5;
					display: flex;

					justify-content: flex-start;

					.ftl {
						display: flex;
						align-items: center;
						justify-content: center;
						width: 50%;
						height: 100%;
						border-right: 1px solid #F5F5F5;

						font-size: 30rpx;
						font-family: PingFang SC;
						font-weight: 400;
						color: #999999;
					}

					.ftr {
						display: flex;
						align-items: center;
						justify-content: center;
						width: 100%;
						height: 100%;

						font-size: 30rpx;
						font-family: PingFang SC;
						font-weight: 500;
						color: #3898FF;
					}
				}
			}
		}
		.ttttt{
			margin-left: 30rpx;
			font-size: 26rpx;
			font-family: PingFang SC;
			font-weight: 400;
			color: #333333;
		}
		.boxxx{
			width: 690rpx;
			height: 160rpx;
			background: #F5F5F5;
			border-radius: 10rpx;
			margin-left: 30rpx;
			font-size: 30rpx;
			font-family: PingFang SC;
			font-weight: 500;
			color: #333333;
			display: flex;
			justify-content: flex-start;
			align-items: center;
			.b-item{
				
			
			// margin-top: 45rpx;
			// margin-bottom: 40rpx;
				.item-b{
					font-size: 26rpx;
					margin-top: 25rpx;
				}
				.item-t{
					text-align: center;
				}
			}
		}
		.line {
			display: flex;
			justify-content: space-between;
			align-items: center;
			margin-left: 30rpx;
		
			.left {
				display: flex;
				justify-content: flex-start;
				align-items: center;
		
				.dot {
					width: 2px;
					height: 30rpx;
					background: #1777FF;
					border-radius: 2rpx;
				}
		
				text {
		
		
					font-size: 30rpx;
					font-family: PingFang SC;
					font-weight: 500;
					color: #333333;
				}
			}
		
			.right {
				display: flex;
				align-items: center;
				// width: 120rpx;
				// height: 50rpx;
				// background: #F5F5F5;
				// border-radius: 25rpx 0rpx 0rpx 25rpx;
		
				// margin-right: 23rpx;
				.img {
					width: 28rpx;
					height: 28rpx;
					margin-left: 22rpx;
				}
		
				text {
		
					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #999999;
					margin-right: 30rpx;
				}
		
			}
		}
		.banner2{
			width: 690rpx;
			margin-left: 30rpx;
			border-bottom: 1px solid #F5F5F5;
			.line-x {
				margin-top: 25rpx;
				display: flex;
				justify-content: flex-start;
			
				.left {
					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #999999;
				}
			
				.right {
					margin-left: 53rpx;
					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #333333;
				}
			}
		}
		.banner {
			width: 690rpx;
			margin-left: 30rpx;
			border-bottom: 1px solid #F5F5F5;

			.line-x {
				margin-top: 25rpx;
				display: flex;
				justify-content: flex-start;

				.left {
					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #999999;
				}

				.right {
					margin-left: 53rpx;
					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #333333;
				}
			}
		}

		.data-list {
			margin-left: 29rpx;
			height: 160rpx;
			width: 100%;
			display: flex;
			justify-content: flex-start;
			align-items: center;
			border-bottom: solid 2rpx rgba(0, 0, 0, .06);
			padding-bottom: 2rpx;

			.left {
				display: flex;
				justify-content: flex-start;

				.left-l {
					display: flex;
					justify-content: center;
					align-items: center;

					.img {
						width: 80rpx;
						height: 80rpx;
						border-radius: 50%;
					}
				}

				.name {
					color: #333333;
					font-size: 30rpx;
				}

				.content1 {
					height: 56rpx;
					display: flex;
					justify-content: flex-start;
					align-items: center;
					font-size: 26rpx;
					color: #999999;
				}

				.content2 {
					font-size: 24rpx;
					color: #999999;
				}

			}

			.right {
				margin-left: 260rpx;
				margin-bottom: 60rpx;
				font-size: 26rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: #3798FF;

			}
		}
	}
</style>
