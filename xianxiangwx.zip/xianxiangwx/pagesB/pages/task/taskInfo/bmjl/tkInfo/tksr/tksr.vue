<template>
	<view class="box">
		<image :src="cdnUrl+'XianxiangUapi/static/datanull.png'" v-if="list.length=='0'" style="margin-left:150rpx;width: 450rpx;height: 320rpx;margin-top: 300rpx;"></image>
		<view class="data-list" v-for="(item,index) in list" :key="index" v-if="list.length>0">
			<view class="left">
				
				<view class="left-r" style="margin-left: 20rpx;">
					<view class="name">{{item.name}}</view>
					<view class="content1">
						<view>{{item.phone}}</view>
						<image src="../../../../../../static/phoneblue.png"
							style="width: 32rpx;height: 32rpx;padding: 22rpx;" @click="callPhone(item.phone)" />
					</view>
					<view class="content2">{{item.add_time?$time(item.add_time,0):""}} {{item.add_time?$time(item.add_time,3):""}}</view>
				</view>
		
			</view>
		
			<view class="right" >
				<view class="" style="margin-bottom: 15rpx;">
					拓客费：{{item.single_amount?$returnFloat(item.single_amount):"0.00"}}元
				</view>
				<view class="">
					体验课费用：{{item.experience_amount?$returnFloat(item.experience_amount):"0.00"}}元
				</view>
			</view>
		</view>
		<u-loadmore v-if="list.length!='0'" :status="status" :load-text="loadText" @loadmore="clkloadMore" />
	</view>
</template>

<script>
	import taskApi from "../../../../../../../api/task/task.js"
	export default {
		data() {
			return {
				task_id:"",
				list:[],
				page: 1,
				count: 10,
				type: "1",
				cdnUrl:"",
				status: 'loading',
				totalPage: 1,
				loadText: {
					loadmore: '上拉或点击加载更多',
					loading: '努力加载中',
					nomore: '没有更多了'
				},
			};
		},
		onLoad(e) {
			this.cdnUrl=this.$cdnUrl
			this.task_id=e.task_id
			this.init()
		},
		methods:{
			init(){
				taskApi.checkCustomer({
					page: this.page,
					
					count: this.count,
					task_id:this.task_id
				}).then(res => {
				        console.log(res)
				        if (res.status == 200) {
							
							this.status = ""
							this.totalPage = res.result.last_page
							this.list = res.result.data
				        } else {
				                uni.showToast({
				                title: res.message,
				                icon: 'none'
				                })
				        }
				})
			},
			clkloadMore() {
				this.reachBtm()
			},
			//下拉加载更多
			onReachBottom() {
				this.reachBtm()
			
			},
			reachBtm() {
				console.log(111);
				if (this.page < this.totalPage) {
					this.status = 'loading';
					this.page++;
					taskApi.checkCustomer({
							page: this.page,
							
							count: this.count,
							task_id: this.id
						})
						.then(res => {
							//如果有数据 重新赋值  如果没有 清空
							if (res.result) {
			
								//最大页数
								this.totalPage = res.result.last_page
								this.list = this.list.concat(res.result.data)
			
								this.status = "loadmore"
			
							} else {
								this.status = "nomore"
							}
			
						})
				} else {
					this.status = "nomore"
				}
			
			
			},
		}
	}
</script>

<style lang="scss" scoped>
	.data-list {
		margin-left: 29rpx;
		height: 160rpx;
		width: 100%;
		display: flex;
		justify-content: space-between;
		align-items: center;
		border-bottom: solid 2rpx rgba(0, 0, 0, .06);
		padding-bottom: 2rpx;
	
		.left {
			display: flex;
			justify-content: flex-start;
	
			.left-l {
				display: flex;
				justify-content: center;
				align-items: center;
	
				.img {
					width: 80rpx;
					height: 80rpx;
					border-radius: 50%;
				}
			}
	
			.name {
				color: #333333;
				font-size: 30rpx;
			}
	
			.content1 {
				height: 56rpx;
				display: flex;
				justify-content: flex-start;
				align-items: center;
				font-size: 26rpx;
				color: #999999;
			}
	
			.content2 {
				font-size: 24rpx;
				color: #999999;
			}
	
		}
	
		.right {
			margin-right: 55rpx;
			font-size: 26rpx;
			font-family: PingFang SC;
			font-weight: 400;
			color: #999999;
			
		}
	}
</style>
