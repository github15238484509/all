<template>
	<view class="box">
		<view class="header">
			<view class="card" v-if="isOne">
				<view class="left1">
					<image :src="$imgUrl(objIf.merchant_logo)" mode="aspectFill"></image>
				</view>
				<view class="right1" @click="goDetail(objIf.merchant_id)">
					<view class="rline1">
						{{objIf.merchant_name?objIf.merchant_name:""}}

					</view>
					<view class="rline2">
						{{objIf.merchant_address?objIf.merchant_address:""}}
					</view>
					<view class="rline3">
						<image src="../../../static/time.png" mode="aspectFill"></image>
						<text style="margin-left: 10rpx;"
							class="line-txt">{{objIf.merchant_worktime_start?objIf.merchant_worktime_start:""}}-{{objIf.merchant_worktime_end?objIf.merchant_worktime_end:""}}</text>
					</view>
					<view class="rline4">
						<image src="../../../static/location.png" style="width: 28rpx;height: 28rpx;margin: 0;"></image>
						<text class="line-txt">{{distance?distance:"0.00m"}}</text>
					</view>
				</view>
				<image src="../../../static/right.png" style="width: 17rpx;height: 32rpx;margin-left: 40rpx;"></image>
			</view>
			<view class="card1" v-if="!isOne">
				<view class="left" v-for="(item,index) in logoList" :key="index">
					<image :src="$imgUrl(item)" class="img"></image>
				</view>
				<view class="right" @click="goAll">
					查看全部>>
				</view>
			</view>
		</view>
		<view class="line">
			<view class="left">
				<view class="dot">

				</view>
				<text style="margin-left: 10rpx;">任务信息</text>

			</view>
			<view class="right" @click="open2">
				<image src="../../../../static/share.png" class="img"></image><text>分享</text>

			</view>
		</view>
		<view class="msg">
			<view class="msg-t">
				<image :src="$imgUrl(oneObj.picture)" class="img"></image>
				<view class="title">
					<text class="tt" v-if="oneObj.status=='1'">等待接单</text>
					<text class="tt" v-if="oneObj.status=='2'">报名中</text>
					<text class="tt" v-if="oneObj.status=='3'">进行中</text>
					<text class="tt" v-if="oneObj.status=='4'">已结束</text>
					{{oneObj.name?oneObj.name:""}}
				</view>
			</view>
			<view class="sj">
				发布时间：{{oneObj.submit_time?$time(oneObj.submit_time,0):""}}
				{{oneObj.submit_time?$time(oneObj.submit_time,3):""}}
			</view>
		</view>
		<view class="banner">
			<view class="line-x">
				<view class="left">
					结束时间
				</view>
				<view class="right">
					{{oneObj.end_time?$time(oneObj.end_time,0):""}} {{oneObj.end_time?$time(oneObj.end_time,4):""}}
				</view>
			</view>
			<view class="line-x">
				<view class="left">
					预计金额
				</view>
				<view class="right" style="color: #FF3131;">
					￥{{oneObj.anticipated?$returnFloat(oneObj.anticipated):"0.00元"}}/人
				</view>
			</view>
			<view class="line-x">
				<view class="left">
					客户数量
				</view>
				<view class="right">
					{{oneObj.customer_num?oneObj.customer_num:"0"}}人
				</view>
			</view>
			<view class="line-x">
				<view class="left">
					客户年龄
				</view>
				<view class="right">
					最小：{{oneObj.start_age?oneObj.start_age:""}}, 最大：{{oneObj.end_age?oneObj.end_age:""}}
				</view>
			</view>
			<view class="line-x">
				<view class="left">
					客户性别
				</view>
				<view class="right">
					{{oneObj.gender?oneObj.gender:""}}
				</view>
			</view>
			<view class="line-x" style="margin-bottom: 33rpx;">
				<view class="left">
					体验课费用
				</view>
				<view class="right" style="margin-left: 29rpx;">
					{{oneObj.experience_amount?$returnFloat(oneObj.experience_amount):"0.00"}}元
				</view>
			</view>
		</view>
		<view class="line" style="margin-top: 30rpx;">
			<view class="left">
				<view class="dot">

				</view>
				<text style="margin-left: 10rpx;">体验课收费说明</text>

			</view>

		</view>
		<view class="t-tip">
			{{oneObj.experience_explain?oneObj.experience_explain:""}}
		</view>
		<view class="line" style="margin-top: 30rpx;">
			<view class="left">
				<view class="dot">

				</view>
				<text style="margin-left: 10rpx;">活动说明</text>

			</view>

		</view>
		<view class="t-tip">
			{{oneObj.activity_explain?oneObj.activity_explain:""}}
		</view>

		<view class="line" style="margin-top: 30rpx;" v-if="oneObj.status==3 || oneObj.status==4 ">
			<view class="left">
				<view class="dot">

				</view>
				<text style="margin-left: 10rpx;">拓客数据</text>

			</view>
			<view class="right" @click="goLook" style="width: 220rpx;">
				<text>查看详细数据>></text>
			</view>
		</view>

		<view class="boxxx" style="margin-top: 20rpx;" v-if="oneObj.status==3 || oneObj.status==4 ">
			<view class="b-item" style="margin-left: 18rpx;">
				<view class="item-t">
					{{oneObj.toker_money?$returnFloat1(oneObj.toker_money):"0.00"}}
				</view>
				<view class="item-b">
					拓客费(元)
				</view>
			</view>
			<view class="b-item" style="margin-left: 120rpx;">
				<view class="item-t">
					{{oneObj.experience_money?$returnFloat1(oneObj.experience_money):"0.00"}}
				</view>
				<view class="item-b">
					体验课费用(元)
				</view>
			</view>
			<view class="b-item" style="margin-left: 100rpx;">
				<view class="item-t">
					{{oneObj.number||"0"}}
				</view>
				<view class="item-b">
					有效客户(人)
				</view>
			</view>
		</view>
		<view class="ttttt" style="margin-top: 20rpx;" v-if="oneObj.status==3 || oneObj.status==4">
			本次任务共获得：{{oneObj.total_money?$returnFloat1(oneObj.total_money):"0.00"}}元
		</view>

		<view class="footer" v-if="oneObj.is_self==1||(oneObj.is_own==0&&oneObj.is_self==1)||(oneObj.is_own==1&&oneObj.is_self==0)">
			<view class="footer-c">
				
				<view class="bbbc" v-if="oneObj.status!==2&&oneObj.status!==1">
					<view class="txt">
						放弃任务
					</view>
				</view>
				<view class="bc" v-if="oneObj.status==2||(oneObj.status==1&&oneObj.is_own==1)" @click="flage1=true">
					<view class="txt">
						放弃任务
					</view>
				</view>
				<view class="bc" v-if="oneObj.status==1&&oneObj.is_own==1" @click="bianji">
					<view class="txt">
						编辑任务
					</view>
				</view>
				<view class="bbbc" v-if="oneObj.status==4">
					<view class="txt">
						编辑任务
					</view>
				</view>
				<view class="bbc" v-if="oneObj.status==1&&oneObj.is_own==1" @click="start">
					<view class="txt">
						立即接单
					</view>
				</view>
				<view class="bbc" v-if="oneObj.status==3&&oneObj.is_recruit==0||oneObj.is_recruit==2" @click="start3">
					<view class="txt">
						开启招募
					</view>
				</view>
				<view class="bbc" v-if="oneObj.status==3&&oneObj.is_recruit==1" @click="close">
					<view class="txt">
						关闭招募
					</view>
				</view>

				<view class="bbc" @click="look" v-if="oneObj.status!==1">
					<view class="txt">
						查看报名
					</view>
				</view>
				<view class="bbc" v-if="oneObj.status==2" @click="start2">
					<view class="txt">
						开始任务
					</view>
				</view>
				<view class="bbc" v-if="oneObj.status==3" @click="tj">
					<view class="txt">
						提交任务
					</view>
				</view>
				<view class="bbbc" v-if="oneObj.status==4">
					<view class="txt">
						已结束
					</view>
				</view>

			</view>

		</view>
		<view class="footer2" v-if="oneObj.status==1&&oneObj.is_own==0" @click="start">
			<text class="txt">立即接单</text>
		</view>
		<view class="footer3" v-if="oneObj.is_self==0&&oneObj.status==3||(oneObj.is_self==0&&oneObj.status==2)">
			<text class="txt">已被接单</text>
		</view>
		<view class="footer3" v-if="oneObj.is_self==0&&oneObj.status==4">
			<text class="txt">已结束</text>
		</view>
		<view class="beijing" v-if="flage1" @click="isFlage">
			<view class="m1">
				<view class="t1">
					提示
				</view>
				<view class="t2">
					您确定要放弃该任务吗？
				</view>
				<view class="ft">
					<view class="ftl" @click.stop="quxiao">
						<view class="ftx">
							取消
						</view>
					</view>
					<view class="ftr" @click.stop="queding">
						<view class="ftx">
							确定
						</view>
					</view>
				</view>
			</view>
		</view>
		<view class="beijing2" v-if="flage2" @click="isFlage2">
			<view class="m1">
				<image src="../../../static/bn22.png" class="img"></image>
				<view class="t1">
					活动已结算
				</view>
				<view class="t2">
					请先仔细查看数据
				</view>
				<view class="box1">
					<view class="list">
						<view class="list-l">
							已付押金：
						</view>
						<view class="list-r">
							￥{{tjObj.deposit_paid?$returnFloat(tjObj.deposit_paid):""}}元
						</view>
					</view>
					<view class="list">
						<view class="list-l">
							计划客户数量：
						</view>
						<view class="list-r">
							{{tjObj.customer_num?tjObj.customer_num:"0"}}人
						</view>
					</view>
					<view class="list">
						<view class="list-l">
							总客户数量：
						</view>
						<view class="list-r">
							{{tjObj.total_customer_num?tjObj.total_customer_num:"0"}}人
						</view>
					</view>
					<view class="list">
						<view class="list-l">
							有效客户数量：
						</view>
						<view class="list-r">
							{{tjObj.effective_customer_num?tjObj.effective_customer_num:"0"}}人
						</view>
					</view>
					<view class="list">
						<view class="list-l">
							单客户金额：
						</view>
						<view class="list-r">
							{{tjObj.single_amount?$returnFloat(tjObj.single_amount):"0"}}元
						</view>
					</view>
				</view>
				<view class="box2">
					<view class="list" style="margin-bottom: 21rpx;">
						<view class="list-l">
							实际金额：
						</view>
						<view class="list-r">
							￥{{tjObj.actual_amount?$returnFloat(tjObj.actual_amount):"0"}}元
						</view>
					</view>
					<view class="list" v-if="tjObj.need_amount>0">
						<view class="list-l">
							还需支付：
						</view>
						<view class="list-r" style="color: #3798FF;">
							￥{{tjObj.need_amount?$returnFloat(tjObj.need_amount):"0"}}元
						</view>
					</view>
					<view class="list2" v-else>
						提示：剩余押金已返还原账户，请留意原账户
						余额动态
					</view>
				</view>
				<view class="btn" @click.stop="ljzf" v-if="tjObj.need_amount>0">
					<view class="text">
						立即支付
					</view>
				</view>
				<view class="btn" @click.stop="ljzf2" v-else>
					<view class="text">
						我知道了
					</view>
				</view>
			</view>
		</view>
		<view class="share" v-if="show2">
			<image :src="$imgUrl(share_task)" mode="aspectFit" class="share_center"></image>
			<view class="footer22">
				<view class="item">
					<view class="left">
						<image src="../../../../static/wxdl.png" class="img"></image>
						<button :plain="true" open-type="share" class="fx" @click="close2()"></button>
						<view class="text">
							微信好友
						</view>

					</view>
					<view class="right">
						<image @click="getImg()" src="../../../static/bctp.png" class="img"></image>
						<view class="text">
							保存图片
						</view>

					</view>
				</view>
				<view class="item2" @click="close2()">
					<view class="txt">
						取消
					</view>

				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import taskApi from "../../../../api/task/task.js"
	import indexApi from "../../../../api/index/indexList.js"
	export default {
		data() {
			return {
				logoList: [],
				flage1: false,
				flage2: false,
				oneObj: {},
				objIf: {},
				id: "",
				longitude: "",
				latitude: "",
				show2: false,
				share_task: "",
				isOne: false,
				ids: [],
				tjObj: {

				},
				distance: "",
			};
		},

		onLoad(e) {
			console.log(e);

			this.id = e.id
			//获取经纬度

			uni.getLocation({
				// type: 'wgs84',
				success: (res) => {
					console.log(res);
					this.longitude = res.longitude
					this.latitude = res.latitude
					// console.log(222222222222);
					this.init()


				},
				fail: (res) => {
					uni.showModal({
						showCancel: false,
						content: '获取定位失败，请打开手机定位',


					})

				}
			})

		},
		methods: {
			goLook() {
				uni.navigateTo({
					url: "./bmjl/tkInfo/tksr/tksr?task_id=" + this.id
				})
			},
			tj() {
				taskApi.submitTask({
					task_id: this.id
				}).then(res => {
					console.log(res)
					if (res.status == 200) {
						this.tjObj = res.result
						this.flage2 = true
					} else {
						uni.showToast({
							title: res.message,
							icon: 'none'
						})
					}
				})
			},
			ljzf() {
				this.flage2 = false
				uni.navigateTo({
					url: "./pay/pay?id=" + this.id+"&type=2"
				})
			},
			ljzf2() {
				taskApi.taskSettlementPay({
					task_id: this.id
				}).then(res => {
					console.log(res)

					this.flage2 = false
					this.init()

				})
			},
			//编辑任务
			bianji() {
				uni.navigateTo({
					url: "../../index/index/fbhd2?ids=" + this.ids + "&&task_id=" + this.id + "&&lng=" + this
						.longitude + "&&lat=" + this.latitude + "&&look=1"
				})
			},
			//查看全部
			goAll() {
				uni.navigateTo({
					url: "../../index/index/fbhd3?ids=" + this.ids
				})
			},
			look() {
				uni.navigateTo({
					url: "./bmjl/bmjl?id=" + this.id+"&status="+this.oneObj.status
				})
			},
			init() {
				taskApi.taskDetail({
					task_id: this.id,
					lng: this.longitude,
					lat: this.latitude
				}).then(res => {
					// console.log(333333333333);
					console.log(res)
					if (res.status == 200) {
						if (res.result.merchant.length > 1) {
							this.oneObj = res.result
							this.ids = res.result.merchant.map(el => {
								return el.merchant_id
							})
							this.ids = this.ids.join(",")
							console.log(this.ids);
							indexApi.merchant_logo({
								merchant_id: this.ids
							}).then(res => {
								console.log(res)
								if (res.status == 200) {
									this.logoList = res.result

								} else {
									uni.showToast({
										title: res.message,
										icon: 'none'
									})
								}
							})
						} else {
							this.isOne = true
							this.oneObj = res.result
							this.objIf = res.result.merchant[0]
							this.distance = this.objIf.distance
							this.ids = res.result.merchant[0].merchant_id
							if (this.distance == 1000) {
								this.distance = "1.0km"
							} else if (this.distance > 1000) {
								const realVal = parseFloat(this.distance / 1000).toFixed(1);
								this.distance = realVal + 'km'
							} else {
								const realVal = parseFloat(this.distance).toFixed(1);
								this.distance = realVal + 'm'
							}
						}


					} else {
						uni.showToast({
							title: res.message,
							icon: 'none'
						})
					}
				})
			},
			start() {
				taskApi.acceptTask({
					task_id: this.id
				}).then(res => {
					console.log(res)
					if (res.status == 200) {
						this.init()
					} else {
						uni.showToast({
							title: res.message,
							icon: 'none'
						})
					}
				})
			},
			//开始任务
			start2() {
				taskApi.startTask({
					task_id: this.id
				}).then(res => {
					console.log(res)
					if (res.status == 200) {
						this.init()
					} else {
						uni.showToast({
							title: res.message,
							icon: 'none'
						})
					}
				})

			},
			//开启招募
			start3() {
				taskApi.recruitTask({
					task_id: this.id
				}).then(res => {
					console.log(res)
					if (res.status == 200) {
						this.init()
					} else {
						uni.showToast({
							title: res.message,
							icon: 'none'
						})
					}
				})

			},
			close() {
				taskApi.closeTask({
					task_id: this.id
				}).then(res => {
					console.log(res)
					if (res.status == 200) {
						this.init()
					} else {
						uni.showToast({
							title: res.message,
							icon: 'none'
						})
					}
				})
			},
			isFlage() {
				this.flage1 = false
			},
			isFlage2() {
				this.flage2 = false
			},
			quxiao() {
				this.flage1 = false
			},
			queding() {
				taskApi.deleteTask({
					task_id: this.id
				}).then(res => {
					console.log(res)
					if (res.status == 200) {
						uni.reLaunch({
							url: "../task"
						})
					} else {
						uni.showToast({
							title: res.message,
							icon: 'none'
						})
					}
				})
			},
			open2() {
				//分享二维码
				taskApi.shareTask({
					// token:uni.getStorageSync('token'),
					page: "/pages/task/taskInfo/taskInfo",
					task_id: this.id
				}).then(res => {
					if (res.status == 200) {
						this.share_task = res.result.share_task
						this.show2 = true
						console.log(this.share_task);
					} else {
						uni.showToast({
							title: res.result.message,
							icon: 'none'
						})
					}

				})

				// if(!uni.getStorageSync('token')){
				// 				 uni.showToast({
				// 					  title:'请选登录',
				// 					  icon:'none'
				// 				  })
				// 				  return;
				// };
			},
			//保存图片
			getImg() {
				// uni.showModal({
				// 	content: '进到了getimg方法'
				// })
				console.log(this.share_task)
				console.log(this.$imgUrl(this.share_task))
				let this_ = this
				uni.getImageInfo({
					src: this_.$imgUrl(this_.share_task),
					success: function(image) {
						// uni.showModal({
						// 	content: '进到了getImageInfo'
						// })
						console.log(image);
						let imgPath = image.path
						console.log(image.path);
			
						uni.saveImageToPhotosAlbum({
							filePath: imgPath,
							success: function() {
			
								uni.showToast({
									title:"保存成功"
								})
							},
							fail: function(err) {
								uni.authorize({
									// scope: 'scope.userLocation',
									success() {
										//1.1 允许授权
										// console.log(error);
									},
									fail() {
										//1.2 拒绝授权
										uni.showModal({
											content: '检测到您没打开获取信息功能权限，是否去设置开？',
											confirmText: '确认',
											cancelText: '取消',
											success: res => {
												if (res.confirm) {
													uni.openSetting({
														success: res => {
															// console.log(res);
															this_
																.getImg();
			
														}
													});
												} else {
													return false;
												}
											}
										});
										return false;
									}
								});
							}
						});
					}
			
				});
			
			},
			close2() {
				this.show2 = false
				// console.log(1111222222);
			},
			goDetail(nid) {
				console.log("跳转店铺详情" + nid)
				uni.navigateTo({
					url: '../../index/index/shopHome?mid=' + nid
				})
			},
		}
	}
</script>

<style lang="scss" scoped>
	.box {
		.boxxx {
			width: 690rpx;
			height: 160rpx;
			background: #F5F5F5;
			border-radius: 10rpx;
			margin-left: 30rpx;
			font-size: 30rpx;
			font-family: PingFang SC;
			font-weight: 500;
			color: #333333;
			display: flex;
			justify-content: flex-start;
			align-items: center;

			.b-item {


				// margin-top: 45rpx;
				// margin-bottom: 40rpx;
				.item-b {
					font-size: 26rpx;
					margin-top: 25rpx;
				}

				.item-t {
					text-align: center;
				}
			}
		}

		.ttttt {
			margin-left: 30rpx;
			font-size: 26rpx;
			font-family: PingFang SC;
			font-weight: 400;
			color: #333333;
		}

		.share {
			position: fixed;
			top: 0;
			left: 0;
			width: 750rpx;
			height: 100vh;
			background: rgba(0, 0, 0, 0.4);

			.share_center {
				position: absolute;
				top: 30rpx;
				left: 127rpx;
				width: 500rpx;
				height: 781rpx;
				z-index: 9999;
			}


			.center {
				position: absolute;
				background-color: #fff;
				bottom: 400rpx;
				left: 127rpx;
				width: 500rpx;
				height: 681rpx;
				background: #FFFFFF;
				border-radius: 10rpx;

				.item1 {

					width: 100%;
					height: 130rpx;
					display: flex;
					align-items: center;
					justify-content: center;

					.img {
						width: 60rpx;
						height: 60rpx;
						margin-right: 30rpx;
					}
				}

				.item2 {
					width: 100%;
					height: 281rpx;
				}

				.item3 {
					width: 100%;
					height: 265rpx;
					padding-top: 27rpx;
					padding-left: 22rpx;
					display: flex;
					justify-content: flex-start;

					.left {
						.left1 {
							width: 275rpx;
							// height: 55rpx;
							font-size: 24rpx;
							font-family: PingFang SC;
							font-weight: 500;
							color: #333333;
						}

						.left2 {
							width: 278rpx;
							font-size: 26rpx;
							font-family: Source Han Sans CN;
							font-weight: 300;
							color: #999999;
							margin-top: 20rpx;
							margin-bottom: 30rpx;

						}

						.left3 {
							width: 72rpx;

							font-size: 28rpx;
							font-family: PingFang SC;
							font-weight: bold;
							color: #FF1C1C;
						}
					}

					.right {
						.right1 {
							width: 160rpx;
							height: 160rpx;
						}

						.right2 {

							font-size: 22rpx;
							font-family: Source Han Sans CN;
							font-weight: 300;
							color: #999999;
						}
					}
				}
			}

			.footer22 {
				position: absolute;
				bottom: 11rpx;
				left: 10rpx;
				background-color: #fff;
				width: 730rpx;
				height: 300rpx;
				background: #FFFFFF;
				border-radius: 10rpx;

				.item2 {
					margin-top: 35rpx;
					width: 690rpx;
					height: 80rpx;
					border: 2rpx solid #EEEEEE;
					border-radius: 10rpx;
					margin-left: 30rpx;
					display: flex;
					align-items: center;
					justify-content: center;

					.txt {

						font-size: 36rpx;
						font-family: PingFang SC;
						font-weight: 400;
						color: #333333;
					}
				}

				.item {
					margin-top: 40rpx;
					width: 100%;
					height: 125rpx;
					display: flex;
					justify-content: space-around;
					position: relative;

					.left {
						position: relative;

						.img {
							width: 80rpx;
							height: 80rpx;
							margin-bottom: 18rpx;
							margin-left: 15rpx;
						}

						.fx {
							width: 80rpx;
							height: 80rpx;
							position: absolute;
							top: 0;
							left: 14rpx;
							opacity: 0
						}

						.text {

							font-size: 26rpx;
							font-family: PingFang SC;
							font-weight: 400;
							color: #333333;
						}
					}

					.right {
						.img {
							margin-left: 15rpx;
							width: 80rpx;
							height: 80rpx;
							margin-bottom: 18rpx;
						}

						.text {

							font-size: 26rpx;
							font-family: PingFang SC;
							font-weight: 400;
							color: #333333;
						}
					}
				}
			}
		}

		.banner {
			width: 690rpx;
			margin-left: 30rpx;
			border-bottom: 1px solid #F5F5F5;

			.line-x {
				margin-top: 25rpx;
				display: flex;
				justify-content: flex-start;

				.left {
					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #999999;
				}

				.right {
					margin-left: 53rpx;
					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #333333;
				}
			}
		}

		.msg {
			width: 690rpx;
			margin-left: 30rpx;
			margin-top: 20rpx;
			border-bottom: 1px solid #F5F5F5;

			.sj {
				margin-top: 20rpx;
				margin-bottom: 28rpx;
				font-size: 26rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #999999;
			}

			.msg-t {
				display: flex;
				justify-content: flex-start;
				align-items: center;

				.img {
					width: 100rpx;
					height: 100rpx;
					border-radius: 10rpx;
				}

				.title {
					margin-left: 20rpx;
					width: 559rpx;
					font-size: 30rpx;
					font-family: PingFang SC;
					font-weight: 500;
					color: #333333;
					overflow: hidden;
					word-wrap: break-word;

					.tt {
						background: linear-gradient(0deg, #1777FF, #569CFF);
						border-radius: 4px;
						font-size: 20rpx;
						font-family: PingFang SC;
						font-weight: 400;
						color: #FFFFFF;
						float: left;
						line-height: 16px;
						padding: 0 4px;
						margin-right: 10rpx;
					}

				}
			}
		}

		.t-tip {
			margin-top: 20rpx;
			width: 690rpx;
			// height: 135rpx;
			font-size: 26rpx;
			font-family: PingFang SC;
			font-weight: 400;
			color: #999999;
			line-height: 36rpx;
			margin-left: 30rpx;
			border-bottom: 1px solid #F5F5F5;
            
            padding-bottom: 30rpx;
		}

		.footer2 {
			width: 690rpx;
			height: 90rpx;
			background: #3798FF;
			border-radius: 10rpx;
			margin-top: 100rpx;
			margin-left: 30rpx;
			display: flex;
			justify-content: center;
			align-items: center;
			margin-bottom: 30rpx;

			.txt {

				font-size: 30rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: #FFFFFF;

			}
		}

		.footer3 {
			width: 690rpx;
			height: 90rpx;
			background: #EEEEEE;
			border-radius: 10rpx;
			margin-top: 100rpx;
			margin-left: 30rpx;
			display: flex;
			justify-content: center;
			align-items: center;
			margin-bottom: 30rpx;

			.txt {

				font-size: 30rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: #999999;

			}
		}

		.footer {
			margin-top: 130rpx;
			width: 100%;
			height: 100rpx;
			background: #FFFFFF;
			box-shadow: 0px -2px 2px 0px rgba(0, 0, 0, 0.08);
			display: flex;
			justify-content: flex-end;
			align-items: center;

			.footer-c {
				height: 70rpx;
				display: flex;
				justify-content: flex-start;
				margin-right: 40rpx;

				.bc {
					width: 160rpx;
					height: 70rpx;
					background: #FFFFFF;
					border: 1px solid #1777FF;
					border-radius: 10rpx;
					display: flex;
					justify-content: center;
					align-items: center;
					margin-right: 10rpx;

					.txt {

						font-size: 26rpx;
						font-family: PingFang SC;
						font-weight: 500;
						color: #3798FF;
					}
				}

				.bbc {
					width: 160rpx;
					height: 70rpx;
					background: #3798FF;
					border-radius: 10rpx;
					display: flex;
					justify-content: center;
					align-items: center;
					margin-right: 10rpx;

					.txt {

						font-size: 26rpx;
						font-family: PingFang SC;
						font-weight: 500;
						color: #FFFFFF;
					}
				}

				.bbbc {
					width: 160rpx;
					height: 70rpx;
					background: #EEEEEE;
					border-radius: 10rpx;
					display: flex;
					justify-content: center;
					align-items: center;
					margin-right: 10rpx;

					.txt {

						font-size: 26rpx;
						font-family: PingFang SC;
						font-weight: 500;
						color: #999999;
					}
				}

			}
		}

		.line {
			display: flex;
			justify-content: space-between;
			align-items: center;
			margin-left: 30rpx;

			.left {
				display: flex;
				justify-content: flex-start;
				align-items: center;

				.dot {
					width: 2px;
					height: 30rpx;
					background: #1777FF;
					border-radius: 2rpx;
				}

				text {


					font-size: 30rpx;
					font-family: PingFang SC;
					font-weight: 500;
					color: #333333;
				}
			}

			.right {
				display: flex;
				align-items: center;
				width: 120rpx;
				height: 50rpx;
				background: #F5F5F5;
				border-radius: 25rpx 0rpx 0rpx 25rpx;

				// margin-right: 23rpx;
				.img {
					width: 28rpx;
					height: 28rpx;
					margin-left: 22rpx;
				}

				text {

					font-size: 24rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #999999;
				}

			}
		}

		.header {
			padding: 30rpx;

			.card1 {
				width: 100%;
				height: 120rpx;
				background: #FFFFFF;
				border: 1px solid #EEEEEE;
				border-radius: 10rpx;
				display: flex;
				justify-content: flex-start;
				align-items: center;
				position: relative;

				.left {
					display: flex;
					justify-content: flex-start;
					margin-left: 10rpx;

					.img {
						width: 100rpx;
						height: 100rpx;
						border-radius: 10rpx;
						margin-right: 20rpx;
					}
				}

				.right {
					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #999999;
					position: absolute;
					top: 45rpx;
					right: 20rpx;
				}
			}

			.card {
				height: 180rpx;
				display: flex;
				justify-content: flex-start;
				align-items: center;
				border: 1px solid #EEEEEE;
				border-radius: 10rpx;

				.left1 {
					width: 180rpx;
					height: 180rpx;
					border-radius: 10rpx;
					margin-left: 11rpx;
					overflow: hidden;

					image {
						width: 180rpx;
						height: 180rpx;
					}
				}

				.right1 {
					margin-left: 22rpx;
					width: 380rpx;
					height: 100%;
					display: flex;
					flex-direction: column;
					justify-content: space-evenly;

					.rline1 {
						font-size: 30rpx;
						display: flex;
						justify-content: space-between;
						white-space: nowrap;
						text-overflow: ellipsis;
						overflow: hidden;

						.img {
							width: 44rpx;
							height: 44rpx;

							border-radius: 50%;

						}
					}

					.rline2 {
						font-size: 24rpx;
						color: #666666;
						white-space: nowrap;
						text-overflow: ellipsis;
						overflow: hidden;
						word-break: break-all;

					}

					.rline3 {
						width: 500rpx;
						font-size: 24rpx;
						display: flex;
						align-items: center;

						image {
							width: 28rpx;
							height: 28rpx;
							margin-left: 1rpx;
						}
					}

					.rline4 {
						width: 500rpx;
						font-size: 24rpx;
						display: flex;
						align-items: center;

						.line-txt {
							margin-left: 10rpx;
							font-size: 24rpx;
							font-family: PingFang SC;
							font-weight: 400;
							color: #333333;
						}

						// padding-left: 5rpx;
						image {
							width: 20rpx;
							height: 27rpx;
							margin-left: 6rpx;
						}

						.refuse {
							display: flex;
							align-items: center;
							justify-content: center;

							font-size: 24rpx;
							font-family: PingFang SC;
							font-weight: 400;
							color: #FE5E5E;

							.fff {
								border-bottom: 1rpx solid #FFF;
							}

							.ml {
								margin-left: 10rpx;
								border-bottom: 1rpx solid #FE5E5E;
							}
						}
					}

				}
			}
		}

		.beijing2 {
			position: fixed;
			width: 100%;
			height: 100%;
			left: 0;
			top: 0;
			background-color: rgba(0, 0, 0, .5);
			z-index: 999;

			.m1 {
				width: 560rpx;
				height: 740rpx;

				position: absolute;
				top: 200rpx;
				left: 95rpx;
				background-color: #FFFFFF;
				border-radius: 10rpx;

				.img {
					width: 560rpx;
					height: 140rpx;
					background: #FFFFFF;
					border-radius: 10rpx;
					position: absolute;
					top: 0;
					left: 0;
				}

				.t1 {
					position: absolute;
					top: 34rpx;
					left: 21rpx;
					font-size: 30rpx;
					font-family: PingFang SC;
					font-weight: bold;
					color: #3798FF;

				}

				.t2 {
					position: absolute;
					top: 87rpx;
					left: 21rpx;
					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #3798FF;

				}

				.btn {
					display: flex;
					justify-content: center;
					align-items: center;
					width: 440rpx;
					height: 90rpx;
					background: #3798FF;
					box-shadow: 0px 5px 7px 0px rgba(46, 94, 204, 0.35);
					border-radius: 45rpx;
					position: absolute;
					bottom: 30rpx;
					left: 60rpx;

					.text {

						font-size: 30rpx;
						font-family: PingFang SC;
						font-weight: 500;
						color: #FFFFFF;
					}
				}

				.box2 {
					width: 520rpx;
					// margin-left: 21rpx;
					margin-top: 30rpx;

					.list2 {

						font-size: 26rpx;
						font-family: PingFang SC;
						font-weight: 400;
						color: #FF4545;
						margin-left: 20rpx;
					}

					.list {
						display: flex;
						justify-content: flex-start;
						align-items: center;

						.list-l {
							margin-left: 21rpx;
							font-size: 30rpx;
							font-family: PingFang SC;
							font-weight: 400;
							color: #999999;
						}

						.list-r {
							font-size: 30rpx;
							font-family: PingFang SC;
							font-weight: 400;
							color: #333333;

						}
					}
				}

				.box1 {
					margin-top: 140rpx;
					height: 289rpx;
					width: 100%;
					padding-left: 21rpx;
					padding-top: 31rpx;

					.list {
						display: flex;
						justify-content: space-between;
						align-items: center;

						.list-l {
							font-size: 30rpx;
							font-family: PingFang SC;
							font-weight: 400;
							color: #999999;
						}

						.list-r {
							font-size: 30rpx;
							font-family: PingFang SC;
							font-weight: 400;
							color: #333333;
							margin-right: 36rpx;
							margin-bottom: 21rpx;
						}
					}
				}

			}
		}

		.beijing {
			position: fixed;
			width: 100%;
			height: 100%;
			left: 0;
			top: 0;
			background-color: rgba(0, 0, 0, .5);
			z-index: 999;

			.m1 {
				width: 500rpx;
				height: 300rpx;

				position: absolute;
				top: 360rpx;
				left: 125rpx;
				background-color: #FFFFFF;
				border-radius: 10rpx;

				.t1 {
					margin: 0 auto;
					width: 62rpx;
					height: 28rpx;
					font-size: 30rpx;
					font-family: PingFang SC;
					font-weight: 500;
					color: #333333;
					margin-top: 30rpx;
				}

				.t2 {
					margin: 0 auto;
					width: 290rpx;
					height: 25rpx;
					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #999999;
					margin-top: 50rpx;
				}

				.ft {
					width: 100%;
					height: 89rpx;
					position: absolute;
					bottom: 0;
					left: 0;
					border-top: 1px solid #F5F5F5;
					display: flex;

					justify-content: flex-start;

					.ftl {
						display: flex;
						align-items: center;
						justify-content: center;
						width: 50%;
						height: 100%;
						border-right: 1px solid #F5F5F5;

						font-size: 30rpx;
						font-family: PingFang SC;
						font-weight: 400;
						color: #999999;
					}

					.ftr {
						display: flex;
						align-items: center;
						justify-content: center;
						width: 50%;
						height: 100%;

						font-size: 30rpx;
						font-family: PingFang SC;
						font-weight: 500;
						color: #3898FF;
					}
				}
			}
		}
	}
</style>
