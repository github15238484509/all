	var tempObj = {};
	let baseUrl =''  //
	let parameter =''

	

	//获取url中"?"符后的字串
	function getRequestParameters() {
		var localhref = window.location.href;
		var localarr;
		
		if(localhref.split('?')[1]){
			localarr = localhref.split('?')[1].split('&')
		}
		if(!localarr){
			uni.showLoading({
			    title: '加载中'
			});
		}
		if(localarr){
			for (var i = 0; i < localarr.length; i++) {
			　　tempObj[localarr[i].split('=')[0]] = localarr[i].split('=')[1];
			}
		}
		return tempObj;
	}
	getRequestParameters();
	baseUrl = window.location.href.split('commonModule')[0]; // 获取域名
	console.log(baseUrl)
	parameter = tempObj.p;  //获取请求地址参数
	console.log(tempObj)
		uni.setStorageSync('parameter', tempObj.p);// 获取项目名称
	try {
		uni.setStorageSync('region', tempObj.r);// 获取token
	    uni.setStorageSync('token', tempObj.t);// 获取token
	} catch (e) {
	    // error
	}
	//判断环境
	// browserRedirect();
	// 如果是自己开发的app，那么可以在UA中添加一个xxApp/1.0.0这样的字段，然后通过这个去判断其是否是在app内。
	function browserRedirect() {
		var sUserAgent = navigator.userAgent.toLowerCase();
		var u = navigator.userAgent;
		var isiOS = !!u.match(/(i[^;]+;(U;))? CPU.+Mac OS X/);
		var isAndroid = u.indexOf('Android') > -1 || u.indexOf('Adr') > -1; //android终端
		if (/ipad|iphone|midp|rv:1.2.3.4|ucweb|android|windows ce|windows mobile/.test(sUserAgent)) {
		//跳转移动端页面
			if(isiOS){
				//isiOS
				alert('isiOS')
			}else if(isAndroid){
				//android终端
				alert('android')
			}else{
				alert('移动端页面')
			}
		} else {
			//跳转pc端页面
			alert('pc端页面')
		}
	}

	// baseUrl = 'http://test.jianyunkeji.net/';   //生产模式
	// parameter = 'tpapi';//生产模式

	const request = function(options) {
	    options.url = baseUrl + parameter + options.url;
	// console.log(options.url)
	     try {

	     } catch (err) {
	      console.log(err)
	    }
	    return uni.request(options);
	  }
	
	export default request;
 
