
const formatTime = date => {
    date = new Date(date);
    const year = date.getFullYear()
    const month = date.getMonth() + 1
    const day = date.getDate()
    const hour = date.getHours()
    const minute = date.getMinutes()
    const second = date.getSeconds()

    return [year, month, day].map(formatNumber).join('-') + ' ' + [hour, minute, second].map(formatNumber).join(':')
}

const formatdate = date => {
    date = new Date(date);
    const year = date.getFullYear()
    const month = date.getMonth() + 1
    const day = date.getDate()

    return [year, month, day].map(formatNumber).join('-');
}

const formatNumber = n => {
    n = n.toString()
    return n[1] ? n : '0' + n
}


module.exports = {
    formatTime,
    formatdate
}
// //工具类
	// exports.all = function(){
	// 	//时间戳格式化转换
	// 	Vue.prototype.inputTime = function(inputTime){
	// 	  const date = new Date(inputTime);
	// 	  const year = date.getFullYear()
	// 	  const month = date.getMonth() + 1
	// 	  const day = date.getDate()
	// 	  const hour = date.getHours()
	// 	  const minute = date.getMinutes()
	// 	  const second = date.getSeconds()
	// 	  return [year, month, day].map(formatNumber).join('-') + ' ' + [hour, minute, second].map(formatNumber).join(':')
	// 	};
	// 	// 手机号正则验证
	// 	Vue.prototype.mobile=function(mobileNum){
	// 	  return mobileNum.match(/^(13[0-9]|14[579]|15[0-3,5-9]|16[6]|17[0135678]|18[0-9]|19[89])\d{8}$/)
	// 	};
	// 	//根据参数获取对应的日期，参数只能事数字，比如0就是今天的日期，1对应的明天的日期
	// 	Vue.prototype.getDay=function() {
	// 	  var today = new Date();
	// 	  var targetday_milliseconds = today.getTime() + 1000 * 60 * 60 * 24 * day;
	// 	  today.setTime(targetday_milliseconds); //注意，这行是关键代码
	// 	  var tYear = today.getFullYear();
	// 	  var tMonth = today.getMonth();
	// 	  var tDate = today.getDate();
	// 	  tMonth = this.doHandleMonth(tMonth + 1);
	// 	  tDate = this.doHandleMonth(tDate);
	// 	  return tYear + "-" + tMonth + "-" + tDate;
	// 	};
	// 	Vue.prototype.doHandleMonth=function(month) {
	// 	  var m = month;
	// 	  if (month.toString().length == 1) {
	// 		m = "0" + month;
	// 	  }
	// 	  return m;
	// 	};
	// 	// 检测过滤空格
	// 	Vue.prototype.filterSpace=function(srt){
	// 	  return str.replace(/ /g, '')
	// 	}
	// };