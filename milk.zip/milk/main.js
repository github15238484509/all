import Vue from 'vue'
import uView from "uview-ui";
Vue.use(uView);
import App from './App'
import 'font_ra0llvaia1/iconfont.css'
import {
	request,
	cdnUrl,
	baseUrl,
	formatTime,
	formatdate,
	fmoney,
	getDay
} from './until/app.js'
Vue.config.productionTip = false;
Vue.prototype.request = request; // 将网络请求挂载到vue原型上
Vue.prototype.$cdnUrl = cdnUrl; //  本地图片地址  注意点:前边一定要$(如果赋值的名字相同的情况下)
Vue.prototype.$baseUrl = baseUrl;// 代码图片地址  注意点:前边一定要$(如果赋值的名字相同的情况下)
Vue.prototype.formatTime = formatTime;
Vue.prototype.fmoney = fmoney;
Vue.prototype.formatdate = formatdate;
Vue.prototype.getDay = getDay;

App.mpType = 'app'
// const throttle = (func, delay) => {
//  let valid = true
//     return function() {
//        if(!valid){
//            //休息时间 暂不接客
//            return false 
//        }
//        // 工作时间，执行函数并且在间隔期内把状态位设为无效
//         valid = false
//         setTimeout(() => {
//             fn()
//             valid = true;
//         }, delay)
//     }
// }
// Vue.prototype.$throttle = throttle;
const timeConvert = (timestamp, num) => {

	timestamp = timestamp + '';
	timestamp = timestamp.length == 10 ? timestamp * 1000 : timestamp;
	var date = new Date(timestamp);
	var y = date.getFullYear();
	var m = date.getMonth() + 1;
	m = m < 10 ? ('0' + m) : m;
	var d = date.getDate();
	d = d < 10 ? ('0' + d) : d;
	var h = date.getHours();
	h = h < 10 ? ('0' + h) : h;
	var minute = date.getMinutes();
	var second = date.getSeconds();
	minute = minute < 10 ? ('0' + minute) : minute;
	second = second < 10 ? ('0' + second) : second;
	if (num == 0) {
		return y + '-' + m + '-' + d;
	} else {
		return y + '-' + m + '-' + d + ' ' + h + ':' + minute + ':' + second;
	}
}
Vue.prototype.$timeConvert = timeConvert;
const app = new Vue({
	...App
	})
app.$mount()
