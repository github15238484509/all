<!-- 确认支付页面 -->
<template>
	<view>
		<view class="payment">
			<view class="txt">支付金额</view>
			<view class="money">￥{{total_money}}</view>
		</view>
		<view class="kong"></view>
		<view class="pattern" @click="pattern(1)">
			<view class="left">
				<image src="../../static/balance.png" style="padding-top: 15rpx;"></image>
				<view class="center">
					<view v-if="current==4&&checked==1">余额支付（余额不足,需混合支付）</view>
					<view v-else>余额支付</view>
					<view>我的余额：{{fmoney(my_money)}}</view>
				</view>
			</view>
			<view class="right" style="padding-top: 15rpx;">
				<image src="../../static/affirm.png" v-if="(current==1 || current==4)&&checked==1"></image>  <!-- 选中 -->
				<image src="../../static/noaffirm.png" v-else-if="(current==2&&my_money>=total_money) || (current==3&&my_money>=total_money) || (current==4&&my_money<=total_money) || (current==4&&my_money>=total_money) || (current==5&&my_money<=total_money) || (current==5&&my_money>=total_money)||my_money<=total_money"></image>  <!-- 可选择 -->
				<!-- <image src="../../static/fixation.png" v-else></image> --> <!-- 禁用图片 -->
			</view>
		</view>
		<view class="pattern" @click="pattern(3)">
			<view class="left">
				<image src="../../static/balance.png" style="padding-top: 15rpx;"></image>
				<view class="center">
					<view v-if="current==5&&checkeds==1">后台充值金支付（余额不足,需混合支付）</view>
					<view v-else>后台充值金支付</view>
					<view>我的余额：{{fmoney(ht_money)}}</view>
				</view>
			</view>
			<view class="right" style="padding-top: 15rpx;">
				<image src="../../static/affirm.png" v-if="(current==3 || current==5)&&checkeds==1"></image>
				<image src="../../static/noaffirm.png" v-else-if="(current==1&&ht_money>=total_money) || (current==2&&ht_money>=total_money) || (current==4&&ht_money<=total_money) || (current==4&&ht_money>=total_money) || (current==5&&ht_money<=total_money) || (current==5&&ht_money>=total_money) || ht_money<=total_money"></image>  <!-- 可选择 -->
				<!-- <image src="../../static/fixation.png" v-else></image> -->
			</view>
		</view>
		<view class="pattern" @click="pattern(2)">
			<view class="left">
				<image src="../../static/payment.png"></image>
				<view class="center">
					<view>微信支付</view>
				</view>
			</view>
			<view class="right">
				<image src="../../static/affirm.png" v-if="current==2 || current==4 || current==5"></image>
				<image src="../../static/noaffirm.png" v-else></image>
			</view>
		</view>
		<view class="butt" @click="butt()">确认支付</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				current:1, //支付方式
				order_index:'',
				total_money:0,//支付金额总价
				my_money:'',//我的余额
				ht_money:'',//我的余额
				showClick:false,//余额
				houtai:false,//后台
				mixture_type:'',//混合支付
				// order_type:'',
				// show:false,
				moneys1:true,
				moneys2:true,
				checked:1,
				checkeds:1,
				oldPage:"",//从哪个页面跳转过来
				use_money:"",//如果是后付订单分润的金额
			}
		},
		onShareAppMessage: function () {
		    return {
		      title:'乃小星',
		      path: '/pages/index/index?scene=' + '1-'+uni.getStorageSync('phone')
		    }
		},
		methods: {
			init(){
				let self = this
				self.request({
					url:'bashi/api/app.php?c=personal/getMyCash',
					data:{
						token:uni.getStorageSync('token')
					}
				}).then(res=>{
					if(res.data.success){
						self.data = res.data.data
						
						self.my_money=Number(self.data.cash/100).toFixed(2)
						// console.log(self.data.server_recharge);
						self.ht_money=Number(self.data.server_recharge/100).toFixed(2)//*100是因为返回的数据是分
						// console.log(typeof self.my_money);
						// console.log(typeof self.total_money);
						// console.log(self.ht_money);
						if(Number(self.my_money)>Number(self.total_money)){
							self.current=1  //余额支付
						}
						if(Number(self.my_money)<Number(self.total_money) && Number(self.ht_money)<Number(self.total_money)){
							self.current=2  //微信支付
						}
						if(Number(self.my_money)<Number(self.total_money) && Number(self.ht_money)>Number(self.total_money)){
							self.current=3  //后台充值金支付
						}
						// 二期新的支付方式 混合支付
						if((Number(self.my_money)<Number(self.total_money))&&Number(self.my_money)!=0){
							self.current=4  //余额支付和微信支付都可以选择
							self.moneys1=true
							self.moneys2=false
							console.log(this.moneys1);
							console.log(this.moneys2);
						}
						if((Number(self.ht_money)<Number(self.total_money))&&Number(self.ht_money)!=0){
							self.current=5  //后台充值金和微信支付都可以选择
							self.moneys2=true
							self.moneys1=false
							console.log(this.moneys2);
							console.log(this.moneys1);
						}
					}else{
						uni.showToast({
							icon:'none',
							title:res.data.msg
						})
					}
				})
			},
			
			// 支付方式切换
			pattern(e){
				console.log(e);
				if(e==1){//余额支付
					if(this.my_money>=this.total_money){
						this.current=1
					// }else if((this.my_money<this.total_money)){//余额+微信混合支付
					}else if((this.my_money<this.total_money)&&this.my_money!=0){//余额+微信混合支付
						console.log(this.moneys1);
						this.current=4
						if(this.current==4){
							this.mixture_type=1
						}
						if(e==2){
							this.current=2
						}
						if(this.moneys1==true){ //再次选择将其设置为未选中
							this.checked=1
							this.moneys1=false
							this.moneys2=true
						}else{
							this.checked=2
							this.moneys1=true
							this.moneys2=false
							this.current=2
						}
					}
				}else if(e==3){//后台充值金
					if((this.ht_money>=this.total_money)){
						this.current=3
					// }else if(this.ht_money<this.total_money){//后台充值金+微信混合支付
					}else if((this.ht_money<this.total_money)&&this.ht_money!=0){//后台充值金+微信混合支付
						console.log(this.moneys2);
						this.current=5
						if(this.current==5){
							this.mixture_type=2
						}
						if(e==2){
							this.current=2
						}
						if(this.moneys2==true){ //再次选择将其设置为未选中
							this.checkeds=1
							this.moneys2=false
							this.moneys1=true
						}else{
							this.checkeds=2
							this.moneys2=true
							this.moneys1=false
							this.current=2
						}
					}
				}else{//微信支付
					this.current=2
					if(this.current==2){
						this.mixture_type=""
					}
				}
			},
			// 确认支付按钮
			butt(){
				let self = this;
				if(self.current==1){
					self.request({
						url:'bashi/api/app.php?c=reserve/payOrder',
						data:{
							token:uni.getStorageSync('token'),
							order_index: self.order_index,
							pay_type:0
						},
						}).then(res=>{
							if(res.data.success){
								if(res.data.data!=null)self.use_money=res.data.data.user_amount
								uni.showToast({
									title: '支付成功'
								});
								setTimeout(()=>{
									uni.reLaunch({
										url:'./paymentSuccs?id='+self.order_index+'&order_type='+self.oldPage+'&use_mony='+self.use_money
									})
								},200)
							}else{
								uni.showToast({
									icon:'none',
									title:res.data.msg
								});
								setTimeout(()=>{
									uni.reLaunch({
										url:'./paymentFail?id='+self.order_index+'&order_type='+self.oldPage+'&use_mony='+self.use_money
									})
								},200)
							}
						},rej=>{
							uni.showToast({
								icon:'none',
								title:res.data.msg
							});
						})
				}else if(self.current==3){
					self.request({
						url:'bashi/api/app.php?c=reserve/payOrder',
						data:{
							token:uni.getStorageSync('token'),
							order_index: self.order_index,
							pay_type:7
						},
						}).then(res=>{
							if(res.data.success){
								if(res.data.data!=null)self.use_money=res.data.data.user_amount
								uni.showToast({
									title: '支付成功'
								});
								setTimeout(()=>{
									uni.reLaunch({
										url:'./paymentSuccs?id='+self.order_index+'&order_type='+self.oldPage+'&use_mony='+self.use_money
									})
								},200)
							}else{
								uni.showToast({
									icon:'none',
									title:res.data.msg
								});
								setTimeout(()=>{
									uni.reLaunch({
										url:'./paymentFail?id='+self.order_index+'&order_type='+self.oldPage+'&use_mony='+self.use_money
									})
								},200)
							}
						},rej=>{
							uni.showToast({
								icon:'none',
								title:res.data.msg
							});
						})
				}else if(self.current==4){
					uni.login({
						success: res => {
							self.request({
								url: 'bashi/api/app.php?c=pay/applet_pay',
								data: {
									token: uni.getStorageSync('token'),
									order_index: self.order_index,
									code: res.code,
									mixture_type:1
								},
								}).then(item=>{
									self.use_money=item.data.data.user_amount
									if (item.data.success){
										uni.requestPayment({
											timeStamp: item.data.data.timeStamp,
											nonceStr: item.data.data.nonceStr,
											package: item.data.data.package,
											signType: item.data.data.signType,
											paySign: item.data.data.paySign,
											appId:item.data.data.sub_appid,
											success: function(response) {
												uni.showToast({
													title: '支付成功'
												});
												setTimeout(()=>{
													uni.reLaunch({
														url:'./paymentSuccs?id='+self.order_index+'&order_type='+self.oldPage+'&use_mony='+self.use_money
													})
												},200)
												if (response.errMsg == 'requestPayment:ok') {
													uni.reLaunch({
														url:'./paymentSuccs?id='+self.order_index+'&order_type='+self.oldPage+'&use_mony='+self.use_money
													})
												}
											},
											fail: function(err) {
												if (err.errMsg == 'requestPayment:fail cancel') {
													uni.showToast({
														title: '取消支付'
													});
												}
												if (err.errMsg == 'requestPayment:fail (detail message)') {
													uni.showToast({
														title: '调用支付失败'
													});
												}
											},
											complete: function(reserr) {
												if (reserr.errMsg == 'requestPayment:cancel') {
													uni.showToast({
														title: '取消支付'
													});
												}
											}
										});
									}else{
										uni.showToast({
											icon:'none',
											title:item.data.msg
										});
									}
								})
						}
					});
				}else if(self.current==5){
					uni.login({
						success: res => {
							self.request({
								url: 'bashi/api/app.php?c=pay/applet_pay',
								data: {
									token: uni.getStorageSync('token'),
									order_index: self.order_index,
									code: res.code,
									mixture_type:2
								},
								}).then(item=>{
									self.use_money=item.data.data.user_amount
									if (item.data.success){
										uni.requestPayment({
											timeStamp: item.data.data.timeStamp,
											nonceStr: item.data.data.nonceStr,
											package: item.data.data.package,
											signType: item.data.data.signType,
											paySign: item.data.data.paySign,
											appId:item.data.data.sub_appid,
											success: function(response) {
												uni.showToast({
													title: '支付成功'
												});
												setTimeout(()=>{
													uni.reLaunch({
														url:'./paymentSuccs?id='+self.order_index+'&order_type='+self.oldPage+'&use_mony='+self.use_money
													})
												},200)
												if (response.errMsg == 'requestPayment:ok') {
													uni.reLaunch({
														url:'./paymentSuccs?id='+self.order_index+'&order_type='+self.oldPage+'&use_mony='+self.use_money
													})
												}
											},
											fail: function(err) {
												if (err.errMsg == 'requestPayment:fail cancel') {
													uni.showToast({
														title: '取消支付'
													});
												}
												if (err.errMsg == 'requestPayment:fail (detail message)') {
													uni.showToast({
														title: '调用支付失败'
													});
												}
											},
											complete: function(reserr) {
												if (reserr.errMsg == 'requestPayment:cancel') {
													uni.showToast({
														title: '取消支付'
													});
												}
											}
										});
									}else{
										uni.showToast({
										        title:item.data.message,
										        icon:'none'
										})
									}
								})
						}
					});
				}else{
					uni.login({
						success: res => {
							self.request({
								url: 'bashi/api/app.php?c=pay/applet_pay',
								data: {
									token: uni.getStorageSync('token'),
									order_index: self.order_index,
									code: res.code,
									mixture_type:""
								},
								}).then(item=>{
									if (item.data.success){
										self.use_money=item.data.data.user_amount
										uni.requestPayment({
											timeStamp: item.data.data.timeStamp,
											nonceStr: item.data.data.nonceStr,
											package: item.data.data.package,
											signType: item.data.data.signType,
											paySign: item.data.data.paySign,
											appId:item.data.data.sub_appid,
											success: function(response) {
												uni.showToast({
													title: '支付成功'
												});
												setTimeout(()=>{
													uni.reLaunch({
														url:'./paymentSuccs?id='+self.order_index+'&order_type='+self.oldPage+'&use_mony='+self.use_money
													})
												},200)
												if (response.errMsg == 'requestPayment:ok') {
													uni.reLaunch({
														url:'./paymentSuccs?id='+self.order_index+'&order_type='+self.oldPage+'&use_mony='+self.use_money
													})
												}
											},
											fail: function(err) {
												if (err.errMsg == 'requestPayment:fail cancel') {
													uni.showToast({
														title: '取消支付'
													});
												}
												if (err.errMsg == 'requestPayment:fail (detail message)') {
													uni.showToast({
														title: '调用支付失败'
													});
												}
											},
											complete: function(reserr) {
												if (reserr.errMsg == 'requestPayment:cancel') {
													uni.showToast({
														title: '取消支付'
													});
												}
											}
										});
									}else{
										uni.showToast({
										        title:res.data.message,
										        icon:'none'
										})
									}
								})
						}
					});
				}
			},
		},
		onLoad(options){
			this.oldPage=options.order_type
			this.order_index=options.id
			// this.total_money=75
			this.total_money=Number(options.total_money)
			this.cdnUrl=this.$cdnUrl
			this.init()
		},
	}
</script>

<style>
page {
	position: relative;
	height: 100%;
}
.payment {
	border-top: 1rpx solid #F5F5F5;
	width: 100%;
	height: 280rpx;
	display: flex;
	flex-direction: column;
	justify-content: center;
	font-size: 26rpx;
	font-family: PingFang SC;
	font-weight: 500;
	color: #343434;
	text-align: center;
}
.payment .money {
	font-size: 50rpx;
	font-weight: bold;
	margin-top: 60rpx;
}
.kong {
	width: 100%;
	height: 20rpx;
	background-color: #F5F5F5;
}
/* 支付方式 */
.pattern {
	padding: 25rpx 30rpx;
	display: flex;
	justify-content: space-between;
	border-top: 1rpx solid #F5F5F5;
	margin: -1rpx 0;
}
.pattern .left {
	display: flex;
}
.pattern .left image {
	width: 44rpx;
	height: 44rpx;
	margin-right: 20rpx;
	vertical-align: middle;
}
.pattern .left .center {
	display: flex;
	flex-direction: column;
	font-size: 26rpx;
	font-family: PingFang SC;
	font-weight: 400;
	color: #343434;
}
.pattern .right image {
	width: 36rpx;
	height: 36rpx;
	vertical-align: middle;
}
/* 确认支付 */
.butt{
	width: 690rpx;
	height: 90rpx;
	background: #3EA4E1;
	border-radius: 45rpx;
	font-size: 36rpx;
	font-family: PingFang SC;
	font-weight: 500;
	color: #F5F5F5;
	line-height: 90rpx;
	text-align: center;
	position: absolute;
	bottom: 30rpx;
	left: 30rpx;
}
</style>
