<!-- 更多订单列表页面 -->
<template>
	<view>
		<!-- 订购记录 details -->
		<view class="order">
			<!-- <view class="txt">订购记录</view> -->
			<view class="title">
				<view class="one">昵称</view>
				<view class="two">订购时间</view>
				<view class="three">订购数量</view>
			</view>
			<view class="matter" v-for="(item,i) in details"  :key='i'>
				<view class="one">{{item.name}}</view>
				<view class="two">{{item.order_time}}</view>
				<view class="three">{{item.goods_count}}</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				details:[],//列表
				goods_index:'',//订购列表
			}
		},
		onShareAppMessage: function () {
		    return {
		      title:'乃小星',
		      path: '/pages/index/index?scene=' + '1-'+uni.getStorageSync('phone')
		    }
		},
		methods: {
			// init初始化
			init(){
				if(uni.getStorageSync('token')){
					let self=this
					self.request({
						url:'bashi/api/app.php?c=goods/allOrderList2Bashi',
						data:{
							token:uni.getStorageSync('token'),
							goods_index:self.goods_index, // 商品id
						},
					}).then(res=>{
						if(res.data.success){
							let index = null;
							for(let i in res.data.data){
								self.details.push(res.data.data[i])
							}
							index = self.details.length-1
							self.details.splice(index,1);
						}
					},rej=>{
						console.log(rej)
					})
				}else{
					uni.redirectTo({
						url:'../my/login'
					})
				}
			},
		},
		onLoad(options){
			this.goods_index=options.id
			console.log(this.goods_index)
			this.cdnUrl=this.$cdnUrl
			this.init()
		}
	}
</script>

<style>
/* 订购记录 */
.order {
	background-color: #FFFFFF;
	padding: 25rpx 30rpx;
	font-size: 26rpx;
	font-family: Source Han Sans CN;
	font-weight: 300;
	color: #9A9A9A;
	margin-bottom: 20rpx;
}
.order .txt {
	font-weight: 400;
	color: #343434;
}
.order .title {
	display: flex;
	justify-content: space-between;
	border-top: 1rpx solid #F5F5F5;
	border-bottom: 1rpx solid #F5F5F5;
	padding: 30rpx 0;
	box-sizing: border-box;
	text-align: center;
}
.order .one {
	width: 100rpx;
}
.order.two {
	flex: 1;
}
.order .three {
	width: 160rpx;
}
.order .matter {
	display: flex;
	justify-content: space-between;
	text-align: center;
	color: #343434;
	padding: 30rpx 0;
	box-sizing: border-box;
	border-bottom: 1rpx solid #F5F5F5;
}
.order .more {
	text-align: center;
	margin-top: 30rpx;
}
</style>
