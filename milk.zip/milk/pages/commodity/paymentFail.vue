<!-- 支付失败页面 -->
<template>
	<view>
		<view class="one">
			<image :src="cdnUrl+'bashi/image/moneyNo.png'"></image>
			<view>预定失败</view>
			<view class="rest">订单未支付（可为其他原因）</view>
		</view>
		<view class="check" @click="examine()">返回</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				cdnUrl:'',
			}
		},
		onShareAppMessage: function () {
		    return {
		      title:'乃小星',
		      path: '/pages/index/index?scene=' + '1-'+uni.getStorageSync('phone')
		    }
		},
		methods: {
			// 返回到支付页面
			black(){
				uni.navigateTo({
					url:'./payment'
				})
			},
			// 转跳到查看我的预定页面
			examine(){
				uni.navigateTo({
					url:'../reserve/particulars?id='+this.order_index
				})
			},
		},
		onLoad(options) {
			this.order_index=options.id
			this.cdnUrl=this.$cdnUrl
		}
	}
</script>

<style>
.one{
	text-align: center;
	font-size: 30rpx;
	font-family: PingFang SC;
	font-weight: 500;
	color: #343434;
	padding-top: 150rpx;
}
.one image {
	width: 146rpx;
	height: 185rpx;
	padding-bottom: 50rpx;
}
.one .rest {
	margin-top: 30rpx;
	color: #9A9A9A;
}
.check {
	width: 690rpx;
	height: 90rpx;
	background: #3EA4E1;
	border-radius: 45rpx;
	line-height: 90rpx;
	text-align: center;
	font-size: 30rpx;
	font-family: PingFang SC;
	font-weight: 500;
	color: #FFFFFF;
	margin: 50rpx 30rpx;
}

</style>
