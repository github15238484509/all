<!-- 附近领取点 -->
<template>
	<view>
		<!-- 附近领取点 viseLsit -->
		<view class="search">
			<image src="../../static/search(1).png"></image>
			<input placeholder="请输入门店名称" value="" @input="getValue"/>
			<view class="text" @click="gosearch()">搜索</view>
		</view>
		<view class="vise" v-for="(item,i) in viseLsit" :key='i' @click="map(item.merchant_id,item.merchant_address,item.distance,item.merchant_name,item.logo)">
			<view class="img">
				<image :src="cdnUrl+item.logo"></image>
			</view>
			<view class="txt">
				<view class="txt1">{{item.merchant_name}}</view>
				<view>{{item.merchant_address}}</view>
			</view>
			<view class="map">
				<view class="location">
					<image src="../../static/location.png"></image>
				</view>
				<view>{{item.distance}}</view>
			</view>
		</view>
		<view class="nomore">没有更多了...</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				cdnUrl:'',
				viseLsit:[], // 附近领取点列表
				lat:'',
				lng:'',
				order_index:'',
				merchant_id:'',//领取点id
				id:1,
				reverseId:'',//从预定列表跳转过来的id
				page:0,//分页
				pageCount:0,//总页数
				search_mer:'',//关键字
			}
		},
		onShareAppMessage: function () {
		    return {
		      title:'乃小星',
		      path: '/pages/index/index?scene=' + '1-'+uni.getStorageSync('phone')
		    }
		},
		methods: {
			// init初始化
			init(){
				if(uni.getStorageSync('token')){
					let self=this
					let data={}
					if(self.search_mer==''){
						data={
							token:uni.getStorageSync('token'),
							lat:self.lat,
							lng:self.lng
						}
					}else{
						data={
							token:uni.getStorageSync('token'),
							lat:self.lat,
							lng:self.lng,
							search_mer:self.search_mer,//关键词
						}
					}
					self.request({
						url:'bashi/api/app.php?c=getUserMerchant',
						data:data
					}).then(res=>{
						if(res.data.success){
							self.pageCount = res.data.pageCount
							// self.viseLsit=res.data.data
							for(var i = 0; i < res.data.data.length ; i++){
								self.viseLsit.push(res.data.data[i])
							}
							if(res.data.data.length==0){
								uni.showToast({
									icon:'none',
									title:'暂无此门店~'
								})
							}
						}
					},rej=>{
						console.log(rej)
					})
				}else{
					uni.redirectTo({
						url:'../my/login'
					})
				}
			},
			getValue(e){
				this.search_mer=e.detail.value
			},
			// 搜索
			gosearch(){
				console.log(111);
				this.page=0
				this.pageCount=0
				this.viseLsit=[]
				this.init()
			},
			// 获取用户当前位置信息==>uni自带样式
			getLocation(){
				let self=this
				uni.getLocation({
					type: 'wgs84',
					success: function (res) {
						console.log('当前位置的经度：' + res.longitude);
						console.log('当前位置的纬度：' + res.latitude);
						self.lat = res.latitude;
						self.lng = res.longitude;
						self.init()
					}
				});
			},
			// 地址 ==> 对应恢复配送接口
			map(merchant_id,merchant_address,distance,merchant_name,logo){
				let self =this;
				if(self.reverseId==''){
					uni.navigateBack({
						delta:1
					})
					uni.setStorageSync('merchant_id',merchant_id)
					uni.setStorageSync('distance',distance)
					uni.setStorageSync('merchant_address',merchant_address)
					uni.setStorageSync('merchant_name',merchant_name)
					uni.setStorageSync('logo',logo)
				}else{
					self.request({
						url:'bashi/api/app.php?c=reserve/recoverReserve',
						data:{
							token:uni.getStorageSync('token'),
							order_index:self.reverseId,//订单自增编号
							merchant_id:merchant_id,//配送地点id
						}
					}).then(res=>{
							if(res.data.success){
								uni.navigateBack({
									delta:1
								})
							}else{
								uni.showToast({
									icon:'none',
									title:res.data.msg
								})
								setTimeout(()=>{
								uni.navigateBack({
									delta:1
								})
								},1000)
							}
					    },rej=>{
							uni.showToast({
								icon:'none',
								title:res.data.msg
							})
					})					
				}
			},
		},
		onReachBottom(){
			if(this.page<this.pageCount-1){
				this.page++
				this.init()
			}
		},
		onLoad(options){
			if(options.reverseId){
				this.reverseId=options.reverseId
			}else{
				this.lat=options.lat
				this.lng=options.lng
				this.lng=options.lng
				this.order_index=options.id
			}
			this.cdnUrl=this.$cdnUrl
			this.getLocation()
		}
	}
</script>

<style>
.search {
	padding-bottom: 10rpx;
	margin: 0 30rpx;
	border-bottom: 1rpx solid #F5F5F5;
	box-sizing: border-box;
}
.search image {
	width: 34rpx;
	height: 34rpx;
	position: absolute;
	left: 70rpx;
	top: 15rpx;
}
.search input {
	position: relative;
	width: 560rpx;
	height: 66rpx;
	background: #CCCCCC;
	opacity: 0.3;
	border-radius: 33rpx;
	line-height: 66rpx;
	font-size: 30rpx;
	font-family: PingFang SC;
	font-weight: 400;
	padding-left: 100rpx;
	box-sizing: border-box;
}
.search .text {
	position: absolute;
	right: 30rpx;
	top: 0rpx;
	width: 120rpx;
	height: 70rpx;
	background-color: #F5F5F5;
	border-radius: 15rpx;
	line-height: 70rpx;
	text-align: center;
	color: #333;
	font-size: 30rpx;
}
.vise {
	width: 100%;
	display: flex;
	justify-content: space-between;
	padding: 40rpx 35rpx; 
	box-sizing: border-box;
	border-bottom: 1rpx solid #F5F5F5;
	border-top: 1rpx solid #F5F5F5;
	margin: -1rpx 0;
	align-items: center;
}
.vise .img image{
	width: 140rpx;
	height: 140rpx;
	border-radius: 10rpx;
	margin-right: 30rpx;
	flex: 1;
}
.vise .txt {
	flex: 1;
	margin-top: 20rpx;
	margin-bottom: 20rpx;
	font-size: 26rpx;
	font-family: PingFang SC;
	font-weight: 400;
	color: #343434;
	margin-right: 50rpx;
	display: flex;
	flex-direction: column;
	justify-content: space-between;
}
.vise .txt .txt1 {
	font-size: 30rpx;
	font-family: PingFang SC;
	font-weight: 500;
	color: #333333;
	margin-bottom: 20rpx;
}
.vise .map {
	display: flex;
	flex-direction: column;
	font-size: 26rpx;
	font-family: PingFang SC;
	font-weight: 400;
	color: #40A2E2;
	align-items: center;
}
.vise .location image {
	width: 44rpx;
	height: 40rpx;
}
.nomore {
	font-size: 26rpx;
	font-family: PingFang SC;
	font-weight: 400;
	color: #9A9A9A;
	text-align: center;
	margin-top: 40rpx;
}
</style>
