<!-- 提交预定信息页面 -->
<template>
	<view style="padding:0 30rpx;">
		<!-- 头部地址详情 site -->
		<view>
			<view :class="topTypeLinke==0?'topType1 topType':'topType2 topType'" style="margin-top: 20rpx;border-radius: 20rpx 20rpx 0 0;"
				v-if='arrive_address==1'>
				<view :class="topTypeLinke==0?'topTypeView':'topTypeView1'" @click="switchTop(0)">
					领取点领取
				</view>
				<view :class="topTypeLinke==0?'topTypeView1':'topTypeView'" @click="switchTop(1)" >
					送奶入户
				</view>
			</view>
			<view class="head" :class="arrive_address==1?'':'head1'" @click="gosite(lat,lng)" v-if="topTypeLinke==0">
				<view class="img1" v-if="logo">
					<image :src="cdnUrl+logo"></image>
				</view>
				<view class="img" v-else>
					<image src="../../static/house.png"></image>
				</view>
				<view class="txt">
					<view class="txt1">{{merchant_name?merchant_name:'请选择领取点'}}</view>
					<view class="txt2" v-if="merchant_address">{{merchant_address}}</view>
					<view class="txt2" v-else>您还没有选择领取点，请点击这里选择</view>
				</view>
				<view class="distance">{{distance}}
					<image src="../../static/back.png"></image>
				</view>
			</view>
			<view class="head" @click="goReceivingAddress " v-if="topTypeLinke==1">
				<view class="img">
					<image src="../../static/adressIcon.png" style="width: 64rpx;height: 64rpx;"></image>
				</view>
				<view class="txt">
					<view class="txt1">{{addressList!=''?addressList.contacts:'请选择收货地址'}} <span
							style="margin-left: 20rpx;font-size: 24rpx;color: #999999;">{{addressList!=''?addressList.phone:''}}</span>
					</view>
					<view :class="addressList==''?'txt2':'txt3'">
						{{addressList!=''?addressList.province_name+addressList.city_name+addressList.county_name+addressList.full_address+addressList.address:'您还没有设置收货地址，请点击这里设置！'}}
					</view>
				</view>
				<view class="distance">
					<image src="../../static/back.png"></image>
				</view>
			</view>
			<view class="head-time" @click="selectTime" style="">
				<view class="font-30">开始配送时间</view>
				<view class="font-30" style="color: #999999;">{{timeValue}} <img src="../../static/back.png" alt="">
				</view>
			</view>
			<!-- <u-pickerr v-model="timeListShow" mode="time" @confirm="deliveryTime" :defaultTime='timeValue' :start-year="stystemYear" :start-mouth="stystemMonth" :start-day="stystemDay"></u-pickerr> -->
			<u-picker mode="time" v-model="timeListShow" :default-time="timeValue" @confirm="deliveryTime"
				:start-year="stystemYear" :start-month="stystemMonth" :start-day="stystemDay"></u-picker>
		</view>
		<view class="drinkFirst" v-if="topTypeLinke==1&&later_pay==1">
			<view style="display: flex;justify-content: space-between;">
				<view style="font-size: 30rpx;margin-top: 20rpx;">
					先喝奶后付钱
				</view>
				<switch :checked="drinkFirst " @change="changeDrinkFirst" color=""
					style="transform:scale(0.7);margin-top: 20rpx;" color="#3DA3E1" />
			</view>
			<view style="font-size: 26rpx;color: #999999;margin-top: 10rpx;">开启即代表已阅读并同意<span style="color: #3DA3E1;"
					@click='drinkFirstAgreement=true'>《后付款协议》</span></view>
		</view>
		<!-- 先喝奶后付款协议弹窗 -->
		<view class="beijing" v-if='drinkFirstAgreement'>
			<view class="tanchuang2">
				<view style="height: 80rpx;line-height: 80rpx;">{{title_DringkFirst}}</view>
				<view class="slot-content"
					style="padding: 30rpx;height: 500rpx;overflow:auto;color: #999999;font-size: 26rpx;text-align: left;">
					<rich-text :nodes="content_DringkFirst"></rich-text>
				</view>
				<view style="height: 100rpx; line-height: 100rpx;border-top: 1rpx solid #F5F5F5;display: flex;">
					<view style="width: 50%; color: #999999;" @click="noAgreement">拒绝</view>
					<view style="width: 50%; color: #3FA2E2;" @click="knowagreement">同意</view>
				</view>
			</view>
		</view>
		<!-- <u-modal v-model="drinkFirstAgreement" confirm-text="我知道了" :title="title_DringkFirst" @confirm="knowagreement">
			<view class="slot-content" style="padding: 30rpx;height: 500rpx;overflow:auto;margin-top: 30rpx;color: #999999;font-size: 26rpx;">
					<rich-text :nodes="content_DringkFirst"></rich-text>
			</view>
		</u-modal> -->
		<!-- 订购数量 quantityList -->
		<view class="quantity">
			<view class="one">
				<view class="img">
					<image :src="cdnUrl+goods_icon"></image>
				</view>
				<view class="txt">
					<view class="txt1">{{goods_name}}</view>
					<view style="display: flex;align-items: center;">
						<view class="txt2">￥{{goods_cost/100}}元/{{goods_unit}}</view>
						<view class="txt2"
							style="font-size: 24rpx;text-decoration: line-through;color: #999999;margin-left: 30rpx;">
							￥{{goods_price/100}}</view>
					</view>
				</view>
			</view>
			<view class="two" v-if="drinkFirst===false">
				<view class="number">数量</view>
				<view class="vase">
					<block v-for="(item,i) in vase" :key="item.id">
						<view :class="selectedIndex==item.id?'bom1':'bom'" @click="vasenum(item.value,item.id)">
							<view>{{item.bom1}}</view>
						</view>
					</block>
					<input placeholder="请输入其他数量" type="number" :value="vasvalue"
						:class="selectedIndex==5?'inpvase1':'inpvase'" @input='getVas' @focus="getIndex" />
				</view>
			</view>
			<view class="three" v-if="drinkFirst===true">
				<view class="day">配送天数</view>
				<view class="num" style="text-align: right; color: #333333;">
					30天
				</view>
			</view>
			<view class="three">
				<view class="day">每日数量</view>
				<view class="num">
					<input type="number" placeholder="请填写数字" :value="value" @input='getValue' />
				</view>
			</view>
		</view>
		<!-- 合计金额 -->
		<view class="sum">
			<view>合计金额</view>
			<view class="money">￥{{total_money}}</view>
		</view>
		<view style="height: 120rpx;" v-if="drinkFirst===false"></view>
		<!-- 底部提交按钮 -->
		<view class="butt" @click="buttn1(total_money)">提交预定信息</view>

		<!-- 提交弹窗提示 -->
		<view class="beijing" v-if='flage'>
			<view class="tanchuang">
				<view class="title">提示</view>
				<view class="txt">领取时间是每天24点之前，未及时领取导致产品变质，视为会员放弃此商品，公司不做补偿。</view>
				<view style="display: flex;">
					<view class="know" style="color: #999999;" @click="cancel()">拒绝</view>
					<view class="know" @click="knows()">同意</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				arrive_address: "", //是否支持入户
				later_pay: "", //是否支持后付
				title_DringkFirst: "", //后付款协议标题
				content_DringkFirst: "", //后付款协议内容
				// 是否协议展示的模态框
				drinkFirstAgreement: false,
				// 先喝后付状态
				drinkFirst: false,
				// 系统时间(年)
				stystemYear: "",
				// 系统时间(月)
				stystemMonth: "",
				// 系统时间(日)
				stystemDay: "",
				// 订单配送时间
				timeStamp: "",
				// 时间显示
				timeValue: '请选择时间',
				// 时间选择器显示与否
				timeListShow: false,
				// 订单类型标签选择页
				topTypeLinke: 0,
				site: [], // 地址详情相关信息
				order_index: '', //订单编号
				vase: [{
						bom1: '30',
						"value": 30,
						id: 0
					},
					{
						bom1: '60',
						"value": 60,
						id: 1
					},
					{
						bom1: '90',
						"value": 90,
						id: 2
					},
					{
						bom1: '180',
						"value": 180,
						id: 3
					},
					{
						bom1: '360',
						"value": 360,
						id: 4
					},
				], // 选择数量
				selectedIndex: 0, // 点中状态ID
				vasvalue: '', //用户手动输入的总瓶数
				goods_count: '', //商品数量
				goods_index: '', //商品编号
				user_address: '', //用户坐标地址
				merchant_id: '', //收货地址id
				day_count: '', //每日领取份数
				total_money: '0', //订单总价
				goods_name: '', //商品名
				goods_icon: '', //商品图
				goods_cost: '', //单价
				goods_price: '', //市场价
				cdnUrl: '',
				value: '', //用户输入的数量
				lat: '',
				lng: '',
				merchant_address: '', //详细位置
				distance: '', //米
				merchant_name: '', //商店名
				logo: '', //商店图片
				goods_unit: '',
				flage: false, //弹窗
				flage1: false, //弹窗
				default_address: "", //默认地址
				address_Id: "", //收货地址ID
				addressList: "", //收货地址
				outPayOrder: "", //是否有待支付订单
			}
		},
		onShareAppMessage: function() {
			return {
				title: '乃小星',
				path: '/pages/index/index?scene=' + '1-' + uni.getStorageSync('phone')
			}
		},
		methods: {
			// 拒绝协议
			noAgreement() {
				uni.showToast({
					title: "同意先喝后付协议后才能享受该服务",
					icon: "none"
				})
				this.drinkFirst = false
				this.drinkFirstAgreement = false
				this.vasvalue == '' ? this.total_money = this.goods_cost / 100 * this.goods_count : this.total_money = this
					.goods_cost / 100 * this.vasvalue
			},
			// 点击我知道了的方法
			knowagreement(e) {
				this.drinkFirstAgreement = false
			},
			// 改变先喝后付switch滑动选择器的状态
			changeDrinkFirst() {
				this.drinkFirst = !this.drinkFirst
				if (this.drinkFirst === true) {
					this.total_money = this.goods_cost / 100 * 30 * this.value
					this.drinkFirstAgreement = true
				} else {
					this.vasvalue == '' ? this.total_money = this.goods_cost / 100 * this.goods_count : this.total_money =
						this.goods_cost / 100 * this.vasvalue
				}
			},
			// 时间选择器确定按钮回调函数
			deliveryTime(e) {
				console.log(e)
				this.timeValue = e.year + '-' + e.month + '-' + e.day
				this.timeStamp = e.timestamp
			},
			// 选择时间
			selectTime() {
				this.timeListShow = true
			},
			// 跳转到收货地址选择页面
			goReceivingAddress() {
				uni.navigateTo({
					url: "../my/addressManagement?type=" + 1 + '&addressIndex=' + this.addressList.address_id
				})
			},
			// 切换订单状态(0:配送到店   1:配送到家)
			switchTop(e) {
				if (e == 0) {
					this.drinkFirst = false
					this.topTypeLinke = 0;
					this.total_money = this.goods_cost / 100 * this.goods_count
				} else {
					this.topTypeLinke = 1;
					uni.getStorageSync('ad')
					uni.getStorageSync('addressList') ? this.addressList = uni.getStorageSync('addressList') : this
						.getAdressList()
				}
				// this.topTypeLinke
			},
			// 获取用户账号信息
			getPersonalInfo() {
				let self = this
				self.request({
					url: 'bashi/api/app.php?c=personal/getPersonalInfo',
					data: {
						token: uni.getStorageSync('token')
					}
				}).then(res => {
					if (res.data.success) self.outPayOrder = res.data.data.order
				});
			},
			// 获取收货地址列表
			getAdressList() {
				let self = this
				self.request({
					url: "bashi/api/app.php?c=personal/user_address_list",
					data: {
						token: uni.getStorageSync("token"),
						default_address: 1,
						page: 1,
						limit: 10
					},
				}).then(res => {
					if (res.data.success) {
						if (res.data.data.list.length > 0) {
							self.addressList = res.data.data.list[0]
						} else {
							self.addressList = ''
						}
					}
				})
			},
			// init初始化
			init() {
				if (uni.getStorageSync('token')) {
					let self = this
					self.total_money = self.goods_cost / 100 * self.vase[0].value
					self.goods_count = self.vase[0].value
					// 提前向用户发起授权请求
					uni.authorize({
						scope: 'scope.userLocation',
						success() { //1.1 允许授权
							self.getLocation()
						},
						fail() { //1.2 拒绝授权
							uni.showModal({
								content: '检测到您没打开获取信息功能权限，是否去设置打开？',
								confirmText: "确认",
								cancelText: '取消',
								success: (res) => {
									if (res.confirm) {
										uni.openSetting({
											success: (res) => {
												self.getLocation();
											}
										})
									} else {
										return false;
									}
								}
							})
							return false;
						}
					});
				} else {
					uni.navigateTo({
						url: '../my/login'
					})
				}
			},
			// 获取用户当前位置信息==>uni自带样式
			getLocation() {
				let self = this
				uni.getLocation({
					type: 'wgs84',
					success: function(res) {
						self.lat = res.latitude;
						self.lng = res.longitude;
						self.map()
					}
				});
			},
			// 获取地址详情
			map() {
				let self = this
				self.request({
					url: 'bashi/api/app.php?c=getUserMerchant',
					data: {
						token: uni.getStorageSync('token'),
						lat: self.lat,
						lng: self.lng
					}
				}).then(res => {
					if (res.data.success) {
						self.site = res.data.data[0]
						self.merchant_id = res.data.data[0].merchant_id //领取点id
						self.merchant_address = self.site.merchant_address
						self.distance = self.site.distance
						self.merchant_name = self.site.merchant_name
					}
				})
			},

			// 初始化结算金额
			init1() {
				this.total_money = this.goods_cost / 100 * this.vase[0].value
				this.goods_count = this.vase[0].value
			},
			// 地址详情
			gosite(lat, lng) {
				uni.navigateTo({
					url: './nearby?lat=' + lat + '&lng=' + lng + '&id=' + this.goods_index
				})
			},
			// 数量选择
			vasenum(val, id) {
				this.selectedIndex = id
				this.total_money = this.goods_cost / 100 * val
				this.goods_count = val
				this.vasvalue = ""
			},
			// 手动输入的总瓶数
			getVas(e) {
				this.vasvalue = e.detail.value
				if (this.vasvalue != '') {
					if (e.detail.value == 0) {
						uni.showToast({
							icon: 'none',
							title: '至少1份'
						});
						this.total_money = 0
					} else {
						this.total_money = (this.goods_cost * 10 / 100) * (this.vasvalue * 10) / 100
						this.goods_count = Number(this.vasvalue)
					}
				}
			},
			getIndex() {
				this.selectedIndex = 5
			},
			//实时获取输入框的值==>每日的数量
			getValue(e) {
				if (e.detail.value==''){
					this.value = e.detail.value
				}
				if (e.detail.value <= 0) {
					uni.showToast({
						icon: 'none',
						title: '至少1份'
					});
					return
				}
				if (this.drinkFirst === false) {
					if (e.detail.value > this.goods_count) {
						uni.showToast({
							icon: 'none',
							title: '不能超过总数'
						});
						this.value = e.detail.value
						return
					} else {
						this.value = e.detail.value
					}
					return
				}
				if (this.drinkFirst === true&&e.detail.value > 3) {
					uni.showToast({
						icon: 'none',
						title: '最多三份'
					});
					this.total_money = e.detail.value * 30 * this.goods_cost / 100
					this.value = e.detail.value
					return
				}
				this.total_money = e.detail.value * 30 * this.goods_cost / 100
				this.value = e.detail.value
			},
			// 拒绝弹窗
			cancel(){
				this.flage=false;
				this.flage1=false;
			},
			// 同意弹窗
			knows() {
				this.flage = false
				this.flage1=true;
				this.butt1(this.total_money)
			},
			buttn1(e) {
				this.$u.throttle(() => {
					this.butt1(e)
				}, 500)
			},
			// 提交预订信息
			// butt(total_money) {
			// 	let self = this
			// 	let pay_type = 0
			// 	if (self.drinkFirst) {
			// 		pay_type = '1'
			// 	}
			// 	if (self.topTypeLinke == 0) {
			// 		// if(self.merchant_id==''){
			// 		// 	uni.showToast({
			// 		// 		icon:'none',
			// 		// 		title:'请选择领取地点' 
			// 		// 	})
			// 		// }else  
			// 		if (self.merchant_id == '') {
			// 			uni.showToast({
			// 				icon: 'none',
			// 				title: '请选择领取地点'
			// 			})
			// 		} else if (self.timeStamp == '') {
			// 			uni.showToast({
			// 				title: '请选择配送时间',
			// 				icon: 'none'
			// 			})
			// 		} else if (self.value == '' || self.value == 0) {
			// 			uni.showToast({
			// 				icon: 'none',
			// 				title: '请输入每日领取的数量'
			// 			})
			// 		} else if (self.outPayOrder == 1) {
			// 			uni.showToast({
			// 				title: '请先支付后付订单',
			// 				icon: 'none'
			// 			})
			// 		} else {
			// 			if (self.flage == false && self.flage1 == false) {
			// 				self.flage = true
			// 				self.flage1 = true
			// 			} else {
			// 				self.request({
			// 					url: 'bashi/api/app.php?c=submitOrder',
			// 					data: {
			// 						expect_time: self.timeStamp,
			// 						token: uni.getStorageSync('token'),
			// 						goods_count: self.goods_count, //商品数量
			// 						goods_index: self.goods_index, //商品编号
			// 						merchant_id: self.merchant_id, //领取点地址id
			// 						day_count: self.value, //每日领取份数
			// 						area_type: self.topTypeLinke, //订单状态
			// 						order_type: 0 //订单类型（首订订单与续订订单）
			// 					},
			// 				}).then(res => {
			// 					if (res.data.success) {
			// 						self.order_index = res.data.data.order_goods_data.order_index
			// 						uni.navigateTo({
			// 							url: './payment?id=' + self.order_index + '&total_money=' +
			// 								total_money
			// 						})
			// 						uni.removeStorageSync('merchant_id')
			// 						uni.removeStorageSync('distance')
			// 						uni.removeStorageSync('merchant_address')
			// 						uni.removeStorageSync('merchant_name')
			// 						uni.removeStorageSync('logo')
			// 					} else {
			// 						uni.showToast({
			// 							icon: 'none',
			// 							title: res.data.msg
			// 						})
			// 					}
			// 				}, rej => {
			// 					uni.showToast({
			// 						icon: 'none',
			// 						title: res.data.msg
			// 					})
			// 				})
			// 			}
			// 		}
			// 	} else if (self.drinkFirst) {
			// 		if (self.addressList == "") {
			// 			uni.showToast({
			// 				title: '请选择收货地址',
			// 				icon: 'none'
			// 			})
			// 			return
			// 		}
			// 		if (self.timeStamp == "") {
			// 			uni.showToast({
			// 				title: '请选择开始配送时间',
			// 				icon: 'none'
			// 			})
			// 			return
			// 		}
			// 		if (self.value == "") {
			// 			uni.showToast({
			// 				title: '请输入每日领取的数量',
			// 				icon: 'none'
			// 			})
			// 			return
			// 		}
			// 		if (self.outPayOrder == 1) {
			// 			uni.showToast({
			// 				title: '请先支付后付订单',
			// 				icon: 'none'
			// 			})
			// 			return
			// 		}
			// 		let goodsNum = 0
			// 		pay_type == 1 ? goodsNum = self.value * 30 : goodsNum = self.goods_count
			// 		self.request({
			// 			url: 'bashi/api/app.php?c=submitOrder',
			// 			data: {
			// 				expect_time: self.timeStamp,
			// 				token: uni.getStorageSync('token'),
			// 				goods_count: goodsNum, //商品数量
			// 				goods_index: self.goods_index, //商品编号
			// 				address_index: self.addressList.address_id, //收货地址id
			// 				day_count: self.value, //每日领取份数
			// 				area_type: self.topTypeLinke, //订单状态
			// 				pay_type: pay_type //是否为先喝后付
			// 			},
			// 		}).then(res => {
			// 			if (res.data.success) {
			// 				self.order_index = res.data.data.order_goods_data.order_index
			// 				if (self.drinkFirst === false) {
			// 					uni.navigateTo({
			// 						url: './payment?id=' + self.order_index + '&total_money=' + total_money
			// 					})
			// 				} else {
			// 					uni.redirectTo({
			// 						url: "./paymentSuccs?id=" + self.order_index + '&pay_type=1'
			// 					})
			// 				}

			// 				uni.removeStorageSync('addressList')
			// 			} else {
			// 				uni.showToast({
			// 					icon: 'none',
			// 					title: res.data.msg
			// 				})
			// 			}
			// 		}, rej => {
			// 			uni.showToast({
			// 				icon: 'none',
			// 				title: res.data.msg
			// 			})
			// 		})
			// 	}

			// },
			butt1(total_money) {
				let self = this
				let pay_type = 0
				if (self.drinkFirst) {
					pay_type = '1'
				}
				if (self.outPayOrder == 1) {
					uni.showToast({
						title: '请先支付后付订单',
						icon: 'none'
					})
					return
				}
				if (self.timeStamp == '') {
					uni.showToast({
						title: '请选择配送时间',
						icon: 'none'
					})
					return
				}
				if (self.topTypeLinke == 0) {
					if (self.merchant_id == '') {
						uni.showToast({
							icon: 'none',
							title: '请选择领取地点'
						})
						return
					}
					if (self.value == '' || self.value == 0) {
						uni.showToast({
							icon: 'none',
							title: '请输入每日领取的数量'
						})
						return
					}
					if (self.value >self.goods_count) {
						uni.showToast({
							icon: 'none',
							title: '每日领取数量不可大于商品总数'
						})
						return
					}
					if (self.flage == false && self.flage1 == false) {
						self.flage = true
						self.flage1 = true
					} else {
						self.request({
							url: 'bashi/api/app.php?c=submitOrder',
							data: {
								expect_time: self.timeStamp,
								token: uni.getStorageSync('token'),
								goods_count: self.goods_count, //商品数量
								goods_index: self.goods_index, //商品编号
								merchant_id: self.merchant_id, //领取点地址id
								day_count: self.value, //每日领取份数
								area_type: self.topTypeLinke, //订单状态
								order_type: 0 //订单类型（首订订单与续订订单）
							},
						}).then(res => {
							if (res.data.success) {
								self.order_index = res.data.data.order_goods_data.order_index
								uni.navigateTo({
									url: './payment?id=' + self.order_index + '&total_money=' + total_money
								})
								uni.removeStorageSync('merchant_id')
								uni.removeStorageSync('distance')
								uni.removeStorageSync('merchant_address')
								uni.removeStorageSync('merchant_name')
								uni.removeStorageSync('logo')
							} else {
								uni.showToast({
									icon: 'none',
									title: res.data.msg
								})
							}
						}, rej => {
							uni.showToast({
								icon: 'none',
								title: res.data.msg
							})
						})
					}
				} 
				else {
					if (self.addressList == "") {
						uni.showToast({
							title: '请选择收货地址',
							icon: 'none'
						})
					}
					if (self.value == "") {
						uni.showToast({
							title: '请输入每日领取的数量',
							icon: 'none'
						})
						return
					}
					if (pay_type==1&&parseInt(self.value)> 3) {
						
						uni.showToast({
							title: '每日数量不可大于三份',
							icon: 'none'
						})
						return
					}
					let goodsNum = 0
					pay_type == 1 ? goodsNum = self.value * 30 : goodsNum = self.goods_count
					self.request({
						url: 'bashi/api/app.php?c=submitOrder',
						data: {
							expect_time: self.timeStamp,
							token: uni.getStorageSync('token'),
							goods_count: goodsNum, //商品数量
							goods_index: self.goods_index, //商品编号
							address_index: self.addressList.address_id, //收货地址id
							day_count: self.value, //每日领取份数
							area_type: self.topTypeLinke, //订单状态
							pay_type: pay_type //是否为先喝后付
						},
					}).then(res => {
						if (res.data.success) {
							self.order_index = res.data.data.order_goods_data.order_index
							if (self.drinkFirst === false) {
								uni.navigateTo({
									url: './payment?id=' + self.order_index + '&total_money=' + total_money
								})
							} else {
								uni.redirectTo({
									url: "./paymentSuccs?id=" + self.order_index + '&pay_type=1'
								})
							}

							uni.removeStorageSync('addressList')
						} else {
							uni.showToast({
								icon: 'none',
								title: res.data.msg
							})
						}
					}, rej => {
						uni.showToast({
							icon: 'none',
							title: res.data.msg
						})
					})
				}

			},
			// 打开消息通知
			setmessage() {
				let self = this
				self.addressList
				self.request({
					url: "bashi/api/app.php?c=setMessage",
					data: {
						token: uni.getStorageSync('token'),
						type: 1,
					},
				}).then(res => {
					if (res.data.success) {
						// 	uni.showToast({
						// 		icon:'none',
						// 		title: res.data.msg
						// 	})
						// 	self.value7="关闭消息提醒"
					}
				})

			},
			getFirstDrink() {
				let self = this
				self.request({
					url: "bashiadmin/api.php?p=bashiadmin&device=0&c=news%2FprotocolInfo&region=6",
					data: {}
				}).then(res => {
					if (res.data.success) {
						self.title_DringkFirst = res.data.data.title
						self.content_DringkFirst = res.data.data.htmlString
					} else {
						self.content_DringkFirst = '<view>后付款协议获取失败</view>'
					}
				})
			}
		},
		onLoad(options) {
			this.goods_index = options.id
			this.goods_icon = options.icon
			this.goods_name = options.name
			this.goods_cost = options.goods_cost
			this.goods_unit = options.goods_unit
			this.goods_price = options.goods_price
			this.later_pay = options.later_pay;
			this.arrive_address = options.arrive_address;
			// this.merchant_id=options.merchant_id
			// this.goods_cost=options.goods_cost
			this.cdnUrl = this.$cdnUrl
			this.init1()
			this.setmessage()
			let myDate = new Date();
			this.stystemYear = myDate.getFullYear();
			let mouthDate = new Date(myDate.getFullYear(), myDate.getMonth() + 1, 0).getDate()
			if (myDate.getDate() + 3 > mouthDate) {
				myDate.getMonth() + 1 < 10 ? this.stystemMonth = '0' + (myDate.getMonth() + 2) : this.stystemMonth = myDate
					.getMonth() + 2
			} else {
				myDate.getMonth() + 1 < 10 ? this.stystemMonth = '0' + (myDate.getMonth() + 1) : this.stystemMonth = myDate
					.getMonth() + 1
			}
			myDate.getDate() + 3 > mouthDate ? this.stystemDay = myDate.getDate() + 3 - mouthDate : this.stystemDay =
				myDate.getDate() + 3;
			this.stystemDay < 10 ? this.stystemDay = "0" + this.stystemDay : this.stystemDay
			this.timeValue = this.stystemYear + '-' + this.stystemMonth + '-' + this.stystemDay
			this.timeStamp = (Date.parse(new Date()) / 1000) + (86400 * 3);
			this.getAdressList()
		},
		onHide() {
			uni.removeStorageSync('addressList')
		},
		onUnload() {
			uni.removeStorageSync('addressList')
		},
		onShow() {
			this.getFirstDrink()
			this.merchant_id = uni.getStorageSync('merchant_id')
			this.distance = uni.getStorageSync('distance')
			this.merchant_address = uni.getStorageSync('merchant_address')
			this.merchant_name = uni.getStorageSync('merchant_name')
			this.logo = uni.getStorageSync('logo')
			uni.getStorageSync('addressList') ? this.addressList = uni.getStorageSync('addressList') : this.getAdressList()
			this.getPersonalInfo()
		}
	}
</script>


<style>
	page {
		background-color: #F5F5F5;
		position: relative;
		/* height: 100%; */
		/* padding: 30rpx; */
	}
</style>

<style scoped>
	.head1 {
		margin-top: 20rpx;
	}

	.font-30 {
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #333333;
	}

	.drinkFirst {
		height: 140rpx;
		background-color: #FFFFFF;
		margin-bottom: 20rpx;
		border-radius: 10rpx;
		padding: 0 30rpx;
	}

	.topTypeView {
		width: 345rpx;
		text-align: center;
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #3FA2E0;
	}

	.topTypeView1 {
		width: 345rpx;
		text-align: center;
		font-family: PingFang SC;
		font-weight: 500;
		font-size: 26rpx;
		color: #333333;
		margin-top: 10rpx;
	}

	.topType {
		display: flex;
		align-items: center;
		justify-content: space-between;
		width: 690rpx;
		height: 82rpx;
		background-size: 708rpx 82rpx;
	}

	.topType1 {
		background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAArIAAABSCAMAAACffMcZAAABZVBMVEUAAAD////////////////////////////////////19fX19fX////////////////////////8/Pz////8/Pz////39/f8/Pz8/Pz////////9/f3////////////9/f37+/v////4+Pj////9/f35+fn////////////7+/v+/v709PT19fX29vb4+Pj5+fn7+/v8/Pz+/v7////////////////////////////////////////////////////////////////7+/v////////////////////////////////////////////////////////////////////////8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////+uYIgGAAAAdnRSTlMAAQMEBQYIDA4YGRoaHigvQkRKU15eYGFkZWhqanB3io6PkKGnqqytr7Cws7Ozs7Ozs7OztLW2t7i5uru8vb6/wMHCw8TFxsjKy8zNzs/R09TV1tfY2tvb3d7f4OHj5Obn6ers7e7v8PHy8/T19vf4+fr7/P3+Btn5/wAAAkhJREFUeNrt2tdOVVEYhVF7x94Ve6cI2HsXK6KIXQQFCyqCcHx+rzXxQvZZm8xkfM8wsvJnZc6bJ0mS9EfLWq+NNX7pv5oc3LsKnTlqwwiAs2psLTxz0i4P7GwbX4PPHLSJ2NnXvwig2msZB69CrQTV3n7sqjS8BKGaWz6FXaW2M1RzO6Gr1sB8iOrtMHQVWwdRvQ0yV7EjENXbV+YqNt1CUa35lK3coW1qdhvXr17wL7LEVe5Ljwp0YMdKZEt1+YSaX0/PsS0LkS3TE74Kod29FNkijdJVyuyexciWqHGerkJmu7ciW6Q+uEo9s0dXIFuiEbhKme3ajGyJZs7AVYrsPmSLdB+uUsfsQWSLNARXKbKdyBZp6hRdyGbVSxeyWb2mC9msJuhCNqybeCGb1XO8kM1qHC9kw7rCF7JZDfCFbFYf+UI2q8YFwJDN6hFgyGb1HjBks5o5SxiyWT0gDNms3hGGbFY/jWaRDesOYshm9QYxZLP6cZIxZLO6xRiyWb1gDNmsvjGGbFhXIUM2q6eQIZvVJ8iQzapxkTJks+qnDNmsPlCGbNhlYDSLbFgPMUM2q2HMkM1q+jRnyGZ1lzNks3rLGbJZTRrNIhvWbdCQzeolaMhm9R00ZMO6ThqyWQ2ShmxWn0lDNqxLqCGb1WPUkM1qFDVks2qcYw3ZrPpYQzarEdaQzcpoFtm07sGGbFZDsCGb1ZTRLLJh9dLWHLJdyNbUqx41o25k62qiW02oq+t4B7I1daNTzaijHdmaetauZtTW9rfY30Qs9ImwZpMdAAAAAElFTkSuQmCC);
	}

	.topType2 {
		background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAqEAAABSCAMAAABT5f3yAAAAA3NCSVQICAjb4U/gAAABblBMVEUAAAD////////////////////////////////19fX19fX////////////////////////8/Pz////////8/Pz39/f6+vr6+vr8/Pz////6+vr////////////////7+/v7+/v////6+vr////8/Pz4+Pj////////////5+fn8/Pzy8vL09PT19fX29vb4+Pj5+fn7+/v8/Pz+/v7////////////////////////////////////////////+/v7////////////////7+/v////////////+/v7////////////////////////////////////////////////////////////8/Pz////////////////////////////////////////////////////////////////////////////+/v7+/v7////////////////////////////////////////////////41MAKAAAAeXRSTlMAAQMEBQgMDhgZGhoeKC9CREpUXV5gYWRlaGprcHF3io2PkKGnrKytr7Cws7Ozs7Ozs7Ozs7S1tre4ubq7vL2+v8DBwsPExcbIyMnLzM3Oz9HS1NXW19ja29vd3t/g4ePk5ufo6ers7e7v8PHy8/P09ff4+fr7/P3+ZGjRpgAAAAlwSFlzAAAOxAAADsQBlSsOGwAAAs1JREFUeJzt3WlvjFEYxvGDIvZ9jT0IEnTKoPat9qXWxl6U1pJSLca390zTeC+571w51/x/H2H+V3LenHlOKQAAAAA8Lds9Mv0H/6UzcXn7YnW4XrFqQp27UmNr1el6w8pJdelqdXao4/WCvofqzhXrrFPn6wHb1JWrNqnO52/hO3Xkuqn7+duiTlw5dT97856oE1dOHdDeanXh2qkD2jugLlw7dUB3y3+pC9fu3085f8Wa9ZsRbb86cPXm9rl0696BgWMI91UduHqz+1yw8RDzTHFB3bd+3YEu2tmaHehxRHus7lu/ZqB9u7oDVbf0NK7uW79moZv6GWiSMx113/qVsuRgixM+ybA6r4FSNvS3GGiSMXVeA6Xs4ZDPcuq3Oq+BUvax0Cx31XUdlHKUhWYZVdd1wELztGfUdR2w0Dw31XEtsNA8r9RxLbDQPFPquBZYaJohdVsPLDTNM3VbDyw0DV8aCcFCs1xUpzXBQrPwL+QYLDTLJ3VaEyw0yVmuhsZgoUkeqMu6YKFJPqjLumChOQa5GhqEhea4pw5rg4XmeKsOa4OFpjjxUx3WBgtNcUvd1QcLTfFa3dUHC83Q/qHu6oOFZrimzmqEhWZ4rs5qhIVm+KbOaoSFJrikruqEhSZ4qq7qhIUm+Kyu6oSFxjvH1dBALDQebyFHYqHxPqqjWmGh4QY55COx0HD31U29sNBwvCcfioVGO8lLnqFYaLTb6qRmWGi0N+qkZlhosPa0OqkZFhrsurqoGxYa7IW6qBsWGuy7uqgbFhrrijqoHRYaa0Qd1A4LjfVFHdQOCw11Xt3TDwsN9Ujd0w8LDTWu7umHhUY6zdXQcCw00rA6pyEWGum9OqchFhqIq6EJWGigO+qajlhooFF1TUdzC0WA9oy6pqPuQltMNMQNdUxLpRzpThQBXqpjWmoW2kwUEabUMS2VcriZKAJcVbf09BdPAVaE16TZfAAAAABJRU5ErkJggg==");
	}

	.head-time {
		border-radius: 0 0 10rpx 10rpx;
		background-color: #FFFFFF;
		display: flex;
		justify-content: space-between;
		margin-bottom: 20rpx;
		height: 80rpx;
		line-height: 80rpx;
		padding: 0 20rpx;
	}

	/* 头部 */
	.head {
		/* margin: 20rpx 0 0 0; */
		width: 100%;
		/* height: 160rpx; */
		display: flex;
		justify-content: space-between;
		background-color: #FFFFFF;
		border-radius: 10rpx;
		border-bottom: 2rpx solid #F5F5F5;
	}

	.head .img image {
		width: 60rpx;
		height: 60rpx;
		padding: 50rpx 35rpx 50rpx 30rpx;
		/* box-sizing: border-box; */
		flex: 1;
	}

	.head .img1 image {
		width: 140rpx;
		height: 140rpx;
		/* padding-left: 30rpx; */
		border-radius: 10rpx;
		/* margin-right: 30rpx; */
		padding: 10rpx 35rpx 0 30rpx;
		flex: 1;
	}

	.head .txt {
		flex: 1;
		font-family: PingFang SC;
		font-weight: 400;
		padding: 25rpx 0;
		box-sizing: border-box;
	}

	.head .txt .txt1 {
		font-size: 30rpx;
		padding-bottom: 20rpx;
		box-sizing: border-box;
		font-weight: 500;
		color: #333333;
	}

	.head .txt .txt2 {
		font-size: 24rpx;
		color: #9A9A9A;
	}

	.head .txt .txt3 {
		font-size: 26rpx;
		color: #333333;
	}

	.head .distance {
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #40A2E2;
		padding: 70rpx 30rpx 60rpx 50rpx;
	}

	.head-time image {
		width: 17rpx;
		height: 32rpx;
		vertical-align: middle;
		margin-left: 25rpx;
	}

	.head .distance image {
		width: 17rpx;
		height: 32rpx;
		vertical-align: middle;
		margin-left: 25rpx;
	}

	/* 订购数量 */
	.quantity {
		width: 100%;
		padding: 30rpx;
		padding-right: 0rpx;
		background-color: #FFFFFF;
		box-sizing: border-box;
	}

	.quantity .one {
		display: flex;
		border-bottom: 2rpx solid #F5F5F5;
		height: 170rpx;
		box-sizing: border-box;
	}

	.quantity .one image {
		width: 140rpx;
		height: 140rpx;
		border-radius: 6rpx;
		margin-right: 25rpx;
	}

	.quantity .one .txt {
		font-size: 28rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #343434;
		padding-right: 35rpx;
		box-sizing: border-box;
		display: flex;
		flex-direction: column;
		justify-content: space-between;
	}

	.quantity .one .txt .txt1 {
		height: 80rpx;
		overflow: hidden;
		text-overflow: ellipsis;
		display: -webkit-box;
		-webkit-line-clamp: 2;
		-webkit-box-orient: vertical;
	}

	.quantity .one .txt2 {
		font-weight: 400;
		color: #289CEC;
		padding-bottom: 30rpx;
	}

	.quantity .two {
		padding-top: 30rpx;
		box-sizing: border-box;
		border-bottom: 2rpx solid #F5F5F5;
		color: #343434;
	}

	.quantity .two .number {
		font-size: 28rpx;
		font-family: PingFang SC;
		font-weight: 500;
		margin-bottom: 20rpx;
	}

	.quantity .two .vase .inpvase {
		/* width: 510rpx; */
		width: 68%;
		height: 54rpx;
		background: #F5F5F5;
		border: 1rpx solid #CCCCCC;
		border-radius: 10rpx;
		padding: 0 20rpx;
		box-sizing: border-box;
		font-size: 26rpx;
		font-family: Source Han Sans CN;
		font-weight: 300;
		color: #999999;
	}

	.quantity .two .vase .inpvase1 {
		width: 68%;
		/* width: 510rpx; */
		height: 54rpx;
		background: #E2F5FF;
		border: 1rpx solid #3EA4E1;
		border-radius: 10rpx;
		padding: 0 20rpx;
		box-sizing: border-box;
		font-size: 26rpx;
		font-family: Source Han Sans CN;
		font-weight: 300;
		color: #999999;
	}

	.quantity .two .vase {
		display: flex;
		flex-wrap: wrap;
	}

	.quantity .two .vase .bom {
		width: 20%;
		/* width: 157rpx; */
		height: 54rpx;
		background: #F5F5F5;
		border: 1rpx solid #CCCCCC;
		border-radius: 10rpx;
		font-size: 26rpx;
		font-family: Source Han Sans CN;
		font-weight: 300;
		line-height: 54rpx;
		text-align: center;
		margin-right: 20rpx;
		margin-bottom: 20rpx;
	}

	.quantity .two .vase .bom1 {
		width: 20%;
		/* width: 157rpx; */
		height: 54rpx;
		background: #E2F5FF;
		border: 1rpx solid #3EA4E1;
		border-radius: 10rpx;
		font-size: 26rpx;
		font-family: Source Han Sans CN;
		font-weight: 300;
		line-height: 54rpx;
		text-align: center;
		margin-right: 20rpx;
		margin-bottom: 20rpx;
	}

	.quantity .three {
		display: flex;
		justify-content: space-between;
		padding-top: 35rpx;
		box-sizing: border-box;
		margin-right: 30rpx;
		font-size: 28rpx;
		font-family: PingFang SC;
		font-weight: 400;
	}

	.quantity .three .day {
		color: #343434;
	}

	.quantity .three .num {
		color: #9A9A9A;
		width: 138rpx;
		flex: 1;
	}

	.quantity .three .num input {
		text-align: right;
	}

	/* 合计金额 */
	.sum {
		display: flex;
		justify-content: space-between;
		height: 100rpx;
		width: 100%;
		line-height: 100rpx;
		font-size: 28rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #343434;
		background-color: #FFFFFF;
		padding: 0 30rpx;
		margin: 20rpx 0;
		box-sizing: border-box;
	}

	.sum .money {
		color: #3EA4E1;
	}

	/* 底部按钮 */
	.butt {
		position: fixed;
		bottom: 25rpx;
		left: 30rpx;
		width: 690rpx;
		height: 90rpx;
		background: #3EA4E1;
		border-radius: 45rpx;
		line-height: 90rpx;
		text-align: center;
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #FFFFFF;
	}

	/* 弹窗 */
	.beijing {
		position: fixed;
		width: 100%;
		height: 100%;
		left: 0;
		top: 0;
		background-color: rgba(0, 0, 0, .5);
		z-index: 222;
	}

	.tanchuang2 {
		position: fixed;
		left: 50%;
		top: 250rpx;
		transform: translateX(-50%);
		width: 560rpx;
		height: 680rpx;
		background-color: #FFFFFF;
		border-radius: 10rpx;
		text-align: center;
	}

	.tanchuang {
		position: fixed;
		left: 50%;
		top: 50%;
		transform: translate(-50%, -50%);
		width: 500rpx;
		/* height: 300rpx; */
		background: #FFFFFF;
		border-radius: 10rpx;
	}

	.tanchuang .title {
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #333333;
		text-align: center;
		margin: 30rpx 0;
	}

	.tanchuang .txt {
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #999999;
		padding: 0 30rpx 20rpx;
		box-sizing: border-box;
	}

	.tanchuang .know {
		width: 50%;
		text-align: center;
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #3DA3E1;
		padding: 20rpx 0;
		border-top: 1rpx solid #F5F5F5;
		box-sizing: border-box;
	}
</style>
