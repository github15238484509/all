<!-- 支付成功页面 -->
<template>
	<view>
		<view class="one">
			<image :src="cdnUrl+'bashi/image/moneySc.png'"></image>
			<view>{{pay_type?'预定':'支付'}}成功</view>
			<view v-if="oldPage==2">获得优惠：{{ausmon_money/100}}元，已存入余额。</view>
		</view>
		<view class="check" @click="examine()">查看我的预定</view>
		<view class="home" @click="home()">去首页逛逛</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				order_index:'',
				cdnUrl:'',
				pay_type:false,
				oldPage:"",//是先喝后付还是先付订单
				ausmon_money:"",//后付订单的分润
			}
		},
		onShareAppMessage: function () {
		    return {
		      title:'乃小星',
		      path: '/pages/index/index?scene=' + '1-'+uni.getStorageSync('phone')
		    }
		},
		methods: {
			// 转跳到查看我的预定页面
			examine(){
				uni.navigateTo({
					url:'../reserve/particulars?id='+this.order_index
				})
			},
			// 转跳到首页
			home(){
				uni.switchTab({
					url:'../index/index'
				})
			},
		},
		onLoad(options) {
			this.oldPage=options.order_type
			if(options.order_type==2)this.ausmon_money=options.use_mony
			this.order_index=options.id
			this.cdnUrl=this.$cdnUrl
			if (options.pay_type)this.pay_type=true
		}
	}
</script>

<style>
.one{
	text-align: center;
	font-size: 30rpx;
	font-family: PingFang SC;
	font-weight: 500;
	color: #343434;
	padding-top: 150rpx;
}
.one image {
	width: 146rpx;
	height: 185rpx;
	padding-bottom: 50rpx;
}
.check {
	width: 690rpx;
	height: 90rpx;
	background: #3EA4E1;
	border-radius: 45rpx;
	line-height: 90rpx;
	text-align: center;
	font-size: 30rpx;
	font-family: PingFang SC;
	font-weight: 500;
	color: #FFFFFF;
	margin: 50rpx 30rpx;
}
.home {
	width: 690rpx;
	height: 90rpx;
	background: #FFFFFF;
	border: 1rpx solid #3EA4E1;
	border-radius: 45rpx;
	font-size: 30rpx;
	font-family: PingFang SC;
	font-weight: 500;
	color: #3EA4E1;
	line-height: 90rpx;
	text-align: center;
	margin: 0 30rpx;
}
</style>
