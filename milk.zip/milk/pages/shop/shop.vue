<!-- 门店--今日是否领取页面 丢弃-->
<template>
	<view>
		<!-- 头部 head -->
		<view class="head">
			<view class="one">
				<view class="left">累计获得津贴（元）</view>
				<view class="right" @click="subsidy()">津贴记录>></view>
			</view>
			<view class="two">
				<view class="left">{{shopcount.merchant_cash}}</view>
				<view class="right" @click="balance()">前往余额</view>
			</view>
		</view>
		<!-- tab栏切换 -->
		<view class="big">
			<view class="tab">
				<block v-for="(item ,i) in tablist" :key="item.id">
					<view :class="seletedIndex==item.id?'txt1':''" @click="tabStatus(item.id)">
						{{item.tab1}}({{item.id=='1'?shopcount.count1:shopcount.count2}})<view class="label" v-if="seletedIndex==item.id"></view>
					</view>
				</block><view class="line"></view>
			</view>
			<view class="record" @click="record()">领取记录</view>
		</view>
		<!-- 门店列表shopList -->
		<view class="shopList" v-if="seletedIndex==0">
			<view class="bomm" v-for="(item,i) in shopList" :key='i'>
				<view class="up">
					<view class="left">
						<image :src="cdnUrl+item.photo" class="img"></image>
						{{item.name}}（{{item.phone}}）
					</view>
					<view class="butt" @click="replace()">代领</view>
				</view>
				<view class="down">
					<image :src="cdnUrl+item.goods_icon"></image>
					<view class="right">
						<view class="txt1">{{item.goods_name}}</view>
						<view class="txt2">今日待领取{{item.day_count}}瓶</view>
					</view>
				</view>
			</view>
		</view>
		<view class="shopList" v-else>
			<view class="bomm" v-for="(item,i) in shopList" :key='i'>
				<view class="up">
					<view class="left">
						<image :src="cdnUrl+item.photo" class="img"></image>
						{{item.name}}（{{item.phone}}）
					</view>
					<view>今日已领取{{item.day_count}}瓶</view>
				</view>
				<view class="down">
					<image :src="cdnUrl+item.goods_icon"></image>
					<view class="right">
						<view class="txt1">{{item.goods_name}}</view>
						<view class="txt2">{{item.delivery_time}}</view>
					</view>
				</view>
			</view>
		</view>
		
		<!-- 代领弹窗 -->
		<view class="replaceWin" v-if="replaceWin==true">
			<view class="window">
				<view class="title">代替顾客领取</view>
				<input placeholder="请输入客户手机号" :value='count' @input="getCount" @confirm='confirm'/>
				<view class="butt">
					<block v-for="(item,i) in buttList" :key='item.id'>
						<view :class="buttIndex==item.id?'txt1':''" @click="buttWin(item.id)">{{item.butt1}}</view>
					</block>
					<view class="line"></view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import uniIcons from "@/components/uni-icons/uni-icons.vue"
	export default {
		data() {
			return {
				tablist: [ // tab栏状态切换
					{tab1: "今日待领取",id: "0"},
					{tab1: "今日已领取",id: "1"},
				],
				seletedIndex: '0', //点击状态ID
				shopList:[],//门店列表
				// allowList:[],//津贴列表
				count:'',//手机号输入框
				shopcount:'',//data中的数据
				replaceWin:false,//代领弹窗
				buttList:[ // 弹窗按钮切换
					{butt1:'取消',id:'0'},
					{butt1:'确认',id:'1'}
				],
				buttIndex: '1', //按钮点击状态ID
				page:'0',//分页
				pageCount:'',//总页数
				delivery_index:'',//领取列表id
			}
		},
		methods: {
			// tab栏切换
			tabStatus(id) {
				this.seletedIndex = id
				this.shopList=[]
				this.init()
			},
			// 津贴记录转跳
			subsidy() {
				uni.navigateTo({
					url:'./subsidy'
				})
			},
			// init初始化
			init(){
				if(uni.getStorageSync('token')){
					let self=this
					self.request({
						url:'bashi/api/app.php?c=mer/merInfo',
						data:{
							token:uni.getStorageSync('token'),
							type:self.seletedIndex, // 领取状态
							page:self.page //分页
						},
					}).then(res=>{
						if(res.data.success){
							self.pageCount=res.data.pageCount
							self.shopList=res.data.data.list
							self.shopcount=res.data.data
							// self.delivery_index=res.data.data.list.delivery_index//领取列表id
						}else{
							if(res.data.msg=='登录状态失效，请重新登录~！'){
								uni.removeStorageSync('token')
								uni.navigateTo({
									url:'../my/login'
								})
							}else{
								uni.showToast({
									icon:'none',
									title:res.data.msg
								})
							}
						}
					},rej=>{
						uni.showToast({
							icon:'none',
							title:res.data.msg
						})
					})
				}
			},
			// 前往余额转跳
			balance(){
				uni.navigateTo({
					url:'../my/balance'
				})
			},
			// 领取记录转跳
			record(){
				uni.navigateTo({
					url:'./getRecord'
				})
			},
			// 当键盘输入时，触发input事件，event.detail = {value}
			getCount(e){
				this.count=e.detail.value
			},
			// 代领按钮跳转
			replace(){
				let self=this
				self.request({
					url:'bashi/api/app.php?c=mer/daiLing',
					data:{
						token:uni.getStorageSync('token'),
						delivery_index:self.delivery_index, //领取列表id
						replace_phone:self.count //代领手机号
					},
				}).then(res=>{
					if(res.data.success){
						uni.showToast({
							title:res.data.msg
						})
						self.init()
					}
				},rej=>{
					uni.showToast({
						title:res.data.msg
					})
				})
			},
			// 弹窗按钮切换
			buttWin(id){
				let self=this
				self.buttIndex=id
				self.replaceWin=true//代领弹窗
				if(self.buttIndex==0){
					self.replaceWin=false//代领弹窗
				}else{
					self.request({
						url:'bashi/api/app.php?c=mer/merInfo',
						data:{
							token:uni.getStorageSync('token'),
							delivery_index:self.delivery_index, // 领取列表id
							replace_phone:self.count //代领手机号
						},
					}).then(res=>{
						if(res.data.success){
							uni.showToast({
								icon:'none',
								title:res.data.msg
							})
							self.init()
						}else{
							uni.showToast({
								icon:'none',
								title:res.data.msg
							})
						}
						},rej=>{
							uni.showToast({
								icon:'none',
								title:res.data.msg
							})
						})
				}
			}
		},
		// 上拉加载(小程序自带函数)
		onReachBottom(){
			if(this.page<this.pageCount-1){
				this.page++
				this.init()
			}
		},
		onLoad(){
			this.cdnUrl=this.$cdnUrl
			this.init()
		},
	}
</script>

<style>
	page {
		background-color: #F5F5F5;
	}

	/* 头部 */
	.head {
		width: 750rpx;
		height: 260rpx;
		background: linear-gradient(0deg, #3EA4E1, #889AFE);
		padding: 60rpx 30rpx 0;
		box-sizing: border-box;
		position: fixed;
	}

	.head .one {
		display: flex;
		justify-content: space-between;
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #FFFFFF;
	}

	.head .one .right {
		text-decoration: underline;
	}

	.head .two {
		display: flex;
		justify-content: space-between;
		margin-top: 40rpx;
		font-family: PingFang SC;
		color: #FFFFFF;
	}

	.head .two .left {
		font-weight: bold;
		font-size: 50rpx;
	}

	.head .two .right {
		width: 135rpx;
		height: 50rpx;
		color: #FFFFFF;
		background: rgba(255, 255, 255, 0.3);
		border-radius: 25rpx;
		font-weight: 400;
		font-size: 26rpx;
		line-height: 50rpx;
		text-align: center;
	}

	/* tab栏切换 */
	.big {
		position: fixed;
		top: 250rpx;
		left: 0;
		width: 100%;
		display: flex;
		justify-content: space-between;
		border-radius: 10rpx 10rpx 0 0;
		border-bottom: 1rpx solid #F5F5F5;
		background-color: #FFFFFF;
	}
	.tab {
		width: 560rpx;
		height: 70rpx;
		display: flex;
	}
	.tab>view {
		width: 50%;
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #9A9A9A;
		line-height: 70rpx;
		text-align: center;
		position: relative;
	}
	.tab .line {
		width: 2rpx;
		height: 50rpx;
		background: #F5F5F5;
		position: absolute;
		left: 270rpx;
		top: 10rpx;
	}
	.tab .label {
		width: 100rpx;
		height: 2rpx;
		background: #3EA4E1;
		position: absolute;
		bottom: 0;
		left: 50%;
		margin-left: -50rpx;
	}

	.tab .txt1 {
		color: #3CA4DC;
	}
	
	.big .record {
		width: 154rpx;
		height: 50rpx;
		background: #3EA4E1;
		border-radius: 25rpx 0px 0px 25rpx;
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #FFFFFF;
		line-height: 50rpx;
		text-align: center;
		margin-top: 10rpx;
	}
	/* 门店列表 */
	.shopList {
		width: 100%;
		padding-top: 320rpx;
	}
	.shopList .bomm {
		margin-bottom: 20rpx;
		background-color: #FFFFFF;
	}
	.shopList .up {
		width: 100%;
		display: flex;
		justify-content: space-between;
		padding: 15rpx 30rpx;
		box-sizing: border-box;
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #9A9A9A;
	}
	.shopList .up .img{
		width: 50rpx;
		height: 50rpx;
		border-radius: 50%;
		margin-right: 22rpx;
		vertical-align: middle;
	}
	.shopList .up .butt {
		width: 135rpx;
		height: 50rpx;
		background: #3EA4E1;
		border-radius: 25rpx;
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #FFFFFF;
		text-align: center;
		line-height: 50rpx;
	}
	.shopList .down {
		margin-left: 40rpx;
		padding-right: 35rpx;
		border-top: 2rpx solid #F5F5F5;
		display: flex;
		padding-top: 20rpx;
		padding-bottom: 20rpx;
	}
	.shopList .down image {
		width: 140rpx;
		height: 140rpx;
		margin-right: 25rpx;
		border-radius: 6rpx;
	}
	.shopList .down .right {
		display: flex;
		flex-direction: column;
		justify-content: space-around;
		flex: 1;
	}
	.down .right .txt1{
		font-size: 28rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #343434;
	}
	.down .right .txt2 {
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #3EA4E1;
	}
	/* 代领弹窗 */
	.replaceWin {
		width: 100%;
		height: 100%;
		position: fixed;
		top: 0;
		left: 0;
		background-color: rgba(0,0,0,.5);
		z-index: 22;
	}
	.replaceWin .window {
		position: absolute;
		top: 50%;
		left: 50%;
		transform: translate(-50%,-50%);
		background:rgba(255,255,255,1);
		width: 600rpx;
		height: 400rpx;
		border-radius: 10rpx;
		box-sizing: border-box;
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #999999;
	}
	.replaceWin .title {
		font-weight: 500;
		color: #333333;
		padding: 50rpx;
		text-align: center;
	}
	.replaceWin input {
		width: 530rpx;
		border-bottom: 1rpx solid #F5F5F5;
		margin: 30rpx 30rpx;
	}
	.replaceWin .butt {
		width: 100%;
		border-top: 1rpx solid #F5F5F5;
		margin-top: 90rpx;
		padding: 30rpx 120rpx;
		display: flex;
		justify-content: space-between;
		box-sizing: border-box;
		position: relative;
	}
	.replaceWin .butt .line {
		position: absolute;
		top: 0;
		left: 300rpx;
		width: 2rpx;
		height: 90rpx;
		background: #F5F5F5;
		border-radius: 1px;
	}
	.replaceWin .butt .txt1 {
		color: #3FA2E0;
	}
</style>
