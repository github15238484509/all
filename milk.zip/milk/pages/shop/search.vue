<!-- 搜索页面 -->
<template>
	<view>
		<view class="status_bar">
			<view class="input">
				<input type="text" :value="value" confirm-type="search" @confirm="confirm" @input="getValue" placeholder="请输入手机号/昵称"/>
				<image src="../../static/search(1).png" class="search_img" @click="search"></image>
				<view class="del" @click="del" v-if="value">
					<image src="../../static/del.png" ></image>
				</view>
			</view>
			<view style="margin-left: 20rpx;" @click="search()">搜索</view>
		</view>
		<view>
			<view class="title">
				<view class="word">历史搜索</view>
				<view class="del" @click="empty"><image src="../../static/del1.png" mode=""></image></view>
			</view>
			<view class="history_list">
				<block v-for="(item,j) in list" :key="j">
					<view class="history" v-if="item" @click="jump(item)">{{ item }}</view>
				</block>
			</view>
		</view>
		
	</view>
</template>

<script>
export default {
	data() {
		return {
			list: [],
			value: ''
		};
	},
	onShareAppMessage: function () {
	    return {
	      title:'乃小星',
	      path: '/pages/index/index?scene=' + '1-'+uni.getStorageSync('phone')
	    }
	},
	methods: {
		//获取历史记录
		init() {
			let self = this;
			self.request({
				url: 'bashi/api/app.php?c=goods/searchHistory',
				data: {
					token: uni.getStorageSync('token')
				},
				}).then(res=>{
					if(res.data.success){
						self.list = res.data.data;
						console.log(self.list)
					}else{
						uni.showToast({
							icon:'none',
							title:res.data.msg
						})
					}
				},rej=>{
					uni.showToast({
						icon:'none',
						title:res.data.msg
					})
				})
		},
		//返回到上一页
		back() {
			uni.switchTab({
				url: './getRecord'
			});
		},
		//实时获取输入框的值
		getValue(e){
			this.value = e.detail.value
		},
		jump(e){
			this.value = e
			this.search()
		},
		//点击搜索跳到搜索页面
		search(){
			uni.navigateTo({
				url:'./getRecord?value='+this.value
			})
		},
		//清空输入框的值
		del(){
			this.value=''
		},
		//键盘点击搜索
		confirm(e){
			uni.navigateTo({
				url:'./getRecord?value='+e.detail.value
			})
		},
		//删除历史记录
		empty(){
			let self = this;
			self.request({
				url: 'bashi/api/app.php?c=mer/searchMer',
				data: {
					token: uni.getStorageSync('token')
				},
				}).then(res=>{
					if(res.data.success){
						self.init()
					}else{
						uni.showToast({
							icon:'none',
							title:res.data.msg
						})	
					}
				},rej=>{
					uni.showToast({
						icon:'none',
						title:res.data.msg
					})	
				})
		}
		
	},
	onShow() {
		this.init()
	}
};
</script>

<style lang="scss">
.status_bar {
	padding: 15rpx 30rpx;
	display: flex;
	font-size: 30rpx;
	font-family: PingFang SC;
	font-weight: 400;
	color: #333333;
	align-items: center;
	.input {
		width: 450rpx;
		height: 70rpx;
		padding: 0 70rpx 0 60rpx;
		line-height: 70rpx;
		height: 70rpx;
		background: rgba(238, 241, 244, 1);
		border-radius: 35rpx;
		position: relative;
		// box-sizing: border-box;
		input {
			height: 70rpx !important;
			line-height: 70rpx !important;
		}
		.search_img {
			width: 30rpx;
			height: 28rpx;
			position: absolute;
			top: 20rpx;
			left: 25rpx;
		}
		.del {
			width: 80rpx;
			height: 70rpx;
			position: absolute;
			top: 0;
			right: 0;
			text-align: center;
			image{
				width: 30rpx;
				height: 30rpx;
			}
		}
	}
}
.title {
	padding: 0 30rpx;
	display: flex;
	height: 70rpx;
	align-items: center;
	justify-content: space-between;
	.word {
		ont-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: rgba(51, 51, 51, 1);
	}
	.del {
		width: 50rpx;
		text-align: right;
		image {
			width: 32rpx;
			height: 32rpx;
		}
	}
}
.history_list {
	display: flex;
	padding: 0 30rpx;
	flex-wrap: wrap;
	.history {
		padding: 10rpx 40rpx;
		background-color: #f5f5f5;
		border-radius: 30rpx;
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: rgba(153, 153, 153, 1);
		margin: 20rpx 20rpx 0 0;
	}
}
</style>
