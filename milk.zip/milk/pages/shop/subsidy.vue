<!-- 门店--津贴记录 -->
<template>
	<view>
		<block v-if="subsidyList.length">
			<view class="list" v-for="(item,i) in subsidyList" :key="i">
				<view class="left">
					<view class="txt">{{item.msg}}</view>
					<view class="time">{{formatTime(item.time)}}</view>
				</view>
				<view class="right">{{item.type<100?'+':'-'}}{{item.amount/100}}</view>
			</view>
		</block>
		<view style="margin: 100rpx; text-align: center;" v-else>暂无更多数据</view>
	</view>
</template>

<script>
	import uniIcons from "@/components/uni-icons/uni-icons.vue"
	export default {
		data() {
			return {
				subsidyList:[],//津贴记录列表
				page:0,//分页
				pageCount:0,//总页数
			}
		},
		onShareAppMessage: function () {
		    return {
		      title:'乃小星',
		      path: '/pages/index/index?scene=' + '1-'+uni.getStorageSync('phone')
		    }
		},
		methods: {
			init(){
				if(uni.getStorageSync('token')){
					let self=this
					self.request({
						url:'bashi/api/app.php?c=mer/merCashChange',
						data:{
							token:uni.getStorageSync('token'),
							page:self.page //分页
						},
					}).then(res=>{
						if(res.data.success){
							self.pageCount=res.data.pageCount
							// self.subsidyList=res.data.data.list
							for(var i =0; i<res.data.data.list.length; i++){
								self.subsidyList.push(res.data.data.list[i])
							}
						}else{
							if(res.data.msg=='登录状态失效，请重新登录~！'){
								uni.removeStorageSync('token')
								uni.reLaunch({
									url:'../my/login'
								})
							}else{
								uni.showToast({
									icon:'none',
									title:res.data.msg
								})
							}
						}
					},rej=>{
						uni.showToast({
							icon:'none',
							title:res.data.msg
						})
					})
				}
			},
		},
		// 上拉加载(小程序自带函数)
		onReachBottom(){
			if(this.page<this.pageCount-1){
				this.page++
				this.init()
			}
		},
		onLoad(){
			this.subsidyList=[]
			this.page=0
			this.init()
		}
	}
</script>

<style>
.list {
	border-top: 1rpx solid #F5F5F5;
	border-bottom: 1rpx solid #F5F5F5;
	padding: 30rpx 0;
	display: flex;
	justify-content: space-between;
	font-size: 26rpx;
	font-family: PingFang SC;
	font-weight: 400;
	color: #333333;
	align-items: center;
	margin: -1rpx;
}
.list .left {
	display: flex;
	flex-direction: column;
	padding-left: 30rpx;
}
.list .left .time {
	font-size: 22rpx;
	color: #999999;
	padding-top: 20rpx;
}
.list .right {
	padding-right: 30rpx;
	font-weight: 500;
	color: #3EA3E2;
}
</style>
