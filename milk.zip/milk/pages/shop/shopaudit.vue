<!-- 门店审核进度页面 -->
<template>
	<view>
		<!-- steps步骤条  纵向排列-->
		<uni-steps :options="options" direction="column" :active="0" v-if="statedata.merchant_status==0"></uni-steps>
		<view v-if="statedata.merchant_status==-1">
			<uni-steps :options="options1" direction="column" :active="2" ></uni-steps>
			<view class="txt">失败原因：{{statedata.merchant_refuse}}<text @click="resubmit()">重新提交</text></view>
		</view>
	</view>
</template>

<script>
	import uniSteps from '@/components/uni-steps/uni-steps.vue'
	import uniIcons from "@/components/uni-icons/uni-icons.vue"
	import formatTime from "@/until/app.js"
	
	export default {
		components: {uniSteps},
		data() {
			return {
				options:[
					{title:'信息提交成功,等待审核',desc:'2019-04-19 17:27'},
				],//格式源
				options1:[
					{title:'信息提交成功,等待审核',desc:'2019-04-19 17:27'},
					{title:'信息审核失败',desc:'2019-04-19 17:27'},
				],				
				active:'0',//当前步骤
				state:'0',//切换审核进度是否成功
				statedata:[],//数据集合
			}
		},
		onShareAppMessage: function () {
		    return {
		      title:'乃小星',
		      path: '/pages/index/index?scene=' + '1-'+uni.getStorageSync('phone')
		    }
		},
		methods: {
			// init初始化
			init(){
				if(uni.getStorageSync('token')){
					let self=this
					self.request({
						url:'bashi/api/app.php?c=mer/merCheck',
						data:{
							token:uni.getStorageSync('token'),
						},
					}).then(res=>{
						if(res.data.success){
							self.statedata=res.data.data
							if(self.statedata.merchant_status==0){
								// self.options[0].desc=self.statedata.submit_time
								self.options[0].desc=self.formatTime(self.statedata.submit_time)
							}
							if(self.statedata.merchant_status==-1){
								self.options1[0].desc=self.formatTime(self.statedata.submit_time)
								self.options1[1].desc=self.formatTime(self.statedata.audit_time)
							}
						}else{
							if(res.data.msg=='登录状态失效，请重新登录~！'){
								uni.removeStorageSync('token')
								uni.reLaunch({
									url:'../my/login'
								})
							}else{
								uni.showToast({
									icon:'none',
									title:res.data.msg
								})
							}
						}
					},rej=>{
						console.log(rej)
					})
				}else{
					uni.redirectTo({
						url:'../my/login'
					})
				}
			},
			// 重新提交文字==>转跳到门店申请页面
			resubmit(){
				uni.navigateTo({
					url:'../shop/applyEnter'
				})
			}
		},
		onLoad(options){
			this.cdnUrl=this.$cdnUrl
			this.init()
		}
	}
</script>

<style>
.txt {
	font-size: 24rpx;
	font-family: PingFang SC;
	font-weight: 500;
	color:rgb(26, 173, 25);
	margin: -5rpx 50rpx;
}
.txt text {
	color: #3EA4DC;
	margin-left: 20rpx;
}
</style>
