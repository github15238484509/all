<!-- 门店是否入驻页 / 门店列表详情页面 -->
<template>
	<view v-if="render">
		<view class="img" v-if="enter==1">
			<image :src="cdnUrl+'bashi/image/noenter.png'"></image>
			<view class="butt" @click="goenter()">立即入驻</view>
		</view>
		<view class="img" v-if="enter==2">
			<image :src="cdnUrl+'bashi/image/planenter.png'"></image>
			<view class="butt" @click="goschedule()">查看审核进度</view>
		</view>
		<view v-if="enter==3">
			<!-- 头部 head -->
			<view class="head">
				<view class="one">
					<view class="left">累计获得津贴（元）</view>
					<view class="right" @click="subsidy()">津贴记录>></view>
				</view>
				<view class="two">
					<view class="left">{{fmoney(shopcount.merchant_cash/100)}}</view>
					<view class="right" @click="balance()">前往余额</view>
				</view>
			</view>
			<!-- tab栏切换 -->
			<view class="big">
				<view class="tab">
					<block v-for="(item ,i) in tablist" :key="item.id">
						<view :class="seletedIndex==item.id?'txt1':''" @click="tabStatus(item.id)">
							{{item.tab1}}({{item.id=='1'?shopcount.count1:shopcount.count2}})<view class="label" v-if="seletedIndex==item.id"></view>
						</view>
					</block><view class="line"></view>
				</view>
				<view class="record" @click="record()">领取记录</view>
			</view>
			<!-- 门店列表shopList -->
			<view class="shopList" v-if="seletedIndex==0">
				<view class="bomm" v-for="(item,i) in shopList" :key='i'>
					<view class="up">
						<view class="left">
							<image :src="cdnUrl+item.photo" class="img"></image>
							{{item.name}}（{{item.phone}}）
						</view>
						<view class="butts" v-if="carflage==true && delivery_peisong!=3">代领</view>
						<view class="butt" @click="replace(item.delivery_index)" v-else>代领</view>
					</view>
					<view class="down">
						<image :src="cdnUrl+item.goods_icon"></image>
						<view class="right">
							<view class="txt1">{{item.goods_name}}</view>
							<view class="txt2">今日待领取{{item.day_count}}瓶</view>
						</view>
					</view>
				</view>
			</view>
			<view class="shopList" v-else>
				<view class="bomm" v-for="(item,i) in shopList" :key='i'>
					<view class="up">
						<view class="left">
							<image :src="cdnUrl+item.photo" class="img"></image>
							{{item.name}}（{{item.phone}}）
						</view>
						<view>今日已领取{{item.day_count}}瓶</view>
					</view>
					<view class="down">
						<image :src="cdnUrl+item.goods_icon"></image>
						<view class="right">
							<view class="txt1">{{item.goods_name}}</view>
							<view class="txt2">{{formatTime(item.delivery_time)}}</view>
						</view>
					</view>
				</view>
			</view>
			
			<!-- 代领弹窗 -->
			<view class="replaceWin" v-if="replaceWin==true">
				<view class="window">
					<view class="title">代替顾客领取</view>
					<input placeholder="请输入客户手机号" :value='count' @input="getCount" @confirm='confirm' type="number"/>
					<view class="butt">
						<block v-for="(item,i) in buttList" :key='item.id'>
							<view :class="buttIndex==item.id?'txt1':''" @click="buttWin(item.id)">{{item.butt1}}</view>
						</block>
						<view class="line"></view>
					</view>
				</view>
			</view>
			
			<!-- 确认送达弹窗 -->
<!-- 			<view class="delivery" v-if="carflage==true && delivery_peisong!=4">
				<view class="carimg">
					<image src="../../static/car1.png"></image>
				</view>
				<view class="text">确定今天的鲜奶已送达了吗？若已送达请点击右方按钮。</view>
				<view class="carbtn" @click="carbtn()">确认送达</view>
			</view> -->
		</view>
		<!-- 账号注销提示弹窗 -->
		<view class="beijing" v-if="showStatusModel==true">
			<view class="tanchuang1">
				<view style="width: 100%;height: 366rpx;"></view>
				<view class="txt" >您提交的注销申请正在审核中，请耐心等待。</view>
				<view class="btn" @click="cancelAccount">取消注销</view>
			</view>
		</view>
		<!-- 支付弹窗 -->
		<view class="beijing" v-if="showOrderModel==true">
			<view class="tanchuang2">
				<view class="headImg">
					<view class="txt1" >您有先喝奶后付款订单暂未支付！</view>
					<view class="txt2">请先支付订单</view>
				</view>
				<view class="txt" >
					<view>订单编号：{{personInfor.order_id}}</view>
					<view>下单时间：{{$timeConvert(personInfor.order_time)}}</view>
					<view>预定数量：{{personInfor.goods_count }}</view>
					<view>领取数量：{{personInfor.getcount}}</view>
				</view>
				<view class="txt" style="border-bottom: 0;">
					<view>订单金额：{{personInfor.order_total_price/100}}</view>
					<view>实付金额：{{personInfor.pay_money/100}}</view>
				</view>
				<view class="btn"  style="margin-top: 50rpx;" @click="goPayOrder">立即支付</view>
			</view>
		</view>
	</view>
</template>

<script>
	import uniIcons from "@/components/uni-icons/uni-icons.vue"
	export default {
		data() {
			return {
				personInfor:{
					order_id:"",
					order_time:'0',
					goods_count:"",
					order_total_price:"0",
					pay_money:"0",	
					getcount:""
				},//未付订单信息
				showOrderModel:false,//是否弹出支付窗口
				showStatusModel:false,// 是否显示注销提示弹窗
				render:false,
				enter:1 ,//判断当前需要显示哪个按钮
				statedata:[],//数据集合
				tablist: [ // tab栏状态切换
					{tab1: "今日待领取",id: "0"},
					{tab1: "今日已领取",id: "1"},
				],
				seletedIndex: '0', //点击状态ID
				shopList:[],//门店列表
				// allowList:[],//津贴列表
				count:'',//手机号输入框
				shopcount:'',//data中的数据
				replaceWin:false,//代领弹窗
				buttList:[ // 弹窗按钮切换
					{butt1:'取消',id:'0'},
					{butt1:'确认',id:'1'}
				],
				buttIndex: '1', //按钮点击状态ID
				page:0,//分页
				pageCount:0,//总页数
				delivery_index:'',//领取列表id
				cdnUrl:'',
				carflage:false,//确认送达弹窗
				delivery_peisong:'',//订单状态
			}
		},
		onShareAppMessage: function () {
		    return {
		      title:'乃小星',
		      path: '/pages/index/index?scene=' + '1-'+uni.getStorageSync('phone')
		    }
		},
		methods: {
			// 取消注销
			cancelAccount(){
				let self=this;
				self.request({
					url:'bashi/api/app.php?c=personal/CancelLogout',
					data:{
						token:uni.getStorageSync('token'),
					}
				}).then(res => {
				        if (res.data.success) {
							this.showStatusModel=false
							uni.showToast({
								title: '取消成功',
								icon: 'none',
							})
				        } else {
				                uni.showToast({
									title: res.message,
									icon: 'none'
				                })
				        }
				})
			},
			// 跳转到支付页面
			goPayOrder(){
				let self=this;
				uni.navigateTo({
					url:'../commodity/payment?id='+self.personInfor.order_index+'&total_money='+self.personInfor.pay_money/100+'&order_type='+'2'
				})	
			},
			// 获取用户账号信息
			getPersonalInfo(){
				let self=this
				self.request({
					url:'bashi/api/app.php?c=personal/getPersonalInfo',
					data:{
						token:uni.getStorageSync('token')
					}
				}).then(res=>{
					if(res.data.success){
							if(res.data.data.order==1){
								self.showOrderModel=true
								self.request({
									url:'bashi/api/app.php?c=reserve/reverseInfo',
									data:{
										token:uni.getStorageSync('token'),
										order_index:res.data.data.order_index,
										lat: 34.74725,
										lng: 113.62493
									}
								}).then(result => {
								        if (result.data.success) {
											self.personInfor=result.data.data
								        } 
								})
						}
						else if(res.data.data.status==1){
							self.showStatusModel=true
						}
					}else{
						uni.removeStorageSync('token')
					}
				});
			},
			// init初始化==>门店状态
			init(){
				if(uni.getStorageSync('token')){
					let self=this
					uni.showLoading({
					    title: '加载中'
					});
					self.request({
						url:'bashi/api/app.php?c=mer/merCheck',
						data:{
							token:uni.getStorageSync('token'),
						},
					}).then(res=>{
						if(res.data.success){
							self.statedata=res.data.data
							if(self.statedata.merchant_status==-2){
								self.enter=1
							}
							if(self.statedata.merchant_status==0||self.statedata.merchant_status==-1){
								self.enter=2
							}
							if(self.statedata.merchant_status==1){
								self.enter=3
								self.shopinit()
							}
							self.render=true
							uni.hideLoading()
						}else{
							// if(res.data.msg=='登录状态失效，请重新登录~！'){
								uni.removeStorageSync('token')
								uni.redirectTo({
									url:'../my/login'
								})
							// }else{
							// 	uni.showToast({
							// 		icon:'none',
							// 		title:res.data.msg
							// 	})
							// }
						}
					},rej=>{
						console.log(rej)
					})
				}else{
					uni.redirectTo({
						url:'../my/login'
					})
				}
			},
			// 立即入驻
			goenter(){
				uni.navigateTo({
					url:'../../pagesB/applyEnter'
				})
			},
			// 查看进度
			goschedule(){
				uni.navigateTo({
					url:'./shopaudit'
				})
			},
			// shopinit初始化==>获取门店领域页面记录
			shopinit(){
				if(uni.getStorageSync('token')){
					let self=this
					self.request({
						url:'bashi/api/app.php?c=mer/merInfo',
						data:{
							token:uni.getStorageSync('token'),
							type:self.seletedIndex, // 领取状态
							page:self.page //分页
						},
					}).then(res=>{
						if(res.data.success){
							self.pageCount=res.data.pageCount
							for(var i=0; i<res.data.data.list.length; i++){
								self.shopList.push(res.data.data.list[i])
							}
							self.shopcount=res.data.data
							if(self.shopList.length){
								self.delivery_peisong=self.shopList[0].delivery_peisong
								self.carflage=true
							}
						}else{
							if(res.data.msg=='登录状态失效，请重新登录~！'){
								uni.removeStorageSync('token')
								uni.navigateTo({
									url:'../my/login'
								})
							}else{
								uni.showToast({
									icon:'none',
									title:res.data.msg
								})
							}
						}
					},rej=>{
						uni.showToast({
							icon:'none',
							title:res.data.msg
						})
					})
				}
			},			
			// tab栏切换
			tabStatus(id) {
				this.seletedIndex = id
				this.shopList=[]
				this.page=0
				this.init()
			},
			// 津贴记录转跳
			subsidy() {
				uni.navigateTo({
					url:'./subsidy'
				})
			},
			// 前往余额转跳
			balance(){
				uni.navigateTo({
					url:'../my/balance'
				})
			},
			// 领取记录转跳
			record(){
				uni.navigateTo({
					url:'./getRecord'
				})
			},
			// 当键盘输入时，触发input事件，event.detail = {value}
			getCount(e){
				this.count=e.detail.value
			},
			// 代领按钮跳转
			replace(delivery_index){
				let self=this
				self.replaceWin=true//代领弹窗
				this.delivery_index=delivery_index
			},
			// 弹窗按钮切换
			buttWin(id){
				let self=this
				// self.buttIndex=id
				if(id==1){
					self.request({
						url:'bashi/api/app.php?c=mer/daiLing',
						data:{
							token:uni.getStorageSync('token'),
							delivery_index:self.delivery_index, //领取列表id
							replace_phone:self.count //代领手机号
						},
					}).then(res=>{
						console.log(self.count);
						if(res.data.success){
							uni.navigateTo({
								url:'./shopwin'
							})
							self.replaceWin=false//代领弹窗
							this.count=''
							self.init()
						}else{
							uni.showToast({
								icon:'none',
								title:res.data.msg
							})
						}
					},rej=>{
						uni.showToast({
							title:res.data.msg
						})
					})
				}else{
					self.replaceWin=false//代领弹窗
					this.count=''
				}
			},
			// 确认送达按钮
			// carbtn(){
			// 	let self=this
			// 	self.request({
			// 		url:'bashi/api/app.php?c=courier/merchant_delivery',
			// 		data:{
			// 			token:uni.getStorageSync('token'),
			// 		},
			// 	}).then(res=>{
			// 		if(res.data.success){
			// 			uni.showToast({
			// 				icon:'none',
			// 				title:res.data.msg
			// 			})
			// 			self.carflage=false
			// 		}else{
			// 			uni.showToast({
			// 				icon:'none',
			// 				title:res.data.msg
			// 			})
			// 		}
			// 	},rej=>{
			// 		uni.showToast({
			// 			icon:'none',
			// 			title:res.data.msg
			// 		})
			// 	})
			// },
		},
		// 上拉加载(小程序自带函数)
		onReachBottom(){
			if(this.page<this.pageCount-1){
				this.page++
				this.init()
			}
		},
		onShow(){
			this.showOrderModel=false
			this.showStatusModel=false
			this.getPersonalInfo()
			this.init()
			this.shopList=[]
			this.page=0
			this.cdnUrl=this.$cdnUrl
		},
	}
</script>

<style>
.img {
	font-size: 30rpx;
	font-family: PingFang SC;
	font-weight: 500;
	color: #FFFFFF;
}
.img image {
	width: 402rpx;
	height: 417rpx;
	margin: 100rpx 170rpx;
}
.img .butt {
	width: 560rpx;
	height: 90rpx;
	background: #3DA3E1;
	border-radius: 45rpx;
	text-align: center;
	line-height: 90rpx;
	margin: 0 auto;
}
.tanchuang2 .headImg{
	background-size: 560rpx 140rpx;
	height: 140rpx;
	border-radius: 10rpx;
	background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAjAAAACMCAMAAABVuGN6AAABIFBMVEUAAAD////b2//b///////h8P/q8//t8//k8P/j8f/u9P/g7v/r9P/i7//s8//h8P/s9f/h8P/s9P/i7//s9P/i7//i8f/s9f/U6fzV6fzV6vzW6vzW6/zX6vzX6/zX6/3X7f/Y6/zY6/3Y7P3Y7f7Y7f/Z6/zZ7P3Z7f7Z7f/a7Pza7P3a7f3a7f7a7v/b7Pzb7f3b7f7b7f/b7v7b7v/c7f7c7v7c7v/d7f3d7v7d7v/e7v3e7v7e7v/e7/7e7//f7v3f7//g7/7g7//g8P/h7/3h7/7h7//h8P/i8P7i8P/j8P7j8P/j8f/k8f7k8f/l8f7l8f/m8f/m8v/n8v7n8v/o8v/o8//p8v7p8v/p8/7p8//q8//r8//r9P/s9P+HpXMuAAAAGHRSTlMAAgcHB1VVVVZaWltbk5Orq9/f4+Pk+Pg6jiyrAAAEaUlEQVR42u3daVvTMADA8Xrf94n3MXWoEw8cImopRWCBWetYQbra7/8tlInAumZNpttTk//vffpi+z9N0q2t42w7ePL8xWsp/muhGJ2rF86dOOjsOnqZj/u/90OM2KUjO7kcOMunbYDvYuTOHOgGQy/MSKrFbPdyjM/aCGtjCEYcd5zDrF+M0BlHL+LKIec0n3XJvvnW2rLnef5aq6MzrD2WYMQp5zxfUZnEwt0j4nItYX4551zkSyqPJHB7BUmpljBCXHC4Xlei2ch3s3zFeSkZTy/iqsPXVJ5ePLefp1ZMPKZgBMGUZz5amM2zoDQrRQRjndXZfKsqg1sEY5vNWZlNlU3SypgQTFks1WWWFEYHBGPbircup7DuXSMYy3x9JfeleLggGMssDAhmgWCQ9bYmVy8evkIwlnk+CMEg68kgBAOdYJ4RDLJePpR7STDImhsQzBy7JGStPpBT+DWJC3e22bort1U8vEkwtnl3R+adwmh+fLTO+i2ZdYXRLYKxzvzNfPMqgyOCsU7y9Eaep0r/uIsJxsJ17/2cXu5vqdVGMDYW87ivl8dbimMFwdg4K81N9JpTvi8pJBg790pT1/dMrasPbBOMpTY/T92euD5xe+rzps6wDsFAiyAY6AgJBjoigoGOHwSDEs5JBGOMmGBQvn0SwZijRTDQkRAMSrfsJRiDdAgGZTvFEAynGIJho0QwUNsoCYKBjohgoCUgGJRp3UswTEoEw8WYkQkJhp2SBpEQDMsYDZ2UYAy0MapeNlKCYeGrLkoJxlAjuQ+ynRKMsUbwo1IrJRhbivE/1mvVSqVSrdU/+n/VC8FYUIxbq+xXc/+iF4IxfuXr9ebSTcYbbv1CMGbbvlFpsV7J82ZRr5e9N64TjME6wq9W8lV1ljJi3yvhCMboYuoVmar6tBTsfwwWwZjcy2rjg7wYX+NyHcHYIPnSaDSW3kiLUVrHBJk3lBKMub41uj7J1jHTCquXKHtQgjF3k/TnZfbLM4/yFV6QafU/xJNgjBWIXX5+MpMFf5bKe182wRh/ghmQjKubC8GYKxS9lt8/upc1uSiRNxkRjNlbJNHPm84W4+XmEsTy4xKMoSKRZ9md7jnPzPSfW8Jo4OPqCcbUPbWQ8d+/3o3mRU8sImh3io5LMObvkfLONJ47Mz35a5/UPamsiGbQasdKL8IgGEOp3WsitI9LMIZS/KGIYEAwIBiwhkGpNJWCaRIMflN7hkNIMPgtGuLfdARjMbXnyCcEgx0qD7sLUoLBDpVnfmwQDDT2Sc2UYLAr1rifkWBQvLMOU4LB/o2SKHjAIcGgR0co3jBNMCgqZsheCMbSYobthWBMX8fkr3zDJCUY5O+u+6/HNOPhD0cwFiQTKN91RDDoTkxR2FzZvj+gWXDXEcHgHyMYEAwIBgQDggHBAAQDggHBgGBAMCAYgGBAMCAYEAwIBgQDEAwIBgQDggHBAAQDggHBgGBAMCAYgGBAMCAYEAwIBgQDEAwIBgQDgoFhfgLzLCBwkc7PowAAAABJRU5ErkJggg==);
}
.tanchuang2 .headImg .txt1{
	font-size: 30rpx;
	font-family: PingFang SC;
	font-weight: bold;
	color: #3DA3E1;
	padding: 40rpx 0rpx 0 20rpx;
	text-align: left;
}
.tanchuang2 .headImg .txt2{
	font-size: 26rpx;
	font-family: PingFang SC;
	font-weight: 400;
	color: #3DA3E1;
	text-align: left;
	padding: 10rpx 0rpx 0 20rpx;
}
	/* 头部 */
	.head {
		width: 750rpx;
		height: 260rpx;
		background: linear-gradient(0deg, #3EA4E1, #889AFE);
		padding: 60rpx 30rpx 0;
		box-sizing: border-box;
		position: fixed;
	}

	.head .one {
		display: flex;
		justify-content: space-between;
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #FFFFFF;
	}

	.head .one .right {
		text-decoration: underline;
	}

	.head .two {
		display: flex;
		justify-content: space-between;
		margin-top: 40rpx;
		font-family: PingFang SC;
		color: #FFFFFF;
	}

	.head .two .left {
		font-weight: bold;
		font-size: 50rpx;
	}

	.head .two .right {
		width: 135rpx;
		height: 50rpx;
		color: #FFFFFF;
		background: rgba(255, 255, 255, 0.3);
		border-radius: 25rpx;
		font-weight: 400;
		font-size: 26rpx;
		line-height: 50rpx;
		text-align: center;
	}

	/* tab栏切换 */
	.big {
		position: fixed;
		top: 250rpx;
		left: 0;
		width: 100%;
		display: flex;
		justify-content: space-between;
		border-radius: 10rpx 10rpx 0 0;
		border-bottom: 1rpx solid #F5F5F5;
		background-color: #FFFFFF;
	}
	.beijing {
		position: fixed;
		width: 100%;
		height: 100%;
		left: 0;
		top: 0;
		background-color: rgba(0,0,0,.5);
	}
	.tanchuang2 {
		position: fixed;
		left: 50%;
		top: 250rpx;
		transform: translateX(-50%);
		width: 560rpx;
		height: 680rpx;
		background-color: #FFFFFF;
		border-radius: 10rpx;
		text-align: center;
	}
	.tanchuang2 .txt{
		padding: 20rpx;
		text-align: left;
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #999999;
		line-height: 50rpx;
		border-bottom: 2rpx solid #F5F5F5;
	}
	.tanchuang2 .btn{
		width: 440rpx;
		height: 80rpx;
		border-radius: 40rpx;
		background-color: #3DA6DE;
		color: #FFFFFF;
		line-height: 80rpx;
		margin: 0rpx auto;
		box-shadow: 0px 5px 7px 0px rgba(46, 94, 204, 0.35);
	}
	.tanchuang1 {
		position: fixed;
		left: 50%;
		top: 250rpx;
		transform: translateX(-50%);
		width: 500rpx;
		height: 640rpx;
		background-color: #FFFFFF;
		border-radius: 10rpx;
		text-align: center;
		background-size: 100% 100%;
		background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAfQAAAKACAYAAABqjYrAAAEeE0lEQVR42ux997csxXXurPfL+6ueg6wcyVEizHT3WLJsK/jJ9rNly5JQzhgJJBSACwIkMpww4cyZmSMrIAtJSICQhRBcbk7TVTcAF/pV9aTqqr137erpOfcCh7V6ncs5M91Vu/b+vm/vCl2rAf+9ZeX3/zv5L3lZc3j8B80t+cfm1vFT6meWX8PJzyqv2T2F57OCcT+xWBsY/Usq7fMy7LjNz61qDBb+Lty/ZNn9HRaflVDPrXKMhuYlYDsOl+ibw2r9NFnG2A3D25lsk6+EtUUs/OxkO+J/GBDLwwqxaXgmcI6ytfC3Zxg0rqdyLlacrLlZc3SN818yFBeqwHo2cRon5gE39AQK1NChdT8fgQ7dYE8WHUCjzQkIJAIl92TIA4dkQdBOrLYmZpuH+H3s9k3HzAG1oR80EmyMhwiZzJ4jvGPvEpHP4Yv/79pALEBEAm/TkCn4iM8V7DrkEU1iPwtoK+i7RrsTr0gSxbHeIsZ4C4gZYuySssCL3COx2+kb/yEDE4bC73ND3F8TZCwT3z0CnpUEig3cbwiBSdqeYdehGfNEjA1FMPkmRp+SIcEpQ6hNWJuBOBhiglIQvm/jXSBxB2Ie1NecoxVXo0T+sSz7Xyp4ri0aAQB4KuiHhPMNYRAC7z0MzJwBB0swEhwiwTojRQGSVbJFC4xkiyCCWT/FzFmSoYQJF7BvggWjZb/EcUDDFmDgCZhsiLFNhgC5OvYUPGE2hH4nSAGRDPHgTVA/E7BYQoRLYgikBOg37JsC8CUsBoTrm0NADIDiQvjBeGiB7dDok09E+0jRJ+qHEvWpxBO/ybAEyFFk7whcK5Ycgha4KLcxAhi/uc8IXGxDMThkEP5QwP7h4KyAhT8kEEFMF1Y/p8kcJvYFXRGiiBUT9p6KbTKEbdKE7GBVsRJEqCVWVp1s0X6e2DYgkpTEIzaSLStGObaYtVtcq7nbzcw1mYOAKgoPS2xgRYJx3sixQktQkjAHBfj3UIID4xhlKGeO52bzopjhIAQwD0zhGLdoaAE7oe00Rr8TBEzgrE64TgtlapaASaBAQYFaINmfgAnPcUyBg/HQEiIeYk4ckBGO76EZNPX/Q6v0BYmJreK4JlAmBgjVZIiJLAGCZYJmfcLo3xw4oTaiRGRVnsDKAPJslzQQEQ+Jw6Ed54AQxdo6+c74MwKuZExj0cIAF0ug71mZlA26dqY+tMkM9tdkKEC7uz4vHKIvkjgQx1uWWABFtIBj2Kk6CPd3QxczbLvYGA8lDFg8JkO8spHYAt7BUgEIQuEIY0qsJFhSBvo6kDANkURjZheBV6cgH53yCCI4inYRrh8MJZyQOYJOXOuU2UHAhObokMEGB9YxkMAzakixFshMWMallZEtQLBsIhkiYFkIIFhAJJDosJ9rgWViggLxfCeoLSJNhrDASrAMtDB2sFhKhnRZfAZUGCBszfsHEUdiiZ4EBRoBZF8TsrMCAc5yBVytQUqT835QAkK49/ZmX4CYs+00LI5lYoGHXXpMtgBg3XJBDAIXdM4drH4IRxAkQ6IKNhT+KoM9FlAGOnR93RXbAozhgqAe4tiUbAmYBA1ySZx2CTDbTEwRhGEggp+m3ydI9gz64pawcJD22cQROEh2C+BWgvRnNg5DW3wJoFTuCuaCMAGqW0VfEx6yJqbNiOqtjT0JMOWRAP7VBOIUHnO3GpFAotgj3AsCDRBe+vrrLXFRTuZ/u5L97+RHuh5vB5koEvGwSMxFRxQGAAk3KG2HtR15C+kkYSi3YmC0YSjAe0GkmwAObjpqMVMXaNnRfiYIJMN5RpIYZZ7EASPhEDZ0L1hlC3CuJ7EAwAUg4QiRZOjLVuZjjwkMcEpjlgkJS/UWCT0ZFgUEMZ8EVjoSqNoC2lkUx3ELIy2JZl0J4bMJVLFwiNaKH0v0JFuEaIb+f6sogguVBQtw7FhIsIrKliuY0HtBWTFISkj5FcrMqUoKQAIOgdhVPMc3BAiWMH4INJFJ0D4IuAq5JcA56wQgAZv4XZsIuFzsJBXA9FBh7JDkAhFQxWlU4VZ9DGxNhlYFcuablhjYEgWfRduwJSw8RIQdIOpt28JxJuBqg2M3szIiCn4CCbgE+H5iibVky8VoO8Yn/96tubz211vy8nnwCbe0RKg+V3XBjXWJD1A9W67CBjMWhKybwH0TUzV6yi9QOQUqsyRE4DYBceEoP0TB2U6eINlGQlUf0MxcANMnopD1YmOWWDZPhgLNuh1bAqLBtEkCgBUsDERBaNlEn2CgBFU0gHkrOLsVsE9vUcBWLLOati1WVTAyEGhWmwCiKwF9F1D+FBhvCQCUAD/cwrNUtC/W9BM+lQNXOxIwHvHpN1oECw/54hlYQmTVkOhMkLUVCZSMmJXHLXgeOEESBbrKhRGTcKpSyZbPL63pGChRQzLHZAsR5oA4sgmtOG0hCkIRy5CTIT1nnQxdrMVs6WBRgaSFk1BCY+0Isy1BVrPcCocoYskWUopXP+O+vLwW62XwgMqAyUzgpQWHdCWiQlx1nACq17wXnY0IYkEKrI6aaKAKRsBD8z4CEDbF7Hk6mNNSFThHDqhpF6jc6gg6x1Poq3BAMcEyfgi40CwKyc6RtRc+YdQEAUGAxJXYc+WEn6BZjlNhEaAidkTKFjQf6do0YVSdEoyMh+68PCUmsTK+U6J1xs4GS+EQU7Lljrdb2QG+B46tsIShQP0R9hdh2RioumwhmX0hcYH70gREoa9yBlW7mo5IF85cdPEZwiI/qhIhHJGXgLHpEjYUC9CUj12qT4x7whUEQLgTWAOLUeHOmSMYkwBCL9mCxTiEZ64AAOyxJQBsFE5l1MdTkG/BfIGJYyzBmvO15vKa3tvmDPaWQLKmYpac2AsXGGSLOW0CkGJRlQgU9CFycVefC1pJAqVexwZbPgDFM6+m5RxNFFwtgAUA3R0bgczD0lmnA2hbAgQkeK5XoGoXAqJkCxMa0IIjAZbVEzRwBF0KLPg2VAWA2isQsBFuVg6MmWsra+y9JXRRiBfo/lT5PbF2VkDiNdmC/beQYW/ZsSqA6S0JCqHEKXX7hLlASSUBKm4JkpUmSBaL3QvO8N0qEmX/BARtaD0BROCSJOUmkiC59hZI5itQ0m4OseRCwHFRGCvhiCqqcgpVSm1OwHA4ccrjApyPdvwdmlrcwsQhPo0IYokjbgTCfVaMAVWHBFuUCIpEga3R+GNNbVQ/BakmyHnhARSI4oPVHFzScsEiQVQ7Nb+VgCVvOyOwVQ68IAMrAydI9paA83YYueLlZZ+DgQtpEIJ3xRIUPK7YwlV7sSzWRAEbDwZMbCRbbqYMLQRsAms3EnQqRpALuRJrdWlCCA5sLqwJ+Cs2bZAgUzM4edOLT6EsDRRTDinglYdkiG/5cUEcBn0sbpsQ0YO2E97YwEqSmJhMiCzHrdrx/NfFSUEsoBIIDgjEFtD8uwSEv0DsIgtz0/S8LSKMt2CR2XTwTqAZfdOpSEJkWCTtJombAi2Zo20BcUcgSapAhIUkphoFmhyS1QVikZw7vhiHmX5z/FStCaXw5ByuAAYGUrwCGAiMjCGQECSRwgQBZzQwoAnAYLThmyhhCUelJsiiCRwM4CwA/zc8NZGQpCJR8sGdGbZ307dQBcwOBHMxEV4Cw9SvvZANmtZJQNGDA7gvAKG96gkqKCUqmCDic7NiSYA9TUawHQVcOUDHWSBABfmn8MSiRDJ+rM8CjQ2OWOCMJ9ZWeKGUIHeLuJULAe5ywefpbcEFYxRnnDEMhSqeCVLBo6Yj8ftimO3zPXpqyj/96K73cJ8jyAXBCTqtA/m7AKZL3GklurLpijmsYkVVRvS/awljbq3p6ShcDsADKUHnN+HMHVKuTWJhA9bZBC1lCqRcIlAlnBBbsRLPSnBsTqzJbG8TKXkmxBRJQomhLRjkEwCMmmg2KjwLiQSiomFl2gR9C8tQJDxV49kWBoElNZfqzkn7xJRA57oxe0ICoAn4Kk5E2ByvAKfMXFvD1YImWv72EwdsS0HGK74mR4BTbU207cK7sJCeShIwyQOZapOYH04ost3CRBOeUeKkgQkbSuT7hA0+hZR4pjrwnQeCISLwKTR4mo9KqqgqmiBEqCSSTIGuyUqw9ROImMAXhPvvY8ZbLUEXl8AlAd88TEI81C2VwMqNt0CGY3jMafwZPTxwwrPoQ4DzKtj8LzxNgZErff8mUilJPAte3AqGC5B4aZeqVGDz2/TCKkwcwJmAIMug8Nj51iEIABQFOn3R9K5p4MwNC2TqCVixD35GgNkPOp9NlvigTAAr8Qp0uguekhCAAKXKwb4qn/CKXv+8L45/HKECi0u4IoEtwoXFKFaxo7GXh48wQSbUlBgyDnhZHJqjxxYnCzQGmp5qVkJUTfHyvkCxCNuuRs1tNz38AScaAhDcvuqYj+NEMUPHwRtbGABnT3hGIbyLWzByoEC3iWY6lOrmkB01xyycFdJ0cEsSuPxzqcJDdAIkPCwLawaNOVzm5GTntIoX+BYQVjkUA0yotIv1VQBTBAIZd5+Sl8R+fAFmE7jfu4TXBIRlgi7QwQUDVsloEvOiiVd4SUJgSLQCAMcQXd3DfJcWtQIsk6IL4sj1K/A8fELMgyfkWhvBGEN6GyOWEdPTEAJYCwQTbhP8LLw2B5vTbgJTeljlxyVLgQpsuqogwNI4hqXYtJRv/Qi1VoTe7ijRaV+crwSakNbg0oNnURS4z9tfrqAXhQlSgUIqC9+qIdEMoUmUkeiMXSCqTxBlKWquCysH8pQ/VWJM0HkjSonzqxX4WGDtlEh7JVJGxIAOCwAMrDFh5VPS9EJDjljED94RSKaHiSYKjKiMjK6ewKAgPZU2eLonQTNlzpoRgayFwbdh+apfeKJBlzapDBSqMiTotBwmGgS6SjvxiDp8kSyFV3Tc0+d9IKvNyUoIjkMJkh1jlUkIt5tgQiU8GElVcOgKCDbGTbQyJRlcQItibMsaupDQEs+1BC3tSm/nKWPiHRXeEi22MhsDdtjRsMxReEqdmANAQc8lVe6ACk82jZN8Ew0+KsMXqKM0mXNIvkV8+GpNQZa9m57ydDO4okHPScJzVYLcW8zZUkXNPTYZC50SdA0Ete2GIgnsKGJs3YIgRJCvvz6BQouehC2WMfIURKYuifUC2A4RiX4+QbNufFUypyJICVwOWUML9BKiDU2gioAnCb6DoaiyOrW/n8qAMbz1rT3yrZEQhLCj+AavctC4C+NO03sfgVR6Zhm6oLcSDETQfuTCvwd+gpndb8BReJP/Hxi/H1gKbvK35sAIooH0Ag8+Zzx+xuyzA0EOEkrUA6BfA/Pegl68NaCc3nCoweSzg/lzmwO3L03IMQaCnYk30UqBZ45/IIjAGPtB0zP+zQEVWMAirIF/lTRcjRHE7ym/F8jpgchzBrLY9wGvvMYVaigwTONz4NmqOLDuM0DK5ANpxQuxjmMgibUUghD8cz83MQYVpgP4QJXCFMsAIOiBFadekhCGXVx/4Aj5hEVIkhA+nMqdZesBluUj+DgQ5AFgmM2aZPY8jRmctPEF2wKwL9L3gfQkb8LiO2qKA6/awouH8Z0K0NbnJrINz5cc14oAZD10ABD0wAwmQR/baQz+9LuFzw4MYLEHdFAkGPtvhYEc4Nlzc4AMtB3oDukZ9xsI8P7NAZFZDsZ/bw4MO5p2HniUn+l8A7MNtg2AjGxQBGzHIQaSKEGZIskmeen8PwboTUwQzdoMBOLAJRvbD+diRTqA3rTbPgQE00AWxA5McoLILk0xNrH9wBKNA8tHBsW2OyQDkdOgaJ8imRlCdeD6tGPHyb2aA0uIgfaXln8LRGRhohTyWV8p0o4no81mHAMk23T8HQDqAdZeGxNM3wXEzADAloErToq4JoEFWUg5fUAcBjOg4sMaa5CoLL+C4sjGK3sR10AgzxMAdgqc5AfSuJcE2i3dNgMCoICpA1dQO0Q5MBMeIzEYYPEA4D821pAfDqTjLzBG2WMMYTjwXIeHVYbetFW3aeABFhC2cwmnA25WZBK3KBgWvOes0dIJuGIWalYCZFF1DwDjDoTVP8uYxs9CGa/gOK4yN5/VBEF5mjG4jtoEbNG07uk4/QBwagycBgbwQSBuj/XACs4B4kSDeX+aRjY0tV0TI2ZnbOz+yKKtrEAEwXsgHYKezUcB/gmSXyGQjPGys7mBdOPBAvACCQ4sAWaMry1Mm0j7HGFqjyUA6k0glhwhPLABTYJ/Tyxx64oywH+GAgS2WeY8IKpfA5gIQIAHfdolwoLwdXAOsDd4SYuUBHiPphWrzQJ2SVecD2yxKVw8tituA0AgGOKxaX9mAPgDGYcIJgwEigfg2EFYjyRRCUC2jqAZCOTZc6HbpNb2FO5jVwWtyu8AEbFDq51YEmzgRlEAShcDIaFaEFqW4AQwrObcvKCesGwJKK+ZwDsEiGfgloObBYMCImIgCQcAgG1gk75FjECANi1B0XTEjASCWyIDIVyhYwfIwCrDgOJJWFme5dSOY0i470P32ckAEW0OYLpZW3NQFD7NgQCF0FzNAmV++3kYcA4Bkrfa1bRL+c53gbYNpNu2gUTLkQ7QOISAtBGYWmhChGqDBiQ+MJIauALO6fsQIiRRAIymRWJNkJwNGwFCvAkIGDAJGCBTDqZtbBwaStA/mkOX7JwxH0Li0SBVG5+GBFkNhFt9GXpICsIPqOI5KArYJlaCHrg40IT6aI/FoCi4QWENkrgxF+5gJ4Vd7niCYsAiZ3A8wKoCkg07PiBd3zMTIXCMpSPOmmBsUdxiVeIsoWVjJ5SANs1qg5UINqExVD9rzYGbZTcH7gddZWF3VOAgg4K05RSOk0q0xNPEyjADNwtv2uQ/ADI7IOjtzAoWAdIJRtRZnCAigmSIOCRBVND/u9k/Rj4SFzZQtQYQETaA2OU827YYMdAkLzxKXaB+4Io9t+LTtNrWHCIlQahagsaApMkBjBlpTUchoO2MOXy/JhQnQ6QChgC7MwUACgoXI5z1HI5AlW5sA6DeHEIiDBOpVIYJJTDA/UHhBZXt3X40QfxEstQBkqR4/LnpZJR2dm9VABwyl7At7VK2E7+QkHUxtGlPS4A+KwCbCUAYCbwiNhAeTpFgZSOhBOMAmDYlsMmdCkSya6Bv9hQAiNkDAEuAJLjmgPAAK21jzuUqSztYmyhheUgKVXLFZzShsj3YJziTaw6s7MRLCpJNHLAjE9mybXfn3tIJXp9osp28ic7F4yTZtDLD5lCEZYWOIBCIcGT8PzQN4LmaIJlR4wKJOAlmFa6/CaTciJUNISChMk5J+BIAxKTPIr/3xIGT1WOZ28Ct7LhAblfpJCH8KAFHiV/M5niMYRWwJgnslCC170ckTj5sAfFT4v5I2kcSfZDGNFFA+xyiRQQBNl6A+G8iFQr6XphYBKoCQy6m+8SawCse9hoeH2EPobl+idqr5g1spMFNUrEgBISQPJrpDaXHKYnfDXEAAefSMbAGBxoAmiGzfAwqQIaDOKQIBaBkjB8D5KC5KxTscNIl5+YGggbkoSAITDIISqKZAC4mIAKX5UDMG1OU/0qaSElRzY1hCY8XKF4801VDKrOUAULG529iIduRRIsSEdYPyb8/2mZOAgKL/WZQTHAFjnSwvUlU0+DnY7/zYZMEKgYIMVO840wzCEb1RhK+JJ1KdJOVrAmknC6BChHsww4GYbxl9LmGlk+dTIp23KY3oKQ3u2iWCcZBaEYtWRmyF6wxheUp3xQXvSFOOvSAC6eKYK+yRqdGfIGBVVREYIZEBPUQ8xMmWaLEIMOzKA4RIVMIJPkOhScrg/3E78Nc4ufGiiifNaLA5cuEfYIDjrcmGZeS2S6BEBdTCKGlZ5w0m4TQhIUnshZoyElwZHmhQ+Kff2ybbCFPi1Ve3Hh8H6haNbFF00Mcc5os7INjsYlikWRWdAUx7WEuivOVKkqrXKi8QGX9AZnqgHtPGQhetOJslgTHJjtgJLzKn0WQIYEqA7JdKsgkA6wXLF8NuBmR/5nF7EP6q0WUb5DiDVjEFdwf/PNNYC1H01tJkSXJ2C/mmmTs4Iu/8EoWpzKCk1WYaJNe4OVVP7iJRBmfL1MRCo3HcDxpktMYvqoo7etNbzVJ4msLguzGqUSFiGgu9klGJZfAFMAGtbAOczsjGQPEV4dNliISAVljQPm5lCCgVqTjoNT0qdMhp2RVTnnzyUYygUoys/lF2wuBsQzMKuVC2WwzCCzCq05N31qQoH5JXkbsLaUyyqYLxY8IEu5hYpAzXcPrf5OVlYeKallSCC8yDSAWsJ0fe5vYKvAgTJfE9911OU1udYUxbdpkTRfLwJiUJcZa4muK5nPoIcEvA4BfLMGxFiEDbp9kicALHdCiAzbJOcNFCKcsiIYIKP6CtmZQWa9MsJdYsBicsSxKWjLAV5htdPYXh5S7y5JK6KLGEMJdxB/LYsqiUxNcgRc63nKJeCrD1hUEVm4W4xBKsMiAKqj0CAIZcB9ZWvjzkiiuf8DCosYvs1JzFaHBt4gyC8kcJTsommRVQQYrUl77+atym0Cm1gxQ6U2SWOUSSD4081r0XmUIumyps8wcdVlRtohoLNOOqsR5Ndlis3LxFlpx5Np08f42F6gShVVPQsrK1BazZfoFRzjTsdlk3U9WgGUcscE7B4WfaML/rpGb4tlzBWWyVrmA05ZV0bKCrFVWkA1W1ddFSpgh829VjUEoUZXJgGUJYUKV6+USCaxcSb4Z2MfmsrI4j0hrLuT3IfasQrwtQpaCtR2Mv25nWSIrrLLSHCy76io8uypkQFVPlrTx8qo8zSXZi0pca+VLqTKrpiQRsuBDlnbyJmu+typFzQvMJnvFuKioQrAouPrsVYaIOaAmK/S/sgRdXihUU9qVWbVTB1VWE6qa8w7YnrSQeCqDAb6Dj2RFSYqsAAeqmEaoMskIKScvstAwYGt06WmQKqb86Km35gLCYFxy7zM73J/8bvbT09m+8dlgR0I+05fFNtjPo9pSZhtHf9Esm5uxBAB139PvfqDj9UtWAfqmX4RsbVwAjPpEO0Lu3a+KiKXrmxUAarMSezGzkT7H38vssCD2JPdloC3LlMlL2KwP4UWJik1fBggf5n375n0lD+v6vi1hhF36AdNb/arn+aUV14GLbPuAX/eJcegzsbNP7RkvyXP9QDwjuK+GE69EHFMCRpJ4w/rIfG6fCYJ9X3BLP9lT5N8HgriPCIA+9Wx70IvPaoJ2loj4kXib+4LnAH0KqKG/ScL+ZchQ8IRXHwGQvqTHyvaPPtLmPmKjvkcc9KG2SXjMQfAQLrhwhFaf0SdsnMyY7WN+IZHYRvqE2hyys7RsB8R4X7p9gz6DinHpxmafiJG+J95tkO8zREUfiVefCOlLXgwFCXTL38Bxl3wMQH1O4r6E4Q8kEPsS9hfsnn0onrAkExEifcKfnfEPqDL1mThJJZN9hi/0If+VWIYuXYcYSNggvo70LUAaAMHT9wAHGCiEeu4Lj5igHEzQBu4zQcwOZggwUHCFn9PsI8TW94xL36P8+h6B0AfEWgGEkTHxBTNU3bEDq89oE0WSkP9h9u5jVScgFvrSBf8+4e/2mPclQnjSb8c+ILhYdpN0Bu4jbp/YAeNTEgSDgbbAQdgLmhRRYyRN4BMa/xJvW5/AwILAkjz/5fSr70kw+nayxSA1FIugOLBFo498EB6wfXcAVYApn5V4H/rE5/sUnlPjIvHMv4+Ixb5H0FNCzMc/AB7UHAemsoO+FYx9CqA9AYgRdh/pKGacPpXtC4KIEFAu/FvCQTFgkKJPoPQ5gEA5sIDHYQAFHyfjQ+4HZraSJpM+U3yEiAxwbJjASmVrNuj3JQA40g9WWDAPJAKAEidljITQdvpASvrFswOemJimQFESJC7wdoNiABNZEhZD3GoCiTEY2Qle/PeJseQkGN4khzPens/0iYSDI6j7RFWgzxj7AW7/JsdWJDcR1bs+x9aS9j9fzPsqhCyRIXkJGCIOamAnQq5pGb1PkaSVvdgZD9cJuYb3BXOhTTLs+Zwsp4+IB1DASF4/+x41OOCPFS2SJKzeMXLrc/rhCR6OMKDsMQi0FdWegU3kC8ZHP7DfFHhTIthrOw9YDpjizCbXAbMd3jbJQBsDdiQTAGKukhKMfe6Uj0QEgAzDk6AY4iYT0p+lDggbseJcEhUrT5UU+y5LlEm8AuzznQGn0gzZSAbilk+MST7PUfcdZ+glQJ/tdDKs0yTpyYAA991fBmR2krCHZA5mSaFUto+U6vaWh6TH5pLZdskL+iBREyIqJINkyvg2sw2DRYieWcbmZpulRIfkE/VA8KpnfU8FZlDWVpKY5hPhQpRFsjLMlmX6NUCE5mARDAmddvO0bxBaZeQkR5LIbCnhxS2pSybpS4LXPJWlUN8YVMADIKF7g0ZUnLEEqJG+5Gc4XhCWiBKXnixClitxQVMVZB/lgiAilnxhDh8COpIPuoOK+hwylxwKmIMqxoZR8q+yGjDgzP1Jv2DwApKvT3JxggoAvoWEFrvyVNbfF5i249oDWsxXOXZInkBcKFYWaN+gzFjLxXCS3W65AKEPlkUIiwA0RXKSARxlAI6bpYqw0o73GVXbtyoSWMb4ywrE4SLAuGy7IOA44EwbVAVEyxbf3DL3svx4OwTrolUDzrRK4DRMnzOlIEu0DcsUS1TUBlwSDGmvXNB/5JISGrENcRbma7WFM7PKwV6cxZfcxrbKAAEi6BWopUBqG4NgW8XGEu9RquQtl9O+4AqDXCC+KxalZNlcLogfconxLZccQ7Ii8cqthm4HGcmSwqiiqtVgOzBvwfVHAd+pbR8RVtEZuWDQyepV9tkqOrxKewnZ1EC8guy0jLKc3N7scenVCbkEcJZniSCvkozKZNhno29vZ7JyBgXjtiYyclsTjFp1YLHowpHtCE55hoBmuxxSVjSO8uwUKWcFGVTQlsErsSqxjExSLinLO1PkWiWObYdgW3QcZba86sKyqwFl+yUr4kW5FBysLZdU5BkAibNRYS5S/lukaiDPsv5up8qVZ5GQeKULqiXOI5de53I2xux2ElpVpfezFSOqjPmyn5WvuHivLQ+wtoPY5VkGRsuYR6tyXnCZYyPPcvH0Sls3sGiWW1VVSFYoel4pYylfoUJKnuXC7tXSv7N3GqhW9ovx9Oem3/DxdoDSpnERn4vNzy9i1M2QMqxk3o/x2c0zmVWVLBNtLvbZmOh/vCApxtY9Y/C+0mN7iwA3ZZi/bnJ8LNSPPO1cxI+gMdr0xFtZH8vtE+Z3ceXAatpNsp8TVwjqcekxC8SkzQX8YJOLl0gsLBXnwsYJxBygjXHlGCwXJPRN5kBtWoG7aQ3SJk148eYcsE3ndByVas/kmTHUHuj7xjPiTcKpzLZtMpWhB8DiTdtWsvj/1s/YAvcYc3gv+Vj32pRzktmECSXm2h5rD9DmGPGhmLBjvMkAjk1E/FAEuYnYcJPZlk2KiIv+T34PGNe4j9hxkwd4aPwA9ogpW/RxP4iRuI436c/HRhzFfeyZ0o8nm4itNpmifhPBsL6FSRYWeMllE7c9RhIxAuAxEucxOM5w+2IqvjYBkeSLbcr2HgEeQ1hkiyIHRySIKzQuSQ/mSIMDpF9Ib3r8ycFWRHRReEPx6aaEeRfACyimahBJkgFufDZ2HFHC5OW7t3XFmwgBbNKgFfcNp9gECL0PO35MDoB0yXYTbjc0kG6QSaOfEgyY2BiseBO7Dz4+JJBBjuRzYMRuMx/YFPR4m33ARAUAZObnY8vuMTTelqPHM5Aw/VG6gLAJi6t4E/e98fMlGqTxJg1KMSRs+7hPxXaMbjIz/k1aHMOxLR2AMok37nvG0PEbgjzQ+JNObMcWWdixE3PEJBID8SQeYyjmqHEkCV+iYwnarI//jiQWgOxjWxAwYjRGBH68SdsVxGFPNcfnyzGG8UgfYgijNmGREkN8B/YF5rGYwIrYlzSgtpWwXTaRBMwer0l7a052CHyhQJZ9lxxsIo4dA8gMfA5AuEWnkiRYxptwGdG5ly8jtoHDAPvYaF+cZxoSJfG4cE2VvyxmNVgAAYorxsQWkWHFfVgYgffbtInPcGSERJ0KSR8e8wTzBbuMSgUvJJCo7Nb2Xez7m3hlBw3gTSIrgkRG3xJtwNjYdo9tcvKII8zGPv924qk/j6XYEmroOCI4Yds6BsSI8z3EzxIW6CKEaSYXfc+9mf3EMlgqzuI+Mi59fz+gik+M3ku6Noeqj4hvOFU9FBMJcUD4aVH421g4Fd1WQhgy3ptQoiHpePBgZYzZeBMQ2YQAhHwO5c8+XrUFkx3rqiUU6Pc9yhLLWvuEatsESHkKfH0XZGIiEGJANBRLLAJVPTHUDhvM+hJ0/BhQvljg+ogRcw4sAGNSOBHOQpAb6sSIWo2RMYTALMZs3seJCXpO3IeVNw1OEvadvt0e6VYPnHKnBIWi7Wewb1vVBgoQMXv2JteG/pnOrmhDXyKLuvqa/L/+2R1Nfo5/1+hOPjf9/IZxz+llPrdHZ0dgfwG/iqEqDTo9RPtgjAmJvgdYKSD3kHLCiNsEA/8+ko0Twph6FoZhVOUwprAFiX9OQhA7lS4Eowptk36S3oRL47EnQ7bH0uQVjo+ZAjsmxivG8KUPx3iMJGcxgQ8cLAZxTJfc401YdcWbtFKNLRUfewAJU/YUCIIdp1RiH8n8N5E5B5+Cs7MniNSRPuADIlEypAI6BjK4mOGk9rRBDJAeLSwkqIJjREXHXoCQ+Gf6CGEQwiP2Vh7cLDv22ZcSK14hIUFSoewCEndPzIi4oci53lFXO83qrTS7unUsu3p9lF2lr7Vj+XXlqrrsn/l11Pj3sdnn9fevXj+W36veHo2vzvR5YxEwFw66PZNY6CGVMmyKoO8RpR7S4fweIrYYE7kef+F8DhYIEiBcKu5gMo6JiiYp8mcZqfTGIBV/saciAuIMMOYYRnr71ccFipMg9HH/wZMhieImlV2THNUnRHzfj1sJNsWKxBPljzWqk85cn1c5wI2OS2SgvoCPGWoaLfETgMD5G1Q+wUqQfKKHFWrMBDKOLZMgBc67r+/3cSg49z3ft8RMWZvHVEUKAGOueIg98WCTdjzNmidEmhNra07WmoSvWDmavedBdT1wJHu3ui6/73B2+b2Hs8vuOZxdqq+7D2eX3HUovy7WP384vi6e/pz8TV+X3n1IfU9d947voe/17vuPqHvrZxzJrnjo6FgEaOJXhK/booVEozPJ+I3MHq+SwZklFzuSoGxZ0r7CjBunEkVMx0G+kXj8myZFiftX318RwGNL+n2egd0JE2s5QsmuiMVMXsGrFpKFRVQSxiJtQmS5n5eleQar/jk+ikxr1GCjSxKQqTKjt2TkAV9w/sXjOO7f4SwYW+UbYlxKIfHaBjmf9Doyfkm/k/R52X/CbDNX9MREmQoXFzJYVHHEYtk+Q+0lxQPmHzMSn5bI0zwjvjon7wlxPzQmVU2wmnA1+eYk/YND2UV3HMiuVkT8z+2j2ed/NMquf1hkNz8isjt/LbO1J09kw6dPZg8/dyr79b4Xst/uV9eBF7Ivq8984aci+7y6PvPjNLtmK83+Y5hm/9obZf/YOZZ9YO1I9l71PH3fS+88mF2onnHRDw5OiP/wmPQ12c+IfkzyV09JflLSjzfcsj3P7zF/kcG+xQXLuISwjdkEyscqXh8kq8TPSaIoouIK4JDSPbi+hDlWCUd8M+7HrbjECHFzbQ2tQYgDkisK12MG95r3qoUoMi5588HSn91xMsMypM8NFP+cS1hwxZt85eYjkFCgiBHCigMqAUmg7bhZehKYvXODOwlQ/GFg6wHyWQY+n9eeEfjaPOvWhKkz7TFxH8wuU9e/do/mhH33b49nv9jzfLZHnM5OnX45C/3v9t+fym57kn/d9NjJ7LpHjmef/bHI/m1zlH1QEX7jXtWuOw5mFynC19m+bmue0au26z7k5fvWuGSv5+0bG6kzLx8H2jtkTBI2QPIJICbWYcSbYVXEOCgR8RMYxw4Jk5BDcD9BysTxAtiDt9s/1Rk6lqFiMAnkooXu2Q/hGlqA1UIyGA54hjp8wjSej0xCnh0HtikElJJAB0gCQC3UqUKmQMo4LFexxgsGRMLI2nyKHrajZIF6zATVAonrEnonzTNZPV+dZ+CKBN89IXBdDr9IEeX/XT+SffPnadZ76mRO3C++/HKmqbuKK5TQsWvXE6eyryuiv+ZHafYPraNZ/d5x2y/+4UFV8j80I/grV+Zl+mmJPjYJPsAPQ4Q3L85l0DgnAffGdvSEJDZlqntceyYlsJmb3ECJQUjStoi4DhFPfiySQVWAkAQ3pMpI+SxnarS2SJAlgSUJbkmsDHlwS07JAm0tCxZlyZB+hgwuxZXNGjiquqwDcxbexCWvZMF7sNpjzYWPSXwy/60yWD3nrUvXeh5bZ7kfWT+a3fQLkT2iMm/5vCJvxbzLuqoi9Pn1/Ozf31PZ/Bd+IvLSvS7Za4K/5K6DeV91n/PsfX2cuY/JXczIPQHK83HpeJRBJfYQwU8Tu2THdbkqnlyoQsRbdyNBLCH35ZeoCpZJPspUC0PHmrMOKwnI7JMFqjGQICojVGqLqMGQkme80CXZRJQEknUSqGAXmcviiQu5eKa4JAGVVCCuqhA+yYLPTgIzHbycPt7+NV3MpjPxK1SWmpP4JAvXJfQvqjnvzv+czI6dfGmpBL58QsevGx89kX1SzdG//6EjeYn+4ml5Xtniyhm5jwVPTuzqSqbkXpq4ZWlRnbATE7lw/IRk6MsTCOXjq+z6gtDKYPC0VuDUapn1QEnpJC983VGZarJbcrfnu5DyWGKC2XT7CjVoPVj5LZRx2YtueiUcqFdcbZyUVHV2X5OKiCm22hlbdg8a/F5gUPeqKeNznZXbZk77kk3Ef3suGZdZaGSuTp9tJ1OZp54/1uX0fD5cZad6nvlyReJf+a80+/Ezp7KTL768rSR+pgi9MBf/+Ml8Hv5vV6bkPs7c9eI6baur85L82IZQSR6Lr8UyQX8WyvWtpFcyhkOvXjVzxQ52+wixFzbXvmyxwEpmegFioLcYbiYeHyqLxZDPoFWIHkboUOYBHDjhI5iEAt4e8AyocT2iIz34mWDbCWGCETzo7D0k6Ht0n8C/2X3sueKisBWoxxQKQJ+THkP0eIQb2Q6qD75+W98vBLPa6wz+jbKvsYo8YY67u2hLgjY0xas5Nz7OxscL2/T8sV4RfqEirv/YOJZtqLnw4y+8nL2kCPVMXzihP1+61B5M7qo0r1fXJ/eNbaRX7uuFgHrVvJ6WmK2W33BXy2PiLAHEGYgjPSQZsAjLrBQUxr4HPyex2+S0l5hPDlhPkPjAHbKV7bM9BNsJPMAwwxHGPQR/MAxAYheys2P/np8kE6pvPmLt+bERO4gJ5U6ECxPPM027Jj1jfr/n6U/PyNATn1PYjsslMkaHEyuIkh4chChg92ijw4Mp/QOABEWy6bFHj3acZDPAeQCyCVaZ9hhDQdIjiBrqOyXeejxCx8QImXHbQqXnD5qkFzhG2Ny4zsbXptn4kTzzbKj541sekdk+efqsIHEeoZ9akNDLEfwNvzqez7lfptYS6BX92obvmRL7JGsHid0AuaQHkC4GsoBPJj1YtDnED4Cr14cocsNiCMLeHiO5IvoACpMeQwj0PHgCET6VSPVgoZ9A2ONLBiGC7wFk3vPzQdLzCA4M9314D9wfGtsEszkmSHv+cUtmhM4d/B6vA5Tz+VQY6SCYQTYDBgXN0DzGYgYXKE6YwZp4Bpxj/wRw7gQZeF87MOWZcMd5k9n+HtPPkAwq4fjJJp65oc+azo9PiVyX1dXhK3peOF/cprZ09f5wMnv+9MtnHZFXT+jVXreoVfPXbKk59cliOn3QjT4056pVY4W8SewhhNfzEC6VFDBEnw+sy/gzRmxk5WB6el+PmEryPdNjq6RHZLUlxyIJ5ZhNpHLG4BmvGOAItE1PBWTTw4WbBP70GNy7GTCGzhy6z6hBAynZIJ6EOMGZvDZ5wiK8vbJorxL3SkoIsVIgVDVJ98KqOQuDJ+OaZ+TpjMh1qVgfvPLJ3rHsUXV4y+mXsjNypadezv546IXs4T+ezFZ+lWbfGxzJvtE9nH1l/VD2uZWD2TUPHMw+fr8q/99/ILv8xueyy27cnb37289lV920J4t27c3ed8e+7IP3HMj++aFD2cc7R7MvKmL91i+PZ7f+7syQ+5d/JrP33n84t622sbb1VcY8u52xe0nOJ1g9YJlwMWiTmcT4wDjErzfLk17iSTyCSHmTT56lcaCKz/psuFk9zyWeJIMtGgIw3xzH2rYD/aJkXRLYk5JtTCoQAMlZJkSqCpTEZ9+SpJ8savvNEmOjSaM733aWl9YfODIj8s8ORtkfDr+4LaR96sUxaa8/KrLrFFl/7L4DWfOm57I3f/Hp7P98+qnszz/7x+wvPv/H7C+/8HT2ui/9KfurL/8pe/1X/pS94SvPZG/4mn09m73hq8/kl/6M/uxfqe+8Tn33Lz7/tLrXU9mffVrd7zNPZW//6p+yS7+1O3vv9/dl/08R/hfVvnM9B74dxP6fvzie/c2DU2I/nNtei6nxtrfpyviA2CzhW0kZzNkMzICXHLdJFbFUQSa+1OSpqmpNxbZeVjIU4ue1M0kiyTaBeLLkrD8hAmlhx1kkWw+dvliSYk561ajPKsYJKq3H+dYzkWfkV03myPPSuiKXa1RGvmwiP6jm3zuPyTzLft8te7K//MyYtDVhawLWxPym/3w2e8vXd2dvveG57G3fei57x417s3d+Z2/2ru+q63t7s3Nu2pude/N+de0bX7dMrun/q7+dc9O+/LPv1Nd39mTv+Pae/F76nm/5xu78GfpZ+pn62boNf/app7J3KKKPVLv+38qh7D8flkvN5jWxv/cBRey3z4ldZ+wNfRIdQuxnoqqXVC2gfdNflVQCl9Tfs/T5SQWEmpyh/pd9Xm0ZD0/OoBMkr3LH3rkWGJtNl8jzE93USmu9T1qvvNYLtfQc+T+qE9x+o85Ef1ERbtWXLptvPiGzL6yqw1iuf1ZlyE9lf/n5MXm/URO3Ite3f/O57J2KcDUBn3vL/uy8Xfuz8287kF1w+/gYVn2+e/7ylcm56/nZ6/dMrnsn1z3Gz8lLXPLrrvF3x2fEH8zJ8wJ17/N3jQWBfuY7vr1XtWHPjOh1dq/b+Gef+WP2hi/8MS/hf3TtcPYttdCtmoV2xesrSjg0pnPs905Wxasxyol9en78xlkYj8AK82TBpCRZAi4lr6a4fsW3X7ITRd/9a0st275Wr80zp6R3Ll5Wnr85bHK2uj6y9PL7jmSXqJXXTXWsaV/NT79wuloS36+Odb3jp8eyD9+xN/sLVebWGfDrvzLOvHWG/I6cvPflxH3B9/ePj1b9wXibV/6SlPuOTN6KNj1m9Wh+iE1+3KrxWtSr1kaTy/7d/DWr+vP6e1c+ND6OVs9b63vrZ4yJ/9DsaNoLvn8gb5PO7jXJv0219U3XPZu3PSd4JUbOU///oXsOZtf9XFaaretKwKfVlrfL7xzvZdft0+3G5tfPJGkkr0ICS14rQr8CUcV7hlx6+2s7jvBavOS23/Os8AkjK9f7n6fl9fytZqq8vkttP9PHsb6oybyC6+jxl7IfPjzK/vbWPTnxvU7Ngb/x2nEG/o4b92TnKALXWfFFt48z7il5z15+8tD8Heb6FLr8Vaat+XGqOal1JuIkv8b/jq1/x11R+PtUzDQ6o9nrWvWVvyN9bU7407PnddUiJ3md0ats/vxb5wT/lm88l/dJ903Pxb/r2meyD997MLvhEVnpQTX/pLa76Wdfetfh2cK5upWtv1oIvYrnJjsC/jUpsGo75L1zvXpEhYfI821okyNadXn9vvEWtH9VLxx5+siLeVa+6PW8WtD2Y7Wd7d/uPZC9Ts1Bv+6Lf8oJ763X6xL6uHyuy9vj7HuceWuCykvKenX39OUm0zPQO1NSnlwbongtaJO5yDGFwZjsGznZp3mbcpJ/aJLN60xetV33QWfwuk96Pl9XGqbk/udqHcAl39ydfax9JLvl8WoW1ukXxDTuHlcO9Kl82mZ6LHNhwyT2ZCeBeU2W1l8rY1TzBj31/2dw4BPuwpgNRr+4/V+mM21YQBsKzosSHme8N85ARr3oZ2eL3iZz5ZNtaHru+T2KzFd/dyIn4RdOL3YdPfFStuvHx7JLvvFsvnpcryrPM3FF4ucpwrtQEV9+BOrk9aNzAh9NCHxyznnXIqeNM2BTh+jFOKOfZPNX6xL+5P3t07fH6SNvL5yQu+6zFjDaBros/0Y1vfB3P9ifffOXxysow5/MPqZe7Xpxnq0fmq+Gb7mknvS2OY6WGCvJdrZpY4E+bAT62Bm06baP78byeabmDJ4NJBjRbCCAv8HICHrIM7gdxLIUbhtDiN5nC+on9KwNBplvwH9Lqnb0jQUDayPQgTeIe/jsuBF4P2OuXBNl/gpTVcLOF72pDO/fVOa4Nz29MJHvPvZi9iW1Ol2Tls5M9Zz427+1Jy9JjzPx+TvEr3zIfH+4SeCeseAKrQ3m333+TfnJpITfmBD89P3u4+xdlef1S2lUn3Xmrm2gbfHm63bnW+X+Qi2ou1qtxv/aT1OXrH83uZ40ftr/Nq5v/fpEvt5hfDCNJ1vf8PiMD+d6jO/3EHwD/Dfx4WIPwbGNaipV5O84vsbFPN8YUGMRmoiVuedGIG9xqz8heMXhBx+2bpgZOkWCXJBlODFqoA1GYHFBnZt1col+g+GYGwEkHmIzX3D4nl1GiG0ECpjQ720wBZmv7ZzvmyvYp1vR7hrPld//2PHslDpvXWfmZa+n1D7xT6jDW/5CldVfr1an6y1leTa+a7ygTZekzUx8moVHU8LpBtiPOw69AD/aYPgRIx5nJfr2eIHh1Wbmfrfe+ncoXyegS/K6YqFt9eeK2C//9u7syz9O50RuEzpE8NZn9aI5na1f9P1Jtq7GWK8B0G2JTRtzCKVXwsc3mIS4UTLGOGKBIyRCs+QyuN5jJCU95vM4QioEDznChYuFoYK5BG6x7Q7co8ZyhLIG2whQrlxgCwWlDUYmHBJsvcBBKQO+VV+9AFttVCQ8yhAzl+R9PjmZD9YkqslUk4ue7/27Bw5lvz/4wkJE/syRF9RJbBMiVyu933r97pyszr9tf56Z6gxVv1VsVk6fHoyCkbivQlMFiG0sKMa5f5tk7rr6kFdENLk/MHkLnbK/Xkyn983rcvzrVTle73O/TJ1m99WfAMQecF2n9q5fqe5/8Z2TlfATAZWLjRBf6wViUAjZlsWujZLCeqMEkfQYSU0ZTOgF3q9MwtBjYH+okLJ+n1QRQ9bnkh6TR5n3rFXiCMsgm0VEwMaCanvRYKnalr0FAuBMCobtfE5vSuRjUpltR7tHH1JyMPvy8FgmTr1UmsgPqcNfvqxK66/73JTIn8v3a+uyev7K1PusbLwzX3leGeAucxx6FYxNd07s8WQlfX1Sks+zdr018K7xXLte4a8X0enT7TSx61L89XplPJSpP+kn9ZvViXZ/r97FrvfU650CV05K8OOKSAnSOBPYsQg59JYwzr0SxN4r+Zll+mpvG2OwKn5Cfpd4nlGrBAR625RFnk0E1FtSkG6cATDfboLuLaGv3XmJPV/Frrej6QNUFHmsqIVv+r3kp0pcx59/KbtN7R9/y5fHx6a+VZWNdZY5JfJ350Q+3uvtzcbPFmFUJQl4gG+6hmE89TEWWTmxK9tpG57zvb15lUOX4rVY+lu1eO6mx06UztY/ro7ovfC26YK5ybx6e7y9L+4GJhG9CsT2dgip7U6Uzna/Phv44gz1uba0zvdeJVnha8H5qgKLMzUmBpnPVrGr8nekQP3Rvc/n8+Vlrp8+dSJ7jzrbXC9203PkeWn91jmR68Nd9Irv6Qr1qCyRn6nx2i7/KqyUny9QnBG7El1aJGkbv+5LT2dvVgvoPt45QpP3k/jvvqYOuLnsjsk4aVJfPeaS+tkUj71XOK71XoFt6r06bVTbIcEd8fCKviZEkZ/Dvjoaz5erudQPP3Q42zs6nZ1UxBx6HVSnun1Sz5OrjFHvq9aHwOjFbnoeOC+tP3gsJ/J8nvZsIPJX0FgVKilrk50H+Sl948Vz2tZ6p4C2vX5b3A1mGT7gulGtgr9KbRO8WC1Q1MLhqunWts7OWO1cr0Dc7+0Q+s71GiJzvRBKb0nT8+XXbBzNRidfKkXm+iUp56jTzl7/5WfyY07PVVuv9OEzei5el/H1fHCjdZZk5K/kcTPm2DWxj8/RP5yLMf0iGW17vVbh9Wo7oH7z261PhJO6flPcX987XkOhfUOX+6frG866cdtJGnaunQx953rtEsJkRfVsf/nhfLHV9WrFtJ73DiXyw2rR28fU6W76IJQ3q7PJdXn9AmMutrDYbSfLq1SQNTrzHQnTd89Py/BvVmV4PSaXqve66/e2h5L6ridOZh9aOZLfT+9X175SIPWdcdy5dgh959q5ztxlk7kGak2+d/xKKjJ/OTsReD2sXsZy4defzRdmvU295Uyf7JZvgdJZ3UPHjIVVO0S+tDK8mt+eza9PF86pMrweC/3WN52tv0GtZfikqr6UKcH/S+do7iMzUl/fIfWd69VK6LZTQ/9vgKkTkAGBi/4/9x7LApWQZ5n28JGP5/9Zz+wuwS7dwM8sYCPqsxHjuxGRmevDSzRQP/j48WAil2ob23e3jmav+/z4hLdpVq7vqfdP6/L6dN41Qvw1wvrUrdYvC/fslrhHF690UN8Lifd84RujfRHiH/mLZnTGPi3DT95Lrysv71JjM51bf+/t+8fnwweS+r+rd9tfcOtkfB8EVsB3y49NVFXsdRfEui5zrDa2AXvL9sXnkx7+iBbArajrPisqa7OyWFsGQ7pQht51g9zu4OwzhANFXcSoXWtQbLAGgCTqBgBE12pv1703CFBdQLQwBQ7Y7677fMhW4Ocx+5jO1aXbT7UPBHREoERdwgeoYOkyxRzybOdnFyDzB8dkfqEC6NaTJ/LMPOQ6oBa+ffj2vfkKdr2nXM+Vzw4mWZlkcGZW7hnXCIqhLgJCXX8soOPZpZ+LtSsi7EyCJPFsu/0omCNCyIl3azV83cjWL77zUP6udj1W+hjZC9V75M0S/K3WCXIYqX+iP8pJXZf1c1Jfm54ZgIiMbkni6sLxZPpFtIHcH/InDkFBmLIBfNeDb5FnvFk4YOIHhDVdGH+8fsVNGLmE3uXZNd7wi1/oXlHXg9ddgAMBX4i6cB9tbK7NP5jiIGGTK+EoEUCOzoB6gCEC7hchQOncp0sRXWq0JS0GlhFwEeHE5t9twoFERYS0K+paIgb7DvK3qAsPeIQJlA28LU7buwC4WO1FCaprgnVauC8Z0MA97OzNJPNLJ2Te/Z+TwWT+2z3PZ5coQtCHmuizxvVWNHOuvDFdvd5xxzTChCNGpl2LvAokkeKg0WUQRhcgC19WDYltRBRGGzzxYPctImIH9Tfbt3W23p5n6/ncuhojTcZ6Jbx+8Yve3vaFrRFK3hixf2qYjkn9rkPzTN0kdcIvoT5Cvj0f+3SOrxiRIxgbETYGBQLmixt4zEddYnyIxCcC+mLifIT4l40lsIhNXf8rPDN1YsrBVCO2IgC3KPyC+hxB4wwJGAoTCdyFfI7C6wjBoNrsvckbBHESRBlZpFJ0stRRpHZQFJQ50A6n8SgppvB3nCBIQUNggRTb3/MNWNdTHegSQNrFlX1MCBuq364gSK3v2RloCoyjOXYpGITQGEVdT/Wi0L60uALa/NsE3Ov5a0+P5e/E1oDcVpm5PPVy0LX5xPGcCN507bjErldA5yXYh47N9pRPS+youPNlWx7xEmGCdwOvUkWz95ozCHGjGBcYIENiO+rSIjVCKg5YuyKEeHwkOCN1a+/69OQ/vWBOl+D/8nNPZx9dO0wS+K3GNf3dNYrUz981JfVjaPk9QiqWMN4V44iMVzS2U1gYOT6UwtUe6/dzQWE/K3X+P7ax2MSHDeg7SILRpUkz8gjC2OIQLJFxxgf1wxTGIKuqEWGk2YUrSV5i3mDgQDcl+YOKfei5NffDaQ6u5uBF3rJi6idFoDNTZ4tmJJICwe8OKPjcDej+sPqLTNBwCCxFKgNpESSZJOsXChAoFNsWd1PYfoW/IYMO9JPK+m2RVBRUqWWvFA9u038AII82GAFjbk2bkLkmX51RP/R4OJnf+fAony/XB5icMymx5wfEPGSW2CdEYoGb7Z/zPqQoKfp8IiIyswi0qeuTkUfQRVQWYo1VRGQDXDGB+6EAhSOdDKTF6kzLKsGrMXzLZBX83991IN/adiuYnZ8skPr00uV3vfd9PKc+9oFo4gMU+cUbdradzvAkIuPMwrsNN9uOCOIGfWHDvQ9X6NttjboCFffguIE+a43/RlrMrBFsj1AccasikRWXjr9umL6YguKnsOXU+W6K2MsVAFEXrpJGYByn4L8jgujRqi9S5axB4FG8WYqothR0eLgzKZAJ+p6LK1T7nhjpxQgwRoQTOWTpKZFwwTdGqwkpCZLFvqbkMyOHgCgFbn8/5YMIZYsNWKDEQECaGX8RFEUhQ6sb2ZletPYDtZo9hMhTtSf9q+3D2eu+MJkvV/uc9Sli77kfL7HbpBJvYD6VWvZOwYwDB8MUGQMKiIFMDAQ8nyB2fSzyiI8IE7wbJnimBZ/1CVE6Jq1sPd/eNi7B6zHUq+DfpsZUj+3VN+/NbnnsZE7gUIY+//fJ2b//rXssf2mMJvWpsHN9IQWzJijewPjcgGPOjmmoyhgjYjvyiDdo/DkCMUbwm54uSZGxFUzfgzEnJvrsI1tYWKagnWFRkbrVY3TKA6+eRSBu48/nCIQYrX6l85I7pijQkvW0oRvCCVzY2VJw8G1gjBlkHGOEYWVSMVZ+QcEFH9CYmErAytamKo2QEnQxmCjHgIVABAADCCgbPCFCiaMYIf/IEXjumODl/NSpMpgrnqcLoy6/50hO5jeoV26Kky+zr2MnXsr+Xe0v1wup9PYnnZHN5k4nh8QUS+ypFfgpAyRTLzFB2VBEgCdMyimQ1aReUoHGIcaqXBtp0QYbWNtSRJTDiQBJeBSwmsA2OQPAPOJXj6Uuneux1WN8mdqvftNvT4Dld5vYpz8/snZkvPpdb2lbsao1RBWETEacMU3R6pWLuSka/zFANOZ0JeYfOLalKElDbY68GTqeZNiEGqEkn6JVKCpWiiV27Fkpy/dogVPkQlg0p2BCFiNiMPZUZ3yV5Ol41UyHo+bAqUF1SSAFBiO1spkUcJwicEHAiYOg/fnUeiaeqdikGqK+IzIAhdM3LgDbn8Xs6iNjOnD8Dg/NtUVUGcrJWLHSLmTrInjn2ZguseoT4L5/MPvsxrEsPcEn8yPHX8r+75378v3levHbBbfNy6vz+fKJeGARboqqdyyIC2S/kTp+Rme/KQjicde+jwD9Aso6YnJaCS7BR0CVLmJdKTD+tgB0f0cnFmlhz/oVD863Luox1if8XXTD7ux7vzlRyMRvnZXdT7qkrkr1779fvQXutoO5cLzKPFGuA89hUtUwKgON0AwQKvPjWSYl2iIU06BxTAtJGlYmjsk4T8HfxUTJGZpeiYikISZJ3BaoKTke3GktKHHx3cO0tZ8vsKoozREQNwBz6ClAGBDZ0iW92Dt3IABHEgwnSK157xTJYIoETxmXGuQYcdLIykptMREThOYtoXQFGhAxGry+n3QwRUS5iW5zys483SBN0RLY9EjQxvRsdjVfepFaBPUPDx7OCTo9+TLrOiRfyv7+tr05wOtV0dP95fq1mnWTzEFRmCJ2ToFsPEVVPz5ePptBWVaKCIuUVS7Ep2TgMYgJ0YoLvpQ9xRUTlYgYmcqYfadjbW3Tx8bm+9UPZu/UK+DV7oXzv/Fs9u1fn3DmzYuL5E7O5tf1vvaGOqtfv351evb7rHrTocY0Jf8WEVM08BinHpGIEQxVJYJwNmVViGLE16jsEcb81IsnMSB03famZFIUOwLF5bIY+QnbJiWmWFJ0GiwiktsItakrsGKiMgaJnRo9oClY6nUJTRBzL/C8Guz4KSszggHFB8a4sow9WRhNfCkBxikwT+a/B/YdvP+pp8yLl2ljxC6xN6tPGYs/UnbZLO6mBlBPtipNXrSSqJds7Dl2mk3mhxWZ/92te3Ng12SugV5nXjmZG/vLow5WlfGX6Pxjk6Kfix3RSfs6XKpNgbanhHjwLFIkRAAEjJGnMoD7d0pUgfxEFxu+EusxNEl9Usl557fH29rOU6f/fefRE0ZmfrJA5sWfp7Jvq89eroTfxXeM11fkUzKWr0QEWeNECidIWCzFoF1TYkyoShuW3KRoFopNYXKmlFzfxBbJpkTlIs24U0iwPfEKQMTC3ZQpSFPGM6gSfFHI+JNhrJIx/12t8ICOQJwALzNN3zYVeecUU0+5RhSBvTtXxrOfLNBIPeScgoFJLwahPgeJGxMA/CTsOHbH3TrlF02C/RwKZOfEKsBMNEZAgZqqiD1ZbdyZZ17Tt3Dl86Nq0dPFasHSo3teyEaq1M65jigy//Dt+wAyL86Nzu1LqX04Htzx9ZEykSF3LFDqpOj8W+EeHYy0AV/tEALKXLNA+EfM6p+vkkCITyPmI3MhHOFTziE0D43XWlyksux3fnvvLFP/7m9OgKvczcVzU3K/7r9ldsEt+/NjZ7UP6mpOVNjKmDITBKO/HShzxInNHQ9o3I2/mb/r+MYjhbGWEAxewu1gSUiKVB8EWnWI0Wm6FGkDVTX1cQaS1HVSTwUpxe0PTGVQOBx78IOuRrtjWUMJxHSoTmoFm6Fa7UDsiNnpWlHHLJFZztZJrWdYgdyxSqKdeTvjTgqCVGSIkth4RmyCZMfoG9TnjoeMO2lRyHSMjMEcBAggO8YzDFvZQVi8jzsHFoOBazij0d/5v1Mn4AvA0UEyU2ccrP5Y2XXx+e60BEqkEzKfbU/Ti50UsLZ/d4JN5kdVSf5f7t6fl9nfeePeCZkbq5etPeZxBxqruY/EHcQ3Olb/Lf8253qn++hjZ/whn7L9Ex6PmaLvpASIm9u+3N0DsUk2hVgGwKaTwqRvjPms78b/xx1k/rCTFvzbtHsBcDsG/nTMI3hTN4aMk+XGb92bkLrK1C9R5/Pf/NjJeZb+xMnJFreT7sp39fvPDEf56nl93kFxO1sKgri5iBMjNQfvuqmLewaGxSbGOvdxbV/wBQivnZi1hZGNfwLAd/dEP3B6oeMKztixndUfACMKNuikbrm9Q8ypAzEdFzgKE7owFhRiFBjX2E5AO8X/h2wSWTiPCrauKFYTOyZGpQUMqkW2I3RSl7S6VtnJARIrgDuiGKAFJ7MdPIWNVgCatAiaHUu9W22PgbY5AAAChg3ckMMZzmWKF8jJ7HtZ88SOWDI/1xFAANtjBIktAYiUohCJrbGMUYdNkfEpggNoN2tlcuwsgrT8YHIq2FUPzVe0X/ejkVql/jL7+vzqoez1aqVznpmrBU6XgZm5STyQPQ1/M+wTW+ATOwRvkaoJgB3r9wYImLaPOwA5d1KLGA1whMbDalNBFFp9jh3AsEipA8RrxxV/sRn/HWvb4bT/ls/G08uJUQGMh53FA3Y2Dh+akboSdNoXXv+VP2VXfHdPtuvxCZHn18nZK1nzf2tCnxK9+vlh/YY2VR0yqzv6/kW/sZMMe5yt5MFObADyLEwnWN+JbazqAlgF4Xah+ucKcJTsrP7EBVxOi21yEj4B2skhfCsmY2f8XTs49u5A/AQlnUB/HZua8U1hoQBiI3X6GUMC3RDljljuCBenO6LYpk7q+Mv0dzXHaSzidIkE+z3k6IDq62L3Fsh9bKVG3NsOlA48ALGj8qFBBYTIDIiKGY5TVehgA5M64iQGRYlN5qkRTPDg2593hZmZvZvtTd2s0bJfXPCLeTDF5JgLWAg6We44u5puRZougvuQWnWsX2l6TGXdnOuWHx/L/uqLemvac/kWpHFmXpwzj1F/Ta1ATl2B00HUOhTUXRdQSTt5xRoCbOpvjx96MQv9T88Vw/EnkCpS0R9jLAYhkuggANsRcIx1ESyxhQFiQ7v8rl/s8g69+l0JvfffuX9C5JN5c/PnEydnZfjpIrmr7zyQl+/Hi+RG40VybSybTf0EBsQ1HrtWVQazIeDLkFiNoWfaVTuwCoVURS3CiaF+dJF47wo8SbHwJkbJHRGaht/FFp7GHbgaEQNEDMVr7CSXKcCZTD4xqzoYVxUSPJzXYuO+NZdEBKpCiwREkIgD+pCytAmCEgMpDMRdwrm7rmKLO7j6RZ+DlrngzD7uUOWdtFias7N/W3hYfYwpWzgO6gmGDq5+4bFPacGA/Q1U7FZbjHlzPXd5qcqMfn/ghbyEzrnWfiOzv1IHi7zthj35nuR8NfuDRmbeDumXoO3SdaeKYsjvvD5TzFRhgkwB0EgL2e+vD4QT+vW/OuGvlKE+hlxd2AddYUqJpZQUtWimZf5djbUmXvvVunqfun4Rzz89eGieoZtkPinBz7P3k9kN6uUvF968Lz+V7or7j7pbHb12ouIUyUC7oXEqEAxKEZvi04yxRyi4FQQOZghgWgfDNEGKNZfMkSwbfT6QPHlEd2zZNEaqATGYvGKCmBfzpA91U7CCVmMDN5jRpaiio0kPbnBMOlOKZgKFDBQrJ4ECQyAg65KnHSSxAyYprPjAzDD1BDwlWOx2pLQSBxVzilYPyAoLS1DYgSQIwScKq5T1nOV56hS3VfUqVC6Z/0y9y/xNKvt66zeey+fcL7vr8PwtWq3Q9nKET+ovt9nlOjBefBlWysqef77vhWBCv/aRE2AsxR4fjUFAEQxCE+S0Voz5aEcAUxwMvGqnxfUYd4/P/tcnymnh92n1GtXbnrDI3PxpEPun1PGw+mRB7ZtXPmgskmv7cAkn4xjL4jj28QpwjjCgxg6LYZhgC0TXTdF4x/0iNInwxBxBllTlgkpiuXjtx3lfxRuLA9oeU76K3ZJ7yiR2TrDyHT323luwBhIi2rgrSjoHx+k5yooX5DiZI3NFRACAi4ZIR+RWRtIAP6FLsvO3aU1K7ZN582vaR/KV6pzraVVuvkBtTdLneetzvfWq+CseGB8aE7XS+bnc3ikin2/yhWXstbdgCkvBErX/9Vw4oX/xv497smOOgEsZ4MzFAaikyI0/5L7TTH1tfPjMpT8ci8W3Kl95oxKA1z0sLDI/CRD8+Hr/veO3vOl5eX3oTKNlEjo33v24hdkxZlctBcPvhKe6xyNUfvLF4QgujuCxHHsFpcCndLp+u0VsoVJu/P325sSGMEvuYQFIEUVcmjBxI8QsoMP/HgcBJvR8ESBsUoIIOCpTBGaOaUBwcbNSwcz8RYDYKZbZNTBerc/lVuVMXda8Ss1X7j56mkXmB9PT2Xtv3pO/Ne2c7+7LLrlzsnd4NtcZIkioTEGUACQBLzRlBz9fSPWeCSf0z/zseCCgcqanfHPqoeMBxZAIi9+pj2lSn0znnPu9fWOfue6Z8WlyUIZu/VvvZb9YVX8uVms73qPm04s+FjKfmjLXD4X8DSa5uFRyFirqBFqVjDpcsShKYH+ImBLkM2M0u+dXmmOkigtn2SIw8RVBOF4rY+CoFDmmnjJRGfWG3y8OAV9maRAvQYbYRTDJWwSWn4RnHk0wxkAEKEpRQjCYK9qNd5urcua5N+3POmqLmj4UhnN9Rb1sRe8z1luTLr79kFq4pMh8ZfKilTaUQdFiJe6IoEw8DKTK3te/aHTt6eeDCf0TPznOyIBSUqD6s0YRmM3QpBSzFt66Wfq8CjQ5qOgO9erV7+zL3qh8p37LXiA7PwmW4j+n3ruufTSvAk3XZ7RSejrJm2GlzMqRQNcolRY7qC3LkW6554Ssm0oJ8ZCWqFqE9KFMRSFdQDSHJn4FQhcVNZSrxMqQftnyVbqAYUMz5EWfxVHiaWB2mTIBeIEsiDUnZJHFdIvaymi8ElmV2j/ZOsIm8/Zjxycr2vfkq5in52838q1FwsrORQl/DcnKRYmqU+hcIk609/3hVDChf/RHsqRwFgHtLVMNKYslRJY/EXfaN6bvBbhouvJd+dBHVw9bW9nwTP1v7hmX3t899bfWiFEJEgHEnXoXUPKrJZyMsIop1jSrdoqOW9WoRiDHpdrMyfrTBRMEn1iGv1ezMyfyy+0yZRNh3LtMCR4AgDbx3DazLN/mlKeQ+7Sh3wmeympb328zHbxdbDNKQm1ifq9ttyEl2iA8beP2ASqDTo92HZfaL1VvQHtKzYcfEi95rz+o1e/nXPvMeBHc5F3WV5oZUxvyh9BSI5IRtInxbRP+204RPyWmZ9o8cPnh78MJ/R+HMmDc4PlpBxfaIX4gmOMEfKadAs+0Ywzwe2Pl++V3q/Uau8aL5N6gSP0/fybIOfTp/9/4q+PZBWqtxuxoWHR6B4iLdkj2KwJsY+FjGxkjqF1tRKy1fXzAGSNRxK02MC4OxlH+zyX1NCu9zqAtvFM4fJwTQHJRVfKK/7sGBlo7dTvYRgYOGoQ2dc/UHeC2QAYU+LsT1IADTn4ft5HvQIanggwKzDYCUG0KsAjnbQOBj/XV7ktb4O2DnguOmYCBqY3cs53ifW7jwqWhFyutjw+Q0SvS9YlcP/ilZJH5wfSl7APfH8+B6rnQS9Wc6JWT4zlnwAqJpbZgkIhwP4sRcdv9ewz1vXAB94Xa23ZLxsV7FNty+xPhhP7BzUASwWKcikuMgEE8IGKi7RGgbeqnKNhwtkguP1b4cL6Q8s3/uVsdD7s7f486XX4fX/+h3vh33mzV+7QqRDwfJXgIPwRDRKV4TBZEvUDsZ2SmZHsE8l3Lj6H+tgWc9GCYjfi2KwgIzGoTYp6DtR3EP6GEyv5JcWIHwUk0XqwxhsYdw4y2XhQHggZicMxBCs4FgKet0uzn2XuFQScBBAIW9JDDQIHTRoyL3lvgYOwMPkGgnPt3Ug9JE8TMymo8oqGTEuNNfK4DA4i5SCmfz7z3qCp9Hszef9fBbL9a4HZQE7bn+v7PRuNjXfW8uZoLdbIku10d4ekD1E/hIS3CdzDiooRvO8VFK+oj83trIgr9730bRB87iE06BIFjJM7y+RSPd0zEkjYR5Gfz6pB+l7quDqlM+13fGZ/5/gHlh3iGPr/0aXNXfH9/Pk30bnuBHNh+isgEIf48oM+yJdIGDNcdO9rEjtiYg02gLZg+34bXRsBVR0HY1Uoi2ynBb4KOZQ5noCKCI2RCLmESeooPGKaOqIyMMibmyBzl1l7gQomNujclQETgM4WVAaZhDgKSA0FcvuyoQ/Sx48ke2ykhsATRn8me87VRvp9XLy46R2XZwz+czDNv3/XE3heyt6lzud92gz4Jznhv9fo46/cCHCquhMfWzP6xKhcCr16VvL77mzBCf/nljMisCCHS9mTObGHsEYxtSlBQGCM8Amy+P72hfOaq6fGw6ohgvRZDz6d/9cepdwubvr7yU5HvrNAVoiumL3Bp+XCUSVi+z3Y4eEj4bEfQQr/taUeIz2LkilWFUfEmaH/hECuDDIN9mMQ7zt+ZNg0QrDV4ECmH4Bhb4M7hKyWzSFKEqRcuMLFVFnfAS7S3EwCCQW0oa19Rwb3FbGHS1RMg1XvO/33tcHZAkbX3Gr2UffD74/JoXu784WTefAakgcAZAoDe7wtPhsW9t2CAjvvZG34VRugvnH65ZHsEr9+k8A2NC8HwS+HP4jt2lj4VluOXAGmfest1u7MLZqX3U2SWrq/33X0wn4efC8tReL840wohPkIlHJ0yZMfwQzIjpsZL8J/fIXiJTfQiDCfaZZNKj493QjgtsJIzJ3RRDTF1KIVXkoTZ3xOLOWrQYC8C0KLkfUWFbVjkHgwAhS5j/lLvGT9PZee/VVk3h9Dv/aXIS+3vIkvti/Zt8WyZFzeigufNwezaXxwPIvTjL7wc2AfBr0oFkU4I8YeMHc/W0/3p04WZ09L7R+4/5M3Q82NhHzmenWucf1Bcx8GMkWUlBfa4dRb1syqwUeDZZimMCxWDngrAAjG4OD5UVH0G59A76WIl7k4VwCoqJiVOubwqcBeLOUgpBS0qJqDqibI+fZOaWpWuz1v/ojp+c7/KvH3Xnw6fzs677tl8RfL4pStH8u1uumy6mDgTFVR/KhAQncV8/PMPhxH64RMvLZB1VwFAYrmfD4jBaeldb2W7UPnW29V0jj5F7oZHJKP0fir7wAOHcl/WPl14Re922DE0E2eRplgizohtskvZhFEsUF0RC/RDVNiO1J5DL6PcqyYPscTBq+qZVWQV1ZSxF3+mqKiP/mzoijwbOpidrzKb3+1/kUXoX1o/nL3pa3pV+7jUro92dVa1s9c+pBURmFgwiBet4sz//vEfyyBC36MWIFZXbahaCGwT6RmXeTSsPjjmzdfuzhq37GOteP+WennLud/Zmy+uuyKoasS1mVgioYkKSOVMEHB6lvhVVbHD/Q7vmbXyg1em5l9lpnO2ONuynUScRYHhK8HD96+vT7PzI+oFKgeyr2wey/YpsvZdv9r9fPYG/X5zdQiIPgwEXFW8LWOySNleLCk+xtc/D8MI/Q9HT1c03XQmAVwsmJEVt7LNjh9WR7u+88a9+aFFX1Qnw/n2pevrQw8enr0UaJylb0csilcQIS5b2FVR0RUVZdULrBOpCP9r5urMRsXg3zDv1eJ9tlHmWa2AOd/KHQ4B8VZVWX0FY9I6c6KgMFep5r8vUHPnT6rsfN+xl7zXR34wXqxkA2blhN4K/H1l6ywWb/ff9UQQof/24IvhdlhWv1rLJHd+aXT2qtXJdJB+gctFN+xWW9ROebN0fdjMeTpLv91a29HaLh8QFdlxAfwlntmoNINlkHCrhN+1qvRbcQZwVgCEbv1sEABtd27swK5jmSTdaAc4uQ9gW2EGb0wItgE47yz4Wtb97aC0/r+BPK9hrrr23APrUwOyTwvpv9mvFhLoreJnGy38vg2PnRvA9xq2iGnNx3y2RSgHy/3Zl1V2vleRte8aPHkye73KztE9560Af2CIDnS8oHFABBMUG459W/D4NYxzxx1fIwBIH2ijt6Jx/3tYLURE7QZhgTnOmN+RPjONPeHE4/RqAM+0fZqKtwaKE2KOTejYFaeELrnz4HiBnFqE+Ynu0Tl5Pz65gH3pH3pgkqVbc+mNtt0OACdbeN+gPjV8f/eOq/CPOeL/jRaGr9DzBBynkG9R7WvTvNSgkjqM04B7NTzY2oDa3DLwvuWOjTdJxfACw7eWETdW0jh9dg0eRBh4XKITjgpr2ETf9hAmOrDzNjSs9hTva4KDKABEo9BhAEQKgkO4gMIl+xmoC7ffGEhBgWPbvpXi9zP63wD6BBI08KzItksLAMmWS0aNNkFWs8+L8Rzl5BCPcxRQPqYIxUfme9T1N7fuU69FfW6+NWgKlC1LIFp9bFjB3IDEh9G+RosZZCQYCWeMGi1KOJnkLYoCDiBRW4TZvnnyRT6j9599ARYMlq81QPHhAqVDVKCthBtPbQQcrRiFYxkWPRDeNJiiZXrWu/a1/N3p6mjh877xbE7Ymsh3GYS+yyB5/ftvqhXv5yjhedHthPBsEcTQdm0Hfa7RBrA5KGEoYmUDG7cWMrZtDxa2YHFvxlrDxOc2jCs0eRqVloKtBOxHCDZhfWm0TTwVIOfYXNSw7NOg+GyGFQL0Yyi+sEQBEsK1BtQphDwbAME0WnADGi1KMWPBBjmXgAfEJDK7StBySd90TlMgNIA+wM4kCp9t2N/1BGmDykYQQAP7ZtoZqJA0WsQ4OveFs8IGJKoQ8dWAxIiTnY/Pzv7E+pFsj5rD9V2t3x4fb1NTAkBnTPnhHWYp07I/SASAXTHbOz6L+DgEqAWFTo6pgMemBQuQObEK1EembT528iU2oa889bzr94hfN1p+QdNo0QLd9lN8XARJKlicTsV4wxYjbbgfjZZbIZiC6/g1q8fy16yek7+R7dnsP9pH52T++JjMdz0+v27VZfnHx/vSp1m6Fp/5Lgwk9hx8a6cOQZHfyT8rjM+KGUaBOO7xa8fObSLZcmJLgAlGg5HEgXjXdgmWJPcWIqJbSGIE+gMhNNpAosNISBtInMB+KUhOAXkH8ZEaBpK+RmPE1kAuVIVDGWIbdy6nAoAMjm8Qsec52Yn1uwZSEiwOliD7HLVoUi+oWehqMx3V4xRo35xLeJ8B9bc+BcjJPt//eupU9pwibN/1vl1785evONvUkOdDPhR5fDIihBxlO9te3liBAI4xPhFhf/u7+ySf0O968hQJjg2fWCLGncy2QfvNs0QMjKHvRUT1EMcX4WSENqjOtrHdM395yzlqy2R+2MzjVtndIHNN7F9Vp8e960ZjxftkJ0Yx0RAsMUraj7KHZ6yosfHhJNS2hi8bbuPiGhIZDWZ7Gi1PO7CqI4UFbeS7bdyWDSDhQnGh7REymGBlxJdphxpHDVA3wjKIRoseIB7Z+57Nc94G4QwRJ+tu84QLlNFHLaIcRPTBsV0bJ7MQMeVzkAYJ8IKsVhTup8Dx6skeX03MH1AZzHNHTnuv3hPH8/nLcXY+BsfZNjUvWVPCQ4DAEXkIHrepoIGlnZKgEnlERkj8PH3sNJvQb1PkQ/UlsrIvNMvxgHGDrKTBlSUcyEVhmgL63vg5AiVrSmSZP00Res7kven/0T5SyMp3GSV4899Xqp0YRRE6AsU9NcY+XGswhVXDEyNYdRN9fpvGfB9uLdLnsvwSBfJJ5MEOX5LGuZ+dxDaoRNJK7Ny+umNZawBpfKjRuIreN6gRo3TKyTy5AOkDsUbAMyNWhitKCRC3TYJtF24wNRiZLEvFG9n5ldP9vWrf+Z3/LbLdirB914fv3K9WGU/nzg/P3nPub6PwihqfMsZIyCYgDphG7fJgFRGgCo3FE+rVs9z/vvvoSY+v0X1sAFMLNFAKq+Ik2H7VCCAAX4w3GBlqTujmOe+7xnPpF1y/u0DctyL//oQ6LKl4xjtccfMlTliFjpNxRiWEPJYYYNWbiPhsgzEOdIaMT5k0gDj3ix7BbKPwJowR0+aYjRol/LoRUGXIS+5c1dNo8cvrXELwBXK0wDMjj6FDDNUoQYDev7V5gxh5qgBcBd5AAqLMRatdMd/bq/aN6zeqXahA7im1XcpH5j9/+pRa2T454tWaO8fK6lGJYCkzrlxb+HwxVEREDFHyyL4X2IT+9UdOVGKLiAGsEYO0uHP4mOgAp6na/uoN5SfmEcU6S9frOT7XHxUycjtT19dNvz2Rna8Xx6kXvujKlK5QhVQVw8ZAeDEyYmJpFJAAYT5QRpD54iOEVxqBnBWV4IAoQFg1ShJ5aN8iMkNfKCMVaCmPMy/MGfCoRDtDlFaIoooWEBqhaw6wMmaoozSClC33725bdGaSHySj9o6fr1588dnO0exZdYSr7/rEg4fG+85VZjTdAtRY9xPLIqSEZVBRCZ8I8ecy2RV2rx/t5hP6l9RRsRHz2RExtRJuFxEUz6HgGBHZP9f2s7J7fhDSKK8QXZDvS38uu/KmvSiRm7/74H3qPQXqxLnLpi8QWqczwJDpMa6wDknEuKX9KNCeiyV+gl0F4BJ3SJIYBcYpPy5EUDLgsxFUoayVWUjkA3TfXHsZ8ow8JakoEEijQKIvBzAhnxFBJauoJIlHrJI+n0ygNursPM9w7hifvPVjtRjOR+ZP7nsxe6uar9Sfv/h29cKL+ybbf9Z99hSsNpUFuDICLGISW5nMA/p96+nn2YR+jToqtlEyqymfiQgvOVTVpmgB0TH7t/I5XRmabrfUi930iYXf+LkEM3TzuvZnYuLD4y1s5u4MDm5ycSOqEK+qrkQuSuqNEmTaqFBcLJJhL1LdjjzryjjYVczQ14uLmtAvrxs/142/ryOBZHw+Wjd+Tj9rZ2HGZ6C2OBfQHvJz5jPX4YA2nxsB/Yp8z6HuD7THsZPVHtIh1rFFQaLQ/gjom2Mz5PezccP6WVgMN8oXBl2462CW3L4/f8HKM57r28Nj+TnaeXZz1/T1qFYfAX/z7ghYJ2yI/W4d8APrPo7/rCPjyhz/CPFBUHBY43Dv70+xCf1f1VGxZJuodq57AGudAYbr9GfHYywKYw3iBBCbYAyuA2Nm+gyCMdMq02WTKpN+de/f33Vgnp2rle+7HpsQ+WNFUr/s5n3Wq1UJvFz34JQHx3w40gCxwiMk1ul7RJCNAb8nYxQcF+vfaJtEOcJex/tQxFrh+hkkytddjIiwsS7gi3Btto74bmDiWIM6BJFJxAEyjCDWAeOtw0FH3pMi7nUruIE2OGBoOwYweA4IrBNt95BkRA0+x4brCOEYQA+JInQ8WkT7of5AAGmJNHMx3HnqhSrXD0fZnw6d9l5XfWePetvV5Mz2e4/moqC+zgAvBMQiY7wiw9YR+nmawGfjtw4IVOhzLdpmhbFBwCBax8nJ/P87nuC/E/2DPeEnPOp3LL8XSLwKOGaN2PT6/Tou8hxgXg8QqcC9tQ/qSpFeB/KObyr/VC8JulnNk++akrlB6FOC1z//efXIZHGcEqbTlwkhYxdZNo4ojGzR/x8RfjO2s8A/0/ILfQpLTEz1JgzrPC6I1gkfgD4HtcPkNATvoftCsY7aABM5XI5Y9wkYpI0AntRQxwCcJ2rxgB4EOqRB3kBcZ3Sy5SEiYtC8gmGdUJXrTPLzESZn0KBnIgFNjQkEHqBKXQ8YC6Nt9dUxCOqy+TvVS1V+8czzXjIf/v6kehf1s3MQvN8CQUaQRFSmvM4IEE/lqTAejv0E+7kR5ofE5fvOTb/hE3rC9NWIaXeur3DuFyEk3Qglt5aHLNZ599W+fOWDR5U4PZTv1HjTV5/NPrVxtJiR5/8+VSD46/9bZu/85p5cCJhTR2SfsEoR5jsc4d8KHLsQrAy5hwerosB4CPIhineo5Arrf8vvg1FAe1Fh0+Lxi/2sGot4WjD4cxvuZHItBphS32kFgkogOEUhztVCPtviO2K0LoKDMCoRlGUChONEs2ttsphocjLcX99xIHtaEbbv+tRDh42takfyezTWwsetzFhj9owgpb6IrVthWUfIOH3zlydYZP786ZdL+UG0YPsWAWjW31rMCqAP6AF/1ln67KAZtYWtrsrpdnbu/Ftdl+uy+y1zf66ve4jSrlh42htt8xg21hkVhKW3R/BwChPn2P2w6sSCAontawwRNasueL5T4xp8EVCLqgLmYCcS1RBbVQAV0iZf1WFJbeaMMxbM03L7ZSrLPle9Ve26/rHs6YOnyesPB17MzlWncb3zW2oh0fcPjRcSrYxKtzValsBpLYmMLJ8oo+6/9nMeoaenXtoG/wZKl60F46XFq0At46pbr1Z9o9rC9h31hjWTvG99rEjm+vqnFRUD35mW3Sd70gGwjpY4FlHVImCdnykuNbZCn1umFB7y7Nb29JXDjbVFyn5nlhjLGStawCnD1bLYdptuu+2tEuV77js2Kbero17/cCr7oyJt6lr9zfG8lKkFQL7V5wGk3N46e+x0JscNsstnfsJ7J/oB+VKFzxZBmUm0zX4aVTROM5Gq14SoBZtvUvPo/67eSbALIHHzulYdBavL7hdPy+5MkbodWTZuW7H9cdfaJiIM8JMzJU6qeH6tcTaB09kOnq+qS1Q7BmuTo17vGZ+w9e6b1GEyBxRpe65Pqr3nb5uU2989eatafjLcGfSXqPXK8tuP/YhH6M+MTlfeh+gVEu+l76v9+qFx2f3CyVvYrtJ70j2Erq8L1SEz+TTS5IUt9W2ohpxtmBxtS1vEq54/olcqoe8Q+NlrC7I9ZiajVrd/SmUxmtCp63/2v5id9/Xd43L77dVlMq81H/jIpmAR+pOHX9yxaQlbXz3Zk37JZE/6m1TZ/XuPnvAS+t/edTBfTKenoGbbMJcmysUODu70CSD0qpxubRsNtPYqc5y1V56D2qD3A7XS9w8HTpNX/3cnszfqcvt398+3+KyOdsRe4PU3nZRF6L/a/xog9CXETt0Sq7rsfk33mJfQr1Fnu+t590tun7yBbXUU3IfoVYkh4izAa7F8G52BMaixGrRm/Rv63BrRmbWAzq8h915DfreGPG/NY9w1oi/ryDOrGLxF7eS79xrQhzXi3mtGcKwFtHPNLrer+XO1f1yfY633kz+qjiP9w/7T5PWl1pHsrddNVrffPS63T+fPp+2Jytp0jWEnzhiulbQ3N27WA+KJuNdLL7/sJfQfqzEhfW6NOe5l7LQe4E9ce68zbITF8VoAFk0OmclXu986Pgr2verAJB+hf/uXx7O3X78nu1Cf7X7P0fHZ7mVxcD1wXNaYvoRhQQjuraV+v1r3YLbHFtF6Cf9aY/rW2gIEvQhHMHAZtR3y/RpphDWCPKm/rzOJhbofByC5xLXGDIS1EoGwxhgATp99Qb0W4KxrgUHFGTsCMGdnt6u5Qr1VJ7p1f15O913v3bUvP7Aj3687OUyGZb+yvrjmEYQc31pj2nKNEfCh/k/E6fEX/ITeUUfEBvU71C4UaK8FYAJHkK8HYJOvXbagBX5OD5mZLvh8lzo5jjOPfqla7Hn+zUqw3qUEq1l2X9S+657/X2Ng0log5ofgW2h7fEkUN67LJDzcceAIx7UArOWKjjU+ZtXYhLaoc6wHfnY9wDHXA4BwvQKHXmMS8nrggHLtt0hwhtiQCZD11TQvl+uyuS6ff1rNn/vI/DfPvZBvATrn2/vyt1rlh8msBgqpUD8LJfdQobrIeKwHAoTVpiMnXvIS+n3qiNhFgD4qY7e1BUimShuHEuGa7eOjiY8fyrejad+9Tp3b7iP0v7t7fCjNpXeOt681VkdhicSy8HUt4FmcBGQtoFqwjHEMseE6o9/LiPf1CuLHrFgAf69VEnhVDlgVRLcsIKiyz2XJfhl9W3Ds8xdZ3Dd/kcWun6bZ79XLVqjrvkfk/Ox2NTeZZy822G2H/1Q1fusBwm8Jwb8nPe0l9DvVEbGVVD6qFEDrSxIG61Xjyyj3UZ1p67Pd36Iy9I+uHvYS+ie6RyeLPg/lMTKrQm2HX4cS0vo2xdR2Ymlo35ct2peMYbVtAb+qHXf9LAf7V4INK7zycqSaX7zoVnXmtZo//+kfT+VvT6Ouz6iDN8bb1Q7mc5N6a9AZGZ/1s8hHFnj2U0df9BL6zb85+drw/2X5+WQe/ULl53r7WnzrPu8BM994WGZv0/Pot+pppSM4oa/v2LdMjETbWbFcRiJQsX1qO07yKnP0bQaG8fy52qd799F8/vw8NSf+u72KtD3X+2/bPz94494SmcsOABauxw76CV0fEbtjq8WE6xXGPPq5X2fMo//2ZHaO8nOd1Rfm0XeuV38CdQYwaofQd64FCb14ktaH1N5bTejU9ZiaP3+LfhnLZP78ivsrKre/hq+f73nBS+hf+/nxHVst4uvTefQ7D8/m0W9UU0c+Ur9q1/58u5vej17Z1NLOtSMedgh951oKyKk9tlOQ+6xaEOcj9IF6u5o+7jUHOT1//sCouCBu5wq+Buqtdr7/PveTHUJf6JoQuvbZ85V4ffPXdmef2fTvR//gvYfG4vWOQ3ms7BD6zrX8DH31bMv87GCCAuzVCBoVf67K+wCfrRtlyHepMuR3fpRmT+x5kbxu+tEoe4vef36LsZ1ntdq2zu5Xwm/q22H3KsbK+P/Vp/yE/rEtGd6n1QXHZNXfdrZdz4J4v1r56rv12wRvGe9H/8cHDs1K6xihf6x9dPbyoSu400ur2xzbC/ge9rd6Fe0tey/K95aFvavLw1kQ24Dv1ZxOr1qXb0BXkQdZ96ubn7Gf5Qt87HerABCvIp9Zhf9WXyXuaX9utfgc1ncZTllfde3kvRdgE+q7TpuJAALJcBX+nF7MNj1QRi+I66jXSD6uSJu6Pq1el/r2yUKh2YI4pL91zE8Qx65D/bAI3rwnR0jUifF1nkf4EAaGdkzUsXsBMTD93A9/dyp78aWXyesjPTGzUd2ylW2XhuWTdSxOqXhdJfAEiO064beUL5jYUqdinALGVdd/oL7m/n7P5AAl5cOJOnMhJ3P7Mgj9y/+V5p+9yPT3NY/9jHbXob5yRVMIJgH28onb+irQJmu8ndgjSKtOCQYq/qx71Ck/g/gC4T6oPXW7bz6cRMarTvEbgTMULtRIY0HBDQRs3Qj6+hqvAfVVxDDIM+tEG+rQ5zhiALqv0RZQINgOugqTYN1ytrpPNFGCA/hsHXM+YuwwoYMJkzoBytP75yt/J+8/16vWf/HMC15C/9APDqgFcZPXpU4yFnLcEH8DhYj9GY9fUQRC2pS6N0U+wM86BBIEQdYt4sdiB2oD5Rd1aMwRf6yvIqKHihkoptZcoQW2G0oOuAIfi/VVGO8ov7jaqkhd9M3naEJX/9avW32rUZHSWT7Up7pN3qu4kKbELIRJ9VV8HOsUFhFjW/dgSp2KO4qYfAkM5o8AyddXETFK4SDAg3UoQaC4i5EIkJyAiV3g9+ZzaoUGr+EkChmvjhgUAlXqO+B91/xOCd237iF6J8g9oE8RGmWjhgdk6xhgQVk7AkZcO9YBgVX3BIXTV6vP08/O9ubedCA79/rn1IK3F73XBepz77px3/iM6/vG7z+vIySMBaw93lhWW0ey4ToiyOpIdlEnfAAlC6CNZKwAZO20eY2IszU4hsjPM8S0jxDrdiYPCHwfodbXEL9dpTPv+hru/4XPrHmA0wPQs/usjN9ZcOkdh/N58Td95Zns5t+egEndIPdzlM+fPz1z4YFjoN/VEWypU/gBCQNfAoBVAnw+jHyn7knE6gxcNIUwyT1rcBKGxWiITzeYcdlAYtXxYZ9fcu1jVYXrdiJgxFCNraAI4K97SMLXIa/aQr7jkvkIfGbd8+y6Z6BQ26zhjssRPXUgK5l/ZoQSx3gQR2jwNDx95tqk4XHO6QlxevWuXuD2vtsPeMn8l8/oE+KenZ+eNVnhXvc4Ouf3Dc/vfZ/hfL+OEA6UsdSZggzNaNb89wn20TUYgEjwXiMybVQg2WM68gJ93UMIdeBeDYLwG4igryOiDAPxwt9WRrnPap8/V7+oRe3W+PrDgiZ0db1bHQGrT1HM37w23dVB9JddUWIkFRzs42BHA2gzlZXXEQz3cQc1pcXBtcYaD+8aTBvUPRxY94mZNZ5owBIWX+Js3qfGAb5GIFH4yB8LyLqnxAcBfwMJdngQR8TgjZC+jECAMu/ZKHyueC+ofXY7YTu5z6VBjgbEkMDWYqHOUNzjFe7zbTz/ct+h7Le7XySvvprr1auDp9t48tdKruBqezoGsI+OSHKGA2bk+ssa5dcjthAt3nsE3ickm3H9c+SfhgoQQg1USI0sf4b74fe3kTcbwTFjhD6zzkwe6mQ1ZcQSjdBnrpps09R7y/Vph5/VK909hJ58/0Ce0evMPif0lZG3BM6JZ/izIxDvGgzi98U9j9RGeCUVqW66mXfRBxsenyl+dgTEOQ8L4YRuxCJvit8agNBtBFQw6HgezX7WTKCoE2DZAINgBJJlwyCtOiMw60aDIFCAQL0RGIQwyIzArAJ23pHjqLjKHYF9gGzRCMicabFAVSegcRoBJDEKU/aT+US9HUeD1adXj2S/UaRNXXep16rqYzMvUC+suMxc4c4Y1wZBLDBpjwJE6IjIBkcE+YxY01F45srzY59orQM+R8cmLloazGpTnVGyLfZ7hNxvxC7VFjFlxKqOwWsrRkFYYn7m6sk0U77SXc2Nf1T5vY/QP3DPwfxY5Hya6d6jE0IfoTHaQEQhJwbqpP+P2JXEOiIM/Jg7Inxp5CRCZZIUqn0UGfuF5cgbez6CdsdohIjQUVDS2fD4eH0+hz5y1GuDreYhI2PENULEwohBiq6zYtk4DH6jAHCks5I6GBQjQsGOQNvWS4B6A8zURt52Y+oZt/XIET/O/TWhK3DSi9v0AqEvq+05PkL/+sax8ZGvtxzMF9NdNV0g5KmaQGodsgsGZnUwe8GEFx6QsGj1jRcmGEeOyDLVdoOMK6oEPSJEDgeMR8C/eWVKXOTDGUUdHUcOYWDJwoiM7QYh8GHhVRxrvUo9PwJWHVv8dnUE7IcVWfsI/Z/Vzg69EPQiY+taHREqvmnDuvN5N3FqgDYZBSY/GNGNwJ+wQBmxKjOcZIYjlPGfYdMNVPW2wUwI/CJihFQARo4Q9nPTqFhy9wUhx0hUJlrMBkdslQdnXSOisyMH/BrgIEOfcysGHADjlXNGDLU1YogJvwjCyMPN1HwZQop+Rn9/vGVNneF+26F8y9p31R70R599kbw+s3JEnYOtt/AcGL8j+qFR0By4C9YjJhHTgdFARFsD8BPa10doRtwIEokjNDOoo5nBKPv3ocxufvRkds+Tp7IfPnEqu+GRE9kHOgIQBiNQHDaQ58CZMV5RC+kvXs4feQV5gyAxd7ps5M1wOMLe3Lr2DrUdLX83uofQP67Ebr51TX3nPYbfN8gqYQjOcsiH8lmsajhiTCPSY9ogSL5BCBUcu8ISGX4SN2KROJzVc7CFX/FoACLfV5Wqj0vuCGCsIIZamf7NGugVJOBWit9prAAl+RWiNL9CgP0KBCZw9tywP2u0t1H4t6fUsgLYaYUArJUU6d/IaL9po7Qwp1z8+8j97orRl5VR0S4rRpa14mbXjVWz7SNkzJH+rczPcNf7azVY3fMLqUj7BfL62ANj8tciYA5sI9fupp+sjFyxtmJ8ZsUPYo2VkUMQhUBZAWy6UhyXYhsBkl9JjXZZRLKC+Ip1/4Yz3gjgGGOuf/f5nx7Pnj4Kv3HttNqD/pPdL2T/sCHmz1+BYxsWDAhQr9hldAKwpnZZAXzK9Gt7TAD/mz535sPY1N6K8Vmw/aYtRrT4WJkD9/TshYu1kFVZ99U37/MS+mf7o/yFLjqr1zFjCtm67cOQjSwfatgYXfDREYLhAHGvwOTeMHF3BRsDKyZWUmNcRrPxnnKA40srBL7YIhPhl/oKglUrRFUDwrmVEb8qZ2Cm6V8NG6cNGzUcLB0VcWJlBLdlxe6n2wYzHmuOEVbsD2EkNR2s1CGjeTDZHbCIa3p/0/hm4K+MisDutLX4OQeIbXB0PmsHjEWYK+7z5vcGBmvVHkyjEmDbaXUEglZjxRICDmmNXHuawblSFChzexgOBpG8bVfIdmawr0xOzbprXHrUYLWutu/8+v+z9x5uchTX2vj8W7/vBvsSjIkmx5me6ZGv7ev0OXFtc23jQLLJ2QQJkDan2TCzMjY44IAT2Nj+HK4DIAkESNqpbgkJcOhfVff0THXVOadOdc8KgXefp57dnemurjp1zvuecyq0JG2qfHrpwHAP+jD1uF4EA2ucACelSLgDEFnXHRVjDKFnWAaojQNE7KYOm+1bN4kkRsY4LoxHYZx2m3oGOBuGIS/LSPwf/3AeFJccef0f8vjXI/aYarpdIOl1pOyG+wyDo+ZArmNObWTp2JAYTNIFrt9mYFaxP7hjoNsbSFwI8IfGVNPl2190EvptMnuVTTW9ktpMetyxKbP1yHYkCzgK6Rtky1FxPC08BYIIxAFrY3oMEel6VFgbsM1whAr6bGYGrKAkQuw9svB/G9TmAi6YDiCuo+3dDn239CKy7NUKFHQCxwIzS+fM4EXDdtMZ1tpdGyrFelGptpkEuVuvEALCSHtYDJNnwRgjR1QUGR59hJOzGR2tG501vFp9gMForCAHQ4ks44OUHiDCddtjtRwoU767MZmNxmIbSIIRAhBQP6HoO7KjxII8BhH6Wkboaj5cLQ763h+OJc/IbWlU+ahMT74nfT/0gWxxUC8CZBIDhkU4bbn3b0b169SY6WABeNDrpuMUWQ5NwQEDvWuINPW+RkUDXzfBzbQ/e+wm5StRfX6O/fUfaVp+G0LW29Yja8zttsS2/haIw4zcAEdod2xgDkFqu6F2GgS1joD6bht7thWCDghnYqA92v+9wWLQGbkXXZ6ncOF9LzgJ/Z6fHk7OuOuFdDHoFQsb2V50zBbXAWfJAHMzQLCd2KjYXzMTZ45zIVMB2A4oE4M4ocwfFhCZwQ1in3CECmO1TfgR7pQi9ljUfVzPMXzHMUsfo2iYNd5GthnQTchB1fi3ViSRCOkADI7b1jGgRCItSEg6aVoNx+qKjAxBhAP/7ogwTjOj4Gq36bzY125bN42LaJuLrNZj52BTcrUVA5OFkcYrgC48vupzBUoKnBRIKbB68s+vOQn9vY+8lIKgAsM0Qu9FtCNiZnvW6WgGcjxQRwaNwG1d2YboQZFUMH2DiXCb5ShjbYJtQR3l+sbf/pH4/uwRfytGdYYTv23d5SRiUaWZHQPsZzdHb00HISKdu20MG9i2G7dX0iYAAlA629R2d7zn7n1OQn/w6VeT0+UWtwsfUYQ+OFwGzYBQ2APJkSoOkrLGPMIDFsQB28YZp92m3sdA8Bgj+oWP0bZ1wplDdRPLYBCZXJB3ilywbZ3IBu+msIbiOeRzK8DOSo0CKRepkQ9cj2Hv0gGMbo89IgCdIQgn0JtAQhFHjHjTbqVwOi27XX2KaS91nQJcIAVkGj1hwPnfGaFnb55SYPUT+YKQXz7/Blmu2L5/8OYpSegrIo12aJ3DvGe8bHPqEuW9Q84aleVgfLabsBGGPWxD2vvt515Pyv7cJV+lirZjt8sxR7JYpD06ohzUhoHsHklmkEPg0hn6uRBQN6Xuqj3l6vyFM+9wE/rDzxxNz19QtnKFOn/BitA5MnfY+u6IURdEZoSsWQEbft02dGoUIlYX1kJkzr0Pc1pi3CFFnQVX9jPy46DdrkANI3W7jzX34EfMQcSANWIoltsL55OVj1FwIr4YiXQjANjKAgf3+6iE4xEzMhYRg5wAQpcHZChwygn958+6Cf0iuXju3B2DV0lKUAwJvXBF4ZQBbAMzQJEjKnQZLpY5cEVUMcuRcDl524w5/vi1v5cmdPX+dDa4MR3jbV7g63Ju6amibU5nnosdDqcKyFJmEbo8XGbuYEro75anxbkIfddvJKHnrwweEnpMZJOAaU+WzsKkzdPvGMiSGqlhZKy3EViE3xt5ON28/ro5iIPNMRHVc6c2y2BLzHKathHf1fiEHTOj3JidRtjG8k4jklzLDRCXPKC0n2+UHDMivYgfuXvVHTEzLpGn86YRuky5K5BS0cdTz72R/OJ5upx7z74UBC9L3w2dE7pPpoUL0FBKLPaQJcfJ5HrUZTJJdH8/K9PtVX4OHf072v9tJWxuGysDwQsSKPLfxqo78oykuM7FaA49jdDTExKz4193/eaYk9RTQlfHv86NTotztyv2tOHYipC3rcfMoMN3rMpmQ7mE5tOOmBlwxp59jj0CSG7/4HHiB6Z4G2q8+e5ygN9mE3bk4XGVTcVzBzsuoQg+mQsu4EclnJAoGc80Bi8V3ErPtJYvZlGEfrsk9GffSJ5+ji7n3L0vBcHLBhF6uxd7tjH2jNa54BKX0PeYmPOl5uK5mQDcUfjak0cqEbraylYt8+WTZfJdZ+NrR5GnQ+1LpMXPRhH6ofR8dkXoj/zqqJPQz5BZrAKh92JP7PXJftJEt807APKVv2/msYpTXwbT4wqY6tYR3jjEnjro7kPNaxDVfKdSwp5nyqRn/u1LrIP/ex4RZi8q/oYEl9fXI/q7jvXXAXY97f51TW494nnrkd3PHs8otqGfxf4ZjJ6jjz2N0OeyF7MoQv85h9DvyghdpSubwzl0n0g2Ku0M2jIm9LdHycLUHWYGqMd0zHqO8Zbyv3FshO4A2R5CNj0myPYMGfYc11JjsQ7YFKXLPS4pIPrTg8cv1CJ0RdCn3Q4QOhCxn3HH3tQByF9KFPYgmcZG/2JYbr3IwxEH1jD1HFjW0+SLtitm2BUh555ZF0FwPRNXI9I+8AiY0JkeEIj2EF5xBosxYANxCUfZ4ZQaY1MDhdSLnYBSaGgvwsGr5wDLHqRokLDN52nkaCkf8r1JpmY/MMNx9VOvt2coYY8gxUK7Y3jgTVnpDlVvYKg9pC+Qc1OQXWy3Gby+aLDbBm0dEvpDGaH/TBL6U47ynnsGEfqA0MMe1EdILpQuIH+7ih4592KEPDBjNp01Q8fMPkBOAjT2YN8MMOtVT7lvqJQ71NeeIzNj6k8vxskb0q115J6CDUG2BBFOhJN3wd4BuwefBzwTsI2U0FeLhL7z10czEjeJ/Dej3+/WCT13Znux2+bWY/xaUE5FW9lmYjw0Rj2HA9VjyIeyxXXCNjEH0sK8GOaLHpKR6cU0uYKBk4mlwN/rGP+Z+AwEsT0zuIOeZfCJjn/6b0vHVYRu3cgAQZNQLVBzGA9KyhywtsGtCKQxbKRYG0xAMQBrG3pdDHuxPcShQdtrXhPT1/UQZYZAyTmWMd4nUC7F+5sGof9UrnJXUTpVzpMH0Ogp97AHeeqYI0P9HTMJPSZkCwGeETH3GA7ZoGyD5GcZuINYiLGotCjuhTccssFkFxNAHONg7bIHLGvidNwcTt56zHfwQNuwZaAi6+Ec+iDlXiBzk9gHf6vrztcIPewhAdI6hKuArFAM8RzX9Ri/d92hk6hTEAPtpdoS09jfQ0gewgmQWKEo3+FIQ/ZOBhQx4ahwg42Yvh7K9mrX1uCLCaVAIz4OIDDAed0jylqPPBU4JoRDCLYXw0LsVWzneuwe7HWsTa76Y//rnIBQ/Dsj9I0hoT/5ZzehX/rAi8l52weL4uRe3rDLi663Ye0DMzFMeYAOmYPwLcMGHMH12H2/F9nA13372fLb1u5W29Z6kH5HHk52DBBNTMgrZmZVYn6QAWYYoWyWi7AxbLBlpHRWXxR3htq2BpG4VnbKlPy7IUIHncwYJ1SsT+tIYNVDnCNS12K2U++WG9P2fBwrikCtoDJ2P5eLn17BA5IVsT4v6XAiAXHNTcQxIrAYj6C5g+lUDMcAksDr6amuRxVIwScyJKIdrufGBdn1kk4Vs58tSchqUVw+h/6D/309+dlf3iBL66F8H7ok9GUxIvSyRuWUbQWD4USpXjKMYaJbp+rHwePT365wsMw6I/IAiTkub2Njk3/E0AEPoHVlxIw+pYQudffy2Wzb2tl377MI3Cw7fvGqJPTBorhZI+XuygCWwlefAKfsmJW1z6iEwxiVrC8eo76NQ99L9mmdc11sROi+jV7nAGjs9oTW45KCiscI0JtBAnHJ9sZjMKjIQ34x07iLRtpSK33VPvSHX0lOl1HKd+SZ4i5C/8DEyxmhz2iL4sqk47ycl3GRhm/b4k3U26xM/drv6NfX1NGvTxwZIxHH5Zyo9XHqd1zBEXOsgQCuT+fQl0WaZVLZpvPlNJKL0O/7+ZHU6b0gX+We7/DwIgyf68dNYPEYsSreZByNj3P7mPWsM7JcrH7HqMNZq5RKPi4K5QOYVQA+rgBw8SYRybjr9SVwumTb1tTBMq+kB8t8Q5LLT//8Blk+PnsgeY86+lW9nKUjiil37jx36TGIxwBSXFCNK7TRb0y4L2d5Vb2c5ckjY9Df+DjZwLjsbbyYpHQ2kISunFJ1jPElchrJReh3Pnk4dXrVFk81TdWynNnj1b/NypxsRmAzzj5sEklvavtj73bUjs8gxW8SOPh6+XEyvlTPZnh98RiNOa7sOOQnxanzqdVZ7h15XvVPJGlT5bNL8g1Vg7etpa9P7W42eFQhi3jMBjwO/YHruEm+RU2l0rEtaj+Vr0+98vHDFXU53iSA3uysyrgchlHKPehkL2dRzmnw0EtOQr/5iSgj9Eeyk+JoQh93xBmNcazHbXvxmB3IONmczGfVDNFmTfVBhN4dXNhlKlDX+I2Vrufnels4HexGTsMDB6Ob3xsjz2O0oYs9B5Fll+o/E7i7ZYwbTxt6RybDCCXWCD1/Ocu+ZOePYknar5PlS6uHknPk+9AvmTqQNJZyQucTRDgO4+lWNMQupsOxQ77854VUxojQ+y/KdPouuQCr84fXksXfH0vuf/po8vFvHS4PIl2O/cY8u4XGums8p8uVTwncKQPmXbtupbPKGVXvQ1fO6fsmX7ZJ/NfF/699TMiDZV7IXs4ibaa1Kpg4GRvj4KND45iGgPjBLefQ9Yyuu22hN16VdGa60fiu7zo4rRtXxCl6jUIttIBqVEGog0sXADSthIBhh/r3XYjU4qKhmECm1911KFShHUb7KMXo4n0q9KcLk3QIOg6ja0Ndlt0BGXYBp6gbg8BRbFsMt9WQNdgvrI9d5N4u1JfidwqU6vLo14vkO57PlK9Pve2b/eTHf3qdLNf3DiVnf31/cvHkQfnq1X72XuiupmNdZPy6DPDTZdstytAao66p0yMnL+zCMob0J+wWwSs0HUajfaHRh7BLOApdW7fDHtyPsAvYS69oD2EXc0ZingOu2YWumwU97cXWtVDdoWmrhc9i3AGG8ATCIs1Ww25xvEMKX4yxCY3n5Z8pZ/SSyQPSOd2ffHT+QJHEfz36e9fg78+tbyRn5q9PLRB6jOuAaRfdiBVchSROx8Z4IQTUdQQhXdPuzGkJXKfCHt2XsAsTX0jZh+4AdHEHPG9XCOlBN7adciQwC03s7RX1Y2QXMYzRXW6gEJOYqOtHqK9yDy3DhIGx8DdgZGFXH8zY7jiHUHqAAjpIyQJIwjgLYG4YdAgZeBd2TsKuRtgFGcS2IXbtAbfbBbRRI/wQqccau25cBEhgXMOerZB5mynDGfavqwg9Skn5YknoZ93zYnLN2kEnod//vSi99uKJA+m71FUdYPt0Z6k76r8prwJp94oEXiRb3AkKu1gkFo/0WQeELkCSmM7ojpzWxtDhqIU9XO9Mx8LSC4Lk7LGNcVKAdBJz1AGgKzgiBX2OQdmHptNjOGghZpM9WOZ6HaFZ17CPsWEP9vUmLiontL60kerw2fe+mHxm7ZAVne8yyP3K5YPS6X0xdX7r+fvQkTGH+6bJDCIiCGcgYiKcI4hwQoxIkLEIgXtD09aAftt2EVvBTWiOSw/W+ZBoJzdAIvWrgLmm7OOhDpscEHaJwNG0EcNRDyknWis1imwtpSYGMQSVMga9F4qY2oRXHBLKFxaUKC4okqlYMFi5I9gQIeeQkAnWB7NdKHgTcgHBnJBT2DWJCicCUi6D5ypQSgl9MgO2z3UOJE9K0qbK4lNH0mg+Bbb5AbA59Awej7ggxxCJysOC0xTDoGXIBh17PXqgHCvr/xh17Cz96NnGHnYN/e0Cjguhq1DEYDq4YZcPiJCjhTquDuJw62uM6mbY1Z3QmKzflHHYw8EajtxHckszU4tZZuqse15IvvKt/jAS32WS+SBK/+D0y8lZcjX8Rakj2x86sk6M6MKk6MIPHMNjMKsDOQ6sjB5gG6FFjDHcrl5s2R6qCz3IYbFJHw2eunBwYGFoL+KRcJfIkLnu7/E4rw05nIBN6P2shUbUFToaFxIgFnbdxksBW9jjOw42wMUk4TsdEQeou4jbpfRti1x45MuJ2KjUIKXgbQQ06Po0Z2nNSD1Ov5L86I+vk+Wx3x5L5xIvGMwlptt30HGLLfJul9DHkHE9lpUJuzGp55xxbzsAm3LEQkT/8Da5MzkhQdq2HUF2FRPyddth2IWyPh52z+lHD5d5G+lDyMgGpIS+MlgMujNbDHrr9+MCmVvkLktTnr+gppoukYTekM5AuCZosuq62k87hm0keCAdeuj+njuIcdka5NC2GfoN2WGb1F23YwNlR0NGsEkFVCERcLQdPNHuuTLBMAZiddfaTGBpO64JOYTmcU/o8OTtEpNAGDJBwk9J+BFS6IzeY5Yhh57FNEyfujAiHfZLgpIi9EvV4qAH9ieXy+07LkJXh8+ceYd2wIY6XGatHPm1ASJqe8iMA+S4kxBbIBEyI/aQSAW6HNTQCwhjZ/YoZDiHUMrTZbttD8fVpftYdsnfxvg4R92Tv2lNbUFTK9e3y90dOXFPAISuygX37kvOUbs7pK2ki0HXhHNMQ2Z7QoRITGc0ZGAtl7CdAYgxTljUjetN7KW3bcbUXNtBvrb8yjvbbWJsMKcHdsBip9MLRuhtwshCD++R4+3YnYhRL5oLjr5p+5Dp/ba9CNCTZD0dDwjc2p7OBCey4ka8ai6xmW7fyfbjnnbLnuT7//ta8kNJ2lQJH35JHsiRneee70UPS2RCXDJtezqjITM6ChGHMmRnCGJwTrBNkFbIIC1XJoGvizEjixWxSbhd1gn1cHDbRCbFRS6+Dl2QHipzKNVh9bIhk8zNKD099vWWvcm5D7yUOr+pzq/BDleI6gkeuLQ98AmbbvHRr3apa2NnO310zEW8qJPYo+9pM2THaVubiedlMIfipVoZ8rHBK65IcDFDAWNPwo5LAUiV6Lhduo7Y22naTAeDXbci9OV+Cm7nyzOtT7t1b3q4jIvQP7OYRfSXTB/SwI16fswgRj7Y2MbLBZt4zA5t9fGu6kS2PRzMcTmtvtMmFNi2PcC2XaGPbU3n0z3o8hwFRdANuQd9FxKV5+XenxyRzu7e7B0G0vkNlmGdb5O67h+UcAMePu7zdYkztm2ms14Wy8sGc5uBs65Moi/JY9fV+IARV1as9hpd1/DatXLAkda/xos4KCJFBbrmIew1rXDA27gWkkMbaUfajzU/A24b9RScKqiutRhsgyJ0dfJVfvzrwz+I07Q6Va7tbiTnqPnEyWw+US0QImW6ZsvIRbpmO8lU45q/3pnts+VJ3RPTemPZC88+2ozntrkR+lo5GTjHr+seS9+1EOFajDzPodMlwLQ1mGZSqXO1buTDcwes6Nwk9usfF8Vz3Jf71Qh7jdH2Nb/pHx+nkeUIrCHO9xrhiK+5dQzUowL2x6XtuO2h63af7H6018pPI8IY7a6nZglxjSdA8L41fADaawDRrcHkl//dhkgaAzxtMMFndBnP7xL3rrn7CPZV788aUdcaoTRrSF1Y6RptWWOM0xrlGMWFMdHrzhYIbQxPi/uKPDjm+394nSw7f3Q4XR180a4D2RaeFUHLnTt+azZBo31z6m9M68AaoH/Gd6NnxaiuhJAzsQbrTNtwUMz+truYTkCEF+P6g+nLGuy8gLqfOw8OnW+jdhHj8oV01iC6dk7oLnwD9NpyFrTv87MXLpa6q7ZffmF3H4zK9fJpuWXtDHk0srIR5fzmLyViYcoajAFtRyDRXqPJ1sKHNTsTYcm7a9tZew3WizbUzjUCw9cYBXIIqPFFnx3zrgNsp70GO9uWE6XJRgVDBf3EeIcKphEbMe245gSPNZq8YKHHtDKsIdEvpmiuAV6zlbC95mjnGgzwbRdhUITadSmiXx9HfYrdBsZwUNouwCbkiRGYWiA0BDi5de1KGbG4CP3R3xwbANzLQ4BrO/qnA3+b43Bh8iR1OUaBLiT0qz24t+1ySix5xmz9JvWEIDq7rpgmMuazQGfF5aBTbaacpjU//GmzSAHW7TZlh92iA6sOirlNZqRchP4++UKiM5UDu3PgwK4KnmPucLYohxLFGoiYHI4rlj3kOH/OOj373e7C/+NyjB36EtPt9LEJKCDCns/h1C4Tg7RrahZZECDTxoS1FvMAqesnIN2YOJ4cm2SJOtu+4Nql29Neq1i/k+wjmAwrOiFtZiZAgVNjcbR17Yr7X0yekKRNle/Jcom87vwdL6Xz78N5dEZ7c5m2u+MBiLJj0l6LqoHyGO5l1ddlPKPryHYw9dAlvzb3vjV/J6O9GfIGnp1OMak1IzJ9fpZ0Sh955ii6XS0vF6oV7oPTERsL/QKhhxV0r92N/LN349S7bol6uuXwju5HTOtnt7q9W9OtmEPkctKx9nbHo7+1cUQIXEPjkkS4Nv7S9hFM980HZn6JWZmI0orm6qOc/w4GW9fUSvdTb96TfPu3ryVP/P51sly5cCC9/tLBNh41N0n3I9480uy+WWNX3RkZp162N0F27XE7Q2WdrG75ukd1idT5TBfESd1t7NjvjM4f+uXR5DRpE2oRaLrCfak/XDPS7pYkwS6QJSkx/u3NclS7FUmfae/tKvbbrfbsTQ0kGPdhwVkNany7smDitx5AbgbJOuYlT6TIrmxR4KRA7rKZbBvPu2/bm0zLVb3fk6RNlRu/0c+iFnVylopaVgSZdtr0SHbtbULq3c18RlzZ1tuVxymGpzc2Sb7tgq6LdBHnJZPZgrhPyDcHugj9pu9G6e6P4Qp39YZBToR+Auhse5Pb0T7uGByPmefcjmP7OI9P7e1MrO1/aqfiOJK6nAO/Ij1o45X0FLhr5cK47/7udbJ05FvA0pdV5CfGLYu3xPi230L63H6zIhCPtrVPIFt1EZhyOuuDtwueJc9lv+HbEWtB3PA96GqFuyL0twVOxlvYdwJiRW1LSFvORFXjbA4WCl00eEnLR6dedhL6d377enL+vS+m+9dVdN/siK0szps5zbRV6LIapU5nekKcnD8/U86fP/SLo05Cb8kjX5XjetFOt+P6zzc+W07B5hH6Kq7I4P/671W3MZDPWGPejz2/TF2rQNvL9sP1f5l++n6+WvEZPvcYclORi74w7szbsnn07/yOLlcuqMM59LlFUX4std/tisA9VpmuOvRntYTs18Y01qtjktMYyLLyc1Yr9H3VXZ/SzWBpNH8ePDw4UOZXg5KTuPa3OiHujFv3yKmlwdsFB1s021zcdF2HYfDqmGVZZRxXy2B0/Obq3WoJnVw9TvbiaFfN7EAbU5BVRIF8PqP+XnWQ7Zpn/WUEv0r8DbSpveogj1Um4Kw6HKRVpvw4suPIZxXvM+YUpWA3WBj3rpv3Jgs/e1VG4a+R5Y7HRPqWtov1/eirDv1YdQAZpQ9rDDlzxmbVcS1Xhka9berZlBPK7eeqhzO66uFQrzpks8p0qqvKljM+LvBexZ1WtdZDvVxFrf3475VDRQL/lf337XJL27tu2jM88rWxqDmtHHlxMZXtNMY8W+Bg1SrPuWbLn9uuVWYw59CVNvceLv6uMcbChQsunWDYbo3TeZbBrlYwvDIGzAWDKvevevSROyC+95aRQ5l7uX1A6lYp82w7jzwx7vZ9yTVyHl1F6VRZ/1X25rUL5dz7FbMbWdrdh9DL6uA45LLq4Yz66Boo8/j46cXaGOxx1TMzserhuPlgRh7trVZ/hkqV6/vP75CHIw1JHClq/jw9IU6bVmqVwVFfQvfVMx/s4zr/PrjPdZ45n69V0KNVT9xf83DAxoEtDOej5h0NcTtVxvDLEvHaJgO1L7lvNomsjbE/q+NRxBzwLnokWzD0XztfSh6XpO0q75eHbpwno/rL1Lnug/dEe8v/eJH42pjqWxvDWI+1xOVkeVza9ua3IdvJ0U9XqZ8vV6tfeN+LdoodIPT6gy8OFn4eSBeNpvPnx1vvVks4mWUDsjKBz9qY8GlcmLhW8tlrmzBOJe6pnWjGsynPWdtkYj/BAel4lHQeXabNL5mQL16RKcl33fR88qgEusf/32tk+er6Rjrvfkm+fQ0CvbXjOK5vxbL2Jurf2ltM99f8nfJMt7N0+3ukrn5Mrv1wRec75CtV33XjHm1rpueU0ha2nPClfQKOTW0L3Lb6Mh5Czw6YuUwuGjovfZXq3uTex6PkMUnaVFmRK4XPvHOwfW1ukHZfObH69uXvHUlW/yCdjx8eGXvdh179e1o41370G3HynWdfT57v/y35QG/zdOQG2c/l37+W3C3XQWzZwiD7NDdKt9/yROwk9Gse7adrSc7LX5m62LcJfatslS1C3yonJKEP5tGvmB3sR7/jheST068kj/3mNWcZpd1PTOD7niRR9fOcJNJx153/cK9/Ifpbev2sPA9/s/qryFz9/HTvG1t6vZo7qnJ9iDw46SKZbt/5zDEnob9PTjmptSRqi9vlM9nxxq0tnNgqW4S+Vd4qRUUy6uCNi+VLKNTq9TNlhKLS7t+SpE2Vm2Q0c869+7PV7vle3ROoX5/8Zpy88bd/pCR365NH3lRC3yEP5FE/3Kh+i9DHoNODqSSVPv9Ux51uf0Qe93r6zc8nZ8szGdIXspyAOr1V/lkIfSUqpDxbq5GdAl2xvVjsfsjjheoA6zKvW2Hcv4J8j7XJ1VajPvT5WtvINmLt4qSZV7T+rRb/9ukXOEYrUeVUd74fPd2+9kC2fe2B78ZOQl+XEc85ciHdBXKFvFopn+5JXwHatMLvd4uS8UoxtcwpByWBqp8/Hfor6/ob9PT8SvHZup5wCL2l3fcBebTka3/NnIsbvn8EttEVYsx1Ga7A30OE3qIwYYWpd6se161osjLkh+rECsPmAOzCMEfVqU52U1kntRNDpdvv/vERJ6Ff/y2RnKq2q90v0+2Tg+1qK4KNoy2s3RwMW/HEVE/8dvFDa6Wor6QNunRohYGdK7Zuc/rMxsYVx3NL4m9r1dbbVomxM/Wl1gIE3NIMuIV1wAQoyOj0hpp1r2jGtIKAhDFALeS6FtQGsx+QY7BCAO4KDXotgmAtcFkxPnMp74rdXlI2K4ZciXabpEi2a4X+uwW0WZGxSjEqcj5DHnn58alXkm/++jVnuXL+YAaAU4M3UmkRDSRP0OFytXml2O+cuDbjR9XdQsBA78+Q0LXPrnr8cKVnqyi+hekdMMamE1wgdEiHCQAGdZ/QQwh7QkSPW0ZdLcOBB53dFaBOB5EN7Wh55KCqufCmOkzmV+50+38+Mki37xik23MH1ZCRPkaQHbZWbdmBY7ACY0ZrBcDOVQTDVopY2sIIGBkrSNdaKwyncpXmCsiOdRuG9LtFOH3mM1urBK6tMPoHyQR5ZsvhlEDXWcTvcHhqFODrg2sahfk9CJ6YB2IosaVQ2MAQ4E4KGnhGiCnFqp/ymO1qAX1oEfItOCSrsBxcfXM5DGTbgTowWUFGb4JCmqKcG6XdT5eRiorAH5WkTZWdcl+v2u6WHpE5WBxnytICREx3CA9ev6czIK6n97+RkliHEXl3tAL9r+qyCJ0oOgnn5ZrvVSd06FmujETeh98d+Gtazz45X2/2G/pf1Yv2dRUmLwz8WwiQYo68y15QgmGAtNJBpcsXDXT5y48KJ5mr42BPu/H5gS4fKOhyiGCmq+2Y7FqYrZoYjo3JCuJAMbCYcizCVdtpgXAOczqxdrVWYQyAsjQkNkBYvYq3G80GrNjBKSXTlsmNq7hTB3IlEZzk/9dQL3GVBnlMmVoMcmg5yLblIC9K+SjBUEbeQtJCrj5ShSLUlkNmZnahxagHI6/WKgwELYcDgfWXGt/mYIuPSjWeN0i73yrfrOYi9G/IEsj3o6s3tg0Xxy0L3IAQOVvtRDIremoZIkDTFn4io1VVXF56Pset6obk9L8DsqR+rnrssCXXz8rP1Dz+3//+j+RzMoJ36Q0EXpuVkdCdFwoXKLshnfxV/FrM3lsreDSMkaP5O802ycVwF0idPE8S+sNybtxF6Ff3NorpdmkLzYEetxDbRG1rFY8UWwznNkTsocWMOl31YZjCCQxaq24cBUl61Y1BLSP7G3IcPYdTEQLtajkwp7XCCPRWcV10BlnAeNa8lIECSlfqgzBkjmK6DJH0zFb597na2PIgZQ54cci6haTCOGDpE91jIOMi+sK1yxkQXjFMu7+QvHf7/uQbv3rNWW6WEVC6b3ewOC7QonSWA7XCA/6WQXA5oVPjm/9QzzUJHWoDi9AfP2zd+8wg8n/0j6+xozWz5P1VETiVjdAj9A4QwZvXmdmIFrM9VT8PV3iZMa5u6N+l0bla4Kn2nkudvHL5ECvdfrk8t/0MPd2eOqZuLMEicTaRcoKNVff9IRUdlwhuQgbmczEYI8PQESy1kEyrC39DRqBZBtfDFY+Myyp9j9meGjca8yW6sAT5hYx0dfEewVKm7LcgDYQTXeDyEKyIJGT9L1hkxDXksGxU5KGw5vVDMNyVnXt98lefT+Z/+qqT0HsyNX+BBMQLBkdlBtpiopZnKeNMUd+PCF045d0idES/5o4fv1pwFDDduH1wXf/o35MP9or13ijT3Z//9mGns9vSphhyAm5pdgRNReQZCUyncgehgxB66AHoLab9UEQUlnDq4DaKVPfytSBny8Vw98s9+S4yv1tOG518w/PZ+wnU6nYj3c7RG45DNG7dbjFJteWUs2AFbnA/RUH+XLziO3SiFIb46rBvMFgmyKSeW+MouzvtKkoLylUnBZC+BAUrgCil2HzQEkDbROWsAHeA7T4KtncfWrIRDBITaao8kKnGy9RiogdfTt59677kM7MHkt2StF3ly2sb6Wlc6clx8/3RQTMliJyrt/nhLlTJfzjXcuW++4+jFPh9P38V7OP75ar2V45kz3/wqaOF+j66O06OvJ59p5wDF3gv//6YReiQjS8ThB4CxN8x6tP7GnpiANdOq2QAXN8pnWvM99Otaip1/iGpu5zo/CPytcHqQCV1psLwZSzLwpt4q/SFJkpbF0MPm2mt+Ey5CiuI8h270DH2LU8iLeO4tEo6OtA4hCjXCMQhEiwbGH0uioTOUrRlPsHSDRAsz8n6ftmH2ITbQ1v2Jwi6CM902EAWelpu2R6oohcsChG9FdUvc8aAd03IutcgLvn85pJ6WctGut3nLBnhnHXznqT7i2PJ7mdeI8vK08eSc+8ZbGEbROlqDjIDRsGIVoRT90Ik+h7XDzfaeHFwSIz6OfrGP5Ir5X5387rH/pyR5u9letsEuB/tyQ68+d+DfyWcXAFE1MdIgMYjdFHQRZzQaX3Bx1CAzmOIEpUojLdP1Bhi9q+c0cFOjQsfynT37ifVi1jy+XP52zxY5plsMdzp8qjX9Oz29GVD8uz2JTPdDgG0APvbAgigtWxnBENGcEPi23Jk4YkPAYaF7KQgnHyM1IUTo0bPELizvBw5s3khM7iBcZeXeYP0KkQDPWHgfeSwDYH2IzQJPRxEVmlDdK8y/3951MhhA/TvVoSteMsjI0kHdBkehGHdw/qFTd4Q4S3jIAEbq6ZAel+XEUECzxn1e9AOqA/LCPEZ1wwVYdkApYJ8jfqWYdIOnZkLYwxXgD5hbYbGtlCnbSRplCMP5LhURTky4j71pr3JV7sbcsX7a87y+eUNec9LaYSUHsrR0ccKkrXIZLhsy1PPGpggmct6SMTLmoEZci6Q9TLsqBXn2W1j1cf888bWNEXofzjw1+F9aqV7Ttjq54fPv558/7nX061kv5Lz6X86+Nfhff+dOgLFcQx1R3Gg98u/yyL0zu9es3RG/1uP0MNBm8Nlm1wKKXxI/wu4IQDSxvS5SLDDNpo6sFLUgdaysD9bgW2nMI7Lht7OD/RWRuf/JU87zAh8QOjPDAh9+NnR9LOrVg4mp0pCz7JLB9MIv9UB+r8cWTZTsE8K0Jej4Xi0NCKG64+G8sq34IUA4YbLo3otzLawBND9ZQz7HAHUMpQd1Zx2ILNR5ANhE5v+2bIRREF9hNq0DI1R0Y5aljMJ1LFi6uqIA8NlQ36IPEicNW1s8FkNJg9B/C0Awy1eCyooUX9odLpAmqADIIBOCfseE6DN568gipgLfRkib5jcLQPTlWJZGPUKWy4rRj2FgQJId/hZkcxsBwkhQ32sMGdkWSD1RLAeaACRRjqL2SrhC+Xxl2px3MV37Ut6vzzmLEsytWxG6aBTCYH7StFowL7ouqIROtUf65oVgZK+DXLC0vk1SYJqxXr+M/vrjGynJWmo62cG/1M/6v7bn3zVIqrQkFXehuXf6XPoCBArov4dEKHrzu9y8brUQdC+CzF8gLDBshXjt9GfECCQcBkOHsLloi2Hpk1ZbRjNnaso++y7XkzuyQ+SeeboiMy1yFwVdRTsubftTU6/Y7AYbtrUWUDWZL8NArNkQgUaxnWYrZqBjO5gENfbThPiOIE6IAy8Fqhd6n0KOdfqYwzptiljLNq3rqX4DuYBXL9gvgKdHEzHSbtJCR3y7IoCt4x0GfA2lxHQXNHJUQCejzlYwmiDTszYwCIDDV1vPVMYJIEZHPAcM7o1rg+xQS1kBgSg7BFJHDC5wo6IPR6Ewa1ARkfJla4/38ebL4475WvPJ3d9U7BI/eqVQ8NoJ51LXyJAccUFkpSMRTGytogLIXRLF4xrVnC9ea8cP7XA7Q/aivf3ytWsrxz+e3oKnEq9f0ZuU3v0T68lD8tU7m0/OpJcK18Qc9VjcTIh/89PiptJyT9r57VPyMVxj8eo8xYCBBwizlpO/D/d+zoKHOl1+Zy8vD405b1CjZEwQArDAYFnZZAxGDk1SIYQ1WsxnDvPo/MPq7nzZ47ZJU+7Dwj+Grkt8xS58DM9vjjfe76EOSGClCndXy0VT8oCw4kI0U0BYJYdXTrxBItKgYwozB8QzhmYtgKPORhsWnas1beC9yVcceFm0VkKlwUDk4SRJaHGXSC843AQV/IIfdiwiDAswvAIYVreBanMEaMDsBdv3huifSKAYoU7MJwBoOTI8AQ5XrzphK3A8gkxuSH1keO1Qjk5BkDmi+PUiy1k5HL6bfuSxtdfSLqSsF1lWW7/yla8v5Leny4w6ggv+YSccdiEOXTMGHO53vezbNX6w4MtbnlUr7a8/fblvybbELDbKck8j+oXf3NsWP8H5cI55SCon9XfHQPsIKuno6fcCV3o/G50Uhxle3l9y797DdAdG3hDp+0XyS9cQUAcBTzToTDlT+h+Z5RRSle23/1Ccq+Kzp8xovNn7LT7xXfvS94tdVu9vOWyqUPZSYcd2zZCMuoTZAASsjAxcmCzAAMPOnBxOCJ5mtzikYjAWGq8IAdIgMQZkjxF80oBG1ZobAxXsIDOlcV08RwccOhtC1e4xC60CB01FC6pRjzCdBKfcBA71Q5qUFyKKxzP4yhL8f+QHFRHCol0AFwyiTwcCJfM8GeGzMhdLQyqz2Ynx50jt/OoLWz3PhalC+Rc5au7+8N96SrqUYuVmp3IK3ILGfrKWcHuc40rjazemKYOifmYXKWuE/p7pfEqcjb79v610RvfFKHP/fpYof78O7Xi/SPrhnxWbAIe90+n4ERwo1HBwAEOQEORMOy8hQR2BEsqm9RPdU2t+fj44kGAyE1CP5pc/82+3Kr2XPoilnSrWroYjuOcu/E2RO1fMEg5qoDBwmOsfLINbh0Jl4WjLuGepmEGLvz2cfvrW6fLKaGyrnB9NTySEGDE6yY/DiEJD5KJPAbIFe0LT4ckYiiXQKJaAaT4XBG569k0iYVgGtMHULjK7LrGSGOmW9hklP6gitL3JvV7XkjWJGG7yqpc8V7f/tIo8hlsY3NGJUT7IN12RdbwHLpdd3EOHZbHPT/NovOf7XvDuAfWs+tkKv2VI38bLoC788evFtr50FOjKD+bT8fBIY+8x0/or3k61USqd5kzfSI8nHwsYzO6VtdRNQd+vnQ8t8tthDpxQ9H5Tvn3hXfuTbdlqu2Z6clwQx31CRD88Ch04iEHQ4UHiXEwSDCCkIgZbPGDi5CFRS5HBOeZkI3bHH2PmE6RKC23Gj9qdj1YGN5G5BEBcgcX8+iEhwNBD1DonUngZAu4g8oFxTJKIZiGzCH/iP3M5iCVeYWM0i96REbpMpI5RR6+caecS+eQ+r3fibPXUMp7r0gXyG0wZeaK+IQ9h06MFRx9R+A1mEetIm01T65+rpdEXXQUimPxyW/EyY+eH61yf27jb8mVj8aF+m76wZFhCr73+2NO+x3NoR8jxzCP5H9SmEO364VT+GVtx4UngkHu/NTk8LfUz+Zi9ka1i5V+ynnwq9c34PR6IWI/ms6dn3z9cyP9lDqeLobr+GbLogpEICrgCz0mIQsbfB0wzvhBuC6YDgknk+qb5YhKBJrCM2vhQ/w49mZz6B1GeqzDmEvvAA3tmPU7iEAdJNJBFL0zmu8a/s7rHz4n8ksh6f3qGJ91tDLsYwTcy40gBAgoLM+40HcBzNH5OGN6nQ6D6VTIsnRGe9JV5HLZZB6l70sulSve1Z7zVUb5sHxjm3odaxoBpQuO+oBOQXoI9ceUoUGqQ50qji8efUfwNfpzBtfeNTjx7Y9q3/jgWdCz9TlxtQBuVi5+22bMhapIPV8cp4gfHMdOUc+3y2heHT2rfqPXd3RCfwOoa/T3XT95NSX9u3/yKq4LnQgeg2XDxqj/kf4UiZNwpK06R3UpXUq3qaXvHng5qcv3Cez85VGNvI8akXpW1DXn3z6Kzi8Do3OG4w3ZcYcgo45gZsgc9mnW00Ha2nGQWCdKeOsbBGAXRFt13uhw2m/ism7nHgsvOwwnAuKZTgTIy9bpEMKoTgTrt4XVkaNNJqFDhtWJir8hIULE2gGMsWOQsKkQulA6BoF2gHaZxt0xQLsDAUhUBIMO4Ih0bCejqBQRLisLyCLDsTGBBmirVQ/UBuCeDkT+xlh0AIVfBmRlyhR0aCJb3qYsOtEgShfDKP3sQZR+c6/PIvQZSRjq5RjqoI90S9DCADjBMaCKYeSdIhGPdVFcB9B7+SxF5l/57mHr2aauKfL/9p9fTyN1vQ8qclFz6Hlkrvakp2TfgZy0CAesjkBsVGjb1l4vAkkHcfY6gC6DuiBgR9LEj+WIcLAjQDeBayBSMJxz5WgqXcq2Vr6SnCPfkHb7Dw4DBH7M+uzq7qHsmFcVnT+cR+ciW+PREbgNQo5FB3M+EHkuE/22xiDi1dkBApROBN+zDI1vRDgKEY6p0OfY7w5R3zISfBVwM8LbbeFhBNQZIXVGtvxJ/YMCNsjhhIJWgQd2HUXo4KACRIcRPESuLqVBjR4SAuIMuBQSci5IJyECZMAAKPBeilAQb7UTIZGJGVma90Q0eaG/OURoyjCC++8giDStmUfp8khMNSeuovRzbtmT7jlXkbqr3LB78OIWtfBoZiMFYn5fMSczKkTJ41sUJ1C9+8SQoIvPBvXY0MWPrcfJUy+8UXAe1EI4lXo3sw52XRFMHIAODwl9z+tAXzAdAxz6gf5+6TuH04g27TsElrK8X27bU5mDdB2ASepayesqOjoRKC+QOAcldTKXsqkgtRBOvYDlE4uHgMjcjtAfkrsRzpSvSD1dRufnP2BE55hzy8GuDhK4dIzspROTANzjOFxmREgFalCmEg2WHHIx62DxB4BNVAaoQzg/ywDPLSNtXwYCUtR5FUgboeBJEPKKcH42xreGenOkkmEeYIR4VMJDiSMGuUbEACPOiUtIPhEe+VnEGCCf+hAF5BC2o4RU5N7hADlHVqNrg3yucmc2V3mqXPH+ufkDycpTx5xlWZb/fEQuWJKpdwWgan+7iohowuG1uUiq8HgWrlkW9DXLEVFXkVTtZ8PO4g5JdkdeG6Xh1Ra2fI5dResTkuR40Ro2vgihs2SJO4lfki+OybMJahpBETd03y80R2XqmaOgk6zIvFDXWkQ75YQupA7mXJZqV9NAlz6wPyVqM7UOResfn30lzTCdc8/+0doOPWvkZS8RQfQckuY44Fh9GBaXeQ7evpAdOED/lwlEGLzAwc1lDk4z8NqJ8xEhA26wKAYR+rJnJysprQ8pRAwgijyVhCuYiNkmV90Rvz3cZy1Tyh0xHAvBiLqikmNM60gKovlq4u2vpK+ZPFUuKpqUUdnygLSpsksesJKm3uXe9MsH+33TLUJe+hmBBJYu7CL6ApN+8TpFujueetXLUUMj9ME998jphhe0M9/V4rjPfHMUna7+drQVbfcfXsMzaCTYFK8tnBTn7fQWn7f42+JWua99/wh4j35qnprnh/qA1xV56fEo1b4xTLXf8r0YIfNiuVee637Kdc8mZ6h959rceStf10E9f7lMkBAx8TkqaQfCU1/KkDOnDVGJgDLCs0NseUb4lM4yh9y5HDQuLqXlUkPDfm+PxwfwowrXVBVG2XrLRu1RSYdBeBpVWZmOWx50/flc+iU7D6Ynwb1Lnn/9PhkdcQhdla+p1Ls6kUuPjJbGIT+6/TDxRv5ZC8OZgur9oIw8d8mIWyfy6Njfk51PHwXrVNF5Tojfl3vS04NpKjhh+aK4n6IROjfCFMn13xudWa8yDB9cg69TB+rkP0v/7xhY33XytDy4Lr6zn5P5FTPZ2Qgq1f6pziEHkY+IPrjvxVRn1X2X7BytbIcdyxL6wQ0anORRlkyqYGiUeGcbx4LTUVI9s7qZjkzEzFhXwWdqDr2SBziuFG00JiKJGFFJFQdkXCQZjdG5iUo6AlEJPfBzNFJAnR8sRNqh3mb1YnLSdc8lt31DEsnPjznLkiwfmjogVyTLl7fsOpgeWhMs9kvKO2KPs0280VicVLPee2VErg6d0Yl8WUamdqq6ODb3yf3titRVufWHRyrZpJ1yL6NDo3uuk6Q+L0+2S7fdIXUocp6QhKn6QcnsemddtI03F7PjiNXxrmr6pvHQS8kjv4BXspvlmt0byUnXPpecKd9LkGeJgnmfLFFV+44q4GoZAowqYvk4MHsznhmNie82OxgSzEyNwObQkQpMhV0S+Hcd5nde6XNu26IxGIBj7s2oqznGwW2yydkhs6WyKbjI0xOPiPHG58UUAeeget798n3pt+xL3nPTnmT+p0dZpD73k6NyzvMlmbZ/Od0K15AnfKXz6RWih6YDAEfEG1XPVi1BhJ5dv03OX+7p/y159pDaXvaqRuTuuUxFhipFXxVM3XPoRGS4xCGDEva75NkXwAYUmStdUWlydaSwmr6598eHbfL+pU3w239+JDlDvovg3TfvTc95V7prO5MRYcebFSxB+htVDrSaThwfjXVTW5dQ5IaIMUYl27mU1d9kzWVXzaiOOxPA4clyz6qNhIOTd3MJ+FtTnKY5iE4HQFttuiQKSlG8L7IIqpm3o2DsUfE5S6Priv0aEPKSARR6G7C2Q/XkSglc07TkOVpd2+wYdUBtXULaYI1HZPWnuVQ0GF0WTjlr1zVNeXby5wFttPoq7MhlyUx7Dg7zuEctkNuTfPSRl9IInFPuk1u/3iPvy7eypauMl/qA0RMyXUKcIKB/V8l566vyueslZNxA0LH7ruuOVa8s79dS5k0d+Jb0+xllicimLJl2O/r9EbkPXrXpY+uRNYZNSmd0216yv2si+gyO0ZJu69DzizIl6xzgTJ4Zukid1S63m133LZHtKR+Q+E6dzH95rPDd+x7any6EG25Tm9amewy7Ae1jqSizJjhGUUFOTcTumxg2Fe6LNCyOim3T8KeJyKw5xCsD6wx9NG0exIRC/ZHGE7qeRLhjsSSKcgbsCMT0JVPGkRObi/1C2reE/zbrsMcqKnBkE+ReYLxyTEZsu7mUtb/W1MF3CQJ/c1Aiu7P6/RApLCGDaxm9MThLxbZZ9Rug0jTa2QQVMLKMEAb4nCgJwsXIz5Rlx5SdraxNrZ4mIVMUzKjPlop1NTt+12OA1VyKaOAxn2v8nx02czCNtM+4/YXkP655Vp4gF7FJ/Yb1fvKefD5dLnBKSX2R0jEDUDVdaHYcxL9EOzNNTbeauvEBIG/raWTpUhPQ7yIoCFqPdX0DdKp4f2Q5s03KXjs0kYL61HG0F3KOAWeoBegU6Dzo/y9mZJ7Omz+SzZt/Um1R+6UWkf9yRObpwTK/HBzvKv++/tF+qptqEecFg4Vw6tz3JtiWYqQKkrPhzDchrOyYxDVy7prEOMN6EdHXdiBshcgxAnWh2YGdu5EuR4a9RXD92uegbi4VbVe3N4gHaOcK4yD42mZBPyPLFovcAgdTlK1A2ILbS4TWVWsaYDscAEBRWxrhNgnQzwWQD2QTANDWEjAoQAebGjE3DRAqgAUgANu5iGzjMR0JQLhNB8mZANuEQFzrf7MjWPWPyAED5ohUTIgcMJJtEmSMOkIgkNoRZSHaWhp5lMGCSNOWanHRufe9lJwm05lnywVHMz8+miz+7BirfGL2YHpvvkBpuPLdGpMIBKamkbloog5JRDpdJlihTtgS9mwBy824HtXFTkTaIwYEYH0dQBc6uN63CAKnbKdJtLWJ6Lo5Hi2K1PPIPM0G9VMdOU+my9s7X07nzRVZ7xwQ+U6N3Hc+M/ruQTmNcbrcXnnaTXsHenYwWwhnROdmINQEnCYIk4pyjKy+NiGiIXAIuwd16CBnFBnbpoHZNv5FcLTvCjAM/DB1ENKZ5hIR/AC2BHGaHRxGIM41rf7T/XDZa3MJyjxEIM63gGubxHMJQo8ssGq6PGFC+G4Cg6OOJkI8LRcJMsEEb3PEug5qP9nGDhCRd+jBwvpjGyFgxIZCNx0yMyNSVP4dgPQ6WJvhevIoPU2DyjTm2XdnqXe16p1L6GrefZvcnz5cJJceOuPWAbjvkeXkNUsYqwvEWg4baQIOR4uhgxRoccCgxbgG070mWV9kEDF+L56NQ9rXsZ1JvS5FvMppvHRXtt/8sgf3Jw/K19fu/GUxMtfJffi/JPbm/S9kqXa5te0ifXpnkZBhh8aOFhTNL3EILKJxoiOcTneL1JmIHo+O7WC2AOzj4hZoB66MTId26mh8swm7yeCDlsMJteVG6Tf+fAvPOy4bKdrSkNBJcEGAucUiOQF61aDX2oHqiBjKwWsfJFgeSPIcCgoIm0t0lEH1ke5z5HRUMND3AtQOjzy4bSkArr5QSe5NVyuI1Uri61Y2kgVJ2JwyLSP6ukzbq3TocLHSQt/ZN5dj00Sin6aHA9lExz8ix5obzbrbFLHIvMl2dAXLxujvIkuPm0T0Demes+8qzT7IACmdUNM6F8hU+z1PHrGJ2/g7L1d1DspU+3PpdND5A91qzPbTl7nQWBehETEtXzyoaVERKYtQIzbOtRgYTxNYZEfrhJNiZkldgWHTlZFw6DRX9yndbTKc2ibBfRxbb5YILGq0dxMxDYpHEhzAoRWzrDD9iBsmv4idMfAhVC+QYhgTl0g5RMYhiiJgRJ5jnwNvP42sVRSlUqKn37I3OUWS+gPyZLAFGYFzysPykJGL79+fOgXpHGdO6ot4BoY3jhHb+N2AEBHGGiHk5lMi1IlgRWAez205dM/1N0+veZGPVX+uU7OZo6i2mJ0rF1De9kRsROLH4MhcltvkQTMny3nzdFX7YEonP3JY1yksYmsxAoCWp/PrwiFedi8qrNsog2UU/rc8ghMO7rkcPB+8q6qTvMA3Yo9Jyxvr3aVGRbCctGWZhrQcqfAWi0B8o1l3xF7Fy/IHQ9/IWnh5amXqL6t8LQ8gAOtdzFLvamHbxTL1rlavq8M7zrtZzae/mqbVOUW9ajU7Se7l5HJ1gpdG6mWizGbJe1zzhC227kWlwIrTXj8iiUr0qdzUVxmiAh1EOfaXT2ZnHSh9UivaM7I+ZkXiO41IfbtMyZ8lt6id+rU96et+L364mGr3zapxImef+1qetlsW/1xBFye4crcrItLJ1ThnHA4x5Gi7xpHOSvODV9/py4zQF3keb/4bVOjFQQMW4dSXl6e2aNw3/B3ZdS56pgAX8XspgChca9TRWir+jU4zmG2lZLnIA+AWcl/L7DNwXWux+H0rb5M2ni2qbYtGfVC7Cs+JyCi9me5Nz46FVSB89l3ZG9m2yZO55piErsqdj0XZdjZ18Ifaoz4k9chu7yLQp0XDmIbyior3GePfMm0BcnIWmfpmGu2iEflBY7qE24Ruwy2i/61FQG8Wi2NZsFfouYtuWwKfs1RsA6feFtDGlMylHqmxV3PeipC/uLtvp9V/YfzWPm/c+0L6nnN16NFQj+b65bCD63wtIniJ6CN576Ktd61FHFugulD7cOAupXvQs0wdaAFYi/cjsttM9WnRwUmuvi4C7cDsbpHpYCwS7V8UXvbeGhK6Tsg5CA8bHaGD3EKEbgoeGiRQgRcFCJoUoRa/i2yQXQQK8HnL7I/Z9kWa0NB6kTa0iHYVv4tsY1zEHRxS1iAwC4vsUJkT/YQ+b2l9IO8fLmDS5jwfzLaynXTt88lV8mUY6jAZbrn1m4rUMzBWB8+k6fd5ApCp8VlCCH/RBQhRYQxZskOMmnT8qDoXYYBoLbrsyNAvQpdIoKHaB2AHCpKLRtSC2E+qP+l6jIzMlWP3uW6fJvAhkcttarJ8bOrlbIvabS9kLwLK12Tk+rMI6MGiwx6WYNtoUWS7SJCM7iwW9DUCiQQNyBYjWO+XtPZRxIfpEKR3i25ypAKU1pJtRy0IZ1FdjFhtbxGY3XS0E8V3Q7ehvth1RJYz0lpC8EX7vMYlJqixLce9LVcdS5EFnNQ9oBK4rl/ECDACFdppmCXJDQT2yvV5fudTxxJ/LEHSNsHLRTiLxf3C+RYj9YrKd3752eRGCcw+pH7Lo2IYqVuk7llalGEDAN9y6Qy3EIBfuW4HAGNA76VLSw7ncMlhCw4nQJeLGls1xiMyfyn5n7WNjMB/MSJyRdqFz7Tvvrh2KNU1tYbjPDVvPjjfQJ83p/rUWmTKbhEnmdYSw6lGHL0WQVJOglpEsrHMIATKXLY8Ap/S+gzYSGsJJ1Y/zih3T6tMf5YEHz+Ja2vUgLVcSrroA/jlB8/7WVwyWhoPGLY8iaDqtVVKi+vEjG0MIx4Z5sAsU+8qvalO4soPAVF7gE+Rq43vken0WUnW3HKLjNTPvXd/OqdORlrjHoclu+8tD0eZ6yiV1qmlTbCF0nKMSH3glCGZT0gy3/FKevLg50wyd5SbH4+Sk77yrNS1PdlhRXItR/pGP6UvCx5BxJjliDk7LQ8yafkSzVKFcV3aHLm0XIGBr54vHed+EPVh/WqVeF5tcxQzGiuhVy+RvzKMDdSi4/rMMkTQKtOvpc0C/ezAGUXqClAveig7GvZdX9ubnHHDc8l2+XIOH1K/7VtRcp50Ci5Uq98lqavov2ykvrmOD3O64jjrxvHS0VIBwoJO5tlqdjVnfrU8QdCHzO/6fpy869pns0Vw8iwEFeEP3xGwIE4QWR0vB8u/vtYJpXfRCarr1canVYbQW4tvD+WtQvpvxXa/HQF/tO3oUErGapGcOnTm3BufT3b94Eh6mhy33PV4nFx43/50L7LaGqdIXUVemw/W0SYCbfS2IYey+pGS+WC7o9queK4k82vlVIsPmd8n329+5lefyw6PUYvgBo5fukVt/vj1u7WJ+lYlm9o6Ybkhekvo6fEutS2v85+DvFsnnLwiXvQ1ky+Sk69avVOe2nX988mFt+xJJn/0qhep3y9f5nL5gy/JhU4vZ8d3qrPfjQis9SboV+ttVPf4o8AIIXMxmJbZSE8HVAso1aExN8ttiz5kro51VW/5O1nqlDrQKD2YaNebkcWJtrBtq1S245YXoS84/vf5zqcu34771EW1xbeNC47PFyDjjfh1LZSU1wLSpwWPehZc7YrKydrVx5zUpwdRmCRjBbwnX/d8cunte5OpJ/1I/REZ2YcPvZycf3+24CmdI53NIj1UvguI7BeY4zKOcePKaxy2C+nqwhjrdbSz5bhXjZXaiqjG7pJH5HGu8vW76lW6d//wsBeZb//ZkeTCW/cmJ10n329+e7aiXelYPX/Jz4KHTZTFwsWS47IwRkJYKNe2FqUvZXESw+OFCjq36GnXZWW6UFKWCxVkBVxTc3bSJcwFx6AsII1YcHzHBc8FRltcoLyIXLtAKNqiR5uxzxYid3sXPPrKIV9qHLB2LDAUcsHTMBeZjoYWjV0qI2sVYSsAVkB8+R17k0lJ6tNPHmUXFdl/aFK+DObrL2VzpXIhVX0QkaWrmV1jwJGpa/xdeuQ7Ri7b87FDLti67MtlYxxdMz4P5rKMTbqSXR72olaitx5+OXngJ0e8yHyHPDjmotv3pEcMq62R50mn4BLtjX3BAhOvFhi2u8gYF45cOXa56EF+XPvm6DIXz13kXcYZXNCCCh+bg5xVzthVCaAWmePswy9GfTUnqHAUyocYFjwIdKEEoHCdjIUSfV1gOhwLFUrZ9vk6BlX6XLUvXJnlqXc9xSq3s6kIW+0Tzkh9X0rSPqSuytXLG6Ntbfm8+pwWrbvA2feaRU87qmo7rPqi8Y63q06OQwIR+Xw2/imZDxa/qZXoH5s/mDz8FE7cu8A0+5HkotsGZH7bvtQpGL5+Fxr/quPKqWeRAewux9lHb8qMw2IF3VjcBGyp+pxxPM+XMxc3CfsXdEI/Xh0eV30nUll8k+8/kfqzuLkOQg7qV0xtpNGUiqpSUpfArNLvu374qkzBH/Uqt34rTi6WgK5S+XoKPo3S5jcBtKrUsbgJ9rZ4nHSTbBPuAATDFPtg3Hdm0y7nSTL/yjf8Fr+poiL58295PjlJvXDlVo3MZd3DEwWrkNfbGetOiBIV9aUqXpWxkRN8bGtvWfIpE3FsNgkuvg37dAKVlNQH4H7xI9mLXM4ckLpaKPfID/xJfYd8qct7H8nSt2qLXJqCH0ZrbzNwXjzBx7uwIFKLymWKXe0LV2N0+faXkju+f9ibzNVq9nNuLJJ5mmYfrqPYIsy3Jub/E8h5cTMIfau8jQwgesvKOCf1y/NI/b6XU1I/WZL6ufKFGg/K1eyTPzrqXT7f2UjfyHWh2tomI8HL86htfgvsj+v45lH5zEY6Bmos1FYydfLbR+cOJjt+/qo3md8t95mfKc8wUMcIq6xOGplLB+GK/Kx/aJplq7y1sHTL+dgi9K3yVib1jTS6UqSuVjqnpC5Xv58h59XvkifElSH1u+V+9cb2bBX8xVa0vgX6mz+ufW2u/FA6BmpsL5JnCNwgTwn0JXJVbnpMJKfKE+BOlmR+Zkrm+vTKFplvlbcboZvRxzztPZMVzvM8cHZ9VZ41P8b65h2fzW9+1OJqT1Cmnje7zJeXXzCnR+rZ9qWzbs/2qZ8yOPu9DKmrufjPLh7KFszJyFDN26q3bdVn+qM0PEdv5j11bp4hk/mKOq7fN8/UjTJjNO/R5/kikafb0dKo/OV0DD40cyBdyEYS99Pw51+Sx7/+xxf/kupEujUt3a54UCPzMerwQnnsCzbLrspim/ZdUPX5zLYEDn0MqIxOWfuY9wsiNgXv5yvym9GuGnoRZPTzDkIhQCiYR+6bp4GNHKz5YruswZ1HFGXe3Ua9r8H86DtTBsE8Li8MPElZz2ttNA0K6A9WB2VUpsyDefu5TR+5EWBNtmuB0Id5gkzyMZkbLZi6NCf1O7MT5d5x9V+Sz8kU7YQk6TLl7m8fTtpqa5Ta3iZXVacHjqg0vNripkXswTwynobcAlPu825jxvQRM2ZIbws6NE+AJ0dHKbCeR8adwIrhGM5sZGMoZaxkrVLil8l94V+T56sXyPppgMj1on33yelXkn+/+s/JqfIEuLPueDHVjfRAIfmcOjVnPl8cM0s+jDGDHHALT1w2Ms/AEBMn5nmYECBjipEqqIcLcP0BpgMuPJh3yzlwyCdAnJDAgcvBvGOczbqJdgdMcg4WCHvh2NsC/PxaQBiiTmIF0kSUr3A9ICBTGQKCLM1n6Eag3wMZQgD9XbgmstqLXRtQCgTdC1wbYHKF2k2AYuCI6AJk7ChZB/O48wL1s4mMC1Rf4FJSoH+B6ZgtwAAY6NFdTuqDU8POlqR+mjyX+x0yOnvv119MdsrFchM/POpddslyzVpfpnxfSglBpYAv3XUo2+I0oy2cQ4AMlD2hq9Z3HNBH9AQaR1cJKGCddzuETWDsMV1K95SraZPpQXpdzmlfcP8r6Qr2Ty8fSh5Sc+VPH4ULFpU/ne0xb967L3Xo3iV1QOlCtothcDpgfpAQhBWA8xVADu8CghuQ/BcQ+1mA8RCzZ8ueIMKddwQamF0v0LoSmPi7gGAZFaCYzibBOcGCwTVIXwIK8yGHesHhmCDOUQBxG4B9KC4itljgyQVPJwhx9mvNeQfpzDOUDSMJjEgIQgMjbIJcAoaCBhSIEkJD2z1PGxz52/Aog3m30xI4HJaAMMImFrERfQuIzwIH6QfzdNQaMJ7XdDgQtkJnpF4fkHq2iGp/8u6b9yb/8eXnkvNv3JN8/fHDKUGXKQ99/9XkyvlD6aK5lBwezubXM2LvDyJ2WF8Calzn3fKw7qUcrwUY9ALENiiHFALwwAGsmLMfGESeOmADIlfz2coJU+P1wekDyb0/OgKTN/XZ4P87n4iTc772XPoK1HfLN/SpF60oXUidsKkRmZvYECzQuuzCsoCQc0BhKTEOAYF1znYtIPa04Ah6fDBmAQn6Sth1YJBbQDjIAUG+KF4SbXVhnYuHXLjYpPCQGjfEEQyoDE9O6C7huxSp6QL3effguP7mRJ8c8gmY9btk0WREQWXa7gX0DvBsMmTRZMjHpdimg+IykMDDeIJ5NwHln+tEoVK3594r36d+y750BfwpX/5Lcv3KRmlSV+X+7x5JPjJ1UBL7S+nZ8hfnxK7SuHnEPkfL38dp4gKHy/FsMtviQ0DcsQq0OXLl/FhELiPyttw2eOt3YzwidxG8LFevHEpOkhkZtYVRjbkae6UDw4WNs302HkDEEEBTVEwd5WAh5Rj7kA7HljjY0Cxhw15BlxnpzvMCooBJqpTuNz3wMWBwIRdjAyTYCjy41vW8WpNJrL7gwgWFwOEocIzCVXfTAyA53hbXobDqc3i1Tc/BbHo4ND6AwPVcA6YjFDDI2GdcKGckjdTV4qrJwSrp+7KjYk+5YU/y71/4S/Ih+YIWtV+9CrGr+XV1fOx79IhdzbFPbozIw4jagxK6zrETV4TFeWbg6VA02ff2h+OhnB4lI+UEXTiIyJvyXP3hPHnJolLs2+5/Mfm3L/w5W/yWb0uTY3+5eaYAU8+bTAwoC7oBI1qvigFcYuQ6z2V0OfC0f99sINupWigfVLmwuenpYDgdoYVq3FvzSTGV8Za8CM/TOLB0ZuChhM2KZMhxCLiK3fQ0oipg7ZtObJZQ0mCetzajLOFh1w9XTE9mK+AV6Z5z1/7ktBtlCv5Lzybv+erzye3fkETyg6OVyt0yjZ9F7Puz7VXpHPtgVbyejtfn2ktE4UFFfWiWiLqDsqCuMhSzAyKfzhwrtZdcEawaB0XkKiKvSuSqqC1papviO+WYvutre9P58vMH8+XquY3pbAGjr+4GnphVJhpuzntMX1XAgTIEwwnQmp4yrOoM+WZwAw/HydeJDir0lasXzZIYX2tWJInRalXe/ElVoipDVvb9/bEbhY8SeNc9V10ezYqybFZ0GnxTvVVlmJJ6vlhOO5zkjEEK/h0yovvUrlfSaL0qsatU/KfmDslXeMrFc+rEObXd7REtHT+I2vOUfLOELJpGCntoV7puzPk5WXp93KguGNpOv/jcuRGJZ9F49jY0JQuVJTl3MEd+Gze17ojKP/Tw/uTfP//ndCxPv3nfcJvhZflK9hlGlmSO+VkJMvKyjbnymRL3s/qVsKaK7Tbnymdjxx3wNMfoKJdxBpvz40/rQzpUywVfVH7Dq50rknZmwLoxA3/P2581gfoKxfq+PwQL6/s5hvLNua9FFVl7ZlMHS6KPtsw0UEHk1TSubxogCRrkHGw0hX5Dhj3n6LfZNkzumnxAfaCAcQ57Zr/gbDUxR2aoE5Su9Qskk83bHkwjaEW4Z8lXsL5Lbm17p5xzPU+eLnebOhc8JfZq5SF5jOwXl+Wzd7yczuGqiDSN2tVe9l1Fcg8GafkmNF5zpg7k4wHpQN+SbVMf7zkHCBTsS9O3OYfOGpF4SuITg2h8RxaNKxlcIuX96c6h5OtPHqlM5Krc8I1+cvq1z6Y7GE6V0yjq7IHhsb2DHQhDMs91WJef1uemiRHzlG1C39ky1uuzdRjOFjS1sR0C+pxjLOaKz27OAUGLZWd9q1/N+T6Mw3N2aVrYW9SbJgfTKWx28Ehzvm/jH4JjzTkKi/owfiN2V+SE/uhv4PsmpD9UGy396sPfkfY7+r9mkhc6iPMAeFsdM5WjbyvfXN9Qxj6iTH2b2Ocx4bochL7hIMAEWCSbPgACtmE0obqZDkexf33amDACncdlB7cdIsU+bLBGnU0T1Iy6moBO4G3AnDjEoCynU3dE+6CSN43I8fKJQQpezeHKFdAqslMR3r/JSO9D2/cnO544kkbs4yh3PhYnn5iRmQEZtau97BeqRXSS6NTzU+IZpOXTA2tmcoKHdNSl431Upk1o3AH7aprPxJ6VE/jMgMTllIZyVC6Vb8BTKXXVR9XX82S0/AG5xuCGb0XJI0+9OhYif+DHR+Rc+QvJv31ORuXyPPZ3q6hcTqOo+fg8xa7aNJIjQ/d0AJ5H9Iwkub7l5GLPbJo25LRJ/O/mPICjZLsAR91h6zaRMbAawegmWG8f5xGEMyycduEJ1lYg6GrOcR1ehJAhrpvvW04kiM/zsL3b/e3jY10gdFAILgUjKp/r03VBQtKE3SyQWN+ot0/UiXhlSOd5dfdJQw1cnua8j/L1jcHrJy6HCwcPB/gzPX9OH5ppu/uA4feNiKjPaFffIqDmnEsGDAdmdnSAyWXpASYHUvJREV4arX/pL8lp8ojQLy4cSh6R29TGVR6WUftX10XyfyW5XzAg9zRyV+T+8CB6H6Tm061ViuRnNxyAbWRQTDuaZ9iIZVtatmcum7LICVzJTW0JTAl8EIWrtl+URuIZiZ8rHaT/lFMYX1rvy5PdxkPiqiiH4LMLB5KTZUSuxkiNVRqVpwf+DKLyqQ3NKeobBNCnI9F5AFgNnWq6yJfEgsw2mpTTP9dHnK7R/U5bnYMcNQ6x9RH8MfTLwmqsvRBP9Im29QGi68MBBaCzoOzmsfuRYA9wdpskz0Fc16dJG+MWJAgpOIFou2151CADb875dgT7rM9XYqRT8HPtQW1ihDwvaCfA8rj6iAH3ne12K3of7Bc7knZmPqi/OSDUZ3zfBwwVSF059cFOLUGeaNPlOLHGaVRG0bokpocPplGlitbV3Pop8ix4tRL+opv3JLf0xFiJPSV3mQG4SS7G++TsoeTyNCW9P50CUG3QCV6R1JDkpwdp+pmMtBoDkqVsq0mMaUpssyMnZ0Ta2ULCNGswcC5UGy4bEnjmBKntevmcuMo+fHDqQPoq0wd/Mj4S19Pr53w1y6CosVHb0dRYqQyLak++ir0+28cJ0Bmh93ECc0a/mF67xofIWGJ/zwv0WU2H/jc5+AURyzxFWBDh9YkotM/HFywjAOq2K3js08GpK9vFHR/EuWoyMLxJZY+cDn1RZjVaEMKTGPqEkHnE0iRSLnwh+zgSfUdfBJPM+w4FoxW66QBi29npE5E9VxH7ljPUJEGpjygT17g4DqELfPoVx0kMo04VcapV6SoVrl7aoVZJqwNJ1Cs2//Vzf0qad+1L7pbvTH84jbTHX+77zuHkC/Itbyp6V0edqoVd56uFdZLs1QKvi+U+6vR0ukdyoh/MxSuyn9wYRvV1vUznpT8o2meD66+YHt2rSDElblmvWlCmjtBVz1QyUQvaVDZBOR1p26QD8l4ZhX9W7udX+8bHlU43y23fjpLL5DvuVXr9pK88l+5OUGOjxiiNyndm/a/P5M6Nj427IivKVvseWT1uRM4kIYsg/IjF3S8u5vcZfeThQhN1kMpxh/tan/HgOGnA//McWfYZelkuMKsV0xx9h8KXUQguyPdLRpx9wvv1UXiXkI2FNs5rXc4ILM+ms6/8bEGTLQcfcu2X+Bvve5PVHl8ngJdFaczkW6uys+AViZ53b5aGV0fHqlPm/vV//pz8pzw+9t7HN4/Y8/LA944k13VFcqVcMf/BiQPpW8ZURKrapEj1Ark1Ts0Zq3YqYlMHp1yiyPehLIJWc8mK/NXvvFyq/5YZALUPPL1nx6CO7dnctzp2VT1DLWRT6fPzBvvE1StLr+71k9uf2DwCz8sd342S4J59UuZ/krJ/Nkuvy33lqk2qjcO58sGpb41ZwYiKXcTSdxABp14fZxTKCvQ98a7P7LOPE8HDJzy17GofR14+ToIYQ5/7nsEe13ksGwxyOIMOYGv8SrleUd/DQ+6X8JZ4EaSPgfGJSBDTET7z/FzngZsVKUuo3AwCp78cRcYAjGpbfxNAdvRZnm4ebrV6+OBwv/SZt8r59Rv2pPuc/21A7JsZsUNlu0zTqwV2X17tp0T/CZmu/y+54KwpV9JfcG9G+Kqt6vQ6lcJX5JcuTPv6y4MyIGlV7smuVfeovy+Rbx9TpK0WsH1Crh34vHxD3Vfla0rv+eFhSd5HN5W89XKrjMiDuzMiT/eUyxeqKNnnB/dc/PDBwlx5Y7bv0BeOXvpE6Vzi7HuAvsfCYQIbmk4i7ns49bTseNmBPpPwOJnVvmM6mDvlwX1eGSz3dTrKyJ+fBa8NF5Iob1cvc9rK21lz3k2M7hmugBWj/2dFYbVpoa7hs8zn9o3vjPrM9uifAwugwL+11bpwnYQAZ6GFVvp9AmlT35AbMCiFfhr1zxmLfQp/O4xo1gFa5ljPOsDG1IFZYEwgpbbGgyDZWWH3V5fdbB9+liUjwDCgsZrV5tYVsU9mxJ4ehHJ/thr+DEku6q1dimxUxB7IVPxNco79oSdefdPLjicy0ld74e+VKXx12M2djx1OnYAbJTmrA1xukoSpUuR3fP9w8vUfHU62Q4vWnjL+fgr4DPr7aeBaqF6gvuvWZWbktj3Jv1z1p3TB26nypLcz8nny/GU4eXp9uN0PsK/ZPmyPswwgnzX0e7ZfxLI5QNctPRO2vhbq69vYqeuyef0ccP2sYTNg3X1+VG8+GyJsC+v78LMxezfv120YIt1ZpJ9zpu2XIUYA+6HxnzN0wMTHWeS5swiZF/QJ4dQCpgpb/0x+njP5dXRtzSJTSNlmzf9NoO3bpGSC+Kw50EiZQwwCapsloD5A9n27HpMcCjKABAwQf2GQAGUziXcWUniByFcA7RKA8RrOxixAgJaC9mES5zzPNESz3ZBDNgsYOCTbWYH87ttyBvVA4LpkAoVlYKM6skVz/WEaPt1TrYj9rlHErtLBitjPv/H55POzB5MdMlV+IpC7WUBS5panCYI2r3uKIHfj2u0/OZJ8eu5ActZ1zw5T68pZyok8PXFvx2D1v37iHhRwzCHjjOKWsJ3EWYHYWx+2U9T+kOdiOGM6+bMCsQ3h6Afg1Fu2A/VRIG2HyAiSq7DJHg3OEMKaFTRRQn2GsHkOwua+7ZhguGvWOQcEmxD2YRg4J3DuMHEH5BPC0ZlFgtbBs2o0oVDGgoGngAkUdQT6yAALwkAFQiZcJ4QCAOF4NkIymHNA9o8hq7k+HBWD3zOIkeVUUYooHPdTMqSup9ohaOfB6RghkQkxjsP59YlssZgidkU2aSr+NjXHni2e+3d54tzJ8lWdH7x/f3LnN6MTk9CrlKdLfA98dtO3RPLe+15I3vH5P6Wr1pXs1OtNz7w1209+QU7kap58Qi3gO5St7J9FIkozazPXh8kZi7KcOsn9XzCc0z5B1j5EKZBo3xHBo20QhEPBsNE5zGkhcHzOU+ZzgsaMOcIZcxI4he0C4UJB68CcAwfnXIEb4cRhzof2ec1Juk5yZUTwsx4DzgF6luftaj/x/Rzlzfc92i7cMpvrM2UjiIjEI9pnydMH8JjjSWYkuM8r81yGM4hcN9zOle7BPqRF7PJNbndni+feLVdgqy1V6tS5f5Wp4/PlyXOf2vlycp98gcuOQUr8zSpjIfQK5W65kO5ju15KzpQnu/3LVX9O3ikdn1OufV7KbJ9c7PZi9tY6NUc+JPJswdtw9bqTWAQTL3x1HYty+xXqd0TcXjZBTH+RdQsPB8XH/hlynXPhpMup4GQu+oQTJ8rV4cU3PpzJCZaFB/eCEboooaBlvVzfe4WHx+xLYGJM7faJWsdhRP0KROxLoL6KJzzGRniSN6dfAve0vZw+WWZ0Yt9It01dkp+MJhebnSO3VJ1xS3ZAzUnXZHvZ/+WqPyaX3bonPS/+628Sue/8+fGPzu+UK9U/PiEzGTc8l/zLZ/+YZjDU1jMlG5VWV7I6L1+1/lC2BS2NyKe1BW+V9dGlf74EzMU7ipSEO7qjiG5uXJgkxoDrogKuiDFkSHw5oyonlAlcfUjZF9/xa2vlwZ7jyfhcwwTosUSULgMrQ4ii5OCKCiTsmwrktNNXsYWHrEVJR6hfIaqp6pCKQhq+oR17qhbPqW1iautXdtjKS8nZt7+YHimrzhlXRKYI7V8++6fkPPmGtw89uD9dTLddzrm/JQidUXbIBXbXdDeSD8i+nf4V6ch85k/pS1NOUnPj1+9JTr9JRuNSJun8uNpHrl5ck69aH0TkjeHxt1VwQlQE/34FXKqiZ+NyzEXFZ4sKtrEZffTJ+JbNcowj+OmPgc+4DqH7ObXxCrc/5shRbGL0LMYEDlWckqppcB/C9HVafOYJRUlHqsz0SL+kgyGScila+NkZsfe141BHUfv5X89WxysiU4SmFtKpOeN3yJSzWkz3DrkYrHHHvuSj219Kbpb7zh+UK9R3fO/VsZfNIPQH5Znq1/Y2kg/Lt51dIBcF/puMwtVUwzuufjZ1YJQjc7o8nEftH1dz42rrXB6Np2n1Xdqqdf0c+8oO2LizWpuVMRNjwlNR0VHh2EnV7AYnuBGJ3/TquLKK/TFE5P0xZjnG4RTICD01qBkxTC0GM3a6cfjZjFHR8ChKRAGM+xrD+sToHv3Z2lGUhe/ytOes7skX24XdU+jPsB3C+kzvG1jXrCi2rdBO/bcY9tF6htlW9Sx1nXZtw0z1an0t9H0WeKb2f0PrP9jOGTi1PGoXoDzoPYLQFbvfjaGcHUo94/h7xtUOgY6dpUOm/s7A+tPQ9TiP2qc3Cun4fK49e1lJRu4qcj9DRu7qwBo1565Wd6voXa30VlHthZIc3y/3uf+3TNHfJo+HVSS/XZJylWIS+iODAhE19Pn9covb9XJr2ScnX0macp/4mdfIufDPZASu2q76oPpymkqny76dLdcUpJG4IvEHXhkucrssJ/H0rPoiiTcgvTH0vGHa1Iwo2LGdqmdm+GbsZzdmMbwrPr9h4QOAITOG7WK2aGHKABM0224U5CJArCjamSja2AyOhyi5YGMyY7SRcMoaBXkVx9zGWWG3D8JvELMJQkZxpPi8BvpsYd8z07d1YMbBfRBnWLgvQExrIDozbMNMPoduNK6hDXxjBjG2ggMwGtjGjGZ4eh2zRp1DQxTFQZopCqIBkBV0HTz4eScFrBhaewr91I0PcnYMpyC/v6Gdid3QQAiq3zLUWQHLHPgMAsCGblja/43CdUKTM3Kd0Rf9eboz1ZixvwtmHA6EISu97Y2B3lkR2wzsfDQGjk5jBnAWTWPCxhmIuHX5FICo4BwJY3xE4V5FWOmxqhN5Sv5gGp1eNDwDXc25708j2JTgJRmeKklRRbdqYZ1KV6sU/f/36T8mp8l971fcti95nyT6Dz/4UvIFebDMLeuRPLXucPIAg/CpCP2Rn8ujZ+UBMrc+LtKU+WfmXkk+8vBL6R77c+X56Sd9PmuDaotalf7OL2YRuE7gqg+qL6pPqm/5G+XUGfnp8awTo+NoIR1umJhC2guu/+aYNmYMEpkBxrigf/pzheVwNCzCFJbT3cjtydQp3Z4gJ8bCFwH038ZVC1tnizjQwHDb/HvWtt+CrWptGhUBBn02dwiDzEWRCAs2L2zHZ8blzAsUJ01HxOoj5JSYcjNkCjn8DYDjnHo6YztDuVwbs32QgxuQbIb1jBzImlnBSKHyyoWt7LqnahGg/TuYMRXEVkqKWM37i20WNinO2opl9wEGE6g+ndAaiOKbfQkMg8DkgpWGOdAzIyeoYZKvfr3ZzlnKwPs4QBj9toB4VqBjbsscuGbWHFNhKWpjpm87irOI8zUrLEcM0pnGLETwAgek2T7qIKBe/YDYVRm+pWxI7jJ6l/PIKoJVkWxK8Hdl6Xm1z12dJX/aV/em88/qNaEnyeNn33n1s+lCO3W2uYqO/89nMrL9P5/+U3LK1X9OzrnuueSim/Ykl9+6Nwnu2Js079yXFpUSV+X8rz2XnC2vOUNG2KdKp0Gl/P+PvD+tQ9al6lR1q6hbEbc68vZkubhPtUG1RbXpzFuyufBz7noxPWVOtT1dob7dSKcXSHxDk6MoEAIEVLquNmZhAmpAWALYXEPHqhkExwCH2HJgDUJtgAQGOyMNR9DQQBxzDD8DAuxNjLMIDXUYNEffclYZAcYMJHv6e5MIG4iDUtCHgrMCBJ6zAsF23f7h/rn4Cgx4APwpBmn9YvbIrG8Wk5UoBA+NGbzd0P81KorBFVGQ/2PXW/XPClAZIGFiBtEwI6QZOJJsOB0MAZIwJZeGDlKzUD8E2ReMBAOI8CiPzSIkQT7fSgMiz2sY5Eq1F6ovgPqFODoUMFCG5nYEBd9ZnO079BjTQSPqAzz4xtSI3BXpXT5Izafnq+/Iz1N/eUjyav757DteTLfGnSlX0KuFdqffmEX0ak5eka2Klk+RpH+yjJxV9KwWoqk0ePr7S9nf+f/KMThJvh5WzeWfIsla3atOZlN1qT31avudeoZaia62lJ19RzYHrtqSvvJV7RNXb4XbfiB1StJUutyfr/qSpdOzqYcGGa3xHH60zOJOuQunAocNBohz12Bl8QgMnXXbsG0vSJnlkSdORoIXMDkw2Ha2TIwVls1TZBggHGFiHBwgCRBjAgY2UCRNjRXFIVyHZnS9QDBY0E6FxTNZqVGkRVUQcKIwBkg3GJ5cQCgY7GDgHrvLMBvkMwXL66QGggYXQRoTtwRMTxkbz8DhjHAdjcDhhJiRlAtgXGNGy1s42iws8vEdw8aM2yEYFj16VwS/a2P4trM0ii+8OCUj+vPS89gl2d+dEf57ZLr7nDteTIlfzV8rIh6VF4zyYjqPn14rt46pVHlax+DlL+kLYFTUff9g/lulzw3yHkbg+Xz4VH84J+4jl0ZFXXc62ijo8ZxlF1jT7RVg+pwTyeL4KYCMA9/+G0T7XbKCM3miYDdUUNdgyjNg8o/LEXDxT8Bog5tDBAPLKedRMJ4F982F87XGjCCBHovaGh6kQUWUDSZZN5jOgktJOdEdmMJi1FGOgKHoV/C9ZbKfgpwzxwmNZxD+EYKdCg1KOH2uMQychsx3UhpIpO/rWJGfD9PzWRlG8RNZqj5faKfmphXBXjJ4valKd6ttYIp8L3zwQErEeblA+3tYHnxlEGVnZK3qUHWlpP2wIu7sVLzsfewbWvSdR+A++igAPRYs8HPblXBmf6C5cZd+2OQnnFF/UBqThEOWAnG8BQvL+O0Rno6R2TbhH+EjDk9QMkhpOGTGTqU7sgJcnMZ0FtdNPsbDXDqqr9bwBM4GEfEEY4ooGwxg9vXued4Y5u0JL1k0PDMVPopbpg6urIMSIMRPSwnPqF84ANqHNIVX1idweOZ8R02Ac7ouZ3JE9BuFufg8olcRckb6h1LCz0pG/iqVf9mwHBz83hhed8WuLBtw+YCs85KTdn06dzA2QEcvcMi3USLb1iih41z7D3ydqxIBQcPTJhtsh7xcwBAwsWszStkpM99xCcY4ZjifCe+AwY1ZopROubOEg5R75nWLUaSgP2Rg3D6eU2PaKGa95ndYvdPAc/T2TDMG1XzOtF1H9rlwOyXTdh3FPgjr80IKl2rv8D4j2gDkFADtD0x5TeNRYOGaafj6oqzF6LePnGdsOUB9Cwb9LhjQtLG4bKY4TqB+obISo3YYfS72QVj6b5HtNMPwpmE9DhC9bhD/B5AdTo/6kZNvPSfgYekP0+HZVjEtPT5tyB4ZM8sGILsxx3iasJkZW97oPdNuoA50XYBkqY3lqJ/COY7UWFPTJ6g8pvG+BdOEbZqymrbxOKDabWGc/jkvQgxMW5xxjPs0Ph7BdBG/SB0BZBZM0/VbmDON4DaKH6LQVpbDoOELJJ8RLgtU/2g8EOB4WFyq3VezCAojLkAwoNKaxDYNKxWoaNbgCeQ+5Bm6cM26Znh9DFzfz9jtbaDKKuz+md9NA4btOxbTDIVFPg84dTKeUyBPq0+C1gGMlAHnSNeJYNpRD9LOnAxG+iZsHcLuH+q9sEA00PuJOSAOWToBj1MPZCuIYxrMmH0WjjGmwR905rg6NkN/H8wgjsi0AJ0PklymAcd5mqFDumM4jfcbDGCm7SACdGAQG9F1rzBOLrvW9CCYLjqFcIBTAm/IYMfAR1PPWLJn8goaLGG6T1w/AzgJLj6bAWyKwmRQfsKNzzMwdtTAwUc+8wJ5EnyEu35PwuK01wtcEIPweuZMCRka3uLo2YK+vgQJ05+LMdfHdKTK1DHjJ+uAKy/guQFj7J32NMN0JGf49fvrvuCBslOWMGgF04zsVll8mfGUzUwJ7JrhOfjeWAgShPCwa0HqSDDj7lPDU3fB57r0mIqsZ8rqskCzDqUwxUms/hgXeNq9q/7AU+dqlY0MjKzHZLgnSpnhA2pQRnYzmyeTAAFg15j5kt64xj5AIv6q/ebJT1SSfVDW0RpXHz3HI6DGe6akIzoGfQh8bWPM+hhUdZzHasPCMW7V2hNMlyCmcY/FTAW7nRlf/4Mx8U9QRg4zHs44cW/thCLOsgKsNADiBHMwxHgislLXiU0jGPp6MXaZjWv8glLPFeMl7JkT0OY2kdCPp1PEb69I3g5YuRlO+JtfxNj6GxzX8RZj17HaW3GQghNAOQOvZ4o3RYFPPMAQm9AvccLLIDjBgDQ4DnIM3iZkGLzNSO3EkYV4GzsYbx5G1TZ3QMWWh/hPW8RxAY5ga3zfUsQVvG31XLxl5RJs2cLbxvZqQb6dRf8NbHEhP5sirpty1AE9c4q4ZorZrqptmvZ4HnX/NPPZrr+xtkB9nSLGxzUOhTqE9r9wXOv4f4oprylGnS6ZkjosrHsCrE8umU8Rz/dp25SHDk159J2y7amKtuozPlxdny5hb1Ma0UwxdNtlY5w+TRG2hdqdGNnQFLMdBV0T/HZT+jrliVc+NueUAQNfpx36PMVvW+DSl2kGbvna8ZTH/xipTyE6wBinGmnwlEL4fD7FNIgpD1D3JRJuO7n3TTOum/YA1inH4E0xSGWKQRqce8HrhXucphx95RDitMf4THno4TRT5tr/wbTDOZryIM0y9sExbBfoufrqsn/umJRpo09fuOA+xZTBtKctltE17thzSX26Qh98v58uqVvTTPuc9nQuuc4w1+Eua69cZ5EMNAXf5qbhIARra81L+GUMc2pMID0upR1HfdMVQW3K0xCr9nW6omMz5rEIpkuCiu5cTB0nPZgu6eROV3Qeq147XbHP02PUu7HonBjveLvqLONocCLVsgRaRler2rWvTk5vUlumKzpZb4ZtHQ+uA0ptsx/wlizTnuTxTyeTt3h7po9Dv6a39OEtKSOSiMRxeEZF+Uxv5vVbWOgnKzE+vGI6GrUtwb+ZA/4mgvD027BPW2XLYTie7dvSvS19OcFK7W1LXltly/HZKltlq2yVLULfKlvkuFW2ylbZKlvlrUXok/KPSe1D6G/zGrNMAtcO/q9PwtfWp5C6J5FrzLom7WeBbUS+q2v11wff1139ZMqkDvSpjvytf5aXwnVUnyeJcaDkhvQJkm+9jGJNInqhy5sao0minZR+ThbHs4HJL5f1JEM25piaeoT1c5LWZVRmLj3W9YOS86Qha0pfOHYz6bD1SaJO4/v6pBs76pRspxBdgnSNehaCC+iYTOL2jdoUY2zrLjvRdVbTXajOugtbpxwyIvSuPkXbHoYV9SmHnWKYNenQVQivJo16Jxl2N+lhH1RfAV2uI+2oO/QQtAvKjkFCNxpQnwTAbBK5jugMdG3d0bm6Njj1KTdA1BHCNuuocwbPbDsG6pO2cdUhpaTAQCMWXd515FpLxib5G22Hxo5LTLrM6lPucbZkYraPUwfi8NUJ/UMdQgTcTLnWgX7Uzfun6OeQDgQ1DpC+G3plja3pkGD24Bp/qL+EjVsO5ySBDYYO1BG9YOnRFEy6Tt0mZFA3+kzpBISJKEYiwQFVT90gbMqJh2TamGQQAYOEQYyctHWtTmEJhCFTtlzqlGNIkT6mH5P4tXXCAcY4qg5x1SQxlianTeHYX8cwyhUcTMHBsl5HDSWcSUThEZChgIAyWkyYlPNQn6SdBpdzYfXLGHTMOEnHBvAS6xhRIf2pg/8LtP0YedcZBeprnWgXKEfCGOuTCAA7wIFDROZYkfWZ/QLaUffQHwpQTLnUPXWY6nd9Ch/rBsdmEacdG7v6JE5sdcyZ5jheDp2j+lE3HB+wLiB6pWyswbArq36m81zHspWIPOsuJ4n4DsQ0pk5R+mcFGVO4LTqdqykehtRdwZVD99EsGebkOzC/PuWQOeIEusaSGmNrHKfosc/bXXORglNxEJDGOlX3GDxOPWQ7p3ADdbUVMhAusXBItuEgVh9C5fSxwXCE6lgUgPVtyg06FAn5OiE+488FxLqRRXC1tzHJdyYofXHVV3eQbd1BRnWGo9xw2L3v2DVKyImy0zqjL5Sd1hFH2kWkXBDmyK3BwB00akciwDqTFBpMe6MczTrH2XEGJYR+TNHYzbF5F65CducKXpx4PgU7ppTDCDpzUzwnmqtjNQ6BskmPATj1ip9xo3lfovAlZY5C15mGzHFguATo62A0PNtb97yX2/dGyX6XdUhdkTMH3MpkTXyf6fN8CBiqOkhV9KjOxIM6M9Pg6ziwnLmS8q1P8qYzuHbDIVcurjU88Ni3fq6j54ORDYbdNyrgOdep8tFbrowanm2rwqtjI/RGiet9wKCMcTRKGEDdM3qql/iuTNQxDjDlkK6vovtmOxpjckjK9rNegtirOoc+9TUqOpcu0ilb5zj77TPGvpFwmfp95elDLFUc0kZJ0mowHaNG2Wi3pM6UtaXN0kPfQHUz2lFWlyidrNUrNtQnym6MCcCdnv5E9bZuRiH7OjHeZ1SRX72iE8PpT2MTDLoxpvbXK0YC45Z92Ui5sQl63agA6FWi+SoBQBXHrFHFpktkG98MG6gaFdYrOGKbgc+N4+Ao+OBug6GbjbLB00Tx++GiOBSAJ4oEmf49gVSofzeBdHBCK5NwXQ3jOtKYKeLQ267XNQFfawrH6pvjuQ2s/glbjgU5mDIzPm/o/dEHf8Jud6FtmKwnECKacMsU6l9jwmjjBCIfox/kOACyaCB1NiaQ507gym/Jl9F3FNgmYH1vQG0gdNWSMaX7E4T8TACYMPQF0xFI1hMO2UwgYIPp9wQhM0xWE7DOucbVsj9Ivyj9MGQIYssEYYcc/Juk29qArnfU0ZhEZD7JwNoJHMupukAbmuDrfB3rJzZmhn1gmNmYdNuJi49QO3FhpdbGxoSbZ0n7mXAQ/EQeoRdu2DB+MwSPKTbY4Q0e0SB1mQOZCWnDKQi0fch1UF2NCVrpGhMbJIg1DHmZANvgACAGZoZM6g6jbIDguOEEeYukJgDHawJuF1mv5UxtgATdmEBALpcp9Kz07w1apgiINCYwndzAdW3SMaaWbDZonaUcYQZhjohhA28rp16KhDkOAYEbDUqHrP5vaL83aEcB0VMvjHA5yC7CnUACIa5NUHph2j5hm5DdNLhymPS/ruEiwQkHkU/wHdBGifFE8YsIyMixn7BJ3OkUEDjT0LGQ0Y68P7UGm1g3QCBrTDC8VcMYGxNA5OVBvPUJP2UZDZ7WfpM0hm3bAPptODxWezfs6yf9DAQloQmGpzixwZTRhhtEnIq4wTCeDb/xcbW5cB3D8SiMGf55w0t2DvlzSb8kkNt1biDy3oD1xwIRx3WF8d1gAuYGDb6TG6TD0nA8E23vpJsEG2a9kxvlbYhy4hGH08eZaHjpdJ8/Ni75QnY2wRibSdffGwRuuPrlwpINw3nc4Nv1JO4Ich0K17MaJfDE4itIjpOwY1Arery0EjcKlWEGscEzCPJvXAlwZ6MEOHrf69vecmSBK8mGU4aNUrJwRFQsWWxUGIuyTspGCSdwAzGMDUP2mO4ROjDZZ9sSu32gnDf4ztpkObmydX+SSzT0/Q2nzDZYpNkoa8+TSAaA41xO9Nm237Dux3WRTQCV9M10llx2jNucfzs2vLIQkO01JjydbCf+uhyCDZYONRxY3YD6MUngyqShm4jzU3vfbD95/5xIPiDLf82L5IMLIvmQLB9eFMlHZPm/S1FWOlHyca18aiVK/ns1K5/pRslV3Ti5qhcln1+Pky/sLpYvfSNOvvzo4eQrsnzZKOqza74Jf/flR+O0fEWWL8o6Pl+oN0r+Z33wXPn8T6/FaVuulOUTy3k7RfIx+ftjnbwfsk9LWb8+tJj1VfX5A7IoGbxvrp/8p5THe1WZ6f//7Z35dxzHdah58ov/wuQXiJJsyVG8yX7O87EdOydxXhIncWx5ibfYTiIMKYmklkiyJVsSZa00SYmgRC3UQmHAASlREtUNkiCAaQCcV7eraqa6prq7ejBYBvi+oxIIYKa36e7v3ltVjd5t0tRf8fmMareqdss9pqmDeXOhpJdE3pxDUk42EGgkNTe/JPLCTqJuotUXUV0WFxGhjxxclS03qQ8Oy0q5DY/d6IFF0yC4SZaQ1Nx4k/gb18G05jyODXyrb8L7K8VXdm42PX5Jo0B9f+1xrAqsk5ED/v0Nj2t8oJhU/Kzu+mwiuqprsC5oHWV/K+6tB0MiTaIDyPrXxL9+/4YTmfL37vvvE9d7B15e6h08tdS7b2apd/j0Uu/+V5d6D7663Pvf15Z7j76+3Pvdm8u9x88u9/7w1krvibd1e1K1p8zXo/Lvd3Q7qtrTph2137/b7f0xbyvOV/tv/+dd7zW6yTKOOss/6jW7LU++PdjGJ9T2/v7sSr7tj6l9ePSN5d7Dap8ePLOc76Ps671qn2X/p1+63vufk9d7/3X8eu9Xf7re+8WLi72fqfbT5xd7P3x2sff9P17r/dvRa71/fvJaP8CQwOLbj+lA5uuP6mBCAh0JJiSAkKBIAgYJmj57aEEFCQs6UDBBwqdVcHCrEyDcfHBYgqOfgEmDiy0mOxn1JEwiqjIxN4qkQrZJ5PEJr29/dMCTVIi/qeya3LSSiBtyfCVn/9D3oyyv6rikkedq0vzGHBWEJhHHron00ojzd9TgvD5Q2V/7uSYjJhNpg8+iaSU1GSnYa35upA0+n7JEIxnhPprUHItkgwH9aIHTvhdmu70/zel2fC7L24nztnVNc//t/8z9mtX8zl9mFlh+VvH60LZkEb/PwuvL97ebN9n/Y23dXpSmjssLpj3/nm7PqfbsuRXVur1nzg2CDwkwJJCQgEcCh9/awEEFRRI03KOCpZYKGCR4+rUKFn557Hrvpy8s9n5kAoV/VYHCP6kqxd/9XgcIEhz8taoyfMkEBHn1QAUEOigIBAOVGWbNhd2qu6EkETf6qpvbRqPtNLCN/rY729cqF83+SjGn1fveig1KkoZBwCiZZuDzaPnHquIm0Up7zbuH6rKopKEYU+fzKuvjTeqFYfe31SSTdH7fig1u4z7bcEAe1z21v1Eg2CRQjz1XYypVNddCq+rYRYjLPzdb/nmSjnB/qvqa1ATMdddtssHq2ziqTI7QRWDl8hu0k5WSzireHxJ4NyJoqJJ93fdZxLZ0K4KLJsHG8PJP9o+XEzC0nYDBCxQkSHhGBQlPv6urDXlwcNYEB6/rSsmR07qS8F8ndPXgJ88t9v5dBQPfVRUDqRb8ze+u5hUCCQS+/NBCPxiQ6sBtThBQ7DJIvJu8cxEVBOFdxK3AzbBVcwL7F2arKOb99mct96IO3Xy9C6YV2l5/f5KSZdr1Jd7rvO0dWqa3362Sm519bysJL6NVsm2t4r6Wlm9boc8iFBAFJNcqOwZlN+l0eN2FY5AEzo2SwMs9LsFzpSLgbKXlN/dW2XmXDm9jK7Rd3npbSck6S873wrmYeOsJSGFo35KSayR0jnq/q7o2hpblf44V16h7XhSOT+BYlJ7PSeDzTYbPweA5mw5fm6FzMHSvaIXuKd7yvOt9f6vk83BfP3T+BK7D4OeVFK/TVtnP0vL7zQFvm1vF66lC6DFyayrqkFxjRJxtIIvPItZRta/ZBrezWxsAxLzHBgZ+QJBXC5xKgXQ9PP6mrhAceWUQBPzcVAT+/WndbSDjGr5lggAZH/H5ftdAmncN5OMGjPz3u+IaEqh30rbKWuAm7ovEv2G0AtJuld1sk/Dy/HUHt9e7MA6E9sVfh/9vf1+r1p+Gl32gZFmhm3NQHAF5+8ep5QciMcfXe8/QDTIpCXbSmmPjnz/p8HaGqg9l59XQZxqQ3dA+VNyES5dddfxKJBL8rMIBXPF6SIZ/FjyGafm5Hgp0K8/XZDhwCAWmrYrPwtmvWw7oZEK6GqXCeIe6x8iYLRmrJeOcZOzTt9Q4qL9TXZj/qMZO/ctT13rfV/cp6eqUxEW6PSWJka5Q6RK9W3WNTr+0lLcDL+kKqG0HnX+3Xl4yr9Pv+Y1673+q6ujPX7yeL/PHavk/eGYx70r9pyd1N6rcE2V7pMtU7ol/pbbVJkWyD5IIld6DWiWBfFVQOvSZJSWfZ1pyTyyu3wg9RpbdGhlWleerMvBuZBm+27AE363pJsgarq9qf7IG76+qDsQEQFXHt7h/bleCBAHPzw66DWRcQi7/s3qchIwrkABALoT/kSrAMT12QC4uudDkJL9TDSi0J/lnnbEAtuy/v1UiyNqbR1p9o68LEErF6mehZTegtOIiqhJ0Wh0w+JF3cNvrgqCADIYqCBHBS9P1Dcmz6jMqOZbBCkhJgNSqurmVfVaBACBSMsNBUuznWxe4lQk+KT9Hy/b7QN01UhMsHYhcT/Q1NbxfUlmT6z8X9n1yX1joy/qrKlH4thKkDHqWROI/lJxFqHcrwd6r7jNyv3nojL7/PPaGHqMl96Sn39FjqKRq+Wy/reT3LlvVfN4mNU7XqN+ed5vTbfqc6TbVyZC+Fx7td5mu9O+H0l16UBIiFQj87AXpHl3Mx0/JIHARvlsBtbLfXyvo0HWVRNx3ygLr4vdeht6NFHQWIauNSngjgUG3wXuzEfar6RiDbIz7UFftiO2+CHzvBwB9+Q/GCfxOXXgPqLEBEhlLxCwX6feO6oGCf6tmHXzD6f+/43A66PM/6Gf7DcUYm/m3akpklYFErPCqtiON3J9RJN/kmIQygg0KorTaUJHZ1x6TtKHMYwOXmOynQWBYu21JeWZWKf8m52tMYJtG/L6JRERUST/DlkD+C0pkco1/87c6q5UMVzLp36j7gWTIIunHz+pBydKFKPcPkafIVEQr9xa5x9ixW39SY5kG//Z/llW00HuzkuWFfu+/1ntfe/heKIOznzIDrkX8953S98G7ntEztb6ljslfq6rD5w7r45WL/sAoAWIaEXQNv2ffi+1uZF/2uCQaO5itqchis+IsYtmx/fx1gUC3gcyzhserSaASs+1ZRCDmiF9OdhMJ24j3GZP1S9+/9PsfOi1lL13q+pkqcd2lylvfNRm/iF9mBMiN4asP6dLbVx5cyKcW3vmA/irfy5RDeY1uC72vqfd8/RE7ZXLBNPnZQu+bj17JpzDKV2mD1w23/rpV+8qDVwrrvtNM2fyimcL5eTOt868OmW4JdVO7/d7BBXuruuHJRXuz6YPbX3ujTRuIO20g+DQyi2wSKKQRJcGY7oU0IqtPIoKc2Jthk/2s259RgsKm3S5Jg32tWc+BdIRgIOln2tLlJgNxv3S/XFNX1YDdq70fKWH9SmXXrZd0Zi2BfZ5N55n0Sl/WRVF3awSc1ci27DWx8i5bX917qgKBYpP9lf22VU/J9GXck8wYkwBHujlF9HKvkXuIJDi3HowNwtLIe8Hgd0boo0i9blBad4OCG0fmGxuAbHbW36SK0d3A8Rkl05dBfLZl/faStI60bu9l9fVl9fWUtPmsNyPtQtY7bdorqr16Ubcz72e91z7Ieq9Lk3+bJj8/c1G/Vt4vy5R1ysUg2b9ML3xEBQH3v6KnTx40MwOk70u6AP77uO4/q2oyi8BtVa+VIEMuOJl1IDcqaVIOlL66fMriC6r6IP1sKvP4obqZ3fVH3a8n2ci/PqUHI0op8R9UhiIBipQW8+chyLMQHtZBypcfdAKDI2ketd8hsxXUDdOduijVi1tNBeOWA373RZMScHlpNE6kDbo3Ruo+2Ii0NtAVM9I6N7o/6QjLShsEM7FZdrHJeXXzwUGf9ueUZP7Pg/p5HnJOS9/y9Ek9bVmk/eRbWlQStJdn16HMubsBecYKOIuU8Cjbk0W+Nrz8vujf04Od5f4mlQu5l33/6cW8r17K9nfc1zSLr74GHaEPsq/oDFGmuOWtOyZJ+9sxqqCd183F9NH76xxMaxutApE1rzzMhbY5ixtbMNf1Rtjrr1bIL3W0QEXIIlNXwmeMcEXAb6j25qWsd1a1tz5c7b2t2jsfqfbxau+cau9dXu3NSvtktddWba7f1npzyVrvfEXr+C01zfxeltFWTZb/nlrX22q9b3ywmm+r7M+xWV22O5r3++tyl1wgcuN54BUdCBw+rfu9bDt02v9Z8feHZ0K/W87bIWkqsJB2n20qyLjXafngm5d1P9sB0yQIaZkBO9MnbUCylAcQEjT8QvXFSaAgkfsPVJDwvadlEJD0M+oHMMmDmb71W/1cg/8rD0iSoOD+K3kw0B+3cI+tDPgBQLlkpmpEMhVZJQguZ7rka0ORTZVku1NlEpsuz5CnortHYjLtkvdO2+PWICiZrrlpDx3D1PtZGnmM9b5IkCiB41+qc0eCSwk6ZVCsnH8S0Mo5//ibg9K4ZNovtgPiapd8324qvHBpO0qe7W59lt+uCwqy6m1r1+xzOzIYaYdL+i/a+5g63jJu4ICqYEp3hXRZSpVSrvFPH2wYNE+7Qp/1pBIS9Fy3KLg592eu3B0pznmvC0naFai/zLp2PvBa/2eFfciKgg6+JiDWIdGWLGNo+Zm3P1n1PpwPfw4nHUnncj6fDTLmeS1oK2cr5jdVO+sI+V1HyNLafSFHyNeId36b2kD4apvN9ss+SeDx2vta+HKspI9Ll/t1pv+/RvYi+iNW1jMiafVveYDSjCPyGUfuhX8vD0QvcjeSt78/5Pyu/5qZYqBwyK5rZsnZBidQcIKDg05wIEGBBANSafiNeXaBzFSQi/+Hz14zsxWu5hUCqQ5IF4ZUBaQacMd9RfmHxZ8ORD5tbwqO2O3PphNHWmnh5tEX2rTz75CYpgMim3a+mtdOTevmvn8qVJrMX+cL3Uq8KL+paX8bXCmmxW1z1j1l93u6eCxKZeutd3Dcwsdiaujf7vK94MQsa8r53r/h7zejyeXzlm6hL9yvu6CkmiTnjpxjMvPlCZtxuyXyUlln1VKV37c90bU9+bWd5bRrMtvQe93fucvrLzcLbGtA8v62tr1Aou3s09A+Z4NmJR3c3ywc6Pj7NTfYfgmenjunq5RSqpfr/0fq+v6bR3UQf5vN3qfdz945rz3pa6EPCTOrEGlWL1pf/LWvD6zzfNn2VL0usK3ns5JgIytZdxZYd1byu5JAaM4LWLzXuyVuLeluv6TtCvqMkbRkzmcvreZZs8hM5Dybi3mtnyEHpbzNMt502Rvh6+xeH5NzJruXcr90D8iFI/1bejqfzeyX8oF9WvauiD0Bm+8lCDhkxH9oSN66EnBoZtAOl7WC5JcL68hFf1qvy77mkBtgzBTXkQcCLw8qBFIZkFLp3aar4ZfmWQVSBfiXJ68Z8evxAyL+O+/XA3c+m0s/0YMW++MAHNG0PNkMCWVwc5kqyCsdSNcTWD9Q6H8NyK5VlKAr1yknAOnLd3og+qlWUtimqWlP0q0yqRaDiCln2e5yfPH7gdGU97UQEJSJ3NnvKZv9TztBiveam428JXD7ssq8pYQrM1J+oaZkSaAoga2c8zKl9fn3Vopl8qBsS4QXlKAvp8wTlZehVsneFaYr19J1Z8PvDb4n8/4dCD6C8i9Znv/7uSy8zrmyfSwJGrxtPDarBS9PXZUA7NdqttE/quxdZgzIuJ28/3068a65tH+eOkLP4gRc+bqs4vdZIBioWdb5rDyzbbK950vkHLPf57OwsIPblRWEbfuhraxPO5m0lrQpbZss2pa0Q5J2M+Z5WoPMfi3P7OW4vmvK+BIwyeciF49kK/IQn0f6JfylvuhdYR82Yh8S8emlIdn63x/y3tOXvq0OnF4K/36m+ufFn/kBgl6vK36ZmaDFr6X/izzjv5b36Ukml89UEOmrMQAyMFDmC99mhH+rMzXRF6EWc+qILyy1qVKpFeVZ+P1QcFH9+pCohwOG1AsswsuYmi6TfxoMBobW1Qove3j70+D+uNsgwdbtSuAyZVTGaHxXjd/42fPqsd3q85QbvwhABqVKpepYqdiK2WGUkOY8Kc5VLNvPnqsCgdoAImvw2qrlZiXrD70vi1x/VrFfZZl5Fr/9zvJeeG+QvUvXncwo+qopzcv1WMjUp9OyDL07Brk3CQIqMuLKbLxKzg3FHbndJ11h9/ullaxVNviqEsVrFwcZdUHUn9iMOixpRL09sp+9vKaz+g9X889txmT1f5SBem+u9J/U92DeT79sMnpXnsum+dn08pB8DzuvOeRl56Eg4XAwQFgO/m54mX5Q4Wf9g9f0y/4m2582pX7JDkT6P1TzbyXL/3s1+O/rD+s5uDJ1Sfpl3ZJ+PiVxejg7nnIkGBLY1LRXWi681suUHZlOBcQ+FZR98T3VX1NvHWnwdTe529kqvi70nqnK74sBhsyUkIqJVE++ZErn0sUin4l0Jf3BlM1F3nL/jhZqYzk2Eeeo782a/W5u3PuxGS2LCHqyxsdXPmsJ2uTBYRKYf1d1ucnsnNvvGch9RKFnESX0cQcF4ww6ytd5cs5m14P+aitrKYFLKfdNk1lL+VsGcLUvm4FhAVkj0MlqA9Hrz/Yd9Tm/dnE1Pw+Ozeqn8j15Vov+oVeN6E8vBwU6LNfleuGWSNmX+qHaqkBM5WA48w8tW9q9trR/cikv7cusA+nTv8s+fljJ/pumH//zR/S0vs+o6Xy3ShnfK41PlWSqdS0UCPginfLK2XXBwU2BgKN8/Unj11Rl8PZ7qXrkfd8qQJLS6v9T3SM/Vv2oElhJF5GUzp99NyTvMQt4U2WZbTDTjg1YQq/JNikwidnXcQdWWUHuMrBOxtjIoFqpqjUQ+maLd7PWN5yhu9LWo7+1tHNhm1K4ZGzvFvqrV4N91Ehwr5XvdUZ/Nhe9PnfkGpLR93JxPSxle1Wyv19lwkciZXooIP5qMS9Xyn1Y0tXBQv32lL/vvlNuP75+yqCM5pfpT3epzF7+6NC31ZQoGa0v5eLb713IS/i32AF6nnDLBDgs3LRSmlP+YLbIbD4s3bRG6mml7P3l3tzSYxZE4F9RN2ERuFRC5Hj+TglcnpQmI6FHF3g2pkxylGVnkSIdV/Y/Suk+28JqxGZUNYpNyvJSsZHqTUDoGy1NZ9sk+aw0y877r81gszMXB/3XdoCZnYJFfzVt1BH4dkDeW5d0H71caBJBP+Fk8w8Y0cdk0xtry1GSrhN4qLugbD2DGQTLQ7KXvvtpM1jv50r0Mp9fJJZn9PLMbDUX+jYzH/8WGbFdIdSpyIz6prs9+d7ttOCy0v77CssPvd5dzt1JreylhP6ZXODqIUkqA/+OqmbIgEU5PjI/WQSe933PbkRo2QhZ7mZI0xd7tkml7O4mBi1bkclnYxe+nD8VGfp2ij3uvQNxq9L4+Szvy5abqQw6k6lb/qjwoZI4UqJtkujtYDwp28t4CumykQBToumnzGMjH1ID8B5wBuDVybgs0w6X45ej3++OAyh2DSyPLcg4HMjqW0b0/6lG5MuTyP5NDcwT2cmgPOmjl75BEWG/ZO+J9Ka7HQHnv0v19yFx3+1l0yW/v6lE1oWAwJe4v13TuqtB+sBlNoEEL/KkRNlneViLDHKSB7Ucm92KPtyt6iuepO3e6f3uzV4rf7PjlQt6FtQGB8VtTTn95Jx+etnL57v98rjcIKU/W26Wfl82/di0nZrNSzXI9s2//r7um39elVd1Jq/LZg/0B9/VZeDL0Rn3OEQcU9IftdmBeQflwTwn9ZMBpQz9A5XN/4OS/NfUQ3a+qCQvkvz0AZ3J3xTKvEP/rmre624Kvi4dFr37HvUz2Z7bVPAh2/hNNTVQxhYMBN7NP+NqgWe7RG5IfquO8fG27jKW7uEPrqz1Ll1dG1fJfTz925Jx51O9lLhnVJn81QuDKV5vWXFfLo4WR9q0SZ5HX5C8Or+lS0iqTjJ3WDJ5kbx+QM6y6ZNfHrn8Pt6yfnVF4XBgHEBVgHK4QvSu5KVv/nsqk/979YeAvv7wQi7QvFxvp9TVyjkZCgRuujtS/s7r90/r6oE8xOcbSuBSXfj1MT0K3Q5iKxf4dkkv2yZ5ZrsgsNjMdTffVrlHyBTceXX/+OjaWu+TxXX1dd0KfWsHvGlx6yb92/0yufRrf+iWyFfJtml7L5P/ZCB5KaOJ5OVaEUnIlJX8KXj56PpYSS9vgsibr/PwOLavn8nrEfcywven5i/+yRx6ecjKX+aPz5SsOanMrG32XSdv+1WWd/s96lG8KoiQUf2/VBUEeQqhPMdAZj+8YB/gQqZKpt1o/+OPjfhT7gdyf/hIZeSXlcg/MU3E7mXo2Qjl8fopYHmp3BuU9pYRdzsgbm7sNFpA8qZPXqpVMl/ejq5//A1VqjeD7o6cHv9AunGW6TdrG0TydvDdr9TT0qRU/x2nVC/98dKvLZl1bCYug/Mk8/+cycKlMiBTyR4z/eB5GZ0S8B6T/PZs84k5nfhKoiul9cvXBiIfCH2MGbrNukXeMjhtIO6sXypnUBqNNt6Bd3KBv/OhU6o/p/+y08NnqkfVb3fb7G1yS/VSCv+x/OleNYVO+re/KKPq5S/cHRguv9+svr9NZfdfUK/5zmN6MJtUBZ44q5/E9uLsbpXLdvThZxPa955tWTeKDHiTMWOS/Eo/+ccBkVdk6JEjy+e6hQFqcjN500wDywen0cdNo21bFn/OjKyXa1NG1T9hRtXnffGjCP5Uyb+bvK/q56dGWM+pyHX5I+vlsbemTC+C/4YaUS9zwe9UWbxk8/+sHn8rffWPqqcDPv32Sh4gHZslmyZj3tp9EZHLODJx6vs1Io8UelaYz50PUrtYHFk+S7mcRtvxWbxUx2QkrAj+T+bvz8vo6yHBn3LaTM3XUxWvL3vtTMR7Qq8d2obl8m3ylnPY+dlhZ12y31LBkGcEyODDZ1X2fcIZ2yP/Pj63VdLJJkhqGZLfxJaLXFW45Xq9uBAn8qDQXXmfMiPM33hfhsRn+RPTkDeNthsEr6/lt02Z/kR78McfHnIFf6pGxjFtpsF7S4W+PNq6vSb79IDaNxlQKOVzmfIjT/rT9zZd3bCPb551/kSv3AflGRcydfY4GTFtE0V+ykxBE5HbketNWi50Ebid0y2Dbc5587kRN422u8v09i/RieDk5mIfY/uQjKSfcQS/EalvpIVkPxMpcZWFP6okflRl4RK8yAOn7D1O9r2ThNv5ZCB5K/g33tcPCJIbryRACJ42jsFuUjkbZOTFkeuNhS4nd6G/mxsdjUYG/6F+hO1xI/hHXxs8o/7wqTFIepOalfgjanvlL+a9ZObrytieObVfZQKva/1n+TtdGLJcncGbEv1ElXp5YMt2HiMrcgmkdUY+msQLQpcHy8hJys2MRqPVCV7kJV10UrJ+xIyiPzKz/RI/MjPoDxeJS5ehVBvfM8nKqBKPEfycKtfbhwLJrJ5X5rXg90YGn7FvI04/c0etX17cuMwROo1GG0nw+vn0um9Znkn+B/V343X/+3K4/32TJC4Vg8dV18BzakDbjOl/nN1EiUdl8JfX+gGQjEGyJfoTlOj3bv+4ebKbPDwtn0d+pdlgN4ROo9G25G/Ht03/u4zBeUkNHJMM2Zbnx529S3/+Q0biL76nx/7kEr+8PRKPyuA/Wes/u//spay8D96fGhf6vupnsxXvLVvGbOS6y5ZVt+2zEe+t2s7ZBq+t2qbZhvswG7Ge2biBbi939LgNOR8+LHkgzPiEvo7QaTTaeAfYSflZSs8vqCepSfb+8Kuj9b3bkelS3n/yrJ4PLgP3zn1UP6htJzY7yM4GQXKjP6MEL9UF6es/7kp+tkbiIenNVoin7PUhCc/WrGvU1o78fbtiG+vEWre8snXEbGPMcbL94ybYvKCuDf8RrZsndDJ0Go22SYKX501LX6Fk7ycL2ftyafZuS+nyumfMoDZ5f8zI9Elr7ih6Ebw830MCFnmsr2TwJ9olgp/dgICrpNTeBGG3RxB77DpGkfHs5gQqtqwuU0GlIiMPg/lojP3jCJ1Go+247D0fPT+f5U9gk9K5ZO8yPe4R9fX36nv5eb+U7s/A2eXNzeClCvGWEfxpM9CuL/hRhdXeYOa8pS3b+nW2m7/+hHkQjARjHVNW//ja1kkcodNotO3vf/9kddC/bB8Z7Ty8qkNzBK+PU+VAu1nahiTe4BhKYPWyqRzl2fiCKatvk8gROo1G29ImfYky3/aS6U9Ml9Z7V5fXe9dWbqimv15R339yfT3PcuS1NrunDY+kt4GQDLSTMu+MM9DuOKIee8tL6mbK2bumb3w7s3GETqPRtl7gV/RjLJPrA4Evqna9G26L3Rv5a+S18h55r/RHXkDutVn8uY8blulp1RKf1RKXYykldTnWl8Y8d3z8Qr9cclEmTgt97782Dby+bDlV7w/9vOrfacXy0pp1JhHbkURsRxLx8yRyO2KOc+xxiDnGZZ951T7UvS6N+MxH+Vw3+vknDZZX97nFHssmn19S8/5RjsWo11IS+dUR+AUl8A+MwCXTXlhaz7NvEfhit1ziVXJfNHKXjF5Kmh8Yuc8j8yjB2zL9GTtdrq0lj7ArJN7u5hWPs2oWgnQD7ZSSenOhJ2NoacRNvU4KsUIZ9zbX/Tw2kBllXaNsa2wwktR8n0bIuepzjd3PdITPbtTzJan5rOq2K404v9PIY1e1bckI51IaEUjGrD/mmixZts3ARbBSepQbysJSXBY+altcuTEozS/q0vz7lOajBG9H0wcH2+3xUr3NxGfMnHFx4gcTIvGw0JMGQks2INZ0DOLdzNdvRku3IPCI3f90G4/NKOdI2lDuacMALRnDsUwb7ks6wn6P89xOR7uOc4GnJgPfIoHHyD3P3lU1QMqg0j9/MUXwTQfbyUNv8jnxpi/+pbndX6qX/ZP9lAGGb13SmfgkSlxa4lyLug99K7Lg3dR2mgzTCT0u6Q74PNIGy0r3wLmaOgI3GfjHpg/8yjYKPKY0b7P3JBf8oO+d8nzzLN6W6vvPpp9wwR93RqdL94PM+5d9twHqpEpcurSWsxu91bUbvbX1G06GjsRptD0ZZF4wJXQpX9uRu/4gtsXuzhF4U8F/YgbXyc2bDL55Fm8lbx98I5I/dd4ZVd/e2QKXLFz6w+W5Bhedc/zy4oRJXILqZRmTst5bWdUCV//1bqgmyNew0Gk02q4Vf6h8ni5NrsCbCH6hn8Gv5yOWLzpdEIi8ean+rPoTsq+b/vjtLtXbMrrtC3/PZOGXzHn+8QRm4akJrJfUOdwNSNwFodNou7xZedvsW0qL9iZxbQeWz7da8P0R9Iu6D16OE5KPnxfvPt1OJJ8/wtZ5Rr07de74JmXgr6gntUn3gFQR5p0y+sRm4W4pXQS+rmUdcDhCp9F2s7ylfeCWzm1f2y7Nvsc9yM7P4uU49qfKIfn4TP7yQPJvm0F3tlxvJX8iUvJW3nYkuixHBrLJsuUzuTTJAm+YhSN0Gm2PZN6hgWt7LfverCxejqvceC/b6XKmXI/o4wTvZ/JSrpfpc687kpdy+UnT5N+nzAA2yfjlPZ1kdfCwoqvrEy1wOZ9sX7gMaOtn4Q0ljtBptAnMut9fGGQil+1NYZnMezszeRG9VD/8bF4+qwve9EDEHm7uuI4LzviOgbT1LItJG4Xul9HtiPQlVUbP1kbPwiOEvsqNk0bbIeK2g9X6WbcpmV/pP/ccee/kbN4XvdzQrewvObLf7cJ3n3ngP4TI/llRK7qhc9tp+njq2QoLpkoi70t2uMD9MvrqJgicDJ1G2yniXhhk3Xb0bX+kOVn3rpO9W76/6shJPncJ3CQblXPBZvgXFwYl/Qslj2feUjkHZkrYANSey7LtMrBQ9sV2AaVG2FcD0t74sbyRl663W/Tug12uB/rBN9HhZOg02lZJ2y+V98UdKpfT143wvSzfz0qtQC6brF/aR9f0Iz8/NE3ONRsYFJqRbi7eheHfX3KaXZaI+SOzHrfkbTPQhYCsC1n2Fh+/RSP5kOg3o4RuBb7iZeBbJfAdl6F3uPnTdkGJ/KI3stxKu19O9MRN1k0bWV7d4bJ0KCC4FggQ3Hat5vXBdXQn59wNBUqjZvSuwPsl9DENZNv0DL3TQLp1v+tss8A7EdvSdBtjft/ZpiCns8Ht6Yxhu6rWFzrmnU08P5p8lv52+4N0bKbtS/vKUriciLRptJ0ter+P3sr+Sr9fPzyVbIf4Oyx02/fxflrss7kQcdOuE0in5Psq+dTd5DslN+K6bWqyjJjAoBP5u06NODoV+9+pObZNP59Og4Andts6kUFFnUCb7l+dtDsRQYYv7A+uFB8LmTiZNtKm0XZfWzJNHuIi4pYR6Ksq8+7LewcLPCj0Kyo6uWbKMFfc0Zm2j8b0y9g+mIuR4u9Eir5TI8D5Bpl1jKirtqNuXZ1IiXQqtism4Ok0CJ5ipdmpkV0nUqidiMCm7hh2Ij/rJsc+WAp3B+uIrM3f6u6PHi9k2OGnpi1toHHDpNF2nsBF3iurw9PHJknepUK/thKea1k6UMPtg1gcTMuQARQfBuTvli7zG+4IkpiPyIw7kdJokv3GBgKdmsy/LsAYx4jV+YhApSoIGmXfYrLiTsNy+oWSEbTuYB5/kFniDdCRBzZcN+e1vXhts1G432RQS3Xr1bSS962F1yet6zazbe62Lq/q7bdN5rASNNBozeUt15j+i2TF7Hs3USr0Jg9ZCMrfZvxG/v4UjY+dkZmV2b8TCNRli03EOB/5u/lIYTdZ33xEN0Rdqb7ToNIQUwGYr1l/p+E6L5T0QVsp22xZPzBiLVDaltGj+iEMK6YU1rXiNfJdW7fRtY6wC1F2TOuF21gvsLLWYDvXvSY3JLfJsSgECG5AYIOAjACAtgdK5879IiTvXebv8Qt9bAFAWQXACQLyQOCqM0XDnZ7hZHGhoGDe6R64EDGYq0mlYD5CvjF9u00z8PkRsuum6wuKOfXEfNWIeXGtP53FlrEX80El64USl/27vfZiq5RxD6IDh5qAYM2pJPQDAE/+y4ifNmmZ9x6V944Q+kZHJAYDgeXBlAy/IuBOTehPT7g2qBLoAKFYLejP41xwAoW0GCiUVRLq2rwfYIS6I9KBSOdDD5YYYb3+FCt3EJg79/SjvpyLUzXsOeJGwG6p2vZDrSPlyZB/Lyx+N+tf9aS/TKZP2+ase3C/Qd4TKfStmLtZOn/TDBa85s3ftIMH7TQH2xbcdn0QUBQCi7K2WNFK3pOWNHfaxRV33qntW+7acvZ6fqGs9MvZ+ma+vt6rlDMXz97M+ouZ/qDE72f3iIg2qriHK3nD9yHY40LfcYFFqNU8yMFvwVHYWbEMVexz7gUvDiJcGKfwC7J3M3uyeqQdKJVXiZt7EkLf1ReCL2z3YsgbJW+YFNFTvt8z9yr/PoW4EfqeKzkVMuz1G+XZNecwTNgNJyajp3y/87Ps0kwbaSP0vSptV9hEr4DohwfnZQzO29ZKYLfwnIYe0kboSHvVm6bFhQAwegm/IP2qKXjZ3n0Ijy9oN6v2H7C0WjeNtMd9CqEzuIORmQBbLPyq+fera+UP4VnxnspX9mS+jT7uN3pZ2bCM8+Y99dDNorNANr22zrMeEDptONtmcAfA5Mu/t7En8w26A2oe+dvgUcJl61gPbE/sExABoe/ppw7VPfMXaQNAo8Cht7mPFgbYs0IP/pk8J+NG3AAAgNAn8Vm/iBsAABD6zhQ3z/oFAACEPkEjyysfuMLnCgAACH1n/oUd+9e8mAoGAACwA4Ue+qP0q4FBagAAALBDhM4fpQcAAJgwoRfkvYa8AQAAdrzQQ2Vz5A0AALCDhR4esIa8AQAAdrTQh56sZqaKMWANAABghwl9cSW+dA4AAAA7VOjug1oonQMAAEyo0Mm+AQAAdonQAQAAAKEDAAAAQgcAAACEDgAAgNAROgAAAEIHAAAAhA4AAAAIHQAAABA6AAAAQgcAAACEDgAAAAgdAAAAEDoAAABCBwAAAIQOAAAACB0AAAAQOgAAAEIHAAAAhA4AAAAIHQAAABA6AAAAQgcAAACEDgAAAAgdAAAAEDoAAABCBwAAAIQOAAAACB0AAAAQOgAAAEIHAAAAhA4AAAAIHQAAABA6AAAAQgcAAACEDgAAAAgdAAAAEDoAAABCBwAAAIQOAAAACB0AAAAQOgAAAEIHAAAAhA4AAAAIHQAAABA6AAAAQkfoAAAACB0AAAAQOgAAACB0AAAAQOgAAAAIHQAAABA6AAAAIHQAAABA6AAAAAgdAAAAEDoAAAAgdAAAAEDoAAAACB0AAAAQOgAAACB0AAAAQOgAAAAIHQAAABA6AAAAIHQAAABA6AAAALuYdYQOAAAw+awpoyN0AAAAhA4AAAAIHQAAABA6AAAAIHQAAACEDgAAAAgdAAAAEDoAAAAgdAAAAIQOAAAACB0AAAAQOgAAACB0AAAAhA4AAAAIHQAAABA6AAAAIHQAAACEDgAAADta6OsIHQAAYBcIfZ0DAQAAsAuETooOAACA0AEAAAChAwAAwMZYXUPoAAAAE0+G0AEAACaf7ipCBwAAQOgAAACA0AEAAAChAwAAAEIHAABA6AAAAIDQAQAAYLxCX0PoAAAAky90eVwcAAAATLjQ5X8AAACA0AEAAAChAwAAAEIHAABA6AgdAAAAoQMAAABCBwAAAIQOAAAACB0AAAChAwAAAEIHAAAAhA4AAAAIHQAAAKEDAAAAQgcAAACEDgAAAAgdAAAAoQMAAABCBwAAAIQOAAAACB0AAAChAwAAAEIHAAAAhA4AAAAIHQAAAKEDAAAAQgcAAACEDgAAAAgdAAAAoQMAAABCBwAAAIQOAAAACB0AAAChAwAAAEIHAAAAhA4AAAAIHQAAAKEDAAAAQgcAAACEDgAAAAgdAAAAoQMAAABCBwAAAIQOAAAACB0AAAChI3QAAACEDgAAAAgdAAAAEDoAAAAgdAAAAIQOAAAACB0AAAAQOgAAACB0AAAAhA4AAAAIHQAAABA6AAAAIHQAAACEDgAAAAgdAAAAEDoAAAAgdAAAAIQOAAAACB0AAAAQOgAAACB0AAAAhA4AAAAIHQAAABA6AAAAIHQAAACEDgAAAAgdAAAAEDoAAAAgdAAAAIQOAAAACB0AAAAQOgAAACB0AAAAhA4AAAAIHQAAABA6AAAAIHQAAACEDgAAAAgdAAAAEDoAAAAgdAAAAIQOAAAACB0AAAAQOgAAACB0AAAAhI7QAQAAEDoAAAAgdAAAAEDoAAAA0Bd6htABAAAQOgAAAGyv0DOEDgAAgNABAAAAoQMAAABCBwAAAIQOAACA0AEAAAChAwAAAEIHAAAAhA4AAIDQAQAAAKEDAAAAQgcAAACEDgAAgNABAAAAoQMAAABCBwAAAIQOAACA0AEAAAChAwAAAEIHAAAAhA4AAIDQAQAAAKEDAAAAQgcAAACEDgAAgNABAAAAoQMAAABCBwAAAIQOAACA0AEAAAChAwAAAEIHAAAAhA4AAIDQAQAAAKEDAAAAQgcAAACEDgAAgNABAAAAoQMAAABCBwAAAIQOAACA0BE6AAAAQgcAAACEDgAAAAgdAAAAEDoAAABCBwAAAIQOAAAACB0AAAAQOgAAAEIHAAAAhA4AAAAIHQAAABA6AAAAQgcAAACEDgAAAAgdAAAAEDoAAABCBwAAAIQOAAAACB0AAAAQOgAAAEIHAAAAhA4AAAAIHQAAABA6AAAAQgcAAACEDgAAAAgdAAAAEDoAAABCBwAAAIQOAAAAWyz0bPXGCocCAABgchGX7+uu3WhzKAAAACY4Q1cu37d2o3eEQwEAADC5rK31juxTX6c4FAAAABPNlAj9U6rNcywAAAAmEnH4p/YJ6h9/zvEAAACYSP5in4v6wU84JgAAABPFT/b5qB/+mWr/wbEBAACYCMTZf7avjJ4uv9OnDgAAsDMRR//Fvhh6eqDclExpU0+faXdXb3TlKTQ0Go1Go9G2uGkHt800c5mZ9qmQu/8/DBHr6YiYFp4AAAAASUVORK5CYII=);
	}
	.tanchuang1 .txt{
		padding: 0 30rpx;
		letter-spacing:3rpx;
		font-size:30rpx;
		font-family:Source Han Sans CN;
		font-weight: 400;
		color: #0068A0;
		text-align: left;
		line-height: 50rpx;
	}
	.tanchuang1 .btn{
		width: 440rpx;
		height: 80rpx;
		border-radius: 40rpx;
		background-color: #3DA6DE;
		color: #FFFFFF;
		line-height: 80rpx;
		margin: 80rpx auto;
	}
	.tab {
		width: 560rpx;
		height: 70rpx;
		display: flex;
	}
	.tab>view {
		width: 50%;
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #9A9A9A;
		line-height: 70rpx;
		text-align: center;
		position: relative;
	}
	.tab .line {
		width: 2rpx;
		height: 50rpx;
		background: #F5F5F5;
		position: absolute;
		left: 270rpx;
		top: 10rpx;
	}
	.tab .label {
		width: 100rpx;
		height: 2rpx;
		background: #3EA4E1;
		position: absolute;
		bottom: 0;
		left: 50%;
		margin-left: -50rpx;
	}

	.tab .txt1 {
		color: #3CA4DC;
	}
	
	.big .record {
		width: 154rpx;
		height: 50rpx;
		background: #3EA4E1;
		border-radius: 25rpx 0px 0px 25rpx;
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #FFFFFF;
		line-height: 50rpx;
		text-align: center;
		margin-top: 10rpx;
	}
	/* 门店列表 */
	.shopList {
		width: 100%;
		padding-top: 320rpx;
		background-color: #F5F5F5;
	}
	.shopList .bomm {
		margin-bottom: 20rpx;
		background-color: #FFFFFF;
	}
	.shopList .up {
		width: 100%;
		display: flex;
		justify-content: space-between;
		padding: 15rpx 30rpx;
		box-sizing: border-box;
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #9A9A9A;
	}
	.shopList .up .img{
		width: 50rpx;
		height: 50rpx;
		border-radius: 50%;
		margin-right: 22rpx;
		vertical-align: middle;
	}
	.shopList .up .butt {
		width: 135rpx;
		height: 50rpx;
		background: #3EA4E1;
		border-radius: 25rpx;
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #FFFFFF;
		text-align: center;
		line-height: 50rpx;
	}
	.shopList .up .butts {
		width: 135rpx;
		height: 50rpx;
		background: #CCCCCC;
		border-radius: 25rpx;
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #FFFFFF;
		text-align: center;
		line-height: 50rpx;
	}
	.shopList .down {
		margin-left: 40rpx;
		padding-right: 35rpx;
		border-top: 2rpx solid #F5F5F5;
		display: flex;
		padding-top: 20rpx;
		padding-bottom: 20rpx;
	}
	.shopList .down image {
		width: 140rpx;
		height: 140rpx;
		margin-right: 25rpx;
		border-radius: 6rpx;
	}
	.shopList .down .right {
		display: flex;
		flex-direction: column;
		justify-content: space-around;
		flex: 1;
	}
	.down .right .txt1{
		font-size: 28rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #343434;
		height: 80rpx;
		overflow: hidden;
		text-overflow: ellipsis;
		display: -webkit-box;
		-webkit-line-clamp: 2;
		-webkit-box-orient: vertical;
	}
	.down .right .txt2 {
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #3EA4E1;
	}
	/* 代领弹窗 */
	.replaceWin {
		width: 100%;
		height: 100%;
		position: fixed;
		top: 0;
		left: 0;
		background-color: rgba(0,0,0,.5);
		z-index: 22;
	}
	.replaceWin .window {
		position: absolute;
		top: 50%;
		left: 50%;
		transform: translate(-50%,-50%);
		background:rgba(255,255,255,1);
		width: 600rpx;
		/* height: 400rpx; */
		border-radius: 10rpx;
		box-sizing: border-box;
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #999999;
	}
	.replaceWin .title {
		font-weight: 500;
		color: #333333;
		padding: 50rpx;
		text-align: center;
	}
	.replaceWin input {
		width: 530rpx;
		border-bottom: 1rpx solid #F5F5F5;
		margin: 30rpx 30rpx;
	}
	.replaceWin .butt {
		width: 100%;
		border-top: 1rpx solid #F5F5F5;
		margin-top: 90rpx;
		/* padding: 30rpx 0; */
		display: flex;
		justify-content: space-between;
		box-sizing: border-box;
		position: relative;
	}
	.replaceWin .butt view{
		width: 50%;
		text-align: center;
		height: 90rpx;
		line-height: 90rpx;
	}
	.replaceWin .butt .line {
		position: absolute;
		top: 0;
		left: 300rpx;
		width: 2rpx;
		height: 90rpx;
		background: #F5F5F5;
		border-radius: 1px;
	}
	.replaceWin .butt .txt1 {
		color: #3FA2E0;
	}
	.delivery {
		position: fixed;
		bottom: 0;
		left: 0;
		width: 100%;
		height: 140rpx;
		background: #000000;
		opacity: 0.7;
		padding: 30rpx;
		box-sizing: border-box;
		display: flex;
		justify-content: space-between;
		align-items: center;
	}
	.delivery .carimg image {
		width: 122rpx;
		height: 122rpx;
		margin-right: 20rpx;
	}
	.delivery .text {
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #FFFFFF;
	}
	.delivery .carbtn {
		width: 250rpx;
		height: 60rpx;
		background: #3FA3DC;
		border-radius: 30rpx;
		text-align: center;
		line-height: 60rpx;
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #FFFFFF;
		margin-left: 40rpx;
	}
</style>
