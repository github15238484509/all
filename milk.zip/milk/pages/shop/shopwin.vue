<!-- 门店代领取成功页面 -->
<template>
	<view>
		<view class="one">
			<image :src="cdnUrl+'bashi/image/moneySc.png'"></image>
			<view>领取成功</view>
		</view>
		<view class="check" @click="examine()">返回</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				retCash:'',//返现优惠
				cdnUrl:'',
			}
		},
		onShareAppMessage: function () {
		    return {
		      title:'乃小星',
		      path: '/pages/index/index?scene=' + '1-'+uni.getStorageSync('phone')
		    }
		},
		methods: {
			examine(){
				uni.navigateBack({
					delta:1
				})
			},
		},
		onLoad() {
			this.cdnUrl=this.$cdnUrl
		}
	}
</script>

<style>
.one{
	text-align: center;
	font-size: 30rpx;
	font-family: PingFang SC;
	font-weight: 500;
	color: #343434;
	padding-top: 150rpx;
}
.one image {
	width: 146rpx;
	height: 185rpx;
	padding-bottom: 50rpx;
}
.check {
	width: 690rpx;
	height: 90rpx;
	background: #3EA4E1;
	border-radius: 45rpx;
	line-height: 90rpx;
	text-align: center;
	font-size: 30rpx;
	font-family: PingFang SC;
	font-weight: 500;
	color: #FFFFFF;
	margin: 50rpx 30rpx;
}
</style>
