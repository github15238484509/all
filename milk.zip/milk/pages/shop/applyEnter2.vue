<!-- 门店申请2 -->
<template>
	<view>
		<view class="information">
			<view class="hang">
				<view class="phopphoto">
					<view class="txt1">营业执照照片</view>
					<view class="txt">
						<view>1、需文字清晰、边框完整、露出国徽</view>
						<view>2、拍复印件需加盖印章、可用有效特许证件代替</view>
					</view>
				</view>
				<image src="../../static/appimg.png" @click="addImg1()" v-if="imgs1==''"></image>
				<image :src="cdnUrl+imgs1" @click="addImg1()" v-else></image>
			</view>
			<view class="time">
				<view class="left">
					<view class="permit">营业执照有效期</view>
				</view>
				<view class="lang" @click="golang()">					
					<image src="../../static/noaffirm.png" v-if="checked==false"></image>
					<image src="../../static/affirm.png" v-else></image>长期有效
				</view>
				<picker class="shot" mode="date" @change="bindDateChange">{{date}}<image src="../../static/mores.png"></image></picker>	
			</view>
			<view class="line"></view>
			<view class="hang">
				<view class="phopphoto">
					<view>法人代表身份证国徽面</view>
					<view class="txt">
						<view>1、法人代表身份证国徽面</view>
					</view>
				</view>
				<image src="../../static/appimg.png" @click="addImg2()" v-if="imgs2==''"></image>
				<image :src="cdnUrl+imgs2" @click="addImg2()" v-else></image>
			</view>
			<view class="hang">
				<view class="phopphoto">
					<view>法人代表身份证人像面</view>
					<view class="txt">
						<view>1、人像面需清晰拍出有效期等文字信息</view>
					</view>
				</view>
				<image src="../../static/appimg.png" @click="addImg3()" v-if="imgs3==''"></image>
				<image :src="cdnUrl+imgs3" @click="addImg3()" v-else></image>
			</view>
<!-- 			<view class="hang">
				<view class="phopphoto">
					<view>法人代表手持身份证件照</view>
					<view class="txt">
						<view>1、正面需清晰拍出人物五官和文字信息</view>
						<view>2、不可自拍、不可知拍身份证</view>
					</view>
				</view>
				<image src="../../static/appimg.png" @click="addImg4()" v-if="imgs4==''"></image>
				<image :src="cdnUrl+imgs4" @click="addImg4()" v-else></image>
			</view> -->
		</view>
		<!-- 按钮 -->
		<view class="butt">
			<view class="next" @click="present()">提交</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				checked:false, //长期有效图片显示状态
				merchant_name:'',//商家名称
				merchant_contacts:'',//商家联系人
				merchant_tel:'',//商家联系电话
				merchant_longitude:'',//用户经度 较大值
				merchant_latitude:'',//用户纬度 较小值
				merchant_address:'',//详细地址
				merchant_logo:'',//商家店铺头像
				merchant_license:'',//营业执照
				license_time:'',//营业执照有效期
				card_front:'',//身份证正面
				card_reverse:'',//身份证反面
				card_person:'',//手持身份证
				imgs:'',//门店照
				imgs1:'',//营业执照照片
				imgs2:'',//法人1
				imgs3:'',//法人2
				imgs4:'',//法人3
				cdnUrl:'',
				baseUrl:'',
				date:'请选择到期时间',
				timedate:'',//营业执照显示的文字 ==> 提交按钮传值
			}
		},
		onShareAppMessage: function () {
		    return {
		      title:'乃小星',
		      path: '/pages/index/index?scene=' + '1-'+uni.getStorageSync('phone')
		    }
		},
		methods: {
			// init初始化
			init(){
					if(!uni.getStorageSync('token')){
						uni.redirectTo({
							url:'../my/login'
						})
					}
			},
			// 添加图片
			addImg1(){
				let self = this,
				header = {
				  'Content-Type': 'multipart/form-data'// 获取到一个本地资源的临时文件路径后，可通过此接口将本地资源上传到指定服务器
				};
				uni.chooseImage({
				  count: 1,
				  success: function(res) {
					  uni.showLoading({
					  	title:'加载中'
					  })
					uni.uploadFile({
					  url: self.baseUrl+'bashi/api/app.php?c=common/identity_card/uploadCardImage',//+url地址
					  filePath: res.tempFilePaths.join(','),//临时路径 tempFilePaths
					  name: 'file',
					  method:'POST',
					  formData: {
						identity_img:res.tempFilePaths.join(',')
					  },
					  header: header,
					  success: function(res) {
					  	uni.hideLoading()
					  	let data = JSON.parse(res.data);
					  	if (data.success) {
					  		uni.showToast({
					  			title: '上传成功'
					  		});
					  		self.imgs1=data.data;
					  	} else {
					  		uni.showToast({
					  			icon: 'none',
					  			title: '上传失败，请重试~'
					  		});
					  	}
					  },fail:function(res){
					  	console.log(res)
					  }
					})
				  }
				})
			},
			addImg2(){
				let self = this,
				header = {
				  'Content-Type': 'multipart/form-data'// 获取到一个本地资源的临时文件路径后，可通过此接口将本地资源上传到指定服务器
				};
				uni.chooseImage({
				  count: 1,
				  success: function(res) {
					  uni.showLoading({
					  	title:'加载中'
					  })
					uni.uploadFile({
					  url: self.baseUrl+'bashi/api/app.php?c=common/identity_card/uploadCardImage',//+url地址
					  filePath: res.tempFilePaths.join(','),//临时路径 tempFilePaths
					  name: 'file',
					  method:'POST',
					  formData: {
						identity_img:res.tempFilePaths.join(',')
					  },
					  header: header,
					  success: function(res) {
					  	uni.hideLoading()
					  	let data = JSON.parse(res.data);
					  	if (data.success) {
					  		uni.showToast({
					  			title: '上传成功'
					  		});
					  		self.imgs2=data.data;
					  	} else {
					  		uni.showToast({
					  			icon: 'none',
					  			title: '上传失败，请重试~'
					  		});
					  	}
					  },fail:function(res){
					  	console.log(res)
					  }
					})
				  }
				})
			},
			addImg3(){
				let self = this,
				header = {
				  'Content-Type': 'multipart/form-data'// 获取到一个本地资源的临时文件路径后，可通过此接口将本地资源上传到指定服务器
				};
				uni.chooseImage({
				  count: 1,
				  success: function(res) {
					  uni.showLoading({
					  	title:'加载中'
					  })
					uni.uploadFile({
					  url: self.baseUrl+'bashi/api/app.php?c=common/identity_card/uploadCardImage',//+url地址
					  filePath: res.tempFilePaths.join(','),//临时路径 tempFilePaths
					  name: 'file',
					  method:'POST',
					  formData: {
						identity_img:res.tempFilePaths.join(',')
					  },
					  header: header,
					  success: function(res) {
					  	uni.hideLoading()
					  	let data = JSON.parse(res.data);
					  	if (data.success) {
					  		uni.showToast({
					  			title: '上传成功'
					  		});
					  		self.imgs3=data.data;
					  	} else {
					  		uni.showToast({
					  			icon: 'none',
					  			title: '上传失败，请重试~'
					  		});
					  	}
					  },fail:function(res){
					  	console.log(res)
					  }
					})
				  }
				})
			},
			addImg4(){
				let self = this,
				header = {
				  'Content-Type': 'multipart/form-data'// 获取到一个本地资源的临时文件路径后，可通过此接口将本地资源上传到指定服务器
				};
				uni.chooseImage({
				  count: 1,
				  success: function(res) {
					  uni.showLoading({
					  	title:'加载中'
					  })
					uni.uploadFile({
					  url: self.baseUrl+'bashi/api/app.php?c=common/identity_card/uploadCardImage',//+url地址
					  filePath: res.tempFilePaths.join(','),//临时路径 tempFilePaths
					  name: 'file',
					  method:'POST',
					  formData: {
						identity_img:res.tempFilePaths.join(',')
					  },
					  header: header,
					  success: function(res) {
					  	uni.hideLoading()
					  	let data = JSON.parse(res.data);
					  	if (data.success) {
					  		uni.showToast({
					  			title: '上传成功'
					  		});
					  		self.imgs4=data.data;
					  	} else {
					  		uni.showToast({
					  			icon: 'none',
					  			title: '上传失败，请重试~'
					  		});
					  	}
					  },fail:function(res){
					  	console.log(res)
					  }
					})
				  }
				})
			},
			// 删除图片
			del1(e){
				for(var i =0; i <this.imgs1.length;i++){
					if(i==e){
						this.imgs1.splice(i,1)
					}
				}
			},
			del2(e){
				for(var i =0; i <this.imgs2.length;i++){
					if(i==e){
						this.imgs2.splice(i,1)
					}
				}
			},
			del3(e){
				for(var i =0; i <this.imgs3.length;i++){
					if(i==e){
						this.imgs3.splice(i,1)
					}
				}
			},
			del4(e){
				for(var i =0; i <this.imgs4.length;i++){
					if(i==e){
						this.imgs4.splice(i,1)
					}
				}
			},
			
			// 长期有效显示状态
			golang(){
				if(this.checked==true){
					this.checked=false
				}else{
					this.checked=true
					this.date='请选择到期时间'
				}
			},
			// 其他时间下拉框
			bindDateChange(e){
				this.checked=false
				this.date = e.target.value
			},
			// 提交按钮
			present(){
				let self=this
				if(self.checked==false){
					self.timedate=self.date
				}else{
					self.timedate='长期有效'
				}
					if(self.imgs1.length==''){
						uni.showToast({
							icon:'none',
						    title: '营业执照照片不能为空',
						    duration: 2000
						});
					}else if(self.checked==false && self.date=='请选择到期时间'){
						uni.showToast({
							icon:'none',
						    title: '请选择营业执照有效期',
						    duration: 2000
						});
					}else if(self.imgs2.length==''){
						uni.showToast({
							icon:'none',
						    title: '法人身份证正面照不能为空',
						    duration: 2000
						});
					}else if(self.imgs3.length==''){
						uni.showToast({
							icon:'none',
						    title: '法人身份证背面照不能为空',
						    duration: 2000
						});
					// }else if(self.imgs4.length==''){
					// 	uni.showToast({
					// 		icon:'none',
					// 	    title: '法人代表手持身份证件照不能为空',
					// 	    duration: 2000
					// 	});
					}else{
						console.log(self.imgs)
						self.request({
							url:'bashi/api/app.php?c=mer/addMer',
							data:{
								token:uni.getStorageSync('token'),
								merchant_name:self.merchant_name,//商家名称
								merchant_contacts:self.merchant_contacts,//商家联系人
								merchant_tel:self.merchant_tel,//商家联系电话
								merchant_longitude:self.merchant_longitude,//用户经度 较大值
								merchant_latitude:self.merchant_latitude,//用户纬度 较小值
								merchant_address:self.merchant_address,//详细地址
								merchant_logo:self.imgs,//商家店铺头像
								merchant_license:self.imgs1,//营业执照
								license_time:self.timedate,//营业执照有效期
								card_front:self.imgs2,//身份证正面
								card_reverse:self.imgs3,//身份证反面
								card_person:self.imgs4,//手持身份证
							},
						}).then(res=>{
							if (res.data.success) {
								uni.showToast({
									title: res.data.msg
								});
								setTimeout(()=>{
									uni.switchTab({
										url:'./shopEnter'
									})
								},1000)
									
							}else {
								uni.showToast({
									icon: 'none',
									title: res.data.msg
								});
								setTimeout(()=>{
									uni.switchTab({
										url:'./shopEnter'
									})
								},1000)
							}
						},rej=>{
							uni.showToast({
								icon: 'none',
								title: res.data.msg
							});
						})
					}
			},
		},
		onLoad(options) {
			this.cdnUrl=this.$cdnUrl
			this.baseUrl=this.$baseUrl
			this.init()
			this.merchant_name=options.name
			this.merchant_contacts=options.contacts
			this.merchant_tel=options.tel
			this.imgs=options.imgs
			this.merchant_address=options.address
			this.merchant_longitude=options.longitude
			this.merchant_latitude=options.latitude
			console.log(options.name)
			console.log(options.imgs)
			console.log(options.address)
		}
	}
</script>

<style>
page {
	position: relative;
	height: 100%;
}
input{
	flex: 1;
	text-align: right;
}
.line {
	width: 100%;
	height: 20rpx;
	background: #E0E0E0;
}
.information {
	font-size: 26rpx;
	font-family: HiraginoSansGB;
	font-weight: normal;
	color: #222222;
	box-sizing: border-box;
	margin-bottom: 150rpx;
}
.information .hang {
	border-top: 1rpx solid #F5F5F5;
	border-bottom: 1rpx solid #F5F5F5;
	padding: 35rpx 30rpx;
	margin: -1rpx;
	display: flex;
	justify-content: space-between;
}
.information .hang .phopphoto {
	display: flex;
	flex-direction: column;
	flex: 1;
}
.hang .phopphoto .txt1 {
	font-family: PingFang SC;
	font-weight: 400;
}
.hang .phopphoto .txt {
	font-size: 24rpx;
	color: #999999;
	padding-top: 20rpx;
}
.hang image {
	width: 130rpx;
	height: 130rpx;
}
.time {
	padding: 30rpx 30rpx;
	font-family: PingFang SC;
	font-weight: 400;
	display: flex;
	justify-content: space-between;
}
.time .lang image {
	width: 36rpx;
	height: 36rpx;
	vertical-align: middle;
	margin-right: 5rpx;
	padding-left: 40rpx;
}
.time .shot image {
	width: 26rpx;
	height: 26rpx;
	vertical-align: middle;
	margin-left: 15rpx;
}
/* 添加图片 */
.addimg image {
	width: 120rpx;
	height: 120rpx;
	margin-bottom: 20rpx;
	margin-right: 20rpx;
}
.addimg .del {
	width: 32rpx;
	height: 32rpx;
	position: absolute;
	top: -20rpx;
	right: 20rpx;
}
/* 按钮 */
.butt {
	position: fixed;
	bottom: 0;
	left: 0;
	width: 750rpx;
	height: 100rpx;
	background: #FFFFFF;
	box-shadow: 0px -2px 5px 0px rgba(0, 0, 0, 0.1);
}
.butt .next {
	margin: 5rpx auto;
	width: 690rpx;
	height: 90rpx;
	background: #3DA3E1;
	border-radius: 45rpx;
	font-size: 30rpx;
	font-family: PingFang SC;
	font-weight: 500;
	color: #FFFFFF;
	line-height: 90rpx;
	text-align: center;
}
</style>
