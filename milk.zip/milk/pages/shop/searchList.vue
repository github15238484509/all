<!-- 搜索列表 =getRecord领取记录页面-->
<template>
	<view>
		<!-- 搜索框 -->
		<view class="status_bar">
			<view class="input">
				<input type="text" :value="value" confirm-type="search" @confirm="confirm" @input="getValue" placeholder="请输入手机号/昵称"/>
				<image src="../../static/search(1).png" class="search_img" @click="search"></image>
				<view class="del" @click="del" v-if="value">
					<image src="../../static/del.png" ></image>
				</view>
			</view>
			<view style="margin-left: 20rpx;" @click="search()">搜索</view>
		</view>
		<!-- tab栏切换 -->
		<view class="tab">
			<block v-for="(item ,i) in tablist" :key="item.id">
				<view :class="seletedIndex==item.id?'txt1':'txt2'" @click="tabStatus(item.id)">
				<text>{{item.tab1}}</text>
				</view>
			</block>
		</view>
		<!-- 门店列表shopList -->
		<view class="shopList">
			<view class="bomm">
				<view class="up">
					<view class="left">
						<image src="../../static/about.png" class="img"></image>
						马小马（188****888）
					</view>
					<view v-if="record">已领取1瓶</view>
					<view v-else>未领取</view>
				</view>
				<view class="down">
					<!-- <image src="../../static/ban1.jpg"></image> -->
					<view class="right">
						<view class="txt1">巴氏鲜奶200ml/瓶，按月订购，新鲜配送</view>
						<view class="txt2">2020-08-31 12:33</view>
					</view>
				</view>
			</view>
			<view style="width: 100%; height: 20rpx; background-color: #F5F5F5;"></view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				tablist:[ // tab栏状态切换
					{tab1:"领取中",id:"0"},
					{tab1:"已作废",id:"1"}
				],
				seletedIndex:'0', // 点击状态ID
				shopList:[],//门店列表
				record:true,// 是否领取文字切换状态
			}
		},
		methods: {
			// tab栏切换
			tabStatus(id){
				this.seletedIndex=id
			},
			// init初始化
			init(){
				let self = this;
				self.request({
					url: 'bashi/api/app.php?c=mer/receiveRecords',
					data: {
						token: uni.getStorageSync('token'),
						page:self.page,
						goods_name:self.value
					},
					success: function(res) {
						if(res.data.success){
							
						}
					}
				});
			},
		},
		onShareAppMessage: function () {
		    return {
		      title:'乃小星',
		      path: '/pages/index/index?scene=' + '1-'+uni.getStorageSync('phone')
		    }
		},
		onLoad(options){
			this.init()
			this.value = options.value
		}
	}
</script>

<style lang="scss">
.status_bar {
	padding: 15rpx 30rpx;
	display: flex;
	font-size: 30rpx;
	font-family: PingFang SC;
	font-weight: 400;
	color: #333333;
	align-items: center;
	.input {
		width: 450rpx;
		height: 70rpx;
		padding: 0 70rpx 0 60rpx;
		line-height: 70rpx;
		height: 70rpx;
		background: rgba(238, 241, 244, 1);
		border-radius: 35rpx;
		position: relative;
		input {
			height: 70rpx !important;
			line-height: 70rpx !important;
		}
		.search_img {
			width: 30rpx;
			height: 28rpx;
			position: absolute;
			top: 20rpx;
			left: 25rpx;
		}
		.del {
			width: 80rpx;
			height: 70rpx;
			position: absolute;
			top: 0;
			right: 0;
			text-align: center;
			image{
				width: 30rpx;
				height: 30rpx;
			}
		}
	}
}
/* tab栏切换 */
.tab {
	width: 750rpx;
	height: 70rpx;
	border-bottom: 1rpx solid #F5F5F5;
	background-color: #FFFFFF;
	display: flex;
}
.tab .txt1 {
	width: 374rpx;
	height: 50rpx;
	border-right: 1rpx solid #F5F5F5;
	padding: 0 140rpx;
	margin: 10rpx 0;
	box-sizing: border-box;
}
.tab text {
	width: 90rpx;
	height: 50rpx;
	display: block;
	font-size: 30rpx;
	font-family: PingFang SC;
	font-weight: 500;
	color: #3CA6E5;
	line-height: 50rpx;
	text-align: center;
	padding-bottom: 10rpx;
	border-bottom: 1rpx solid #3CA6E5;
}
.tab .txt2 text{
	font-weight: 400;
	border-bottom: 0;
	color: #9A9A9A;
	width: 374rpx;
	height: 50rpx;
	margin: 10rpx 0;
	border-right: 1rpx solid #F5F5F5;
	box-sizing: border-box;
}
/* 门店列表 */
.shopList {
	width: 100%;
}
.shopList .bomm {
	background-color: #FFFFFF;
}
.shopList .up {
	width: 100%;
	display: flex;
	justify-content: space-between;
	padding: 15rpx 30rpx;
	box-sizing: border-box;
	font-size: 26rpx;
	font-family: PingFang SC;
	font-weight: 400;
	color: #9A9A9A;
}
.shopList .up .img{
	width: 50rpx;
	height: 50rpx;
	border-radius: 50%;
	margin-right: 22rpx;
	vertical-align: middle;
}
.shopList .up .butt {
	width: 135rpx;
	height: 50rpx;
	background: #3EA4E1;
	border-radius: 25rpx;
	font-size: 26rpx;
	font-family: PingFang SC;
	font-weight: 400;
	color: #FFFFFF;
	text-align: center;
	line-height: 50rpx;
}
.shopList .down {
	margin-left: 40rpx;
	padding-right: 35rpx;
	border-top: 2rpx solid #F5F5F5;
	display: flex;
	padding-top: 20rpx;
	padding-bottom: 20rpx;
	border-radius: 6rpx;
}
.shopList .down image {
	width: 140rpx;
	height: 140rpx;
	margin-right: 25rpx;
}
.shopList .down .right {
	display: flex;
	flex-direction: column;
	justify-content: space-around;
	flex: 1;
}
.down .right .txt1{
	font-size: 28rpx;
	font-family: PingFang SC;
	font-weight: 400;
	color: #343434;
}
.down .right .txt2 {
	font-size: 26rpx;
	font-family: PingFang SC;
	font-weight: 400;
	color: #3EA4E1;
}
</style>
