<!-- 领取记录页面 -->
<template>
	<view>
		<!-- 搜索框 -->
		<view class="search" @click="goSearch()">
			<image src="../../static/search(1).png" style="width: 34rpx;height: 34rpx;vertical-align: middle;margin-right: 20rpx;"></image>
			搜索
		</view>
		<!-- tab栏切换 -->
		<view class="tab">
			<block v-for="(item ,i) in tablist" :key="item.id">
				<view :class="seletedIndex==item.id?'txt1':'txt2'" @click="tabStatus(item.id)">
				<text>{{item.tab1}}</text>
				</view>
			</block>
		</view>
		<!-- 门店列表shopList -->
		<view class="shopList" v-for="(item,i) in shopList" :key="i">
			<view class="bomm">
				<view class="up">
					<view class="left">
						<image :src="cdnUrl+item.photo" class="img"></image>
						{{item.name}}（{{item.phone}}）
					</view>
					<view v-if="item.delivery_status==1">已领取{{item.day_count}}瓶</view>
					<view v-else>未领取</view>
				</view>
				<view class="down">
					<image :src="cdnUrl+item.goods_icon"></image>
					<view class="right">
						<view class="txt1">{{item.goods_name}}</view>
						<view class="txt2" v-if="item.delivery_status==1">{{formatTime(item.delivery_time)}}</view>
						<view class="txt2" v-else>{{item.add_date}}发放</view>
					</view>
				</view> 
			</view>
			<view style="width: 100%; height: 20rpx; background-color: #F5F5F5;"></view>
		</view>
		<view class="nodate" v-if="shopList.length== 0">暂无信息</view>
	</view>
</template>

<script>
	import uniIcons from "@/components/uni-icons/uni-icons.vue"
	export default {
		data() {
			return {
				tablist:[ // tab栏状态切换
					{tab1:"领取中",id:"1"},
					{tab1:"已作废",id:"2"}
				],
				seletedIndex:'1', // 点击状态ID
				shopList:[],//门店列表
				// record:true,// 是否领取文字切换状态
				page:0,//分页
				pageCount:0,//总页数
				keywords:'',
				cdnUrl:'',
			}
		},
		methods: {
			// tab栏切换
			tabStatus(id){
				this.seletedIndex=id
				this.shopList=[]
				this.page=0
				this.init()
			},
			// init初始化
			init(){
				if(uni.getStorageSync('token')){
					let self=this
					self.request({
						url:'bashi/api/app.php?c=mer/receiveRecords',
						data:{
							token:uni.getStorageSync('token'),
							type:self.seletedIndex, // 领取状态
							page:self.page ,//分页
							keywords:self.keywords,//关键词
						},
					}).then(res=>{
						if(res.data.success){
							self.pageCount=res.data.pageCount
							// self.shopList=res.data.data.list
							for(var i =0; i<res.data.data.list.length; i++){
								self.shopList.push(res.data.data.list[i])
							}
						}else{
							if(res.data.msg=='登录状态失效，请重新登录~！'){
								uni.removeStorageSync('token')
								uni.reLaunch({
									url:'../my/login'
								})
							}else{
								uni.showToast({
									icon:'none',
									title:res.data.msg
								})
							}
						}
					},rej=>{
						uni.showToast({
							icon:'none',
							title:res.data.msg
						})
					})
				}
			},
			
			//去搜索页面
			goSearch(){
				uni.navigateTo({
					url:'./search'
				})
			},
		},
		// 上拉加载(小程序自带函数)
		onReachBottom(){
			if(this.page<this.pageCount-1){
				this.page++
				this.init()
			}
		},
		onShareAppMessage: function () {
		    return {
		      title:'乃小星',
		      path: '/pages/index/index?scene=' + '1-'+uni.getStorageSync('phone')
		    }
		},
		onLoad(options){
			this.cdnUrl=this.$cdnUrl
			if(options.value){
				this.keywords = options.value
			}
			this.shopList=[]
			this.page=0
			this.init()
		},
	}
</script>

<style>
/* 暂无数据 */
.nodate{
	margin: 200rpx;
	text-align: center;
}
/* 搜索框 */
.search{
	width:690rpx;
	height:70rpx;
	text-align: center;
	line-height: 70rpx;
	background:rgba(245,245,245,.5);
	border-radius:35rpx;
	margin: auto;
	font-size:30rpx;
	font-family:PingFang SC;
	font-weight:400;
	color: #999999;
	ackground: #F5F5F5;
}
/* tab栏切换 */
.tab {
	width: 750rpx;
	height: 70rpx;
	border-bottom: 1rpx solid #F5F5F5;
	background-color: #FFFFFF;
	display: flex;
}
.tab .txt1 {
	width: 374rpx;
	height: 50rpx;
	border-right: 1rpx solid #F5F5F5;
	padding: 0 140rpx;
	margin: 10rpx 0;
	box-sizing: border-box;
}
.tab text {
	width: 90rpx;
	height: 50rpx;
	display: block;
	font-size: 30rpx;
	font-family: PingFang SC;
	font-weight: 500;
	color: #3CA6E5;
	line-height: 50rpx;
	text-align: center;
	padding-bottom: 10rpx;
	border-bottom: 1rpx solid #3CA6E5;
}
.tab .txt2 text{
	font-weight: 400;
	border-bottom: 0;
	color: #9A9A9A;
	width: 374rpx;
	height: 50rpx;
	margin: 10rpx 0;
	border-right: 1rpx solid #F5F5F5;
	box-sizing: border-box;
}
/* 门店列表 */
.shopList {
	width: 100%;
}
.shopList .bomm {
	background-color: #FFFFFF;
}
.shopList .up {
	width: 100%;
	display: flex;
	justify-content: space-between;
	padding: 15rpx 30rpx;
	box-sizing: border-box;
	font-size: 26rpx;
	font-family: PingFang SC;
	font-weight: 400;
	color: #9A9A9A;
}
.shopList .up .img{
	width: 50rpx;
	height: 50rpx;
	border-radius: 50%;
	margin-right: 22rpx;
	vertical-align: middle;
}
.shopList .up .butt {
	width: 135rpx;
	height: 50rpx;
	background: #3EA4E1;
	border-radius: 25rpx;
	font-size: 26rpx;
	font-family: PingFang SC;
	font-weight: 400;
	color: #FFFFFF;
	text-align: center;
	line-height: 50rpx;
}
.shopList .down {
	margin-left: 40rpx;
	padding-right: 35rpx;
	border-top: 2rpx solid #F5F5F5;
	display: flex;
	padding-top: 20rpx;
	padding-bottom: 20rpx;
	border-radius: 6rpx;
}
.shopList .down image {
	width: 140rpx;
	height: 140rpx;
	margin-right: 25rpx;
}
.shopList .down .right {
	display: flex;
	flex-direction: column;
	justify-content: space-around;
	flex: 1;
}
.down .right .txt1{
	font-size: 28rpx;
	font-family: PingFang SC;
	font-weight: 400;
	color: #343434;
	height: 80rpx;
	overflow: hidden;
	text-overflow: ellipsis;
	display: -webkit-box;
	-webkit-line-clamp: 2;
	-webkit-box-orient: vertical;
}
.down .right .txt2 {
	font-size: 26rpx;
	font-family: PingFang SC;
	font-weight: 400;
	color: #3EA4E1;
}
</style>
