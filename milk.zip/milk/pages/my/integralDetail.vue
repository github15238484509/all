<!-- 提现记录页面 -->
<template>
	<view v-if="render">
		<view class="" v-if="list.length!=0">
			<view style="width: 100%; height: 20rpx; background-color: #F5F5F5;"></view>
			<view class="list" v-for="(item,i) in list" :key="i" @click="goStatus(item)">
				<view class="left">
					<view class="shang" v-if="item.msg=='提现驳回增加'">{{item.msg}}</view>
					<view class="shang" v-else>{{item.msg}}<text style="color: #999999; margin-left: 10rpx;">({{item.extract_msg}})</text></view>
					<view class="time">{{item.time}}</view>
				</view>
				<view class="right">{{item.type<100?'+':'-'}}{{item.amount/100}}</view>
			</view>
		</view>
		<view class="noData" v-else>
			<image :src="cdnUrl+'bashi/image/nodata.png'"></image>
		</view>
	</view>
</template>
<script>
	import {formatTime} from '@/until/app.js'
	export default {
		data() {
			return {
				page:0,
				pageCount:0,
				render:false,
				list:[],//提现列表
				cdnUrl:'',
			}
		},
		onShareAppMessage: function () {
		    return {
		      title:'乃小星',
		      path: '/pages/index/index?scene=' + '1-'+uni.getStorageSync('phone')
		    }
		},
		methods: {
			// 点击待审核和审核失败的记录调整至审核进度页面
			goStatus(e){
				if(e.extract_msg!="打款完成")
				uni.navigateTo({
					url:'../publicPages/status?type=4'+'&withdrawalStatusIndex='+e.order
				})
			},
			init(){
				let self = this
				self.request({
					url:'bashi/api/app.php?c=userExtractChange',
					data:{
						token:uni.getStorageSync('token'),
						page:self.page
					}
				}).then(res=>{
					if(res.data.success){
						for(var i = 0; i < res.data.data.list.length; i++){
							res.data.data.list[i].time = formatTime(Number(res.data.data.list[i].time))
						}
						// self.list=res.data.data.list
						self.pageCount=res.data.pageCount
						for(var i=0; i<res.data.data.list.length; i++){
							self.list.push(res.data.data.list[i])
						}
						self.render=true
					}
				})
			}
		},
		// 上拉加载(小程序自带函数)
		onReachBottom(){
			if(this.page<this.pageCount-1){
				this.page++
				this.init()
			}
		},
		onShow(){
			this.page=0
			this.list=[]
			this.cdnUrl=this.$cdnUrl
			this.init()
		}
	}
</script>

<style>
	page{
		background-color: #F5F5F5;
	}
</style>
<style lang="scss">
.list {
	padding: 30rpx 0;
	border-bottom: 2rpx solid #F5F5F5;
	display: flex;
	justify-content: space-between;
	align-items: center;
	font-size: 26rpx;
	font-family: PingFang SC;
	background-color: #FFFFFF;
}
.list .left{
	padding-left: 30rpx;
}
.list .left .shang {
	font-weight: 500;
	color: #333333;
}
.list .left .time {
	font-size: 22rpx;
	font-weight: 400;
	color: #999999;
	padding-top: 20rpx;
}
.list .right {
	font-weight: bold;
	color: #FF3636;
	padding-right: 30rpx;
}
.noData{
	text-align: center;
	image{
		width: 360rpx;
		height: 300rpx;
		margin: 100rpx auto;
	}
}
</style>
