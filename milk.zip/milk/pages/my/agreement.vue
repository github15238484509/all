<!-- 查看app相关协议列表 -->
<template>
	<view style="background-color: #fff;">
		<view style="width:100%;height:20rpx;background:rgba(245,245,245,1);"></view>
		<block v-for="(item,i) in list" :key="i">
			<view class="agreement" @click="registerAgreement(item.url)" style="border-bottom: 1rpx solid #f5f5f5;">
				{{item.title}}<image src="../../static/back.png" mode=""></image>
			</view>
		</block>
	</view>
</template>

<script>
	export default{
		data() {
			return {
				list:{},
			}
		},
		onShareAppMessage: function () {
		    return {
		      title:'乃小星',
		      path: '/pages/index/index?scene=' + '1-'+uni.getStorageSync('phone')
		    }
		},
		methods:{
			init(){
				let self = this
				self.request({
					url:'bashi/api/app.php?c=account/proList',
					data:{
						token:uni.getStorageSync('token')
					},
					}).then(res=>{
						self.list = res.data.data.list
					},rej=>{
						console.log(rej)
					})
			},
			registerAgreement(e){
				uni.navigateTo({
					url:'./common?src='+e
				})
			}
		},
		onShow() {
			this.init()
		}
	}
</script>

<style lang="scss">
	page{
		background-color: #f5f5f5;
	}
	.agreement{
		padding: 30rpx;
		font-size:26rpx;
		font-family:PingFang SC;
		font-weight:500;
		color:rgba(51,51,51,1);
		image{
			width:17rpx;
			height:32rpx;
			float: right;
		}
	}
</style>

