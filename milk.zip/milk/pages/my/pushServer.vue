<!-- 消息推送页面 -->
<template>
	<view>
		<view style="padding: 20rpx 0rpx;">
			<view class="userList">
				<view class="">
					派发完毕通知
				</view>
				<view class="" style="padding-right: 20rpx;">
					<switch @change="switch1Change" :checked="value1" :disabled="value1"/>
				</view>
			</view>
			<view class="userList">
				<view class="">
					商品取货提醒
				</view>
				<view class="" style="padding-right: 20rpx;">
					<switch @change="switch2Change" :checked="value2" :disabled="value2"/>
				</view>
			</view>
			<view class="userList">
				<view class="">
					恢复派送通知
				</view>
				<view class="" style="padding-right: 20rpx;">
					<switch @change="switch3Change" :checked="value3" :disabled="value3"/>
				</view>
			</view>
			<view class="userList">
				<view class="">
					暂停派送通知
				</view>
				<view class="" style="padding-right: 20rpx;">
					<switch @change="switch4Change" :checked="value4" :disabled="value4"/>
				</view>
			</view>
			<view class="userList">
				<view class="">
					退款拒绝通知
				</view>
				<view class="" style="padding-right: 20rpx;">
					<switch @change="switch5Change" :checked="value5" :disabled="value5"/>
				</view>
			</view>
			<view class="userList">
				<view class="">
					退款成功通知
				</view>
				<view class="" style="padding-right: 20rpx;">
					<switch @change="switch6Change" :checked="value6" :disabled="value6"/>
				</view>
			</view>
			<!-- <view style="width: 100%; height: 20rpx; background-color: #F5F5F5; padding: 0;"></view>
			<view class="userList" @click="setmessage()">
				<view class="">
					系统内部消息
				</view>
				<view class="" style="padding-right: 20rpx;">
					{{value7}}
				</view>
			</view> -->
		</view>
		<view class="tip" v-if="showTip" @click="cancel">
			<view class="tipImg">
				<image :src="cdnUrl+'bashi/static/tip.png'" mode=""></image>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				userInfo: '',
				cdnUrl: this.$cdnUrl,
				showModel: false,
				baseUrl: '',
				name: '',
				value1: false,
				value2: false,
				value3: false,
				value4: false,
				value5: false,
				value6: false,
				showTip:false,
				// value7:'开启消息提醒',
			}
		},
		onShareAppMessage: function () {
		    return {
		      title:'乃小星',
		      path: '/pages/index/index?scene=' + '1-'+uni.getStorageSync('phone')
		    }
		},

		methods: {
			cancel(){
				this.showTip=false
				if(this.value1){
					this.book1()
				}
				if(this.value2){
					this.book2()
				}
				if(this.value3){
					this.book3()
				}
				if(this.value4){
					this.book4()
				}
				if(this.value5){
					this.book5()
				}
				if(this.value6){
					this.book6()
				}
			},
			// 配送通知
			book1() {
				let self = this
				if (self.value1 == true) {
					uni.requestSubscribeMessage({
						tmplIds: ['62mA4YUA7o7DVgnZLQL-p7ZywxxCgoWZru37vdeTHig'],
						success(res) {
							if (res['62mA4YUA7o7DVgnZLQL-p7ZywxxCgoWZru37vdeTHig'] == 'accept') {
								uni.showToast({
									title: '订阅成功'
								})
								self.getBook()
							}else{
								self.value1=false
							}
						},
						fail(res) {
							uni.showToast({
								icon: 'none',
								title: '取消订阅成功'
							})
							self.value1 == false
							
						}
					})
				}
			},
			book2() {
				let self = this
				if (self.value2 == true ) {
					uni.requestSubscribeMessage({
						tmplIds: ['c6Pb2tIdAeMottCxBovLMy1ut3FwqsQOay5aivVNxws'],
						success(res) {
							if (res['c6Pb2tIdAeMottCxBovLMy1ut3FwqsQOay5aivVNxws'] == 'accept') {
								uni.showToast({
									title: '订阅成功'
								})
								self.getBook()
							}else{
								self.value2=false
							}
						},
						fail(res) {
							uni.showToast({
								icon: 'none',
								title: '取消订阅成功'
							})
							self.value2 = false
						}
					})
				} 
			},
			book3() {
				let self = this
				if (self.value3 == true) {
					uni.requestSubscribeMessage({
						tmplIds: ['R4AkVsRejXqyxjJkVNOTnvZpdtgwf9b_DPF5Z9BFMXg'],
						success(res) {
							if (res['R4AkVsRejXqyxjJkVNOTnvZpdtgwf9b_DPF5Z9BFMXg'] == 'accept') {
								uni.showToast({
									title: '订阅成功'
								})
								self.getBook()
							}else{
								self.value3=false
							}
						},
						fail(res) {
							uni.showToast({
								icon: 'none',
								title: '取消订阅成功'
							})
							self.value3 = false
						}
					})
				} 
			},
			book4() {
				let self = this
				if (self.value4 == true) {
					uni.requestSubscribeMessage({
						tmplIds: ['qYTC7ot2kMMdLj-dnQ_VC7BSeLfeRGn_BhiNymtMnEs'],
						success(res) {
							if (res['qYTC7ot2kMMdLj-dnQ_VC7BSeLfeRGn_BhiNymtMnEs'] == 'accept') {
								uni.showToast({
									title: '订阅成功'
								})
								self.getBook()
							}else{
								self.value4=false
							}
						},
						fail(res) {
							uni.showToast({
								icon: 'none',
								title: '取消订阅成功'
							})
							self.value4 = false
						}
					})
				} 
			},
			book5() {
				let self = this
				if (self.value5 == true) {
					uni.requestSubscribeMessage({
						tmplIds: ['YcZ8Sal8biDIp3TL-IZe1G7w20kC4W239wr4pAvtyZI'],
						success(res) {
							if (res['YcZ8Sal8biDIp3TL-IZe1G7w20kC4W239wr4pAvtyZI'] == 'accept') {
								uni.showToast({
									title: '订阅成功'
								})
								self.getBook()
							}else{
								self.value5=false
							}
						},
						fail(res) {
							uni.showToast({
								icon: 'none',
								title: '取消订阅成功'
							})
							self.value5 = false
						}
					})
				} 
			},
			book6() {
				let self = this
				if (self.value6 == true) {
					uni.requestSubscribeMessage({
						tmplIds: ['kQHDjrEHClEK93itZFpLZqX0EBaXS28-TW8nbMFxEic'],
						success(res) {
							if (res['kQHDjrEHClEK93itZFpLZqX0EBaXS28-TW8nbMFxEic'] == 'accept') {
								uni.showToast({
									title: '订阅成功'
								})
								self.getBook()
							}else{
								self.value6=false
							}
						},
						fail(res) {
							uni.showToast({
								icon: 'none',
								title: '取消订阅成功'
							})
							self.value6 = false
						}
					})
				} 
			},
			// 打开消息通知
			setmessage(e){
				let self = this
						self.request({
							url: "bashi/api/app.php?c=setMessage",
							data: {
								token: uni.getStorageSync('token'),
								type:1,
							},
						}).then(res => {
							if (res.data.success) {
							// 	uni.showToast({
							// 		icon:'none',
							// 		title: res.data.msg
							// 	})
							// 	self.value7="关闭消息提醒"
							}
						})
					
			},
			getBook() {
				let self = this
				uni.getSetting({
					withSubscriptions: true,
					success(res) {
						var itemSettings = res.subscriptionsSetting.itemSettings;
						if (itemSettings) {
							if (itemSettings['62mA4YUA7o7DVgnZLQL-p7ZywxxCgoWZru37vdeTHig'] == 'accept') {
								self.value1 = true
							}
							if (itemSettings['c6Pb2tIdAeMottCxBovLMy1ut3FwqsQOay5aivVNxws'] == 'accept') {
								self.value2 = true
							}
							if (itemSettings['R4AkVsRejXqyxjJkVNOTnvZpdtgwf9b_DPF5Z9BFMXg'] == 'accept') {
								self.value3 = true
							}
							if (itemSettings['qYTC7ot2kMMdLj-dnQ_VC7BSeLfeRGn_BhiNymtMnEs'] == 'accept') {
								self.value4 = true
							}
							if (itemSettings['YcZ8Sal8biDIp3TL-IZe1G7w20kC4W239wr4pAvtyZI'] == 'accept') {
								self.value5 = true
							}
							if (itemSettings['kQHDjrEHClEK93itZFpLZqX0EBaXS28-TW8nbMFxEic'] == 'accept') {
								self.value6 = true
							}
						}
					}
				})
			},
			switch1Change: function (e) {
				this.value1=e.target.value
				if(e.target.value){
					this.showTip=true
				}
			},
			switch2Change: function (e) {
				this.value2=e.target.value
				if(e.target.value){
					this.showTip=true
				}
			},
			switch3Change: function (e) {
				this.value3=e.target.value
				if(e.target.value){
					this.showTip=true
				}
			},
			switch4Change: function (e) {
				this.value4=e.target.value
				if(e.target.value){
					this.showTip=true
				}
			},
			switch5Change: function (e) {
				this.value5=e.target.value
				if(e.target.value){
					this.showTip=true
				}
			},
			switch6Change: function (e) {
				this.value6=e.target.value
				if(e.target.value){
					this.showTip=true
				}
			},
		},
		onShow() {
			console.log(this.$cdnUrl)
			this.getBook()
			this.setmessage()
		},
	}
</script>

<style lang="scss">
page {
		padding-bottom: 150rpx;
	}
	.tip{
		width: 100%;
		height: 100%;
		background-color: rgba(0,0,0,.5);
		position: fixed;
		top: 0;
		left: 0;
		.tipImg{
			width: 600rpx;
			height: 560rpx;
			position: absolute;
			top: 50%;
			left: 50%;
			transform: translate(-50%,-50%);
			image{
				width: 100%;
				height: 100%;
			}
		}
	}
	.userList {
		display: flex;
		padding: 30rpx;
		justify-content: space-between;
		border-bottom: 1rpx solid #f5f5f5;
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #333333;

		image {
			width: 80rpx;
			height: 80rpx;
			border-radius: 50%;
			vertical-align: middle;
		}
	}
</style>
