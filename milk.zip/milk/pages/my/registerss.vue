<!-- 欢迎注册页面 --> 
<template>
	<view>
		<view style="margin: 0 40rpx;">
			<view class="tit">欢迎注册</view>
			<view>
				<view class="hang1" @click="siteoption">
					<image src="../../static/site1.png" class="image1"></image>
					<text v-if="chooseAddress">{{chooseAddress}}</text>
					<text v-else>请输入地址</text>
					<image src="../../static/back.png"  class="image2"></image>
				</view>
				<view class="inp1">
					<image src="../../static/site2.png"></image>
					<input placeholder="如所在地区为乡镇请如实填写" @input="site2"/>
				</view>
				<view class="inp">
					<image src="../../static/pop.png"></image>
					<input placeholder="请输入邀请人手机号" type="number" maxlength="11" v-model="referrer_phone" @input="referr"/>
				</view>
				<view class="yaoqing">
					<view class="txt">邀请人信息</view>
					<image :src="cdnUrl+photo"></image>
					{{name}}
				</view>
			</view>
			<view class="butt" @click="zuce()">注册</view>
		</view>
		
		<!-- 地址弹窗 -->
		<view class="citys" v-if="showCity">
			<view class="city">
				<view class="city_top">
					<view class="city_tabs">
						<block v-for="(item,i) in tabs" :key="i">
							<view :class="[i==currentTab?'txt':'']">
								{{item.name}}
								<view class="tip" v-if="currentTab==i"></view>
							</view>
						</block>
					</view>
					<view class="city_sure" @click="sure">
						确定
					</view>
				</view>
				
				<view class="srcoll_options">
					<scroll-view scroll-y="true"  style="width:40%">
						<!-- <block v-for="(item,i) in provinceList" :key="i"> -->
							<view class="txt" @click="getProvinceIndex()">
								<!-- {{item.region_name}} -->河南
							</view>
						<!-- </block> -->
					</scroll-view>
					<scroll-view scroll-y="true" >
						<block v-for="(item,i) in cityList" :key="i">
							<view :class="[item.region_id==cityIndex?'txt':'']" @click="getCityIndex(item.region_id,item.region_name)">
								{{item.region_name}}
							</view>
						</block>
					</scroll-view>
					<scroll-view scroll-y="true" >
						<block v-for="(item,i) in countryList" :key="i">
							<view :class="[item.region_id==countyIndex?'txt':'']" @click="getCountyIndex(item.region_id,item.region_name)">
								{{item.region_name}}
							</view>
						</block>
					</scroll-view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				showCity:false,
				cdnUrl:'',
				phoneNumber:'',
				unionid:'',
				openid:'',
				sex:'',
				nickName:'',
				avatarUrl:'',
				referrer_phone:'',
				name:'',
				photo:'',
				// 省/市/区=>id
				tabs:[
					{name:'省份'},
					{name:'城市'},
					{name:'区县'}
				],
				currentTab:'0',
				provinceList:[],//省列表
				cityList:[],//市列表
				countryList:[],//区列表
				provinceIndex:'11',
				cityIndex:'-1',
				countyIndex:'-1',
				provinceName:'',//省名字
				cityName:'',//市名字
				countryName:'',//区名字
				chooseAddress:'',//拼接地址结果
				site:'',//详细地址
			}
		},
		onShareAppMessage: function () {
		    return {
		      title:'乃小星',
		      path: '/pages/index/index?scene=' + '1-'+uni.getStorageSync('phone')
		    }
		},
		methods: {
			siteoption(){
				this.showCity=true
				// this.getAddress()
			},
			// 详细地址
			site2(e) {
				this.site = e.detail.value;
			},
			// 邀请人手机号
			referr(e){
				let self=this
				if (self.referrer_phone.length==11){
					// 判断输入的手机号做完正则表达是否还是11位
					if(/^1[0-9]{10}$/.test(self.referrer_phone)){
						self.request({
							url:'bashi/api/app.php?c=account/checkPhone',
							data:{
								referrer_phone:self.referrer_phone,
								phone:self.phoneNumber
							}
						}).then(res=>{
							if(res.data.success){
								if(res.data.cmd='popup_to_login'){
									self.photo=res.data.data.photo
									self.name=res.data.data.name
								}else{
									uni.showToast({
									icon:'none',
									title: '未找到',
									});
								}
							}else{
								if(res.data.cmd='no_tuiguang'){
									self.photo=res.data.data.photo
									self.name=res.data.data.name
								}	
								uni.showToast({
									icon:'none',
									title: res.data.msg
								});
							}
						},rej=>{
							uni.showToast({
								icon:'none',
								title: res.data.msg
							});
						})
						// 如果手机号正则判断完手机号不为11位就提示输入正确的手机号
					}else{
							uni.showToast({
								icon:'none',
								title: '请输入正确的手机号',
								duration: 2000
							});
					}
				}else{
					
				}
			},
			// 注册
			zuce(){
				let that=this
				if(that.countyIndex == -1){
					uni.showToast({
						icon:'none',
						title:'请选择地址'
					})
				// }else if(that.site==''){
				// 	uni.showToast({
				// 		icon:'none',
				// 		title:'请输入详细地址'
				// 	})
				}else{
					that.request({
						url:"bashi/api/app.php?c=account/register",
						data:{
							unionid: that.unionid,
							phone:that.phoneNumber,
							wechat_openid:that.openid,
							nickname: that.nickName,
							headimgurl: that.avatarUrl,
							referrer_phone:that.referrer_phone,
							province:that.provinceIndex,
							city:that.cityIndex,
							district:that.countyIndex,
							address:that.site,
						}
					}).then(res=>{
						if(res.data.success){
								uni.setStorageSync("token", res.data.data.token)
								uni.setStorageSync("phone", that.phoneNumber)
								uni.navigateBack({
									delta:2
								})
							}else{
								uni.showToast({
									icon:'none',
									title:res.data.msg
								})
							}
						},rej=>{
						// 打印日志或者弹窗提示
					})
				}
			},
			// //获取省列表
			// getAddress(){
			// 	this.showCity=true
			// 	this.currentTab='0'
			// 	let self = this
			// 	self.request({
			// 		url: 'bashi/api/app.php?c=personal/getProvinceList'
			// 	}).then(res => {
			// 		if (res.data.success) {
			// 			// self.provinceList = res.data.data.list
			// 			self.provinceList = res.data.data.list
			// 		}
			// 	});
			// },
			//点击省获取市列表
			getProvinceIndex(e,name){
				this.provinceIndex=11
				this.provinceName='河南'
				this.cityName=''
				this.countryName=''
				this.currentTab='0'
				let self = this
				self.request({
					url: 'bashi/api/app.php?c=personal/getCityList',
					data:{
						province_id:11
					}
				}).then(res => {
					if (res.data.success) {
						self.cityList = res.data.data.list
						self.countryList=[]
					}
				});
			},
			//点击市获取区列表
			getCityIndex(e,name){
				this.cityIndex=e
				this.cityName=name
				this.countryName=''
				this.currentTab='1'
				let self = this
				self.request({
					url: 'bashi/api/app.php?c=personal/getCountryList',
					data:{
						city_id:e
					}
				}).then(res => {
					if (res.data.success) {
						self.countryList = res.data.data.list
					}
				});
			},
			//获取点击的区
			getCountyIndex(e,name){
				this.countyIndex=e
				this.countryName=name
				this.currentTab='2'
			},
			sure(){
				this.showCity=false;
				this.chooseAddress=this.provinceName+this.cityName+this.countryName;
			},
		},
		onLoad(options) {
			this.cdnUrl=this.$cdnUrl
			this.phoneNumber=options.phone
			if (options.referrer_phone)this.referrer_phone=options.referrer_phone
			this.unionid=options.unionid
			this.sex=options.sex
			this.openid=options.wechat_openid
			this.nickName=options.nickname
			this.avatarUrl=options.headimgurl
			console.log(this.referrer_phone)
			if(this.referrer_phone!=''){
				this.referr()
			}
		}
	}
</script>

<style lang="scss">
page {
	position: relative;
	height: 100%;
}
.tit{
	font-family: Source Han Sans CN;
	font-weight: 700;
	font-size: 70rpx;
	margin-top: 50rpx;
	margin-bottom: 150rpx;
}
.hang1 {
	width: 560rpx;
	position: relative;
	border-bottom: 1rpx solid #F5F5F5;
	height: 90rpx;
	line-height: 90rpx;
	padding-left: 60rpx;
	color: #999999;
}
.hang1 .image1 {
	position: absolute;
	left: 0;
	top: 30rpx;
	width: 36rpx;
	height: 36rpx;
}
.hang1 .image2 {
	position: absolute;
	right: 0;
	top: 30rpx;
	width: 17rpx;
	height: 32rpx;
}
.inp1 input {
	width: 560rpx;
	position: relative;
	border-bottom: 1rpx solid #F5F5F5;
	height: 90rpx;
	line-height: 90rpx;
	padding-left: 60rpx;
}
.inp1 image {
	position: absolute;
	left: 40rpx;
	top: 360rpx;
	width: 38rpx;
	height: 38rpx;
}
.inp input {
	width: 560rpx;
	position: relative;
	border-bottom: 1rpx solid #F5F5F5;
	height: 90rpx;
	line-height: 90rpx;
	padding-left: 60rpx;
}
.inp image {
	position: absolute;
	left: 40rpx;
	top: 450rpx;
	width: 38rpx;
	height: 38rpx;
}
.yaoqing {
	font-size: 30rpx;
	font-family: PingFang SC;
	font-weight: 400;
	color: #999999;
}
.yaoqing .txt {
	margin: 20rpx 0;
	font-size: 26rpx;
}
.yaoqing image {
	width: 100rpx;
	height: 100rpx;
	vertical-align: middle;
	margin-right: 20rpx;
	border-radius: 50%;
}
.butt {
	position: absolute;
	left: 30rpx;
	bottom: 200rpx;
	width: 690rpx;
	height: 90rpx;
	background: #3DA3E1;
	border-radius: 45rpx;
	font-size: 30rpx;
	font-family: PingFang SC;
	font-weight: 500;
	color: #FFFFFF;
	line-height: 90rpx;
	text-align: center;
}
/* 地址 */
.citys{
	z-index: 111;
	width: 100%;
	height: 100%;
	background-color: rgba(0,0,0,.3);
	position: fixed;
	top: 0;
	left: 0;
	.city{
		width: 100%;
		height: 700rpx;
		background: #FFFFFF;
		position: absolute;
		left: 0;
		bottom: 0;
		.city_top{
			width: 100%;
			height: 88rpx;
			border-bottom: 2rpx solid #e7e7e7;
			display: flex;
			justify-content: space-between;
			.city_sure{
				width: 130rpx;
				height: 88rpx;
				line-height: 88rpx;
				text-align: center;
				font-size: 26rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: #3FA2E4;
			}
			.city_tabs{
				display: flex;
				view{
					padding: 0 40rpx;
					height: 88rpx;
					line-height: 88rpx;
					position: relative;
					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 500;
					color: #999999;
					.tip{
						padding: 0;
						width: 56rpx;
						height: 2rpx;
						background: #3FA2E4;
						position: absolute;
						bottom: 0;
						left: 50%;
						transform: translateX(-50%);
					}
				}
				.txt{
					color: #333!important;
					font-weight: 500!important;
				}
			}
		}
		.srcoll_options{
			height: 600rpx;
			display: flex;
			scroll-view{
				view{
					text-align: center;
					height: 70rpx;
					line-height: 70rpx;
				}
				.txt{
					color: #3FA2E4;
				}
			}
		}
	}
}
</style>

