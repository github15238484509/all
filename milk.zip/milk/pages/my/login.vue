<!-- 授权登录页面 -->
<template>
	<view class="">
		<view class="img">
			<image class='i-logo' :src="logo"></image>
		</view>
		<view class="word word1">{{company.company_name}}</view>
		<view class="word word2">申请获取你的公开信息（昵称、头像等）</view>
		<button class="btn" v-if="show" style="margin-top:100rpx;" @click="$u.throttle(getUserInfo,1000)">微信授权</button>
		<button class="btn" v-else style="margin-top:100rpx;" open-type="getPhoneNumber" @getphonenumber="getPhoneNumber">微信用户快捷登录</button>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				show: true,
				code: '',
				openid: '',
				session_key: '',
				phoneNumber: '',
				sex: '',
				userInfo: {},
				url: '',
				logo: '',
				unionid: '',
				referrer_phone: ''
			}
		},
		methods: {
			init() {
				let self = this
				uni.login({
					success: res => {
						// 发送 res.code 到后台换取 openId, sessionKey, unionId
						self.code = res.code;
						self.getOpenId()
						self.getUserInfo()
					}
				})
			},
			//获取openId
			getOpenId() {
				var that = this
				that.request({
					url: 'bashi/api/app.php?c=account/getOpenId',
					data: {
						code: that.code,
					}
				}).then(res => {
					// console.log(res)
					if (res.data.data.unionid) {
						that.unionid = res.data.data.unionid
					} else {
						that.unionid = ''
					}
					that.openid = res.data.data.openid;
					that.session_key = res.data.data.session_key
				}, rej => {
					// 打印日志或者弹窗提示
					console.log(rej)
				})
			},
			// 判断是否授权
			getUserInfo() {
				wx.getUserProfile({
					desc: '用于完善会员资料',
					success: (res) => {
						this.show=false
						// 可以将 res 发送给后台解码出 unionId
						this.userInfo = res.userInfo
						if (this.userInfo.gender == 1) {
							this.sex = '男'
						} else {
							this.sex = '女'
						}
					},
					fail:(res)=>{
						// uni.showToast({
						// 	title:"授权失败",
						// 	icon:"none"
						// })
					}
				})
			},
			//调用获取用户手机号
			getPhoneNumber(e) {
				if(e.detail.errMsg=='getPhoneNumber:ok'){
					var encryptedData = e.detail.encryptedData;
					var iv = e.detail.iv;
					this.getWechatPhone(encryptedData, iv);
				}
			},
			//获取用户手机号
			getWechatPhone(encryptedData, iv) {
				let that = this;
				that.request({
					url: 'bashi/api/app.php?c=account/getCryptPhone',
					data: {
						sessionKey: that.session_key,
						encryptedData: encryptedData,
						iv: iv
					}
				}).then(res => {
					that.phoneNumber = res.data.data.phoneNumber
					that.checkPhone()
				}, rej => {
					// 打印日志或者弹窗提示
				})
			},
			//检测手机号是否注册过
			checkPhone() {
				let that = this;
				that.request({
					url: 'bashi/api/app.php?c=account/checkPhone',
					data: {
						phone: that.phoneNumber
					}
				}).then(res => {
					// register 未注册过
					if (res.data.cmd == 'register') {
						// if (that.referrer_phone) {
						// 	that.url = 'bashi/api/app.php?c=account/register'
						// 	that.register()
						// } else {
							uni.navigateTo({
								url: `./registerss?phone=${that.phoneNumber}&referrer_phone=${that.referrer_phone}&unionid=${that.unionid}&wechat_openid=${that.openid}&sex=${that.sex}&nickname=${that.userInfo.nickName}&headimgurl=${that.userInfo.avatarUrl}`
							})
						// }
					} else {
						that.url = 'bashi/api/app.php?c=account/login'
						that.register()
					}
				}, rej => {
					// 打印日志或者弹窗提示
				})
			},
			//用户授权登录
			register() {
				let that = this;
				that.request({
					url: that.url,
					data: {
						unionid: that.unionid,
						phone: that.phoneNumber,
						wechat_openid: that.openid,
						sex: that.sex,
						nickname: that.userInfo.nickName,
						headimgurl: that.userInfo.avatarUrl,
						referrer_phone: that.referrer_phone,
						app_type: 3,
					}
				}).then(res => {
					if (res.data.success) {
						uni.removeStorageSync('scene')
						uni.setStorageSync("token", res.data.data.token)
						uni.setStorageSync("phone", that.phoneNumber)
						uni.setStorageSync('accountOrder',res.data.data.order)
						uni.setStorageSync('accountStatus',res.data.data.status)
						uni.switchTab({
							url:'/pages/index/index'
						})
					} else {
						uni.showToast({
							icon: 'none',
							title: res.data.msg
						})
					}
				}, rej => {
					console.log("rej",rej)
					// 打印日志或者弹窗提示
				})
			},
			// 登录时的关于我们
			getLogo() {
				let that = this;
				that.request({
					url: 'bashi/api/app.php?c=account/appConfig'
				}).then(res => {
					that.logo = that.$cdnUrl + res.data.platform_logo
				}, rej => {
					// 打印日志或者弹窗提示 
					console.log(rej)
				})
			}
		},
		mounted() {
			this.init()
			this.getLogo()
		},
		onLoad(e) {
			if (e.scene) {
				this.referrer_phone = e.scene
			}
		}
	}
</script>

<style>
	.img {
		padding: 100rpx 0;
		text-align: center;
	}

	image {
		width: 150rpx;
		height: 150rpx;
		border-radius: 15rpx;
		box-shadow: 0px 0px 32px 0px rgba(166, 166, 166, 0.3);
	}

	.word {
		text-align: center;
	}

	.word1 {
		font-size: 36rpx;
		font-family: PingFang SC;
		font-weight: bold;
		color: rgba(51, 51, 51, 1);
		line-height: 66rpx;
	}

	.word2 {
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: rgba(153, 153, 153, 1);
		line-height: 66rpx;
	}

	.btn {
		width: 690rpx !important;
		height: 90rpx;
		line-height: 90rpx;
		color: #fff;
		background: #008B4D;
		border-radius: 10rpx;
		padding: 0 !important;
		margin-top: 50rpx;
	}
</style>
