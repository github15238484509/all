<!-- 余额明细页面 -->
<template>
	<view>
		<view class="all">
			<view class="all_word" @click="getTypes">
				{{typeWord}}<image src="/static/down.png" mode=""></image>
			</view>
		</view>
		<view class="" v-if="list.length!=0">
			
			<view class="list" v-for="(item,i) in list" :key="i">
				<view class="left">
					<view class="shang" v-if="item.msg=='预定'">{{item.msg}} ({{item.text}})</view>
					<view class="shang" v-else-if="item.msg=='提现扣减'">{{item.msg}}<text style="color: #999999;margin-left: 10rpx;">({{item.extract_msg}})</text></view>
					<view class="shang" v-else>{{item.msg}}</view>
					<view class="time">{{item.time}}</view>
				</view>
				<view class="right">{{item.type<100?'+':'-'}}{{item.amount/100}}</view>
			</view>
		</view>
		<view class="noData" v-else>
			<image :src="cdnUrl+'bashi/image/nodata.png'"></image>
		</view>
		
		<view class="showModel" v-if="show">
			<view class="model">
				<block v-for="(item,i) in typeList" :key="i">
					<view class="all_word" @click="getType(item.name,item.type)">
						{{item.name}}<image src="/static/down.png" v-if="i==0"></image>
					</view>
				</block>
			</view>
		</view>
	</view>
</template>

<script>
	import {formatTime} from '@/until/app.js'
	export default {
		data() {
			return {
				page:0,
				pageCount:'',//总页数
				list:[],//提现列表
				show:false,
				typeList:[
					{name:'全部',type:''},
					{name:'提现',type:'104'},
					{name:'预定',type:'101'},
					{name:'分红',type:'19'},
					{name:'门店津贴',type:'2'},
					{name:'优惠',type:'1'},
					{name:'退款',type:'18'},
					
				],
				type:'',
				typeWord:'全部',
				cdnUrl:'',
			}
		},
		onShareAppMessage: function () {
		    return {
		      title:'乃小星',
		      path: '/pages/index/index?scene=' + '1-'+uni.getStorageSync('phone')
		    }
		},
		methods: {
			init(){
				let self = this
				self.request({
					url:'bashi/api/app.php?c=userCashChange',
					data:{
						token:uni.getStorageSync('token'),
						page:self.page,
						type:self.type
					}
				}).then(res=>{
					if(res.data.success){
						for(var i = 0; i < res.data.data.list.length; i++){
							res.data.data.list[i].time = formatTime(Number(res.data.data.list[i].time))
						}
						// self.list=res.data.data.list
						self.pageCount=res.data.pageCount
						for(var i=0; i<res.data.data.list.length; i++){
							self.list.push(res.data.data.list[i])
						}
						// console.log(self.list);
					}
				})
			},
			getTypes(){
				this.show=true
			},
			getType(name,type){
				this.show=false
				this.type=type
				this.typeWord=name
				this.page=0
				this.list=[]
				this.init()
			}
		},
		// 上拉加载(小程序自带函数)
		onReachBottom(){
			if(this.page<this.pageCount-1){
				this.page++
				this.init()
			}
		},
		onShow(){
			this.init()
			this.page=0
			this.list=[]
			this.cdnUrl=this.$cdnUrl
		}
	}
</script>

<style lang="scss">
	page{
		padding-top: 100rpx;
	}
.list {
	padding: 30rpx 0;
	border-bottom: 1rpx solid #F5F5F5;
	display: flex;
	justify-content: space-between;
	align-items: center;
	font-size: 26rpx;
	font-family: PingFang SC;
	margin-bottom: 100rpx;
	margin: -1rpx;
}
.list .left{
	padding-left: 30rpx;
}
.list .left .shang {
	font-weight: 500;
	color: #333333;
}
.list .left .time {
	font-size: 22rpx;
	font-weight: 400;
	color: #999999;
	padding-top: 20rpx;
}
.list .right {
	font-weight: bold;
	color: #FF3636;
	padding-right: 30rpx;
}
.noData{
	text-align: center;
	image{
		width: 360rpx;
		height: 300rpx;
		margin: 100rpx auto;
	}
}
.all{
	width: 100%;
	height: 100rpx;
	padding: 20rpx 0;
	background-color: #f5f5f5;
	position: fixed;
	top: 0;
	left: 0;
	.all_word{
		width: 180rpx;
		height: 60rpx;
		line-height: 60rpx;
		text-align: center;
		background: #FFFFFF;
		border-radius: 10rpx;
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #333333;
		float: right;
		margin-right: 20rpx;
		image{
			width: 20rpx;
			height: 20rpx;
			margin-left: 10rpx;
		}
	}
}
.showModel{
	width: 100%;
	height: 100%;
	position: fixed;
	top: 0;
	left: 0;
	background-color: rgba(0,0,0,.5);
	.model{
		width: 200rpx;
		height: 370rpx;
		background: #FFFFFF;
		border-radius: 10rpx;
		position: absolute;
		top: 20rpx;
		right: 20rpx;
		.all_word{
			height: 60rpx;
			line-height: 60rpx;
			text-align: center;
			background: #FFFFFF;
			// border-radius: 10rpx;
			font-size: 26rpx;
			font-family: PingFang SC;
			font-weight: 500;
			color: #333333;
			border-bottom: 1rpx solid #f5f5f5;
			image{
				width: 20rpx;
				height: 20rpx;
				margin-left: 10rpx;
			}
		}
	}
}
</style>
