<!-- 我的团队 --> 
<template>
	<view v-if="showlogin">
		<!-- 头部 -->
		<view class="top">
			<!-- 人气总指数 -->
			<view class="up">
				<view class="txt1">{{allLsit.personal_num?allLsit.personal_num:0}}</view>
				<view class="txt2">人气总指数</view>
				<!-- <view class="txt3">
					<view class="chang"></view> 
					<view class="zheng"></view> 
					<text class="txt4" v-if="allLsit.cha>0">相比上个月：<text class="text">+{{allLsit.cha?allLsit.cha:0}}</text></text>
					<text class="txt4">相比上个月：<text class="text">{{allLsit.cha?allLsit.cha:0}}</text></text>
				</view> -->
			</view>
			<!-- 指数 -->
			<view class="down">
				<view class="left">
					<view class="txt4">{{allLsit.hero_num?allLsit.hero_num:0}}</view>
					<view class="txt5">有效指数</view>
				</view>
				<view class="lien"></view>
				<view class="left">
					<view class="txt4">{{allLsit.union_num?allLsit.union_num:0}}</view>
					<view class="txt5">无效指数</view>
				</view>
			</view>
			<!-- 邀请人 -->
			<view class="inviter">
				<view class="left">
					<view class="txt4">{{allLsit.simple_num?allLsit.simple_num:0}}</view>
					<view class="txt5">个人指数</view>
				</view>
				<view class="lien"></view>
				<view class="left">
					<view class="leftimg" @click="gettel(allLsit.ref_phone)">
						<view class="txt4">{{allLsit.ref_phone?allLsit.ref_phone:"暂无"}}</view>
						<image src="../../static/tel.png" v-if="allLsit.ref_phone"></image>
					</view>
					<view class="txt5">邀请人</view>
				</view>
			</view>
		</view>
		<!-- 底部 -->
		<view class="foot">
			<!-- 搜索 -->
			<view class="search">
				<image src="../../static/search(1).png"></image>
				<input placeholder="请输入手机号搜索下级成员" value="" @input="getValue"/>
				<view class="txt"  @click="gosearch()">搜索</view>
			</view>
			<!-- 下级信息 -->
			<view class="xinxi" v-if="timelist.length!=0" v-for="(item,i) in timelist" :key="i">
				<view class="shang">
					<view class="left">
						<image :src="cdnUrl+item.photo"></image>
						<view class="txt">
							<view class="phnoe" @click="gettel(item.phone)">{{item.phone}}<image src="../../static/tel.png"></image></view>
							<image :src="cdnUrl+'bashi/image/grade1.png'" v-if="item.rank==0&&item.pay_order==false"></image>
							<image src="../../static/grade.png" v-if="item.rank==0&&item.pay_order==true"></image>
							<image :src="cdnUrl+'bashi/image/grade2.png'" v-if="item.rank==1"></image>
							<image :src="cdnUrl+'bashi/image/grade3.png'" v-if="item.rank==2"></image>
							<image :src="cdnUrl+'bashi/image/grade4.png'" v-if="item.rank==3"></image>
							<image :src="cdnUrl+'bashi/image/grade5.png'" v-if="item.rank==4"></image>
						</view>
					</view>
					<view class="zhishu">人气指数:{{item.hero_num}}/{{item.union_num}}</view>
				</view>
				<view class="xia">
					<view class="left">
						<view>消费金额：{{item.total_out_cash/100}}</view>
						<view style="padding-top: 25rpx;">累计优惠：{{item.total_income/100}}</view>
					</view>
					<view class="lien"></view>
					<view class="left">
						<view>今日待领取：{{item.today_num}}</view>
						<view style="padding-top: 25rpx;">剩余待领：{{item.res_total_num}}</view>
					</view>
				</view>
			</view>
			<view class="nomore" v-else>没有更多了~</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				showlogin:false,//判断是否登录
				grade:'0',// 会员等级
				allLsit:[],//data中所有数据的集合
				timelist:[],//list对象集合
				cdnUrl:'',
				page:0,//分页
				pageCount:0,//总页数
				keywords:'',//关键字
			}
		},
		onShareAppMessage: function () {
		    return {
		      title:'乃小星',
		      path: '/pages/index/index?scene=' + '1-'+uni.getStorageSync('phone')
		    }
		},
		methods: {
			// init初始化
			init(){
				if(uni.getStorageSync('token')){
					let self=this
					let data={}
					if(self.keywords==''){
						data={
							token:uni.getStorageSync('token'),
							page:self.page ,//分页
						}
					}else{
						data={
							token:uni.getStorageSync('token'),
							page:self.page ,//分页
							keywords:self.keywords,//关键词
						}
					}
					uni.showLoading({
					    title: '加载中'
					});
					self.request({
						url:'bashi/api/app.php?c=reserve/myTeam',
						data:data
					}).then(res=>{
						if(res.data.success){
							uni.hideLoading()
							self.showlogin=true;
							self.pageCount = res.data.pageCount
							self.allLsit=res.data.data //data中所有数据的集合
							for(var i = 0; i < res.data.data.list.length ; i++){
								self.timelist.push(res.data.data.list[i])
							}
							if(res.data.data.list.length==0){
								uni.showToast({
									icon:'none',
									title:'暂无此下级成员~'
								})
							}
						}else{
							uni.showToast({
								icon:'none',
								title:res.data.msg
							})
						}
					},rej=>{
						console.log(rej)
					})
				}else{
					uni.redirectTo({
						url:'../my/login'
					})
				}
			},
			// 拨打电话
			gettel(e){
				uni.makePhoneCall({
				    phoneNumber: e 
				});
			},
			getValue(e){
				this.keywords=e.detail.value
			},
			// 搜索
			gosearch(){
				this.page=0
				this.pageCount=0
				this.timelist=[]
				this.init()
			},
		},
		// 上拉加载(小程序自带函数)
		onReachBottom(){
			if(this.page<this.pageCount-1){
				this.page++
				this.init()
			}
		},
		onShow() {
			this.cdnUrl=this.$cdnUrl
			this.page=0
			this.pageCount=0
			this.keywords=''
			this.timelist=[]
			this.init()
		},
		onLoad(options) {
			
		}
	}
</script>

<style>
.top {
	width: 750rpx;
	height: 400rpx;
	background: linear-gradient(0deg, #40A2E0, #97D7FF);
	position: relative;
}
.top .up {
	font-family: PingFang SC;
	color: #FFFFFF;
	padding-top: 30rpx;
	text-align: center;
}
.top .up .txt1 {
	font-size: 56rpx;
	font-weight: bold;
}
.top .up .txt2 {
	font-size: 26rpx;
	font-weight: 400;
	padding: 20rpx 0;
}
.top .up .txt3 {
	position: absolute;
	left: 50%;
	top: 55%;
	transform: translate(-50%,-55%);
}
.top .up .txt3 .chang {
	width: 300rpx;
	height: 80rpx;
	background: #F5F5F5;
	opacity: 0.5;
	border-radius: 10px;
	z-index: 1;
}
.top .up .txt3 .zheng {
	width:0;
	height:0;
	border-right:20rpx solid transparent;
	border-left:20rpx solid transparent;
	border-bottom:20rpx solid rgba(245,245,245,.5);
	position: absolute;
	left: 50%;
	top: -20rpx;
	transform: translateX(-50%);
}
.top .up .txt3 .txt4 {
	display: inline-block;
	padding: 0 30rpx;
	width: 300rpx;
	line-height: 80rpx;
	position: absolute;
	left: 50%;
	top: 0rpx;
	transform: translateX(-50%);
	font-size: 22rpx;
	font-family: PingFang SC;
	font-weight: 400;
	color: #FEFFFF;
}
.top .up .txt3 .txt4 .text {
	font-size: 36rpx;
	font-weight: 500;
}
.top .down {
	display: flex;
	font-size: 26rpx;
	font-family: PingFang SC;
	font-weight: 400;
	color: #FFFFFF;
	justify-content: space-between;
	padding: 30rpx 140rpx;
}
.top .down .lien {
	width: 2rpx;
	height: 50rpx;
	background: #FFFFFF;
	opacity: 0.5;
	margin: 20rpx 0;
}
.top .down .left {
	text-align: center;
}
.top .down .txt4 {
	font-size: 36rpx;
	font-weight: 500;
}
.top .inviter {
	position: absolute;
	left: 30rpx;
	top: 327rpx;
	width: 690rpx;
	height: 150rpx;
	background: #FFFFFF;
	border-radius: 10rpx;
	font-size: 26rpx;
	font-family: PingFang SC;
	font-weight: 400;
	color: #333333;
	display: flex;
	justify-content: space-between;
	padding: 0rpx 30rpx 0 115rpx;
	box-sizing: border-box;
	border: 4rpx solid rgba(158,158,158,.1);
}
.top .inviter .lien {
	width: 2rpx;
	height: 50rpx;
	background: #CCCCCC;
	border-radius: 1px;
	position: absolute;
	left: 345rpx;
	top: 50rpx;
}
.top .inviter .left {
	text-align: center;
	line-height: 50rpx;
	padding-top: 20rpx;
}
.top .inviter .left .leftimg {
	display: flex;
	justify-content: center;
}
.top .inviter .left .leftimg image{
	width: 28rpx;
	height: 34rpx;
	margin-left: 25rpx;
}
.top .inviter .txt4 {
	font-size: 36rpx;
	font-weight: 500;
}
/* 底部foot */
.foot {
	width: 690rpx;
	background: #FFFFFF;
	border-radius: 10rpx;
	border: 4rpx solid rgba(158,158,158,.1);
	margin: 100rpx 30rpx 0;
}
.foot .search {
	margin: 10rpx 10rpx 10rpx 20rpx;
	display: flex;
	position: relative;
	align-items: center;
	font-size: 30rpx;
	font-family: Source Han Sans CN;
	font-weight: 400;
	color: #333333;
}
.foot .search image {
	width: 29rpx;
	height: 29rpx;
	position: absolute;
	top: 30rpx;
	left: 30rpx;
}
.foot .search input {
	width: 520rpx;
	background: #F5F5F5;
	border-radius: 40rpx;
	padding: 20rpx 0 25rpx 60rpx ;
	margin-right: 10rpx;
}
.foot .xinxi {
	border-top: 2rpx solid #F5F5F5;
	border-bottom: 2rpx solid #F5F5F5;
	padding: 20rpx 30rpx;
	padding-right: 20rpx;
	box-sizing: border-box;
	margin: -1rpx;
}
.xinxi .shang {
	display: flex;
	justify-content: space-between;
	font-size: 26rpx;
	font-family: PingFang SC;
	font-weight: 400;
	color: #333333;
}
.xinxi .shang .left {
	display: flex;
	align-items: center;
}
.xinxi .shang .left image {
	width: 50rpx;
	height: 50rpx;
	margin-right: 15rpx;
	border-radius: 50%;
}
.shang .left .txt image{
	width: 120rpx;
	height: 40rpx;
	border-radius: 0;
}
.shang .left .txt .phnoe image{
	width: 28rpx;
	height: 34rpx;
	border-radius: 0;
	margin-left: 30rpx;
}
.xinxi .xia {
	display: flex;
	font-size: 26rpx;
	font-family: PingFang SC;
	font-weight: 400;
	color: #999999;
	justify-content: space-between;
	padding: 30rpx 80rpx 0;
}
.xia .lien {
	width: 2rpx;
	height: 100rpx;
	background: #CCCCCC;
	opacity: 0.5;
}
.xia .left {
	/* text-align: center; */
}
.nomore {
	text-align: center;
	margin: 25rpx auto 100rpx;
	font-size: 26rpx;
	font-family: PingFang SC;
	font-weight: 400;
	color: #999999;
}
</style>
