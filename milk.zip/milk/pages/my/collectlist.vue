<!-- 我的收藏页面 -->
<template>
	<view>
		<view v-if="list.length!=0">
		<mark-slide-list :list="list" :button="buttonList" :border="true" @click="clickMethod" @change="changeMethod"></mark-slide-list>
		</view>
		<view v-else style="margin: 100rpx 0; text-align: center;">暂无数据</view>
	</view>
</template>

<script>
	import markSlideList from '../../components/mark-slide-list/mark-slide-list.vue'
	export default {
		data() {
			return {
				list : [],
				buttonList: [
				    {
				        title: '取消收藏',
				        background: '#3EA3E1',
				    }
				],
				goods_index:'',//商品id
			}
		},
		onShareAppMessage: function () {
		    return {
		      title:'乃小星',
		      path: '/pages/index/index?scene=' + '1-'+uni.getStorageSync('phone')
		    }
		},
		methods: {
			// init初始化
			init(){
				if(uni.getStorageSync('token')){
					let self=this
					self.request({
						url:'bashi/api/app.php?c=goods/getCollectList',
						data:{
							token:uni.getStorageSync('token'),
						},
					}).then(res=>{
						if(res.data.success){
							console.log(res)
							self.list=res.data.data //data中所有数据的集合
							console.log(self.list)
						}
					},rej=>{
						console.log(rej)
					})
				}else{
					uni.redirectTo({
						url:'../my/login'
					})
				}
			},
			
			changeMethod(data, button, index){
			   let self=this
			   self.request({
			   		url:'bashi/api/app.php?c=goods/addCollect',
			   		data:{
			   			token:uni.getStorageSync('token'),
						data_id:data.collect_data_id,
						type:1
			   		},
			   	}).then(res=>{
					console.log(res)
			   		if(res.data.success){
						self.init()
			   		}else{
						uni.showToast({
							icon:'none',
							title:res.data.msg
						});
					}
			   	},rej=>{
			   		console.log(rej)
			   	})
			  },
			clickMethod(data){
			    // console.log('点击行回调', data)
				if(data.goods_status==2){
					uni.navigateTo({
						url:'../commodity/commodity?id='+data.collect_data_id
					})
				}else{
					uni.navigateTo({
						url:'./Nocommunity?id='+data.collect_data_id
					})
				}
			},
		},
		components: {
			markSlideList
		},
		onLoad(options) {
			this.init()
		}
	}
</script>

<style>

</style>
