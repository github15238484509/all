<!-- 个人资料 -->
<template>
	<view style="padding: 20rpx 0rpx;">
		<view class="userList" @click="getImg">
			<view style="line-height: 80rpx;">
				头像
			</view>
			<view class="">
				<image :src="cdnUrl+userInfo.photo" mode=""></image>
				<uni-icons type="arrowright" size="20" color="#ccc" style="vertical-align: middle;margin-left:10rpx"></uni-icons>
			</view>
		</view>
		<view class="userList" @click="editName(userInfo.name)">
			<view class="">
				昵称
			</view>
			<view class="">
				{{userInfo.name}}
				<uni-icons type="arrowright" size="20" color="#ccc" style="vertical-align: middle;margin-left:10rpx"></uni-icons>
			</view>
		</view>
		<view class="userList" @click="editSex">
			<view class="">
				性别
			</view>
			<view class="">
				{{userInfo.sex}}
				<uni-icons type="arrowright" size="20" color="#ccc" style="vertical-align: middle;margin-left:10rpx"></uni-icons>
			</view>
		</view> 
		<view class="userList">
			<view class="">
				地址
			</view>
			<view class="" style="padding-right: 20rpx;">
				{{userInfo.address_detail?userInfo.address_detail:'暂无'}}
			</view>
		</view>
		<view class="userList"  @click="gettel(userInfo.referrer_phone)">
			<view class="">
				邀请人
			</view>
			<view class="" style="padding-right: 20rpx;">
				{{userInfo.referrer_phone?userInfo.referrer_phone:'暂无'}}
				<image src="../../static/tel.png" class="telimg" v-if="userInfo.referrer_phone"></image>
			</view>
		</view>
		<view class="userList">
			<view class="">
				注册时间
			</view>
			<view class="" style="padding-right: 20rpx;">
				{{userInfo.regtime}}
			</view>
		</view>
		<view class="userList" @click="gopush()">
			<view class="">
				推送消息设置
			</view>
			<view class="">
				<uni-icons type="arrowright" size="20" color="#ccc" style="vertical-align: middle;margin-left:10rpx"></uni-icons>
			</view>
		</view>
		<view style="width: 100%; height: 20rpx; background-color: #F5F5F5; padding: 0;"></view>
		<view class="userList" @click="$u.throttle(logout,1000)">
			<view class="">
				注销账户
			</view>
			<view class="">
				<uni-icons type="arrowright" size="20" color="#ccc" style="vertical-align: middle;margin-left:10rpx"></uni-icons>
			</view>
		</view>

		<!-- 性别渲染层 -->
		<view class="model" v-if="showModel" @click="cancel">
			<view class="model_con">
				<view class="sex" @click="getSex('男')">
					男
				</view>
				<view class="sex" @click="getSex('女')">
					女
				</view>
				<view style="width: 100%;height: 10rpx;background-color: #eee;">

				</view>
				<view class="sex" @click="cancel">
					取消
				</view>
			</view>
		</view>
		<!-- 底部按钮 -->
		<button class="butt" @click="unbind">退出登录</button>
	</view>
</template>

<script>
	import uniIcons from "@/components/uni-icons/uni-icons.vue"
	export default {
		components: {
			uniIcons
		},
		data() {
			return {
				userInfo: '',
				cdnUrl:this.$cdnUrl,
				showModel: false,
				name: '',
			}
		},
		onShareAppMessage: function () {
		    return {
		      title:'乃小星',
		      path: '/pages/index/index?scene=' + '1-'+uni.getStorageSync('phone')
		    }
		},
		methods: {
			init() {
				let self = this
				if (uni.getStorageSync('token')) {
					self.request({
						url: "bashi/api/app.php?c=personal/getPersonalInfo",
						data: {
							token: uni.getStorageSync('token')
						}
					}).then(res => {
						if (res.data.success) {
							self.userInfo = res.data.data.user_data
							// self.userInfo.regtime=formatTime(self.userInfo.regtime*1000)
						}
					})
				} else {
					uni.redirectTo({
						url: '../my/login'
					})
				}
			},
			//上传头像
			getImg() {
				let self = this,
					header = {
						"Content-Type": "multipart/form-data"
					};
				uni.chooseImage({
					count: 1,
					success: function(res) {
						uni.uploadFile({
							url: self.baseUrl + 'bashi/api/app.php?c=uploadHeadImage', //+url地址
							filePath: res.tempFilePaths.join(','),
							name: 'file',
							formData: {
								token: uni.getStorageSync('token')
							},
							header: header,
							success: function(res) {
								uni.showToast({
									title: '更换头像成功~'
								})
								self.init();
							},
						})
					}
				})
			},
			//修改name
			editName(e) {
				uni.navigateTo({
					url: './setName?name=' + e
				})
			},
			//修改性别
			editSex() {
				this.showModel = true
			},
			getSex(e) {
				let self = this
				self.request({
					url: "bashi/api/app.php?c=personal/setMyInfo",
					data: {
						token: uni.getStorageSync('token'),
						name: self.name,
						sex: e
					},
				}).then(res => {
					if (res.data.success) {
						uni.showToast({
							title: res.data.msg
						})
						self.init()
						self.showModel = false
					}
				}, rej => {
					console.log(rej)
				})
			},
			cancel() {
				this.showModel = false
			},
			// 拨打电话
			gettel(e){
				uni.makePhoneCall({
				    phoneNumber: e 
				});
			},
			//退出登录
			unbind() {
				let self = this
				uni.showModal({
					content: '您确定退出登录吗？',
					success: function(res) {
						if (res.confirm) {
							self.request({
								url: "bashi/api/app.php?c=account/loginOut",
								data: {
									token: uni.getStorageSync('token'),
								},
							}).then(res => {
								uni.clearStorage();
								if (res.data.success) {
									uni.showToast({
										title: '退出成功'
									});
									setTimeout(() => {
										uni.switchTab({
											url: '../index/index'
										})
									}, 500)
								}
							})
						}
					}
				})
			},
			// 注销账户
			logout() {
				let self=this;
				self.request({
					url:"bashi/api/app.php?c=personal/LogoutStatus",
					data:{
					}
				}).then(res => {
				        if (res.data.success) {
							if(res.data.data.time!=null&&res.data.data.out_time!='0'){
								uni.navigateTo({
									url:"../publicPages/status?type=2"+'&timeValue='+res.data.data.time+'&reason='+res.data.data.reason+'&out_time='+res.data.data.out_time+'&msg='+res.data.message
								})
							}else{
								uni.navigateTo({
									url:"cancelAccount"
								})
							}
				        } else {
				                uni.showToast({
				                title: res.message,
				                icon: 'none'
				                })
				        }
				})
				// let self = this
				// uni.showModal({
				// 	content: '您确定注销账户吗？',
				// 	success: function(res) {
				// 		if (res.confirm) {
				// 			self.request({
				// 				url: "bashi/api/app.php?c=personal/userLogout",
				// 				data: {
				// 					token: uni.getStorageSync('token'),
				// 				},
				// 			}).then(res => {
				// 				if (res.data.success) {
				// 					uni.clearStorage();
				// 					uni.showToast({
				// 						icon:'none',
				// 						title: res.data.msg
				// 					});
				// 					console.log(111);
				// 					setTimeout(() => {
				// 						console.log(222);
				// 						uni.switchTab({
				// 							url: '../index/index'
				// 						})
				// 					}, 500)
				// 				}else{
				// 					uni.showToast({
				// 						icon:'none',
				// 						title: res.data.msg
				// 					})
				// 				}
				// 			})
				// 		}
				// 	}
				// })
			},
			// 转跳到推送消息页面
			gopush(){
				uni.navigateTo({
					url:"./pushServer"
				})
			},

		},
		onShow() {
			this.init()
		}
	}
</script>

<style lang="scss">
	page {
		padding-bottom: 150rpx;
	}

	.userList {
		display: flex;
		padding: 30rpx;
		justify-content: space-between;
		border-bottom: 1rpx solid #f5f5f5;
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #333333;

		image {
			width: 80rpx;
			height: 80rpx;
			border-radius: 50%;
			vertical-align: middle;
		}
		.telimg {
			width: 34rpx;
			height: 34rpx;
			margin-left: 20rpx;
			align-items: center;
		}
	}

	.model {
		width: 100%;
		height: 100%;
		position: fixed;
		top: 0;
		left: 0;
		background-color: rgba(0, 0, 0, .5);
		z-index: 111111111;

		.model_con {
			width: 690rpx;
			position: absolute;
			bottom: 30rpx;
			left: 50%;
			transform: translateX(-50%);
			background-color: #fff;
			border-radius: 20rpx;

			.sex {
				width: 100%;
				height: 100rpx;
				line-height: 100rpx;
				text-align: center;
				font-size: 26rpx;
				color: #333;
			}
		}
	}

	.butt {
		position: fixed;
		left: 30rpx;
		bottom: 30rpx;
		width: 690rpx;
		height: 90rpx;
		background: #40A2E0;
		border-radius: 45rpx;
		line-height: 90rpx;
		text-align: center;
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #FFFFFF;
	}
</style>
