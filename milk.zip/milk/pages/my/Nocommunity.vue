<!-- 商品下架页面 -->
<template>
	<view class="">
		<view class="none_img" >
			<image src="../../static/noshop.png" mode=""></image>
		</view>
		<view style="background-color: #f5f5f5;width: 100%;height: 20rpx;"></view>
		<view class="recommend">
			<view class="recommend_tit">
				<view class="line"></view>
				<view class="title">
					商品推荐
				</view>
				<view class="line1"></view>
			</view>
		</view>
		<!-- 商品列表 -->
		<view class="productlist">
			<view class="text">产品列表</view>
			<!-- goodslist是msg下的数组 -->
				<view class="list" v-for="item in goodslist" :key='item.goods_index' @click="product(item.goods_index)">
					<view class="img">
						<image :src="cdnUrl+item.goods_icon"></image>
					</view>
					<view class="right">
						<view class="txt1">{{item.goods_name}}</view>
						<view class='txt2' v-if="item.goods_yd=='已预定'">{{item.goods_yd}}</view>
						<view class='txt22' v-else>{{item.goods_yd}}</view>
						<view class="txt3">
							<view class="money">￥{{item.goods_cost/100}}元/瓶</view>
							<view class="predeter" @click.stop="predeter(item)">立即预定</view>
						</view>
					</view>
				</view>
		</view>
	</view>
</template>

<script>
	export default {
		data(){
			return{
				cdnUrl:'',
				goodslist:[],
			}
		},
		onShareAppMessage: function () {
		    return {
		      title:'乃小星',
		      path: '/pages/index/index?scene=' + '1-'+uni.getStorageSync('phone')
		    }
		},
		methods:{
			// 初始化页面加载 
			init(){
				this.cdnUrl=this.$cdnUrl;
				let self=this;
				
				self.request({
					url:'bashi/api/app.php?c=account/appIndex',
					data:{
						token:uni.getStorageSync('token'),
					}
				}).then(res=>{
					self.goodslist=res.data.data.goodslist
					if(self.goodslist.length>=3){
						self.goodslist.length=3
					}
				},rej=>{
					// 打印日志或者弹窗提示
					console.log(rej)
				})
			},
			// 产品详情页面转跳
			product(id){
				uni.navigateTo({
					url:'../commodity/commodity?id='+id
				})
			},
			
				// 立即预定按钮转跳
				predeter(item){
					if(uni.getStorageSync('token')!=''){
						uni.navigateTo({
							// url:'../commodity/information?id='+id,
							url:'../commodity/information?id='+item.goods_index+'&name='+item.goods_name+'&icon='+item.goods_icon+'&goods_cost='+item.goods_cost
						})
					}else{
						uni.reLaunch({
							url:'../my/login'
						})
					}
				}
		},
		onShow(){
			this.init()
		}
	}
</script>

<style lang="scss">
	.none_img{
		text-align: center;
		image{
			width: 224rpx;
			height: 215rpx;
			margin: 50rpx 0;
		}
	}
	.recommend{
		.recommend_tit{
			display: flex;
			align-items: center;
			justify-content: center;
			margin: 20rpx 0 30rpx;
			.line{
				width:100rpx;
				height:2rpx;
				background:rgba(153,153,153,1);
				position: absolute;
				left: 190rpx;
			}
			.line1{
				width:100rpx;
				height:2rpx;
				background:rgba(153,153,153,1);
				position: absolute;
				right: 190rpx;
			}
			.title{
				font-size:30rpx;
				font-family:PingFang SC;
				font-weight:500;
				color:rgba(51,51,51,1);
				margin: 0 20rpx;
				position: relative;
			}
		}
	}
/* 产品列表 */
.productlist {
	margin: 55rpx 30rpx 0;
}
.productlist .text {
	font-size: 28rpx;
	font-family: PingFang SC;
	font-weight: bold;
	color: #343434;
	margin-bottom: 42rpx;
}
.productlist .list {
	display: flex;
	margin-bottom: 30rpx;
}
.productlist .list .img {
	width: 200rpx;
	height: 200rpx;
	/* background-color: #007AFF; */
	margin-right: 25rpx;
}
.productlist .img image {
	width: 100%;
	height: 100%;
}
.productlist .right {
	border-bottom: 1rpx solid #F5F5F5;
	padding-bottom: 35rpx;
	flex: 1;
}
.productlist .right .txt1 {
	font-size: 28rpx;
	font-family: PingFang SC;
	font-weight: 500;
	color: #343434;
	overflow: hidden;
	text-overflow: ellipsis;
	display: -webkit-box;
	-webkit-line-clamp: 2;
	-webkit-box-orient: vertical;
}
.productlist .right .txt2 {
	width: 90rpx;
	height: 36rpx;
	background: #3EA4E1;
	border-radius: 4rpx;
	font-size: 22rpx;
	font-family: PingFang SC;
	font-weight: 400;
	color: #FFFFFF;
	text-align: center;
	line-height: 36rpx;
	margin-top: 13rpx;
}
.productlist .right .txt22 {
	width: 90rpx;
	height: 36rpx;
	background:#CCCCCC;
	border-radius: 4rpx;
	font-size: 22rpx;
	font-family: PingFang SC;
	font-weight: 400;
	color: #FFFFFF;
	text-align: center;
	line-height: 36rpx;
	margin-top: 13rpx;
}
.productlist .right .txt3 {
	display: flex;
	justify-content: space-between;
}
.productlist .right .txt3 .money {
	font-size: 28rpx;
	font-family: PingFang SC;
	font-weight: 400;
	color: #289CEC;
	margin-top: 47rpx;
} 
.productlist .right .txt3 .predeter {
	width: 140rpx;
	height: 50rpx;
	background: #3EA4E1;
	border-radius: 25rpx;
	font-size: 26rpx;
	font-family: PingFang SC;
	font-weight: 500;
	color: #FFFFFF;
	text-align: center;
	line-height: 50rpx;
	margin-top: 30rpx;
}
.productlist .foot {
	font-size: 26rpx;
	font-family: PingFang SC;
	font-weight: 400;
	color: #9A9A9A;
	text-align: center;
	padding-bottom: 30rpx;
}
</style>
