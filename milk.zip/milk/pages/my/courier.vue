<!--成为配送员 -->
<template>
	<view>
		<view v-if="bind">
			<view style="padding: 0 30rpx;" class="bindCard" v-if="enter==1">
				<view class="content">
					<view class="">手机号</view>
					<view class="">
						<input type="number" maxlength="11" v-model="tel" placeholder="请输入手机号" @input="getTel" />
					</view>
				</view>
				<view class="content">
					<view class="">姓名</view>
					<view class="">
						<input type="text" v-model="name" placeholder="请输入姓名" @input="getName" />
					</view>
				</view>
				<view class="content">
					<view class="">年龄</view>
					<view class="">
						<input type="number" maxlength="3" v-model="age" placeholder="请输入年龄" @input="getAge" />
					</view>
				</view>
				<view class="content">
					<view class="">性别</view>
					<view  class="flexs">
						<view v-for="(item, i) in sex" :key="i" @click="getSex(i)">
							<image :src="i === select ? item.icon2 : item.icon" style="width: 39rpx;height:39rpx;"></image>
							<text>{{ item.name }}</text>
						</view>
					</view>
				</view>
				<view style="width: 100%;height: 20rpx;background-color: #F5F5F5;"></view>
				<view class="cause">
					<view class="text1">申请原因：</view>
					<textarea maxlength="500" placeholder="请描述申请缘由，最多输入500个字。" v-model="textareas" @input="monitor"></textarea><!-- v-html="textareas" -->
					<text>{{num}}/500</text>
				</view>
				<view class="sureBind" @click="confirm">提交</view>
			</view>
			
			<view v-if="enter==2">  <!-- 复制 门店审核进度页面 -->
				<!-- steps步骤条  纵向排列-->
				<uni-steps :options="options" direction="column" :active="0" v-if="statedata.status==1"></uni-steps>
				<view v-if="statedata.status==2">
					<uni-steps :options="options1" direction="column" :active="2" ></uni-steps>
					<view class="txt">失败原因：{{statedata.refusal_cause}}<text @click="resubmit()">重新提交</text></view>
				</view>
			</view>
			
			<view class="couriers" v-if="enter==3">
				<view class="hang">
					<!-- 今明日汇总 -->
					<view class="collect" style="padding-right: 0rpx;">
						<view style="display: flex;align-items: center;">
							<view class="" >{{btnDayType==0?'今':'明'}}日配送汇总：</view>
							<view class="btn" @click="openbgc()">查看数据</view>
						</view>
						<view class="btnDayType" @click="tabStatus()" ><span class="iconfont icon-jiantou_zuoyouqiehuan"></span> {{btnDayType==0?'明':'今'}}日配送</view>
					</view>
					<!-- tab栏 -->
					<view class="tabs">
						<block v-for="(item,i) in tab" :key="item.id">
							<view :class="tabselect==item.id?'txt1':'txt2'" @click="dayStatus(item.id)">
							<text>{{item.name}}</text>
							</view>
						</block>
					</view>
				</view>
				<view style="margin-top: 75rpx;"></view>
				<view class="store" v-for="(item,i) in couriers" :key= 'i' style="background-color: #FFFFFF;margin-top: 20rpx;padding: 30rpx 30rpx 10rpx 30rpx;border-bottom: 2rpx solid #F5F5F5;">
					<view class="hang1">
						<view class="left" v-if="orderStatus==1">
							<image :src="cdnUrl+item.logo"></image>
							<view class="text">{{item.merchant_name}}</view>
						</view>
						<view class="left" v-else>
							<image src="../../static/adressIcon.png" style="width: 64rpx;height: 64rpx;"></image>
							<view>
								<view style="display: flex;align-items: center;">
									<view>{{item.address.contacts}}</view>
									<view  @click="callPhone(item.address.phone)" style="margin-left: 60rpx;color: #999999;font-size: 24rpx;">{{item.address.phone}} <img src="../../static/tel.png" alt="" style='width: 30rpx;height: 30rpx;margin-left: 20rpx;'></view>
								</view>
								<view class="text" style="width: 500rpx;margin: 20rpx 0;">{{item.address.full_address+item.address.address}}</view>
							</view>
						</view>
						<view class="right" >
							<view v-if="(item.delivery_peisong==0&&orderStatus==2)||(item.delivery_peisong==1&&orderStatus==1)">待出库</view>
							<view v-if="(item.delivery_peisong==1&&orderStatus==2)||(item.delivery_peisong==2&&orderStatus==1)">待配送</view>
							<view v-if="(item.delivery_peisong==2&&orderStatus==2)||(item.delivery_peisong==3&&orderStatus==1)">配送中</view>
							<view v-if="(item.delivery_peisong==3&&orderStatus==2)||(item.delivery_peisong==4&&orderStatus==1)">已送达</view>
						</view>
					</view>
					<view class="hang2" v-for="(items,k) in couriers[i].all_goods" :key= 'k'>
						<image :src="cdnUrl+items.goods_icon"></image>
						<view class="right">
							<view class="text2">{{items.goods_name}}</view>
							<view class="text3">x{{items.goods_num}}</view>
						</view>
					</view>
					<view class="hang3">
						<view v-if='orderStatus==1' class="btn1" @click="getmap(item.merchant_longitude,item.merchant_latitude,item.merchant_name)">查看导航</view>
						<view v-if='orderStatus==2' class="btn1" @click="getmap(item.address.lng,item.address.lat,item.full_address)">查看导航</view>
						<view class="btn2" v-if="(item.delivery_peisong==0&&orderStatus==2)||(item.delivery_peisong==1&&orderStatus==1)">确认配送</view>
						<view class="btn3" v-if="(item.delivery_peisong==1&&orderStatus==2)||(item.delivery_peisong==2&&orderStatus==1)" @click="getdelivery(item)">确认配送</view>
						<view class="btn3" v-if="(item.delivery_peisong==2&&orderStatus==2)||(item.delivery_peisong==3&&orderStatus==1)" @click="getarrive(item)">已送达</view>
						<view class="btn2" v-if="(item.delivery_peisong==3&&orderStatus==2)||(item.delivery_peisong==4&&orderStatus==1)">已送达</view>
					</view>	
				</view>
			</view>
		</view>
		<!-- 配送汇总弹窗 -->
		<view class="beijing" v-if="flage">
			<view class="tanchuang">
				<image src="../../static/del.png" class="del" @click="delbgc()"></image>
				<text >{{btnDayType==0?'今':'明'}}日配送汇总</text>
				<view class="summarize" v-for="(item,i) in goods_data" :key='i'>
					<view class="text1">{{item.goods_name}}</view>
					<view class="text2">X{{item.goods_num}}</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import uniSteps from '@/components/uni-steps/uni-steps.vue'
	import uniIcons from "@/components/uni-icons/uni-icons.vue"
	import formatTime from "@/until/app.js"
	export default {
		components: {uniSteps},
		data() {
			return {
				order_delivery_index:"",//入户订单状态
				orderStatus:1,//查询的订单状态
				btnDayType:"0",//状态切换今天还是明天
				bind: false, //是否申请成为配送员
				enter: 3,//判断当前需要显示哪个按钮
				cdnUrl:'', //图片地址
				tel: '',
				name: '',
				age: '',
				sex: [
					{ id: 0, icon: '../../static/fk_icon.png', icon2: '../../static/fk_icon2.png', name: '男' },
					{ id: 1, icon: '../../static/fk_icon.png', icon2: '../../static/fk_icon2.png', name: '女' }
				],
				select: 0,
				sextype:1,
				textareas:'',
				num:0,//剩余字数
				
				// 配送员中心
				tab:[
					{id:0,name:'到店订单'},
					{id:1,name:'入户订单'}
				],
				tabselect:0,
				tabtype:'today',
				state:2,//产品状态
				flage:false,
				couriers:[],//数据集合
				goods_data:[],//商品汇总
				page:0,//分页
				pageCount:0,//总页数
				
				// 审核
				options:[
					{title:'信息提交成功,等待审核',desc:'2019-04-19 17:27'},
				],//格式源
				options1:[
					{title:'信息提交成功,等待审核',desc:'2019-04-19 17:27'},
					{title:'信息审核失败',desc:'2019-04-19 17:27'},
				],				
				active:'0',//当前步骤
				state:'0',//切换审核进度是否成功
				statedata:[],//数据集合
			}
		},
		onShareAppMessage: function () {
		    return {
		      title:'乃小星',
		      path: '/pages/index/index?scene=' + '1-'+uni.getStorageSync('phone')
		    }
		},
		methods: {
			// 拨打用户电话
			callPhone(e){
				uni.makePhoneCall({
					phoneNumber:e
				})
			},
						dayStatus(id){
							this.tabselect = id
							this.couriers=[]
							this.page=0
							if(id==0){
								this.orderStatus=1
							}
							if(id==1){
								this.orderStatus=2
							}
							this.init1()
						},
			//判断是否实名认证过  认证过后再判断是否申请成为配送员
			init() {
				let self = this
				self.request({
					url:'bashi/api/app.php?c=common/identity_card/checkUserCard',
					data:{
						token:uni.getStorageSync('token')
					}
				}).then(res=>{
					 if(res.data.data.card_status=='1'){
						 self.init1()  //==>配送员中心接口  my/withdrawal页面类似
					  }else if(res.data.data=='0'){
						  uni.showModal({
						  	title: '提示',
						  	content: '实名认证正在审核中，请耐心等待',
						  	showCancel:false,
						  	success: function success(res) {
						  		if (res.confirm) {
						  			uni.navigateBack({
						  				delta:1
						  			})
						  		}
						  	}
						  });
					  }else if(res.data.data=='-1'){
						  uni.showModal({
							title: '提示',
							content: '实名认证未通过，请重新实名认证',
							cancelColor:'#999999',
							confirmText:'去实名',
							confirmColor:'#3EA3E1',
							success: function success(res) {
								if (res.confirm) {
									uni.navigateTo({
										url:'/pages/my/identify'
									})
								}else{
									uni.navigateBack({
										delta:1
									})
								}
							}
						  });
					  }else{
						  uni.showModal({
						  	title: '提示',
						  	content: '尚未实名认证，请先实名认证',
						  	cancelColor:'#999999',
						  	confirmText:'去实名',
						  	confirmColor:'#3EA3E1',
						  	success: function success(res) {
						  		if (res.confirm) {
						  			uni.navigateTo({
						  				url:'/pages/my/identify'
						  			})
						  		}else{
						  			uni.navigateBack({
						  				delta:1
						  			})
						  		}
						  	}
						  });
					  }
				},rej=>{
					console.log(rej)
				})
			},
			getTel(e) {
				this.tel = e.detail.value
			},
			getName(e) {
				this.name = e.detail.value
			},
			getAge(e) {
				this.age = e.detail.value
			},
			getSex(i) {
				this.select = i
				if(i==0){
					this.sextype=1
				}else{
					this.sextype=2
				}
			},
			// 文本域字数显示
			monitor(){
				var txtval= this.textareas.length
				this.num = 500 - txtval
				if(this.num==0){
					uni.showToast({
						icon:'none',
						title: '超过上限值500'
					});
				}
			},
			// 提交按钮
			confirm(){
				let self = this
				if(self.tel == ''){
					uni.showToast({
						icon:'none',
						title:'请输入手机号'
					})
				}else if(self.name==''){
					uni.showToast({
						icon:'none',
						title:'请输入姓名'
					})
				}else if(self.age == ''){
					uni.showToast({
						icon:'none',
						title:'请输入年龄'
					})
				}else if(self.textareas==''){
					uni.showToast({
						icon:'none',
						title:'请输入申请原因'
					})
				}else{
					self.request({
						url:'bashi/api/app.php?c=courier/commit_courier',
						data:{
							token:uni.getStorageSync('token'),
							phone:self.tel,
							age:self.age,
							real_name:self.name,
							sex:self.sextype,
							cause:self.textareas
						}
					}).then(res=>{
						 if(res.data.success){
							uni.showToast({
								title:res.data.msg
							})
							// self.enter=2
							self.init1()
						  }else{
							uni.showToast({
							  	title:res.data.msg
							})
						  }
					},rej=>{
						console.log(rej)
					})
				}
			},
			
			// 配送员中心
			tabStatus(id){
				this.btnDayType=='0'?this.btnDayType='1':this.btnDayType='0'
				this.btnDayType=='0'?this.tabtype="today":this.tabtype="tomorrow"
				this.couriers=[]
				this.page=0
				this.init1()
			},
			// 查看地址
			getmap(longitude,latitude,merchant_name){
				uni.openLocation({
					latitude: Number(latitude),
					longitude:Number(longitude),
					name:merchant_name,
					success: function () {
						console.log(latitude,longitude);
					},
					fail: function (res){
						console.log(res)
					}
				});	
			},
			// 确认派送
			getdelivery(item){
				let self=this
				let requestData=''
				let requestData1=''
 				if (self.orderStatus==1){
					requestData=0;
					requestData1=item.merchant_id
				}else{
					requestData=item.address_id;
					requestData1=0
				}
				self.request({
					url:'bashi/api/app.php?c=courier/confirm_delivery',
					data:{
						token:uni.getStorageSync('token'),
						merchant_id:requestData1,
						address_id:requestData,
					}
				}).then(res=>{
					if(res.data.success){
						uni.showToast({
							icon:'none',
							title:res.data.msg
						})
						self.init1()
						self.couriers=[]
						// 刷新页面
					}else{
						uni.showToast({
							icon:'none',
							title:res.data.msg
						})
					}
				},rej=>{
					console.log(rej)
				})
			},
			// 已送达
			getarrive(item){
				let self=this
				let requestData=''
				let requestData1=''
				if (self.orderStatus==1){
					requestData=0;
					requestData1=item.merchant_id
				}else{
					requestData=item.address_id;
					requestData1=0
				}
				self.request({
					url:'bashi/api/app.php?c=courier/courier_reach',
					data:{
						token:uni.getStorageSync('token'),
						merchant_id:requestData1,
						address_id:requestData,
					}
				}).then(res=>{
					if(res.data.success){
						uni.showToast({
							icon:'none',
							title:res.data.msg
						})
						self.init1()
						self.couriers=[]
						// 刷新页面
					}else{
						uni.showToast({
							icon:'none',
							title:res.data.msg
						})
					}
				},rej=>{
					console.log(rej)
				})
			},
			// 打开弹窗
			openbgc(){
				this.flage=true
			},
			// 关闭弹窗
			delbgc(){
				this.flage=false
			},
			
			// 审核
			init1(){
				if(uni.getStorageSync('token')){
					let self=this
					self.request({
						url:'bashi/api/app.php?c=courier/delivery_record', 
						data:{
							token:uni.getStorageSync('token'),
							type:self.tabtype,
							status:self.orderStatus
						},
					}).then(res=>{
						if(res.data.success){
							// self.couriers=res.data.data
							uni.setNavigationBarTitle({
								title: '配送员中心'
							});
							self.order_delivery_index=res.data.delivery_index
							self.bind=true
							self.pageCount=res.data.pageCount
							for(var i=0; i<res.data.data.mer_data.length; i++){
								self.couriers.push(res.data.data.mer_data[i])
							}
							self.goods_data=res.data.data.goods_data
						}else{
							if(res.data.msg=="未提交申请!"){
								uni.setNavigationBarTitle({
									title: '申请成为配送员'
								});
								self.bind=true
								self.enter=1
							}
							if(res.data.msg=="未通过申请!"){
								uni.setNavigationBarTitle({
									title: '审核进度'
								});
								self.bind=true
								self.enter=2
								self.statedata=res.data.data
								if(self.statedata.status==1){
									self.options[0].desc=self.formatTime(self.statedata.sub_time)
								}
								if(self.statedata.status==2){
									self.options1[0].desc=self.formatTime(self.statedata.sub_time)
									self.options1[1].desc=self.formatTime(self.statedata.audit_time)
								}
								if(self.statedata.status==3){
									self.enter=3
								}
							}
							if(res.data.msg=="未提交未启用!"){
								uni.setNavigationBarTitle({
									title: '审核进度'
								});	
								self.bind=true
								self.enter=2
								self.statedata=res.data.data
								if(self.statedata.status==1){
									self.options[0].desc=self.formatTime(self.statedata.sub_time)
								}
								if(self.statedata.status==2){
									self.options1[0].desc=self.formatTime(self.statedata.sub_time)
									self.options1[1].desc=self.formatTime(self.statedata.audit_time)
								}
								if(self.statedata.status==3){
									self.enter=3
								}
							}
							// uni.showToast({
							// 	icon:'none',
							// 	title:res.data.msg
							// })
						}
					},rej=>{
						console.log(rej)
					})
				}else{
					uni.redirectTo({
						url:'../my/login'
					})
				}
			},
			// 重新提交文字==>转跳到门店申请页面
			resubmit(){
				this.enter=1
			}
		},
		// 上拉加载(小程序自带函数)
		onReachBottom(){
			if(this.page<this.pageCount-1){
				this.page++
				this.init1()
			}
		},
		onShow() {
			this.init()
			this.couriers=[]
			this.page=0
			this.cdnUrl=this.$cdnUrl
		}
	}
</script>

<style>
	page{
		background-color: #F5F5F5;
	}
</style>
<style>
	.btnDayType{
		width: 180rpx;
		height: 50rpx;
		background: #FFFFFF;
		opacity: 0.8;
		border-radius: 25rpx 0 0 25rpx;
		text-align: center;
		line-height: 50rpx;
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #3FA3DC;
	}
	.bindCard {
		background-color: #fff;
	}
	.content {
		padding: 30rpx 0;
		border-bottom: 1rpx solid #f5f5f5;
		display: flex;
		justify-content: space-between;
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: rgba(51, 51, 51, 1);
	}
	.content .flexs {
		display: flex;
		justify-content: space-between;
	}
	.content .flexs image {
		margin-right: 10rpx;
	}
	.content input {
		text-align: right;
	}
	.content image {
		width: 17rpx;
		height: 32rpx;
		vertical-align: middle;
		margin-left: 20rpx;
	}
	.cause {
		margin-top: 30rpx;
		position: relative;
	}
	.cause .text1 {
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #333333;
		margin-bottom: 20rpx;
	}
	.cause textarea {
		width: 690rpx;
		height: 200rpx;
		background: #F5F5F5;
		border-radius: 10rpx;
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #999999;
		padding: 30rpx;
		box-sizing: border-box;
	}
	.cause text {
		position: absolute;
		bottom: 10rpx;
		right: 10rpx;
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #999999;
	}
	.sureBind {
		width: 690rpx;
		height: 90rpx;
		background: #3EA4E1;
		border-radius: 45rpx;
		margin-top: 400rpx;
		line-height: 90rpx;
		text-align: center;
		color: #fff;
		font-size: 30rpx;
		margin-bottom: 30rpx;
	}
/* 配送员中心 */
.hang {
	position: relative;
}
.collect {
	width: 100%;
	height: 120rpx;
	background: linear-gradient(0deg, #3DA3E1, #889AFE);
	font-size: 30rpx;
	font-family: PingFang SC;
	font-weight: 500;
	color: #FFFFFF;
	line-height: 100rpx;
	padding: 0 30rpx;
	box-sizing: border-box;
	display: flex;
	justify-content: space-between;
	align-items: center;
}
.btn {
	width: 150rpx;
	height: 50rpx;
	background: #FFFFFF;
	opacity: 0.8;
	border-radius: 25rpx;
	text-align: center;
	line-height: 50rpx;
	font-size: 26rpx;
	font-family: PingFang SC;
	font-weight: 400;
	color: #3FA3DC;
}
.tabs {
	position: absolute;
	bottom: -50rpx;
	left: 0;
	width: 100%;
	height: 70rpx;
	background: #FFFFFF;
	border-radius: 10px 10px 0px 0px;
	display: flex;
	line-height: 70rpx;
}
.tabs .txt1 {
	line-height: 50rpx;
	margin: 10rpx 0;
	width: 374rpx;
	height: 50rpx;
	text-align: center;
	border-right: 2rpx solid #F5F5F5;
	padding: 0 130rpx;
}
.tabs text {
	line-height: 50rpx;
	width: 130rpx;
	height: 50rpx;
	display: block;
	font-size: 26rpx;
	font-family: PingFang SC;
	font-weight: 500;
	color: #3BA3DC;
	text-align: center;
	border-bottom: 4rpx solid #3BA3DC;
	padding-bottom: 10rpx;
}
.tabs .txt2 text{
	margin: 10rpx 0;
	width: 374rpx;
	height: 50rpx;
	text-align: center;
	border-right: 2rpx solid #F5F5F5;
	color: #999999;
	border-bottom:0;
}
.kong {
	width: 100%;
	height: 20rpx;
	background-color: #F5F5F5;
}
/* 列表 */
.store .hang1 {
	padding: 10rpx 0;
	display: flex;
	justify-content: space-between;
	align-items: center;
	font-size: 30rpx;
	font-family: Source Han Sans CN;
	font-weight: 300;
	color: #3FA3DC;
	box-sizing: border-box;
}
.store .hang1 image {
	width: 60rpx;
	height: 60rpx;
	margin-right: 15rpx;
}
.store .hang1 .left {
	display: flex;
	align-items: center;
	font-weight: 400;
	color: #333333;
}
.hang2 {
	border-top: 2rpx solid #F5F5F5;
	border-bottom: 2rpx solid #F5F5F5;
	padding: 20rpx 0rpx;
	box-sizing: border-box;
	display: flex;
}
.hang2 image {
	width: 140rpx;
	height: 140rpx;
	margin-right: 20rpx;
}
.hang2 .right {
	flex: 1;
	font-family: PingFang SC;
	margin-top: 10rpx;
 }
.hang2 .text2 {
	display: -webkit-box;
	-webkit-box-orient: vertical;
	-webkit-line-clamp: 2;
	overflow: hidden;
	font-size: 26rpx;
	font-weight: 400;
	color: #333333;
}
.hang2 .text3 {
	font-size: 30rpx;
	font-weight: 500;
	color: #3FA3DC;
	text-align: right;
	margin-top: 10rpx;
}
.hang3 {
	display: flex;
	justify-content: flex-end;
	font-size: 26rpx;
	font-family: Source Han Sans CN;
	font-weight: 300;
	color: #FFFFFF;
	margin: 10rpx 0;
	/* padding: 0 0rpx; */
}
.hang3 .btn1 {
	width: 135rpx;
	height: 50rpx;
	background: #FFFFFF;
	border: 1px solid #3FA3DC;
	border-radius: 25rpx;
	text-align: center;
	line-height: 50rpx;
	color: #3FA3DC;
}
.hang3 .btn2 {
	width: 135rpx;
	height: 50rpx;
	background: #CCCCCC;
	border-radius: 25rpx;
	text-align: center;
	line-height: 50rpx;
	margin-left: 20rpx;
}
.hang3 .btn3 {
	width: 135rpx;
	height: 50rpx;
	background: #3FA3DC;
	border-radius: 25rpx;
	text-align: center;
	line-height: 50rpx;
	margin-left: 20rpx;
}
/* 弹窗 */
.beijing {
	position: fixed;
	width: 100%;
	height: 100%;
	left: 0;
	top: 0;
	background-color: rgba(0,0,0,.5);
}
.tanchuang {
	position: fixed;
	left: 50%;
	top: 350rpx;
	transform: translateX(-50%);
	width: 600rpx;
	height: 700rpx;
	background-color: #FFFFFF;
	border-radius: 10rpx;
	padding: 30rpx;
	overflow: auto;
}
.tanchuang .del{
	width: 44rpx;
	height: 44rpx;
	position: absolute;
	right: 15rpx;
	top: 22rpx;
}
.tanchuang text {
	font-size: 30rpx;
	font-family: PingFang SC;
	font-weight: 500;
	color: #333333;
	margin-left: 180rpx;
}
.tanchuang .summarize {
	border-bottom: 2rpx solid #F5F5F5;
	display: flex;
	justify-content: space-between;
	align-items: center;
	padding: 10rpx 0;
	font-size: 26rpx;
	font-family: PingFang SC;
	font-weight: 400;
	color: #999999;
}
.tanchuang .summarize .text1 {
	display: -webkit-box;
	-webkit-box-orient: vertical;
	-webkit-line-clamp: 2;
	overflow: hidden;
	width: 485rpx;
}
.tanchuang .summarize .text2 {
	font-size: 30rpx;
	font-family: PingFang SC;
	font-weight: 500;
	color: #41A2DC;
}

/* 审核 */
.txt {
	font-size: 24rpx;
	font-family: PingFang SC;
	font-weight: 500;
	color:rgb(26, 173, 25);
	margin: -5rpx 50rpx;
}
.txt text {
	color: #3EA4DC;
	margin-left: 20rpx;
}
</style>
