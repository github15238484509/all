<!-- 我的余额 -->
<template>
	<view style="">
		<view class="myIntegral">
			<view class="num">
				<view class="num_tit">账户余额(元)</view>
				<view class="num_total">{{cash||0}}</view>
			</view>
			<view class="buju">
				<view class="left">累计提现(元):{{data.total_extract_cash||0}}</view>
				<view class="right">提现中(元):{{data.extract||0}}</view>
			</view>
		</view>
		
		<view class="agreement" style="border-bottom: 1rpx solid #f5f5f5;" @click="withdraw()">
			提现<image src="../../static/back.png" mode=""></image>
		</view>
		<!-- 我的银行卡标签 -->
<!-- 		<view class="agreement" style="border-bottom: 1rpx solid #f5f5f5;" @click="bankCard()">
			我的银行卡<image src="../../static/back.png" mode=""></image>
		</view> -->
		
		<view style="width:100%;height:20rpx;background:rgba(245,245,245,1);"></view>
		<view class="agreement" style="border-bottom: 1rpx solid #f5f5f5;" @click="balance()">
			余额明细<image src="../../static/back.png" mode=""></image>
		</view>
		<view class="agreement" style="border-bottom: 1rpx solid #f5f5f5;" @click="withRecord()">
			提现记录<image src="../../static/back.png" mode=""></image>
		</view>
		
	</view>
</template>

<script>
	import {fmoney} from '@/until/app.js'
	export default{
		data() {
			return {
				data:{},
				cash:'',
				txcash:0,
			}
		},
		onShareAppMessage: function () {
		    return {
		      title:'乃小星',
		      path: '/pages/index/index?scene=' + '1-'+uni.getStorageSync('phone')
		    }
		},
		methods:{
			init(){
				let self = this
				self.request({
					url:'bashi/api/app.php?c=personal/getMyCash',
					data:{
						token:uni.getStorageSync('token')
					}
				}).then(res=>{
					if(res.data.success){
						self.data = res.data.data
						self.cash=fmoney(self.data.cash/100,2)
						self.txcash = self.data.cash/100
						self.data.total_extract_cash=fmoney(self.data.total_extract_cash/100,2)
						self.data.extract=fmoney(self.data.extract/100,2)
					}else{
						uni.showToast({
							icon:'none',
							title:res.data.msg
						})
					}
				})
			},
			// 提现 
			withdraw(){
				let self = this
				uni.navigateTo({
					url:'/pages/my/withdrawal?cash='+self.cash+'&txcash='+self.txcash
				})
			},
			// 我的银行卡
			bankCard(){
				uni.navigateTo({
					url:'/pages/my/myCard'
				})
			},
			// 余额明细
			balance(){
				uni.navigateTo({
					url:'/pages/my/balanceDetail'
				})
			},
			// 提现记录
			withRecord(){
				uni.navigateTo({
					url:'./integralDetail'
				})
			},
		},
		onShow() {
			this.init()
		},
		onLoad(){
			
		}
	}
</script>

<style lang="scss">
	page{
		background-color: #f5f5f5;
	}
	.myIntegral{
		margin: 40rpx 30rpx;
		height: 300rpx;
			font-family: PingFang SC;
			font-weight: 500;
			color: #FFFFFF;
			padding:60rpx 30rpx 30rpx;
			border-radius: 15rpx;
			background: #3EA4E1;
			font-size: 26rpx;
			box-sizing: border-box;
		.num{
			.num_total{
				margin-top: 15rpx;
				font-size: 77rpx;
				font-family: Arial;
				font-weight: 400;
			}
		}
		.buju {
			padding-top: 40rpx;
			display: flex;
			justify-content: space-between;
			view {
				width: 50%;
			}
		}
	}
	.agreement{
		padding: 30rpx;
		font-size:26rpx;
		font-family:PingFang SC;
		font-weight:500;
		color:rgba(51,51,51,1);
		background-color: #fff;
		image{
			width:17rpx;
			height:32rpx;
			float: right;
		}
	}
</style>
