<!-- 后台充值金页面 -->
<template>
	<view>
		<!-- 头部 -->
		<view class="myIntegral">
			<view class="num">
				<view class="num_tit">后台充值金(元)</view>
				<view class="num_total">{{fmoney(ht_money/100||0)}}</view>
			</view>
		</view>
		<!-- 列表 -->
		<view class="order">
			<view class="txt"><text></text>其他明细</view>
			<block v-for="(item,i) in list" :key="i">
				<view class="list" v-if="list.length!=0">
					<view class="left">
						<view class="text">{{item.msg}}</view>
						<view class="time">{{item.time}}</view>
					</view>
					<view :class="item.type<100?'right':'right1'">{{item.type<100?'+':'-'}}{{fmoney(item.amount/100)}}</view>
				</view>
				<view class="noData" v-else>
					<image :src="cdnUrl+'bashi/image/nodata.png'"></image>
				</view>
			</block>
		</view>
	</view>
</template>

<script>
	import {formatTime} from '@/until/app.js'
	export default {
		data() {
			return {
				// rights:'后台充值金添加',//钱的类型
				ht_money:'',//后台钱变量
				page:0,
				pageCount:'',//总页数
				list:[],//提现列表
				cdnUrl:'',
			}
		},
		onShareAppMessage: function () {
		    return {
		      title:'乃小星',
		      path: '/pages/index/index?scene=' + '1-'+uni.getStorageSync('phone')
		    }
		},
		methods: {
			init(){
				let self = this
				self.request({
					url:'bashi/api/app.php?c=userServerRechargeChange',
					data:{
						token:uni.getStorageSync('token'),
						page:self.page
					}
				}).then(res=>{
					if(res.data.success){
						self.ht_money=res.data.data.server_recharge
						for(var i = 0; i < res.data.data.list.length; i++){
							res.data.data.list[i].time = formatTime(Number(res.data.data.list[i].time))
						}
						// self.list=res.data.data.list
						self.pageCount=res.data.pageCount
						for(var i=0; i<res.data.data.list.length; i++){
							self.list.push(res.data.data.list[i])
						}
						self.render=true
					}
				})
			},
		},
		// 上拉加载(小程序自带函数)
		onReachBottom(){
			if(this.page<this.pageCount-1){
				this.page++
				this.init()
			}
		},
		onLoad(options) {
			// this.ht_money=options.ht_money/100
			this.init()
			this.cdnUrl=this.$cdnUrl
		}
	}
</script>

<style lang="scss">
	page{
		// background-color: #f5f5f5;
	}
	.myIntegral{
		background-color: #f5f5f5;
			font-family: PingFang SC;
			font-weight: 500;
			color: #FFFFFF;
			font-size: 26rpx;
			box-sizing: border-box;
		.num{
			height: 300rpx;
			padding:60rpx 30rpx 30rpx;
			border-radius: 15rpx;
			margin: 0 30rpx;
			background: #3EA4E1;
			.num_total{
				margin-top: 15rpx;
				font-size: 77rpx;
				font-family: Arial;
				font-weight: 400;
			}
		}
		.buju {
			padding-top: 40rpx;
			display: flex;
			justify-content: space-between;
			view {
				width: 50%;
			}
		}
	}
	.order {
		width: 100%;
		padding: 35rpx 30rpx;
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #9A9A9A;
		box-sizing: border-box;
	}
	.order .txt text {
		display: inline-block;
		width: 4rpx;
		height: 30rpx;
		background: #3EA4E1;
		margin-right: 10rpx;
		vertical-align: middle;
	}
	.order .txt {
		font-size: 30rpx;
		font-weight: 500;
		color: #343434;
		padding-bottom: 30rpx;
	}
	.order .list{
		display: flex;
		justify-content: space-between;
		padding: 15rpx;
		box-sizing: border-box;
		font-family: PingFang SC;
		border-bottom: 1rpx solid #F5F5F5;
	}
	.list .left .text{
		font-size: 26rpx;
		font-weight: 500;
		color: #333333;
	}
	.list .left .time {
		font-size: 22rpx;
		font-weight: 400;
		color: #999999;
		margin-top: 20rpx;
	}
	.list .right {
		font-size: 26rpx;
		font-weight: bold;
		color: #FF3636;
		margin-top: 10rpx;
	}
	.list .right1 {
		font-size: 26rpx;
		font-weight: bold;
		color: #333333;
		margin-top: 10rpx;
	}
	.noData{
		text-align: center;
		image{
			width: 360rpx;
			height: 300rpx;
			margin: 100rpx auto;
		}
	}
</style>
