<!-- 身份证页面上传提交页面 -->
<template>
	<view>
		<view class="cardImg" v-if="showCamera1">  
		  <view class="title">第一步：请拍摄身份证正面照</view>
		  <view class="identityImg" @click="showTip1">
		    <image :src="cdnUrl+'bashi/image/sfz1.png'"></image>
		    <view class="camera" ><image src="../../static/Pphoto.png"></image> </view>
		  </view>
		  <view class="tip">保证图片的清晰</view>
		</view>
		<view class="cardImg" v-else>  
		  <view class="title">第一步：请确认身份证信息</view>
		  <view class="identityImg" v-if="showSure" @click="showTip1">
		    <image :src="cdnUrl+card_front"></image>
		  </view>
		  <view class="identityImg" v-else>
		    <image :src="cdnUrl+card_front"></image>
		  </view>
		  <view class="idMsg">
		    <view><text space="emsp">证件号码 </text> {{card_num}}</view>
		    <view><text space="emsp">姓  名 </text>{{card_name}}</view>
		  </view>
		</view>
		
		
		<view class="cardImg" v-if="showCamera2">  
		  <view class="title">第二步：请拍摄身份证反面照</view>
		  <view class="identityImg" @click="showTip2">
		    <image :src="cdnUrl+'bashi/image/sfz2.png'"></image>
		    <view class="camera" ><image src="../../static/Pphoto.png"></image> </view>
		  </view>
		  <view class="tip">保证图片的清晰</view>
		</view>
		<view class="cardImg" v-else>  
		  <view class="title">第二步：请确认身份证信息</view>
		  <view class="identityImg" @click="showTip2" v-if="showSure">
		    <image :src="cdnUrl+card_back"></image>
		  </view>
		  <view class="identityImg" v-else>
		    <image :src="cdnUrl+card_back"></image>
		  </view>
		  <view class="idMsg">
		    <view><text space="emsp">有效期至 </text> {{card_time}}</view>
		  </view>
		</view>
		<button class="btn" @click="getNext" v-if="showSure">提交</button>
		
		<view class="rule" v-if="upload_card1">
		  <view class="front">
		  <view class="del" @click="close1"><image src="/static/del.png"></image></view>
		    <view class="front_title">拍摄身份证正面</view>
		    <view class="front_content">身份证完整、身份证号清晰</view>
		    <image :src="cdnUrl+'bashi/image/sfz4.png'"></image>
		    <button class="know" @click="upload1">我知道了</button>
		  </view>
		</view>
		
		<view class="rule" v-if="upload_card2">
		  <view class="front">
		    <view class="del" @click="close2"><image src="/static/del.png"></image></view>
		    <view class="front_title">拍摄身份证反面面</view>
		    <view class="front_content">身份证完整、日期和文字清晰</view>
		    <image :src="cdnUrl+'bashi/image/sfz3.png'"></image>
		    <button class="know" @click="upload2">我知道了</button>
		  </view>
		</view>

	</view>
</template>

<script>
	import {formatTime} from '@/until/app.js'
	export default {
		data() {
			return {
				cdnUrl:'',
				showCamera1: true, //true显示相机  false显示身份证信息
				showCamera2: true,
				description: '', //规则内容
				current: '-1',
				card_front: '', //正面照片
				card_back: '', //反面照片
				upload_card1: false, //提示拍摄正面照片
				upload_card2: false, //提示拍摄反面照片
				card_num: '', //身份证号
				card_name: '', //身份证名字
				card_time: '', //身份证时间有效期
				start_date: '', //身份证开始日期
				end_date: '', //身份证结束日期
				card_status: '', //认证状态
				upload_success:true,//上传成功
				showSure:true,//判断是否认证通过
			}
		},
		onShareAppMessage: function () {
		    return {
		      title:'乃小星',
		      path: '/pages/index/index?scene=' + '1-'+uni.getStorageSync('phone')
		    }
		},
		methods: {
			init() {
				let self = this
				self.request({
					url:'bashi/api/app.php?c=common/identity_card/checkUserCard',
					data:{
						token:uni.getStorageSync('token')
					}
				}).then(res=>{
					 if(res.data.success){
						 if(res.data.data.card_status=='1'){
							 self.showCamera1=false
							 self.showCamera2=false
							 self.showSure=false
							 self.card_front=res.data.data.card_front
							 self.card_back=res.data.data.card_reverse
							 self.card_num=res.data.data.card_id
							 self.card_name=res.data.data.card_name
							 // self.card_time=formatTime(res.data.data.card_validity)
							 self.start_date = res.data.data.start_date
							 self.end_date = res.data.data.end_date
							 self.card_time = self.start_date+'至'+self.end_date 
						 }
					 }
				},rej=>{
					console.log(rej)
				})
			},
			close() {
			    this.showRule= false
			  },
			  close1() {
			    this.upload_card1=false
			  },
			  close2() {
			    this.upload_card2=false
			  },
			  //点击正面照片上的相机
			  showTip1() {
			    this.upload_card1=true
			  },
			  //点击反面照片上的相机
			  showTip2() {
			    this.upload_card2= true
			  },
			  // 上传身份证正面
			upload1() {
			    let self = this,
			      header = {
			        "Content-Type": "multipart/form-data"
			      };
			     self.upload_card1=false,
			     self.showRule=false,
			     self.upload_success=false
			    uni.chooseImage({
			      count: 1,
			      success: function (res) {
			        uni.uploadFile({
			          url: self.$baseUrl+'bashi/api/app.php?c=common/identity_card/uploadCardImage',
			          filePath: res.tempFilePaths.join(','),
			          name: 'file',
			          header: header,
					  formData:{
						  identity_img:res.tempFilePaths.join(',')
					  },
			          success: function (res) {
			            let data = JSON.parse(res.data)
			            if (data.success) {
							console.log(data);
			              self.getFaceMsg(data.data)
			            }
			          },
			        })
			      }
			    })
			  },
			getFaceMsg(path) {
			    let self = this
				self.request({
					url:'bashi/api/app.php?c=common/identity_card/getImageInfo',
					data:{
						token:uni.getStorageSync('token'),
						path: path,
						side: 'face'
					}
				}).then(res=>{
					 if(res.data.success){
						self.card_front=path
					    self.card_num=res.data.data.num
					    self.card_name=res.data.data.name
						self.showCamera1=false
					  } else {
					    uni.showToast({
							icon:'none',
							title:res.data.msg
						})
					  }
				},rej=>{
					console.log(rej)
				})
			  },
			  // 上传身份证反面
			upload2() {
			    let self = this,
			      header = {
			        "Content-Type": "multipart/form-data"
			      };
			      self.upload_card2=false
			      self.showRule=false
			      self.upload_success=false
			    uni.chooseImage({
			      count: 1,
			      success: function (res) {
			        uni.uploadFile({
			          url: self.$baseUrl+'bashi/api/app.php?c=common/identity_card/uploadCardImage',
			          filePath: res.tempFilePaths.join(','),
			          name: 'file',
			          header: header,
					  formData:{
					  	identity_img:res.tempFilePaths.join(',')
					  },
			          success: function (res) {
			            let data = JSON.parse(res.data)
			            if (data.success) {
			              self.getBackMsg(data.data)
			            }
			          },
			        })
			      }
			    })
			  },
			getBackMsg(path) {
				  let self = this
				  self.request({
				  	url:'bashi/api/app.php?c=common/identity_card/getImageInfo',
				  	data:{
				  		token:uni.getStorageSync('token'),
				  		path: path,
				  		side: 'back'
				  	}
				  }).then(res=>{
				  	 if(res.data.success){
				  		self.card_back=path
				  	    self.start_date = res.data.data.start_date
				  	    self.end_date = res.data.data.end_date
						self.card_time = self.start_date+'至'+self.end_date 
				  		self.showCamera2=false
				  	  } else {
				  	    uni.showToast({
				  			icon:'none',
				  			title:res.data.msg
				  		})
				  	  }
				  },rej=>{
				  	console.log(rej)
				  })
			  },
			getNext() {
				  let self = this
				  if(self.card_front==''){
					  uni.showToast({
					  	icon:'none',
					  	title:'请上传身份证正面照'
					  })
				}else if(self.card_back==''){
					uni.showToast({
						icon:'none',
						title:'请上传身份证反面照'
					})
				}else{
					let d = new Date(self.end_date)
					console.log(d.getTime(d)/1000);
					self.request({
						url:'bashi/api/app.php?c=common/identity_card/submitCard',
						data:{
						  token: uni.getStorageSync('token'),
						  card_name: self.card_name,
						  card_number: self.card_num,
						  start_date:self.start_date,
						  end_date:self.end_date,
						  // card_validity: d.getTime(d)/1000,
						  face_path: self.card_front,
						  back_path: self.card_back,
						}
					}).then(res=>{
						 if(res.data.success){
							uni.showToast({
								title:res.data.msg
							})
								setTimeout(()=>{
									uni.switchTab({
										url:'/pages/my/my'
									})
								},1000)
						  } else {
						    uni.showToast({
								icon:'none',
								title:res.data.msg
							})
						  }
					},rej=>{
						console.log(rej)
					})
				}
			}
		},
		onShow(){
			this.cdnUrl=this.$cdnUrl
			this.init()
		}
	}
</script>

<style>
	page{
		background-color: #f8f8f8;
	}
.cardImg{
  margin: 20rpx 30rpx;
  background:rgba(255,255,255,1);
  border-radius:10px;
  text-align: center;
  padding: 20rpx 0;
}
.title{
  font-size:26rpx;
  font-family:Adobe Heiti Std;
  font-weight:600;
  color:rgba(51,51,51,1);
  margin-bottom: 30rpx;
  padding-bottom: 30rpx;
  border-bottom: 1rpx solid #f8f8f8;
}
.identityImg{
  width:361rpx;
  height:231rpx;
  border-radius:10px;
  margin: auto;
  position: relative;
}
.identityImg image{
  width: 360rpx;
  height: 230rpx;
}
.camera{
  width:120rpx;
  height:120rpx;
  position: absolute;
  top: 50%;
  left: 50%;
  margin-top: -60rpx;
  margin-left: -60rpx;
  border-radius:50%;
}
.camera image {
	width: 100%;
	height: 100%;
}
.tip{
  font-size:24rpx;
  font-family:Adobe Heiti Std;
  font-weight:normal;
  color:rgba(153,153,153,1);
  margin-top: 30rpx;
}
.btn{
  width:430rpx;
  height:79rpx;
  background:#3EA3E1;
  border-radius:40rpx;
  color: #fff;
  margin-top: 60rpx;
  font-size:30rpx;
  font-weight:normal;
}
.rule{
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0,0,0,.4);
  z-index: 11;
}
.description{
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%,-50%);
  width:500rpx;
  background:rgba(255,255,255,1);
  border-radius:10px;
}
.del{
  width: 50rpx;
  height: 50rpx;
  line-height: 50rpx;
  text-align: center;
  position: absolute;
  top: 10rpx;
  right: 20rpx;
}
.del image{
  width: 30rpx!important;
  height: 30rpx!important;
}
.description_title,.front_title{
  height: 90rpx;
  line-height: 120rpx;
  text-align: center;
  font-size:30rpx;
  font-family:Source Han Sans CN;
  font-weight:400;
  color:rgba(51,51,51,1);
}
.description_content{
  padding: 30rpx;
  font-size:26rpx;
  font-family:Source Han Sans CN;
  font-weight:300;
  color:rgba(153,153,153,1);
  line-height:36rpx;
  text-indent:2em
}
.read{
  height: 90rpx;
  line-height: 90rpx;
  border-top: 1rpx solid #f5f5f5;
  color: #3D568A;
  font-size: 26rpx;
  text-align: center;
}
.front{
  width: 600rpx;
  position: absolute;
  background-color: #fff;
  top: 50%;
  margin-top: -50%;
  left: 75rpx;
}
.front_content{
  font-size:24rpx;
  font-family:Adobe Heiti Std;
  font-weight:normal;
  color:rgba(153,153,153,1);
  line-height:50rpx;
  text-align: center;
}
.front image{
  width: 550rpx;
  height: 420rpx;
  margin-left: 25rpx;
}
.know{
  width:240rpx;
  height:80rpx;
  line-height: 80rpx;
  background:#3EA3E1;
  border-radius:40rpx;
  margin: 30rpx auto; 
  color: #fff;
  font-size: 28rpx;
}
.idMsg{
  text-align:left;
  margin-left:140rpx;
  width: 430rpx;
}
.idMsg view{
  border-bottom: 1px solid #ccc;
  font-size:24rpx;
  font-family:Adobe Heiti Std;
  font-weight:normal;
  color:rgba(51,51,51,1);
  line-height:70rpx;
}
.idMsg text{
	margin-right: 30rpx;
}
</style>
