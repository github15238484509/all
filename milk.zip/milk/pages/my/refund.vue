<!-- 我的退款页面 -->
<template>
	<view>
		<!-- 列表循环 reserveList  -->
			<block v-if="reserveList.length!=0">
			<view class="reserveList" v-for="(item,i) in reserveList" :key= 'i'>
				<view class="up">
					<view class="gray">剩余待发放：{{item.res_total_count}}{{item.goods_unit}}</view>
					<view class="right" v-if="item.check_status==0">待审核</view>
					<view class="right" v-if="item.check_status==1">审核通过</view>
					<view class="right" v-if="item.check_status==2">已驳回</view>
					<view class="right" v-if="item.check_status==3">已退款</view>
				</view>
				<view class="center">
						<view class="img">
							<image :src='cdnUrl+item.goods_icon'></image>
						</view>
					<view class="right">
						<view class="txt1">{{item.goods_name}}</view>
						<view class="money">
							<view class="txt2">￥{{item.goods_cost/100}}/{{item.goods_unit}}</view>
							<view class="gray">×{{item.refund_count}}</view>
						</view>
					</view>
				</view>
				<view class="down">
					<view class="gray">退款金额：￥{{item.refund_price/100}}</view>
					<view class="butt">
						<view class="suspend" v-if="item.check_status==0" @click="schedule(item.order_index)">查看进度</view>
						
						<view class="take" v-if="item.check_status==3">已退款</view>
						
						<view class="suspend" v-if="item.check_status==2" @click="cause(item.order_index)">查看原因</view>
					</view>
				</view>
		</view>
		</block>
		<view v-else>
			<image :src="cdnUrl+'bashi/image/nodata.png'" style="width: 344rpx; height: 298rpx; margin-top: 200rpx; left: -50%; transform: translateX(60%);"></image>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				reserveList:[], // 订单列表
				page:0,
				pageCount:0,
				cdnUrl:'',
			}
		},
		onShareAppMessage: function () {
		    return {
		      title:'乃小星',
		      path: '/pages/index/index?scene=' + '1-'+uni.getStorageSync('phone')
		    }
		},
		methods: {
			init(){
				let self = this
				self.request({
					url:'bashi/api/app.php?c=reserve/myRefundList',
					data:{
						token:uni.getStorageSync('token'),
						page:self.page
					},
					}).then(res=>{
						if(res.data.success){
							self.pageCount = res.data.pageCount
							for(var i = 0; i < res.data.data.list.length ; i++){
								self.reserveList.push(res.data.data.list[i])
							}
							// console.log(self.reserveList.length)
						}else{
							if(res.data.msg=='登录状态失效，请重新登录~！'){
								uni.removeStorageSync('token')
								uni.reLaunch({
									url:'./login'
								})
							}else{
								uni.showToast({
									icon:'none',
									title:res.data.msg
								})
							}
						}
					},rej=>{
						console.log(rej)
					})
			}, 
			
			// 查看进度
			schedule(id){
				uni.navigateTo({
					url:'../reserve/audit?id='+id
				})
			},
			// 查看原因
			cause(id){
				uni.navigateTo({
					url:'../reserve/audit?id='+id
				})
			},
		},
		// 上拉加载(小程序自带函数)
		onReachBottom(){
			if(this.page<this.pageCount-1){
				this.page++
				this.init()
			}
		},
		onShow() {
			this.cdnUrl=this.$cdnUrl
			this.page=0
			this.pageCount=0
			this.reserveList=[]
			this.init()
		},
		onLoad() {
		}
	}
</script>

<style>
page {
	background-color: #F5F5F5;
}
/* 循环列表 */
.reserveList {
	width: 750rpx;
	/* height: 360rpx; */
	background: #FFFFFF;
	padding: 28rpx 30rpx 13rpx;
	box-sizing: border-box;
	margin: 20rpx 0;
}
.reserveList .up {
	display: flex;
	justify-content: space-between;
	height: 50rpx;
	line-height: 30rpx;
	font-size: 26rpx;
	font-family: PingFang SC;
	font-weight: 400;
	border-bottom: 1rpx solid #F5F5F5;
}
.up .gray {
	color: #9A9A9A;
}
.up .right {
	color: #3EA4E1;
}
.reserveList .center {
	padding: 30rpx 0;
	display: flex;
	border-bottom: 1rpx solid #F5F5F5;
}
.reserveList .center .img{
	width: 140rpx;
	height: 140rpx;
	background-color: #007AFF;
	border-radius: 6rpx;
	margin-right: 25rpx;
	
}
.img image{
		width: 100%;
		height: 100%;
	}
.center .right{
	flex: 1;
	display: flex;
	flex-direction: column;
	justify-content: space-between;
}
.center .right .txt1 {
	font-size: 28rpx;
	font-family: PingFang SC;
	font-weight: 400;
	color: #343434;
}
.center .right .money {
	display: flex;
	justify-content: space-between;
	/* margin-top: 58rpx; */
}
.center .money .txt2 {
	font-size: 28rpx;
	font-family: PingFang SC;
	font-weight: 400;
	color: #289CEC;
}
.center .money .gray {
	font-size: 28rpx;
	font-family: PingFang SC;
	font-weight: 400;
	color: #9A9A9A;
}
.reserveList .down {
	margin: 15rpx 10rpx;
	display: flex;
	justify-content: space-between;
}
.reserveList .down .gray {
	font-size: 26rpx;
	font-family: PingFang SC;
	font-weight: 400;
	color: #9A9A9A;
}
.reserveList .down .butt {
	display: flex;
	text-align: center;
	font-size: 24rpx;
	font-family: PingFang SC;
	font-weight: 400;
	line-height: 50rpx;
}
.down .butt .suspend {
	width: 135rpx;
	height: 50rpx;
	background-color: #3EA4E1;
	margin-right: 23rpx;
	color: #fff;
	border-radius: 25rpx;
}
.down .butt .begin {
	width: 135rpx;
	height: 50rpx;
	background: #3EA4E1;
	color: #FFFFFF;
	border-radius: 25rpx;
}
.down .butt .renew {
	width: 135rpx;
	height: 50rpx;
	background: #FFFFFF;
	border: 1rpx solid #CCCCCC;
	border-radius: 25rpx;
	color: #9A9A9A;
	margin-right: 23rpx;
}
.down .butt .take {
	width: 135rpx;
	height: 50rpx;
	background: #CCCCCC;
	border-radius: 25rpx;
	color: #FFFFFF;
}
.nodata {
	width: 334rpx;
	height: 298rpx;
	margin: 134rpx 203rpx ;
}
.nodata image {
	width: 100%;
	height: 100%;
}
</style>

