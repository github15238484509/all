<template>
	
	<!-- 页面主体 -->
	<view>
		
		<!-- 头部内容 -->
		<view class="headWarning" >
			<view class="tip">
				<view>
					<img src="../../static/warning.png" alt="" style="width: 70rpx;height: 70rpx;">
				</view>
				<view class="tiptext">
					<view class="fontBig">您正在注销账号</view>
					<view class="fontSmall" style="margin-top: 10rpx;">一旦注销成功将无法找回，请谨慎操作</view>
				</view>
			</view>
	
			<view class="contactCustomer">
				<view class="fontSmall">如有问题，请联系客服进行解决！</view>
				<button open-type="contact" class="customerService" style="border: 0 none;margin: 0;padding: 0;">在线客服</button>
			</view>
		</view>
		
		<!-- 注销原因 -->
		<view class="division-1"> 请选择注销原因</view>
		
		<view style="background-color: #FFFFFF;padding: 0 30rpx;">
			
			<!-- radio单选框 -->
			<radio-group @change="checkboxChange">
				<label class="uni-list-cell uni-list-cell-pd fontSmall" v-for="item in radioList" :key="item.value" style="color: #333333;">
					<view>{{item.name}}</view>
					<view>
						<radio :value="item.value" :checked="item.checked" color="#3FA3DA" style="transform:scale(0.8)"/>
					</view>
				</label>
			</radio-group>
			
		</view>
		
		<!-- 卸载理由 -->
		<view class="division-1"> 请简单描述您在使用中遇到的问题</view>
		<view style="background-color: #FFFFFF;padding: 0 30rpxs;">
			<view style="height: 260rpx;display: flex;justify-content: center;align-items: center;position: relative;">
				<textarea style="height: 200rpx;width: 690rpx;background-color: #F5F5F5;padding: 20rpx;box-sizing: border-box;"   maxlength="500" placeholder="请描述申请缘由，最多输入500个字。" v-model="reason" @input="monitor"></textarea><!-- v-html="textareas" -->
				<text style="position: absolute;right: 50rpx;bottom: 50rpx;font-size: 24rpx;color: #999999;">{{num}}/500</text>
			</view>
<!-- 			<view >
				<textarea v-model="reason" value="" placeholder="请描述申请缘由，最多输入500个字。" placeholder-style="font-size:24rpx;padding:20rpx" style="width: 690rpx;height: 200rpx; margin: 0 auto;background-color: #F5F5F5;" />
			</view> -->
		</view>
	<!-- 底部按钮 -->
		<view class="btnview"> 
			<view class="btn footBig" @click="back">我点错了</view>
			<view class="btn footBig" style="background: #3FA3DA;color:#FFFFFF;" @click="userLogout">确定注销账号</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				num:0,
				radioList: [
					{
						value: '产品品质不佳',
						name: '产品品质不佳'
					}, 
					{
						value: '服务差，不知道什么时候取货',
						name: '服务差，不知道什么时候取货'
					}, 
					{
						value: '所在城市未开通服务',
						name: '所在城市未开通服务'
					}, 
					{
						value: '送货慢，收不到货',
						name: '送货慢，收不到货'
					}, 
					{
						value: '其他原因',
						name: '其他原因'
					}, 
				],
				radioValue:"",
				reason:"",
			}
		},
		methods: {
			// 申请原因输入框
			monitor(e){
				this.num=e.detail.value.length
			},
			// radio的值被改变是触发 
			checkboxChange(evt){
				this.radioValue=evt.detail.value
			},
			// 我点错了按钮 返回上一页面
			back(){
				uni.reLaunch({
					url:'./userInfo'
				})
			},
			// 确认注销账号按钮  客户端3.0注销账号接口
			userLogout(){
				let self =this;
				if(self.radioValue==""){
					uni.showToast({
						title:"请选择注销原因",
						icon:"none"
					})
					return
				}
				if(self.reason==""){
					uni.showToast({
						title:"请输入申请原因",
						icon:"none"
					})
					return
				}
				self.request({
					url:"bashi/api/app.php?c=personal/userLogout",
					data:{
						out_describe:self.radioValue,
						out_cause:self.reason
					}
				}).then(res => {
				        if (res.data.success) {
							console.log(res)
								uni.redirectTo({
									url:"../publicPages/status?type=1"+'&timeValue='+res.data.data
								})

				        } else {
				               uni.showToast({
				               title: res.data.message,
				               icon: 'none'
				               })
				        }
				})
			}
		}
	}
</script>

<style>
	page {
		background-color: #F5F5F5;
	}
</style>

<style lang="scss" scoped>
	button::after{
	border: none;
	}
	.headWarning{
		background-color: #FFFFFF;
		padding:30rpx 30rpx 0 30rpx;
	}
	.headWarning .tip{
		display: flex;
		height: 125rpx;
	}
	.headWarning .contactCustomer{
		height: 75rpx;
		background-color: #FFFFFF;
		display: flex;
		justify-content: space-between;
		line-height: 74rpx;
	}
	.headWarning .tip .tiptext{
		border-bottom: 2rpx solid #F5F5F5;
		margin-left: 30rpx;
	}
	.btnview{
		display: flex;
		justify-content: space-around;
		align-items: center;
		position: fixed;
		height: 110rpx;
		width: 100%;
		background-color: #FFFFFF;
		bottom: 0rpx;
	}
	.btn{
		width: 330rpx;
		height: 90rpx;
		line-height: 90rpx;
		border: 1rpx solid #CCCCCC;
		text-align: center;
		border-radius: 10rpx;
	}
	.uni-list-cell{
		display: flex;
		justify-content: space-between;
		height: 90rpx;
		line-height: 90rpx;
	}
	.division-1 {
		height: 60rpx;
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #999999;
		line-height: 60rpx;
		padding: 0 30rpx;
	}

	.contactCustomer .customerService {
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #3FA3DC;
		opacity: 0.8;
		background-color: #FFFFFF;
	}

	.triangle {
		border-style: solid;
		border-width: 0px 30rpx 65rpx 30rpx;
		border-color: transparent transparent #CE1515 transparent;
		width: 0px;
		height: 0px;
	}

	.fontSmall {
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #999999;
	}

	.footBig {
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #333333;
	}
</style>
