<!-- 提现页面 -->
<template>
	<view class="">
		<view class="cardMsg">
			<view class="card_img">
				<image :src="cdnUrl+wxUserInfo.photo" mode=""></image>
			</view>
			<view class="card_msg">
				<view class="card_num">
					昵称:{{wxUserInfo.name}}
				</view>
			<!-- 	<view class="card_name">
					{{wxUserInfo.card_bank}}
				</view> -->
			</view>
<!-- 			<view class="card_choose">
				<image src="../../static/right_back.png" mode=""></image>
			</view> -->
		</view>
		<view class="money">
			<view class="word">
				提现金额
			</view>
			<view class="ipt">
				<view class="money_mark">
					￥
				</view>
				<input type="text" :value="moneyValue" placeholder="请输入提现金额" @input="getMoney" :class="moneyValue!=''?'current':''"/>
				<view class="" class="del_money" @click="delMoney">
					<image src="../../static/del.png" ></image>
				</view>
			</view>
			<view class="left_monry">
				可提现余额：{{cash}}
				<view class="all_money" @click="getAll">
					全部提现
				</view>
			</view>
		</view>
		<view class="rule">
			<view class="rule_left">
				提现规则：
			</view>
			<view class="rule_right">
				<!-- <text space="emsp">{{show_style}}</text> -->
				<rich-text :nodes="show_style"></rich-text>
			</view>
		</view>
		<view class="sure" @click="confirm">
			确定提现
		</view>
	</view>
</template>

<script>
export default {
	data() {
		return {
			cdnUrl:'',
			cash:'',
			show:false,
			moneyValue:'',
			cardMsg:{},
			txcash:0,
			show_style:'',
			wxUserInfo:{
				photo:"",
				name:"",
				
			},
		};
	},
	onShareAppMessage: function () {
	    return {
	      title:'乃小星',
	      path: '/pages/index/index?scene=' + '1-'+uni.getStorageSync('phone')
	    }
	},
	methods: {
		//判断是否实名认证过  未认证则判断是否有银行卡
		init() {
			let self = this
			self.request({
				url:'bashi/api/app.php?c=common/identity_card/checkUserCard',
				data:{
					token:uni.getStorageSync('token')
				}
			}).then(res=>{
				// console.log(res.data.data);
				 if(res.data.data.card_status=='1'){
					 self.getWxUserInfo()
				  }else if(res.data.data=='0'){
					  uni.showModal({
					  	title: '提示',
					  	content: '实名认证正在审核中，请耐心等待',
					  	showCancel:false,
					  	success: function success(res) {
					  		if (res.confirm) {
					  			uni.navigateBack({
					  				delta:1
					  			})
					  		}
					  	}
					  });
				  }else if(res.data.data=='-1'){
					  uni.showModal({
						title: '提示',
						content: '实名认证未通过，请重新实名认证',
						cancelColor:'#999999',
						confirmText:'去实名',
						confirmColor:'#3EA3E1',
						success: function success(res) {
							if (res.confirm) {
								uni.navigateTo({
									url:'/pages/my/identify'
								})
							}else{
								uni.navigateBack({
									delta:1
								})
							}
						}
					  });
				  }else{
					  uni.showModal({
					  	title: '提示',
					  	content: '尚未实名认证，请先实名认证',
					  	cancelColor:'#999999',
					  	confirmText:'去实名',
					  	confirmColor:'#3EA3E1',
					  	success: function success(res) {
					  		if (res.confirm) {
					  			uni.navigateTo({
					  				url:'/pages/my/identify'
					  			})
					  		}else{
					  			uni.navigateBack({
					  				delta:1
					  			})
					  		}
					  	}
					  });
				  }
			},rej=>{
				console.log(rej)
			})
		},
		//获取个人信息
		getWxUserInfo(){
			let self = this
			self.request({
				url:'bashi/api/app.php?c=personal/getPersonalInfo',
				data:{
					token:uni.getStorageSync('token')
				}
			}).then(res=>{
				 if(res.data.success){
					 self.wxUserInfo=res.data.data.user_data
					// if(res.data.data.length==0){
					// 	uni.showModal({
					// 		title: '提示',
					// 		content: '尚未绑定银行卡，请先去绑定',
					// 		cancelColor:'#999999',
					// 		confirmText:'去绑定',
					// 		confirmColor:'#3EA3E1',
					// 		success: function success(res) {
					// 			if (res.confirm) {
					// 				uni.navigateTo({
					// 					url:'/pages/my/myCard'
					// 				})
					// 			}else{
					// 				uni.navigateBack({
					// 					delta:1
					// 				})
					// 			}
					// 		}
					// 	});
					// }else{
						self.show = true
					// 	self.cardMsg = res.data.data[0]
					// 	// 隐藏身份证中间的数字
					// 	self.cardMsg.card_number=self.cardMsg.card_number.replace(/(\d{4})\d+(\d{3})$/, "$1 **** **** **** $2")
					// }
				  } else {
				    uni.showToast({
						icon:'none',
						title:res.data.message
					})
				  }
			},rej=>{
				console.log(rej)
			})
		},
		//获取输入的金额
		getMoney(e){
			this.moneyValue=e.detail.value
		},
		//清除输入的金额
		delMoney(){
			this.moneyValue=''
		},
		getAll(){
			this.moneyValue = this.txcash
			
		},
		confirm(){
			let self = this
			if(self.moneyValue==''){
				uni.showToast({
					icon:'none',
					title:'请输入提现金额'
				})
			}else if(Number(self.moneyValue)>Number(self.txcash)){
				uni.showToast({
					icon:'none',
					title:'余额不足'
				})
			}else{
				self.request({
					url:'bashi/api/app.php?c=card/user_apply_withdraw',
					data:{
						token:uni.getStorageSync('token'),
						cash_amount:Number(self.moneyValue)*100
					}
				}).then(res=>{
					 if(res.data.success){
						uni.showToast({
							title:res.data.msg
						})
						let time=res.data.date
						setTimeout(res=>{
							uni.reLaunch({
								url:"../publicPages/status?type=3"+'&timeValue='+time
							})
								// url:'/pages/my/withdrawalSuccess?money='+self.moneyValue
						},1000)
					  } else {
					    uni.showToast({
							icon:'none',
							title:res.data.msg
						})
					  }
				},rej=>{
					console.log(rej)
				})
			}
		},
		// init2用于获取提现记录
		init2(){
			let self = this
			self.request({
				url:'bashi/api/app.php?c=card/get_bank_info',
				data:{
					token:uni.getStorageSync('token')
				}
			}).then(res=>{
				self.show_style=res.data.data.show_style
			},rej=>{
				console.log(rej)
			})
		}
	},
	onShow() {
		this.init()
		this.init2()
		this.cdnUrl=this.$cdnUrl
	},
	onLoad(options) {
		this.cash = options.cash
		this.txcash=options.txcash
	}
};
</script>

<style>
	page{
		background-color: #f8f8f8;
	}
	.cardMsg{
		/* width: 550rpx; */
		/* height: 70rpx; */
		background: #555555;
		border-radius: 30rpx 30rpx 0rpx 0rpx;
		margin: 102rpx 54rpx 0;
		display: flex;
		align-items: center;
		padding: 45rpx;
	}
	.card_img{
		width: 78rpx;
		height: 78rpx;
	}
	.card_img image{
		width: 78rpx;
		height: 78rpx;
		border-radius: 50%;
	}
	.card_msg{
		width: 430rpx;
		padding-left: 20rpx;
		color: #fff;
	}
	.card_num{
		font-size: 24rpx;
	}
	.card_name{
		font-size: 24rpx;
		margin-top: 10rpx;
	}
	.card_choose{
		width: 40rpx;
		height: 40rpx;
	}
	.card_choose image{
		width: 40rpx;
		height: 40rpx;
	}
	.money{
		width: 100%;
		padding: 30rpx 30rpx 0 30rpx;
		height: 285rpx;
		background: #FFFFFF;
		box-shadow: 0px 5rpx 7rpx 0px rgba(0, 0, 0, 0.15);
		box-sizing: border-box;
	}
	.word{
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #333333;
	}
	.ipt{
		position: relative;
		padding: 0 80rpx 0 40rpx;
		margin-top: 40rpx;
		border-bottom: 1rpx solid #DFDFDF;
	}
	.money_mark{
		position: absolute;
		bottom: 10rpx;
		left: 0;
		font-size: 36rpx;
		font-family: HiraginoSansGB;
		font-weight: bold;
		color: #212121;
	}
	.ipt input{
		/* border-bottom: 1rpx solid #DFDFDF; */
		height: 80rpx;
		line-height: 80rpx;
	}
	.ipt .current{
		color: #333;
		font-size: 64rpx;
		font-weight: bold;
	}
	.del_money{
		position: absolute;
		bottom: 0;
		right: 0;
		width: 80rpx;
		height: 80rpx;
	}
	.del_money image{
		width: 30rpx;
		height: 30rpx;
		margin: 25rpx;
	}
	.left_monry{
		height: 90rpx;
		line-height: 90rpx;
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #999999;
		position: relative;
	}
	.all_money{
		position: absolute;
		top: 0;
		right: 0;
		height: 90rpx;
		line-height: 90rpx;
		padding-left: 40rpx;
		color: #509EE0;
		font-size: 24rpx;
	}
	.rule{
		padding: 40rpx;
		display: flex;
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #999999;
	}
	.rule_right{
		flex: 1;
		line-height: 40rpx;
	}
	.sure{
		width: 690rpx;
		height: 90rpx;
		background: #3EA4E1;
		border-radius: 45rpx;
		margin: 50rpx 30rpx 0;
		line-height: 90rpx;
		text-align: center;
		color: #fff;
		font-size: 30rpx;
	}
</style>
