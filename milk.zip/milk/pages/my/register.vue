<!-- 推荐分享 -->
<template>
	<view v-if="resur"  style="width: 100%;height: 100%;">
		<!-- <image :src='cdnUrl+"bashi/image/regesterBgc.png"' class="bgc1"></image>
		<image :src='cdnUrl+"bashi/image/regesterBgc1.png"' class="bgc2"></image>
		<image :src='cdnUrl+"bashi/image/regesterBgc2.png"' class="bgc3"></image>
		<image :src="qrcode_url" class="bgc4"></image>
		<view class="butt">
			<button class="share" @click="bendi()">
				保存到相册
			</button>
			<button class="share1" open-type="share">
				分享到微信
			</button>
		</view> -->
		<view class="bgc">
			<image :src='cdnUrl+"bashi/image/money.png"' class="img1"></image>
			<image :src='cdnUrl+"bashi/image/sharePacket1.png"' class="img2"></image>
			<view class="img3">
				<image src="../../static/ewmimg.png"></image>
				<image :src="qrcode_url" class="img4"></image>
				<view class="text">打开微信扫一扫立刻进入小程序</view>
			</view>
			<!-- <view style="width: 100%;height: 100%;">
				<image :src="qrcode_url"></image>
			</view> -->
			<view style="display: flex;justify-content: space-between;">
				<button class="btn"  @click="bendi()">保存到相册</button>
				<button class="btn1" open-type="share">分享到微信</button>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				img: '',
				cdnUrl: '',
				baseUrl: '',
				token: uni.getStorageSync('token'),
				qrcode_url: '',
				qrcode_all: '',
				// hintShow:false,//分享消费不足提示框
				// use_money:'',
				resur: false,
			}
		},
		methods: {
			init() {
				if (uni.getStorageSync('token')) {
					let self = this
					uni.showLoading({
						title: '加载中'
					});
					self.request({
						url: 'bashi/api/app.php?c=statistics/productQrcode',
						data: {
							token: uni.getStorageSync('token'),
						},
					}).then(res => {
						if (res.data.success) {
							// uni.setStorageSync('ewm',self.cdnUrl + res.data.data.qrcode_url1 + '?s=' + Math.floor(Math.random()*10));
							// uni.setStorageSync('all',self.cdnUrl + res.data.data.qrcode_url2);
							self.qrcode_url = self.cdnUrl + res.data.data.qrcode_url1 + '?s=' + Math.floor(Math.random()*10);
							self.qrcode_url2 = self.cdnUrl + res.data.data.qrcode_url2 + '?s=' + Math.floor(Math.random()*10);
							// 产生随机数   +'?s=Math.floor(Math.random()*10)'
							self.qrcode_all = self.cdnUrl + res.data.data.qrcode_url2;
							uni.hideLoading();
							self.resur = true;
						}
					})
				}
			},

			// 图片保存到本地
			bendi() {
				let self = this;
				// 特别注意要先获取图片信息在进行保存，否则不让保存
				uni.getImageInfo({
					src:self.qrcode_all,
					success:function(image){
						uni.saveImageToPhotosAlbum({
							filePath: image.path,
							success: function() {
							},
							fail: function(error) {
								uni.authorize({
									scope: 'scope.userLocation',
									success() { //1.1 允许授权
										console.log(error);
									},
									fail() { //1.2 拒绝授权
										uni.showModal({
											content: '检测到您没打开获取信息功能权限，是否去设置开？',
											confirmText: "确认",
											cancelText: '取消',
											success: (res) => {
												if (res.confirm) {
													uni.openSetting({
														success: (res) => {
															// console.log(res);
															self.bendi();
														}
													})
												} else {
													return false;
												}
											}
										})
										return false;
									}
								});
							}
						})
						
						// 查看大图保存图片
						// let urls = [];
						// urls.push(image.path)
						//  uni.previewImage({
						//       current: image.path,
						//       urls: urls
						// });
						
					}
				})
			},
		},
		onShareAppMessage: function() {
			return {
				title: '乃小星',
				path: '/pages/index/index?scene=' + '1-'+uni.getStorageSync('phone')
			}
		},
		onShow() {
			this.cdnUrl = this.$cdnUrl
			this.baseUrl = this.$baseUrl
			// if (uni.getStorageSync('ewm')) {
			// 	this.qrcode_url = uni.getStorageSync('ewm');
			// 	this.resur = true
			// } else {
				this.init();
			// }
		}
	}
</script>

<style>
	page {
		width: 100%;
		height: 100%;
		/* overflow: hidden; */
		background: linear-gradient(1deg,#6CC3FA, #2BAEFF);
		position: relative;
	}
	/* page image {
		width: 100%;
		height: 100%;
	} */
.bgc {
	position: absolute;
	width: 100%;
	height: 100%;
}
.bgc image{
	width: 100%;
	height: 100%;
}
.bgc .img1 {
	width: 100%;
	height: 666rpx;
}
.bgc .img2 {
	position: absolute;
	left: 90rpx;
	top: 100rpx;
	width: 565rpx;
	height: 89rpx;
}
.bgc .img3 {
	position: absolute;
	left: 120rpx;
	top: 540rpx;
	width: 511rpx;
	height: 511rpx;
}
.bgc .img3 .text {
	position: absolute;
	left: 90rpx;
	bottom: 50rpx;
	font-size: 24rpx;
	font-family: PingFang SC;
	font-weight: 400;
	color: #999999;
}
.bgc .img3 .img4 {
	position: absolute;
	left: 100rpx;
	top: 70rpx;
	width: 307rpx;
	height: 306rpx;
}
.btn {
	width: 330rpx;
	height: 88rpx;
	background: linear-gradient(1deg, #FFD26E, #FFF18A);
	border-radius: 44rpx;
	text-align: center;
	line-height: 88rpx;
	font-size: 40rpx;
	font-family: Adobe Heiti Std;
	font-weight: normal;
	color: #FE6600;
	position: fixed;
	left: 30rpx;
	bottom: 10rpx;
}
.btn1 {
	width: 330rpx;
	height: 88rpx;
	background: linear-gradient(1deg, #FFD26E, #FFF18A);
	border-radius: 44rpx;
	text-align: center;
	line-height: 88rpx;
	font-size: 40rpx;
	font-family: Adobe Heiti Std;
	font-weight: normal;
	color: #FE6600;
	position: fixed;
	right: 30rpx;
	bottom: 10rpx;
}
</style>
