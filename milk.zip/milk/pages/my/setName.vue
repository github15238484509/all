<template>
	<view class="">
		<view class="userList">
			<view class="">
				昵称
			</view>
			<view style="flex: 1;">
				<input type="text" :value="name" maxlength="8" placeholder="请输入昵称~" @input="getName"/>
			</view>
		</view>
		
		<view class="sure" @click="sure">
			确定
		</view>
	</view>
</template>

<script>
	export default{
		data() {
			return {
				name:'',
				sex:''
			}
		},
		onShareAppMessage: function () {
		    return {
		      title:'乃小星',
		      path: '/pages/index/index?scene=' + '1-'+uni.getStorageSync('phone')
		    }
		},
		methods:{
			getName(e){
				this.name=e.detail.value
			},
			sure(){
				let self = this
				if(self.name==''){
					uni.showToast({
						icon:'none',
						title:'昵称不能为空'
					})
				}else{
					self.request({
						url:"bashi/api/app.php?c=personal/setMyInfo",
						data:{
							token:uni.getStorageSync('token'),
							name:self.name,
							sex:self.sex
						},
						}).then(res=>{
							if(res.data.success){
								uni.showToast({
									title:res.data.msg
								})
								setTimeout(function(){
									uni.navigateTo({
										url:'./userInfo'
									})
								},500)
							}else{
								uni.showToast({
									icon:'none',
									title:res.data.msg
								})
							}
						},rej=>{
							console.log(rej)
						})
					 
				}
			}
		},
		onLoad(option) {
			this.name=option.name
		}
	}
</script>

<style lang="scss">
	.userList{
		display: flex;
		padding: 20rpx 30rpx;
		height: 80rpx;
		line-height: 80rpx;
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #333333;
		input{
			width: 100%;
			height: 80rpx;
			line-height: 80rpx;
			margin-left: 30rpx;
		}
	}
	.sure{
		margin: 500rpx 30rpx 0;
		height: 90rpx;
		line-height: 90rpx;
		text-align: center;
		background: #3FA2E0;
		border-radius: 45px;
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #FFFFFF;
	}
</style>
