<!-- 新闻详情页面 -->
<template>
	<view>
		<web-view :src="src"></web-view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				src:''
			}
		},
		onShareAppMessage: function () {
		    return {
		      title:'乃小星',
		      path: '/pages/index/index?scene=' + '1-'+uni.getStorageSync('phone')
		    }
		},
		onLoad(option){
			this.src=this.$cdnUrl+option.src
		},
		methods: {
			
		}
	}
</script>

<style>

</style>

