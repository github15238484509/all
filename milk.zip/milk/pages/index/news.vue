<!-- 新闻列表 -->
<template>
	<view class="">
		<view class="news_list" v-for="(item, i) in news_list" :key="i" @click="goNews(item.url)">
			<view style="display:flex;justify-content: space-between;">
				<view class="news_title">{{ item.title }}</view>
				<view class="news_time">{{ formatTime(item.time) }}</view>
			</view>
			<view class="news_itro">{{ item.edit_user }}</view>
		</view>
	</view>
</template>

<script>
// import { formatTime } from '@/until/common.js';
export default {
	data() {
		return {
			news_list: []
		};
	},
	onShareAppMessage: function () {
	    return {
	      title:'乃小星',
	      path: '/pages/index/index?scene=' + '1-'+uni.getStorageSync('phone')
	    }
	},
	methods: {
		init() {
			let self = this;
			this.request({
				url: 'bashi/api/app.php?c=account/appGongGao'
				// data: {
				// 	token: uni.getStorageSync('token')
				// },
			}).then(res=>{
				self.news_list = res.data.data;
			},rej=>{
				// 打印日志或弹窗提示
				console.log(rej)
			})
		},
		goNews(e) {
			uni.navigateTo({
				url: './common?src=' + e
			});
		}
	},
	onShow() {
		this.init();
	}
};
</script>

<style lang="scss">
.news_list {
	padding: 20rpx 30rpx;
	border-bottom: 1px solid #f5f5f5;
	.news_title {
		font-size: 30rpx;
		flex: 1;
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
	}
	.news_time {
		color: #999;
		font-size: 26rpx;
	}
	.news_itro {
		color: #666;
		font-size: 26rpx;
		margin-top: 10rpx;
	}
}


</style>
