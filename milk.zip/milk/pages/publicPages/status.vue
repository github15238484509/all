<template>
	<view class="main-box">
		<view class="content">
			<view class="content-top">
				<view class="dot">
				</view>
				<view class="">
					<view class='line1'>信息提交成功,等待审核</view>
					<view class='line2' v-if="previousPage==3">{{goodsDailList.submit_time}}</view>
					<view class='line2' v-if="previousPage==4">{{$timeConvert(goodsDailList.extract_time)}}</view>
					<view class='line2' v-if="previousPage==1||previousPage==2">{{$timeConvert(goodsDailList.submit_time)}}</view>
				</view>
			</view>
			<view class="content-btm" v-if="goodsDailList.payment_status==2||goodsDailList.msg=='注销审核已拒绝'">
				<view class="dot">
					
				</view>
				<view class="">
					<view class='line1'>信息审核失败</view>
					<view class='line2'>{{$timeConvert(goodsDailList.audit_time)}}</view>
					<view class='line3'>
						失败原因：{{goodsDailList.refund_reason}}  
						<text style="color: #4794FF;margin-left: 10rpx;" @click="goGoodAdd">重新提交</text>
					</view>
				</view>
				
			</view>
			<view class="content-btm" v-if="goodsDailList.payment_status==1">
				<view class="dot">
					
				</view>
				<view class="">
					<view class='line1'>信息审核成功</view>
					<view class='line2'>{{$timeConvert(goodsDailList.audit_time)}}</view>
				</view>
				
			</view>
			<view class="dot-line" v-if="goodsDailList.payment_status==2||goodsDailList.payment_status==1||goodsDailList.msg=='注销审核已拒绝'">
				
			</view>
		</view>
		<view class="btm">
			审核时间为1-3天，如有疑问请联系客服
		</view>
	</view>
</template>

<script>
	import {fmoney} from '@/until/app.js'
	export default {
		data() {
			return {
				goodsDailList:{
					submit_time:"",
					
				},// 审核进度信息
				requestUrl:"",//请求的接口地址
				requestData:{},//请求的接口需要的参数
				previousPage:"",//从哪个页面跳转来的
				cash:"",//账户余额
				txcash:'',
			}
		},
		onLoad(e){
			console.log(e)
			this.previousPage=e.type
			if (e.type==2){
				this.goodsDailList.submit_time=e.timeValue
				this.goodsDailList.refund_reason=e.reason
				this.goodsDailList.audit_time=e.out_time
				this.goodsDailList.msg=e.msg
			}
			if (e.type==3){
				this.goodsDailList.submit_time=e.timeValue
			}else if(e.type==4){
				this.requestUrl='bashi/api/app.php?c=order/TransactionStatus'
				this.requestData={
					id:e.withdrawalStatusIndex
				}
				this.getRequest()
			}else if(e.type==1){
				this.goodsDailList.submit_time=e.timeValue
			}
			// e.type==3?this.requestUrl="":e.type==2?this.requestUrl==""
			
		},
		onShow(){
			if(this.previousPage==4)this.init()
		},
		methods: {
			// 拿到该有的信息
			init(){
				let self = this
				self.request({
					url:'bashi/api/app.php?c=personal/getMyCash',
					data:{
						token:uni.getStorageSync('token')
					}
				}).then(res=>{
					if(res.data.success){
						self.cash=fmoney(res.data.data.cash/100,2)
						self.txcash = res.data.data.cash/100
					}else{
						uni.showToast({
							icon:'none',
							title:res.data.msg
						})
					}
				})
			},
			// 重新提交
			goGoodAdd(){
				if(this.previousPage==4){
					uni.reLaunch({
						url:'/pages/my/withdrawal?cash='+this.cash+'&txcash='+this.txcash
					})
				}
				if (this.previousPage==2){
					uni.reLaunch({
						url:'../my/cancelAccount'
					})
				}
			},
			// 请求不同的进度接口
			getRequest(){
				let self=this
				self.request({
					url:self.requestUrl,
					data:self.requestData
				}).then(res => {
				        if (res.data.success) {
							self.goodsDailList=res.data.data
				        } else {
				                uni.showToast({
				                title: res.message,
				                icon: 'none'
				                })
				        }
				})
			},
		}
	}
</script>

<style lang="scss" scoped>
		.btm{
			width: 100%;
			position: fixed;
			left: 50%;
			bottom: 20rpx;
			transform: translate(-50%,-50%);
			font-size: 26rpx;
			text-align: center;
			font-weight: 500;
			color: #999999;
		}
		.main-box{
			overflow: hidden;
		}
		.content{
			margin-left: 60rpx;
			position:relative;
			margin-top:50rpx
			
		}
		.content-top{
			display: flex;
			align-items: center;
			margin-top: 50rpx;
			font-size: 24rpx;
			color: #999999;
			.line1{
				font-size: 26rpx;
				color: #333333;
			}
			.line2{
				font-size: 24rpx;
				color: #999999;
			}
		}
		.content-btm{
			display: flex;
			align-items: center;
			margin-top: 65rpx;
			font-size: 24rpx;
			color: #999999;
			.line1{
				font-size: 26rpx;
				color: #333333;
			}
			.line2{
				font-size: 24rpx;
				color: #999999;
			}
			.line3{
				font-size: 24rpx;
					color: #999999;
			}
		}
		.dot{
			width: 20rpx;
			height: 20rpx;
			background: #4794FF;
			border-radius: 50%;
			margin-right: 16rpx;
		}
		.dot-line{
			width: 2rpx;
			height: 80rpx;
			left: 10rpx;
			top: 30%;
			background: #4794FF;
			position: absolute;
		}
</style>

