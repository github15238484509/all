<!-- 退款审核进度页面 -->
<template>
	<view>
		<!-- steps步骤条  纵向排列-->
		<uni-steps :options="options" direction="column" :active="0" v-if="statedata.check_status=='未审核'"></uni-steps>
		<view v-if="statedata.check_status=='拒绝'">
			<uni-steps :options="options1" direction="column" :active="2" ></uni-steps>
			<view class="txt">失败原因：{{orderStatus!=2?statedata.check_message:statedata.reason}}<text @click="resubmit()">重新提交</text></view>
		</view>
	</view>
</template>

<script>
	import uniSteps from '@/components/uni-steps/uni-steps.vue'
	import uniIcons from "@/components/uni-icons/uni-icons.vue"
	import formatTime from '@/until/app.js'
	export default {
		components: {uniSteps},
		data() {
			return {
				options:[
					{title:'信息提交成功,等待审核',desc:'2019-04-19 17:27'},
				],//格式源
				options1:[
					{title:'信息提交成功,等待审核',desc:'2019-04-19 17:27'},
					{title:'信息审核失败',desc:'2019-04-19 17:27'},
				],
				active:'0',//当前步骤
				state:'0',//切换审核进度是否成功
				statedata:[],//数据集合
				order_index:'',//订单自增编号
				orderStatus:"",//订单状态(先喝后付?)
			}
		},
		onShareAppMessage: function () {
		    return {
		      title:'乃小星',
		      path: '/pages/index/index?scene=' + '1-'+uni.getStorageSync('phone')
		    }
		},
		methods: {
			// init初始化
			init(){
				if(uni.getStorageSync('token')){
					let self=this
					let requestUrl=''
					self.orderStatus==2?requestUrl='bashi/api/app.php?c=personal/CancelStatus':requestUrl='bashi/api/app.php?c=reserve/refundCheckStatus'
					self.request({
						url:requestUrl,
						data:{
							token:uni.getStorageSync('token'),
							order_index:self.order_index,
						},
					}).then(res=>{
						if(res.data.success){
							self.statedata=res.data.data
							if(self.orderStatus!=2){
								if(self.statedata.check_status=='未审核'){
									self.options[0].desc=self.formatTime(self.statedata.refund_time)
								}
								if(self.statedata.check_status=='拒绝'){
									self.options1[0].desc=self.formatTime(self.statedata.refund_time)
									self.options1[1].desc=self.formatTime(self.statedata.check_time)
								}
							}else{ 
								if(self.statedata.check_status=='未审核'){
									self.options[0].desc=self.formatTime(self.statedata.time)
								}
								if(self.statedata.check_status=='拒绝'){
									self.options1[0].desc=self.formatTime(self.statedata.time)
									self.options1[1].desc=self.formatTime(self.statedata.out_time)
								}
							}

						}else{
							if(res.data.msg=='登录状态失效，请重新登录~！'){
								uni.removeStorageSync('token')
								uni.reLaunch({
									url:'../my/login'
								})
							}else{
								uni.showToast({
									icon:'none',
									title:res.data.msg
								})
							}
						}
					},rej=>{
						console.log(rej)
					})
				}else{
					uni.redirectTo({
						url:'../my/login'
					})
				}
			},
			// 重新提交文字==>转跳到退款申请页面
			resubmit(){
				uni.redirectTo({
					url:'./refund?id='+this.order_index+'&orderStatus='+this.orderStatus
				})
			}
		},
		onLoad(options){
			this.orderStatus=options.orderStatus
			this.cdnUrl=this.$cdnUrl
			this.order_index=options.id
			this.init()
		}
	}
</script>

<style>
.txt {
	font-size: 24rpx;
	font-family: PingFang SC;
	font-weight: 500;
	color:rgb(26, 173, 25);
	margin: -5rpx 50rpx;
}
.txt text {
	color: #3EA4DC;
	margin-left: 20rpx;
}
</style>
