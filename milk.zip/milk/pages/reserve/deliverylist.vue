<!-- 更多领取记录页面 deliverylist -->
<template>
	<view>
		<view class="record">
			<view class="txt"><text></text>历史领取记录</view>
			<block v-if="deliverylist.length!=0">
			<view class="hang" v-for="(item,i) in deliverylist" :key='i'>
					<view class="time">{{item.add_date}} </view>
					<view class="draw" v-if="item.delivery_status==1">
						<view class="txt">已领取</view>
						<view>{{formatTime(item.delivery_time)}}</view>
					</view>
					<view v-else style="color: #333333;">已作废</view>
			</view>
				<!-- <view class="img" @click="more()">
					<image src="../../static/mores.png"></image> 查看更多
				</view> -->
			</block>
			<view class="cent" v-if='deliverylist.length==0'>暂无记录</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				deliverylist:[], // 领取记录
				order_index:'',//订单编号
				lat:'', // 经纬度较小值
				lng:'', //经纬度较大值
				cdnUrl:'',
			}
		},
		onShareAppMessage: function () {
		    return {
		      title:'乃小星',
		      path: '/pages/index/index?scene=' + '1-'+uni.getStorageSync('phone')
		    }
		},
		methods: {
			// 初始化加载数据
			init(){
				if(uni.getStorageSync('token')){
					let self=this
					self.request({
						url:'bashi/api/app.php?c=reserve/reverseInfo',
						data:{
							token:uni.getStorageSync('token'),
							order_index:self.order_index, // 订单编号
							lat:'34.75383', // 经纬度较小值
							lng:'113.67734' //经纬度较大值
						},
					}).then(res=>{
						if(res.data.success){
							self.deliverylist=res.data.data.delivery_list //领取记录
							self.quantityList=res.data.data //订购详情
						}else{
							if(res.data.msg=='登录状态失效，请重新登录~！'){
								uni.removeStorageSync('token')
								uni.reLaunch({
									url:'../my/login'
								})
							}else{
								uni.showToast({
									icon:'none',
									title:res.data.msg
								})
							}
						}
					},rej=>{
						console.log(rej)
					})
				}else{
					uni.redirectTo({
						url:'../my/login'
					})
				}
			},
		},
		onLoad(options){
			this.order_index=options.id
			this.lng=options.lng
			this.lat=options.lat
			this.cdnUrl=this.$cdnUrl
			this.init()
		}
	}
</script>

<style>
/* 领取记录 */
.record {
	width: 100%;
	/* height: 520rpx; */
	padding: 35rpx 30rpx 0;
	padding-right: 0;
	background-color: #FFFFFF;
	font-size: 26rpx;
	font-family: PingFang SC;
	font-weight: 400;
	color: #9A9A9A;
	box-sizing: border-box;
	margin-top: 20rpx;
}
.record .txt text {
	display: inline-block;
	width: 4rpx;
	height: 30rpx;
	background: #3EA4E1;
	margin-right: 10rpx;
	vertical-align: middle;
}
.record .txt {
	font-size: 30rpx;
	font-weight: 500;
	color: #343434;
	box-sizing: border-box;
}
.record .hang {
	display: flex;
	justify-content: space-between;
	border-bottom: 1rpx solid #F5F5F5;
	padding: 20rpx 0;
	align-items: center;
	padding-right: 30rpx;
}
.record .hang .time {
	font-size: 30rpx;
	color: #333333;
	line-height: 90rpx;
}
.record .hang .draw {
	display: flex;
	flex-direction: column;
	text-align: right;
}
.record .hang .draw .txt {
	color: #3DA3E1;
	padding-bottom: 10rpx;
}
.record .img {
	padding: 30rpx 0;
	text-align: center;
}
.record .img image{
	width: 28rpx;
	height: 28rpx;
	vertical-align:bottom;
	padding-right: 10rpx;
}
.record .cent {
	line-height: 400rpx;
	text-align: center;
}
</style>
