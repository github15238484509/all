<!-- 提交续订信息页面 -->
<template>
	<view v-if="resur">
		<!-- 头部地址详情 site(收货地址) -->
		<view style="height: 20rpx;width: 100%;"></view>
		<view class="head1" v-if="quantityList.address[0]!=null">
			<view class="img1" style="display: flex;align-items: center;">
				<image src="../../static/adressIcon.png" style="width: 64rpx;height: 64rpx;"></image>
			</view>
			<view style="margin-left: 30rpx;">
				<view style="display: flex;align-items: center;margin-bottom: 20rpx;">
					<view class="txt" style="margin-right: 20rpx;">{{quantityList.address[0].contacts}}</view>
					<view class="txtAdressPhone">{{quantityList.address[0].phone}}</view>
				</view>
				<view style="font-size: 26rpx;">
					{{quantityList.address[0].province_name+quantityList.address[0].city_name+quantityList.address[0].county_name+quantityList.address[0].full_address+quantityList.address[0].address}}
				</view>
			</view>
		</view>
		<!-- 头部地址详情 site(门店地址) -->
		<view class="head" v-if="quantityList.merchant_name!=''">
			<view class="img1">
				<image :src="cdnUrl+(quantityList.logo)"></image>
			</view>
			<view class="txt">
				<view class="txt1">{{quantityList.merchant_name}}</view>
				<view class="txt1">{{quantityList.merchant_address}}</view>
				<!-- <view class="txt2">提示：已为您推荐距离您最近的领取点</view> -->
			</view>
			<view class="distance">{{quantityList.distance}}
				<image src="../../static/back.png"></image>
			</view>
		</view>
		<!-- 时间选择器 -->
		<view>
			<view class="head-time" style="" @click="selectTime">
				<view class="font-30">开始配送时间</view>
				<view class="font-30" style="color: #999999;display: flex;align-items: center;">{{timeValue}} <img
						src="../../static/back.png" alt="" style="width: 17rpx;height: 32rpx;margin-left: 20rpx;">
				</view>
			</view>
			<u-picker mode="time" v-model="timeListShow" :default-time="timeValue" @confirm="deliveryTime" :start-year="stystemYear"
				:start-month="stystemMonth" :start-day="stystemDay"></u-picker>
		</view>
		<!-- 订购数量 quantityList -->
		<view class="quantity">
			<view class="one" @click="goshop()">
				<view class="img">
					<image :src="cdnUrl+quantityList.goods_icon"></image>
				</view>
				<view class="txt">
					<view class="txt1">{{quantityList.goods_name}}</view>
					<view class="txt2">￥{{quantityList.goods_cost/100}}元/{{danwei}}</view>
				</view>
			</view>
			<view class="two">
				<view class="number">数量</view>
				<view class="vase">
					<block v-for="(item,i) in vase" :key="i">
						<view :class="selectedIndex==i?'bom1':'bom'" @click="vasenum(item.value,i)">
							<view>{{item.text}}</view>
						</view>
					</block>
					<input placeholder="请输入其他数量" type="number" v-model="vasvalue"
						:class="selectedIndex==5?'inpvase1':'inpvase'" @input='getVas' @focus="changeSelectedIndex" />
				</view>
			</view>
			<view class="three">
				<view class="day">每日数量</view>
				<view class="num">
					<input style="text-align: right;" type="number" placeholder="请填写数字" :value="dayNumValue" @input='getValue' />
				</view>
			</view>
		</view>
		<!-- 合计金额 -->
		<view class="sum">
			<view>合计金额</view>
			<view class="money">￥{{total_money}}</view>
		</view>
		<!-- 底部提交按钮 -->
		<view class="butt" @click="butt(total_money)">提交续订信息</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				// 每日数量
				dayNumValue: '',
				// 是否显示时间选择器
				timeListShow: false,
				// 选中的时间戳
				timeStamp: "",
				// site:[],// 地址详情相关信息
				quantityList: {
					distance: ""
				}, //订购数量显示数据
				vase: [], // 选择数量 
				selectedIndex: '0', // 点中状态ID
				vasvalue: '', //用户手动输入的总瓶数
				order_index: '', //原订单id
				order_indexs: '', //新的订单id
				cdnUrl: '',
				total_money: '', //订单总价
				lat: '',
				lng: '',
				goods_count: '',
				goods_index: '',
				// goods_icon:'',
				goods_cost: '',
				good_index: '',
				danwei: '',
				// 选择的年月日
				timeValue: '开始选择时间',
				// 选中的时间戳
				timeStamp: '',
				//保证得到数据后再显示
				resur: false,
				// 系统年月日
				stystemYear: '',
				stystemMonth: '',
				stystemDay: '',
			}
		},
		onShareAppMessage: function() {
			return {
				title: '乃小星',
				path: '/pages/index/index?scene=' + '1-' + uni.getStorageSync('phone')
			}
		},
		methods: {
			// 当光标聚焦在数量框时
			changeSelectedIndex(){
				this.selectedIndex=5,
				this.goods_count=0
			},
			//实时获取输入框的值==>每日的数量
			getValue(e) {
				if (e.detail.value <= 0) {
					uni.showToast({
						icon: 'none',
						title: '至少1份'
					});
				} else if (e.detail.value > this.goods_count) {
					uni.showToast({
						icon: 'none',
						title: '不能超过总数'
					});
					this.dayNumValue = e.detail.value
				} else {
					this.dayNumValue = e.detail.value
				}

			},
			// 选择时间
			selectTime() {
				console.log(this.timeListShow)
				this.timeListShow = true
				console.log(this.timeListShow)
			},
			// 时间选择器确定按钮回调函数
			deliveryTime(e) {
				this.timeValue = e.year + '-' + e.month + '-' + e.day
				this.timeStamp = e.timestamp
			},
			init() {
				uni.showLoading({
					title: '加载中'
				})
				if (uni.getStorageSync('token')) {
					let self = this
					// self.goods_count=30//goods_count的初始值
					self.request({
						url: 'bashi/api/app.php?c=reserve/renewOrderInfo',
						data: {
							token: uni.getStorageSync('token'),
							order_index: self.order_index,
							lat: self.lat, //经纬度较小值
							lng: self.lng, //经纬度较大值
						},
					}).then(res => {
						self.resur = true
						uni.hideLoading()
						if (res.data.success) {
							self.quantityList = res.data.data
							self.vase = res.data.data.list
							self.goods_count = self.vase[0].value
							self.total_money = self.quantityList.goods_cost / 100 * self.vase[0].value
						} else {
							if (res.data.msg == '登录状态失效，请重新登录~！') {
								uni.removeStorageSync('token')
								uni.reLaunch({
									url: '../my/login'
								})
							} else {
								uni.showToast({
									icon: 'none',
									title: res.data.msg
								})
							}
						}
					}, rej => {
						console.log(rej)
					})
				} else {
					uni.redirectTo({
						url: '../my/login'
					})
				}
			},
			// 数量选择
			vasenum(val, id) {
				this.selectedIndex = id
				this.total_money = this.quantityList.goods_cost / 100 * val
				if (val<this.dayNumValue){
					uni.showToast({
					        title:'选择数量小于每日数量',
					        icon:'none'
					})
				}
				this.goods_count = val

				// console.log(val)
			},
			// 手动输入的总瓶数
			getVas(e) {
				this.selectedIndex = 5
				if (e.detail.value == 0) {
					uni.showToast({
						icon: 'none',
						title: '至少1份'
					});
					this.total_money = 0
				} else {
					this.vasvalue = e.detail.value
					if (this.vasvalue != '') {
						this.vasenum(+this.vasvalue)
					}
				}
			},
			// 到商品详情页面
			goshop() {
				uni.navigateTo({
					url: '../commodity/commodity?id=' + this.goods_index
				})
			},
			// 提交续订信息
			butt(total_money) {
				let self = this
				if (self.timeStamp==''){
					uni.showToast({
					        title:'请选择时间',
					        icon:'none'
					})
					return
				}
				if (self.goods_count==0||self.goods_count==''){
					uni.showToast({
					        title:'请选择配送数量',
					        icon:'none'
					})
					return
				}
				if (self.dayNumValue==''){
					uni.showToast({
					        title:'请输入每日数量',
					        icon:'none'
					})
					return
				}
				if (self.dayNumValue>self.goods_count){
					uni.showToast({
					        title:'每日数量大于商品总数',
					        icon:'none'
					})
					return
				}
				self.request({
					url: 'bashi/api/app.php?c=reserve/submitRenewOrder',
					data: {
						token: uni.getStorageSync('token'),
						order_index: self.order_index, // 订单编号
						reverse_count: self.goods_count, //续订数量
						expect_time: self.timeStamp, //选择的时间
						day_count: self.dayNumValue, //选择配送的每日数量
						order_type:1//订单类型（是否为续订订单）
					},
				}).then(res => {
					self.order_indexs = res.data.data.order_index
					if (res.data.success) {
						console.log(self.order_indexs)
						uni.navigateTo({
							url: '../commodity/payment?id=' + self.order_indexs + '&total_money=' +
								total_money
						})
					} else {
						uni.showToast({
							icon: 'none',
							title: res.data.msg
						})
					}
				}, rej => {
					uni.showToast({
						icon: 'none',
						title: res.data.msg
					});
				})
			},
		},
		onLoad(options) {
			this.order_index = options.id
			this.goods_index = options.goodid
			this.lng = options.lng
			this.lat = options.lat
			this.danwei = options.danwei
			// console.log(options.id)
			// console.log(options.lat)
			this.goods_name = options.name
			this.goods_cost = options.cost
			this.goods_icon = options.icon
			this.cdnUrl = this.$cdnUrl
			this.init()
			let myDate = new Date();
			this.stystemYear = myDate.getFullYear();
			this.stystemMonth = myDate.getMonth() + 1;
			this.stystemDay = myDate.getDate() + 3;
			this.timeValue=this.stystemYear+'-'+this.stystemMonth+'-'+this.stystemDay
			this.timeStamp=(Date.parse(new Date())/1000)+(86400*3);
		}
	}
</script>

<style>
	page {
		background-color: #F5F5F5;
		position: relative;
		height: 100%;
	}

	.txtAdressPhone {
		font-size: 26rpx;
		color: #999999;

	}

	.head1 {
		height: 172rpx;
		width: 100%;
		display: flex;
		/* justify-content: space-between; */
		padding: 40rpx 35rpx;
		box-sizing: border-box;
		background-color: #FFFFFF;
	}

	.head-time {
		border-radius: 0 0 10rpx 10rpx;
		background-color: #FFFFFF;
		display: flex;
		justify-content: space-between;
		margin-bottom: 20rpx;
		height: 80rpx;
		line-height: 80rpx;
		padding: 0 30rpx;
	}

	/* 头部 */
	.head {
		/* margin: 20rpx 0; */
		width: 100%;
		/* height: 160rpx; */
		display: flex;
		justify-content: space-between;
		background-color: #FFFFFF;
		border-radius: 10rpx;
	}

	.head .img image {
		width: 60rpx;
		height: 50rpx;
		padding: 50rpx 35rpx 50rpx 30rpx;
		/* box-sizing: border-box; */
		flex: 1;
	}

	.head .img1 image {
		width: 140rpx;
		height: 140rpx;
		/* padding-left: 30rpx; */
		border-radius: 10rpx;
		/* margin-right: 30rpx; */
		padding: 10rpx 35rpx 0 30rpx;
		flex: 1;
	}

	.head .txt {
		flex: 1;
		font-family: PingFang SC;
		font-weight: 400;
		padding: 25rpx 0;
		box-sizing: border-box;
	}

	.head .txt .txt1 {
		font-size: 26rpx;
		color: #343434;
		padding-bottom: 20rpx;
		box-sizing: border-box;
	}

	.head .txt .txt2 {
		font-size: 24rpx;
		color: #9A9A9A;
	}

	.head .distance {
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #40A2E2;
		padding: 70rpx 30rpx 60rpx 50rpx;
	}

	.head .distance image {
		width: 17rpx;
		height: 32rpx;
		vertical-align: middle;
		margin-left: 25rpx;
	}

	/* 订购数量 */
	.quantity {
		width: 100%;
		padding: 30rpx;
		padding-right: 0rpx;
		background-color: #FFFFFF;
		box-sizing: border-box;
	}

	.quantity .one {
		display: flex;
		border-bottom: 2rpx solid #F5F5F5;
		height: 170rpx;
		box-sizing: border-box;
	}

	.quantity .one image {
		width: 140rpx;
		height: 140rpx;
		border-radius: 6rpx;
		margin-right: 25rpx;
	}

	.quantity .one .txt {
		font-size: 28rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #343434;
		padding-right: 35rpx;
		box-sizing: border-box;
		display: flex;
		flex-direction: column;
		justify-content: space-between;
	}

	.quantity .one .txt1 {
		height: 80rpx;
		overflow: hidden;
		text-overflow: ellipsis;
		display: -webkit-box;
		-webkit-line-clamp: 2;
		-webkit-box-orient: vertical;
	}

	.quantity .one .txt2 {
		font-weight: 400;
		color: #289CEC;
		padding-bottom: 50rpx;
	}

	.quantity .two {
		padding-top: 30rpx;
		box-sizing: border-box;
		border-bottom: 2rpx solid #F5F5F5;
		color: #343434;
	}

	.quantity .two .number {
		font-size: 28rpx;
		font-family: PingFang SC;
		font-weight: 500;
		margin-bottom: 20rpx;
	}

	.quantity .two .vase {
		display: flex;
		flex-wrap: wrap;
	}

	.quantity .two .vase .bom {
		width: 10%;
		width: 157rpx;
		height: 54rpx;
		background: #F5F5F5;
		border: 1rpx solid #CCCCCC;
		border-radius: 10rpx;
		font-size: 26rpx;
		font-family: Source Han Sans CN;
		font-weight: 300;
		line-height: 54rpx;
		text-align: center;
		margin-right: 20rpx;
		margin-bottom: 20rpx;
	}

	.quantity .two .vase .bom1 {
		width: 10%;
		width: 157rpx;
		height: 54rpx;
		background: #E2F5FF;
		border: 1rpx solid #3EA4E1;
		border-radius: 10rpx;
		font-size: 26rpx;
		font-family: Source Han Sans CN;
		font-weight: 300;
		line-height: 54rpx;
		text-align: center;
		margin-right: 20rpx;
		margin-bottom: 20rpx;
	}

	.quantity .two .vase .inpvase {
		width: 510rpx;
		height: 54rpx;
		background: #F5F5F5;
		border: 1rpx solid #CCCCCC;
		border-radius: 10rpx;
		padding: 0 20rpx;
		box-sizing: border-box;
		font-size: 26rpx;
		font-family: Source Han Sans CN;
		font-weight: 300;
		color: #999999;
	}

	.quantity .two .vase .inpvase1 {
		width: 510rpx;
		height: 54rpx;
		background: #E2F5FF;
		border: 1rpx solid #3EA4E1;
		border-radius: 10rpx;
		padding: 0 20rpx;
		box-sizing: border-box;
		font-size: 26rpx;
		font-family: Source Han Sans CN;
		font-weight: 300;
		color: #999999;
	}

	.quantity .three {
		display: flex;
		justify-content: space-between;
		padding-top: 35rpx;
		box-sizing: border-box;
		margin-right: 30rpx;
		font-size: 28rpx;
		font-family: PingFang SC;
		font-weight: 400;
	}

	.quantity .three .day {
		color: #343434;
	}

	/* 合计金额 */
	.sum {
		display: flex;
		justify-content: space-between;
		height: 100rpx;
		width: 100%;
		line-height: 100rpx;
		font-size: 28rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #343434;
		background-color: #FFFFFF;
		padding: 0 30rpx;
		margin: 20rpx 0;
		box-sizing: border-box;
	}

	.sum .money {
		color: #3EA4E1;
	}

	/* 底部按钮 */
	.butt {
		position: absolute;
		bottom: 50rpx;
		left: 30rpx;
		width: 690rpx;
		height: 90rpx;
		background: #3EA4E1;
		border-radius: 45rpx;
		line-height: 90rpx;
		text-align: center;
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #FFFFFF;
	}
</style>
