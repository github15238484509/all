<!-- 预定详情页面 -->
<template>
	<view v-if="resur">
		<!-- 都存储在quantityList中  -->
		<!-- 状态 -->
		<view class="state">
			{{quantityList.status_text}}
		</view> 
		<!--门店地址-->
		<view class="vise" v-if="(this.lat!=''||this.lng!='')&&quantityList.status==0" @click="daohang()">
			<view class="img1">
				<image :src="cdnUrl+quantityList.logo"></image>
			</view>
			<view style="margin-left: 30rpx;">
				<view class="txt">{{quantityList.merchant_name}}</view>
				<view class="txt" style="padding-top: 10rpx;">{{quantityList.merchant_address}}</view>
			</view>
			<view class="map">
				<view class="location">
					<image src="../../static/location.png"></image>
				</view>
				<view>{{quantityList.distance}}</view>
			</view>
		</view>
		<!--收货地址-->
		<view class="vise1" v-if="(this.lat!=''||this.lng!='')&&quantityList.status!=0">
			<view class="img1" style="display: flex;align-items: center;">
				<image src="../../static/adressIcon.png" style="width: 64rpx;height: 64rpx;"></image>
			</view>
			<view style="margin-left: 30rpx;">
				<view style="display: flex;align-items: center;margin-bottom: 20rpx;">
					<view class="txt" style="margin-right: 20rpx;">{{quantityList.address[0].contacts}}</view>
					<view class="txtAdressPhone" >{{quantityList.address[0].phone}}</view>
				</view>
				<view style="font-size: 26rpx;">{{quantityList.address[0].province_name+quantityList.address[0].city_name+quantityList.address[0].county_name+quantityList.address[0].full_address+quantityList.address[0].address}}</view>
			</view>
		<!--<view class="map">
				<view class="location">
					<image src="../../static/location.png"></image>
				</view>
				<view>{{quantityList.distance}}</view>
			</view> -->
		</view>
		<view class="vise" @click="getLocation()" v-if="this.lat==''||this.lng==''">
			<view class="img">
				<image src="../../static/house.png"></image>
			</view>
			<view class="txt">您还没有授权定位,无法获取{{quantityList.status==0?'领取门店':'收货地址'}}的位置</view>
			<view class="map">
				<view class="location">
					<image src="../../static/location.png"></image>
				</view>
				<view></view>
			</view>
			
		</view>
		<!-- 订购详情 quantityList -->
		<view class="quantity" @click="goshop(quantityList.goods_index)">
			<view class="one">
				<image class="img1" :src="cdnUrl+quantityList.goods_icon" v-if="goods_status!=3"></image>
				<view class="img" v-if="goods_status==3">
					<image class="icon-image" :src="cdnUrl+quantityList.goods_icon"></image>
					<image class="layer" src="../../static/xiajia.png"></image>
				</view>
				<view class="txt">
					<view class="txt1">{{quantityList.goods_name}}</view>
					<view class="txt2">
						<view>￥{{quantityList.goods_cost/100}}元/{{danwei}}</view>
						<view class="num"> ×{{quantityList.goods_count}}</view>
					</view>
				</view> 
			</view>
			<view class="three">
				<view class="day">每日数量</view>
				<view>{{quantityList.day_count}}份</view>
			</view>
		</view>
		<!-- 合计金额 -->
		<view class="marg">
			<view class="sum">
				<view>合计金额</view>
				<view class="money">￥{{quantityList.order_total_price/100}}</view>
			</view>
			<view class="sum">
				<view>付款的方式</view>
				<view class="money" v-if="quantityList.order_payment==0">余额支付</view>
				<view class="money" v-else-if="quantityList.order_payment==7">后台充值金支付</view>
				<view class="money" v-else-if="quantityList.order_payment==8">余额+微信支付</view>
				<view class="money" v-else-if="quantityList.order_payment==9">后台充值金+微信支付</view>
				<view class="money" v-else-if="quantityList.order_payment==10">先喝奶后付钱</view>
				<view class="money" v-else>微信支付</view>
			</view>
		</view>
		<!-- 订单信息 -->
		<view class="order">
			<view class="txt"><text></text>其他信息</view>
			<view class="serial">
				<view>订单编号：{{quantityList.order_id}}</view>
				<view class="copy" @click="copy(quantityList.order_id)">复制</view>
			</view>
			<view>提交预定时间：{{formatTime(quantityList.order_time)}}</view>
		</view>
		<!-- 领取记录 deliverylist -->
		<view class="record">
			<view class="txt" ><text></text>历史领取记录</view>
			<block v-if="deliverylist.length!=0">
				<view class="hang" v-for="(item,i) in deliverylist" :key='i'>
						<view class="time">{{item.add_date}} </view>
						<view class="draw" v-if="item.delivery_status==1">
							<view class="txt">已领取</view>
							<view>{{formatTime(item.delivery_time)}}</view>
						</view>
						<view v-else style="color: #333333;">已作废</view>
				</view>
				<view class="img" @click="more(lat,lng)">
					<image src="../../static/mores.png"></image> 查看更多
				</view>
			</block>
			<view class="cent" v-if='deliverylist.length==0'>暂无记录</view>
		</view>
		<!-- 底部按钮 -->
		<view class="butt" v-if="goods_status!=3">
			<view class="butt1"  v-if="(quantityList.order_status==2&&quantityList.status!=2)|| (quantityList.order_status==3&&quantityList.status!=2) || (quantityList.order_status==4&&quantityList.status!=2) || (quantityList.order_status==5&&quantityList.status!=2) || (quantityList.order_status==6&&quantityList.status!=2) || (quantityList.order_status==7&&quantityList.status!=2)" @click="renew(quantityList.order_index,quantityList.goods_index)">续订</view>
			
			<view class="butt1" v-if="quantityList.order_status==3&&(quantityList.order_payment!=7&&quantityList.order_payment!=9) || quantityList.order_status==4&&(quantityList.order_payment!=7&&quantityList.order_payment!=9) || quantityList.order_status==5&&(quantityList.order_payment!=7&&quantityList.order_payment!=9)" @click="refund(quantityList)">{{quantityList.status==2?'取消订单':'退款'}}</view><!-- || quantityList.order_status==7 -->
			
			<view class="butt4" v-if="quantityList.order_status==2&&(quantityList.order_payment!=7&&quantityList.order_payment!=9) || quantityList.order_status==6&&(quantityList.order_payment!=7&&quantityList.order_payment!=9)">退款</view>
			
			<!-- <view class="butt1" v-if="quantityList.order_status==3 || quantityList.order_status==4 || quantityList.order_status==7" @click="suspendzt(quantityList.order_index)">暂停配送</view>	 -->
			<view class="butt1" v-if="quantityList.order_status==3" @click="suspendzt(quantityList.order_index)">暂停配送</view>	
			<view class="butt4" v-if="quantityList.order_status==4" >暂停配送中</view>
			<view class="butt4" v-if="quantityList.order_status==6">恢复配送等待期</view>
			<view class="butt1" v-if="quantityList.order_status==5" @click="suspendhf(quantityList.order_index)">恢复配送</view>
			<!-- <view class="butt4" v-if="quantityList.order_status==2 || quantityList.order_status==6">暂停配送</view> -->
			<view class="butt2" v-if="quantityList.order_status==3 && deliverylist[0].delivery_status==0 || quantityList.order_status==4 && deliverylist[0].delivery_status==0 || quantityList.order_status==7 && deliverylist[0].delivery_status==0" @click="receive(quantityList.order_index)">立即领取</view>
			<view class="butt3" v-if="quantityList.order_status==3 && deliverylist[0].delivery_status==1 || quantityList.order_status==4 && deliverylist[0].delivery_status==1 || quantityList.order_status==7 && deliverylist[0].delivery_status==1 || quantityList.order_status==5 || quantityList.order_status==2 || quantityList.order_status==6">立即领取</view>
			<view class="butt2" v-if="quantityList.order_status==9" @click="reparticulars(lat,lng,quantityList)">再次预定</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				state:'', //领取的状态
				quantityList:[], //订购详情
				deliverylist:[], // 领取记录
				draw:true, // 领取记录中的状态
				stutas:'0',// 按钮状态
				order_index:'',//新订单编号
				lat:'', // 经纬度较小值
				lng:'', //经纬度较大值
				cdnUrl:'',
				goods_index:'',//原商品id
				goods_status:'',//商品状态
				res_total_count:'',//剩余待发放的瓶数
				resur:false,
				danwei:'',//价格后的单位
				good_index:'',
				latitude:'',//店铺的维度
				longitude:'',//店铺的经度
			}
		},
		onShareAppMessage: function () {
		    return {
		      title:'乃小星',
		      path: '/pages/index/index?scene=' + '1-'+uni.getStorageSync('phone')
		    }
		},
		methods: {
			// 初始化加载数据
			init(){
				if(uni.getStorageSync('token')){
					let self=this
					uni.showLoading({
					    title: '加载中'
					});
					self.request({
						url:'bashi/api/app.php?c=reserve/reverseInfo',
						data:{
							token:uni.getStorageSync('token'),
							order_index:self.order_index, // 订单编号
							lat:self.lat, // 经纬度较小值
							lng:self.lng, //经纬度较大值
						},
					}).then(res=>{
						// console.log(self.order_index)
						if(res.data.success){
							self.resur=true
							uni.hideLoading()
							self.deliverylist=res.data.data.delivery_list //领取记录
							self.deliverylist.splice(3)//截取前三条数据
							self.latitude=res.data.data.merchant_latitude
							self.longitude=res.data.data.merchant_longitude
							self.quantityList=res.data.data //订购详情
							// 调用价格后边的单位
							self.good_index=self.quantityList.goods_index
							self.request({
								url:'bashi/api/app.php?c=goods_unit',
								data:{
									goods_index:self.good_index
								}
							}).then(res=>{
								self.danwei=res.data.data
							})
						}else{
							if(res.data.msg=='登录状态失效，请重新登录~！'){
								uni.removeStorageSync('token')
								uni.reLaunch({
									url:'../my/login'
								})
							}else{
								uni.showToast({
									icon:'none',
									title:res.data.msg
								})
							}
						}
					},rej=>{
						console.log(rej)
					})
				}else{
					uni.redirectTo({
						url:'../my/login'
					})
				}
			},
			
			// 获取用户当前位置信息==>uni自带样式
			getLocation(){
				let self=this
				uni.getLocation({
					type: 'wgs84',
					success: function (res) {
						console.log(res);
						console.log('当前位置的经度：' + res.longitude);
						console.log('当前位置的纬度：' + res.latitude);
						self.lat = res.latitude;
						self.lng = res.longitude;
						self.init()
					},
					fail:function(rej){
						// 提前向用户发起授权请求
						uni.authorize({
						    scope: 'scope.userLocation',
						    success(){ //1.1 允许授权
						        self.getLocation()
						    },
							fail(){    //1.2 拒绝授权
								uni.showModal({
									content:'检测到您没打开获取信息功能权限，是否去设置打开？',
										confirmText: "确认",
										cancelText:'取消',
										success: (res) => {
											if(res.confirm){
												uni.openSetting({
													success: (res) => {
														// console.log(res);
														self.getLocation();
													}
												})
											}else{
												console.log('取消');
												return false;
											}
										}
								})		                            
								return false;
							}
						});
					}
				});
			},
			
			// 导航点位
			daohang(){
				  let that = this;
				    uni.openLocation({
				      latitude: Number(that.latitude),
				      longitude: Number(that.longitude),
				      scale: 18,
				      address: that.quantityList.merchant_address
				    });
			},
			// 到商品详情页面
			goshop(id){
				if(this.goods_status!=3){
					uni.navigateTo({
						url:'../commodity/commodity?id='+id
					})
				}else{
					uni.navigateTo({
						url:'../my/Nocommunity'
					})
				}
			},
			
			// 复制(uni自带样式)
			copy(id){
				// 设置系统间贴板的内容
				uni.setClipboardData({
					data:id,
					success: function () {
						// 获取系统剪贴板内容
					    uni.getClipboardData({
					        success: function (res) {
					        }
					    });
					}
				});
			},
			// 查看更多领取记录
			more(lat,lng){
				uni.navigateTo({
					url:'./deliverylist?lat='+lat+'&lng='+lng+'&id='+this.order_index
				})
			},
			
			// 底部按钮
			// 立即领取
			receive(){
				let self = this
				uni.showModal({
					title:'领取提示',
					content:'请把领取成功页面展示给领取点 负责人看。',
					success: function (res){
						if(res.confirm){
							self.request({
								url:'bashi/api/app.php?c=reserve/getDelivery',
								data:{
									token:uni.getStorageSync('token'),
									order_index:self.order_index, // 订单编号
								},
							}).then(res=>{
								if(res.data.success){
									var user_amount =res.data.data.user_amount
									self.innerAudioContext.play();
									self.innerAudioContext.onEnded(function(){
										uni.navigateTo({
											url:'./reserveWin?user_amount='+user_amount
										})
									})
								}else{
									uni.showToast({
										icon:'none',
										title:res.data.msg
									})
								}
							},rej=>{
								console.log(rej)
							})
						}
					},
				})
			},
			// 续订按钮
			renew(id,goodid){
				uni.navigateTo({
					url:'./renew?id='+id+'&lng='+this.lng+'&lat='+this.lat+'&goodid='+goodid+'&danwei='+this.danwei
				})
			},
			// 退订按钮
			refund(list){
				let self =this;
				let requestUrl='';
				self.quantityList.status==2?requestUrl='bashi/api/app.php?c=personal/CancelStatus':requestUrl='bashi/api/app.php?c=reserve/refundCheckStatus'
				self.request({
					url:requestUrl,
					data:{
						token:uni.getStorageSync('token'),
						order_index:list.order_index
					}
				}).then(res => {
					console.log(111)
					console.log(res.data.data.refund_time)
					console.log(self.quantityList.status)
					console.log(res.data.data.check_status)
				        if (res.data.data.refund_time!=0&&self.quantityList.status!=2&&res.data.data.check_status!='通过待退款'&&res.data.data.check_status!='退款完成') {
							uni.navigateTo({
								url:"./audit?id="+list.order_index+'&orderStatus='+self.quantityList.status
							})
				        } else if (res.data.data.time!=0&&self.quantityList.status==2&&res.data.data.check_status!='通过待退款'&&res.data.data.check_status!='退款完成'){
							uni.navigateTo({
								url:"./audit?id="+list.order_index+'&orderStatus='+self.quantityList.status
							})
						}else {
							let txt=''
							self.quantityList.status==2?txt='您确定要申请退还剩余商品吗':txt='您确定要申请退还剩余为配送 商品的金额吗'
							uni.showModal({
								title:'提示',
								content:txt,
								success: function (res){
									if(res.confirm){
										uni.navigateTo({
											url:'./refund?id='+list.order_index+'&goods_count='+list.goods_count+'&danwei='+self.danwei+'&good_index='+list.good_index+'&orderStatus='+list.status
										})
									}
								},
							})
				        }
				})
		
			},
			// 暂停配送按钮
			suspendzt(id){
				let self =this;
				uni.showModal({
					title:'提示',
					content:'您确定要暂停配送吗？由于生产和运输原因，您预定的产品还会再配送3天。',
					success: function (res){
						console.log(res)
						if(res.confirm){
							self.request({
								url:'bashi/api/app.php?c=reserve/suspendReserve',
								data:{
									token:uni.getStorageSync('token'),
									order_index:id//订单自增编号
								}
							}).then(res=>{
								if(res.data.success){
									uni.showToast({
										title:res.data.msg
									})
									self.init()
								}else{
									uni.showToast({
										icon:'none',
										title:res.data.msg
									})
								}
							},rej=>{
								uni.showToast({
									icon:'none',
									title:res.data.msg
								})
							})
						}
					}
				})
			},	
			// 恢复配送按钮
			suspendhf(id){
				let self =this;
				uni.showModal({
						title:'提示',
						content:'恢复配送需要重新选择领取点。3天后开始恢复配送，请耐心等待。',
					success: function (res){
						if(res.confirm){
								// 转跳到附近领取点页面
								uni.navigateTo({
									url:'../commodity/nearby?reverseId='+id
								})
						}
					}
				})
			},
			// 再次预定按钮
			reparticulars(lat,lng,list){
				uni.navigateTo({
					url:'../commodity/information?lat='+lat+'&lng='+lng+'&icon='+list.goods_icon+'&name='+list.goods_name+'&goods_cost='+list.goods_cost+'&id='+list.goods_index
				})
			},
			// 音频事件
			music(){
				this.innerAudioContext = uni.createInnerAudioContext();
				this.innerAudioContext.autoplay = false; // 默认为false
				const musics='bashi/music/1.mp3'
				this.innerAudioContext.src = this.cdnUrl+musics
				this.innerAudioContext.onPlay(() => {
				  console.log('开始播放');
				});
				this.innerAudioContext.onError((res) => {
				  console.log(res.errMsg);
				  console.log(res.errCode);
				});
			},
		},
		onLoad(options){
			this.order_index=options.id
			this.goods_status=options.status
			this.goods_index=options.goodid
			this.res_total_count=options.res_total_count
			this.lng=options.lng
			this.lat=options.lat
			// this.getLocation()
		},
		onShow() {
			this.cdnUrl=this.$cdnUrl
			this.getLocation()
			this.music()
		}
	}
</script>

<style>
page {
	background-color: #F5F5F5;
	/* height: 100%; */
	position: relative;
	padding-bottom: 200rpx;
}
/* 状态 */
.state {
	width: 100%;
	padding: 20rpx 30rpx;
	background-color: #3EA4E1;
	font-size: 30rpx;
	font-family: PingFang SC;
	font-weight: 500;
	color: #FFFFFF;
	box-sizing: border-box;
}
/* 地址 */
.vise {
	width: 100%;
	display: flex;
	justify-content: space-between;
	padding: 40rpx 35rpx; 
	box-sizing: border-box;
	background-color: #FFFFFF;
	margin: 20rpx 0;
}
.vise1 {
	width: 100%;
	display: flex;
	/* justify-content: space-between; */
	padding: 40rpx 35rpx; 
	box-sizing: border-box;
	background-color: #FFFFFF;
	margin: 20rpx 0;
}
.vise .img image{
	width: 60rpx;
	height: 50rpx;
	margin-right: 30rpx;
	margin-top: 20rpx;
	flex: 1;
}
.vise .img1 image{
	width: 140rpx;
	height: 140rpx;
	/* padding-left: 30rpx; */
	border-radius: 10rpx;
	/* margin-right: 30rpx; */
	/* padding-right: 35rpx; */
	flex: 1;
}
.vise .txt {
	/* flex: 1; */
	font-size: 30rpx;
	font-family: PingFang SC;
	font-weight: 400;
	color: #343434;
	margin-right: 100rpx;
}
.vise .map {
	display: flex;
	flex-direction: column;
	font-size: 26rpx;
	font-family: PingFang SC;
	font-weight: 400;
	color: #40A2E2;
	align-items: center;
	/* flex: 1; */
	width: 150rpx;
}
.vise .txtAdressPhone{
	font-size: 26rpx;
	color: #999999;
	
}
.vise .location image {
	width: 44rpx;
	height: 40rpx;
}
/* 订购数量 */
.quantity {
	width: 100%;
	padding: 30rpx;
	padding-right: 0rpx;
	background-color: #FFFFFF;
	box-sizing: border-box;
}
.quantity .one {
	display: flex;
	border-bottom: 2rpx solid #F5F5F5;
	box-sizing: border-box;
}
.quantity .one .img1{
	width: 140rpx;
	height: 140rpx;
	border-radius: 6rpx;
	margin-right: 25rpx;
}
.quantity .one .img{
	position: relative;
}
.img .layer{
	position: absolute;
	left: 50%;
	top: 50%;
	transform:translate(-50%,-50%);
	width: 84rpx;
	height: 30rpx;
}
.quantity .one .img .icon-image{
	width: 140rpx;
	height: 140rpx;
	border-radius: 6rpx;
	margin-right: 25rpx;	
}
.img .layer image{
	width: 84rpx;
	height: 30rpx;
	margin-right: 25rpx;
}
.quantity .one .txt {
	font-size: 28rpx;
	font-family: PingFang SC;
	font-weight: 500;
	color: #343434;
	padding-right: 30rpx;
	box-sizing: border-box;
	display: flex;
	flex-direction: column;
	justify-content: space-between;
	flex: 1;
}
.quantity .one .txt1 {
	height: 80rpx;
	overflow: hidden;
	text-overflow: ellipsis;
	display: -webkit-box;
	-webkit-line-clamp: 2;
	-webkit-box-orient: vertical;
}
.quantity .one .txt2 {
	font-weight: 400;
	color: #289CEC;
	padding-bottom: 50rpx;
	display: flex;
	justify-content: space-between;
}
.quantity .one .txt2 .num{
	color: #9A9A9A;
}
.quantity .three {
	display: flex;
	justify-content: space-between;
	padding-top: 35rpx;
	box-sizing: border-box;
	margin-right: 30rpx;
	font-size: 28rpx;
	font-family: PingFang SC;
	font-weight: 400;
}
.quantity .three .day {
	color: #343434;
}
/* 合计金额 */
.marg {
	margin: 20rpx 0;
	padding: 0 30rpx;
	padding-right: 0;
	box-sizing: border-box;
	background-color: #FFFFFF;
}
.sum {
	display: flex;
	justify-content: space-between;
	height: 100rpx;
	width: 100%;
	line-height: 100rpx;
	font-size: 28rpx;
	font-family: PingFang SC;
	font-weight: 400;
	color: #343434;
	border-bottom: 1rpx solid #F5F5F5;
	padding-right: 30rpx;
	box-sizing: border-box;
}
.sum .money {
	font-size: 30rpx;
}
/* 订单信息 */
.order {
	width: 100%;
	padding: 35rpx 30rpx;
	background-color: #FFFFFF;
	font-size: 26rpx;
	font-family: PingFang SC;
	font-weight: 400;
	color: #9A9A9A;
	box-sizing: border-box;
}
.order .txt text {
	display: inline-block;
	width: 4rpx;
	height: 30rpx;
	background: #3EA4E1;
	margin-right: 10rpx;
	vertical-align: middle;
}
.order .txt {
	font-size: 30rpx;
	font-weight: 500;
	color: #343434;
	padding-bottom: 30rpx;
}
.order .serial {
	display: flex;
	justify-content: space-between;
	padding-bottom: 25rpx;
}
.order .serial .copy {
	text-decoration: underline;
	color: #3EA4E1;
}
/* 领取记录 */
.record {
	width: 100%;
	/* height: 520rpx; */
	padding: 35rpx 30rpx 0;
	padding-right: 0;
	background-color: #FFFFFF;
	font-size: 26rpx;
	font-family: PingFang SC;
	font-weight: 400;
	color: #9A9A9A;
	box-sizing: border-box;
	margin-top: 20rpx;
}
.record .txt text {
	display: inline-block;
	width: 4rpx;
	height: 30rpx;
	background: #3EA4E1;
	margin-right: 10rpx;
	vertical-align: middle;
}
.record .txt {
	font-size: 30rpx;
	font-weight: 500;
	color: #343434;
	box-sizing: border-box;
}
.record .hang {
	display: flex;
	justify-content: space-between;
	border-bottom: 1rpx solid #F5F5F5;
	padding: 20rpx 0;
	align-items: center;
	padding-right: 30rpx;
}
.record .hang .time {
	font-size: 30rpx;
	color: #333333;
	line-height: 90rpx;
}
.record .hang .draw {
	display: flex;
	flex-direction: column;
	text-align: right;
}
.record .hang .draw .txt {
	color: #3DA3E1;
	padding-bottom: 10rpx;
}
.record .img {
	padding: 30rpx 0;
	text-align: center;
}
.record .img image{
	width: 28rpx;
	height: 28rpx;
	vertical-align:bottom;
	padding-right: 10rpx;
}
.record .cent {
	line-height: 400rpx;
	text-align: center;
}
/* 底部按钮 */
.butt {
	width: 100%;
	height: 90rpx;
	background-color: #FFFFFF;
	position: fixed;
	bottom: 0;
	left: 0;
	display: flex;
	padding-left: 60rpx;
	justify-content: flex-end;
	box-sizing: border-box;
}
.butt>view {
	min-width: 115rpx;
	height: 60rpx;
	border-radius: 30rpx;
	font-size: 26rpx;
	font-family: PingFang SC;
	font-weight: 400;
	line-height: 60rpx;
	text-align: center;
	margin-right: 20rpx;
	margin-top: 15rpx;
	padding: 0 10rpx;
}
.butt .butt1 {
	background: #FFFFFF;
	border: 1rpx solid #3EA4E1;
	color: #3EA4E1;
}
.butt .butt2 {
	background: #3EA4E1;
	color: #FFFFFF;
}
.butt .butt3 {
	color: #FFFFFF;
	background: #CCCCCC;
}
.butt .butt4 {
	color: #9A9A9A;	
	border: 1px solid #CCCCCC;
}
</style>
