<!-- 领取成功页面 -->
<template>
	<view>
		<view class="one">
			<image :src="cdnUrl+'bashi/image/moneySc.png'"></image>
			<view>领取成功</view>
			<view v-if='oldPage!=2'>获得优惠：{{user_amount/100}}元，已存入余额。</view>
		</view>
		<view class="check" @click="examine()">返回</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				user_amount:'',//返现优惠
				cdnUrl:'',
				oldPage:"",//从哪个状态领取的
			}
		},
		onShareAppMessage: function () {
		    return {
		      title:'乃小星',
		      path: '/pages/index/index?scene=' + '1-'+uni.getStorageSync('phone')
		    }
		},
		methods: {
			// 转跳到查看我的预定页面
			examine(){
				uni.navigateBack({
					delta:1
				})
			},
		},
		onLoad(options) {
			this.cdnUrl=this.$cdnUrl
			this.user_amount=options.user_amount
			this.oldPage=options.type
		}
	}
</script>

<style>
.one{
	text-align: center;
	font-size: 30rpx;
	font-family: PingFang SC;
	font-weight: 500;
	color: #343434;
	padding-top: 150rpx;
}
.one image {
	width: 146rpx;
	height: 185rpx;
	padding-bottom: 50rpx;
}
.check {
	width: 690rpx;
	height: 90rpx;
	background: #3EA4E1;
	border-radius: 45rpx;
	line-height: 90rpx;
	text-align: center;
	font-size: 30rpx;
	font-family: PingFang SC;
	font-weight: 500;
	color: #FFFFFF;
	margin: 50rpx 30rpx;
}
</style>
