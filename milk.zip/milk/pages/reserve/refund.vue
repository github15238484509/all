<!-- 申请退款 -->
<template>
	<view>
		<!-- 本页面所以信息都存储在comment_content中 -->
		<view class="quantity">
			<view class="one">
				<view class="img">
					<image :src="cdnUrl+comment_content.goods_icon"></image>
				</view>
				<view class="txt">
					<view class="txt1">{{comment_content.goods_name}}</view>
					<view class="txt2">
						<view>￥{{comment_content.goods_cost/100}}元/{{danwei}}</view>
						<view class="num"> ×{{comment_content.goods_count}}</view>
					</view>
				</view>
			</view>
			<view class="two">
				<view class="txt1">已领取：{{comment_content.ling_total_count}}</view>
				<view>未领取：{{comment_content.res_total_count}}</view>
				<view>可退份数：{{comment_content.refund_total_count}}</view>
			</view>
		</view>
		<!-- 提示信息 -->
		<view class="hint">
			<view>提示：</view>
			<view class="left">提示：由于生产和运输原因，申请退款三天后停止配送并退还剩余金额
	    至我的余额，故实际退款数量会扣除此三天内的需配送数量。</view>
		</view>
		<!-- 退款数量 -->
		<view class="refund">
			<view class="txt">请选择退款数量</view>
			<view class="number">
				<view @click="delnum()">-</view>
				<input type="number" :value="count" @input="getCount" @blur="blur" /> 
				<view @click="addnum()">+</view>
			</view>
		</view>
		<!-- 退款原因 -->
		<view class="reason">退款原因
			<textarea placeholder="请详细描述您的退款原因" :value='values' @confirm='confirm' @input="getCon"></textarea>
		</view>
		<!-- 添加图片 -->
		<view class="addimg">
			<view v-for="(item, i) in imgs" :key='i' style="display: inline-block; position: relative;">
				<image :src="cdnUrl+item" style="width: 120rpx; height: 120rpx;margin: 0 40rpx 20rpx 0;"></image>
				<image src="../../static/del.png" class="del" @click="del(i)"></image>
			</view>
			<image src="../../static/addtp.png" @click="addImg()"></image>
		</view>
		<!-- 提交申请按钮 -->
		<view class="butt" @click="butt(comment_content.order_index)">提交申请</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				comment_content:[],//退款页面所有的内容
				imgs:[], //存放图片
				order_index:'',//订单id
				cdnUrl:'',
				baseUrl:'',
				refund_total_count: '', //申请退货份数
				count: 1, //申请退货的份数要小于等于可退份数
				values:'',//退款原因
				good_index:'',
				danwei:'',
				orderStatus:"",//订单状态
			}
		},
		onShareAppMessage: function () {
		    return {
		      title:'乃小星',
		      path: '/pages/index/index?scene=' + '1-'+uni.getStorageSync('phone')
		    }
		},
		methods: {
			// init初始化
			init(){
				if(uni.getStorageSync('token')){
					let self=this
					self.request({
						url:'bashi/api/app.php?c=reserve/refundInfo',
						data:{
							token:uni.getStorageSync('token'),
							order_index:self.order_index, // 订单自增编号
						},
					}).then(res=>{
						if(res.data.success){
							self.comment_content=res.data.data
							self.refund_total_count=self.comment_content.refund_total_count
							// // 调用价格后边的单位
							// self.good_index=self.orderLsit.goods_index
							// self.request({
							// 	url:'bashi/api/app.php?c=goods_unit',
							// 	data:{
							// 		goods_index:self.good_index
							// 	}
							// }).then(res=>{
							// 	self.danwei=res.data.data
							// })
						}else{
							if(res.data.msg=='登录状态失效，请重新登录~！'){
								uni.removeStorageSync('token')
								uni.reLaunch({
									url:'../my/login'
								})
							}else{
								uni.showToast({
									icon:'none',
									title:res.data.msg
								})
							}
						}
					},rej=>{
						console.log(rej)
					})
				}else{
					uni.redirectTo({
						url:'../my/login'
					})
				}
				
			},
			
			// 添加数量
			addnum(){
				console.log(this.refund_total_count)
				if(this.count<this.refund_total_count){
					this.count++
				}else{
					uni.showToast({
						icon:'none',
						title:'超过可退份数' 
					})
				}
			},
			// 减少数量
			delnum(){
				if(this.count>1){
					this.count--
				}else{
					uni.showToast({
						icon:'none',
						title:'至少有一份'
					})
				}
			},
			// 当键盘输入时，触发input事件，event.detail = {value}
			getCount(e){
				this.count=e.detail.value
			},
			// 退款数量
			blur(e){
				if(this.count>this.comment_content.refund_total_count){
					uni.showToast({
						icon:'none',
						title:'超过可退份数' 
					})
				}else if(this.count<1){
					uni.showToast({
						icon:'none',
						title:'至少有一份' 
					})
					this.count=1
				}
			}, 
			// 获取输入框中的退款原因
			getCon(e){
				this.values=e.detail.value
			},
			// 添加图片
			addImg(){
				let self = this,
				header = {
				  'Content-Type': 'multipart/form-data'// 获取到一个本地资源的临时文件路径后，可通过此接口将本地资源上传到指定服务器
				};
				uni.chooseImage({
				  count: 1,
				  success: function(res) {
					  uni.showLoading({
					  	title:'加载中'
					  })
					uni.uploadFile({
					  url: self.baseUrl+'bashi/api/app.php?c=common/identity_card/uploadCardImage',//+url地址
					  filePath: res.tempFilePaths.join(','),//临时路径 tempFilePaths
					  name: 'file',
					  method:'POST',
					  formData: {
						identity_img:res.tempFilePaths.join(',')
					  },
					  header: header,
					  success: function(res) {
					  	uni.hideLoading()
					  	let data = JSON.parse(res.data);
					  	if (data.success) {
					  		uni.showToast({
					  			title: '上传成功'
					  		});
					  		self.imgs.push(data.data);
					  	} else {
					  		uni.showToast({
					  			icon: 'none',
					  			title: '上传失败，请重试~'
					  		});
					  	}
					  },fail:function(res){
					  	console.log(res)
					  }
					})
				  }
				})
			},
			// 删除图片
			del(e){
				for(var i =0; i <this.imgs.length;i++){
					if(i==e){
						this.imgs.splice(i,1)
					}
				}
			},
			// 提交按钮
			butt(id){
				let self=this
				let requestUrl=''
				let requestData={}
				self.orderStatus==2?requestUrl='bashiadmin/api.php?c=reserve/CancelOrder':requestUrl='bashi/api/app.php?c=reserve/submitRefund'
				self.orderStatus==2?requestData={
					token:uni.getStorageSync('token'),
					order_index:self.order_index,//订单编号
					status:1,//客户端取消,
					number:self.count,//申请数量
					reason:self.values,//申请原因
					image:self.imgs.join(','),//申请图片 多个用英文逗号分隔
				}:requestData={
					token:uni.getStorageSync('token'),
					order_index:self.order_index,//订单编号
					refund_count:self.count,//申请数量
					refund_reason:self.values,//申请原因
					refund_images:self.imgs.join(','),//申请图片 多个用英文逗号分隔
				}
				if (!self.values) {
					uni.showToast({
						icon:'none',
					    title: '退款原因不能为空',
					    duration: 2000
					});
				}else if(self.count>self.comment_content.refund_total_count){
					uni.showToast({
					        title:'超过可退款数量',
					        icon:'none'
					})
				} else{
					self.request({
						url:requestUrl,
						data:requestData,
						}).then(res=>{
							if (res.data.success) {
								uni.showToast({
									title: res.data.msg
								});
								setTimeout(()=>{
									uni.redirectTo({
										url:'./audit?id='+id+'&orderStatus='+self.orderStatus
									})
								},200)
							} else {
								uni.showToast({
									icon: 'none',
									title: res.data.msg
								});
							}
						},rej=>{
							uni.showToast({
								icon: 'none',
								title: res.data.msg
							});
						})
				}
			},
		},
		onLoad(options){
			this.orderStatus=options.orderStatus
			this.order_index=options.id
			this.danwei=options.danwei
			this.good_index=options.good_index
			// this.refund_total_count=options.goods_count
			this.cdnUrl=this.$cdnUrl
			this.baseUrl=this.$baseUrl
			this.init()
		}
	}
</script>

<style>
page {
	position: relative;
	height: 100%;
}
/* 订购数量 */
.quantity {
	width: 100%;
	padding: 30rpx;
	padding-right: 0rpx;
	box-sizing: border-box;
}
.quantity .one {
	display: flex;
	border-bottom: 2rpx solid #F5F5F5;
	height: 170rpx;
	box-sizing: border-box;
}
.quantity .one image {
	width: 140rpx;
	height: 140rpx;
	border-radius: 6rpx;
	margin-right: 25rpx;
}
.quantity .one .txt {
	font-size: 28rpx;
	font-family: PingFang SC;
	font-weight: 500;
	color: #343434;
	padding-right: 30rpx;
	box-sizing: border-box;
	display: flex;
	flex: 1;
	flex-direction: column;
	justify-content: space-between;
}
.quantity .one .txt1 {
	overflow: hidden;
	text-overflow: ellipsis;
	display: -webkit-box;
	-webkit-line-clamp: 2;
	-webkit-box-orient: vertical;
	height: 80rpx;
}
.quantity .one .txt2 {
	font-weight: 400;
	color: #289CEC;
	padding-bottom: 50rpx;
	display: flex;
	justify-content: space-between;
}
.quantity .one .txt2 .num{
	color: #9A9A9A;
}
.quantity .two {
	display: flex;
	justify-content: flex-end;
	font-size: 26rpx;
	font-family: PingFang SC;
	font-weight: 400;
	color: #3CA4DC;
	padding: 30rpx 30rpx 0;
	box-sizing: border-box;
}
.quantity .two>view {
	margin-left: 70rpx;
}
.quantity .two .txt1 {
	color: #343434;
}
/* 提示信息 */
.hint {
	width: 100%;
	background: #F5F5F5;
	border-radius: 1rpx;
	font-size: 22rpx;
	font-family: PingFang SC;
	font-weight: 400;
	color: #FF3434;
	padding: 15rpx 30rpx;
	box-sizing: border-box;
	display: flex;
}
.hint .left {
	flex: 1;
}

/* 退款数量 */
.refund {
	width: 100%;
	padding: 25rpx;
	padding-right: 0;
	box-sizing: border-box;
	display: flex;
	justify-content: space-between;
	border-bottom: 1rpx solid #F5F5F5;
	align-items: center;
}
.refund .txt {
	font-size: 26rpx;
	font-family: PingFang SC;
	font-weight: 400;
	color: #343434;
}
.refund .number{
	padding-right: 30rpx;
	color: #343434;
	text-align: center;
	line-height: 50rpx;
	display: flex;
	margin: -1rpx;
	height: 50rpx;
}
.refund .number view{
	width: 50rpx;
	height: 50rpx;
	border: 1rpx solid #F5F5F5;
}
.refund .number input {
	/* padding: 0 30rpx; */
	border-top: 1rpx solid #F5F5F5;
	border-bottom: 1rpx solid #F5F5F5;
	display: inline-block;
	width: 100rpx;
	height: 50rpx;
}
/* 退款原因 */
.reason {
	padding: 30rpx;
	box-sizing: border-box;
	font-size: 26rpx;
	font-family: PingFang SC;
	font-weight: 400;
	color: #000000;
}
.reason textarea {
	width: 100%;
	height: 240rpx;
	background: #F5F5F5;
	border-radius: 10rpx;
	margin-top: 20rpx;
	padding: 20rpx;
	color: #9A9A9A;
	box-sizing: border-box;
}
/* 添加图片 */
.addimg {
	padding: 30rpx;
}
.addimg image {
	width: 120rpx;
	height: 120rpx;
	margin-bottom: 20rpx;
}
.addimg .del {
	width: 32rpx;
	height: 32rpx;
	position: absolute;
	top: -20rpx;
	right: 20rpx;
}
/* 提交申请按钮 */
.butt {
	width: 690rpx;
	height: 90rpx;
	background: #40A2E0;
	border-radius: 45rpx;
	position: absolute;
	bottom: 30rpx;
	left: 30rpx;
	font-size: 30rpx;
	font-family: PingFang SC;
	font-weight: 500;
	color: #FFFFFF;
	line-height: 90rpx;
	text-align: center;
}
</style>
