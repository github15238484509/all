<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/6/28
 * Time: 9:28
 */
use jiupian\api\model\alipay\aop\AopClient;
use HoloPHP\server\Server;
use HoloPHP\server\Log;
use jiupian\api\model\ReCharg;
use jiupian\api\model\types\UserRecharge;
use jiupian\api\model\UserConsumer;
use jiupian\api\model\ModelUserCashChange;
use jiupian\api\model\MallGoodOrder;
use jiupian\api\model\types\UserCashChange;
use jiupian\api\model\alipay\Config;
require_once 'baseWeb.php';
$config  = new Config();
$config = $config->getConfig();
$arr=$_POST;
$aop = new AopClient();
$aop->alipayrsaPublicKey = $config["alipay_public_key"];
$result = $aop->rsaCheckV1($arr, $config["alipay_public_key"], $config["sign_type"]);

if($result) {//验证成功
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //请在这里加上商户的业务逻辑程序代


    //——请根据您的业务逻辑来编写程序（以下代码仅作参考）——

    //获取支付宝的通知返回参数，可参考技术文档中服务器异步通知参数列表

    //商户订单号

    $out_trade_no = $_POST['out_trade_no'];

    //支付宝交易号

    $trade_no = $_POST['trade_no'];

    //交易状态
    $trade_status = $_POST['trade_status'];
    $total_fee = $_POST['total_amount'];
    $bank = $_POST['buyer_logon_id']?$_POST['buyer_logon_id']:"支付宝";



    if ($_POST['trade_status'] == 'TRADE_SUCCESS') {
        //判断该笔订单是否在商户网站中已经做过处理
        //如果没有做过处理，根据订单号（out_trade_no）在商户网站的订单系统中查到该笔订单的详细，并执行商户的业务程序
        //请务必判断请求时的total_amount与通知时获取的total_fee为一致的
        //如果有做过处理，不执行商户的业务程序
        //注意：
        //付款完成后，支付宝系统发送该交易状态通知
        $transaction = $_POST['trade_no'];
        $payment_order_id = $_POST['out_trade_no'];
        Log::put("jiupianalipay", "支付宝参数接收完成");
        Log::put("jiupianalipay", json_encode($arr));
        $order = new ReCharg(null, $payment_order_id);
        if ($order->getPayment_status() == 1) {
            Log::put("jiupianalipay", "订单已经处理回调~！");
            die ('fail');
        }
        if (!$order->isExist()) {
            Log::put("jiupianalipay", "订单不存在~！");
            die ('fail');
        }
        if ($order->getOrderID() != $payment_order_id) {
            Log::put("jiupianalipay", "订单不匹配~！");
            die ('fail');
        }
        Log::put("jiupianalipay", "订单校验完成");
        // 判断充值金额和订单金额是否一致，不一致充值失败
        if (Server::environment("prod") && $total_fee *100 != $order->getOrderFee()) {
            Log::put("jiupianalipay", '判断充值金额是否一致失败');
            die ('fail');
        }
        $user = new UserConsumer($order->getConsumerID(), null, null);
        if (!$user->isExist()) {
            Log::put("jiupianalipay", "订单归属用户不存在");
            die ('fail');
        }
        if ($order->getType() == UserRecharge::TYPE_RECHARGE_CENTER) {//充值中心
            $order->stopAutocommit();
            if (! $order->updateReCharg($transaction, $bank)) {
                $order->rollback();
                Log::put("jiupianalipay",'更新充值状态失败');
                die ('fail');
            }
            $before = $user->getCash();
            $later = $before + $order->getOrderFee();
            $res = $user->addCash($order->getOrderFee());
            $expend_cash = new ModelUserCashChange();
            $order_id = $order->getOrderID();
            $res_log = $expend_cash->addDeal($order->getConsumerID(), $before, $later, $order->getOrderFee(), UserCashChange::TYPE_ALIPAY_ADD, 0, $order_id, 0, 0);
            if ($res && $res_log) {
                Log::put("jiupianalipay", "余额充值处理成功完毕");
                $order->commit();
                die('success');
            } else {
                Log::put("jiupianalipay", "余额充值处理失败完毕");
                $order->rollback();
                die('fail');
            }
        } elseif ($order->getType() == UserRecharge::TYPE_MALL_ORDER_PAY) {
            $order->stopAutocommit();
            if (! $order->updateReCharg($transaction, $bank)) {
                $order->rollback();
                Log::put("jiupianalipay",'更新充值状态失败');
                die ('fail');
            }
            $order_id = $order->getOrderID();
            $before = $user->getCash();
            $later = $before + $order->getOrderFee();
            $expend_cash = new ModelUserCashChange();
            $deal_cash = $expend_cash->addDeal($order->getConsumerID(), $before, $later, $order->getOrderFee(), UserCashChange::TYPE_ALIPAY_ADD, 0, $order_id, 0, 0);
            $res_add_cash  = $user->addCash($order->getOrderFee());
            if(!$res_add_cash){
                $order->rollback();
                Log::put("jiupianalipay", '增加用户余额失败');
                die ('fail');
            }
            if (!$deal_cash) {
                $order->rollback();
                Log::put("jiupianalipay", '插入充值记录失败');
                die ('fail');
            }
            /*$before_lebi = $later;
            $later_lebi = $before_lebi - $order->getOrderFee();
            $deal_cash = $expend_cash->addDeal($order->getConsumerID(), $before_lebi, $later_lebi, $order->getOrderFee(), 120, 0, $order_id, 0, 0);
            if (! $deal_cash) {
                $order->rollback();
                Log::put("jiupianalipay",'插入扣款记录失败');
                die ('fail');
            }*/
            /*$user_order = new MallGoodOrder();
            $order_index = $order->getMallOrderId();
            $res_pay = $user_order->payOrder_v2($order_index,$order->getPayType(),$payment_deal_id);
            if(!$res_pay){
                $order->rollback();
                Log::put("jiupianalipay",'更改订单状态失败');
                die ('fail');
            }*/
            /*$total_out_cash = $user->getOneFieldData("total_out_cash");
            $update_out_cash = $user->updateFields("total_out_cash", $total_out_cash + $order->getOrderFee());
            if (!$update_out_cash) {
                $order->rollback();
                Log::put("jiupianalipay", '更新用户累计消耗cash失败');
                die ('fail');
            }*/
            //分润
            $order_index = $order->getMallOrderId();
            Log::put("jiupianalipay", '开始分润');
            $user_order = new MallGoodOrder();
            $res = $user_order->getOrderPay($order_index, $order->getPayment_index(),$order->getPayType());
            if ($res->code == 1) {
                $order->commit();
                Log::put("jiupianalipay", '分润并支付完成');
                die ('success');
            } else {
                $order->rollback();
                Log::put("jiupianalipay", $res->msg);
                die ('fail');
            }
        }else{
            Log::put("jiupianalipay", "支付方式错误");
            die ('fail');
        }
    }else{
        Log::put("jiupianalipay", "支付状态错误");
        die ('fail');
    }
        //——请根据您的业务逻辑来编写程序（以上代码仅作参考）——
}else {
    //验证失败
    Log::put("jiupianalipay","alipay_errorstart");
    Log::put("jiupianalipay","验证签名失败");
    Log::put("jiupianalipay",json_encode($arr));
    Log::put("jiupianalipay","alipay_errorend");
    die ('fail');	//请不要修改或删除
}

?>