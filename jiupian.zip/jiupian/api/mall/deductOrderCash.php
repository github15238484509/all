<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2020/4/13
 * Time: 16:35
 */
use jiupian\api\model\ModelNewProfit;
use jiupian\api\model\UserConsumer;
$id = $_REQUEST['id'];
switch($id){
    case 395:
        $i = 1;
        break;
    case  484:
        $i = 1;
        break;
    case  571:
        $i = 3;
        break;
    case  622:
        $i = 2;
        break;
    case  626:
        $i = 3;
        break;
    default:
        $i = 0;
        break;


}
$profit = new ModelNewProfit($id);
$info = $profit->getInfo();
$userInfo = new UserConsumer();


if($info->mall_cash_user && $info->mall_cash > 0 ){
      $cash_amount = $info->mall_cash*$i;
      $users = $userInfo->getUserById($info->mall_cash_user);
      $phone = $users->phone;
      $a = "手机号- ".$phone." -扣除现金".$cash_amount/100;
      echo $a;
      echo "<br/>";
     echo "<br/>";
}

if($info->mall_bonus_user && $info->mall_bonus > 0 ){
    $cash_amount = $info->mall_bonus*$i;
    $users = $userInfo->getUserById($info->mall_bonus_user);
    $phone = $users->phone;
    $a = "手机号- ".$phone." -扣除积分".$cash_amount/100;
    echo $a;
    echo "<br/>";
    echo "<br/>";
}

if($info->libao_cash_user && $info->libao_cash > 0 ){
    $cash_amount = $info->libao_cash*$i;
    $users = $userInfo->getUserById($info->libao_cash_user);
    $phone = $users->phone;
    $a = "手机号- ".$phone." -扣除现金".$cash_amount/100;
    echo $a;
    echo "<br/>";
    echo "<br/>";
}

if($info->libao_bonus_user && $info->libao_bonus > 0 ){
    $cash_amount = $info->libao_bonus*$i;
    $users = $userInfo->getUserById($info->libao_bonus_user);
    $phone = $users->phone;
    $a = "手机号- ".$phone." -扣除积分".$cash_amount/100;
    echo $a;
    echo "<br/>";
    echo "<br/>";
}

if($info->first_zhizun_userid && $info->first_zhizun_cash > 0 ){
    $cash_amount = $info->first_zhizun_cash*$i;
    $users = $userInfo->getUserById($info->first_zhizun_userid);
    $phone = $users->phone;
    $a = "手机号- ".$phone." -扣除现金".$cash_amount/100;
    echo $a;
    echo "<br/>";
    echo "<br/>";
}

if($info->first_zhizun_user && $info->first_zhizun_bonus > 0 ){
    $cash_amount = $info->first_zhizun_bonus*$i;
    $users = $userInfo->getUserById($info->first_zhizun_user);
    $phone = $users->phone;
    $a = "手机号- ".$phone." -扣除积分".$cash_amount/100;
    echo $a;
    echo "<br/>";
    echo "<br/>";
}

if($info->second_zhizun_userid && $info->second_zhizun_cash > 0 ){
    $cash_amount = $info->second_zhizun_cash*$i;
    $users = $userInfo->getUserById($info->second_zhizun_userid);
    $phone = $users->phone;
    $a = "手机号- ".$phone." -扣除现金".$cash_amount/100;
    echo $a;
    echo "<br/>";
    echo "<br/>";
}

if($info->second_zhizun_user && $info->second_zhizun_bonus > 0 ){
    $cash_amount = $info->second_zhizun_bonus*$i;
    $users = $userInfo->getUserById($info->second_zhizun_user);
    $phone = $users->phone;
    $a = "手机号- ".$phone." -扣除积分".$cash_amount/100;
    echo $a;
    echo "<br/>";
    echo "<br/>";
}

if($info->first_partner_userid && $info->first_partner_cash > 0 ){
    $cash_amount = $info->first_partner_cash*$i;
    $users = $userInfo->getUserById($info->first_partner_userid);
    $phone = $users->phone;
    $a = "手机号- ".$phone." -扣除现金".$cash_amount/100;
    echo $a;
    echo "<br/>";
    echo "<br/>";
}

if($info->first_partner_user && $info->first_partner_bonus > 0 ){
    $cash_amount = $info->first_partner_bonus*$i;
    $users = $userInfo->getUserById($info->first_partner_user);
    $phone = $users->phone;
    $a = "手机号- ".$phone." -扣除积分".$cash_amount/100;
    echo $a;
    echo "<br/>";
    echo "<br/>";
}

if($info->second_partner_userid && $info->second_partner_cash > 0 ){
    $cash_amount = $info->second_partner_cash*$i;
    $users = $userInfo->getUserById($info->second_partner_userid);
    $phone = $users->phone;
    $a = "手机号- ".$phone." -扣除现金".$cash_amount/100;
    echo $a;
    echo "<br/>";
    echo "<br/>";
}

if($info->second_partner_user && $info->second_partner_bonus > 0 ){
    $cash_amount = $info->second_partner_bonus*$i;
    $users = $userInfo->getUserById($info->second_partner_user);
    $phone = $users->phone;
    $a = "手机号- ".$phone." -扣除积分".$cash_amount/100;
    echo $a;
    echo "<br/>";
    echo "<br/>";
}

if($info->first_sushan_userid && $info->first_sushan_cash > 0 ){
    $cash_amount = $info->first_sushan_cash*$i;
    $users = $userInfo->getUserById($info->first_sushan_userid);
    $phone = $users->phone;
    $a = "手机号- ".$phone." -扣除现金".$cash_amount/100;
    echo $a;
    echo "<br/>";
    echo "<br/>";
}

if($info->first_sushan_user && $info->first_sushan_bonus > 0 ){
    $cash_amount = $info->first_sushan_bonus*$i;
    $users = $userInfo->getUserById($info->first_sushan_user);
    $phone = $users->phone;
    $a = "手机号- ".$phone." -扣除积分".$cash_amount/100;
    echo $a;
    echo "<br/>";
    echo "<br/>";
}

if($info->second_sushan_userid && $info->second_sushan_cash > 0 ){
    $cash_amount = $info->second_sushan_cash*$i;
    $users = $userInfo->getUserById($info->second_sushan_userid);
    $phone = $users->phone;
    $a = "手机号- ".$phone." -扣除现金".$cash_amount/100;
    echo $a;
    echo "<br/>";
    echo "<br/>";
}

if($info->second_sushan_user && $info->second_sushan_bonus > 0 ){
    $cash_amount = $info->second_sushan_bonus*$i;
    $users = $userInfo->getUserById($info->second_sushan_user);
    $phone = $users->phone;
    $a = "手机号- ".$phone." -扣除积分".$cash_amount/100;
    echo $a;
    echo "<br/>";
    echo "<br/>";
}

if($info->first_operation_userid && $info->first_operation_cash > 0 ){
    $cash_amount = $info->first_operation_cash*$i;
    $users = $userInfo->getUserById($info->first_operation_userid);
    $phone = $users->phone;
    $a = "手机号- ".$phone." -扣除现金".$cash_amount/100;
    echo $a;
    echo "<br/>";
    echo "<br/>";
}

if($info->first_operation_user && $info->first_operation_bonus > 0 ){
    $cash_amount = $info->first_operation_bonus*$i;
    $users = $userInfo->getUserById($info->first_operation_user);
    $phone = $users->phone;
    $a = "手机号- ".$phone." -扣除积分".$cash_amount/100;
    echo $a;
    echo "<br/>";
    echo "<br/>";
}
if($info->second_operation_userid && $info->second_operation_cash > 0 ){
    $cash_amount = $info->second_operation_cash*$i;
    $users = $userInfo->getUserById($info->second_operation_userid);
    $phone = $users->phone;
    $a = "手机号- ".$phone." -扣除现金".$cash_amount/100;
    echo $a;
    echo "<br/>";
    echo "<br/>";
}
if($info->second_operation_user && $info->second_operation_bonus > 0 ){
    $cash_amount = $info->second_operation_bonus*$i;
    $users = $userInfo->getUserById($info->second_operation_user);
    $phone = $users->phone;
    $a = "手机号- ".$phone." -扣除积分".$cash_amount/100;
    echo $a;
    echo "<br/>";
    echo "<br/>";
}


