<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/6/25
 * Time: 19:14
 */
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use HoloPHP\AutoLoader;
use config\ClentCmd;
use jiupian\api\model\MallGoodOrderBarter;
use jiupian\api\model\MallGood;
use jiupian\api\model\ModelGoodsSku;
use jiupian\api\model\Express;
use jiupian\api\model\ServiceAddress;
use jiupian\api\model\MallGoodOrder;
use jiupian\api\model\ModelUserSupplier;
$R = new \stdClass ();
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
Verify::existsingAll( "token", "device", "service_order_index");
$service_order_index = $_REQUEST["service_order_index"];
$result = array();
$mallGoodOrderBarter = new MallGoodOrderBarter ($service_order_index);
$res = $mallGoodOrderBarter->findOrderBarter ( $service_order_index,$user_id );
if (! $res) {
    exit(HttpResponse::exitJSON(false, "售后订单信息错误", ClentCmd::HINT,$list));
}
$res = $mallGoodOrderBarter->findOrderBarter ( $service_order_index,$user_id );
$mall_goods=new MallGood($res->barter_goods_index);
$result["service_order_index"] = $service_order_index;
$result["barter_goods_name"] = $mall_goods->getFieldsValue("goods_name");
$supplier = new ModelUserSupplier($mall_goods->getFieldsValue("goods_supplier"));
$result["supplier_name"] = $supplier->getName()?:'';
$modelSku = new ModelGoodsSku($res->barter_sku_index);
$result["barter_goods_icon"] = $modelSku->getFieldsValues("sku_pic")?:'';
$result["barter_goods_norms"] = $modelSku->getFieldsValues("sku_name")?:"";
$result["barter_goods_price"] = $res->barter_goods_price;
$result["total_price"] = $res->barter_goods_cost * $res->barter_goods_count;
$result["barter_goods_cost"] = $res->barter_goods_cost;
$result["barter_goods_bonus"] = $res->barter_goods_bonus;
$result["barter_goods_count"] = $res->barter_goods_count;
$result["barter_time"] =  $res->barter_time;
$result["check_time"] =  $res->check_time;
$result["barter_order"] =  $res->barter_order;
switch($res->barter_status){
    case 0:
        $result["step"] = 0;
        break;
    case 1:
        $result["step"] = 1;
        break;
    case 2:
        $result["step"] = 2;
        break;
    case 3:
        $result["step"] = 3;
     /*   $exp = new Express();
        $result["express_number"] = $res->barter_express_number;
        $result["express_name"] = $exp->getExpressNameByCode($res->barter_express_company)?:'';*/
        break;
    case 4:
        $result["step"] = 5;
        $exp = new Express();
        $result["express_number"] = $res->barter_express_number;
        $result["express_name"] = $exp->getExpressNameByCode($res->barter_express_company)?:'';
        break;
    case 5:
        $exp = new Express();
        $result["express_number"] = $res->barter_express_number;
        $result["express_name"] = $exp->getExpressNameByCode($res->barter_express_company)?:'';
        $result["step"] = 5;
        break;
    case 6:
        $exp = new Express();
        $result["express_number"] = $res->merchant_express_number;
        $result["express_name"] = $exp->getExpressNameByCode($res->merchant_express_company)?:'';
        $result["step"] = 5;
        break;
    case 7:
        $exp = new Express();
        $result["express_number"] = $res->merchant_express_number;
        $result["express_name"] = $exp->getExpressNameByCode($res->merchant_express_company)?:'';
        $result["step"] = 6;
        break;
}
if($result["step"] == 3 && $res->barter_express_time){//审核通过未发货
    $result["step"] == 4;
}
$result["stepArr"] = array(
    0 => array(
        "step" => 0,
        "stepName" => "已取消"
    ),
    1 => array(
        "step" => 1,
        "stepName" => "待审核"
    ),
    2 => array(
        "step" => 2,
        "stepName" => "审核拒绝"
    ),
    3 => array(
        "step" => 3,
        "stepName" => "审核通过"
    ),
    4 => array(
        "step" => 4,
        "stepName" => "退货中"
    ),
    5 => array(
        "step" => 5,
        "stepName" => "换新中"
    ),
    6=> array(
        "step" => 6,
        "stepName" => "已完成"
    )
);

$address = new ServiceAddress();
$mall_order = new MallGoodOrder($res->barter_id);
$result["return_address"] = $address->getSupplierAddress_v2($mall_order->getOrderSupplier());
$result["barter_refuse_reason"] = $res->barter_refuse?:'';
exit(HttpResponse::exitJSON(TRUE, "获取售后详情成功", ClentCmd::HINT,$result));