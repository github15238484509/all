<?php
use jiupian\api\model\MallGood;
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use HoloPHP\AutoLoader;
use config\ClentCmd;
use jiupian\api\model\MallGoodOrder;
use jiupian\api\model\MallGoodOrderGoods;
use jiupian\api\model\ModelGoodsSku;
use jiupian\api\model\ModelUserSupplier;
use jiupian\api\model\MallGoodOrderBarter;
use jiupian\api\model\MallGoodOrderRefund;
$orderObj=new MallGoodOrderGoods();
$R = new \stdClass();
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
verify::existsingAll("token", "device", "type", "service_order_index","express_com","express_num" );
// $order_id =2;
$order_id = $_REQUEST ["service_order_index"];
$order_type = $_REQUEST ["type"];
$express_com = $_REQUEST ["express_com"];
$express_num = $_REQUEST ["express_num"];
//0 退货  1换货或维修
if ($order_type==1) {
	$mallGoodOrderRefund = new MallGoodOrderRefund ();
	$res = $mallGoodOrderRefund->findOrderRefund($user_id, $order_id);
	if (! $res) {
        exit(HttpResponse::exitJSON(FALSE, "维修查询id不存在", ClentCmd::HINT));
	}
	if ($res->refund_status!=3) {
        exit(HttpResponse::exitJSON(FALSE, "操作状态错误", ClentCmd::HINT));
	}
	if ($res->express_number!=0||$res->express_company!=0) {
        exit(HttpResponse::exitJSON(FALSE, "不允许修改物流编号", ClentCmd::HINT));
	}
	$info=new \stdClass();
	if ($express_num=="0"&&$express_com=="0") {
		$info->express_number="";
		$info->express_company="";
	}else {
		$info->express_number=$express_num;
		$info->express_company=$express_com;
	}

	$info->order_id=$order_id;
	$res1 = $mallGoodOrderRefund->updateOrderRefundExpress($info, $user_id);
	if (! $res1) {
        exit(HttpResponse::exitJSON(FALSE, "系统繁忙", ClentCmd::HINT));
	}
    exit(HttpResponse::exitJSON(TRUE, "设置物流成功", ClentCmd::HINT));
}elseif ($order_type==2){
	$mallGoodOrderBarter = new MallGoodOrderBarter ();
	$res = $mallGoodOrderBarter->findOrderBarter ( $order_id, $user_id );
	if (! $res) {
        exit(HttpResponse::exitJSON(FALSE, "维修查询id不存在", ClentCmd::HINT));
	}
	if ($res->barter_status!=3) {
        exit(HttpResponse::exitJSON(FALSE, "操作状态错误", ClentCmd::HINT));
	}
	if (!empty($res->barter_express_number)||!empty($res->barter_express_company)) {
        exit(HttpResponse::exitJSON(FALSE, "不允许修改物流编号", ClentCmd::HINT));
	}
	$info=new \stdClass();
	if ($express_num==0&&$express_com==0) {
		$info->express_number="";
		$info->express_company="";
	}else {
		$info->express_number=$express_num;
		$info->express_company=$express_com;
	}
	$info->order_id=$order_id;
	$res1 = $mallGoodOrderBarter->updateOrderBarterExpress($info, $user_id);
	if (! $res1) {
        exit(HttpResponse::exitJSON(FALSE, "系统繁忙", ClentCmd::HINT));
	}
    exit(HttpResponse::exitJSON(TRUE, "设置物流成功", ClentCmd::HINT));
}else {
    exit(HttpResponse::exitJSON(FALSE, "非法操作", ClentCmd::HINT));
}

?>