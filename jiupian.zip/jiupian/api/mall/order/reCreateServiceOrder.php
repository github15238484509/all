<?php
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use HoloPHP\AutoLoader;
use config\ClentCmd;
use jiupian\api\model\MallGoodOrderBarter;
use jiupian\api\model\MallGoodOrderRefund;
use HoloPHP\tools\UUID;
$R = new \stdClass();
Verify::existsingAll ( "token", "service_type", "service_order_index" );
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
$token = $_REQUEST ["token"];
$service_type = $_REQUEST ["service_type"];
$service_order_id = $_REQUEST ["service_order_index"];
$service_order = UUID::order_id ();
if (empty ( $service_order )) {
    exit(HttpResponse::exitJSON(FALSE, "订单提交失败!", ClentCmd::HINT));
}
// 服务类型 2返修换货 1退货
if ($service_type == 2) {
	$mallgood_order_barter = new MallGoodOrderBarter ();
	$mallgood_order_barter->stopAutocommit();
	$res=$mallgood_order_barter->findOrderBarterRemake($service_order_id, $user_id);
	if ($res) {
		foreach ($res as $key=>$val){
			if ($val->barter_status != 2) {//必须审核拒绝才可以再次申请
                $mallgood_order_barter->rollback();
                exit(HttpResponse::exitJSON(FALSE, "不能重复操作!", ClentCmd::HINT));
			}
		}
	}else{
        $mallgood_order_barter->rollback();
        exit(HttpResponse::exitJSON(FALSE, "售后订单号不存在!", ClentCmd::HINT));
	}
	$result= $mallgood_order_barter->findOrderBarter($service_order_id, $user_id);
	if (!$result){
        $mallgood_order_barter->rollback();
        exit(HttpResponse::exitJSON(FALSE, "售后订单号不存在!", ClentCmd::HINT));
	}
	$res = $mallgood_order_barter->remake_mallorder_barter($service_order_id, $user_id,$service_order);
	$res1 = $mallgood_order_barter->updateOrderBarterStatus($service_order_id,$user_id,0);
	if (!$res) {
        $mallgood_order_barter->rollback();
        exit(HttpResponse::exitJSON(FALSE, "网络繁忙!", ClentCmd::HINT));
	}
    $mallgood_order_barter->commit();
    exit(HttpResponse::exitJSON(true, "再次申请成功!", ClentCmd::HINT));
}elseif($service_type == 1){
    $mallgood_order_refund = new MallGoodOrderRefund ();
    $mallgood_order_refund->stopAutocommit();
    $res=$mallgood_order_refund->findOrderRefundRemake($user_id,$service_order_id );
    if ($res) {
        foreach ($res as $key=>$val){
            if ($val->refund_status==1) {
                $mallgood_order_refund->rollback();
                exit(HttpResponse::exitJSON(FALSE, "不能重复操作!", ClentCmd::HINT));
            }
        }
    }
    $result= $mallgood_order_refund->findOrderRefund($service_order_id, $user_id);
    if ($result){
        $mallgood_order_refund->rollback();
        exit(HttpResponse::exitJSON(FALSE, "售后订单号不存在！", ClentCmd::HINT));
    }
    $res = $mallgood_order_refund->remake_mallorder_refund($service_order_id, $user_id,$service_order);
    $res1 = $mallgood_order_refund->updateOrderRefundStatus($service_order_id,$user_id,0);
    if (!$res||!$res1) {
        $mallgood_order_refund->rollback();
        exit(HttpResponse::exitJSON(FALSE, "网络繁忙！", ClentCmd::HINT));
    }
    $mallgood_order_refund->commit();
    exit(HttpResponse::exitJSON(FALSE, "申请成功！", ClentCmd::HINT));
}else{
    exit(HttpResponse::exitJSON(false, "申请售后类型错误!", ClentCmd::HINT));
}
?>
