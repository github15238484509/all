<?php
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use HoloPHP\AutoLoader;
use config\ClentCmd;
use jiupian\api\model\MallGoodOrder;
use jiupian\api\model\MallGoodOrderGoods;
use jiupian\api\model\MallOrderConfirm;
$R = new \stdClass();
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
verify::existsingAll("token", "device", "order_index");
$order_index = $_REQUEST ["order_index"];
$R = new \stdClass ();
$order_index = $_REQUEST['order_index'];
$order = new MallGoodOrder($order_index);
$order_status = $order->getStatus();
$order_consumer = $order->getConsumer();
if($order_consumer != $user_id){
    exit(HttpResponse::exitJSON(FALSE, "订单信息错误", ClentCmd::HINT));
}
/*if($order_status != 0){
    exit(HttpResponse::exitJSON(FALSE, "未取消订单不能删除", ClentCmd::HINT));
}*/
$res = $order->delOrder();
if(!$res){
    exit(HttpResponse::exitJSON(FALSE, "网络异常稍后重试", ClentCmd::HINT));
}else{
    exit(HttpResponse::exitJSON(TRUE, "订单删除成功", ClentCmd::HINT));
}

