<?php
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use HoloPHP\AutoLoader;
use config\ClentCmd;
use jiupian\api\model\MallGoodOrderBarter;
$R = new \stdClass ();
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
verify::existsingAll("token", "device", "service_order_index" );
$order_index = $_REQUEST ["service_order_index"];
$mall_order_barter = new MallGoodOrderBarter ();
$info = $mall_order_barter->findOrderBarter ( $order_index, $user_id );
if (! $info) {
    exit(HttpResponse::exitJSON(FALSE, "系统繁忙", ClentCmd::HINT));
}
if ($info->barter_status == 6) {
	$res = $mall_order_barter->updateOrderBarterStatus ( $order_index, $user_id, 7 );
	if (! $res) {
        exit(HttpResponse::exitJSON(FALSE, "商品暂未发货", ClentCmd::HINT));
	}else {
        exit(HttpResponse::exitJSON(TRUE, "确认收货成功", ClentCmd::HINT));
    }
}else {
    exit(HttpResponse::exitJSON(FALSE, "商品暂未发货", ClentCmd::HINT));
}
?>