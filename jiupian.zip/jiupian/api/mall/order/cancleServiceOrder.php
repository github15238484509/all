<?php
use jiupian\api\model\MallGood;
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use HoloPHP\AutoLoader;
use config\ClentCmd;
use jiupian\api\model\MallGoodOrder;
use jiupian\api\model\MallGoodOrderGoods;
use jiupian\api\model\ModelGoodsSku;
use jiupian\api\model\ModelUserSupplier;
use jiupian\api\model\MallGoodOrderBarter;
use jiupian\api\model\MallGoodOrderRefund;
$orderObj=new MallGoodOrderGoods();
$R = new \stdClass();
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
verify::existsingAll("token", "device","type","service_order_index" );
$order_index = $_REQUEST ["service_order_index"];
if ($_REQUEST ["type"]==2) {
	//执行取消售后服务流程 更新barter_status为0
	$mall_order_barter=new MallGoodOrderBarter();
	$info=$mall_order_barter->findOrderBarter($order_index, $user_id);
	if (!$info) {
        exit(HttpResponse::exitJSON(FALSE, "取消售后失败", ClentCmd::HINT));
	}
	if ($info->barter_status==0) {
        exit(HttpResponse::exitJSON(FALSE, "取消售后失败", ClentCmd::HINT));
	}
	if ($info->barter_status>3) {
        exit(HttpResponse::exitJSON(FALSE, "售后订单号状态不合理不能操作！", ClentCmd::HINT));
	}
	$res=$mall_order_barter->updateOrderBarterStatus($order_index, $user_id);
    $order_goods_index = $info->order_goods_index;
    $result=$orderObj->updateGoodsAfterSale(0,$order_goods_index);
	if (!$res || !$result) {
        exit(HttpResponse::exitJSON(FALSE, "取消售后失败", ClentCmd::HINT));
	}
    exit(HttpResponse::exitJSON(TRUE, "取消售后成功", ClentCmd::HINT));
}elseif ($_REQUEST ["type"]==1){
	//执行取消售后服务流程
	$mall_order_refund=new MallGoodOrderRefund();
	$info=$mall_order_refund->findOrderRefund( $user_id,$order_index);
	if (!$info) {
        exit(HttpResponse::exitJSON(FALSE, "取消售后失败", ClentCmd::HINT));
	}
	//退款 判断是否已结算
    $mallGoodOrder = new MallGoodOrder($info->refund_id);
	if ($info->refund_status==0) {
        exit(HttpResponse::exitJSON(FALSE, "取消售后失败", ClentCmd::HINT));
	}
	if ($info->refund_status>3) {
        exit(HttpResponse::exitJSON(FALSE, "售后订单号状态不合理不能操作！", ClentCmd::HINT));
	}
	$res=$mall_order_refund->updateOrderRefundStatus($order_index, $user_id,0);
    $order_goods_index = $info->order_goods_index;
    $result=$orderObj->updateGoodsAfterSale(0,$order_goods_index);
	if (!$res || !$result) {
        exit(HttpResponse::exitJSON(FALSE, "取消售后失败", ClentCmd::HINT));
	}
    exit(HttpResponse::exitJSON(TRUE, "取消售后成功", ClentCmd::HINT));
}
?>