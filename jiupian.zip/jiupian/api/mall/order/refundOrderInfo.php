<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/6/25
 * Time: 18:12
 */
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use HoloPHP\AutoLoader;
use config\ClentCmd;
use jiupian\api\model\MallGood;
use jiupian\api\model\MallGoodOrderRefund;
use jiupian\api\model\ModelGoodsSku;
use jiupian\api\model\Express;
use jiupian\api\model\ServiceAddress;
use jiupian\api\model\MallGoodOrder;
use jiupian\api\model\ModelUserSupplier;
$R = new \stdClass ();
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
Verify::existsingAll( "token", "device", "service_order_index" );
$service_order_index = $_REQUEST["service_order_index"];
$result = array();
$mallGoodOrderRefund = new MallGoodOrderRefund ($service_order_index);
$res = $mallGoodOrderRefund->findOrderRefund ( $user_id,$service_order_index );
if (! $res) {
    exit(HttpResponse::exitJSON(TRUE, "售后订单信息错误", ClentCmd::HINT,$list));
}
$res = $mallGoodOrderRefund->findOrderRefund ( $user_id,$service_order_index );
$mall_goods=new MallGood($res->refund_goods_index);
$result["refund_goods_name"] = $mall_goods->getFieldsValue("goods_name");
$supplier = new ModelUserSupplier($mall_goods->getFieldsValue("goods_supplier"));
$result["supplier_name"] = $supplier->getName()?:'';
$modelSku = new ModelGoodsSku($res->refund_sku_index);
$result["refund_goods_icon"] = $modelSku->getFieldsValues("sku_pic")?:'';
$result["refund_goods_norms"] = $modelSku->getFieldsValues("sku_name")?:"";
$result["refund_goods_price"] = $res->refund_goods_price;
$result["total_price"] = $res->refund_goods_cost * $res->refund_goods_count;
$result["refund_goods_cost"] = $res->refund_goods_cost;
$result["refund_goods_bonus"] = $res->refund_goods_bonus;
$result["refund_goods_count"] = $res->refund_goods_count;
$result["refund_time"] =  $res->refund_time;
$result["check_time"] =  $res->check_time;
$result["payment_time"] =  $res->payment_time;
$result["refund_order"] =  $res->refund_order;
switch($res->refund_status){
    case 0:
        $result["step"] = 0;
        //$info->text =  "已取消";
        break;
    case 1:
        $result["step"] = 1;
        //$info->text =  "待审核";
        break;
    case 2:
        $result["step"] = 2;
       // $info->text =  "审核拒绝";
        break;
    case 3:
        $result["step"] = 3;
        //$info->text =  "审核通过";
        break;
    case 4:
        $result["step"] = 4;
       // $info->text =  "卖家待收货";
        $result["express_number"] = $res->express_number;
        $exp = new Express();
        $result["express_name"] = $exp->getExpressNameByCode($res->express_company)?:'';
        break;
    case 5:
        $result["step"] = 4;
       // $info->text =  "待退款";
        $result["express_number"] = $res->express_number;
        $exp = new Express();
        $result["express_name"] = $exp->getExpressNameByCode($res->express_company)?:'';
        break;
    case 6:
        $result["step"] = 5;
       // $info->text =  "已完成";
        $result["express_number"] = $res->express_number;
        $exp = new Express();
        $result["express_name"] = $exp->getExpressNameByCode($res->express_company)?:'';
        break;
}
$result["stepArr"] = array(
    0 => array(
        "step" => 0,
        "stepName" => "已取消"
    ),
    1 => array(
        "step" => 1,
        "stepName" => "待审核"
    ),
    2 => array(
        "step" => 2,
        "stepName" => "审核拒绝"
    ),
    3 => array(
        "step" => 3,
        "stepName" => "审核通过"
    ),
    4 => array(
        "step" => 4,
        "stepName" => "退货中"
    ),
    5 => array(
        "step" => 5,
        "stepName" => "已完成"
    )
);
$address = new ServiceAddress();
$mall_order = new MallGoodOrder($res->refund_id);
$result["return_address"] = $address->getSupplierAddress_v2($mall_order->getOrderSupplier());
$result["refund_refuse_reason"] = $res->refund_refuse;
exit(HttpResponse::exitJSON(TRUE, "获取售后详情成功", ClentCmd::HINT,$result));