<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/6/25
 * Time: 13:23
 */
use jiupian\api\model\MallGood;
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use HoloPHP\AutoLoader;
use config\ClentCmd;
use jiupian\api\model\MallGoodOrder;
use jiupian\api\model\MallGoodOrderGoods;
use jiupian\api\model\ModelGoodsSku;
use jiupian\api\model\ModelUserSupplier;
use jiupian\api\model\MallGoodOrderBarter;
use jiupian\api\model\MallGoodOrderRefund;
use HoloPHP\tools\UUID;
$R = new \stdClass();
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
verify::existsingAll("token", "device", "order_index","order_goods_index","service_type","service_goods_count","service_content", "service_images");
$order_index = $_REQUEST ["order_index"];
$order_goods_index = $_REQUEST ["order_goods_index"];
$service_type = $_REQUEST ["service_type"];
$service_goods_count = intval($_REQUEST ["service_goods_count"]);
$service_remark = $_REQUEST ["service_content"];
$service_images = $_REQUEST ["service_images"];
$mallorder_goods = new MallGoodOrderGoods ($order_goods_index);
$mallorder = new MallGoodOrder ($order_index);
if($mallorder_goods->getFieldsValue("order_index") != $order_index || $mallorder->getFieldsValue("order_consumer") != $user_id){
    exit(HttpResponse::exitJSON(FALSE, "订单信息错误!", ClentCmd::HINT,$list));
}
$orderGoodsInfo =  $mallorder_goods->getOrderGoodsInfo($order_goods_index);
if( $service_goods_count < 0 ||  $service_goods_count > $mallorder_goods->getFieldsValue("goods_count")){
    exit(HttpResponse::exitJSON(FALSE, "申请售后商品数量错误!", ClentCmd::HINT,$list));
}
//1、确认收货后7天内可以申请退货。
//2、确认收货7天内，可以申请换货。
//3、确认收货1年内，可以申请返修
//1.表示退款，2表示换货/返修
$confirm_time = $mallorder->getFieldsValue("confirm_time");
if($service_type == 1){//退货
    $end_time = $confirm_time + 7*24*3600;
    if(time() > $end_time ){
        exit(HttpResponse::exitJSON(FALSE, "申请售后时间已过期1", ClentCmd::HINT,$list));
    }
}else{
    if( $_REQUEST ["barter_type"] == 1){//换货
        $end_time = $confirm_time + 15*24*3600;
        if(time() > $end_time ){
            exit(HttpResponse::exitJSON(FALSE, "申请售后时间已过期1", ClentCmd::HINT,$list));
        }
    }elseif($_REQUEST ["barter_type"] == 2){//返修
        $end_time = $confirm_time + 365*24*3600;
        if(time() > $end_time ){
            exit(HttpResponse::exitJSON(FALSE, "申请售后时间已过期1", ClentCmd::HINT,$list));
        }
    }
}
$mallorder->stopAutocommit();
if($mallorder_goods->getFieldsValue("goods_after_sale") != 0){
    if (($orderGoodsInfo->goods_after_sale == 1 && $service_type == 1) || ($orderGoodsInfo->goods_after_sale == 2 && $service_type == 2)){
        $barter = new MallGoodOrderBarter();
        $refund = new MallGoodOrderRefund();
        if($service_type == 2){//更改返修审核状态
            $service_order = $barter->barterStatus_v2($order_goods_index)->barter_order;
            $status1 = $barter->barterStatus($order_goods_index,$user_id,$service_remark,$service_images,$service_order,$barter_type);
            $status2 = 1;
        }elseif($service_type == 1){//更改退款审核状态
            $service_order = $refund->refundStatus_v2($order_goods_index)->refund_order;
            $status1 = 1;
            $status2 = $refund->refundStatus($order_goods_index,$user_id,$service_remark,$service_images,$service_order);
        }
        if($status1 && $status2){
            $mallorder->commit();
            exit(HttpResponse::exitJSON(TRUE, "申请售后成功", ClentCmd::HINT,$list));
        }else{
            $mallorder->rollback();
            exit(HttpResponse::exitJSON(FALSE, "申请售后失败6", ClentCmd::HINT,$list));
        }
    }else{
        $barter = new MallGoodOrderBarter();
        $refund = new MallGoodOrderRefund();
        if($orderGoodsInfo->goods_after_sale == 1){//更改退款审核状态
            $status1 = 1;
            $status2 = $refund->refundStatus_v1($order_goods_index,$user_id);
        }elseif($orderGoodsInfo->goods_after_sale == 2){//更改返修审核状态
            $status1 = $barter->barterStatus_v1($order_goods_index,$user_id);
            $status2 = 1;
        }
        if($status2 && $status1){
        }else{
            $mallorder->rollback();
            exit(HttpResponse::exitJSON(FALSE, "申请售后失败1", ClentCmd::HINT,$list));
        }
    }
}
// 服务类型 1退货 2表示换货/返修
if ($service_type == 2) {
    $service_order = UUID::order_id ();
    if (empty ( $service_order )) {
        exit(HttpResponse::exitJSON(FALSE, "申请售后失败2", ClentCmd::HINT,$list));
    }
    $barter_type = $_REQUEST["barter_type"];
    $goods_sku = $orderGoodsInfo->goods_sku;
    $mallgood_order_barter = new MallGoodOrderBarter ();
    $keys = array ();
    $values_list = array();
    array_push ( $keys, "barter_index" );
    array_push ( $keys, "barter_consumer" );
    array_push ( $keys, "barter_order" );
    array_push ( $keys, "barter_id" );
    array_push ( $keys, "barter_status" );
    array_push ( $keys, "barter_remark" );
    array_push ( $keys, "barter_images" );
    array_push ( $keys, "barter_time" );
    array_push ( $keys, "barter_type" );
    array_push ( $keys, "barter_goods_price" );
    array_push ( $keys, "barter_goods_cost" );
    array_push ( $keys, "barter_goods_count" );
    array_push ( $keys, "barter_goods_index" );
    array_push ( $keys, "barter_goods_sku" );;
    array_push ( $keys, "barter_supplier");
    array_push ( $keys, "order_goods_index");
    array_push ( $keys, "barter_goods_retail");
    array_push ( $keys, "barter_sku_index");
    array_push ( $keys, "barter_goods_bonus");
    $val = array (
        "NULL",
        $user_id,
        $service_order,
        $order_index,
        1,
        "'$service_remark'",
        "'$service_images'",
        time (),
        $barter_type,
        $orderGoodsInfo->goods_price,
        $orderGoodsInfo->goods_cost,
        $service_goods_count,
        $orderGoodsInfo->goods_index,
        "'$goods_sku'",
        $mallorder->getFieldsValue("order_supplier"),
        $order_goods_index,
        $orderGoodsInfo->retail_price,
        $orderGoodsInfo->sku_index,
        $orderGoodsInfo->goods_bonus
    );
    array_push($values_list,$val);
    $res=$mallgood_order_barter->make_mallorder_barter ( $keys, $values_list );
    $res_service=$mallorder_goods->updateOrderGoodsService(2, $order_index, $order_goods_index);
    if(!$res || !$res_service){
        $mallorder->rollback();
        exit(HttpResponse::exitJSON(FALSE, "申请售后失败3", ClentCmd::HINT,$list));
    }else{
        $mallorder->commit();
        exit(HttpResponse::exitJSON(TRUE, "申请售后成功", ClentCmd::HINT,$list));
    }
}else{
    $service_order = UUID::order_id ();
    if (empty ( $service_order )) {
        exit(HttpResponse::exitJSON(FALSE, "申请售后失败5", ClentCmd::HINT,$list));
    }
    $goods_sku = $orderGoodsInfo->goods_sku;
    $refund_total_price = $orderGoodsInfo->goods_cost * $service_goods_count;
    $keys = array ();
    array_push ( $keys, "refund_index" );
    array_push ( $keys, "refund_consumer" );
    array_push ( $keys, "refund_order" );
    array_push ( $keys, "refund_id" );
    array_push ( $keys, "refund_status" );
    array_push ( $keys, "refund_remark" );
    array_push ( $keys, "refund_images" );
    array_push ( $keys, "refund_time" );
    array_push ( $keys, "refund_goods_price" );
    array_push ( $keys, "refund_goods_count" );
    array_push ( $keys, "refund_goods_index" );
    array_push ( $keys, "refund_goods_sku" );
    array_push ( $keys, "refund_supplier");
    array_push ( $keys, "refund_total_price");
    array_push ($keys,  "order_goods_index");
    array_push ($keys,  "refund_goods_cost");
    array_push ($keys,  "refund_goods_retail");
    array_push ($keys,  "refund_sku_index");
    array_push ($keys,  "refund_goods_bonus");
    $values_list = array ();
    $val = array (
        "NULL",
        $user_id,
        $service_order,
        $order_index,
        1,
        "'$service_remark'",
        "'$service_images'",
        time (),
        $orderGoodsInfo->goods_price,
        $service_goods_count,
        $orderGoodsInfo->goods_index,
        "'$goods_sku'",
        $mallorder->getFieldsValue("order_supplier"),
        $refund_total_price,
        $order_goods_index,
        $orderGoodsInfo->goods_cost,
        $orderGoodsInfo->retail_price,
        $orderGoodsInfo->sku_index,
        $orderGoodsInfo->goods_bonus
    );
    array_push ( $values_list, $val );
    $mallgood_order_refund = new MallGoodOrderRefund ();
    $res = $mallgood_order_refund->make_mallorder_refund ( $keys, $values_list );
    //是否售后中，0表示没有，1表示退款，2表示换货/返修
    $res_service=$mallorder_goods->updateOrderGoodsService(1, $order_index, $order_goods_index);
    if(!$res || !$res_service){
        $mallorder->rollback();
        exit(HttpResponse::exitJSON(FALSE, "申请售后失败4", ClentCmd::HINT,$list));
    }else{
        $mallorder->commit();
        exit(HttpResponse::exitJSON(TRUE, "申请售后成功", ClentCmd::HINT,$list));
    }
}