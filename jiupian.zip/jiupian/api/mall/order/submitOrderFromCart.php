<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/6/22
 * Time: 20:17
 */
use jiupian\api\model\MallGood;
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use HoloPHP\AutoLoader;
use config\ClentCmd;
use jiupian\api\model\ModelGoodsSku;
use jiupian\api\model\ModelUserSupplier;
use jiupian\api\model\MallGoodOrder;
use jiupian\api\model\types\Platform;
use jiupian\api\model\MallGoodOrderGoods;
use tables\account\UserAddress;
use HoloPHP\tools\UUID;
use jiupian\api\model\MallGoodCart;
use jiupian\api\model\types\UserLevel;
use jiupian\api\model\types\SystemUser;
use jiupian\api\model\ModelPriceLevel;
use HoloPHP\server\Log;
use jiupian\api\model\ModelFreightTemplates;
use  HoloPHP\server\Redis;
use  HoloPHP\server\Server;
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
verify::existsingAll("cart_index", "order_remark", "user_address_id");
$R = new \stdClass ();
$cart_list = $_REQUEST["cart_index"];
//$order_remark = json_decode($_REQUEST["order_remark"], true);
$remark =  $_REQUEST["order_remark"];
$order_remark = array();
if($remark){
    foreach($remark["data"] as $key=>$val){
        $order_remark[$val["id"]] = $val["content"];
    }
}
$user_address_id = $_REQUEST["user_address_id"];
$user_address = new UserAddress ($user_address_id);
if (!$user_address->isExist()) {
    exit(HttpResponse::exitJSON(FALSE, "收货地址不存在!", ClentCmd::HINT));
}
/**
 * 验证购物车信息是否正确
 */
$mall_carts = new MallGoodCart($user_id);
$mall_carts->stopAutocommit();
$my_carts = $mall_carts->findGoodCartList();
$order_index_arr = array_column($my_carts, "cart_index");
$carts = explode(",", $cart_list);
foreach($carts as $key=>$val){
    if(!in_array($val,$order_index_arr)){
        $mall_carts->rollback();
        exit(HttpResponse::exitJSON(FALSE, "购物车信息错误，请重试!", ClentCmd::HINT));
    }
}

$list = array();
$list2 = array();
$i = 0;
foreach ($carts as $key => $val) {
    $i++;
    $mall_cart = new MallGoodCart(null, $val);
    $goods_index = $mall_cart->getFieldsValue("goods_index");
    $mallgoods = new MallGood($goods_index);
    $online_area = $mallgoods->getFieldsValue("online_area");
    $rank = $userInfo->getOneFieldData("rank");
    if($rank == UserLevel::REGISTERUSER){
        $online_area = $mallgoods->getOneField("online_area");
        /*if($online_area == 1){
            exit(HttpResponse::exitJSON(FALSE, "请先购买礼包产品!", ClentCmd::HINT));
        }*/
    }
    $goods_count = $mall_cart->getFieldsValue("goods_count");
    $limit_days = $mallgoods->getFieldsValue('limit_days');
    $limit_count = $mallgoods->getFieldsValue('limit_count');

    $sale_level = $mallgoods->getFieldsValue('sale_level');
    if($sale_level > 0 && $userInfo->getOneFieldData('rank') <  $sale_level){
        exit(HttpResponse::exitJSON(FALSE, "请您升级会员级别!", ClentCmd::HINT));
    }

    if($limit_days > 0 && $limit_count > 0){
        //今天的结束时间
        $end_time =  mktime(0,0,0,date('m'),date('d')+1,date('Y'))-1;
        $start_time = $end_time - $limit_days*24*3600;
        $res = $mallgoods->getLatelyOrder($goods_index,$user_id,$start_time,$end_time);
        if($res && $res->total_count  >= $limit_count ){
            exit(HttpResponse::exitJSON(FALSE, "限购了,明天再来吧!", ClentCmd::HINT));
        }
        if($goods_count > $limit_count ){
            exit(HttpResponse::exitJSON(FALSE, "您最多购买".$limit_count."份产品", ClentCmd::HINT));
        }
    }


    if($online_area == UserLevel::VIPGOODS || $online_area == UserLevel::SUPREGOODS  || $online_area == UserLevel::PARTNERGOODS  ||  $online_area == UserLevel::SUSHANHOMEGOODS){
        switch($rank){
            case UserLevel::VIPUSER:
                if($online_area == UserLevel::VIPGOODS){
                    exit(HttpResponse::exitJSON(FALSE, "您已经购买过VIP会员礼包!", ClentCmd::HINT));
                }
                break;
            case UserLevel::SUPREUSER:
                if($online_area == UserLevel::SUPREGOODS){
                    exit(HttpResponse::exitJSON(FALSE, "您已经购买过至尊会员礼包!", ClentCmd::HINT));
                }
                if($online_area == UserLevel::VIPGOODS){
                    exit(HttpResponse::exitJSON(FALSE, "请您购买更高级别的礼包!", ClentCmd::HINT));
                }
                break;
            case  UserLevel::PARTNERUSER:
                if($online_area == UserLevel::PARTNERGOODS){
                    exit(HttpResponse::exitJSON(FALSE, "您已经购买过合伙人会员礼包!", ClentCmd::HINT));
                }
                if($online_area == UserLevel::VIPGOODS){
                    exit(HttpResponse::exitJSON(FALSE, "请您购买更高级别的礼包!", ClentCmd::HINT));
                }
                if($online_area == UserLevel::SUPREGOODS){
                    exit(HttpResponse::exitJSON(FALSE, "请您购买更高级别的礼包!", ClentCmd::HINT));
                }
                break;
            case UserLevel::SUSHANPARTNER:
                    exit(HttpResponse::exitJSON(FALSE, "您已经不能首购区购买礼包!", ClentCmd::HINT));
                break;
            case UserLevel::OPERATIONPARTNER:
                    exit(HttpResponse::exitJSON(FALSE, "您已经不能首购区购买礼包!", ClentCmd::HINT));
                break;
            default:
                break;
        }
        if($goods_count > 1){
            exit(HttpResponse::exitJSON(FALSE, "会员首购产品只能购买一件!", ClentCmd::HINT));
        }

    }
    $supplier_id = $mall_cart->getFieldsValue("supplier_id");
    $sku_index = $mall_cart->getFieldsValue("sku_index");
    /**
     * 是否自己在自己店铺消费
     */
    $skuObj = new ModelGoodsSku($sku_index);
    $skuData = $skuObj->getGoodsSkuData($sku_index);
    $priceLevel = new ModelPriceLevel();
    if($online_area == 1){
        $skuData->sku_cost_price = $priceLevel->getSkuGoods($userInfo->getOneFieldData('rank'),$goods_index,$sku_index)->level_goods_cost?:$skuData->sku_cost_price;
    }


    $userSupplier = new ModelUserSupplier($supplier_id);
    $goods_supplier_id = $userSupplier->getOneField("consumer_id");
    $mallGood = new MallGood($goods_index);
    $goods_status = $mallGood->getFieldsValue("goods_status");
    if ($goods_status != 2) {
        $mall_carts->rollback();
        exit(HttpResponse::exitJSON(FALSE, "商品已经下架", ClentCmd::HINT));
    }
    $mallGoodsCount = $mallGood->getFieldsValue("goods_sku_count");
    if ($mallGoodsCount < $goods_count || $skuData->sku_inventory < $goods_count) {
        $mall_carts->rollback();
        exit(HttpResponse::exitJSON(FALSE, "商品库存不足1", ClentCmd::HINT));
    }
    //减去库存增加销量
    $res = $skuObj->deductGoodsSkuInventory($sku_index, $goods_count);
    $lessInventory = $mallGood->deductSkuCount($goods_count);
    $res_sale = $mallGood->addSaleCount($goods_count);
    if(!$res || !$res_sale){
        $mall_carts->rollback();
        exit(HttpResponse::exitJSON(FALSE, "商品库存不足2", ClentCmd::HINT));
    }
    if (!empty($order_remark)) {
        $list[$supplier_id]["order_remark"] =$order_remark[$supplier_id]?$order_remark[$supplier_id]:"";
    }else{
        $list[$supplier_id]["order_remark"] = "";
    }
    if($mallGood->getOneField('is_skill') == 1){
        $skuData->sku_cost_price = $mallGood->getOneField('skill_price');
    }
    $list[$supplier_id]["order_goods_price"] += $goods_count * $skuData->sku_cost_price;
    $list[$supplier_id]["order_supplier_price"] += $goods_count * $skuData->sku_retail_price;

    $list2[$supplier_id][$i]["goods_index"] = $goods_index;
    $list2[$supplier_id][$i]["goods_sku"] = $skuData->sku_info;
    $list2[$supplier_id][$i]["sku_index"] = $sku_index;
    $list2[$supplier_id][$i]["goods_count"] = $goods_count;

    if(!isset($list[$supplier_id]["order_id"])){
        $list[$supplier_id]["order_id"] = UUID::order_id();
    }

}
/**
 * 拼接收货地址
 */
$user_address = new UserAddress($user_address_id);
$order_address = $user_address->getFieldsValue ( "province_name" ) . $user_address->getFieldsValue ( "city_name" ) . $user_address->getFieldsValue ( "county_name" ) . $user_address->getFieldsValue ( "address" );
$order_province = $user_address->getFieldsValue("province_id");
$order_city = $user_address->getFieldsValue("city_id");
$order_county = $user_address->getFieldsValue("county_id");
$order_contacts = $user_address->getFieldsValue("contacts");
$order_phone = $user_address->getFieldsValue("phone");
if($user_address->getFieldsValue("is_merchant_address") == 1){
    $order_source  = 1;
}else{
    $order_source = 0;
}

$order_total_price = 0;
$order1 = array();
//查找运营中心
$operation_user_id = 0;
$ref_user = $userInfo->getOneFieldData('referrer');
while($operation_user_id == 0){
    $info =  $userInfo->getzhizun($ref_user);
    if($info){
        if($info->rank >= UserLevel::OPERATIONPARTNER){
            $operation_user_id = $info->user_id;
        }else{
            $operation_user_id = 0;
            $ref_user =  $info->referrer;
        }
    }else{
        $operation_user_id =  SystemUser::SYSTEM_REFERRER;//固定值
    }
}
$total_price = [];
foreach ($list as $key => $value) {
   array_push($total_price,$value["order_goods_price"]);
}
$total_price = array_sum($total_price);

if(Server::environment('prod')){
    $freight = Redis::get('jiupian_redis_test')?:0;
}else{
    $freight = Redis::get('jiupian_redis_prod')?:0;
}
if($total_price >= $freight){
    $order_freight_price = 0;
}else{
    $fretemplate = new ModelFreightTemplates($mallgoods->getOneField('freight_id'));
    if($fretemplate->isExist()){
        $template = json_decode($fretemplate->getOneField('template'));
        foreach($template as $key=>$val){
            if($val->id == $order_province){
                $order_freight_price =$val->first_money;
            }
        }
    }else{
        $order_freight_price = 0;
    }
}
foreach ($list as $key => $value) {
    $order_type = 0;
    $platform = Platform::WECHAT;
    $order_supplier = $supplier_ids = $key;
   // $order_freight_price = 0;
    $order_goods_price = $value["order_goods_price"];
    $order_supplier_price = $value["order_supplier_price"];
    $mallorder = new MallGoodOrder();
    $order_index = $mallorder->make_mallorder($value["order_id"], $user_id, $value["order_remark"], $order_freight_price, $order_contacts, $order_phone, $order_address, $order_goods_price, $order_province, $order_city, $order_county, $order_supplier, $order_type, $order_supplier_price, $platform,  $supplier_ids,$order_source,$operation_user_id);
    if (!$order_index) {
        $mall_carts->rollback();
        exit(HttpResponse::exitJSON(FALSE, "下订单失败1", ClentCmd::HINT));
    }
    $order_total_price += $value["order_goods_price"];
    $order_total_price += $order_freight_price;
    $order1[$order_supplier]["order_index"] = $order_index;
    $order1[$order_supplier]["order_id"] = $value["order_id"];
}
foreach ($list2 as $k => $v) {
    $supplier_id = $k;
    $order_index =$order1[$supplier_id]["order_index"];
    $order_id = $order1[$supplier_id]["order_id"];
    $goods_info = array();
    $priceLevel = new ModelPriceLevel();

    foreach ($v as $k2=>$v2) {

        $skuObj = new ModelGoodsSku($v2['sku_index']);
        $sku_data = $skuObj->getGoodsSkuData($v2["sku_index"]);

        $mallggoods = new MallGood($v2["goods_index"]);
        $online_area = $mallggoods->getFieldsValue('online_area');

        if($online_area == 1){
            $sku_data->sku_cost_price = $priceLevel->getSkuGoods($userInfo->getOneFieldData('rank'),$v2["goods_index"],$v2["sku_index"])->level_goods_cost?:$skuData->sku_cost_price;

        }
        if($mallggoods->getOneField('is_skill') == 1){
            $sku_data->sku_cost_price = $mallGood->getOneField('skill_price');
        }
        $mallOrderGoods = new MallGoodOrderGoods ();
        $order_goods_index = $mallOrderGoods->addOrderGoods_v2($v2["goods_index"], $order_index, $user_id, $v2["goods_sku"], $v2["goods_count"], $sku_data->sku_cost_price,
            $sku_data->sku_market_price, $sku_data->sku_retail_price, $supplier_id,$v2["sku_index"]);
        if (!$order_goods_index) {
            $mall_carts->rollback();
            exit(HttpResponse::exitJSON(FALSE, "下订单失败3", ClentCmd::HINT));
        }
    }
}
/**
 * 删除购物车
 */
if (!$mall_carts->deleteGoodCart($cart_list)) {
    $mall_carts->rollback();
    exit(HttpResponse::exitJSON(FALSE, "下订单失败2", ClentCmd::HINT));
}
$mall_carts->commit();
$R->order_total_price = $order_total_price;
/*if(UserLevel::REGISTERUSER == $userInfo->getOneFieldData("rank")){
    $R->user_cash = $userInfo->getCash() - $userInfo->getOneFieldData("total_income");
    if($R->user_cash < 0){
        $R->user_cash = 0;
    }
    $R->user_bonus = 0;
}else{*/
    $R->user_cash = $userInfo->getCash();
    $R->user_bonus = $userInfo->getBonus();
//}
$R->user_cash = $userInfo->getCash();
$R->user_bonus = $userInfo->getBonus();
$order = array();
foreach ($order1 as $v){
    array_push($order,$v);
}
$R->list = $order;
exit(HttpResponse::exitJSON(TRUE, "下订单成功", ClentCmd::HINT,$R));
