<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/6/22
 * Time: 19:39
 */
use jiupian\api\model\MallGood;
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use HoloPHP\AutoLoader;
use config\ClentCmd;
use jiupian\api\model\ModelGoodsSku;
use jiupian\api\model\ModelUserSupplier;
use jiupian\api\model\MallGoodOrder;
use jiupian\api\model\types\Platform;
use jiupian\api\model\MallGoodOrderGoods;
use tables\account\UserAddress;
use HoloPHP\tools\UUID;
use jiupian\api\model\types\UserLevel;
use jiupian\api\model\types\SystemUser;
use jiupian\api\model\ModelPriceLevel;
use jiupian\api\model\ModelFreightTemplates;
use HoloPHP\server\Redis;
use HoloPHP\server\Server;
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
verify::existsingAll("goods_index", "token", "goods_count", "sku_index", "order_remark", "user_address_id","goods_sku");
$R = new \stdClass ();
$goods_index = $_REQUEST ["goods_index"];
$mallgoods = new MallGood($goods_index);
$sku_index = $_REQUEST ["sku_index"];
$goods_sku = trim($_REQUEST ["goods_sku"]);
$goodsSku = new ModelGoodsSku($sku_index);
$goods_count = intval($_REQUEST ["goods_count"]);

$limit_days = $mallgoods->getFieldsValue('limit_days');
$limit_count = $mallgoods->getFieldsValue('limit_count');
$sale_level = $mallgoods->getFieldsValue('sale_level');
if($sale_level > 0 && $userInfo->getOneFieldData('rank') <  $sale_level){
    exit(HttpResponse::exitJSON(FALSE, "请您升级会员级别!", ClentCmd::HINT));
}

$mallorder = new MallGoodOrder();
if($limit_days > 0 && $limit_count > 0){
    //今天的结束时间
    $end_time =  mktime(0,0,0,date('m'),date('d')+1,date('Y'))-1;
    $start_time = $end_time - $limit_days*24*3600;
    $res = $mallorder->getLatelyOrder($goods_index,$user_id,$start_time,$end_time);
    if($res && $res->total_count  >= $limit_count ){
        exit(HttpResponse::exitJSON(FALSE, "限购了!", ClentCmd::HINT));
    }
    if($goods_count > $limit_count ){
        exit(HttpResponse::exitJSON(FALSE, "您最多购买".$limit_count."份产品", ClentCmd::HINT));
    }
}


$skuData = $goodsSku->getGoodsSkuData($sku_index);
$priceLevel = new ModelPriceLevel();
$priceInfo = $priceLevel->getSkuGoods($userInfo->getOneFieldData('rank'),$goods_index,$sku_index);
if($mallgoods->getFieldsValue('online_area') == 1){
    $skuData->sku_cost_price = $priceInfo->level_goods_cost?:$skuData->sku_cost_price;
}
//if($mallgoods->getFieldsValue('online_area') > 1){
//    //判断是否已买过商品
//    $mallorders = new MallGoodOrder();
//    $mallorders_goods = new MallGoodOrderGoods();
//    $order_index_list = $mallorders->selectArrayByWhere("order_consumer = {$user_id} and order_status > 0","order_time desc","order_index");
//    $goods_index_array = [];
//    if($order_index_list){
//        foreach ($order_index_list as $v){
//            $goods_index_list = $mallorders_goods->findOrderGoodsByOrder($v->order_index,"goods_index");
//            if($goods_index_list){
//                foreach ($goods_index_list as $va){
//                    $goods_index_array[] = $va->goods_index;
//                }
//            }
//        }
//    }
//    if (!empty($goods_index_array)){
//        foreach ($goods_index_array as $value){
//            $mall_goods = new MallGood($value);
//            $online_area = $mall_goods->getFieldsValue("online_area");
//            $goods_status = $mall_goods->getFieldsValue("goods_status");
//            if($goods_status == 2 && $online_area != 1){
//                exit(HttpResponse::exitJSON(FALSE, "您已买过首购区，请前往复购区!", ClentCmd::HINT));
//            }
//        }
//    }
//}

$order_remark = trim($_REQUEST["order_remark"]);
$user_address_id = $_REQUEST["user_address_id"];
$supplierObj = new ModelUserSupplier($mallgoods->getOneField("goods_supplier"));
$online_area = $mallgoods->getOneField("online_area");
//获取当前会员级别
$rank = $userInfo->getOneFieldData("rank");
if($rank == UserLevel::REGISTERUSER){
    $online_area = $mallgoods->getOneField("online_area");
//    if($online_area == 1){
//        exit(HttpResponse::exitJSON(FALSE, "请先购买礼包产品!", ClentCmd::HINT));
//    }
}
if($online_area == UserLevel::VIPGOODS || $online_area == UserLevel::SUPREGOODS  || $online_area == UserLevel::PARTNERGOODS  || $online_area == UserLevel::SUSHANHOMEGOODS ){
    switch($rank){
        case UserLevel::VIPUSER:
           if($online_area == UserLevel::VIPGOODS){
                exit(HttpResponse::exitJSON(FALSE, "您已经购买过VIP会员礼包!", ClentCmd::HINT));
            }
            break;
        case UserLevel::SUPREUSER:
            if($online_area == UserLevel::SUPREGOODS){
                exit(HttpResponse::exitJSON(FALSE, "您已经购买过至尊会员礼包!", ClentCmd::HINT));
            }
            if($online_area == UserLevel::VIPGOODS){
                exit(HttpResponse::exitJSON(FALSE, "请您购买更高级别的礼包!", ClentCmd::HINT));
            }
            break;
        case  UserLevel::PARTNERUSER:
            if($online_area == UserLevel::PARTNERGOODS){
                exit(HttpResponse::exitJSON(FALSE, "您已经购买过合伙人会员礼包!", ClentCmd::HINT));
            }
           if($online_area == UserLevel::VIPGOODS){
                exit(HttpResponse::exitJSON(FALSE, "请您购买更高级别的礼包!", ClentCmd::HINT));
            }
            if($online_area == UserLevel::SUPREGOODS){
                exit(HttpResponse::exitJSON(FALSE, "请您购买更高级别的礼包!", ClentCmd::HINT));
            }
            break;
        case UserLevel::SUSHANPARTNER:
//            if($online_area == UserLevel::VIPGOODS){
//
//            }else{
                exit(HttpResponse::exitJSON(FALSE, "您已经不能购买礼包!", ClentCmd::HINT));
                break;
//            }

        case UserLevel::OPERATIONPARTNER:
//            if($online_area == UserLevel::VIPGOODS){
//
//            }else{
                exit(HttpResponse::exitJSON(FALSE, "您已经不能购买礼包!", ClentCmd::HINT));
                break;
//            }

        default:
            break;
    }
    if($goods_count > 1){
        exit(HttpResponse::exitJSON(FALSE, "会员首购产品只能购买一件!", ClentCmd::HINT));
    }
}
if($skuData->sku_info != $goods_sku || $skuData->sku_goods != $goods_index){
    exit(HttpResponse::exitJSON(FALSE, "商品规格选择不正确!", ClentCmd::HINT));
}
if ($goods_count < 1) {
    exit(HttpResponse::exitJSON(FALSE, "订单数量不正确!", ClentCmd::HINT));
}
$user_address = new UserAddress ($user_address_id);
if (!$user_address->isExist()) {
    exit(HttpResponse::exitJSON(FALSE, "收货地址不存在!", ClentCmd::HINT));
}
$order_province = $user_address->getFieldsValue("province_id");
$order_city = $user_address->getFieldsValue("city_id");
$order_county = $user_address->getFieldsValue("county_id");
$order_contacts = $user_address->getFieldsValue("contacts");
$order_phone = $user_address->getFieldsValue("phone");
$order_address = $user_address->getFieldsValue ( "province_name" ) . $user_address->getFieldsValue ( "city_name" ) . $user_address->getFieldsValue ( "county_name" ) . $user_address->getFieldsValue ( "address" );
if($user_address->getFieldsValue("is_merchant_address") == 1){
    $order_source  = 1;
}else{
    $order_source = 0;
}
//判断当前库存是否满足购买要求
if($skuData->sku_inventory < $goods_count){
    exit(HttpResponse::exitJSON(FALSE, "商品库存不足!", ClentCmd::HINT));
}
if($mallgoods->getFieldsValue("goods_status") != 2 ){
    exit(HttpResponse::exitJSON(FALSE, "商品已经下架!", ClentCmd::HINT));
}
$order_freight_price = 0;
$R->create_order_time = time();
// 开启事务
$mallgoods->stopAutocommit();
$goodsSku->lockLine();
$order_id = UUID::order_id();
if (empty ($order_id)) {
    $mallgoods->rollback();
    exit(HttpResponse::exitJSON(FALSE, "订单提交失败1!", ClentCmd::HINT));
}
$res = $goodsSku->deductGoodsSkuInventory($sku_index, $goods_count);
$res2 = $mallgoods->deductSkuCount($goods_count);
$res3 = $mallgoods->addSaleCount($goods_count);
if (!$res || !$res2 || !$res3) {
    $mallgoods->rollback();
    exit(HttpResponse::exitJSON(FALSE, "订单提交失败2!", ClentCmd::HINT));
}
if($mallgoods->getOneField('is_skill') == 1){
    $skuData->sku_cost_price = $mallgoods->getOneField('skill_price');
    //限购
   // $orderGoods = new MallOrderGoods;
    //$sql = "select a.goods_count,a.order_index,b.payment_time,b.order_status from mall_order_goods as a left join mall_orders on a.order_index = b.order_index where b.payment_time > 0 and b.order_status >= 2 ";
}
$order_goods_price = $skuData->sku_cost_price * $goods_count;
if(Server::environment('prod')){
    $freight = Redis::get('jiupian_redis_test')?:0;
}else{
    $freight = Redis::get('jiupian_redis_prod')?:0;
}
if($order_goods_price >= $freight){
    $order_freight_price = 0;
}else{
    $fretemplate = new ModelFreightTemplates($mallgoods->getOneField('freight_id'));
    if($fretemplate->isExist()){
        $template = json_decode($fretemplate->getOneField('template'));
        foreach($template as $key=>$val){
            if($val->id == $order_province){
                $order_freight_price = $val->first_money;
            }
        }
    }else{
        $order_freight_price = 0;
    }
}
$order_supplier_price = $skuData->sku_retail_price * $goods_count;
$order_supplier = $supplier_ids = $mallgoods->getOneField("goods_supplier");
$order_type = 0;
$platform = Platform::WECHAT;

//查找体系运营中心
$operation_user_id = 0;
$ref_user = $userInfo->getOneFieldData('referrer');
while($operation_user_id == 0){
    $info =  $userInfo->getzhizun($ref_user);
    if($info){
        if($info->rank >= UserLevel::OPERATIONPARTNER){
            $operation_user_id = $info->user_id;
        }else{
            $operation_user_id = 0;
            $ref_user =  $info->referrer;
        }
    }else{
        $operation_user_id =  SystemUser::SYSTEM_REFERRER;//固定值
    }
}

$order_index = $mallorder->make_mallorder($order_id, $user_id, $order_remark, $order_freight_price, $order_contacts, $order_phone, $order_address, $order_goods_price, $order_province, $order_city, $order_county, $order_supplier, $order_type, $order_supplier_price, $platform,  $supplier_ids,$order_source,$operation_user_id);
if (!$order_index || !$res ) {
    $mallgoods->rollback();
    exit(HttpResponse::exitJSON(FALSE, "订单提交失败3!", ClentCmd::HINT));
}
$goodName = $mallgoods->getFieldsValue("goods_name");
//更订单商品
$mallorder_goods = new MallGoodOrderGoods ();
$goods_cost = $skuData->sku_cost_price;
$goods_prices = $skuData->sku_market_price;
$retail_price = $skuData->sku_retail_price;
$add_arr = array();
$keys = array();
array_push($keys, "order_goods_index");
array_push($keys, "goods_index");
array_push($keys, "user_id");
array_push($keys, "order_index");
array_push($keys, "goods_sku");
array_push($keys, "sku_index");
array_push($keys, "goods_count");
array_push($keys, "goods_cost");
array_push($keys, "goods_price");
array_push($keys, "retail_price");
$info_arr ["order_goods_index"] = "NULL";
$info_arr ["goods_index"] = "'$goods_index'";
$info_arr ["user_id"] = "'$user_id'";
$info_arr ["order_index"] = "'$order_index'";
$info_arr ["goods_sku"] = "'$goods_sku'";
$info_arr ["sku_index"] = "'$sku_index'";
$info_arr ["goods_count"] = "'$goods_count'";
$info_arr ["goods_cost"] = "'$goods_cost'";
$info_arr ["goods_price"] = "'$goods_prices'";
$info_arr ["retail_price"] = "'$retail_price'";
array_push($add_arr, $info_arr);
$gid = $mallorder_goods->make_mallorder_goods($keys, $add_arr);
if (empty ($gid)) {
    $mallgoods->rollback();
    exit(HttpResponse::exitJSON(FALSE, "订单提交失败4!", ClentCmd::HINT));
}
$mallgoods->commit();
$R->order_index = $order_index;
$R->order_id = $order_id;
$R->order_total_price = $order_goods_price + $order_freight_price;//总价钱(订单商品价钱+订单的运费)
/*if(UserLevel::REGISTERUSER == $userInfo->getOneFieldData("rank")){
    $R->user_cash = $userInfo->getCash() - $userInfo->getOneFieldData("total_income");
    if($R->user_cash < 0){
        $R->user_cash = 0;
    }
    $R->user_bonus = 0;
}else{*/
    $R->user_cash = $userInfo->getCash();
    $R->user_bonus = $userInfo->getBonus();
//}
exit(HttpResponse::exitJSON(TRUE, "订单提交成功!", ClentCmd::HINT,$R));
?>