<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/26
 * Time: 16:44
 */
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use config\ClentCmd;
use jiupian\api\model\MallGoodOrder;
$R = new \stdClass ();
Verify::existsingAll("password");
$password = $_REQUEST["password"];
if ($password !== "jianyunkeji2018jiupian") {
    exit(HttpResponse::exitJSON(FALSE, "执行权限错误~！", ClentCmd::HINT));
}
$mallorder = new MallGoodOrder ();
$list = $mallorder->getAllOrders(' order_status = 1 ',' order_consumer,order_index,order_time ');
if(!$list){
    $list = [];
    exit('没有可执行数据');
}else{
    foreach($list as $key=>$val){
        $times = time();
        if($times -  $val->order_time > 24*3600 ){
            $res = $mallorder->update_mallorder ( $val->order_consumer,  $val->order_index,'超时未支付自动取消订单' );
        }
    }
    exit('数据处理完毕');
}