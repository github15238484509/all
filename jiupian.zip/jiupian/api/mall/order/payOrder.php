<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/6/23
 * Time: 15:02
 */
use jiupian\api\model\MallGood;
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use HoloPHP\AutoLoader;
use config\ClentCmd;
use jiupian\api\model\MallGoodOrder;
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
verify::existsingAll("token","order_index","type");
//验证支付密码
/*if ($userInfo->getPayPwd() != substr($_REQUEST ["pay_pwd"], 0, 16)) {
    exit(HttpResponse::exitJSON(FALSE, "支付密码错误!", ClentCmd::HINT));
}*/
// 验证订单
$order_ids = $_REQUEST["order_index"];
$type = $_REQUEST["type"];
$order_id = explode(',', $order_ids);
$order = new MallGoodOrder();
$limit_res = $order->getLimitOrder($user_id,$order_id);
if(!$limit_res){
    exit(HttpResponse::exitJSON(FALSE, "限购了，明天再来吧!", ClentCmd::HINT));
}
/*if($userInfo->getOneFieldData('phone') == '15638173002'){
    exit(HttpResponse::exitJSON(FALSE, "你被限制高消费了", ClentCmd::HINT));
}*/
$myorders = $order->getOrderLists($order_type = 1, $user_id, $page = 0,1000);
if (!$myorders) {
    $myorders = array();
}
$temp = array();
foreach ($myorders as $key => $value) {
    array_push($temp, $value->order_index);
}
foreach ($order_id as $key => $val) {
    $order_info = $order->getOrderInfo($val);
    if($order_info->order_status >= 2){
        exit(HttpResponse::exitJSON(FALSE, "您已经支付过订单 ，请勿重复支付!", ClentCmd::HINT));
    }
    if (!in_array($val, $temp)) {
        exit(HttpResponse::exitJSON(FALSE, "订单信息错误，请重试!", ClentCmd::HINT));
    }
    //限购

}
$order->stopAutocommit();
$res = $order->getOrderPay($order_ids, 0,$type);
if($res->code != 1){
    $order->rollback();
    $msg = $res->msg;
    exit(HttpResponse::exitJSON(FALSE, $msg, ClentCmd::HINT,$res->code));
}
$order->commit();
exit(HttpResponse::exitJSON(TRUE, "订单支付成功!", ClentCmd::HINT,$res->total_cash));