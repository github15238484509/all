<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/6/25
 * Time: 11:18
 */
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use HoloPHP\AutoLoader;
use config\ClentCmd;
use jiupian\api\model\MallGoodOrder;
use jiupian\api\model\MallGoodOrderGoods;
use jiupian\api\model\MallOrderConfirm;
$R = new \stdClass();
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
verify::existsingAll("token", "device", "order_index");
$order_index = $_REQUEST ["order_index"];
$ConfirmOrder = new MallOrderConfirm();
$res = $ConfirmOrder->ConfirmOrder($order_index,$user_id);
if($res->code == 1){
    exit(HttpResponse::exitJSON(TRUE, $res->msg, ClentCmd::HINT));
}else{
    exit(HttpResponse::exitJSON(FALSE, $res->msg, ClentCmd::HINT));
}
