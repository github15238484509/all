<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/6/25
 * Time: 16:57
 */
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use HoloPHP\AutoLoader;
use config\ClentCmd;
use jiupian\api\model\MallGood;
use jiupian\api\model\ModelGoodsSku;
use jiupian\api\model\MallGoodOrderBarter;
use jiupian\api\model\MallGoodOrderRefund;
use jiupian\api\model\ModelUserSupplier;
$R = new \stdClass ();
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
Verify::existsingAll( "token", "device", "page" ,"type");
$page = $_REQUEST ["page"];
$type = $_REQUEST ["type"];
$count = 20;
$list = array ();
if($type == 1){//退款
    $mallorder_refund = new MallGoodOrderRefund ();
    $mallorder_refunds = $mallorder_refund->findOrderRefundList ( $user_id ,$page,$count);
    if(!$mallorder_refunds){
        $mallorder_refunds = array();
    }else{
        foreach ( $mallorder_refunds as $key => $val ) {
            $info = new \stdClass ();
            $info->service_order_index = $val->refund_index;
            $info->service_order = $val->refund_order;
            $info->status = $val->refund_status;
            //0已取消，1待审核2审核拒绝3待退货4待收货，5待退款，6已完成
            switch($val->refund_status){
                case 0:
                    $info->text =  "已取消";
                    break;
                case 1:
                    $info->text =  "待审核";
                    break;
                case 2:
                    $info->text =  "审核拒绝";
                    break;
                case 3:
                    $info->text =  "审核通过";
                    break;
                case 4:
                    $info->text =  "退货中";
                    break;
                case 5:
                    $info->text =  "退货中";
                    break;
                case 6:
                    $info->text =  "已完成";
                    break;
            }
            $info->a = $val->refund_total_price;
            $info->goods_price = $val->refund_goods_price;
            $info->goods_cost = $val->refund_goods_cost;
            $info->goods_bonus = $val->refund_goods_bonus;
            $info->goods_count = $val->refund_goods_count;
            $info->total_price = $val->refund_goods_count * $val->refund_goods_cost;
            $mallGoods = new MallGood($val->refund_goods_index);


            $supplier = new ModelUserSupplier($mallGoods->getFieldsValue("goods_supplier"));
            $info->supplier_name = $supplier->getName()?:'';

            $info->goods_name = $mallGoods->getFieldsValue("goods_name");
            $modelSku = new ModelGoodsSku($val->refund_sku_index);
            $info->goods_icon = $modelSku->getFieldsValues("sku_pic")?:'';
            $info->goods_norms = $modelSku->getFieldsValues("sku_name");
            $info->goods_id = $val->refund_goods_index;
            $info->mall_goods_index = $val->order_goods_index;
            array_push ( $list, $info );
        }
    }
}else{//换货返修
    $mallorder_barter = new MallGoodOrderBarter ();
    $mallorder_barters = $mallorder_barter->findOrderBarterList ($user_id,$page,$count);
    if(!$mallorder_barters){
        $mallorder_barters = array();
    }else{
        foreach ( $mallorder_barters as $key => $val ) {
            $info = new \stdClass ();
            $info->service_order_index = $val->barter_index;
            $info->service_order = $val->barter_order;
            $info->status = $val->barter_status;
            //0已取消，1待审核2审核拒绝3待退货4维修中/换货中5待发货6待收货7已完成
            switch($val->barter_status){
                case 0:
                     $info->text =  "已取消";
                     break;
                case 1:
                    $info->text =  "待审核";
                    break;
                case 2:
                    $info->text =  "审核拒绝";
                    break;
                case 3:
                    $info->text =  "买家待退货";
                    break;
                case 4:
                    $info->text =  "换新中";
                    break;
                case 5:
                    $info->text =  "换新中";
                    break;
                case 6:
                    $info->text =  "换新中";
                    break;
                case 7:
                    $info->text =  "已完成";
                    break;
            }
            $info->total_price = $val->barter_goods_cost * $val->barter_goods_count;
            $info->goods_price = $val->barter_goods_price;
            $info->goods_cost = $val->barter_goods_cost;
            $info->goods_bonus = $val->barter_goods_bonus;
            $info->goods_count = $val->barter_goods_count;
            $mallGoods = new MallGood($val->barter_goods_index);
            $info->goods_name = $mallGoods->getFieldsValue("goods_name");

            $supplier = new ModelUserSupplier($mallGoods->getFieldsValue("goods_supplier"));
            $info->supplier_name = $supplier->getName()?:'';

            $modelSku = new ModelGoodsSku($val->barter_sku_index);
            $info->goods_icon = $modelSku->getFieldsValues("sku_pic")?:'';
            $info->goods_norms = $modelSku->getFieldsValues("sku_name");
            $info->goods_id = $val->barter_goods_index;
            $info->mall_goods_index = $val->order_goods_index;
            array_push ( $list, $info );
        }
    }
}
$R->list = $list;
exit(HttpResponse::exitJSON(TRUE, "售后列表成功", ClentCmd::HINT,$R));
