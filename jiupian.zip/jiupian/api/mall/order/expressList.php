<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/5/26
 * Time: 16:20
 */
use tables\mall\Express;
use HoloPHP\tools\Verify;
use HoloPHP\AutoLoader;
use HoloPHP\tools\HttpResponse;
require_once AutoLoader::autoPath('/api/account/verify/verify_token.php');
$R = new \stdClass ();
Verify::existsingAll("token");
$express = new Express();
$list = $express->getList("1 = 1",null,"express_id as value,express_name as text");
if(!$list){
    exit(HttpResponse::exitJSON(false, "获取快递列表失败~！", "hint"));
}else{
    exit(HttpResponse::exitJSON(true, "获取快递列表成功~！", "hint",$list));
}