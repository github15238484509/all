<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/6/23
 * Time: 18:29
 */
use jiupian\api\model\MallGood;
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use HoloPHP\AutoLoader;
use config\ClentCmd;
use jiupian\api\model\MallGoodOrder;
use jiupian\api\model\MallGoodOrderGoods;
use jiupian\api\model\ModelGoodsSku;
use jiupian\api\model\ModelUserSupplier;
use jiupian\api\model\MallGoodParcel;
use jiupian\api\model\ModelCurrencies;
use jiupian\api\model\types\UserLevel;
$R = new \stdClass();
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
verify::existsingAll("token", "device", "order_index");
$order_index = $_REQUEST ["order_index"];
$mallorder = new MallGoodOrder ($order_index);
if (empty ($mallorder->findOrderById($order_index, $user_id))) {
    exit(HttpResponse::exitJSON(TRUE, "请求的订单号不存在!", ClentCmd::HINT,$list));
}
$orderInfo = $mallorder->getInfo();
$R->order_id = $orderInfo->order_id;
$R->order_index = $orderInfo->order_index;
$R->order_status = $orderInfo->order_status;
$R->order_remark = $orderInfo->order_remark?:'';
$R->order_time = $orderInfo->order_time;
$R->payment_time = $orderInfo->payment_time;
$R->order_freight_price = $orderInfo->order_freight_price;
$R->order_total_price =  $orderInfo->order_total_price;
$R->order_phone = $orderInfo->order_phone;
$R->order_contacts = $orderInfo->order_contacts;
$R->order_address = $orderInfo->order_address;
$supplier = new ModelUserSupplier($orderInfo->order_supplier);
$R->supplier_name = $supplier->getName();
$mallorder_goods = new MallGoodOrderGoods ();
$goods_list = $mallorder_goods->findOrderGoodsByOrder($order_index,$fields="goods_bonus,order_goods_index,goods_index,sku_index,goods_after_sale,goods_status,order_goods_index,goods_count,goods_sku,goods_price,goods_cost,goods_after_sale,goods_parcel");
$goods_arr = array();
$parcels = array();
$return_integral = 0;
foreach ($goods_list as $key => $value) {
    $info = new \stdClass ();
    $goods_id = $value->goods_index;
    $goodsObj = new MallGood ($goods_id);
    $info->order_goods_index = $value->order_goods_index;
    $info->goods_name = $goodsObj->getFieldsValue("goods_name");
    $info->sku_index = $value->sku_index;
    $modelSku = new ModelGoodsSku($value->sku_index);
    $info->goods_norms = $modelSku->getFieldsValues("sku_name")?:'';
    $info->goods_icon = $modelSku->getFieldsValues("sku_pic")?:'';
    $info->goods_after_sale = $value->goods_after_sale;
    $info->goods_count = $value->goods_count;
    $info->goods_price = $value->goods_price;
    $info->goods_cost = $value->goods_cost;
    if($value->goods_parcel){
        $parcel = new MallGoodParcel($value->goods_parcel);
        $parcelInfo = $parcel->getOne($value->goods_parcel);
        $info->express_name = $parcelInfo->express_company;
        $info->express_number = $parcelInfo->express_number;
    }else{
        $info->express_name = "";
        $info->express_number = "";
    }
    array_push($goods_arr, $info);
}
$R->goods_list = $goods_arr;
/*if(UserLevel::REGISTERUSER == $userInfo->getOneFieldData("rank")){
    $R->user_cash = $userInfo->getCash() - $userInfo->getOneFieldData("total_income");
    if($R->user_cash < 0){
        $R->user_cash = 0;
    }
    $R->user_bonus = 0;
}else{*/
    $R->user_cash = $userInfo->getCash();
    $R->user_bonus = $userInfo->getBonus();
//}
exit(HttpResponse::exitJSON(TRUE, "订单详情获取成功!", ClentCmd::HINT,$R));