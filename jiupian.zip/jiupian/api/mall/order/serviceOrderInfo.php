<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/6/25
 * Time: 18:12
 */
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use HoloPHP\AutoLoader;
use config\ClentCmd;
use jiupian\api\model\MallGoodOrderBarter;
use jiupian\api\model\MallGoodOrderRefund;
use jiupian\api\model\ModelGoodsSku;
use jiupian\api\model\Express;
use jiupian\api\model\ServiceAddress;
$R = new \stdClass ();
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
Verify::existsingAll( "token", "device", "service_order_index" ,"type");
$service_order_index = $_REQUEST["service_order_index"];
$type = $_REQUEST["type"];
$result = array();
if($type == 1){//退款
    $mallGoodOrderRefund = new MallGoodOrderRefund ($service_order_index);
    $res = $mallGoodOrderRefund->findOrderRefund ( $user_id,$service_order_index );
    if (! $res) {
        exit(HttpResponse::exitJSON(TRUE, "售后订单信息错误", ClentCmd::HINT,$list));
    }
    $res = $mallGoodOrderRefund->findOrderRefund ( $user_id,$refund_order );
    $mall_goods=new MallGood($res->refund_goods_index);
    $result["refund_goods_name"] = $mall_goods->getFieldsValue("goods_name");
    $modelSku = new ModelGoodsSku($res->sku_index);
    $result["refund_goods_icon"] = $modelSku->getFieldsValues("sku_pic")?:'';
    $result["refund_goods_price"] = $res->refund_goods_price;
    $result["total_price"] = $res->refund_goods_cost * $res->refund_goods_count;
    $result["refund_goods_cost"] = $res->refund_goods_cost;
    $result["refund_goods_bonus"] = $res->refund_goods_bonus;
    $result["refund_goods_count"] = $res->refund_goods_count;
    $result["refund_time"] =  $res->refund_time;
    $result["express_time"] =  $res->express_time;
    $result["express_number"] = $res->express_number;
    $exp = new Express();
    $result["express_number"] = $exp->getExpressNameByCode($res->express_company)?:'';
    $address = new ServiceAddress();
    $mall_order = new MallGoodOrder($res->refund_id);
    $result["return_address"] = $address->getSupplierAddress_v2($mall_order->getOrderSupplier());
    $result["refund_refuse_reason"] = $res->refund_refuse;
}else{
    $mallGoodOrderRefund = new MallGoodOrderBarter ($service_order_index);
    $res = $mallGoodOrderRefund->findOrderBarter ( $user_id,$service_order_index );
    if (! $res) {
        exit(HttpResponse::exitJSON(TRUE, "售后订单信息错误", ClentCmd::HINT,$list));
    }
    $res = $mallGoodOrderRefund->findOrderBarter ( $user_id,$refund_order );
    $mall_goods=new MallGood($res->barter_goods_index);
    $result["refund_goods_name"] = $mall_goods->getFieldsValue("goods_name");
    $modelSku = new ModelGoodsSku($res->sku_index);
    $result["refund_goods_icon"] = $modelSku->getFieldsValues("sku_pic")?:'';
    $result["refund_goods_price"] = $res->barter_goods_price;
    $result["total_price"] = $res->barter_goods_cost * $res->barter_goods_count;
    $result["refund_goods_cost"] = $res->barter_goods_cost;
    $result["refund_goods_bonus"] = $res->barter_goods_bonus;
    $result["refund_goods_count"] = $res->barter_goods_count;
    $result["express_number"] = $res->barter_express_number;
    $result["barter_time"] =  $res->barter_time;
    $result["express_time"] =  $res->barter_express_time;
    $exp = new Express();
    $result["express_number"] = $exp->getExpressNameByCode($res->barter_express_company)?:'';
    $address = new ServiceAddress();
    $mall_order = new MallGoodOrder($res->barter_id);
    $result["return_address"] = $address->getSupplierAddress_v2($mall_order->getOrderSupplier());
    $result["refund_refuse_reason"] = $res->barter_refuse;
}
exit(HttpResponse::exitJSON(TRUE, "获取售后详情成功", ClentCmd::HINT,$result));