<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/6/29
 * Time: 11:29
 */
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use HoloPHP\AutoLoader;
use config\ClentCmd;
use jiupian\api\model\MallGoodOrder;
$R = new \stdClass ();
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
Verify::existsingAll( "token", "device", "order_index");
$order_index = $_REQUEST["order_index"];
$mallorder = new MallGoodOrder ( $order_index );
if (empty ( $mallorder->findOrderById ( $order_index, $user_id ) )) {
    exit(HttpResponse::exitJSON(FALSE, "请求的订单id号不存在", ClentCmd::HINT));
}
$order_status = $mallorder->getFieldsValue ( "order_status" );
if ($order_status == 1 ) {
    // 更新订单状态
    $res = $mallorder->update_mallorder ( $user_id, $order_index );
    if (! $res) {
        exit(HttpResponse::exitJSON(FALSE, "取消订单失败", ClentCmd::HINT));
    }else{
        exit(HttpResponse::exitJSON(TRUE, "取消订单成功", ClentCmd::HINT));
    }
}else{
    exit(HttpResponse::exitJSON(FALSE, "已支付订单暂不能取消", ClentCmd::HINT));
}

