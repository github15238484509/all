<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/6/23
 * Time: 17:33
 */
use jiupian\api\model\MallGood;
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use HoloPHP\AutoLoader;
use config\ClentCmd;
use jiupian\api\model\MallGoodOrder;
use jiupian\api\model\MallGoodOrderGoods;
use jiupian\api\model\ModelGoodsSku;
use jiupian\api\model\ModelUserSupplier;
use jiupian\api\model\MallGoodParcel;
use jiupian\api\model\types\UserLevel;
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
verify::existsingAll("token","order_type", "page");
$R = new \stdClass();
$count = 20;
$order_type = $_REQUEST["order_type"];
$mallorder = new MallGoodOrder ();
// 0 全部订单 1待付款 2待收货 3已完成
$list = $mallorder->getOrderLists($order_type, $user_id, $page ,$count,false,$fields="order_index,order_id,order_status,order_total_price,order_supplier");
if ($list) {
    foreach ($list as $key => $val) {
        $mallorder_goods = new MallGoodOrderGoods ();
        $goods_list = $mallorder_goods->findOrderGoodsByOrder($val->order_index,$fields="goods_bonus,goods_index,sku_index,goods_after_sale,goods_status,order_goods_index,goods_count,goods_sku,goods_price,goods_cost,goods_parcel");
        $goods_arr = array();
        $userSupplier = new ModelUserSupplier($val->order_supplier);
        $val->supplier_name = $userSupplier->getOneField("supplier_name")?:'';

        /*if(UserLevel::REGISTERUSER == $userInfo->getOneFieldData("rank")){
            $R->user_cash = $userInfo->getCash() - $userInfo->getOneFieldData("total_income");
            if($R->user_cash < 0){
                $R->user_cash = 0;
            }
            $list[$key]->user_cash =  $R->user_cash;
            $list[$key]->user_bonus = 0;
        }else{*/
            $list[$key]->user_cash = $userInfo->getCash();
            $list[$key]->user_bonus = $userInfo->getBonus();
        //}

       /* $list[$key]->user_cash = $userInfo->getCash();
        $list[$key]->user_bonus = $userInfo->getBonus();*/
        foreach ($goods_list as $key => $value) {
            $info = new \stdClass ();
            $goods_id = $value->goods_index;
            $goodsObj = new MallGood ($goods_id);
            $info->goods_name = $goodsObj->getFieldsValue("goods_name");
            $modelSku = new ModelGoodsSku($value->sku_index);
            $info->goods_norms = $modelSku->getFieldsValues("sku_name")?:'';
            $info->goods_icon = $modelSku->getFieldsValues("sku_pic")?:'';
            $info->goods_after_sale = $value->goods_after_sale;
            $info->goods_status = $value->goods_status;
            $info->order_goods_index = $value->order_goods_index;
            $info->goods_id = $value->goods_index;
            $info->goods_count = $value->goods_count;
            $info->goods_sku = $value->goods_sku;
            $info->goods_price = $value->goods_price;
            $info->goods_cost = $value->goods_cost;
            $info->goods_bonus = $value->goods_bonus;
            if($value->goods_parcel){
                $parcel = new MallGoodParcel($value->goods_parcel);
                $parcelInfo = $parcel->getOne($value->goods_parcel);
                $info->express_name = $parcelInfo->express_company;
                $info->express_number = $parcelInfo->express_number;
            }else{
                $info->express_name = "";
                $info->express_number = "";
            }
            array_push($goods_arr, $info);
        }
        $val->goods_list = $goods_arr;
    }
}else {
    $list = array();
}
exit(HttpResponse::exitJSON(TRUE, "订单列表获取成功!", ClentCmd::HINT,$list));
