<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/6/22
 * Time: 18:59
 */
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use jiupian\api\model\ModelUserSupplier;
use config\ClentCmd;
use HoloPHP\AutoLoader;
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
verify::existsingAll("supplier_id","type","token");
$R = new \stdClass();
$supplier_id = $_REQUEST["supplier_id"];
$userSupplier = new ModelUserSupplier($supplier_id);
if(!$userSupplier->isExist()){
    exit(HttpResponse::exitJSON(FALSE, "关注失败!", ClentCmd::HINT));
}
$type = $_REQUEST["type"];
if($type == 0){//添加关注
    $supplier_ids = $userInfo->getOneFieldData("supplier_ids");
    if($supplier_ids){
        $supplier_ids = $supplier_ids.",$supplier_id";
    }else{
        $supplier_ids = $supplier_id;
    }
    $res = $userInfo->updateFields("supplier_ids",$supplier_ids);
    if(!$res){
        exit(HttpResponse::exitJSON(FALSE, "关注失败!", ClentCmd::HINT));
    }else{
        exit(HttpResponse::exitJSON(TRUE, "关注成功!", ClentCmd::HINT));
    }
}else{//取消关注
    $supplier_ids = explode(",",$userInfo->getOneFieldData("supplier_ids"));
    $new_supplier_ids = array();
    foreach($supplier_ids as $key => $val){
        if($val != $supplier_id){
            array_push($new_supplier_ids,$val);
        }
    }
    $supplier_ids = implode(",",$new_supplier_ids);
    $res = $userInfo->updateFields("supplier_ids",$supplier_ids);
    if(!$res){
        exit(HttpResponse::exitJSON(FALSE, "取消关注失败!", ClentCmd::HINT));
    }else{
        exit(HttpResponse::exitJSON(TRUE, "取消关注成功!", ClentCmd::HINT));
    }
}