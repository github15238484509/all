<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/6/22
 * Time: 18:17
 */
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use jiupian\api\model\MallGood;
use jiupian\api\model\ModelUserSupplier;
use jiupian\api\model\UserConsumer;
use jiupian\api\model\VerifyToken;
use tables\account\LoginStatus;
use jiupian\api\model\ModelCurrencies;
use config\ClentCmd;
verify::existsingAll("supplier_id","page");
$R = new \stdClass();
$supplier_id = $_REQUEST["supplier_id"];
$userSupplier = new ModelUserSupplier($supplier_id);
//$R->supplier_banner = $userSupplier->getOneField("supplier_banner");
//$R->supplier_icon = $userSupplier->getOneField("supplier_icon");
$R->supplier_banner = "jiupian/supplier_banner.png";
$R->supplier_icon = "jiupian/logo.png";
$R->supplier_name = $userSupplier->getOneField("supplier_name");
$supplier_popular = $R->supplier_popular = $userSupplier->getOneField("supplier_popular");
$userSupplier->updatePopular(1 );
$mallgoood = new MallGood();
$page = $_REQUEST["page"];
$count = 20;
$sort = "1,1";
$list = $mallgoood->getSupplierGoodsList_v2 ($supplier_id, $sort, $page, $count);
if(!$list){
    $R->list = array();
}else{
    $currieences = new ModelCurrencies();
    $coinInfo = $currieences->getDefultCoin();
    foreach($list as $key=>$val){
        $list[$key]->goods_bonus = $mallgoood->getCalculateBonus($val->online_area,$val->goods_cost);
        $list[$key]->goods_icon = $val->goods_icon."?x-oss-process=image/resize,m_fixed,h_200,w_200";
        $list[$key]->coin_name = $coinInfo->currencies_name;
        $currencies_price = intval($coinInfo->currencies_price);
        $list[$key]->coin_count = floor($list[$key]->goods_bonus/$currencies_price);
    }
    $R->list =  $list;
}
//判断用户是否登录
$is_login = VerifyToken::checkToken($_REQUEST["token"]);
if(!$is_login){
    $R->is_focus = 0;
}else{
    $status = new LoginStatus($_REQUEST["token"]);
    $user_id = $status->user_id();
    $userInfo = new UserConsumer($user_id);
    $supplier_ids = $userInfo->getOneFieldData("supplier_ids");
    if(!$supplier_ids){
        $R->is_focus = 0;
    }else{
        $supplier_arr = explode(",",$supplier_ids);
        if(in_array($supplier_id,$supplier_arr)){
            $R->is_focus = 1;
        }else{
            $R->is_focus = 0;
        }
    }
}
exit(HttpResponse::exitJSON(TRUE, "获取旗舰店详情成功!", ClentCmd::HINT,$R));

