<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/6/27
 * Time: 13:41
 */
use jiupian\api\model\MallGood;
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use HoloPHP\AutoLoader;
use config\ClentCmd;
use jiupian\api\model\AppBanner;
use tables\mall\ModelNews;
use jiupian\api\model\VerifyToken;
use jiupian\api\model\Merchant;
use jiupian\api\model\ModelConfigRegion;
use jiupian\api\model\MerchantAlbum;
use jiupian\api\model\types\UserLevel;
use jiupian\api\model\ModelSymtomManage;
$R = new \stdClass();
$banner = new AppBanner();
$banner_type = '256';
$banner_list = $banner->getList($banner_type);
if(!$banner_list){
    $banner_list = array();
}
$R->banner = $banner_list;
$model = new ModelNews();
$R->news = $model->getGonggaoNews ();// 快报
if(!$news){
    $news = array();
}
$R->icon_class = array (
    array (
        'name' => '食疗攻略',
        'image' => 'jiupian/school.png',
        'type' => "to_mall"
    ),
    array (
        'name' => '素膳之家',
        'image' => 'jiupian/sushanhome.png',
        'type' => "to_sushan"

    ),
    array (
        'name' => '意见反馈',
        'image' => 'jiupian/yidou.png',
        'type' =>"to_check"
    ),
    array (
        'name' => '我要分享',
        'image' => 'jiupian/sushanqrcode.png',
        'type' =>"to_qrcode"
    )
);
$mallgoods = new MallGood();
$fields = "goods_index,goods_name,goods_sale,goods_price,goods_cost,goods_sort,goods_sort2,goods_status,goods_icon,goods_icon_new,goods_subtitle,online_area";
$sort = " goods_recommend,goods_popular desc ";
$vipGoods =  UserLevel::VIPGOODS;
$supreGoods = UserLevel::SUPREGOODS;
$partnerGoods =  UserLevel::PARTNERGOODS;
$sushanGoods =  UserLevel::SUSHANHOMEGOODS;
$where =  " goods_status = 2 and ( online_area = $vipGoods or online_area = $supreGoods or online_area = $partnerGoods or  online_area = $sushanGoods) ";
$list = $mallgoods->getGoodsListByWhere($where, $sort, $fields);
if(!$list){
    $list = array();
}else{
    foreach($list as $key=>$val){
        $list[$key]->goods_icon = $val->goods_icon."?x-oss-process=image/resize,m_fixed,h_200,w_200";
    }
}
$R->list = $list;
$user_id = VerifyToken::checkToken($_REQUEST["token"]);
$R->symptom_status = 0;
if($user_id){
    $mer = new Merchant(null,$user_id);
    if(!$mer->isExist()){//0待审核、1已通过，-1审核拒绝-2待提交资料
        $R->merchant_status = -2;
    }else{
        $R->merchant_status = $mer->getOneFieldData("merchant_status");
    }
     $symptom = new ModelSymtomManage();
    $res = $symptom->getHealthByUser($user_id);
    if($res){
        $cha_time = time() - $res->addtime;
        if($cha_time > 7*24*3600){
            $R->symptom_status = 0;
        }else{
            $R->symptom_status = 1;
        }
    }else{
        $R->symptom_status = 0;
    }

}
/*$mer = new Merchant();
$merchant_list = $mer->getListByWhere($fields = 'merchant_id,merchant_name,merchant_province,merchant_city,merchant_county,merchant_address', $where = ' where merchant_status = 1', $limit = '', $order_by = '');
if(!$merchant_list){
    $R->merchant_list = array();
}else{
    $album = new MerchantAlbum();
    $configRegion = new ModelConfigRegion();
    foreach($merchant_list as $key=>$val){
        $merchant_list[$key]->merchant_address = $configRegion->getName($val->merchant_province).$configRegion->getName($val->merchant_city).$configRegion->getName($val->merchant_county).$val->merchant_address;
        $merchant_list[$key]->merchant_logo = $album->getPhotoListData($val->merchant_id,2)[0]->photo_path;
    }
    $R->merchant_list = $merchant_list;
}*/
exit(HttpResponse::exitJSON(true, "获取首页成功~！", "hint",$R));

