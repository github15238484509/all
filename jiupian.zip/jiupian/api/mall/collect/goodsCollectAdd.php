<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/6/21
 * Time: 11:15
 */
use jiupian\api\model\GoodsCollect;
use jiupian\api\model\MallGood;
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use HoloPHP\AutoLoader;
use config\ClentCmd;
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
Verify::existsingAll("data_id", "device", "token" ,"collect_type","type");
$collect_type = $_REQUEST["collect_type"];
$type = $_REQUEST["type"];
if($collect_type == 0){//收藏商品
    if($type == 0){//添加收藏
        $collect = new GoodsCollect ( $user_id );
        $collectLog = $collect->getByGoodsID_mall( $_REQUEST ["data_id"],$collect_type);
        if($collectLog){
            exit(HttpResponse::exitJSON(TRUE, "添加收藏成功", ClentCmd::HINT));
        }
        $goods = new MallGood($_REQUEST["data_id"]);
        $goods_icon = $goods->findGoodsIcon();
        $res = $collect->addCollect($_REQUEST["data_id"], $goods_icon, $collect_type);
        if(!$res){
            exit(HttpResponse::exitJSON(FALSE, "添加收藏失败", ClentCmd::HINT));
        }else{
            exit(HttpResponse::exitJSON(TRUE, "添加收藏成功", ClentCmd::HINT));
        }
    }else{//取消收藏
        $collect = new GoodsCollect ( $user_id );
        $collectLog = $collect->getByGoodsID_mall( $_REQUEST ["data_id"],$collect_type);
        if(!$collectLog){
            exit(HttpResponse::exitJSON(FALSE, "取消收藏失败", ClentCmd::HINT));
        }
        $res = $collect->delectCollect();
        if(!$res){
            exit(HttpResponse::exitJSON(FALSE, "取消收藏失败", ClentCmd::HINT));
        }else{
            exit(HttpResponse::exitJSON(TRUE, "取消收藏成功", ClentCmd::HINT));
        }
    }

}
