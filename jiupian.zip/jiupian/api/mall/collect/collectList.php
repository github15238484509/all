<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/7/2
 * Time: 17:32
 */
use jiupian\api\model\GoodsCollect;
use jiupian\api\model\MallGood;
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use HoloPHP\AutoLoader;
use config\ClentCmd;
use jiupian\api\model\ModelCurrencies;
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
Verify::existsingAll("device", "token" ,"collect_type");
$collect_type = $_REQUEST["collect_type"];
$R = new \stdClass();
if($collect_type == 0) {//收藏商品
    $collect = new GoodsCollect ( $user_id );
    $collectLog = $collect->getCollectList_v2( $user_id);
    if(!$collectLog){
        $collectLog = array();
        $R->list = $collectLog;
        exit(HttpResponse::exitJSON(TRUE, "收藏列表成功", ClentCmd::HINT, $R));
    }else{
        $list = array();
        $priceLevel = new ModelPriceLevel();
        foreach($collectLog as $key=>$val){
            $mallgood = new MallGood($val->collect_data_id);
            $list[$key]["goods_name"] = $mallgood->getFieldsValue("goods_name");
            $list[$key]["goods_index"] = $val->collect_data_id;
            $list[$key]["goods_cost"] = $mallgood->getFieldsValue("goods_cost");
            $list[$key]["goods_price"] = $mallgood->getFieldsValue("goods_price");
            $list[$key]["goods_icon"] =  $mallgood->getFieldsValue("goods_icon");
           /* if($mallgood->getFieldsValue('online_area') == 1){
                $list[$key]["goods_cost"] = $priceLevel->getSkuGoods($userInfo->getOneFieldData('rank'),$val->collect_data_id,$val->sku_index);
            }*/

        }
        $R->list = $list;
        exit(HttpResponse::exitJSON(TRUE, "收藏列表成功", ClentCmd::HINT, $R));
    }
}