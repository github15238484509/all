<?php
namespace jiupian\api\mall;

use tables\account\Card;
use HoloPHP\tools\HttpResponse;
use HoloPHP\tools\ImgUpload;
use HoloPHP\server\Server;
use HoloPHP\tools\Verify;
use config\ClentCmd;
require_once 'verify/verify_token.php';
Verify::existsingAll("type"); // 图片类型
$directory = Server::getProject() . '/identity/' . date("Ymd", time()) . "/" . $userInfo->getCardIndex();
$oss = new ImgUpload($directory);
$ret = $oss->upload($_FILES["file"]);
if (! $ret) {
    exit(HttpResponse::exitJSON(false, "上传文件失败~！", "hint", $ret));
}
$filePath = $ret["data"][0]["uri"];
exit(HttpResponse::exitJSON(true, "上传文件成功~！", "hint", $filePath));
?>