<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/6/2
 * Time: 10:38
 */
use jiupian\api\model\ModelImport;
set_time_limit(0);
$import = new ModelImport();
//1.查找 推荐人 的user__id

