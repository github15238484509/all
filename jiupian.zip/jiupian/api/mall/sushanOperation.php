<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/30
 * Time: 16:04
 */
use jiupian\api\model\MallGoodOrder;
use jiupian\api\model\UserConsumer;
use  jiupian\api\model\types\UserLevel;
$mallorder = new MallGoodOrder();
$list = $mallorder->selectArrayByWhere( ' order_status >= 2  ',' order_index asc ','order_index,order_consumer');
var_dump($mallorder->getDB()->latelySQL());
if($list){
    foreach($list as $key=>$val){
        //查找体系运营中心
        $operation_user_id = 0;
        $userInfo = new UserConsumer($val->order_consumer);
        $ref_user = $userInfo->getOneFieldData('referrer');
        while($operation_user_id == 0){
            $info =  $userInfo->getzhizun($ref_user);
            if($info){
                if($info->rank >= UserLevel::OPERATIONPARTNER){
                    $operation_user_id = $info->user_id;
                }else{
                    $operation_user_id = 0;
                    $ref_user = $info->referrer;
                }
            }else{
                $operation_user_id =  '8888888888100023';//固定值
            }
        }
        $sql = " update mall_orders set operation_user_id = $operation_user_id where order_index = $val->order_index" ;
        $res = $mallorder->update($sql);
        if($res){
            echo "订单order_index=".$val->order_index."的运营中心user_id=".$operation_user_id;
            echo '<br/>';
        }else{
            echo "订单order_index=".$val->order_index."的运营中心更新失败";
            echo '<br/>';
        }
    }
    exit('数据处理完毕');
}else{
    exit('没有数据处理');
}

