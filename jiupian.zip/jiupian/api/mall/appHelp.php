<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/5/15
 * Time: 18:01
 */
use tables\mall\ModelNews;
use HoloPHP\tools\HttpResponse;
$model = new ModelNews();
$news = $model->getHelpNews ();
if(!$news){
    $news = array();
}
HttpResponse::exitJSON(true, "帮助列表成功~！", "hint",$news);