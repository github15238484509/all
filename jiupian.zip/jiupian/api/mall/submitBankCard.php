<?php
namespace jiupian\api\mall;

use HoloPHP\tools\Verify;
use jiupian\api\model\ModelUserBankCard;
use jiupian\api\model\ModelUserExtractOrder;
use jiupian\api\model\ModelBankList;
use HoloPHP\tools\HttpResponse;
use config\ClentCmd;
use tables\account\Card;
use HoloPHP\AutoLoader;
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
$R = new \stdClass();
Verify::existsingAll("card_bank", "card_holder", "card_number");
$card_bank = $_REQUEST['card_bank'];
$card_holder = $_REQUEST['card_holder'];
$card_number = $_REQUEST['card_number'];
$province_id = $_REQUEST['province_id']?:''; // 省份
$city_id = $_REQUEST['city_id']?:''; // 市
$county_id = $_REQUEST['county_id']?:''; // 区
$card_branch = $_REQUEST['card_branch']?:''; // 支行
// 根据银行卡的名称获取银联号码
$modelBank = new ModelBankList();
$codeObj = $modelBank->getCodeByName($card_bank);
if ($codeObj) {
    $codes = $codeObj->bank_code;
    $full_name = $codeObj->bank_full_name;
} else {
    exit(HttpResponse::exitJSON(FALSE, "开户银行不存在~！", ClentCmd::HINT));
}
// 暂时一个用户只能存在一个银行卡
$card_model = new ModelUserBankCard();
$oldinfo = $card_model->getCardByMerchant($user_id);
if ($oldinfo) {
    // 编辑银行卡信息之前 判断是否有正在提现的订单
    $modelUserExtraOrder = new ModelUserExtractOrder();
    $arr = $modelUserExtraOrder->getToDoOrder($user_id);
    if (is_array($arr) && count($arr) > 0) { // 存在待处理订单
        exit(HttpResponse::exitJSON(FALSE, "有未处理的提现订单，不支持修改银行卡~！", ClentCmd::HINT));
    }
    $cardIndex = $oldinfo->card_index;
    $card_model1 = new ModelUserBankCard($cardIndex);
    $info = $card_model1->updateBankCardInfo($user_id, $card_bank, $card_holder, $card_number, 1, time(), $province_id, $city_id, $county_id, $card_branch, $codes, $full_name);
    if (! $info) {
        exit(HttpResponse::exitJSON(FALSE, "添加银行卡数据失败~！", ClentCmd::HINT));
    }
    exit(HttpResponse::exitJSON(true, "更新银行卡成功~！", ClentCmd::HINT));
} else {
    $info = $card_model->addBankCard($user_id, $card_bank, $card_holder, $card_number, 1, time(), $province_id, $city_id, $county_id, $card_branch, $codes, $full_name);
    if (! $info) {
        exit(HttpResponse::exitJSON(FALSE, "添加银行卡数据失败~！", ClentCmd::HINT));
    }
    exit(HttpResponse::exitJSON(true, "绑定银行卡成功~！", ClentCmd::HINT));
}
