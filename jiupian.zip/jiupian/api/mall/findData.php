<?php
use jiupian\api\model\ModelUserCashChange;

$cashChange = new ModelUserCashChange();
$list = $cashChange->selectArrayByWhere('  `time` > 1588262400 and  `time` < 1593532800  and consumer != 84447043238014  ',' `index` asc limit 450,500 ',' distinct consumer ');


foreach($list as $key=>$val){
    $list2 = $cashChange->selectArrayByWhere('`time` > 1588262400 and  `time` < 1593532800 and consumer =  '.$val->consumer ,'`index` asc');
    foreach($list2 as $k1=>$v1){
        if(isset($list2[$k1+1]) && $list2[$k1+1]->before != $v1->later){
            echo $v1->index;
            die();
        }
    }
    echo $val->consumer.'success';
    echo "<br/>";
}