<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/5/2
 * Time: 16:49
 */
header("Content-type:image/png");
error_reporting ( E_ALL );
ini_set ( 'display_errors', '0' );
require_once $_SERVER ["DOCUMENT_ROOT"] . '/HoloPHP/qrcode/phpqrcode.php';

set_time_limit(0);
// 二维码内容
$value = $_REQUEST ["QRCodeContent"];
// 容错级别
$errorCorrectionLevel = 'Q'; // L,M,Q,H
$levels = array("L", "M", "Q", "H");
if (isset ($_REQUEST ["level"]) && in_array($_REQUEST ["level"], $levels)) {
    $errorCorrectionLevel = $_REQUEST ["level"];
}
// 生成图片大小
$matrixPointSize = 10;
if (isset($_REQUEST["size"])) {
    $matrixPointSize = $_REQUEST["size"];
    if ($matrixPointSize <= 4) {
        $matrixPointSize = 4;
    } elseif ($matrixPointSize > 100) {
        $matrixPointSize = 100;
    }
}
$path = md5($value) . ".png";
// 生成二维码图片
QRcode::png($value, $path, $errorCorrectionLevel, $matrixPointSize, 2);
$QR = imagecreatefromstring(file_get_contents($path));

$logo_img = isset($_REQUEST['logo_img']) ? $_REQUEST['logo_img'] : '';
if (!empty($logo_img) && ($logo_content = file_get_contents($logo_img))) {
    $logo = imagecreatefromstring($logo_content);
    $QR_width = imagesx($QR); // 二维码图片宽度
    $QR_height = imagesy($QR); // 二维码图片高度
    $logo_width = imagesx($logo); // logo图片宽度
    $logo_height = imagesy($logo); // logo图片高度
    $logo_qr_width = $QR_width / 5;
    $scale = $logo_width / $logo_qr_width;
    $logo_qr_height = $logo_height / $scale;
    $from_width = ($QR_width - $logo_qr_width) / 2;
    // 重新组合图片并调整大小
    imagecopyresampled($QR, $logo, $from_width, $from_width, 0, 0, $logo_qr_width, $logo_qr_height, $logo_width, $logo_height);
}

// 输出图片
imagepng($QR);
// exit('<img src="qrCodeImage.png">');

