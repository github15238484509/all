<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/6/26
 * Time: 13:46
 */
use jiupian\api\model\MallGoodOrder;
use jiupian\api\model\MallGoodOrderGoods;
use jiupian\api\model\ModelGoodsSku;
use jiupian\api\model\ModelUserSupplier;
use jiupian\api\model\MallGood;
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use HoloPHP\AutoLoader;
use config\ClentCmd;
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
verify::existsingAll("token", "device", "type","page");
$page = $_REQUEST["page"];
$type = $_REQUEST["type"];
$R = new \stdClass();
if($type == 0){//未评价
    $mall_order_good = new MallGoodOrderGoods();
    $list = $mall_order_good->uncommentOrder($user_id, $page);
    if (!$list) {
        $list = array();
        $R->list = $list;
        exit(HttpResponse::exitJSON(TRUE, "获取列表成功~！", ClentCmd::HINT,$R));
    }
    $arr = array();
    foreach ($list as $key => $val) {
        $mallgood = new MallGood($val->goods_index);
        $modelSku = new ModelGoodsSku($val->sku_index);
        $arr[$key]["goods_icon"] = $modelSku->getFieldsValues("sku_pic")?:'';
        $arr[$key]["goods_name"] = $mallgood->getFieldsValue("goods_name");
        $arr[$key]["goods_price"] = $val->goods_price;
        $arr[$key]["goods_cost"] = $val->goods_cost;
        $arr[$key]["goods_bonus"] = $val->goods_bonus;
        $arr[$key]["goods_count"] = $val->goods_count;
        $arr[$key]["total_price"] = $val->goods_cost * $val->goods_count;
        $arr[$key]["order_index"] = $val->order_index;
        $arr[$key]["order_goods_index"] = $val->order_goods_index;
        $arr[$key]["goods_index"] = $val->goods_index;
        $arr[$key]["payment_time"] = $val->payment_time;
        $arr[$key]["comment_time"] = $val->comment_time;
        $supplier_id = $mallgood->getFieldsValue("goods_supplier");
        $supplier = new ModelUserSupplier($supplier_id);
        $arr[$key]["supplier_id"] =$supplier_id;
        $arr[$key]["supplier_name"] =$supplier->getName()?:"";
    }
    $R->list = $arr;
    exit(HttpResponse::exitJSON(TRUE, "获取列表成功~！", ClentCmd::HINT,$R));
}else{//已评价
    $mall_order_good = new MallGoodOrderGoods();
    $list = $mall_order_good->commentOrder($user_id, $page);
    if (!$list) {
        $list = array();
        $R->list = $list;
        exit(HttpResponse::exitJSON(TRUE, "获取列表成功~！", ClentCmd::HINT,$R));
    }
    $arr = array();
    foreach ($list as $key => $val) {
        $mallgood = new MallGood($val->goods_index);
        $modelSku = new ModelGoodsSku($val->sku_index);
        $arr[$key]["goods_icon"] = $modelSku->getFieldsValues("sku_pic")?:'';
        $arr[$key]["goods_name"] = $mallgood->getFieldsValue("goods_name");
        $arr[$key]["goods_price"] = $val->goods_price;
        $arr[$key]["goods_cost"] = $val->goods_cost;
        $arr[$key]["goods_bonus"] = $val->goods_bonus;
        $arr[$key]["goods_count"] = $val->goods_count;
        $arr[$key]["total_price"] = $val->goods_cost * $val->goods_count;
        $arr[$key]["order_index"] = $val->order_index;
        $arr[$key]["order_goods_index"] = $val->order_goods_index;
        $arr[$key]["goods_index"] = $val->goods_index;
        $arr[$key]["payment_time"] = $val->payment_time;
        $arr[$key]["comment_time"] = $val->comment_time;
        $supplier_id = $mallgood->getFieldsValue("goods_supplier");
        $supplier = new ModelUserSupplier($supplier_id);
        $arr[$key]["supplier_id"] =$supplier_id;
        $arr[$key]["supplier_name"] =$supplier->getName()?:"";
    }
    $R->list = $arr;
    exit(HttpResponse::exitJSON(TRUE, "获取列表成功~！", ClentCmd::HINT,$R));
}
