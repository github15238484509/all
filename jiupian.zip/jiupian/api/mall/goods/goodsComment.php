<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/6/14
 * Time: 16:20
 */
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use jiupian\api\model\MallComment;
use config\ClentCmd;
use jiupian\api\model\UserConsumer;
use jiupian\api\model\MallCommentPraise;
use jiupian\api\model\VerifyToken;
use jiupianadmin\model\ModelVirtualUser;
Verify::existsingAll("goods_index","page","type");
$goods_id = $_REQUEST ["goods_index"];
$page = $_REQUEST ["page"];
$type = $_REQUEST ["type"];
$R = new \stdClass();
$mall_comment =new MallComment();
$fields = "*";
$list=$mall_comment->goods_comment_v2($goods_id,$page,$fields,$type);
if(!$list){
    $list = array();
}
if ($list) {
    $mallgood_comment_praise = new MallCommentPraise();
    foreach ( $list as $key => $val ) {
        if($val->comment_type==1){
            $virtual = new ModelVirtualUser($val->comment_consumer);
            $virtualInfo = $virtual->getInfo();
            $val->comment_nick = mb_substr($virtualInfo->virtual_name,0,1,'utf-8')."**";;
            $val->icon = $virtualInfo->virtual_photo;
        }else{
            $users=new UserConsumer($val->comment_consumer);
            if (! $users->isExist ()) {
                $comment_consumer="***";
            }else {
                $comment_consumer=$users->getUserName();
                if (empty($comment_consumer)) {
                    $comment_consumer="***";
                }
            }
            $val->icon = $users->getHeadPhoto();
            //是否匿名评论 0正常 1匿名
            if ($val->comment_anonymity==0 ) {
                //$val->comment_consumer=$comment_consumer;
                $name = $users->getUserName();
                $val->comment_nick = $name;
            }else {
                $name = $users->getUserName();
                $val->comment_nick = mb_substr($name,0,1,'utf-8')."**";
            }
        }
        //$list[$key]->commemt_image = explode(",",$val->comment_images);
        if(empty($val->comment_images)){

        }else{
            $commemt_image = explode(",",$val->comment_images);
            foreach($commemt_image as $key11=>$value11){
                $commemt_image[$key11] =  $value11. "?x-oss-process=image/resize,m_fixed,h_100,w_100";
            }
            $list[$key]->commemt_image = $commemt_image;
        }

        $res = VerifyToken::checkToken($_REQUEST["token"]);
        if($res){
            $is_praise = $mallgood_comment_praise->is_praise ( $val->comment_index ,$res);
            if($is_praise > 0){
                $list[$key]->is_praise = 1;
            }else{
                $list[$key]->is_praise = 0;
            }
        }else{
            $list[$key]->is_praise = 0;
        }
        unset ( $val->comment_order_id );
        unset ( $val->comment_anonymity );
        unset ( $val->activity_type );
        unset ( $val->comment_reason );
        unset ( $val->comment_status );
        unset ( $val->comment_consumer );
        unset ($val->comment_images);
    }
}
$R->score_count = $mall_comment->getGoodsScore($goods_id);
$R->list = $list;
exit(HttpResponse::exitJSON(TRUE, "获取评论列表!", ClentCmd::HINT,$R));