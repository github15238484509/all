<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/6/27
 * Time: 14:57
 */
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use jiupian\api\model\MallGood;
use config\ClentCmd;
use jiupian\api\model\MallGoodOrder;
use jiupian\api\model\MallGoodOrderGoods;
use jiupian\api\model\ModelCurrencies;
use jiupian\api\model\ModelPriceLevel;
use jiupian\api\model\VerifyToken;
use jiupian\api\model\UserConsumer;
Verify::existsingAll("page","type");
$page = $_REQUEST ["page"];
$type  = $_REQUEST["type"];
$R = new \stdClass();
$mallgoods = new MallGood();
$can_buy = 1;
if($type == 0 ){
    $where = " goods_status = 2 and online_area = 1";
    $start_page = $page * 20;
    $limit = " limit  " . $start_page . "  , 20";
    $where .=  $limit;
    $fields = "goods_index,is_skill,skill_price,skill_end_time,skill_start_time,goods_name,goods_price,goods_cost,goods_sort,goods_sort2,goods_status,online_area,goods_sale,goods_icon,goods_icon_new,goods_subtitle ";
    $list = $mallgoods->getGoodsListByWhere($where,NULL,$fields);
    if(!$list){
        $list = array();
    }else{
        $priceLevel = new ModelPriceLevel();
        $is_login = VerifyToken::checkToken($_REQUEST["token"]);
        if(!$is_login){
            $rank = 0;
        }else{
            $userInfo = new UserConsumer($is_login);
            $rank =  $userInfo->getOneFieldData("rank");
        }
        foreach($list as $key=>$val){
            $time = time();
            $list[$key]->goods_cost = $priceLevel->getLine($rank,$val->goods_index)->level_goods_cost;
            if($val->online_area == 2){
                $list[$key]->goods_cost = 0;
            }
            if($val->is_skill == 1 && $val->online_area == 1){
                $list[$key]->goods_cost = $val->skill_price;
                $list[$key]->res_skill_time = $val->skill_end_time - time();
                if( $list[$key]->res_skill_time < 0 ){
                    $list[$key]->is_skill = "0";
                    $list[$key]->res_skill_time = 0;
                }
            }elseif($val->is_skill == 0 && $val->online_area == 1 && $val->skill_start_time > 0 && $val->skill_start_time > $time ){
                $list[$key]->is_skill = "2";
                $list[$key]->res_skill_time = $val->skill_start_time - time();
            }elseif($val->is_skill == 0 && $val->online_area == 1 && $val->skill_start_time > 0 && $val->skill_start_time < $time  && $val->skill_end_time > $time){
                $mallgoods->updateGoodsSkillStatus(1,$val->goods_index);
                $list[$key]->is_skill = "1";
                $list[$key]->res_skill_time = $val->skill_end_time - time();
                if( $list[$key]->res_skill_time < 0 ){
                    $list[$key]->res_skill_time = 0;
                }
            }
            $list[$key]->goods_icon = $val->goods_icon."?x-oss-process=image/resize,m_lfit,w_800";
            $list[$key]->can_buy = $can_buy;
        }
    }
    exit(HttpResponse::exitJSON(true, "获取商品列表成功~！", "hint",$list));
}else{
    $is_login = VerifyToken::checkToken($_REQUEST["token"]);
//    if($is_login){
//        //判断是否已买过商品
//        $mallorder = new MallGoodOrder();
//        $mallorder_goods = new MallGoodOrderGoods();
//        $order_index_list = $mallorder->selectArrayByWhere("order_consumer = {$is_login} and order_status > 0","order_time desc","order_index");
//        $goods_index_array = [];
//        if($order_index_list){
//            foreach ($order_index_list as $v){
//                $goods_index = $mallorder_goods->findOrderGoodsByOrder($v->order_index,"goods_index");
//                if($goods_index){
//                    foreach ($goods_index as $va){
//                        $goods_index_array[] = $va->goods_index;
//                    }
//                }
//            }
//        }
//        if (!empty($goods_index_array)){
//           foreach ($goods_index_array as $value){
//               $mall_goods = new MallGood($value);
//               $online_area = $mall_goods->getFieldsValue("online_area");
//               $goods_status = $mall_goods->getFieldsValue("goods_status");
//               if($goods_status == 2 && $online_area != 1){
//                   $can_buy = 0;
//               }
//           }
//        }
//    }

    $where = " goods_status = 2 and  online_area != 1 ";
    $start_page = $page * 20;
    $limit = " limit  " . $start_page . "  , 20";
    $where .=  $limit;
    $fields = "goods_index,goods_name,goods_price,is_skill,skill_price,skill_end_time,goods_cost,goods_sort,goods_sort2,goods_status,online_area,goods_sale,goods_icon,goods_icon_new,goods_subtitle ";
    $list = $mallgoods->getGoodsListByWhere($where,NULL,$fields);
    if(!$list){
        $list = array();
    }else{
        foreach($list as $key=>$val){
            $list[$key]->goods_icon = $val->goods_icon."?x-oss-process=image/resize,m_lfit,w_800";
            $list[$key]->can_buy = $can_buy;
            if($val->is_skill == 1 && $val->online_area == 1){
                $val->goods_cost = $val->skill_price;
                $list[$key]->res_skill_time = $val->skill_end_time - time();
                if($list[$key]->res_skill_time < 0 ){
                    $list[$key]->res_skill_time = 0;
                }
            }
        }
    }
    exit(HttpResponse::exitJSON(true, "获取商品列表成功~！", "hint",$list));
}
