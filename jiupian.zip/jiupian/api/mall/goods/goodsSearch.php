<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/6/27
 * Time: 16:49
 */
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use jiupian\api\model\MallGood;
use config\ClentCmd;
use jiupian\api\model\ModelCurrencies;
Verify::existsingAll("page","keywords");
$R = new \stdClass();
$page = $_REQUEST ["page"];
$keywords = trim($_REQUEST["keywords"]);
$where = " goods_status = 2 and goods_name like '%$keywords%'";
$mallgoods = new MallGood();
//$where = " goods_status = 2 and  FIND_IN_SET ('$keywords',keywords)";
$sort = " goods_recommend desc,goods_sale desc ";
$start_page = $page * 20;
$limit = " limit  " . $start_page . "  , 20";
$sort = $sort.$limit;
$fields = "goods_index,goods_name,goods_price,goods_cost,goods_sort,goods_sort2,goods_status,online_area,goods_sale,goods_icon,goods_icon_new";
$list = $mallgoods->getGoodsListByWhere($where,$sort,$fields);
if(!$list){
    $list = array();
}else{
    $currieences = new ModelCurrencies();
    $coinInfo = $currieences->getDefultCoin();
    foreach($list as $key=>$val){
        $list[$key]->goods_icon = $val->goods_icon;
    }
}
$R->list = $list;
exit(HttpResponse::exitJSON(true, "商品搜索成功~！", "hint",$R));
