<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/6/27
 * Time: 16:01
 */
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use jiupian\api\model\MallGood;
use config\ClentCmd;
use jiupian\api\model\ModelGoodsClassify;
use jiupian\api\model\ModelCurrencies;
Verify::existsingAll("page");
$R = new \stdClass();
$classify = new ModelGoodsClassify();
$classify_list = $classify->getClassify();
if(!$classify_list){
    $classify_list = array();
}
if(!isset( $_REQUEST['id']) || empty($_REQUEST['id'])){
    $id = $classify_list[0]->id;
}else{
    $id = $_REQUEST['id'];
    if($id == ""){
        $id = $classify_list[0]->id;
    }
}
$classify = new ModelGoodsClassify($id);
$mallgoods = new MallGood();
if(!$classify->isExist()){
    exit(HttpResponse::exitJSON(FALSE, "商品分类传输错误", ClentCmd::HINT));
}
$where = " goods_status = 2  and FIND_IN_SET ($id,goods_sort)";
$sort = " goods_recommend desc,goods_sale desc ";
$start_page = $page * 20;
$limit = " limit  " . $start_page . "  , 20";
$sort = $sort.$limit;
$fields = "goods_index,goods_name,goods_price,goods_cost,goods_sort,goods_sort2,goods_status,online_area,goods_sale,goods_icon";
$list = $mallgoods->getGoodsListByWhere($where,$sort,$fields);
if(!$list){
    $list = array();
}else{
    $currieences = new ModelCurrencies();
    $coinInfo = $currieences->getDefultCoin();
    foreach($list as $key=>$val){
        $list[$key]->goods_bonus = $mallgoods->getCalculateBonus($val->online_area,$val->goods_cost);
        $list[$key]->goods_icon = $val->goods_icon;
        $list[$key]->coin_name = $coinInfo->currencies_name;
        $currencies_price = intval($coinInfo->currencies_price);
        $list[$key]->coin_count = floor($list[$key]->goods_bonus/$currencies_price);
    }
}
$R->classify_list = $classify_list;
$R->list = $list;
exit(HttpResponse::exitJSON(true, "获取商品列表成功~！", "hint",$R));


