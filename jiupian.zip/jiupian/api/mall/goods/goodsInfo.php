<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/6/13
 * Time: 13:37
 */
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use jiupian\api\model\MallGood;
use jiupian\api\model\ModelUserSupplier;
use jiupian\api\model\ModelGoodsSku;
use jiupian\api\model\ModelConfigRegion;
use jiupian\api\model\VerifyToken;
use tables\account\LoginStatus;
use jiupian\api\model\GoodsCollect;
use jiupian\api\model\MallComment;
use jiupian\api\model\UserConsumer;
use jiupian\api\model\ModelGoodsIntroduce;
use jiupian\api\model\ModelGoodsAlbum;
use jiupian\api\model\ModelFreightTemplates;
use config\ClentCmd;
use jiupian\api\model\ModelConfigSKU;
use jiupian\api\model\ModelUserFoot;
use jiupian\api\model\ModelCurrencies;
use jiupian\api\model\types\UserLevel;
use jiupian\api\model\ModelPriceLevel;
use jiupianadmin\model\ModelVirtualUser;
Verify::existsingAll("goods_index");
$goods_index = $_REQUEST["goods_index"];
$mallgood_info = new MallGood($goods_index);
$info = $mallgood_info->getGoodsInfoByIndex($goods_index);

$time = time();
if($info->is_skill == 1){
    $info->res_skill_time = $info->skill_end_time - time();
    if( $info->res_skill_time < 0 ){
        $info->is_skill == "0";
        $mallgood_info->updateGoodsSkillStatus(0,$info->goods_index);
        $mallgood_info->updateFieldsValue("skill_start_time",0);
        $mallgood_info->updateFieldsValue("skill_end_time",0);
        $info->res_skill_time = 0;
    }
}elseif($info->is_skill == 0 &&  $info->online_area == 1 && $info->skill_start_time > 0 && $info->skill_start_time > $time){
    $info->is_skill = "2";
    $info->res_skill_time = $info->skill_start_time - time();
}elseif($info->is_skill == 0 &&  $info->online_area == 1 && $info->skill_start_time > 0 && $info->skill_start_time <  $time && $info->skill_end_time >  $time){
    $mallgood_info->updateGoodsSkillStatus(1,$info->goods_index);
    $info->is_skill = "1";
    $info->res_skill_time = $info->skill_end_time - time();
    if( $info->res_skill_time < 0 ){
        $info->res_skill_time = 0;
    }
}


$album = new ModelGoodsAlbum();
$album_list = $album->getGoodsAllPic($info->goods_index);
$album_arr = array();
if ($album_list) {
    foreach ($album_list as $key => $val) {
        array_push($album_arr, $val->photo_thumb);
    }
}
if (count($album_arr) == 0) {
    array_push($album_arr, $info->goods_icon);
}
$info->goods_album = $album_arr;
// 商品介绍图集
$introduce = new ModelGoodsIntroduce();
$introduce_list = $introduce->getIntroInfo($info->goods_index);
$introduce_arr = array();
if ($introduce_list) {
    foreach ($introduce_list as $key => $val) {
        array_push($introduce_arr, $val->image_url);
    }
}
$info->goods_introduce = $introduce_list;
// 商品sku信息
$sku_array = array();
$price_array = array();
$sku = new ModelGoodsSku ();
$sku_list = $sku->getGoodsSkuLists($info->goods_index);
//var_dump($sku_list);
$is_login = VerifyToken::checkToken($_REQUEST["token"]);
$price_level = new ModelPriceLevel();
if ($sku_list && count($sku_list) > 0) {

    foreach ($sku_list as $key => $value) {
        unset ($value->sku_lefen_price);
        unset ($value->sku_repertory);
        unset ($value->sku_update_time);
        unset ($value->sku_code);
        unset ($value->sku_supply_price);
        unset ($value->return_integral);
        unset ($value->sku_integral_price);
        unset ($value->sku_give_integral);
        unset ($value->sku_defective);
        unset ($value->sku_give_integral);
        $online_area = $mallgood_info->getFieldsValue('online_area');

        if($online_area == 1){
            if($is_login){
                $users = new UserConsumer($is_login);
                $rank = $users->getOneFieldData('rank');
            }else{
                $rank = 0;
            }

            $value->sku_cost_price = $price_level->getSkuGoods($rank,$goods_index,$value->sku_index)->level_goods_cost;

        }

        if( $info->is_skill == 1){
            $value->sku_cost_price = $mallgood_info->getOneField('skill_price');
        }


        $skuInfo = $value->sku_info;
        array_push($price_array, $value);
        if (substr($skuInfo, 0, 3) == "0:0") {
            $sku_array = array();
            continue;
        } else {
            $sku_array = array_merge($sku_array, explode(",", $skuInfo));
        }
    }
}
unset($currieencesList);
$info->goods_sku_price = $price_array;
$online_area = $info->online_area;
if($online_area == UserLevel::VIPGOODS || $online_area == UserLevel::SUPREGOODS  || $online_area == UserLevel::PARTNERGOODS  || $online_area == UserLevel::SUSHANHOMEGOODS ){
    $info->libao_goods = 1;
}else{
    $info->libao_goods = 0;
    $price_level = new ModelPriceLevel();
    if($is_login){
        $users = new UserConsumer($is_login);
        $rank = $users->getOneFieldData('rank');
    }else{
        $rank = 0;
    }
    $info->goods_cost = $price_level->getLine($rank,$goods_index)->level_goods_cost;
}
//旗舰店信息
$supplier = new ModelUserSupplier($info->goods_supplier);
$supplier_name = $supplier->getName() ?: "";
$supplier_icon = $supplier->getOneField("supplier_icon");
$supplier_popular = $supplier->getOneField("supplier_popular");
$modelFreight = new ModelFreightTemplates($info->freight_id);
if($modelFreight->isExist() && !empty($modelFreight ->getOneField("desc"))){
    $goods_freight_desc = $modelFreight ->getOneField("desc");
    if($goods_freight_desc == "\n"){
        $goods_freight_desc = "";
    }
}else{
    $goods_freight_desc = $supplier->getFreightName() ?: "";
}
$info->goods_freight_desc = '包邮';
/*$configRegion = new ModelConfigRegion();
$supplier_province = $configRegion->getCityById($supplier->getProvince())->region_name;
$supplier_city = $configRegion->getCityById($supplier->getCity())->region_name;
$supplier_address = ($supplier_province == $supplier_city) ? $supplier_city : ($supplier_province . $supplier_city);
$info->supplier_info = array(
    'supplier_id' => $info->goods_supplier,
    'supplier_icon' =>"jiupian/logo.png",
    'supplier_name' => $supplier_name,
    'supplier_address' => $supplier_address ?: '',
    'supplier_popular' => $supplier_popular,
    'goods_freight_desc' => $goods_freight_desc
);*/
//更新商品浏览量
$mallgood_info->updateGoodsRenqi($goods_index);
//是否收藏
$is_login = VerifyToken::checkToken($_REQUEST["token"]);
if(!$is_login){
    $info->is_collect = 0;
}else{
    if(isset($_REQUEST['type'])){
        $cType = $_REQUEST['type'];
    }else{
        $cType = 0;
    }
    $status = new LoginStatus($_REQUEST["token"]);
    $user_id = $status->user_id();
    $collect = new GoodsCollect ($user_id);
    $collectLog = $collect->getByGoodsID_mall($goods_index,$cType);
    if ($collectLog) {
        $info->yet_collect = 1;
    }else{
        $info->yet_collect = 0;
    }
    //更新用户浏览记录
    $userFoot = new ModelUserFoot();
    $userFoot->addFoot($user_id,$goods_index);
}
//口碑精选
$mall_comment =new MallComment();
$sort = " comment_index DESC";
$fields = "comment_consumer,comment_type,comment_anonymity,comment_nick,comment_score,comment_content,comment_images,comment_time,payment_time";
$score_info = $mall_comment->getHighScore($goods_index);
if(!$score_info){
    $info->score_info = array();
}else{
    if($score_info->comment_type == 1){
        $virtual = new ModelVirtualUser($score_info->comment_consumer);
        $virtualInfo = $virtual->getInfo();
        $score_info->comment_nick = mb_substr($virtualInfo->virtual_name,0,1,'utf-8')."**";;
        $score_info->comment_head = $virtualInfo->virtual_photo;
        $info->score_info = $score_info;
    }else{
        $user = new UserConsumer($score_info->comment_consumer);
        if ($score_info->comment_anonymity==0 ) {
            $score_info->comment_nick = $user->getOneFieldData("name");
        }else {
            $score_info->comment_nick = mb_substr($user->getOneFieldData("name"),0,1,'utf-8')."**";
        }
        $score_info->comment_head = $user->getHeadPhoto();
        $info->score_info = $score_info;
    }

}
if( $info->is_skill == 1){
    $info->goods_cost = $mallgood_info->getOneField('skill_price');
}
exit(HttpResponse::exitJSON(TRUE, "获取商品详情成功!", ClentCmd::HINT,$info));
