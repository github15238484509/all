<?php
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use jiupian\api\model\MallComment;
use config\ClentCmd;
use jiupian\api\model\MallCommentPraise;
use HoloPHP\AutoLoader;
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
$R = new \stdClass ();
Verify::existsingAll("comment_index" ,"type");
$comment_index = $_REQUEST ["comment_index"];
$comment_type = $_REQUEST ["type"];

// 根据商品id取得商品详情
$mallgood_comment_praise = new MallCommentPraise();
$mallgood_comment_praise->stopAutocommit();
//1点赞  0取消点赞
if ($comment_type==1) {
	$res=$mallgood_comment_praise->comment_praise ( $comment_index ,$user_id);
	$count=1;
	$msg = "点赞成功";
}elseif ($comment_type==0){
	$res=$mallgood_comment_praise->cancle_praise ( $comment_index ,$user_id);
	$count=-1;
    $msg = "取消点赞成功";
}
if (!$res) {
    $mallgood_comment_praise->rollback();
    exit(HttpResponse::exitJSON(FALSE, "点赞失败", ClentCmd::HINT));
}
$mallgood_comment = new MallComment();
$res=$mallgood_comment->update_comment_praise($comment_index, $count);
if (!$res) {
    $mallgood_comment_praise->rollback();
    exit(HttpResponse::exitJSON(FALSE, "点赞失败", ClentCmd::HINT));
}
$mallgood_comment_praise->commit();
exit(HttpResponse::exitJSON(TRUE, $msg, ClentCmd::HINT));
?>