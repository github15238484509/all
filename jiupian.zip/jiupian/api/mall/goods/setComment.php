<?php
use jiupian\api\model\MallGoodOrderGoods;
use jiupian\api\model\MallGood;
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use HoloPHP\AutoLoader;
use config\ClentCmd;
use jiupian\api\model\MallComment;
use jiupian\api\model\MallGoodOrder;
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
verify::existsingAll( "order_index","comment_score","comment_content","order_goods_index","comment_express_score","comment_service_score");
$order_id = $_REQUEST ["order_index"];
$comment_anonymity = 1;//全部匿名
$comment_score = $_REQUEST ["comment_score"];
$comment_content = $_REQUEST ["comment_content"];
$comment_images = $_REQUEST ["comment_images"]?:'';
$order_goods_index=$_REQUEST ["order_goods_index"];
$comment_express_score=$_REQUEST ["comment_express_score"];
$comment_service_score=$_REQUEST ["comment_service_score"];
$mallgood_comment = new MallComment ();
$mall_order_goods= new MallGoodOrderGoods($order_goods_index);
if ($mall_order_goods->getFieldsValue('goods_status') == 3) {
    exit(HttpResponse::exitJSON(FALSE, "已经操作过请勿重复操作~！", ClentCmd::HINT));
}
$goods_sku = $mall_order_goods->getFieldsValue('goods_sku');
$goods_id = $mall_order_goods->getFieldsValue('goods_index');
$mallgoodorder = new MallGoodOrder($order_id);
$payment_time = $mallgoodorder->getFieldsValue("payment_time");
$info=new \stdClass();
$info->comment_order_id = $order_id;
$info->comment_consumer = $user_id;
$info->comment_anonymity = $comment_anonymity;
$info->comment_score = $comment_score;
$info->comment_content = $comment_content;
$info->comment_images = $comment_images;
$info->comment_goods_sku = "$goods_sku";
$info->comment_goods_id = $goods_id;
$info->comment_express_score = $comment_express_score;
$info->comment_service_score = $comment_service_score;
$info->payment_time = $payment_time;
//添加评论
$mall_order_goods->stopAutocommit();
$res = $mallgood_comment->setComment($info);
if (!$res) {
    $mall_order_goods->rollback();
    exit(HttpResponse::exitJSON(FALSE, "添加评论失败1~！", ClentCmd::HINT));
}
//评论完之后需要更新订单状态
$res1=$mall_order_goods->updateOrderGoodsStatus(3, $order_id ,$order_goods_index);
$mall_goods=new MallGood($goods_id);
$res2=$mall_goods->updateGoodsStatus($comment_score,$goods_id);
if (!$res1 ||!$res2) {
    $mall_order_goods->rollback();
    exit(HttpResponse::exitJSON(FALSE, "添加评论失败2~！", ClentCmd::HINT));
}
$mall_order_goods->commit();
exit(HttpResponse::exitJSON(TRUE, "添加评论成功~！", ClentCmd::HINT));
?>