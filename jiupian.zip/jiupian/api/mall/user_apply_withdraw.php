<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/4/24
 * Time: 13:11
 */
use HoloPHP\tools\HttpResponse;
use config\ClentCmd;
use HoloPHP\tools\Verify;
use jiupian\api\model\ModelUserBankCard;
use jiupian\api\model\ModelUserCashChange;
use HoloPHP\tools\UUID;
use jiupian\api\model\ModelUserExtractOrder;
use jiupian\api\model\UserConsumer;
use jiupian\api\model\types\SystemUser;
use HoloPHP\AutoLoader;
use jiupian\api\model\types\UserCashChange;
use jiupian\api\model\types\UserLevel;
use jiupian\api\model\ModelFunctions;
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
$R=new \stdClass();
Verify::existsingAll("cash_amount","card_index");
$functions = new ModelFunctions();
$res = $functions->checkPhone($userInfo->getPhone());
if(!$res){
    exit(HttpResponse::exitJSON(FALSE, "请您去个人中心绑定手机号~！", ClentCmd::HINT));
}
if($userInfo->getOneFieldData("rank") == UserLevel::REGISTERUSER){
    exit(HttpResponse::exitJSON(FALSE, "暂时不能提现~！", ClentCmd::HINT));
}
$modelUserExtraOrder = new ModelUserExtractOrder();
if($_REQUEST['cash_amount']%10000 != 0){
    exit(HttpResponse::exitJSON(FALSE, "金额必须为整100的整数倍~！", ClentCmd::HINT));
}
$cash_amount = $_REQUEST['cash_amount'];
$card_index = $_REQUEST['card_index'];
$card_model = new ModelUserBankCard();
$info = $card_model->getCardByMerchant($user_id);
if(!$info){
    exit(HttpResponse::exitJSON(FALSE, "用户没有银行卡~！", ClentCmd::HINT));
}
if($info->card_index != $card_index){
    exit(HttpResponse::exitJSON(FALSE, "当前银行卡与用户不符~！", ClentCmd::HINT));
}
if(empty($info->card_bank) || empty($info->card_holder) || empty($info->card_number)){
    exit(HttpResponse::exitJSON(FALSE, "银行卡信息不完整~！", ClentCmd::HINT));
}else{
    if(empty($cash_amount)){
        exit(HttpResponse::exitJSON(FALSE, "请填写提现金额须为100的倍数~！", ClentCmd::HINT));
    }
    //获取提现的金额
    $total_extract_cash = $userInfo->getOneFieldData('total_extract_cash');
    $total_income = $userInfo->getOneFieldData('total_income');
    $cashchange = new ModelUserCashChange();
   $data['consumer'] = $user_id;
    $year = date("Y");
    $month = date("m");
    $day = date("d");
    $start = mktime(0,0,0,$month,$day,$year);//当天开始时间戳
    $end = mktime(23,59,59,$month,$day,$year);//当天结束时间戳
    $data['timeFrom'] = $start;
    $data['timeTo'] = $end;
    $data['change_type'] = "1,7,8,9,10,11,49,12,13,14,15,16";
    //$one_cash = $cashchange->getSumByTime($data);
    $userCash = $userInfo->getOneFieldData('cash');
    $one_cash = 0;
    $aCash = floor($total_income - $total_extract_cash - $one_cash);
    if($userCash < 10000 || $aCash < 0){
        $aCash = 0;
    }else{
        if($aCash >= $userCash){
            $aCash = $userCash;
        }
        $aCash = floor($aCash/10000)*10000;
    }

    if($aCash < $cash_amount ){
        exit(HttpResponse::exitJSON(FALSE, "您当前提现余额不足，请核对~！", ClentCmd::HINT));
    }
    //获取系统用户
    $system_user_id = SystemUser::SYSTEM_WITHDRAW;
    //获取提现手续费比例
    //$rates = json_decode(WithDraw::getNewRate(),true);

   /* $rate = 0;
    $service_money = 0;*/
    $rate = 0.20;
    $service_money = floor($cash_amount*$rate);
    //扣除用户的cash
    $oldCash = $userInfo -> getCash();
    $modelCashChange = new ModelUserCashChange();
    $modelCashChange->stopAutocommit();
    $deductRet = $userInfo->deductCash($cash_amount);

    if (!$deductRet ) {
        $modelCashChange->rollback();
        exit(HttpResponse::exitJSON(FALSE, "服务器异常，请稍后重试1~！", ClentCmd::HINT));
    }
    //添加提现记录
    $orderId = UUID::order_id();
    $balanceRet = $modelUserExtraOrder->addDeal($orderId,$user_id,$oldCash,$oldCash-$cash_amount,$cash_amount,$service_money,$card_index);
    if(!$balanceRet){
        $modelCashChange->rollback();
        exit(HttpResponse::exitJSON(FALSE, "服务器异常，请稍后重试2~！", ClentCmd::HINT));
    }
    //记录提现日志
    $cashChangeRet = $modelCashChange->addDeal($user_id,$oldCash,$oldCash-$cash_amount+$service_money,$cash_amount-$service_money,UserCashChange::TYPE_WITHDRAWAL_DEDUCT,0,$orderId,0,0,0,$system_user_id);
    if(!$cashChangeRet){
        $modelCashChange->rollback();
        exit(HttpResponse::exitJSON(FALSE, "服务器异常，请稍后重试3~！", ClentCmd::HINT));
    }
    $cashChangeRet = $modelCashChange->addDeal($user_id,$oldCash-$cash_amount+$service_money,$oldCash-$cash_amount,$service_money,UserCashChange::TYPE_SHOUXUFEI_DEDUCT,0,$orderId,0,0,0,$system_user_id);
    if(!$cashChangeRet){
        $modelCashChange->rollback();
        exit(HttpResponse::exitJSON(FALSE, "服务器异常，请稍后重试3~！", ClentCmd::HINT));
    }

    //更新用户累计消耗的cash
    /*$total_out_cash = $userInfo->getOneFieldData("total_out_cash");
    $update_out_cash = $userInfo->updateFields("total_out_cash",$total_out_cash+$cash_amount);
    if(!$update_out_cash){
        $modelCashChange->rollback();
        exit(HttpResponse::exitJSON(FALSE, "服务器异常，请稍后重试4~！", ClentCmd::HINT));
    }*/
    //更新用户累计分红
    $res_extract_cash = $userInfo->updateFields("total_extract_cash",$total_extract_cash + $cash_amount);
    if(!$res_extract_cash){
        $modelCashChange->rollback();
        exit(HttpResponse::exitJSON(FALSE, "服务器异常，请稍后重试6~！", ClentCmd::HINT));
    }
    //添加系统用户的cash以及log
    $systemInfo = new UserConsumer($system_user_id);
    $systemCash_before = $systemInfo->getCash();
    $systemCash_after = $systemCash_before + $cash_amount;
    $add_sysytem_cash = $systemInfo->addCash($cash_amount);
    $add_sysytem_cash_log = $modelCashChange->addDeal($system_user_id,$systemCash_before,$systemCash_after,$cash_amount,UserCashChange::TYPE_WITHDRAWAL_ADD,0,$orderId,0,0,0,$user_id);
    if(!$add_sysytem_cash || !$add_sysytem_cash_log){
        $modelCashChange->rollback();
        exit(HttpResponse::exitJSON(FALSE, "服务器异常，请稍后重试5~！", ClentCmd::HINT));
    }
    $modelCashChange->commit();
    $R->card_bank = $info->card_bank;
    $R->card_number = $info->card_number;
    $R->time = time();
    $R->cash_amount = $cash_amount;
    exit(HttpResponse::exitJSON(TRUE, "申请提现成功~！", ClentCmd::HINT,$R));

}

