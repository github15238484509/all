<?php
namespace jiupian\api\mall;
use jiupian\api\model\ModelUserBankCard;
use jiupian\api\model\ModelBankLogo;
use HoloPHP\tools\HttpResponse;
use config\ClentCmd;
use jiupian\api\model\ModelUserCashChange;
use HoloPHP\AutoLoader;
use jiupian\api\model\types\UserLevel;
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
$R = new \stdClass ();
$card_model = new ModelUserBankCard();
$info = $card_model->getCardByMerchant($user_id);
//银行卡信息绑定并且信息完整
if(!$info){
    exit(HttpResponse::exitJSON(FALSE, "此帐号还没有银行卡~！", ClentCmd::HINT));    
}
//银行卡的相关logo获取
$cardLogo = new ModelBankLogo();
if(!empty($info->card_bank)){
    $logo = $cardLogo -> getBankLogo($info->card_bank);
}else{
    $logo = '';
}
$info->logo = $logo;
unset($info->bank_code);
unset($info->branch_bank);
unset($info->bank_full_name);
$R->card_info = $info;
//获取提现金额
$total_extract_cash = $userInfo->getOneFieldData('total_extract_cash');
if($userInfo->getOneFieldData("rank") == UserLevel::REGISTERUSER){
    $total_income = 0;
}else{
    $total_income = $userInfo->getOneFieldData('total_income');
}
$cashchange = new ModelUserCashChange();
$data['consumer'] = $user_id;
$year = date("Y");
$month = date("m");
$day = date("d");
$start = mktime(0,0,0,$month,$day,$year);//当天开始时间戳
$end = mktime(23,59,59,$month,$day,$year);//当天结束时间戳
$data['timeFrom'] = $start;
$data['timeTo'] = $end;
$data['change_type'] = "1,7,8,9,10,11,49,12,13,14,15,16";
//$one_cash = $cashchange->getSumByTime($data);
$userCash = $userInfo->getOneFieldData('cash');
$one_cash = 0;
$aCash = floor($total_income - $total_extract_cash - $one_cash);
if($userCash < 10000 ||  $aCash < 0){
    $aCash = 0;
}else{
    if($aCash >= $userCash){
        $aCash = $userCash;
    }
    $aCash = floor($aCash/10000)*10000;
}
$R->available_cash = (string)$aCash;//可提现余额
$R->rate = "0.20";
//银行，持卡人 卡号 支行
if(empty($info->card_bank) || empty($info->card_holder) || empty($info->card_number)){
    exit(HttpResponse::exitJSON(FALSE, "银行卡信息不完整~！", ClentCmd::HINT));
}else{
    exit(HttpResponse::exitJSON(TRUE, "银行卡信息~！", ClentCmd::HINT,$R));
}
