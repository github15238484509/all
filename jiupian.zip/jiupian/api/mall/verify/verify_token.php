<?php
namespace jiupian\api\mall\verify;
use HoloPHP\tools\HttpResponse;
use jiupian\api\model\UserConsumer;
use config\ClentCmd;
use tables\account\LoginStatus;

/**
 * 验证用户登录状态是否有效
 *
 * @author YongLe
 */
$token = $_REQUEST["token"];
if (! $token) {
    $token = $_COOKIE["token"];
}
$status = new LoginStatus($token);
// token验证无效
if (! $status->existToken()) {
    exit(HttpResponse::exitJSON(FALSE, "登录状态失效，请重新登录~！", ClentCmd::POPUP_TO_LOGIN, $token));
}
$user_id = $status->user_id();
$userInfo = new UserConsumer($user_id, null);
// 用户数据不存在
if (! $userInfo->isExist()) {
    exit(HttpResponse::exitJSON(FALSE, "帐号异常，请联系客服~！", ClentCmd::POPUP_TO_AFFIRM, $user_id));
}else{
    //更新用户最近浏览时间
    $userInfo->updateFields("browse_new_time",time());
}
// 登录状态有效，继续执行
