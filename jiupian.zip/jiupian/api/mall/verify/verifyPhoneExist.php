<?php
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use jiupian\api\model\UserConsumer;

if (! Verify::existsingAll("phone")) {
    exit(HttpResponse::exitJSON(false, "缺少请求参数~！", "hint"));
}
$user = new UserConsumer(null, null, $_REQUEST["phone"]);
if ($user->isExist()) {
    exit(HttpResponse::exitJSON(FALSE, "此手机号已注册~！", "popup_to_login"));
}
//可以注册，继续执行