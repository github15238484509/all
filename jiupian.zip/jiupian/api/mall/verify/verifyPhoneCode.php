<?php
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use HoloPHP\tools\SMS;
use HoloPHP\server\Server;
if (! Verify::existsingAll("phone", "phone_code")) {
    exit(HttpResponse::exitJSON(false, "缺少请求参数~！", "hint"));
}
if(Server::environment("prod")){
    $code = SMS::verifyCode($_REQUEST["phone"], $_REQUEST["phone_code"]);
}else{
    $code = 1;
}
if ($code == - 5) {
    exit(HttpResponse::exitJSON(FALSE, "验证码错误", "hint"));
} elseif ($code == 0) {
    exit(HttpResponse::exitJSON(FALSE, "该手机号未曾获取验证码，请重新获取", "hint"));
} elseif ($code != 1) {
    exit(HttpResponse::exitJSON(FALSE, "服务器异常~！", "hint"));
}
// 验证通过，继续执行业务逻辑
?>