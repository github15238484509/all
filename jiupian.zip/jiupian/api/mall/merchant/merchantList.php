<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/8/1
 * Time: 10:15
 */
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use config\ClentCmd;
use jiupian\api\model\Merchant;
use jiupian\api\model\ModelConfigRegion;
use jiupian\api\model\MerchantAlbum;
use jiupian\api\model\CoordinateDistance;
use jiupian\api\model\SetLocation;
use jiupian\api\model\ModelFunctions;
Verify::existsingAll("token","device","page","user_longitude","user_latitude");
$R = new \stdClass();
$page = $_REQUEST["page"];
$count  = 20;
$start = $page * $count;
$limit = " limit ".  $start .",".$count;
$lat = trim($_REQUEST["user_latitude"]);
$lng = trim($_REQUEST["user_longitude"]);
if(empty($lat) || empty($lng) || $lat == 0 || $lng == 0){
    $functions = new ModelFunctions();
    $ip = $functions->get_client_ip();
    $location = new SetLocation();
    $res = $location->getlocation($ip);
    if($res->succeed){
        $lat =   $res->lat;
        $lng =   $res->lng;
    }else{
        $lat = 0;
        $lng = 0;
    }
}
$mer = new Merchant();
$merchant_list = $mer->getListByWhere($fields = 'merchant_latitude,merchant_longitude,merchant_id,merchant_name,merchant_province,merchant_city,merchant_county,merchant_address', $where = ' where merchant_status = 1', $limit, $order_by = '');
if(!$merchant_list){
    $R->list = array();
}else{
    $album = new MerchantAlbum();
    $configRegion = new ModelConfigRegion();
    foreach($merchant_list as $key=>$val){
        $merchant_list[$key]->merchant_address = $configRegion->getName($val->merchant_province).$configRegion->getName($val->merchant_city).$configRegion->getName($val->merchant_county).$val->merchant_address;
        $merchant_list[$key]->merchant_logo = $album->getPhotoListData($val->merchant_id,2)[0]->photo_path;
        if($lat == 0 || $lng == 0){
            $lat =  $val->merchant_latitude;
            $lng = $val->merchant_longitude;
        }
        $cd = new CoordinateDistance($lat,$lng,$val->merchant_latitude,$val->merchant_longitude);
        $merchant_distance =$cd -> result();
        $merchant_list[$key]->merchant_distance = number_format($merchant_distance/1000, 2);
    }
    $R->list = $merchant_list;
}
exit(HttpResponse::exitJSON(true, "获取素膳之家列表", ClentCmd::HINT,$R));