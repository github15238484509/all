<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/9/19
 * Time: 15:15
 */
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use config\ClentCmd;
use HoloPHP\AutoLoader;
use jiupian\api\model\Merchant;
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
$R = new \stdClass ();
Verify::existsingAll( "province_id", "city_id", "county_id");
$province_id = $_REQUEST["province_id"];
$city_id = $_REQUEST["city_id"];
$county_id = $_REQUEST["county_id"];
$mer = new Merchant();
$list = $mer->getMerListByRegion($province_id,$city_id,$county_id);
if(!$list){
    $list = [];
}
$R->list = $list;
exit(HttpResponse::exitJSON(TRUE, "获取列表成功~！", ClentCmd::HINT,$R));
