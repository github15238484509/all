<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/8/1
 * Time: 10:43
 */
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use config\ClentCmd;
use jiupian\api\model\Merchant;
use jiupian\api\model\ModelConfigRegion;
use jiupian\api\model\MerchantAlbum;
Verify::existsingAll("token","device","merchant_id");
$R = new \stdClass();
$merchant_id = $_REQUEST["merchant_id"];
$mer = new Merchant($merchant_id);
if(!$mer->isExist()){
    exit(HttpResponse::exitJSON(false, "获取素膳之家详情失败", ClentCmd::HINT));
}else{
    $configRegion = new ModelConfigRegion();
    $R->merchant_image = explode(",",$mer->getOneFieldData("merchant_image"))?:"";
    $R->merchant_name = $mer->getOneFieldData("merchant_name");
    $R->merchant_tel = $mer->getOneFieldData("merchant_tel");
    $R->merchant_worktime = $mer->getOneFieldData("merchant_worktime");
    $R->merchant_desp = $mer->getOneFieldData("merchant_desp");
    $R->merchant_activite = $mer->getOneFieldData("merchant_activite");
    $R->merchant_longitude = $mer->getOneFieldData("merchant_longitude");
    $R->merchant_latitude = $mer->getOneFieldData("merchant_latitude");
    $merchant_province =  $mer->getOneFieldData("merchant_province");
    $merchant_city =  $mer->getOneFieldData("merchant_city");
    $merchant_county =  $mer->getOneFieldData("merchant_county");
    $address = $mer->getOneFieldData("merchant_address");
    $R->merchant_address = $configRegion->getName($merchant_province).$configRegion->getName($merchant_city).$configRegion->getName($merchant_county).$address;

}
exit(HttpResponse::exitJSON(true, "获取素膳之家详情", ClentCmd::HINT,$R));