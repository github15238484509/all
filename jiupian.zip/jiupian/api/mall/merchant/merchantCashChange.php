<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/8/7
 * Time: 18:02
 */
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use HoloPHP\AutoLoader;
use config\ClentCmd;
use jiupian\api\model\ModelUserCashChange;
use jiupian\api\model\types\UserCashChange;
$R = new \stdClass();
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
Verify::existsingAll("token","page");
$start_time = null;
$page = $_REQUEST["page"];
$cashChange = new ModelUserCashChange();
$list = $cashChange->getListv2($user_id,$page,$start_time,'13,15,17,20');
if($list){
    foreach($list as $key=>$val){
        $list[$key]->msg = UserCashChange::TYPE_MAP[$val->type];
    }
}else{
    $list = array();
}
$total_cash = $cashChange->getTotalMerchant($user_id,'13,15,17,20');
$R->total_cash = $total_cash;
$R->list = $list;
exit(HttpResponse::exitJSON(true, "获取列表成功~！", "hint",$R));