<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/7/31
 * Time: 18:42
 */
use jiupian\api\model\Merchant;
use HoloPHP\tools\HttpResponse;
use HoloPHP\AutoLoader;
use config\ClentCmd;
$R = new \stdClass ();
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
$merchant = new Merchant(null,$user_id);
$R->register_time = $merchant->getOneFieldData("register_time");
$R->audit_time = $merchant->getOneFieldData("audit_time");
$R->merchant_refuse = $merchant->getOneFieldData("merchant_refuse");
if($merchant->getOneFieldData("merchant_status") == -1){
    $R->is_refuse = 1;
}else{
    $R->is_refuse = 0;
}
exit(HttpResponse::exitJSON(true, "获取拒绝原因成功", ClentCmd::HINT,$R));


