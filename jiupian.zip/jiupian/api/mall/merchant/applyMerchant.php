<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/7/31
 * Time: 9:29
 */
use jiupian\api\model\Merchant;
use jiupian\api\model\MerchantAlbum;
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use HoloPHP\AutoLoader;
use config\ClentCmd;
use jiupian\api\model\types\UserLevel;
$info =  new \stdClass ();
$info1 =  new \stdClass ();
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');

$merchant = new Merchant(null,$user_id);
if($merchant->isExist()){
    if($merchant->getOneFieldData("merchant_status") == 0){
        exit(HttpResponse::exitJSON(false, "正在审核中，请勿重复提交", ClentCmd::HINT));
    }
    if($merchant->getOneFieldData("merchant_status") == -1){//重新申请
        Verify::existsingAll("token","device","merchant_longitude","merchant_latitude","merchant_activite","merchant_contacts","merchant_tel","merchant_worktime","merchant_province","merchant_city","merchant_county","merchant_address","merchant_desp","merchant_license","merchant_logo","merchant_name","merchant_image");
        $info->merchant_contacts = $_REQUEST["merchant_contacts"];
        $info->merchant_tel = $_REQUEST["merchant_tel"];
        $info->merchant_province = $_REQUEST["merchant_province"];
        $info->merchant_city = $_REQUEST["merchant_city"];
        $info->merchant_county = $_REQUEST["merchant_county"];
        $info->merchant_address = $_REQUEST["merchant_address"];
        $info->merchant_desp = $_REQUEST["merchant_desp"];
        $info->merchant_name = $_REQUEST["merchant_name"];
        $info->merchant_worktime = $_REQUEST["merchant_worktime"];
        $info->merchant_activite = $_REQUEST["merchant_activite"];

        $info->merchant_longitude = trim($_REQUEST["merchant_longitude"]);
        $info->merchant_latitude = trim($_REQUEST["merchant_latitude"]);

        $info->merchant_status = 0;
        $info->consumer_id = $user_id;
        $info->register_time = time();


        $info1->merchant_license = $_REQUEST["merchant_license"];
        $info1->merchant_logo = $_REQUEST["merchant_logo"];
        $merchant->stopAutocommit();
        $info->check_status = 1;
        $res = $merchant->updateInfo($info);
        if(!$res){
            $merchant->rollback();
            exit(HttpResponse::exitJSON(false, "网络异常，请稍后再试!", ClentCmd::HINT));
        }
        $album = new MerchantAlbum();
        $del_license = $album->updateFields($merchant->getOneFieldData("merchant_id"),1);
        $del_logo = $album->updateFields($merchant->getOneFieldData("merchant_id"),2);
        if(!$del_logo || !$del_license){
            $merchant->rollback();
            exit(HttpResponse::exitJSON(false, "网络异常，请稍后再试1!", ClentCmd::HINT));
        }
        $res_license = $album->insertPhoto($merchant->getOneFieldData("merchant_id"),$info1->merchant_license,"营业执照",1);
        $res_logo = $album->insertPhoto($merchant->getOneFieldData("merchant_id"),$info1->merchant_logo,"商家logo",2);
        if(!$res_logo || !$res_license){
            $merchant->rollback();
            exit(HttpResponse::exitJSON(false, "网络异常，请稍后再试2!", ClentCmd::HINT));
        }
        $merchant->commit();
        exit(HttpResponse::exitJSON(true, "资料正在审核中!", ClentCmd::HINT));
    }
}else{
    //获取当前会员级别
    $rank = $userInfo->getOneFieldData("rank");
   /* if($rank < UserLevel::VIPUSER){
        exit(HttpResponse::exitJSON(false, "VIP会员级别以上才能申请素膳之家", ClentCmd::HINT));
    }*/
    Verify::existsingAll("token","device","merchant_longitude","merchant_latitude","merchant_activite","merchant_contacts","merchant_tel","merchant_worktime","merchant_province","merchant_city","merchant_county","merchant_address","merchant_desp","merchant_license","merchant_logo","merchant_name","merchant_image");
    $info->merchant_contacts = $_REQUEST["merchant_contacts"];
    $info->merchant_tel = $_REQUEST["merchant_tel"];
    $info->merchant_province = $_REQUEST["merchant_province"];
    $info->merchant_city = $_REQUEST["merchant_city"];
    $info->merchant_county = $_REQUEST["merchant_county"];
    $info->merchant_address = $_REQUEST["merchant_address"];
    $info->merchant_desp = $_REQUEST["merchant_desp"];
    $info->merchant_image = $_REQUEST["merchant_image"];
    $info->merchant_name = $_REQUEST["merchant_name"];
    $info->merchant_worktime = $_REQUEST["merchant_worktime"];
    $info->merchant_activite = $_REQUEST["merchant_activite"];
    $info->merchant_longitude = trim($_REQUEST["merchant_longitude"]);
    $info->merchant_latitude = trim($_REQUEST["merchant_latitude"]);
    $info->register_time = time();
    $info->consumer_id = $user_id;

    $info1->merchant_license = $_REQUEST["merchant_license"];
    $info1->merchant_logo = $_REQUEST["merchant_logo"];
    $merchant->stopAutocommit();
    $merchant_id = $merchant->addMer($info);
    if(!$merchant_id){
        $merchant->rollback();
        exit(HttpResponse::exitJSON(false, "网络异常，请稍后再试1!", ClentCmd::HINT));
    }
    $album = new MerchantAlbum();
    $res_license = $album->insertPhoto($merchant_id,$info1->merchant_license,"营业执照",1);
    $res_logo = $album->insertPhoto($merchant_id,$info1->merchant_logo,"商家logo",2);
    if(!$res_logo || !$res_license){
        $merchant->rollback();
        exit(HttpResponse::exitJSON(false, "网络异常，请稍后再试2!", ClentCmd::HINT));
    }
    $merchant->commit();
    exit(HttpResponse::exitJSON(true, "资料正在审核中!", ClentCmd::HINT));
}