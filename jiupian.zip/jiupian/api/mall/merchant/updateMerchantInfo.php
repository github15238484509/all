<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/7/31
 * Time: 18:11
 */
use jiupian\api\model\Merchant;
use jiupian\api\model\MerchantAlbum;
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use HoloPHP\AutoLoader;
use config\ClentCmd;
$info =  new \stdClass ();
$info1 =  new \stdClass ();
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
Verify::existsingAll("token","device","merchant_id","merchant_activite","merchant_contacts","merchant_tel","merchant_worktime","merchant_desp","merchant_logo","merchant_name","merchant_image");
$info->merchant_contacts = $_REQUEST["merchant_contacts"];
$info->merchant_tel = $_REQUEST["merchant_tel"];
$info->merchant_desp = $_REQUEST["merchant_desp"];
$info->merchant_name = $_REQUEST["merchant_name"];
$info->merchant_worktime = $_REQUEST["merchant_worktime"];
$info->merchant_activite = $_REQUEST["merchant_activite"];
$info->merchant_image = $_REQUEST["merchant_image"];
$merchant_id = $_REQUEST["merchant_id"];
$info1->merchant_logo = $_REQUEST["merchant_logo"];
$merchant = new Merchant($merchant_id);
if($merchant->isExist()){
    $merchant->stopAutocommit();
    $res = $merchant->updateInfo($info);
    if(!$res){
        $merchant->rollback();
        exit(HttpResponse::exitJSON(false, "网络异常，请稍后再试2!", ClentCmd::HINT));
    }
    $album = new MerchantAlbum();
    $res1 = $album->updateLogo($merchant_id,2,$info1->merchant_logo);
    if(!$res1){
        $merchant->rollback();
        exit(HttpResponse::exitJSON(false, "网络异常，请稍后再试1!", ClentCmd::HINT));
    }
    $merchant->commit();
    exit(HttpResponse::exitJSON(true, "更新成功!", ClentCmd::HINT));
}else{
    exit(HttpResponse::exitJSON(false, "商家不存在!", ClentCmd::HINT));
}