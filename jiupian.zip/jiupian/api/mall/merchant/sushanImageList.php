<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/9/26
 * Time: 13:54
 */
use HoloPHP\tools\HttpResponse;
$R = new \stdClass();
$arr = array(
    '0' => 'jiupian/sushanhome/sushan-01.jpg',
    '1' => 'jiupian/sushanhome/sushan-02.jpg',
    '2' => 'jiupian/sushanhome/sushan-03.jpg',
    '3' => 'jiupian/sushanhome/sushan-04.jpg'
);
$R->list = $arr;
exit(HttpResponse::exitJSON(true, "获取素膳之家图片", 'hint',$R));