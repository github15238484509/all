<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/7/31
 * Time: 18:56
 */
use jiupian\api\model\Merchant;
use jiupian\api\model\MerchantAlbum;
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use HoloPHP\AutoLoader;
use config\ClentCmd;
use jiupian\api\model\ModelConfigRegion;
use jiupian\api\model\ModelUserCashChange;
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
$R =  new \stdClass ();
$mer  = new Merchant(null,$user_id);
$R->merchant_id = $mer->getOneFieldData("merchant_id");
$R->merchant_name = $mer->getOneFieldData("merchant_name");
$configRegion = new ModelConfigRegion();
$merchant_province =  $mer->getOneFieldData("merchant_province");
$merchant_city =  $mer->getOneFieldData("merchant_city");
$merchant_county =  $mer->getOneFieldData("merchant_county");
$address = $mer->getOneFieldData("merchant_address");
$R->merchant_address = $configRegion->getName($merchant_province).$configRegion->getName($merchant_city).$configRegion->getName($merchant_county).$address;
$res = $userInfo->getUser($user_id);
$lists = $userInfo->getTixiUser($res);
if(empty($lists) || !$lists){
    $R->underling_count = 0;
}else{
    $R->underling_count = count($lists) - 1;
}
$cashChange = new ModelUserCashChange();
$total_cash = $cashChange->getTotalMerchant($user_id,'13,15,17,20');
$R->subsidies = $total_cash;
exit(HttpResponse::exitJSON(true, "获取素膳之家主页", ClentCmd::HINT,$R));