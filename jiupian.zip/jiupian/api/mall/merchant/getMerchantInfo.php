<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/7/31
 * Time: 15:17
 */
use jiupian\api\model\Merchant;
use HoloPHP\tools\HttpResponse;
use HoloPHP\AutoLoader;
use config\ClentCmd;
$R = new \stdClass ();
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
$merchant = new Merchant(null,$user_id);
$merInfo = $merchant->getMer($user_id);
exit(HttpResponse::exitJSON(true, "资料获取成功", ClentCmd::HINT,$merInfo));