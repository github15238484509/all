<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/8/1
 * Time: 11:36
 */
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use HoloPHP\AutoLoader;
use config\ClentCmd;
$R = new \stdClass();
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
Verify::existsingAll("page");
$page = $_REQUEST["page"];
$count  = 20;
$start = $page * $count;
$res1 = $userInfo->getUser($user_id);
$user_ids = $userInfo->getTixiUser($res1);
if($user_ids){
    $list = array_slice($user_ids,$start,$count);
    foreach($list as $key=>$val){
        if($val->user_id == $user_id){
            unset($list[$key]);
        }
    }
    $list = array_values($list);
}else{
    $list = array();
}
$R->list = $list;
exit(HttpResponse::exitJSON(true, "获取素膳之家列表", ClentCmd::HINT,$R));