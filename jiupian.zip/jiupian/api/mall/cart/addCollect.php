<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/8/10
 * Time: 13:35
 */
use jiupian\api\model\MallGoodCart;
use HoloPHP\AutoLoader;
use config\ClentCmd;
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use jiupian\api\model\GoodsCollect;
use jiupian\api\model\MallGood;
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
Verify::existsingAll("cart_index","token");
$cart_index = $_REQUEST ["cart_index"];
$device_index = $_REQUEST ["device"];
$mallgoods_cart = new MallGoodCart ( $user_id,$cart_index );
$goods_index = $mallgoods_cart->getFieldsValue("goods_index");
$collect = new GoodsCollect ( $user_id );
$collectLog = $collect->getByGoodsID_mall( $goods_index,0);
if($collectLog){
    $res1 = $mallgoods_cart->deleteGoodCart ( $cart_index );
    exit(HttpResponse::exitJSON(TRUE, "添加收藏成功", ClentCmd::HINT));
}
$mallgoods_cart->stopAutocommit();
$goods = new MallGood($goods_index);
$goods_icon = $goods->findGoodsIcon();
$res = $collect->addCollect($goods_index, $goods_icon, 0);
if(!$res){
    $mallgoods_cart->rollback();
    exit(HttpResponse::exitJSON(FALSE, "添加收藏失败", ClentCmd::HINT));
}else{
    $res1 = $mallgoods_cart->deleteGoodCart ( $cart_index );
    if(!$res1){
        $mallgoods_cart->rollback();
        exit(HttpResponse::exitJSON(FALSE, "添加收藏失败", ClentCmd::HINT));
    }else{
        $mallgoods_cart->commit();
        exit(HttpResponse::exitJSON(TRUE, "添加收藏成功", ClentCmd::HINT));
    }
}