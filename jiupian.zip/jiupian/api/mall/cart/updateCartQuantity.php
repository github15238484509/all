<?php
use jiupian\api\model\MallGoodCart;
use HoloPHP\AutoLoader;
use config\ClentCmd;
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
Verify::existsingAll("token", "device","cart_index","count");
$count=intval($_REQUEST ["count"]);
if( $count<0 ){
    exit(HttpResponse::exitJSON(FALSE, "更新商品数量失败!", ClentCmd::HINT));
}
$cart_id=$_REQUEST ["cart_index"];
// 根据商品id取得商品详情
$mallgoods_cart = new MallGoodCart ($user_id);
$res = $mallgoods_cart->updateGoodCartCount ( $count, $cart_id ,$device_index);
if ($res) {
    exit(HttpResponse::exitJSON(TRUE, "更新商品数量成功!", ClentCmd::HINT));
} else {
    exit(HttpResponse::exitJSON(FALSE, "更新商品数量失败!", ClentCmd::HINT));
}
?>