<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/7/2
 * Time: 19:21
 */
use jiupian\api\model\ModelGoodsSku;
use jiupian\api\model\ModelUserSupplier;
use jiupian\api\model\MallGoodCart;
use jiupian\api\model\MallGood;
use HoloPHP\AutoLoader;
use config\ClentCmd;
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use jiupian\api\model\ModelCurrencies;
use jiupian\api\model\ModelPriceLevel;
use jiupian\api\model\UserConsumer;
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
Verify::existsingAll("token", "device","cart_index");
$cart_index = $_REQUEST["cart_index"];
$R = new \stdClass();
// 根据商品id取得商品详情
$mallgoods_cart = new MallGoodCart ($user_id);
$list = $mallgoods_cart->findGoodCartList_v4($cart_index);
$supplier_list = array();
if (!$list) {
    $list = array();
    exit(HttpResponse::exitJSON(TRUE, "购物车列表!", ClentCmd::HINT,$list));
} else {
    $priceLevel = new ModelPriceLevel();
    foreach ($list as $key => $val) {
        $mallgood = new MallGood ($val->goods_index);
        $mallgood_info = $mallgood->getGoodsInfo();
        $val->goods_name = $mallgood_info->goods_name;
        $val->supplier_id = $mallgood_info->goods_supplier;
        $goods_sku = new ModelGoodsSku($val->sku_index);
        $goods_sku_info = $goods_sku->getGoodsSkuData($val->sku_index);
        $val->goods_price = $goods_sku_info->sku_market_price;
        $val->sku_inventory = $goods_sku_info->sku_inventory;//可订商品数量
        $val->goods_cost = $goods_sku_info->sku_cost_price;
        $val->goods_retail = $goods_sku_info->sku_retail_price;
        $val->goods_norms = $goods_sku_info->sku_name;
        $val->goods_bonus = $mallgood->getCalculateBonus($mallgood->getFieldsValue("online_area"),$goods_sku_info->sku_cost_price);
        $val->goods_icon = $goods_sku_info->sku_pic?:$mallgood_info->goods_icon;
        // 如果商品在线获取商品sku相对应的商品数量
        if ($goods_sku_info->sku_inventory == 0) {
            $val->has_inventory = 0; // 0已售完
        } else {
            $val->has_inventory = 1;
        }
        if($mallgood->getFieldsValue('online_area') == 1){
            $val->goods_cost = $priceLevel->getSkuGoods($userInfo->getOneFieldData('rank'),$val->goods_index,$val->sku_index)->level_goods_cost;
        }
        // 判断商品在线情况
        $val->goods_status = 1;// 1已下架
        if ($mallgood_info->goods_status != 2) {
            $val->goods_status = 3;//已下架
        } else {
            $val->goods_status = $mallgood_info->goods_status;
        }
        //判断商品的归属(旗舰店商品)
        $supplier = new ModelUserSupplier($val->supplier_id);
        $val->supplier_name = $supplier->getName();
        if (!isset($supplier_list[$val->supplier_id])) {
            $arr_sup = array();
        } else {
            $arr_sup = $supplier_list[$val->supplier_id];
        }
        array_push($arr_sup, $val);
        $supplier_list[$val->supplier_id] = $arr_sup;
    }
    $list1 = array();
    foreach ($supplier_list as $k => $v) {
        array_push($list1, $v);
    }
    $R = new \stdClass();
    $cartList  = array();
    foreach($list1 as $key1=>$val1){
        @$cartList[$key1]->supplier_id  = $val1[0]->supplier_id;
        $cartList[$key1]->supplier_name  = $val1[0]->supplier_name;
        $cartList[$key1]->list  = $val1;
    }
    $R->cartList = $cartList;
    exit(HttpResponse::exitJSON(TRUE, "购物车列表!", ClentCmd::HINT,$R));
}
?>