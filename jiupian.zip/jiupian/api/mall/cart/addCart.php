<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/6/21
 * Time: 10:35
 */
use jiupian\api\model\MallGoodCart;
use jiupian\api\model\MallGood;
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use HoloPHP\AutoLoader;
use jiupian\api\model\ModelGoodsSku;
use config\ClentCmd;
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
Verify::existsingAll("goods_index", "token", "device", "sku_index","goods_count");
$goods_index = $_REQUEST["goods_index"];
$goods_count = intval($_REQUEST["goods_count"]);
$sku_index = $_REQUEST["sku_index"];
$goodsSku = new ModelGoodsSku($sku_index);
$skuInfo =  $goodsSku->getGoodsSkuData($sku_index);
$goods_sku = str_replace(";", ",", $skuInfo->sku_info);
$goods_norms = $skuInfo->sku_name;
$device_index = $_REQUEST ["device"];
//判断商品数量
if ($goods_count < 0) {
    exit(HttpResponse::exitJSON(FALSE, "数量不能为空!", ClentCmd::HINT));
}
//判断商品是否存在
$mallgoods_cart = new MallGoodCart($user_id);
$goods = $mallgoods_cart->getExistGoods($goods_sku, $goods_index, $user_id, 0);
if ($goods) {
    $res = $mallgoods_cart->updateGoodCartCount2($goods_count, $goods->cart_index);
} else {
    // 根据商品id取得商品详情
    $mallgoods = new MallGood($goods_index);
    $goods_info = $mallgoods->getGoodsInfo();
    $res = $mallgoods_cart->addGoodCart($goods_index, $goods_sku, $goods_norms, $goods_count, $device_index, $goods_info->goods_supplier,$goods_info->good_weight,$sku_index);
}
if (!$res) {
    exit(HttpResponse::exitJSON(FALSE, "添加购物车失败", ClentCmd::HINT));
}else{
    exit(HttpResponse::exitJSON(TRUE, "添加购物车成功", ClentCmd::HINT));
}