<?php
use jiupian\api\model\MallGoodCart;
use HoloPHP\AutoLoader;
use config\ClentCmd;
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
Verify::existsingAll("cart_index","token");
$cart_index = $_REQUEST ["cart_index"];
$device_index = $_REQUEST ["device"];
$mallgoods_cart = new MallGoodCart ( $user_id );
$res = $mallgoods_cart->deleteGoodCart ( $cart_index );
if ($res) {
    exit(HttpResponse::exitJSON(TRUE, "删除购物车成功!", ClentCmd::HINT));
} else {
    exit(HttpResponse::exitJSON(false, "删除购物车失败!", ClentCmd::HINT));
}
?>