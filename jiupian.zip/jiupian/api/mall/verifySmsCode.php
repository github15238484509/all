<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/5/10
 * Time: 13:40
 */
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use HoloPHP\tools\SMS;
use HoloPHP\server\Server;
require_once 'verify/verify_token.php';
if (! Verify::existsingAll("phone", "phone_code","token")) {
    exit(HttpResponse::exitJSON(false, "缺少请求参数~！", "hint"));
}
if(Server::environment("prod")){
    $code = SMS::verifyCode($_REQUEST["phone"], $_REQUEST["phone_code"]);
}else{
    $code = 1;
}
if ($code == - 5) {
    exit(HttpResponse::exitJSON(FALSE, "验证码错误", "hint"));
} elseif ($code == 0) {
    exit(HttpResponse::exitJSON(FALSE, "该手机号未曾获取验证码，请重新获取", "hint"));
} elseif ($code != 1) {
    exit(HttpResponse::exitJSON(FALSE, "服务器异常~！", "hint"));
}elseif($code == 1){
    exit(HttpResponse::exitJSON(TRUE, "验证成功~！", "hint"));
}