<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/4/28
 * Time: 20:13
 */
use HoloPHP\tools\Verify;
use jiupian\api\model\ModelTransferOffline;
use HoloPHP\tools\HttpResponse;
use config\ClentCmd;
use jiupian\api\model\types\TransferOffline;
use HoloPHP\AutoLoader;
require_once AutoLoader::autoPath('/api/account/verify/verify_token.php');
Verify::existsingAll("trans_id","token");
$deal_id = $_REQUEST["trans_id"];
$transfer = new ModelTransferOffline($deal_id);
$info = $transfer->getInfo();
if($user_id != $info->user_id){
    exit(HttpResponse::exitJSON(FALSE, "获取详情失败", ClentCmd::HINT));
}
if(!$info->reason){
    $info->reason = "";
}
if(!$info->sub_time){
    $info->sub_time = time();
}
unset($info->user_id);
unset($info->trans_id);
exit(HttpResponse::exitJSON(TRUE, "获取详情成功", ClentCmd::HINT,$info));


