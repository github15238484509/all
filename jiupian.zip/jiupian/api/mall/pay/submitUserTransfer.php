<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/4/24
 * Time: 15:36
 */
use HoloPHP\tools\Verify;
use jiupian\api\model\ModelTransferOffline;
use HoloPHP\tools\HttpResponse;
use config\ClentCmd;
use jiupian\api\model\types\TransferOffline;
use HoloPHP\AutoLoader;
require_once AutoLoader::autoPath('/api/account/verify/verify_token.php');
Verify::existsingAll("amount", "remark" ,"card_name","card_bank","card_vouchar","trans_type");
$phone = $userInfo->getUserPhone();
$amount = floor($_REQUEST["amount"] * 100) ;
$remark = $_REQUEST["remark"];
$card_name = $_REQUEST["card_name"];
$card_number = $_REQUEST["card_number"]?$_REQUEST["card_number"]:'';
$card_bank = $_REQUEST["card_bank"];
$card_vouchar = $_REQUEST["card_vouchar"];
$trans_type = $_REQUEST["trans_type"];
if($trans_type == 0) {
    if(empty($amount) || empty($card_name) || empty($card_number)){//银联
        exit(HttpResponse::exitJSON(FALSE, "参数不能为空", ClentCmd::HINT));
    }
}else{//支付宝
    if(empty($amount) || empty($card_name) || empty($card_number)){
        exit(HttpResponse::exitJSON(FALSE, "参数不能为空", ClentCmd::HINT));
    }
}
$transModel = new ModelTransferOffline();
$res = $transModel->addOneDate(
    $user_id,
    $phone,
    $amount,
    $remark,
    $card_name,
    $card_number,
    $card_bank,
    $card_vouchar,
    TransferOffline::STATUS_ING,
    $trans_type
);
if(!$res){
    exit(HttpResponse::exitJSON(FALSE, "提交失败", ClentCmd::HINT));
}
exit(HttpResponse::exitJSON(TRUE, "提交成功", ClentCmd::HINT));


