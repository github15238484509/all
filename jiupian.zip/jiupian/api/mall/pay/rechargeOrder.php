<?php
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use config\ClentCmd;
use HoloPHP\tools\UUID;
use jiupian\api\model\MallGood;
use jiupian\api\model\MallGoodOrderGoods;
use jiupian\api\model\ReCharg;
use jiupian\api\model\types\UserLevel;
use jiupian\api\model\UserConsumer;
use tables\mall\MallGoodOrder;
use HoloPHP\AutoLoader;
use jiupian\api\model\types\UserRecharge;
use jiupian\api\model\alipay\jiupianPay;
use HoloPHP\wechat\lib\WxPayUnifiedOrder;
use HoloPHP\server\Server;
use HoloPHP\wechat\lib\WxPayApi;
use HoloPHP\wechat\lib\JsApiPay;
use HoloPHP\server\Log;
use jiupian\api\model\MallGoodOrder as MallOrder;
require_once AutoLoader::autoPath('/api/account/verify/verify_token.php');
Verify::existsingAll( "token", "order_index", "order_money","type","pay_type");
if (! $userInfo->isExist()) {
    HttpResponse::exitJSON(false, "用户还未注册~！", ClentCmd::TO_REGISTER);
}
$order_ids = $_REQUEST["order_index"];
$money = $_REQUEST["order_money"];
$pay_type = $_REQUEST["pay_type"];
$type = $_REQUEST["type"];
if($type == UserRecharge::TYPE_RECHARGE_CENTER){//充值中心
    $recharge = new ReCharg();
    if($money * 100 < 20000){
        exit(HttpResponse::exitJSON(false, "充值金额不能低于200~！", ClentCmd::HINT));
    }
    if($pay_type == UserRecharge::PAY_TYPE_ALIPAY){
        $body = "支付宝支付";
        $detail = "支付宝余额充值支付" . $money . "元";
        $pay_id = UUID::order_id();
        $order_index = $recharge->addReCharg($money*100, $user_id, $pay_id,$pay_type , $detail, $type,0);
        if (! $order_index) {
            exit(HttpResponse::exitJSON(false, "插入数据失败", ClentCmd::HINT));
        }else{
            $pay = new jiupianPay();
            if(server::environment('local','test')){
                $total_amount = 1;
            }else{
                $total_amount = $money;
            }
            $orderString = array(
                "out_trade_no" => $pay_id,
                "subject" => '纠偏健康管理',
                "body" => $body,
                "total_amount" => $total_amount
            );
            $bizContent = json_encode($orderString);
            $string = $pay->getorderString($bizContent);
            echo $string;
            exit();
        }
    }elseif($pay_type == UserRecharge::PAY_TYPE_WECHATH5){
        if(getenv('HTTP_CLIENT_IP')) {
            $cip = getenv('HTTP_CLIENT_IP');
        } elseif(getenv('HTTP_X_FORWARDED_FOR')) {
            $cip = getenv('HTTP_X_FORWARDED_FOR');
        } elseif(getenv('REMOTE_ADDR')) {
            $cip = getenv('REMOTE_ADDR');
        } else {
            $cip = $HTTP_SERVER_VARS['REMOTE_ADDR'];
        }

        if($cip == 'unknown'){
            exit(HttpResponse::exitJSON(false, "用户还未注册~！", ClentCmd::TO_REGISTER));
        }
        $SetSpbill_create_ip = trim($cip);
        $body = "纠偏素膳支付";
        $detail = "微信H5余额充值支付" . $money . "元";
        $recharge = new ReCharg();
        $pay_id = UUID::order_id();
        $order_index = $recharge->addReCharg($money*100, $user_id, $pay_id, $pay_type, $detail, $type,0);
        if (! $order_index) {
            HttpResponse::exitJSON(false, "插入数据失败", ClentCmd::HINT);
        }
        $attach = $order_index;
        // ②、统一下单
        $input = new WxPayUnifiedOrder();
        $tools = new JsApiPay();
        $input->SetBody($body);
        $input->SetDetail($detail);
        $input->SetAttach($attach);
        $input->SetOut_trade_no($pay_id);
        if (Server::environment('local', 'test')) {
            $input->SetTotal_fee(1);
        } else {
            $money = $money*100;
            $input->SetTotal_fee($money);
        }
        $input->SetNotify_url(PROJECT_URL . "H5notify.php");
        $input->SetTime_start(date("YmdHis"));
        $input->SetTime_expire(date("YmdHis", time() + 600));
        $input->SetGoods_tag("H5SubmitPayOrder");
        $input->SetTrade_type("MWEB");
        $input->SetSpbill_create_ip($SetSpbill_create_ip);
        $order = WxPayApi::unifiedOrder($input);
        if($order["result_code"] == "SUCCESS" && $order["return_code"] == "SUCCESS"){
            try {
               // $jsConfigData = json_decode($tools->GetJsApiParameters($order),true);
                exit(HttpResponse::exitJSON(true, "下单成功~！", ClentCmd::HINT, $order));
            } catch (\Exception $e) {
                //$resData->msg = $e->getMessage();
                exit(HttpResponse::exitJSON(false, "下单失败1~！", ClentCmd::HINT, $order));
            }
        }else{
            exit(HttpResponse::exitJSON(false, "下单失败1~！", ClentCmd::HINT, $order));
        }
    }elseif($pay_type == UserRecharge::PAY_TYPE_WECHAT){
        $pay_open_id = $_REQUEST["openid"];
        if($pay_open_id){
            $userInfo->updateFields("wechat_openid",$pay_open_id);
        }
        $body = "纠偏健康管理支付";
        $detail = "微信公众号余额充值支付" . $money . "元";
        $recharge = new ReCharg();
        $pay_id = UUID::order_id();
        $order_index = $recharge->addReCharg($money*100, $user_id, $pay_id, $pay_type, $detail, $type,0);
        if (! $order_index) {
            HttpResponse::exitJSON(false, "插入数据失败", ClentCmd::HINT);
        }
        $attach = $order_index;
        // ②、统一下单
        $input = new WxPayUnifiedOrder();
        $tools = new JsApiPay();
        $input->SetBody($body);
        $input->SetDetail($detail);
        $input->SetAttach($attach);
        $input->SetOut_trade_no($pay_id);
        if (Server::environment('local', 'test')) {
            $input->SetTotal_fee(1);
        } else {
            $money = $money*100;
            $input->SetTotal_fee($money);
        }
        $input->SetNotify_url(PROJECT_URL . "H5notify.php");
        $input->SetTime_start(date("YmdHis"));
        $input->SetTime_expire(date("YmdHis", time() + 600));
        $input->SetGoods_tag("JsSubmitPayOrder");
        $input->SetTrade_type("JSAPI");
        $input->SetOpenid($pay_open_id);
        $order = WxPayApi::unifiedOrder($input);
        Log::put("下单",json_encode($order));
        if($order["result_code"] == "SUCCESS" && $order["return_code"] == "SUCCESS"){
            try {
                $jsConfigData = json_decode($tools->GetJsApiParameters($order),true);
                exit(HttpResponse::exitJSON(true, "下单成功~！", ClentCmd::HINT, $jsConfigData));
            } catch (\Exception $e) {
                $resData = new \stdClass();
                $resData->msg = $e->getMessage();
                exit(HttpResponse::exitJSON(false, "下单失败2~！", ClentCmd::HINT, $resData));
            }
        }else{
            exit(HttpResponse::exitJSON(false, "下单失败22~！", ClentCmd::HINT, $order));
        }

    }else{
        exit(HttpResponse::exitJSON(false, "支付方式选择错误~！", ClentCmd::HINT));
    }
}elseif($type == UserRecharge::TYPE_MALL_ORDER_PAY){//商城订单支付
    $mall_order = new MallOrder();
    $order_list = explode(",",$order_ids);
    $limit_res  = $mall_order->getLimitOrder($user_id,$order_list);
    if(!$limit_res){
        exit(HttpResponse::exitJSON(false, "限购了，明天再来吧~！", ClentCmd::HINT));
    }
    if($pay_type == UserRecharge::PAY_TYPE_ALIPAY){
        $order_price = 0;
        $order_list = explode(",",$order_ids);
        foreach($order_list as $key=>$val){
            $user_pay = new MallGoodOrder($val, null, null);
            $order_price = $order_price + $user_pay->getTotalPrice();
            if ($user_pay->getStatus() != 1) {
                exit(HttpResponse::exitJSON(false, "订单状态无效~！", ClentCmd::HINT, $resData));
            }
            ##首购区不能购买低等级产品
            $userInfo = new UserConsumer($user_pay->getFieldsValue("order_consumer"));
            //会员等级
            $rank = $userInfo->getOneFieldData("rank");
            //获取商品对应的会员礼包级别
            $mallOrderGoods = new MallGoodOrderGoods();
            $goods_list = $mallOrderGoods->findOrderGoodsByOrder($user_pay->getFieldsValue("order_index"));
            foreach ($goods_list as $key => $val) {
                $mallgoods = new MallGood($val->goods_index);
                $online_area = $mallgoods->getFieldsValue("online_area");
                if($online_area > 1){
                    switch($rank){
                        case UserLevel::VIPUSER:
                            if($online_area == UserLevel::VIPGOODS){
                                exit(HttpResponse::exitJSON(FALSE, "您已经购买过VIP会员礼包!", ClentCmd::HINT));
                            }
                            break;
                        case UserLevel::SUPREUSER:
                            if($online_area == UserLevel::SUPREGOODS){
                                exit(HttpResponse::exitJSON(FALSE, "您已经购买过至尊会员礼包!", ClentCmd::HINT));
                            }
                            if($online_area == UserLevel::VIPGOODS){
                                exit(HttpResponse::exitJSON(FALSE, "请您购买更高级别的礼包!", ClentCmd::HINT));
                            }
                            break;
                        case  UserLevel::PARTNERUSER:
                            if($online_area == UserLevel::PARTNERGOODS){
                                exit(HttpResponse::exitJSON(FALSE, "您已经购买过合伙人会员礼包!", ClentCmd::HINT));
                            }
                            if($online_area == UserLevel::VIPGOODS){
                                exit(HttpResponse::exitJSON(FALSE, "请您购买更高级别的礼包!", ClentCmd::HINT));
                            }
                            if($online_area == UserLevel::SUPREGOODS){
                                exit(HttpResponse::exitJSON(FALSE, "请您购买更高级别的礼包!", ClentCmd::HINT));
                            }
                            break;
                        case UserLevel::SUSHANPARTNER:
                            exit(HttpResponse::exitJSON(FALSE, "您已经不能购买礼包!", ClentCmd::HINT));
                            break;
                        case UserLevel::OPERATIONPARTNER:
                            exit(HttpResponse::exitJSON(FALSE, "您已经不能购买礼包!", ClentCmd::HINT));
                            break;
                        default:
                            break;
                    }
                }
            }

        }
        if ($order_price != $money*100) {
            exit(HttpResponse::exitJSON(false, "订单金额不符~！", ClentCmd::HINT, $resData));
        }
        $body = "支付宝订单支付";
        $detail = "支付宝订单支付" . $money . "元";
        $recharge = new ReCharg();
        $pay_id = UUID::order_id();
        $order_index = $recharge->addReCharg($money*100, $user_id, $pay_id,$pay_type , $detail, $type,$order_ids);
        if (! $order_index) {
            exit(HttpResponse::exitJSON(false, "插入数据失败", ClentCmd::HINT));
        }else{
            $pay = new jiupianPay();
            if(server::environment('local','test')){
                $total_amount = 0.01;
            }else{
                $total_amount = $money;
            }
            $orderString = array(
                "out_trade_no" => $pay_id,
                "subject" => '纠偏健康管理',
                "body" => $body,
                "total_amount" => $total_amount
            );
            $bizContent = json_encode($orderString);
            $string = $pay->getorderString($bizContent);
            echo $string;
            exit();
        }
    }elseif($pay_type == UserRecharge::PAY_TYPE_WECHATH5){
        $order_price = 0;
        $order_list = explode(",",$order_ids);
        foreach($order_list as $key=>$val){
            $user_pay = new MallGoodOrder($val, null, null);
            $order_price = $order_price + $user_pay->getTotalPrice();
            if ($user_pay->getStatus() != 1) {
                exit(HttpResponse::exitJSON(false, "订单状态无效~！", ClentCmd::HINT));
            }
            ##首购区不能购买低等级产品
            $userInfo = new UserConsumer($user_pay->getFieldsValue("order_consumer"));
            //会员等级
            $rank = $userInfo->getOneFieldData("rank");
            //获取商品对应的会员礼包级别
            $mallOrderGoods = new MallGoodOrderGoods();
            $goods_list = $mallOrderGoods->findOrderGoodsByOrder($user_pay->getFieldsValue("order_index"));
            foreach ($goods_list as $key => $val) {
                $mallgoods = new MallGood($val->goods_index);
                $online_area = $mallgoods->getFieldsValue("online_area");
                if($online_area > 1){
                    switch($rank){
                        case UserLevel::VIPUSER:
                            if($online_area == UserLevel::VIPGOODS){
                                exit(HttpResponse::exitJSON(FALSE, "您已经购买过VIP会员礼包!", ClentCmd::HINT));
                            }
                            break;
                        case UserLevel::SUPREUSER:
                            if($online_area == UserLevel::SUPREGOODS){
                                exit(HttpResponse::exitJSON(FALSE, "您已经购买过至尊会员礼包!", ClentCmd::HINT));
                            }
                            if($online_area == UserLevel::VIPGOODS){
                                exit(HttpResponse::exitJSON(FALSE, "请您购买更高级别的礼包!", ClentCmd::HINT));
                            }
                            break;
                        case  UserLevel::PARTNERUSER:
                            if($online_area == UserLevel::PARTNERGOODS){
                                exit(HttpResponse::exitJSON(FALSE, "您已经购买过合伙人会员礼包!", ClentCmd::HINT));
                            }
                            if($online_area == UserLevel::VIPGOODS){
                                exit(HttpResponse::exitJSON(FALSE, "请您购买更高级别的礼包!", ClentCmd::HINT));
                            }
                            if($online_area == UserLevel::SUPREGOODS){
                                exit(HttpResponse::exitJSON(FALSE, "请您购买更高级别的礼包!", ClentCmd::HINT));
                            }
                            break;
                        case UserLevel::SUSHANPARTNER:
                            exit(HttpResponse::exitJSON(FALSE, "您已经不能购买礼包!", ClentCmd::HINT));
                            break;
                        case UserLevel::OPERATIONPARTNER:
                            exit(HttpResponse::exitJSON(FALSE, "您已经不能购买礼包!", ClentCmd::HINT));
                            break;
                        default:
                            break;
                    }
                }
            }
        }
        if ($order_price != floor($money*100)) {
            exit(HttpResponse::exitJSON(false, "订单金额不符11~！", ClentCmd::HINT));
        }
        if(getenv('HTTP_CLIENT_IP')) {
            $cip = getenv('HTTP_CLIENT_IP');
        } elseif(getenv('HTTP_X_FORWARDED_FOR')) {
            $cip = getenv('HTTP_X_FORWARDED_FOR');
        } elseif(getenv('REMOTE_ADDR')) {
            $cip = getenv('REMOTE_ADDR');
        } else {
            $cip = $HTTP_SERVER_VARS['REMOTE_ADDR'];
        }

        if($cip == 'unknown'){
            exit(HttpResponse::exitJSON(false, "用户还未注册~！", ClentCmd::TO_REGISTER));
        }
        $SetSpbill_create_ip = trim($cip);
        $body = "纠偏健康管理支付";
        $detail = "微信H5订单支付" . $money . "元";
        $recharge = new ReCharg();
        $pay_id = UUID::order_id();
        $order_index = $recharge->addReCharg($money*100, $user_id, $pay_id, $pay_type, $detail, $type,$order_ids);
        if (! $order_index) {
            HttpResponse::exitJSON(false, "插入数据失败", ClentCmd::HINT);
        }
        $attach = $order_index;
        // ②、统一下单
        $input = new WxPayUnifiedOrder();
        $tools = new JsApiPay();
        $input->SetBody($body);
        $input->SetDetail($detail);
        $input->SetAttach($attach);
        $input->SetOut_trade_no($pay_id);
        if (Server::environment('local', 'test')) {
            $input->SetTotal_fee(1);
        } else {
            $money = $money *100;
            $input->SetTotal_fee($money);
        }
        $input->SetNotify_url(PROJECT_URL . "H5notify.php");
        $input->SetTime_start(date("YmdHis"));
        $input->SetTime_expire(date("YmdHis", time() + 600));
        $input->SetGoods_tag("H5SubmitPayOrder");
        $input->SetTrade_type("MWEB");
        $input->SetSpbill_create_ip($SetSpbill_create_ip);
        $order = WxPayApi::unifiedOrder($input);
        if($order["result_code"] == "SUCCESS" && $order["return_code"] == "SUCCESS"){
            try {
                //$jsConfigData = json_decode($tools->GetJsApiParameters($order),true);
                exit(HttpResponse::exitJSON(true, "下单成功~！", ClentCmd::HINT, $order));
            } catch (\Exception $e) {
               // $resData->msg = $e->getMessage();
                exit(HttpResponse::exitJSON(false, "下单失败~！", ClentCmd::HINT, $order));
            }
        }else{
            exit(HttpResponse::exitJSON(false, "下单失败~！", ClentCmd::HINT, $order));
        }
    }elseif($pay_type == UserRecharge::PAY_TYPE_WECHAT){
        $pay_open_id = $_REQUEST["openid"];
        if($pay_open_id){
            $userInfo->updateFields("wechat_openid",$pay_open_id);
        }
        $order_price = 0;
        $order_list = explode(",",$order_ids);
        foreach($order_list as $key=>$val){
            $user_pay = new MallGoodOrder($val, null, null);
            $order_price = $order_price + $user_pay->getTotalPrice();
            if ($user_pay->getStatus() != 1) {
                exit(HttpResponse::exitJSON(false, "订单状态无效~！", ClentCmd::HINT));
            }
            ##首购区不能购买低等级产品
            $userInfo = new UserConsumer($user_pay->getFieldsValue("order_consumer"));
            //会员等级
            $rank = $userInfo->getOneFieldData("rank");
            //获取商品对应的会员礼包级别
            $mallOrderGoods = new MallGoodOrderGoods();
            $goods_list = $mallOrderGoods->findOrderGoodsByOrder($user_pay->getFieldsValue("order_index"));
            foreach ($goods_list as $key => $val) {
                $mallgoods = new MallGood($val->goods_index);
                $online_area = $mallgoods->getFieldsValue("online_area");
                if($online_area > 1){
                    switch($rank){
                        case UserLevel::VIPUSER:
                            if($online_area == UserLevel::VIPGOODS){
                                exit(HttpResponse::exitJSON(FALSE, "您已经购买过VIP会员礼包!", ClentCmd::HINT));
                            }
                            break;
                        case UserLevel::SUPREUSER:
                            if($online_area == UserLevel::SUPREGOODS){
                                exit(HttpResponse::exitJSON(FALSE, "您已经购买过至尊会员礼包!", ClentCmd::HINT));
                            }
                            if($online_area == UserLevel::VIPGOODS){
                                exit(HttpResponse::exitJSON(FALSE, "请您购买更高级别的礼包!", ClentCmd::HINT));
                            }
                            break;
                        case  UserLevel::PARTNERUSER:
                            if($online_area == UserLevel::PARTNERGOODS){
                                exit(HttpResponse::exitJSON(FALSE, "您已经购买过合伙人会员礼包!", ClentCmd::HINT));
                            }
                            if($online_area == UserLevel::VIPGOODS){
                                exit(HttpResponse::exitJSON(FALSE, "请您购买更高级别的礼包!", ClentCmd::HINT));
                            }
                            if($online_area == UserLevel::SUPREGOODS){
                                exit(HttpResponse::exitJSON(FALSE, "请您购买更高级别的礼包!", ClentCmd::HINT));
                            }
                            break;
                        case UserLevel::SUSHANPARTNER:
                            exit(HttpResponse::exitJSON(FALSE, "您已经不能购买礼包!", ClentCmd::HINT));
                            break;
                        case UserLevel::OPERATIONPARTNER:
                            exit(HttpResponse::exitJSON(FALSE, "您已经不能购买礼包!", ClentCmd::HINT));
                            break;
                        default:
                            break;
                    }
                }
            }
        }
       /* if (intval($order_price) != intval($money*100)) {
            exit(HttpResponse::exitJSON(false, $order_price."订单金额不符22~！".$money, ClentCmd::HINT));
        }*/
        $body = "纠偏健康管理支付";
        $detail = "微信公众号订单支付" . $money . "元";
        $recharge = new ReCharg();
        $pay_id = UUID::order_id();
        $order_index = $recharge->addReCharg($order_price, $user_id, $pay_id, $pay_type, $detail, $type,$order_ids);
        if (! $order_index) {
            HttpResponse::exitJSON(false, "插入数据失败", ClentCmd::HINT);
        }
        $attach = $order_index;
        // ②、统一下单
        $input = new WxPayUnifiedOrder();
        $tools = new JsApiPay();
        $input->SetBody($body);
        $input->SetDetail($detail);
        $input->SetAttach($attach);
        $input->SetOut_trade_no($pay_id);
        if (Server::environment('local', 'test')) {
            $input->SetTotal_fee(1);
        } else {
            $money = $order_price;
            $input->SetTotal_fee($money);
        }
        $input->SetNotify_url(PROJECT_URL . "H5notify.php");
        $input->SetTime_start(date("YmdHis"));
        $input->SetTime_expire(date("YmdHis", time() + 600));
        $input->SetGoods_tag("JsSubmitPayOrder");
        $input->SetTrade_type("JSAPI");
        $input->SetOpenid($pay_open_id);
        $order = WxPayApi::unifiedOrder($input);
        Log::put("支付",json_encode($order));
        if($order["result_code"] == "SUCCESS" && $order["return_code"] == "SUCCESS"){
            try {
                $jsConfigData = json_decode($tools->GetJsApiParameters($order),true);
                exit(HttpResponse::exitJSON(true, "下单成功~！", ClentCmd::HINT, $jsConfigData));
            } catch (\Exception $e) {
                $resData = new \stdClass();
                 $resData->msg = $e->getMessage();
                exit(HttpResponse::exitJSON(false, "下单失败1~！", ClentCmd::HINT, $resData));
            }
        }else{
            exit(HttpResponse::exitJSON(false, "微信下单失败~！", ClentCmd::HINT, $order));
        }
    }else{
        exit(HttpResponse::exitJSON(false, "支付方式错误~！", ClentCmd::HINT));
    }
}
