<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/5/15
 * Time: 18:01
 */
use tables\mall\ModelNews;
use HoloPHP\tools\HttpResponse;
$model = new ModelNews();
$news = $model->getGonggaoNews();
if(!$news){
    $news = array();
}
foreach($news as $key=>$val){
    $news[$key]->main = '系统公告';
}
exit(HttpResponse::exitJSON(true, "帮助列表成功~！", "hint",$news));