<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/6/8
 * Time: 9:20
 */
use tables\model\app\bank\ModelBankList;
use HoloPHP\tools\HttpResponse;
use config\ClentCmd;
$bankList = new ModelBankList();
$list = $bankList->getAllUseList();
if(!$list){
    $list = array();
    exit(HttpResponse::exitJSON(TRUE, "银行卡信息~！", ClentCmd::HINT,$list));
}else{
    $tmp_list = [];
    foreach($list as $key=>$val){
        $tmp_list[$key]["value"] = $val->bank_code;
        $tmp_list[$key]["text"] = $val->bank_name;
    }
    exit(HttpResponse::exitJSON(TRUE, "银行卡信息~！", ClentCmd::HINT,$tmp_list));
}