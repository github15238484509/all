<?php
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use HoloPHP\AutoLoader;
use config\ClentCmd;
use jiupian\api\model\ModelSumOperation;
use jiupian\api\model\UserConsumer;
$R = new \stdClass ();
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
$year = date("Y");
$month = date("m");
$info = new \stdClass();
$info->sum_year = $year;
$info->sum_month = $month;
$info->user_id = $user_id;
$oper = new ModelSumOperation();
$sum_info = $oper->readLineByAnd($info,null,'yeji');

if(!$sum_info){
    $sum_info = new \stdClass();
    $sum_info->user_id  = $user_id;
    $sum_info->yeji = 0;
}else{
    $sum_info->user_id  = $user_id;
}
$sum_userids = $oper->myoids($user_id);
if(!$sum_userids){
    $sum_list = [];
}else{
    $sum_userids = implode(",",$sum_userids);
    $sum_list = $oper->selectArrayByWhere( " user_id in ( $sum_userids ) and sum_year = $year and  sum_month = $month ","sum_id asc ","sum_id,user_id,yeji");
    if($sum_list){
        foreach($sum_list as $k=>$v){
            $users = new UserConsumer($v->user_id);
            $sum_list[$k]->photo = $users->getOneFieldData('photo');
            $sum_list[$k]->name = $users->getOneFieldData('name');
            $sum_list[$k]->operation_name  =  $sum_list[$k]->name."的运营中心业绩";
        }
    }else{
        $sum_list = [];
    }
}
$R->sum_info = $sum_info;
$R->sum_list = $sum_list;
exit(HttpResponse::exitJSON(TRUE, "运营中心列表获取成功!", ClentCmd::HINT,$R));

