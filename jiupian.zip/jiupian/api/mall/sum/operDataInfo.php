<?php
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use HoloPHP\AutoLoader;
use config\ClentCmd;
use jiupian\api\model\ModelSumOperation;
use jiupian\api\model\UserConsumer;
use jiupian\api\model\ModelSumData;
use jiupian\api\model\ModelGoodsZone;
//require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
$R = new \stdClass ();
Verify::existsingAll('type','user_id');
$year = date("Y");
$month = date("m");
$type = $_REQUEST['type'];
$userid = $_REQUEST['user_id'];
$zone = new ModelGoodsZone();
$zone_list2 = $zone->selectArrayByWhere("zone_type = 1 and is_del = 0 ");
if($type == 1){
    $sumdata = new ModelSumData();
    $info = new \stdClass();
    $info->sum_year = $year;
    $info->sum_month = $month;
    $info->user_id = $userid;
    $oper = new ModelSumOperation();
    $sum_info = $oper->readLineByAnd($info,null,'yeji,sum_id');
    if($sum_info){
        $list = $sumdata->selectArrayByWhere('sum_id = '.$sum_info->sum_id,' goods_zone asc','goods_zone,sum_price');
        if(!$list){
            /* $zone_list[0]['zone_name'] = '商城分区';
             $zone_list[0]['goods_zone'] = 1;
             $zone_list[0]['sum_price'] = 0;*/

            $zone_list[1]['zone_name'] = 'Vip礼包区';
            $zone_list[1]['goods_zone'] = 2;
            $zone_list[1]['sum_price'] = 0;

            $zone_list[2]['zone_name'] = '至尊礼包区';
            $zone_list[2]['goods_zone'] = 3;
            $zone_list[2]['sum_price'] = 0;


            $zone_list[3]['zone_name'] = '10800元礼包分区';
            $zone_list[3]['goods_zone'] = 4;
            $zone_list[3]['sum_price'] = 0;


            $zone_list[4]['zone_name'] = '愫膳之家礼包区';
            $zone_list[4]['goods_zone'] = 5;
            $zone_list[4]['sum_price'] = 0;

            if($zone_list2){
                foreach($zone_list2 as $k=>$v){
                    $zonelist2[$k]['zone_name'] = $v->zone_name;
                    $zonelist2[$k]['goods_zone'] = $v->id;
                    $zonelist2[$k]['sum_price'] = 0;
                }
            }else{
                $zonelist2 = [];
            }
        }else{
            //$zone_list[0]['zone_name'] = '商城分区';
            $zone_list[1]['zone_name'] = 'Vip礼包区';
            $zone_list[2]['zone_name'] = '至尊礼包区';
            $zone_list[3]['zone_name'] = '10800元礼包分区';
            $zone_list[4]['zone_name'] = '愫膳之家礼包区';
            foreach($zone_list as $k2=>$v2){
                foreach($list as $k=>$v){

                    if($k2 + 1 == $v->goods_zone){
                        $zone_list[$k2]['sum_price']  = $v->sum_price;
                        $zone_list[$k2]['goods_zone']  = $v->goods_zone;
                    }
                }
//                var_dump($list,$zone_list);die;
                if(!isset($zone_list[$k2]['sum_price'])){
                    $zone_list[$k2]['sum_price'] = 0;
                    $zone_list[$k2]['goods_zone'] = $k2+1;
                }
            }
            if($zone_list2){
                foreach($zone_list2 as $k=>$v){
                    $zonelist2[$k]['zone_name'] = $v->zone_name;
                    $zonelist2[$k]['goods_zone'] = $v->id;
                    $zonelist2[$k]['sum_price'] = 0;
                    foreach($list as $k3=>$v3){
                        if($v->id == $v3->goods_zone){
                            $zonelist2[$k]['sum_price']  = $v3->sum_price;
                            $zonelist2[$k]['goods_zone']  = $v3->goods_zone;
                        }
                    }
                }
            }else{
                $zonelist2 = [];
            }
        }
    }else{
        $sum_info = new \stdClass();
        $sum_info->yeji = 0;
        /*  $zone_list[0]['zone_name'] = '商城分区';
          $zone_list[0]['goods_zone'] = 1;
          $zone_list[0]['sum_price'] = 0;*/

        $zone_list[1]['zone_name'] = 'Vip礼包区';
        $zone_list[1]['goods_zone'] = 2;
        $zone_list[1]['sum_price'] = 0;

        $zone_list[2]['zone_name'] = '至尊礼包区';
        $zone_list[2]['goods_zone'] = 3;
        $zone_list[2]['sum_price'] = 0;


        $zone_list[3]['zone_name'] = '10800元礼包分区';
        $zone_list[3]['goods_zone'] = 4;
        $zone_list[3]['sum_price'] = 0;


        $zone_list[4]['zone_name'] = '愫膳之家礼包区';
        $zone_list[4]['goods_zone'] = 5;
        $zone_list[4]['sum_price'] = 0;


        if($zone_list2){
            foreach($zone_list2 as $k=>$v){
                $zonelist2[$k]['zone_name'] = $v->zone_name;
                $zonelist2[$k]['goods_zone'] = $v->id;
                $zonelist2[$k]['sum_price'] = 0;
            }
        }else{
            $zonelist2 = [];
        }
    }


    $R->list =  array_values($zone_list);;
    $R->list2 = $zonelist2;
    $users = new UserConsumer($userid);
    $sum_info->operation_name = $users->getOneFieldData('name')?:'';
    $referrer_user_id = $users->getOneFieldData('referrer');
    $ref_users = new UserConsumer($referrer_user_id);
    if($ref_users->isExist()){
        $sum_info->referrer_name = $ref_users->getOneFieldData('name')?:'';
        $sum_info->regtime = date("Y-m-d H:i",$ref_users->getOneFieldData('regtime'));
    }else{
        $sum_info->referrer_name = '';
        $sum_info->regtime = '';
    }
    $oper_user_id = $ref_users->findRefOper($referrer_user_id);
    if($oper_user_id){
        $oper_user = new UserConsumer($oper_user_id);
        $sum_info->ref_operation = $oper_user->getOneFieldData('name');
    }else{
        $sum_info->ref_operation = '';
    }
    $R->yeji = $sum_info;
//    var_dump($R);die;
//    exit(HttpResponse::exitJSON(TRUE, "运营中心列表获取成功!", ClentCmd::HINT,$R));
}elseif( $type == 2 ){
    $sumdata = new ModelSumData();
    $info = new \stdClass();
    if($month == 1){
        $info->sum_year = $year-1;
        $info->sum_month = 12;
    }else{
        $info->sum_year = $year;
        $info->sum_month = $month-1;
    }
    $info->user_id = $userid;
    $oper = new ModelSumOperation();
    $sum_info = $oper->readLineByAnd($info,null,'yeji,sum_id');
    if($sum_info){
        $list = $sumdata->selectArrayByWhere('sum_id = '.$sum_info->sum_id,' goods_zone asc','goods_zone,sum_price');
        if(!$list){
            /* $zone_list[0]['zone_name'] = '商城分区';
             $zone_list[0]['goods_zone'] = 1;
             $zone_list[0]['sum_price'] = 0;*/

            $zone_list[1]['zone_name'] = 'Vip礼包区';
            $zone_list[1]['goods_zone'] = 2;
            $zone_list[1]['sum_price'] = 0;

            $zone_list[2]['zone_name'] = '至尊礼包区';
            $zone_list[2]['goods_zone'] = 3;
            $zone_list[2]['sum_price'] = 0;


            $zone_list[3]['zone_name'] = '10800元礼包分区';
            $zone_list[3]['goods_zone'] = 4;
            $zone_list[3]['sum_price'] = 0;


            $zone_list[4]['zone_name'] = '愫膳之家礼包区';
            $zone_list[4]['goods_zone'] = 5;
            $zone_list[4]['sum_price'] = 0;

            if($zone_list2){
                foreach($zone_list2 as $k=>$v){
                    $zonelist2[$k]['zone_name'] = $v->zone_name;
                    $zonelist2[$k]['goods_zone'] = $v->id;
                    $zonelist2[$k]['sum_price'] = 0;
                }
            }else{
                $zonelist2 = [];
            }

        }else{
            //$zone_list[0]['zone_name'] = '商城分区';
            $zone_list[1]['zone_name'] = 'Vip礼包区';
            $zone_list[2]['zone_name'] = '至尊礼包区';
            $zone_list[3]['zone_name'] = '10800元礼包分区';
            $zone_list[4]['zone_name'] = '愫膳之家礼包区';
            foreach($zone_list as $k2=>$v2){
                foreach($list as $k=>$v){
                    if($k2 + 1 == $v->goods_zone){
                        $zone_list[$k2]['sum_price']  = $v->sum_price;
                        $zone_list[$k2]['goods_zone']  = $v->goods_zone;
                    }
                }
                if(!isset($zone_list[$k2]['sum_price'])){
                    $zone_list[$k2]['sum_price'] = 0;
                    $zone_list[$k2]['goods_zone'] = $k2+1;
                }
            }
            if($zone_list2){
                foreach($zone_list2 as $k=>$v){
                    $zonelist2[$k]['zone_name'] = $v->zone_name;
                    $zonelist2[$k]['goods_zone'] = $v->id;
                    $zonelist2[$k]['sum_price'] = 0;
                    foreach($list as $k3=>$v3){
                        if($v->id == $v3->goods_zone){
                            $zonelist2[$k]['sum_price']  = $v3->sum_price;
                            $zonelist2[$k]['goods_zone']  = $v3->goods_zone;
                        }
                    }
                }
            }else{
                $zonelist2 = [];
            }

        }
    }else{
        $sum_info = new \stdClass();
        $sum_info->yeji = 0;
        /*  $zone_list[0]['zone_name'] = '商城分区';
          $zone_list[0]['goods_zone'] = 1;
          $zone_list[0]['sum_price'] = 0;*/

        $zone_list[1]['zone_name'] = 'Vip礼包区';
        $zone_list[1]['goods_zone'] = 2;
        $zone_list[1]['sum_price'] = 0;

        $zone_list[2]['zone_name'] = '至尊礼包区';
        $zone_list[2]['goods_zone'] = 3;
        $zone_list[2]['sum_price'] = 0;


        $zone_list[3]['zone_name'] = '10800元礼包分区';
        $zone_list[3]['goods_zone'] = 4;
        $zone_list[3]['sum_price'] = 0;


        $zone_list[4]['zone_name'] = '愫膳之家礼包区';
        $zone_list[4]['goods_zone'] = 5;
        $zone_list[4]['sum_price'] = 0;

        if($zone_list2){
            foreach($zone_list2 as $k=>$v){
                $zonelist2[$k]['zone_name'] = $v->zone_name;
                $zonelist2[$k]['goods_zone'] = $v->id;
                $zonelist2[$k]['sum_price'] = 0;
            }
        }else{
            $zonelist2 = [];
        }

    }
    $R->list =  array_values($zone_list);
    $R->list2 = $zonelist2;
    $users = new UserConsumer($userid);
    $referrer_user_id = $users->getOneFieldData('referrer');
    $sum_info->operation_name = $users->getOneFieldData('name')?:'';
    $ref_users = new UserConsumer($referrer_user_id);
    if($ref_users->isExist()){
        $sum_info->referrer_name = $ref_users->getOneFieldData('name')?:'';
        $sum_info->regtime = date("Y-m-d H:i",$ref_users->getOneFieldData('regtime'));
    }else{
        $sum_info->referrer_name = '';
        $sum_info->regtime = '';
    }
    $oper_user_id = $ref_users->findRefOper($referrer_user_id);
    if($oper_user_id){
        $oper_user = new UserConsumer($oper_user_id);
        $sum_info->ref_operation = $oper_user->getOneFieldData('name');
    }else{
        $sum_info->ref_operation = '';
    }
    $R->yeji = $sum_info;
//    exit(HttpResponse::exitJSON(TRUE, "运营中心列表获取成功!", ClentCmd::HINT,$R));

}elseif($type == 3){
    $oper = new ModelSumOperation();
    $sumdata = new ModelSumData();
    $sum_info = $oper->selectArray('user_id',$userid,' sum_id desc ','yeji,sum_id');
    if(!$sum_info){
        $suminfo = new \stdClass();
        $suminfo->yeji = 0;
        /*$zone_list[0]['zone_name'] = '商城分区';
        $zone_list[0]['goods_zone'] = 1;
        $zone_list[0]['sum_price'] = 0;*/

        $zone_list[1]['zone_name'] = 'Vip礼包区';
        $zone_list[1]['goods_zone'] = 2;
        $zone_list[1]['sum_price'] = 0;

        $zone_list[2]['zone_name'] = '至尊礼包区';
        $zone_list[2]['goods_zone'] = 3;
        $zone_list[2]['sum_price'] = 0;


        $zone_list[3]['zone_name'] = '10800元礼包分区';
        $zone_list[3]['goods_zone'] = 4;
        $zone_list[3]['sum_price'] = 0;


        $zone_list[4]['zone_name'] = '愫膳之家礼包区';
        $zone_list[4]['goods_zone'] = 5;
        $zone_list[4]['sum_price'] = 0;

        if($zone_list2){
            foreach($zone_list2 as $k=>$v){
                $zonelist2[$k]['zone_name'] = $v->zone_name;
                $zonelist2[$k]['goods_zone'] = $v->id;
                $zonelist2[$k]['sum_price'] = 0;
            }
        }else{
            $zonelist2 = [];
        }


    }else{
        $yeji = 0;
        $sumids = [];
        foreach($sum_info as $key=>$val){
            $yeji = $yeji + $val->yeji;
            array_push($sumids,$val->sum_id);
        }
        $sumids = implode(",",$sumids);
        $list = $sumdata->selectArrayByWhere(" sum_id  in ( $sumids )  group by goods_zone ",' goods_zone asc',' sum(sum_price) as sum_price,goods_zone');
        if(!$list){
            /* $zone_list[0]['zone_name'] = '商城分区';
             $zone_list[0]['goods_zone'] = 1;
             $zone_list[0]['sum_price'] = 0;*/

            $zone_list[1]['zone_name'] = 'Vip礼包区';
            $zone_list[1]['goods_zone'] = 2;
            $zone_list[1]['sum_price'] = 0;

            $zone_list[2]['zone_name'] = '至尊礼包区';
            $zone_list[2]['goods_zone'] = 3;
            $zone_list[2]['sum_price'] = 0;


            $zone_list[3]['zone_name'] = '10800元礼包分区';
            $zone_list[3]['goods_zone'] = 4;
            $zone_list[3]['sum_price'] = 0;


            $zone_list[4]['zone_name'] = '愫膳之家礼包区';
            $zone_list[4]['goods_zone'] = 5;
            $zone_list[4]['sum_price'] = 0;

            if($zone_list2){
                foreach($zone_list2 as $k=>$v){
                    $zonelist2[$k]['zone_name'] = $v->zone_name;
                    $zonelist2[$k]['goods_zone'] = $v->id;
                    $zonelist2[$k]['sum_price'] = 0;
                }
            }else{
                $zonelist2 = [];
            }


        }else{
            //$zone_list[0]['zone_name'] = '商城分区';
            $zone_list[1]['zone_name'] = 'Vip礼包区';
            $zone_list[2]['zone_name'] = '至尊礼包区';
            $zone_list[3]['zone_name'] = '10800元礼包分区';
            $zone_list[4]['zone_name'] = '愫膳之家礼包区';
            foreach($zone_list as $k2=>$v2){
                foreach($list as $k=>$v){
                    if($k2 + 1 == $v->goods_zone){
                        $zone_list[$k2]['sum_price']  = $v->sum_price;
                        $zone_list[$k2]['goods_zone']  = $v->goods_zone;
                    }
                }
                if(!isset($zone_list[$k2]['sum_price'])){
                    $zone_list[$k2]['sum_price'] = 0;
                    $zone_list[$k2]['goods_zone'] = $k2+1;
                }
            }

            if($zone_list2){
                foreach($zone_list2 as $k=>$v){
                    $zonelist2[$k]['zone_name'] = $v->zone_name;
                    $zonelist2[$k]['goods_zone'] = $v->id;
                    $zonelist2[$k]['sum_price'] = 0;
                    foreach($list as $k3=>$v3){
                        if($v->id == $v3->goods_zone){
                            $zonelist2[$k]['sum_price']  = $v3->sum_price;
                            $zonelist2[$k]['goods_zone']  = $v3->goods_zone;
                        }
                    }
                }
            }else{
                $zonelist2 = [];
            }
        }

        $suminfo = new \stdClass();
        $suminfo->yeji = $yeji;
    }

    $R->list = array_values($zone_list);
    $R->list2 = $zonelist2;
    $users = new UserConsumer($userid);
    $suminfo->operation_name = $users->getOneFieldData('name')?:'';
    $referrer_user_id = $users->getOneFieldData('referrer');
    $ref_users = new UserConsumer($referrer_user_id);
    if($ref_users->isExist()){
        $suminfo->referrer_name = $ref_users->getOneFieldData('name')?:'';
        $suminfo->regtime = date("Y-m-d H:i",$ref_users->getOneFieldData('regtime'));
    }else{
        $suminfo->referrer_name = '';
        $suminfo->regtime = '';
    }
    $oper_user_id = $ref_users->findRefOper($referrer_user_id);
    if($oper_user_id){
        $oper_user = new UserConsumer($oper_user_id);
        $suminfo->ref_operation = $oper_user->getOneFieldData('name');
    }else{
        $suminfo->ref_operation = '';
    }
    $R->yeji = $suminfo;
//    exit(HttpResponse::exitJSON(TRUE, "运营中心列表获取成功!", ClentCmd::HINT,$R));

}
$a2o = new \ugo\api\model\tools\Array2Object();
$R = $a2o->object_to_array($R);
unset($R['list']['2']);
exit(HttpResponse::exitJSON(TRUE, "运营中心列表获取成功!", ClentCmd::HINT,$R));