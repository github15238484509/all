<?php

echo "我是测试";die('123');