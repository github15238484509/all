<?php
use jiupian\api\model\UserConsumer;
use jiupian\api\model\ModelSumOperation;
use jiupian\api\model\ModelSumData;
use jiupian\api\model\ModelGoodsZone;
//1.找出所有运营中心及其上级运营中心
$users = new UserConsumer();
$sumdata = new ModelSumData();
$year = date("Y");
$month = date("m");
$list = $users->selectArrayByWhere('rank = 5',' user_index desc ','user_id,rank');
if($list){
    //查看当前月是否存在
    $sum = new ModelSumOperation();
    $sum_user_list = $sum->selectArrayByWhere(" sum_year = $year and sum_month = $month  ",' sum_id asc','sum_id,user_id');
    if($sum_user_list){
        $sum_userids = [];
        foreach($sum_user_list as $k=>$v){
            array_push($sum_userids,$v->user_id);
        }
        $sum_userids = array_unique($sum_userids);
        foreach($list as $k2=>$v2){
            if(!in_array($v2->user_id,$sum_userids)){
                $info = new \stdClass();
                $info->user_id = $v2->user_id;
                $info->yeji = 0;
                $info->sum_month = date("m");
                $info->sum_year = date("Y");
                $str_date = date("Y-m-01");
//                $info->add_time = strtotime($str_date);
                $info->add_time = time();
                $user_info = new UserConsumer($v2->user_id);
                $info->ref_user_id = $user_info->findRefOper($user_info->getOneFieldData('referrer'))?:0;
                $sum_id = $sum->insertInfo($info);
            }
        }
        exit('插入部分新运营中心');
    }else{
        foreach($list as $k2=>$v2){
            $info = new \stdClass();
            $info->user_id = $v2->user_id;
            $info->yeji = 0;
            $info->sum_month = date("m");
            $info->sum_year = date("Y");
            $str_date = date("Y-m-01");
//            $info->add_time = strtotime($str_date);
            $info->add_time = time();
            $user_info = new UserConsumer($v2->user_id);
            $info->ref_user_id = $user_info->findRefOper($user_info->getOneFieldData('referrer'))?:0;
            $sum_id = $sum->insertInfo($info);
        }
        exit('插入新运营中心');
    }
}else{
    exit("系统暂无运营中心");
}