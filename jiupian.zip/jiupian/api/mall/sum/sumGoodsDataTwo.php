<?php
set_time_limit(10);
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use HoloPHP\AutoLoader;
use config\ClentCmd;
use jiupian\api\model\ModelSumOperation;
use jiupian\api\model\ModelSumData;
use jiupian\api\model\UserConsumer;
use jiupian\api\model\MallGoodOrder;
use jiupian\api\model\MallGoodOrderGoods;
use jiupian\api\model\MallGood;
use jiupian\api\model\ModelGoodsZone;
use jiupian\api\model\ModelSumGoodsData;
$R = new \stdClass ();
$order = new MallGoodOrder();
$users = new UserConsumer();
$start_time = 1598889600;//2020-09-01
$sql = " select a.order_goods_index,a.user_id,a.goods_index,a.goods_count,a.goods_cost,a.sum_goods,a.order_index,b.order_consumer,b.order_index,b.payment_time,b.order_status from mall_orders_goods a inner join mall_orders b on a.order_index = b.order_index  where  a.sum_goods = 0 and b.order_status >= 2 and b.payment_time >  $start_time";
$list = $order->getDB()->readArray($sql);

if($list){
    $orderGoods = new MallGoodOrderGoods();
    $good = new MallGood();
    $zone = new ModelGoodsZone();
    $oper = new ModelSumOperation();
    $sumdata = new ModelSumData();
    $goodsdata = new ModelSumGoodsData();
    foreach($list as $k=>$v){
        $goods_info = $good->getGoodsInfoByIndexv2($v->goods_index);
        if($goods_info->sum_area != 0 )
        {
            $goods_info->online_area =  $goods_info->sum_area;
            $zone_info = $zone->getOneById($goods_info->online_area);
            if($zone_info && $zone_info->open_sum == 1) {
                $flag = true;
                //添加业绩
                $total_price = floor($v->goods_cost * $v->goods_count);
                $operation_ids = $users->myoids($v->order_consumer);//运营中心
//                $operation_ids_all = $users->myoids_all($v->order_consumer);//运营中心团队全部
//                $operation_ids_two = $users->myoids_two($v->order_consumer);//运营中心团队截断
                if($operation_ids)
                {
                    foreach($operation_ids as $k3=>$v3)
                    {
                        $year = date("Y",$v->payment_time);
                        $month = date("m",$v->payment_time);
                        $info = new \stdClass();
                        $info->sum_year = $year;
                        $info->sum_month = $month;
                        $info->user_id = $v3;
                        $sum_info = $oper->readLineByAnd($info);
                        //添加商品分区业绩统计
                        if($sum_info){
                            $oper->stopAutocommit();
                            $res1 = $oper->addYejiById($total_price,$sum_info->sum_id);//添加业绩
                            $link_sum_id = $sum_info->sum_id;
                            $info2 = new \stdClass();
                            $info2->sum_id = $sum_info->sum_id;
                            $info2->goods_zone = $goods_info->online_area;
                            $sumDataInfo = $sumdata->readLineByAnd($info2);
                            if($sumDataInfo)
                            {
                                $res2 = $sumdata->addSumPriceById($total_price,$sumDataInfo->sum_yejiid);
                                $link_sum_yejiid = $sumDataInfo->sum_yejiid;
                            }else{
                                $info2 = new \stdClass();
                                $info2->sum_id = $sum_info->sum_id;
                                $info2->goods_zone = $goods_info->online_area;
                                $info2->sum_price = $total_price;
                                $res2 = $sumdata->insertInfo($info2);
                                //1
                                $link_sum_yejiid = $res2;
                            }

                            $res3 = $order->setSumDatav2($v->order_goods_index);

                            //添加商品业绩统计
                            $info2 = new \stdClass();
                            $info2->goods_index = $v->goods_index;
                            $info2->goods_yeji = $total_price;
                            $info2->goods_count = $v->goods_count;
                            $info2->goods_zone = $goods_info->online_area;
                            $info2->link_order_goods_index = $v->order_goods_index;
                            $info2->sum_year = $year;
                            $info2->sum_month = $month;
                            $info2->add_time = time();
                            $info2->link_sum_yejiid = $link_sum_yejiid;
                            $info2->link_sum_id = $link_sum_id;
                            $res4 = $goodsdata->insertInfo($info2);
                            //$goodsdata 1

                            if(!$res1 || !$res2 || !$res3 || !$res4){
                                echo 'err'.$v->order_index;
                                echo "<br/>";
                                $oper->rollback();
                            }else{
                                echo 'suc'.$v->order_index;
                                echo "<br/>";
                                $oper->commit();
                            }
                        }else{
                            $oper->stopAutocommit();
                            $info = new \stdClass();
                            $info->user_id = $v3;
                            $info->sum_year = $year;
                            $info->sum_month = $month;
                            $info->yeji = $total_price;
                            $info->ref_user_id = $users->findRefOperv2($v3)?:0;
                            $sum_id = $oper->insertInfo($info);
                            if(!$sum_id ){
                                $oper->rollback();
                            }
                            $link_sum_id = $sum_id;
                            $info2 = new \stdClass();
                            $info2->sum_id = $sum_id;
                            $info2->goods_zone = $goods_info->online_area;
                            $info2->sum_price = $total_price;
                            $res2 = $sumdata->insertInfo($info2);
                            //2
                            $link_sum_yejiid = $sumDataInfo->sum_yejiid;
                            $res3 = $order->setSumDatav2($v->order_goods_index);

                            //添加商品业绩统计
                            $info2 = new \stdClass();
                            $info2->goods_index = $v->goods_index;
                            $info2->goods_yeji = $total_price;
                            $info2->goods_count = $v->goods_count;
                            $info2->goods_zone = $goods_info->online_area;
                            $info2->link_order_goods_index = $v->order_goods_index;
                            $info2->sum_year = $year;
                            $info2->sum_month = $month;
                            $info2->add_time = time();
                            $info2->link_sum_yejiid = $link_sum_yejiid;
                            $info2->link_sum_id = $link_sum_id;
                            $res4 = $goodsdata->insertInfo($info2);
                            //$goodsdata 2

                            if(!$res3 || !$res2 || !$res4){
                                echo 'err'.$v->order_index;
                                echo "<br/>";
                                $oper->rollback();
                            }else{
                                echo 'suc'.$v->order_index;
                                echo "<br/>";
                                $oper->commit();
                            }
                        }
                    }
                }
            }
        }
    }
}else{
    exit("没有统计数据");
}


