<?php
set_time_limit(10);
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use HoloPHP\AutoLoader;
use config\ClentCmd;
use jiupian\api\model\ModelSumOperation;
use jiupian\api\model\ModelSumData;
use jiupian\api\model\UserConsumer;
use jiupian\api\model\MallGoodOrder;
use jiupian\api\model\MallGoodOrderGoods;
use jiupian\api\model\MallGood;
use jiupian\api\model\ModelGoodsZone;
$R = new \stdClass ();
$order = new MallGoodOrder();
$users = new UserConsumer();
$start_time = 1600704000;//2020-09-22
$list = $order->selectArrayByWhere("order_sum = 0 and order_status >= 2 and payment_time >  $start_time ",'order_index desc','order_index,order_id,order_consumer,payment_time');
if($list){
    $orderGoods = new MallGoodOrderGoods();
    $good = new MallGood();
    $zone = new ModelGoodsZone();
    $oper = new ModelSumOperation();
    $sumdata = new ModelSumData();
    foreach($list as $k=>$v){
      $goods_list = $orderGoods->findOrderGoodsByOrder($v->order_index,'goods_index,goods_cost,goods_count');
      if($goods_list){
          foreach($goods_list as $k2=>$v2){
              $goods_info = $good->getGoodsInfoByIndexv2($v2->goods_index);
              $zone_info = $zone->getOneById($goods_info->online_area);
              if($zone_info && $zone_info->open_sum == 1){
                  $flag = true;
                  //添加业绩
                  $total_price = floor($v2->goods_cost*$v2->goods_count);
                  $operation_ids = $users->myoids($v->order_consumer);
                  if($operation_ids){
                      foreach($operation_ids as $k3=>$v3){
                          $year = date("Y",$v->payment_time);
                          $month = date("m",$v->payment_time);
                          $info = new \stdClass();
                          $info->sum_year = $year;
                          $info->sum_month = $month;
                          $info->user_id = $v3;
                          $sum_info = $oper->readLineByAnd($info);
                          if($sum_info){
                              $oper->stopAutocommit();
                              $res1 = $oper->addYejiById($total_price,$sum_info->sum_id);
                              $info2 = new \stdClass();
                              $info2->sum_id = $sum_info->sum_id;
                              $info2->goods_zone = $goods_info->online_area;
                              $sumDataInfo = $sumdata->readLineByAnd($info2);
                              if($sumDataInfo){
                                  $res2 = $sumdata->addSumPriceById($total_price,$sumDataInfo->sum_yejiid);
                              }else{
                                  $info2 = new \stdClass();
                                  $info2->sum_id = $sum_info->sum_id;
                                  $info2->goods_zone = $goods_info->online_area;
                                  $info2->sum_price = $total_price;
                                  $res2 = $sumdata->insertInfo($info2);
                              }
                              $res3 = $order->setSumData($v->order_index);
                              if(!$res1 || !$res2 || !$res3){
                                  $oper->rollback();
                              }else{
                                  echo $v->order_index;
                                  echo "<br/>";
                                  $oper->commit();
                              }
                          }else{
                              $oper->stopAutocommit();
                              $info = new \stdClass();
                              $info->user_id = $v3;
                              $info->sum_year = $year;
                              $info->sum_month = $month;
                              $info->yeji = $total_price;
                              $info->ref_user_id = $users->findRefOperv2($v3)?:0;
                              $sum_id = $oper->insertInfo($info);
                              if(!$sum_id ){
                                  $oper->rollback();
                              }

                              $info2 = new \stdClass();
                              $info2->sum_id = $sum_id;
                              $info2->goods_zone = $goods_info->online_area;
                              $info2->sum_price = $total_price;
                              $res2 = $sumdata->insertInfo($info2);
                              if(!$res2 ){
                                  $oper->rollback();
                              }
                              $res3 = $order->setSumData($v->order_index);
                              if(!$res3 ){
                                  $oper->rollback();
                              }else{
                                  echo $v->order_index;
                                  echo "<br/>";
                                  $oper->commit();
                              }
                          }
                      }
                  }
              }
          }
      }
      $res3 = $order->setSumData($v->order_index);
    }
    exit('统计数据结束');
}else{
    exit("没有统计数据");
}


