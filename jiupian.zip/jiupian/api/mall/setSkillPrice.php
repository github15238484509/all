<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/10/9
 * Time: 15:22
 */
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use jiupian\api\model\MallGood;
$t = time();
$good = new MallGood();
$sql = " select  goods_index,is_skill,skill_start_time,skill_end_time from mall_goods where  goods_status = 2  and  online_area = 1 ";
$list = $good->getDB()->readArray($sql);
if(!$list){
    echo "没有数据处理";
    exit();
}else{
    foreach($list as $key=>$val){
        if($t > $val->skill_start_time && $t < $val->skill_end_time  && $val->is_skill  == 0 ){
            $goods = new MallGood($val->goods_index);
            $goods->updateFieldsValue("is_skill",1);
        }
        if( $t > $val->skill_end_time){
            $goods = new MallGood($val->goods_index);
            $goods->updateFieldsValue("is_skill",0);
            $goods->updateFieldsValue("skill_start_time",0);
            $goods->updateFieldsValue("skill_end_time",0);
        }
    }
    echo "数据处理完毕";
    exit();
}