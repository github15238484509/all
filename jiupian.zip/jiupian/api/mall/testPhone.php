<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/1/21
 * Time: 16:38
 */
use jiupian\api\model\UserConsumer;
$phone = '18868665098';
$userInfo = new UserConsumer(null,null,$phone);
var_dump($userInfo->getInfo($phone));