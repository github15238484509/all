<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/4/24
 * Time: 17:34
 */
namespace jiupian\api\mall\address;
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use tables\account\UserAddress;
use config\ClentCmd;
use HoloPHP\AutoLoader;
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
$R = new \stdClass ();
Verify::existsingAll("address_id", "token");
$addressObj = new UserAddress ();
$res = $addressObj->delectAddress ( $_REQUEST ["address_id"],$user_id );
if ($res) {
    exit(HttpResponse::exitJSON(TRUE, "删除成功~！",ClentCmd::HINT));
} else {
    exit(HttpResponse::exitJSON(FALSE, "删除失败~！",ClentCmd::HINT));
}
?>