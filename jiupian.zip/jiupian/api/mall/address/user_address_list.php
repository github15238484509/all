<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/4/27
 * Time: 13:30
 */
namespace jiupian\api\mall\address;

use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use  jiupian\api\model\UserAddress;
use config\ClentCmd;
use HoloPHP\AutoLoader;
use jiupian\api\model\ModelFunctions;
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
$R = new \stdClass();
$address = new UserAddress();
$list = $address->getListByUserId($user_id);
if (! $list) {
    $list = array();
} else {
    $functions = new ModelFunctions();
    foreach ($list as $key => $val) {
        $val->address = $functions->filterString($val->address);
        $val->contacts = $functions->filterString($val->contacts);
        $val->full_address = $val->province_name . $val->city_name . $val->county_name . $val->address;
    }
}
$R->list = $list;
HttpResponse::exitJSON(TRUE, "获取地址列表成功~！", ClentCmd::HINT, $R);
