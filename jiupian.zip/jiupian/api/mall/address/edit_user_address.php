<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/4/24
 * Time: 16:40
 */

namespace jiupian\api\mall\address;

use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use jiupian\api\model\UserAddress;
use config\ClentCmd;
use HoloPHP\AutoLoader;
use jiupian\api\model\ModelFunctions;

require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
$R = new \stdClass ();
Verify::existsingAll("address_id", "province_id", "province_name", "city_id", "city_name", "county_id", "county_name", "contacts", "phone", "address", "default_address");
$addressId = $_REQUEST ["address_id"];
$province_id = $_REQUEST ["province_id"];
$province_name = $_REQUEST ["province_name"];
$city_id = $_REQUEST ["city_id"];
$city_name = $_REQUEST ["city_name"];
$county_id = $_REQUEST ["county_id"];
$county_name = $_REQUEST ["county_name"];
$contacts = $_REQUEST ["contacts"];
$phone = $_REQUEST ["phone"];
$address = $_REQUEST ["address"];
$default = $_REQUEST ["default_address"];
if (isset($_REQUEST ["address_index"])) {
    $address_index = $_REQUEST ["address_index"];
}
if (isset($_REQUEST ["is_merchant_address"]) && $_REQUEST ["is_merchant_address"] == 1) {
    $merchant_id = $_REQUEST ["merchant_id"];
    $is_merchant_address = 1;
}else{
    $merchant_id = 0;
    $is_merchant_address = 0;
}
if ($addressId == 0) {//添加收货地址
    $addressObj = new UserAddress ();
    $addressObj->getDB()->autocommit(FALSE);
} else {//编辑收货地址
    $addressObj = new UserAddress ($address_index);
    $addressObj->getDB()->autocommit(FALSE);
}
if ($default == 1 && $addressObj->getCount($user_id) >= 1) {
    $res_canl = $addressObj->cancleAddressDefault($user_id);
    if (!$res_canl) {
        $addressObj->getDB()->rollback();
        $addressObj->getDB()->autocommit(true);
        exit(HttpResponse::exitJSON(FALSE, "设置失败，请稍后重试~！", ClentCmd::HINT));
    }
}
if ($addressId == 0) {
    $functions = new ModelFunctions();
    $address = $functions->filterString($address);
    $contacts = $functions->filterString($contacts);
    $res = $addressObj->addAddress($province_id, $province_name, $city_id, $city_name, $county_id, $county_name, $contacts, $phone, $address, $user_id, $default,0,0,null,$merchant_id,$is_merchant_address);
} else {
    $functions = new ModelFunctions();
    $address = $functions->filterString($address);
    $contacts = $functions->filterString($contacts);
    $res = $addressObj->editAddress($province_id, $province_name, $city_id, $city_name, $county_id, $county_name, $contacts, $phone, $address, $default,0,0,0,$is_merchant_address,$merchant_id);
}

if ($res) {
    $addressObj->getDB()->commit();
    $addressObj->getDB()->autocommit(true);
    if ($addressId == 0) {
        $R->addressId = $res;
    }else{
        $R->addressId = $address_index;
    }
    $R->province_name = $province_name;
    $R->city_name = $city_name;
    $R->county_name = $county_name;
    $R->contacts = $contacts;
    $R->phone = $phone;
    $R->address = $address;
    $R->default = $default;
    $R->full_address = $province_name.$city_name.$county_name.$address;
    exit(HttpResponse::exitJSON(TRUE, "设置成功~！",ClentCmd::HINT,$R));
} else {
    $R->code = -3;
    $addressObj->getDB()->rollback();
    $addressObj->getDB()->autocommit(true);
    exit(HttpResponse::exitJSON(FALSE, "设置失败，请稍后重试~！", ClentCmd::HINT));
}
?>