<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/5/7
 * Time: 18:46
 */
namespace jiupian\api\mall\address;
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use tables\account\UserAddress;
use config\ClentCmd;
use HoloPHP\AutoLoader;
use jiupian\api\model\ModelFunctions;
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
Verify::existsingAll("address_id", "device", "token");
$address_id = $_REQUEST ["address_id"];
$addressObj = new UserAddress ( $address_id );
$info = $addressObj->getAddressInfo($address_id);
if(!$info){
    exit(HttpResponse::exitJSON(FALSE, "数据错误~！",ClentCmd::HINT));
}
$functions = new ModelFunctions();
$info->address = $functions->filterString($info->address);
$info->contacts = $functions->filterString($info->contacts);
$info->address_index = $info->index;
unset($info->index);
unset($info->time);
unset($info->full_address);
unset($info->lng);
unset($info->lat);
unset($info->consumer);
unset($info->identity_id);
unset($info->identity_name);
unset($info->identity_front);
unset($info->identity_back);
exit(HttpResponse::exitJSON(TRUE, "数据列表成功~！",ClentCmd::HINT,$info));



