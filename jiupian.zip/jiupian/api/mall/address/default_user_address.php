<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/4/24
 * Time: 17:44
 */
namespace jiupian\api\mall\address;
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use tables\account\UserAddress;
use config\ClentCmd;
use HoloPHP\AutoLoader;
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
$R = new \stdClass ();
Verify::existsingAll("address_id", "device", "token");
$address_id = $_REQUEST ["address_id"];
$addressObj = new UserAddress ( $address_id );
if ($addressObj->getUser()!=$user_id) {
    exit(HttpResponse::exitJSON(FALSE, "请求数据异常",ClentCmd::HINT));
}
$addressObj->getDB ()->autocommit ( false );
$res_cancle = $addressObj->cancleAddressDefault ( $user_id );
if (! $res_cancle) {
    $addressObj->getDB ()->rollback ();
    $addressObj->getDB ()->autocommit ( true );
    exit(HttpResponse::exitJSON(FALSE, "请求数据异常!",ClentCmd::HINT));
}
$res = $addressObj->setDefAddressID ( $address_id );
if ($res) {
    $addressObj->getDB ()->commit ();
    $addressObj->getDB ()->autocommit ( true );
    exit(HttpResponse::exitJSON(TRUE, "设置默认收货地址成功!",ClentCmd::HINT));
} else {
    $addressObj->getDB ()->rollback ();
    $addressObj->getDB ()->autocommit ( true );
    exit(HttpResponse::exitJSON(FALSE, "设置默认收货地址失败!",ClentCmd::HINT));
}
exit ( json_encode ( $R ) );
?>