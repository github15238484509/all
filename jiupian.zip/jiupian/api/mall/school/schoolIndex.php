<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/8/2
 * Time: 15:24
 */
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use config\ClentCmd;
use HoloPHP\AutoLoader;
use jiupian\api\model\ModelVideoText;
use HoloPHP\server\Redis;
use jiupian\api\model\AppBanner;
use jiupian\api\model\VerifyToken;
/*require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');*/
verify::existsingAll("token");
$info = new \stdClass();
$videotext = new ModelVideoText();
$user_id = VerifyToken::checkToken($_REQUEST["token"]);
if($user_id){
    require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
    $rank = $userInfo->getOneFieldData("rank");
    $wheres = " status =1 and  is_del = 0 and type = 0 and ( authority = -1 or  $rank >= authority )";
}else{
    $wheres = " status =1 and  is_del = 0 and type = 0 and authority = -1 ";
    $user_id = session_id();
}
$sort = " id desc limit 0,3";
$fields = " id,cover,title,addtime,popular,subtitle";
$list = $videotext->selectArrayByWhere($wheres, $sort, $fields);
if($list){
    foreach($list as $key=>$val){
        $key1 = "jiupian_".$user_id;
        $data = Redis::get($key1, false);
        $ids = explode(",",$data);
        if(in_array($val->id,$ids)){
            $list[$key]->is_read = 1;
        }else{
            $list[$key]->is_read = 0;
        }
    }
}else{
    $list = array();
}
$info->list = $list;
$banner = new AppBanner();
$banner_type = '258';
$banner_list = $banner->getList($banner_type);
if(!$banner_list){
    $banner_list = array();
}
$info->banner = $banner_list;
exit(HttpResponse::exitJSON(TRUE, "首页获取成功!", ClentCmd::HINT,$info));


