<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/8/2
 * Time: 17:04
 */
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use config\ClentCmd;
use HoloPHP\AutoLoader;
use jiupian\api\model\ModelVideoText;
use HoloPHP\server\Redis;
use jiupian\api\model\ModelSchoolComment;
use jiupian\api\model\UserConsumer;
use jiupian\api\model\ModelSchoolCommentPraise;
use jiupian\api\model\VerifyToken;
use jiupian\api\model\ModelSchoolCommentReply;
use jiupian\api\model\types\UserLevel;
//require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
verify::existsingAll("token","id","page");
$id = $_REQUEST["id"];
$page = $_REQUEST["page"];
$videotext = new ModelVideoText($id);
if(!$videotext->isExist()){
    exit(HttpResponse::exitJSON(FALSE, "传输参数错误!", ClentCmd::HINT));
}

$user_id = VerifyToken::checkToken($_REQUEST["token"]);
if($user_id) {
    require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
    $rank = $userInfo->getOneFieldData("rank");
    if($videotext->getFieldsValue("authority") != -1 && $rank < $videotext->getFieldsValue("authority")){
        $authority = $videotext->getFieldsValue("authority");
        $name = UserLevel::RANK_MAP[$authority];
        $msg = $name."级别以上才有权限查看";
        exit(HttpResponse::exitJSON(FALSE, $msg, ClentCmd::HINT));
    }
}else{
    if($videotext->getFieldsValue("authority") != -1 ){
        $authority = $videotext->getFieldsValue("authority");
        $name = UserLevel::RANK_MAP[$authority];
        $msg = $name."级别以上才有权限查看";
        exit(HttpResponse::exitJSON(FALSE, $msg, ClentCmd::HINT));
    }
    $user_id = session_id();
}
$fields = " title,author,addtime,gradeCount,praiseCount,text_content,banner,subtitle,voice_title,voice_url";
$info = $videotext->getInfo($id,$fields);
$info->text_content = addslashes($info->text_content);
$praise = new ModelSchoolCommentPraise();
$res1 = $praise->is_praise($id,$user_id,1);
if($res1 > 0){
    $info->is_praise = 1;
}else{
    $info->is_praise = 0;
}
$comment = new ModelSchoolComment();
$list = $comment->goods_comment($id, $page,$fields=" comment_index,comment_consumer,comment_content,comment_praise,comment_time");
if($list){
    $commentReply = new ModelSchoolCommentReply();
    foreach($list as $key=>$val){

        $users=new UserConsumer($val->comment_consumer);
        $name = $users->getUserName();
        $list[$key]->comment_nick = mb_substr($name,0,1,'utf-8')."**";
        $res = $praise->is_praise($val->comment_index,$user_id,0);
        if($res > 0){
            $list[$key]->is_comment_praise = 1;
        }else{
            $list[$key]->is_comment_praise = 0;
        }

        //查看回复以及回复点赞
        $res1 = $commentReply->getReply($val->comment_index);
        if(!$res1){
            $res1 = [];
        }else{
            $res1 = $res1[0];
            $res2 = $praise->is_praise($res1->reply_index,$user_id,2);
            if($res2 > 0){
                $res1->is_reply_comment_praise = 1;
            }else{
                $res1->is_reply_comment_praise = 0;
            }
        }
        @$res1->reply_author = "作者";
        $list[$key]->reply = $res1;
    }
}else{
    $list = array();
}
$info->list = $list;
$res = $videotext->update_popular($id);
if(!$res){
    exit(HttpResponse::exitJSON(FALSE, "网络异常，请稍后再试!", ClentCmd::HINT));
}
$key1 = "jiupian_".$user_id;
$data = Redis::get($key1, false);
$ids = explode(",",$data);
if(count($ids) == 0){
    $data = $id;
}else{
    if(!in_array($id,$ids)){
        $data  = $data.",".$id;
    }
}
Redis::set($key1,$data);
exit(HttpResponse::exitJSON(TRUE, "获取详情成功!", ClentCmd::HINT,$info));








