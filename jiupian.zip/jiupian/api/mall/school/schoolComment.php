<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/8/2
 * Time: 19:02
 */
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use config\ClentCmd;
use HoloPHP\AutoLoader;
use jiupian\api\model\ModelVideoText;
use jiupian\api\model\ModelSchoolComment;
use jiupian\api\model\ModelFunctions;
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
verify::existsingAll("token","id","content");
$functios = new ModelFunctions();
$content = $functios->filterString($_REQUEST["content"]);
$comment = new ModelSchoolComment();
$id = $_REQUEST["id"];
$text = new ModelVideoText($id);
if(!$text->isExist()){
    exit(HttpResponse::exitJSON(FALSE, "网络异常，请稍后再试!", ClentCmd::HINT));
}
$text->stopAutocommit();
$info = new \stdClass();
$info->comment_consumer = $user_id;
$info->comment_content = $content;
$info->comment_id = $id;
$res2 = $comment->setComment($info);
//$res1 = $text->update_grade($id);
if(!$res2){
    $text->rollback();
    exit(HttpResponse::exitJSON(FALSE, "网络异常，请稍后再试!", ClentCmd::HINT));
}else{
    $text->commit();
    exit(HttpResponse::exitJSON(TRUE, "留言成功!", ClentCmd::HINT));
}



