<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/8/2
 * Time: 18:33
 */
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use config\ClentCmd;
use HoloPHP\AutoLoader;
use jiupian\api\model\ModelVideoText;
use jiupian\api\model\ModelSchoolComment;
use jiupian\api\model\ModelSchoolCommentPraise;
use jiupian\api\model\ModelSchoolCommentReply;
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
verify::existsingAll("token","type","data_id");
$type = $_REQUEST["type"];
if($type == 1){//视频或图文点赞
    verify::existsingAll("data_id");
    $id = $_REQUEST["data_id"];
    $text = new ModelVideoText($id);
    if(!$text->isExist()){
        exit(HttpResponse::exitJSON(FALSE, "网络异常，请稍后再试!", ClentCmd::HINT));
    }
    //判断是否点赞过
    $praise = new ModelSchoolCommentPraise();
    $res = $praise->is_praise($id,$user_id,$type);
    if($res > 0 ){
        exit(HttpResponse::exitJSON(FALSE, "您已经点赞过!", ClentCmd::HINT));
    }
    $text->stopAutocommit();
    $res1 = $text->update_praise($id);
    $res2 =  $praise->comment_praise($id, $user_id,$type);
    if(!$res2 || !$res1){
        $text->rollback();
        exit(HttpResponse::exitJSON(FALSE, "网络异常，请稍后再试!", ClentCmd::HINT));
    }else{
        $text->commit();
        exit(HttpResponse::exitJSON(TRUE, "点赞成功!", ClentCmd::HINT));
    }
}elseif($type == 0){//评论点赞
    verify::existsingAll("data_id");
    $id = $_REQUEST["data_id"];
    $comment = new ModelSchoolComment($id);
    if(!$comment->isExist()){
        exit(HttpResponse::exitJSON(FALSE, "网络异常，请稍后再试!", ClentCmd::HINT));
    }
    //判断是否点赞过
    $praise = new ModelSchoolCommentPraise();
    $res = $praise->is_praise($id,$user_id,$type);
    if($res > 0 ){
        exit(HttpResponse::exitJSON(FALSE, "您已经点赞过!", ClentCmd::HINT));
    }
    $comment->stopAutocommit();
    $res1 = $comment->update_comment_praise($id,1);
    $res2 =  $praise->comment_praise($id, $user_id,$type);
    if(!$res2 || !$res1){
        $comment->rollback();
        exit(HttpResponse::exitJSON(FALSE, "网络异常，请稍后再试!", ClentCmd::HINT));
    }else{
        $comment->commit();
        exit(HttpResponse::exitJSON(TRUE, "点赞成功!", ClentCmd::HINT));
    }
}elseif($type == 2){//评论回复点赞
    verify::existsingAll("data_id");
    $id = $_REQUEST["data_id"];
    $commentReply = new ModelSchoolCommentReply($id);
    if(!$commentReply->isExist()){
        exit(HttpResponse::exitJSON(FALSE, "网络异常，请稍后再试!", ClentCmd::HINT));
    }
    //判断是否点赞过
    $praise = new ModelSchoolCommentPraise();
    $res = $praise->is_praise($id,$user_id,$type);
    if($res > 0 ){
        exit(HttpResponse::exitJSON(FALSE, "您已经点赞过!", ClentCmd::HINT));
    }
    $commentReply->stopAutocommit();
    $res1 = $commentReply->update_comment_praise($id,1);
    $res2 =  $praise->comment_praise($id, $user_id,$type);
    if(!$res2 || !$res1){
        $commentReply->rollback();
        exit(HttpResponse::exitJSON(FALSE, "网络异常，请稍后再试!", ClentCmd::HINT));
    }else{
        $commentReply->commit();
        exit(HttpResponse::exitJSON(TRUE, "点赞成功!", ClentCmd::HINT));
    }
}