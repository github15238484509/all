<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/8/3
 * Time: 9:29
 */
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use config\ClentCmd;
use HoloPHP\AutoLoader;
use jiupian\api\model\ModelVideoText;
use HoloPHP\server\Redis;
use jiupian\api\model\VerifyToken;
//require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
verify::existsingAll("token","page","type");
$info = new \stdClass();
$page = $_REQUEST["page"];
$start = $page*20;
$type = $_REQUEST["type"];
$videotext = new ModelVideoText();
$videotext = new ModelVideoText();
$user_id = VerifyToken::checkToken($_REQUEST["token"]);
if($user_id){
    require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
    $rank = $userInfo->getOneFieldData("rank");
    if($type == 0){
        $wheres = " status =1 and is_del = 0 and type = 0 and ( authority = -1 or  $rank >= authority )";
    }elseif($type == 1){
        $wheres = " status =1 and is_del = 0 and type = 1 and ( authority = -1 or  $rank >= authority )";
    }
}else{
    $wheres = " status =1 and is_del = 0 and type = $type and authority = -1 ";
    $user_id = session_id();
}

$sort = " addtime ,recomend desc limit $start ,20";
$fields = " id,cover,title,addtime,popular,duration,subtitle";
$list = $videotext->selectArrayByWhere($wheres, $sort, $fields);
if(!$list){
    $list = array();
}else{
    foreach($list as $key=>$val){
        $key1 = "jiupian_".$user_id;
        $data = Redis::get($key1, false);
        $ids = explode(",",$data);
        if(in_array($val->id,$ids)){
            $list[$key]->is_read = 1;
        }else{
            $list[$key]->is_read = 0;
        }
    }
}
$info->list = $list;
exit(HttpResponse::exitJSON(TRUE, "列表获取成功!", ClentCmd::HINT,$info));
