<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/8/2
 * Time: 14:25
 */
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use config\ClentCmd;
use jiupian\api\model\ModelSymtomManage;
use jiupian\api\model\ModelSymptom;
use HoloPHP\AutoLoader;
use jiupian\api\model\ModelFunctions;
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
verify::existsingAll("token","health_id");
$info = new \stdClass();
$health_id = $_REQUEST["health_id"];
$manage = new ModelSymtomManage($health_id);
if(!$manage->isExist()){
    exit(HttpResponse::exitJSON(FALSE, "传输参数错误!", ClentCmd::HINT,$R));
}
/*if($manage->getFieldsValue("symptom_user") != $user_id){
    exit(HttpResponse::exitJSON(FALSE, "传输参数错误!", ClentCmd::HINT,$R));
}*/
$info = $manage->getHealthInfo($health_id,"name,sex,age,height,weight,waistline,bloodPressure,bloodSugar,symptom_ids,reply");
if($info){
    $symptom_ids = explode(",",$info->symptom_ids);
    $symptom_list = [];
    foreach($symptom_ids as $val){
        $symptom = new ModelSymptom($val);
        if($symptom->isExist()){
            array_push($symptom_list,$symptom-> getFieldsValue("symptom_name"));
        }else{
            continue;
        }
    }
    $info->symptom_list = $symptom_list;
    $functions = new ModelFunctions();
    $info->reply = $functions->filterString($info->reply);
    unset($info->symptom_ids);
    exit(HttpResponse::exitJSON(TRUE, "获取详情成功!", ClentCmd::HINT,$info));
}else{
    exit(HttpResponse::exitJSON(FALSE, "获取详情失败!", ClentCmd::HINT,$info));
}
