<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/8/2
 * Time: 10:24
 */
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use config\ClentCmd;
use jiupian\api\model\ModelSymptom;
use HoloPHP\AutoLoader;
use jiupian\api\model\AppBanner;
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
verify::existsingAll("token","page");
$R = new \stdClass();
$page = $_REQUEST["page"];
$symptom = new ModelSymptom();
$wheres = " is_del = 0 and symptom_page = $page";
$sort = " `id` asc ";
$fields = " symptom_name,id,symptom_page";
$list = $symptom->getList($wheres, $sort, $fields);
if(!$list){
    exit(HttpResponse::exitJSON(FALSE, "列表获取失败!", ClentCmd::HINT,$R));
}
$R->total_page = $symptom->getMaxPage()->total_page;
$banner = new AppBanner();
$banner_type = '260';
$banner_list = $banner->getList($banner_type);
if(!$banner_list){
    $R->background_image = "jiupian/back.png";
}else{
    $R->background_image = $banner_list[0]->banner_photo;
}
$R->list = $list;
exit(HttpResponse::exitJSON(TRUE, "列表获取成功!", ClentCmd::HINT,$R));