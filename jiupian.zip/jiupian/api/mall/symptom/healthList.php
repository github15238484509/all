<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/8/2
 * Time: 14:03
 */
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use config\ClentCmd;
use jiupian\api\model\ModelSymtomManage;
use HoloPHP\AutoLoader;
use jiupian\api\model\UserConsumer;
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
verify::existsingAll("token");
$info = new \stdClass();
$manage = new ModelSymtomManage();
if(isset($_REQUEST["phone"]) && !empty($_REQUEST["phone"])){
    $phone = trim($_REQUEST["phone"]);
    $res_user = new UserConsumer(null,null,$phone);
    $res_user_id = $res_user->getOneFieldData("user_id");
    $wheres = " is_del = 0 and symptom_user = $res_user_id ";
    $wheres1 = " symptom_user = $res_user_id ";
}else{
    $wheres = " is_del = 0 and symptom_user = $user_id ";
    $wheres1 = " symptom_user = $user_id ";
}

$sort = " addtime desc";
$fields = " addtime,id,is_reply";
$list = $manage->selectArrayByWhere($wheres, $sort , $fields );
$list1 = $manage->selectArrayByWhere($wheres1, $sort , $fields );
if(!$list){
    $list = [];
}else{
    foreach($list as $key=>$val){
        $list[$key]->health_id = $val->id;
        unset($val->id);
    }
}
$info->is_submit = 1;
if(!$list1){
    $info->is_submit = 0;
}else{
   if(time() - $list1[0]->addtime > 7*24*3600){
       $info->is_submit = 0;
   }else{
       $info->is_submit = 1;
   }
}
$info->list = $list;
exit(HttpResponse::exitJSON(TRUE, "列表获取成功!", ClentCmd::HINT,$info));