<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/8/2
 * Time: 14:12
 */
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use config\ClentCmd;
use jiupian\api\model\ModelSymtomManage;
use HoloPHP\AutoLoader;
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
verify::existsingAll("token","health_id");
$info = new \stdClass();
$health_id = $_REQUEST["health_id"];
$manage = new ModelSymtomManage($health_id);
if(!$manage->isExist()){
    exit(HttpResponse::exitJSON(FALSE, "传输参数错误!", ClentCmd::HINT,$R));
}
if($manage->getFieldsValue("symptom_user") != $user_id){
    exit(HttpResponse::exitJSON(FALSE, "传输参数错误!", ClentCmd::HINT,$R));
}
if($manage->getFieldsValue("is_reply") == 1){
    exit(HttpResponse::exitJSON(FALSE, "已解读不可删除!", ClentCmd::HINT,$R));
}
$res = $manage->updateFieldsValue("is_del",1);
if(!$res){
    exit(HttpResponse::exitJSON(FALSE, "删除失败!", ClentCmd::HINT,$R));
}else{
    exit(HttpResponse::exitJSON(TRUE, "删除成功!", ClentCmd::HINT,$R));
}