<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/8/2
 * Time: 10:58
 */
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use config\ClentCmd;
use jiupian\api\model\ModelSymptom;
use jiupian\api\model\ModelFunctions;
use jiupian\api\model\ModelSymtomManage;
use HoloPHP\AutoLoader;
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
verify::existsingAll("token","ids","name","sex","age","weight","height","waistline","bloodPressure","bloodSugar","address","medicalHistory","detoxificationHistory","phone");
$info = new \stdClass();
$functions = new ModelFunctions();
$info->symptom_user = $user_id;
$info->symptom_ids = $_REQUEST["ids"];
$info->name = $_REQUEST["name"];
$info->sex = $_REQUEST["sex"];
if($info->sex != "女" && $info->sex != "男"){
    exit(HttpResponse::exitJSON(FALSE, "请填写正确的性别!", ClentCmd::HINT));
}
$info->age = $_REQUEST["age"];
$info->weight = $_REQUEST["weight"];
$info->height = $_REQUEST["height"];
$info->waistline = $_REQUEST["waistline"];
$info->address =$functions->filterString( $_REQUEST["address"]);
$info->bloodPressure = $_REQUEST["bloodPressure"];
$info->bloodSugar = $_REQUEST["bloodSugar"];
$info->medicalHistory = $functions->filterString($_REQUEST["medicalHistory"]);
$info->detoxificationHistory = $functions->filterString($_REQUEST["detoxificationHistory"]);
$info->phone = $_REQUEST["phone"];
$info->addtime = time();
if(!$functions->checkPhone($info->phone)){
    exit(HttpResponse::exitJSON(FALSE, "请填写正确的手机号!", ClentCmd::HINT));
}
if(!is_numeric($info->age)  || $info->age > 100){
    exit(HttpResponse::exitJSON(FALSE, "请填写正确的年龄!", ClentCmd::HINT));
}
if(!is_numeric($info->height)  || $info->height > 300){
    exit(HttpResponse::exitJSON(FALSE, "请填写正确的升高!", ClentCmd::HINT));
}
if(!is_numeric($info->waistline)  || $info->waistline > 300){
    exit(HttpResponse::exitJSON(FALSE, "请填写正确的腰围!", ClentCmd::HINT));
}
if(!is_numeric($info->weight)  || $info->weight > 150){
    exit(HttpResponse::exitJSON(FALSE, "请填写正确的体重!", ClentCmd::HINT));
}
if($info->bloodPressure < 0){
    exit(HttpResponse::exitJSON(FALSE, "请填写正确的血压!", ClentCmd::HINT));
}
if($info->bloodSugar < 0){
    exit(HttpResponse::exitJSON(FALSE, "请填写正确的血糖!", ClentCmd::HINT));
}
$symptom = new ModelSymptom();
$symptom->update_selected($info->symptom_ids,1);
$manage = new ModelSymtomManage();
$res = $manage->insertData($info);
if($res){
    exit(HttpResponse::exitJSON(true, "提交成功!", ClentCmd::HINT));
}else{
    exit(HttpResponse::exitJSON(FALSE, "提交失败!", ClentCmd::HINT));
}