<?php
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use jiupian\api\model\UserConsumer;
// 检测手机号是否已经注册过会员
if (!Verify::existsingAll("phone")) {
    exit(HttpResponse::exitJSON(false, "缺少请求参数~！", "hint"));
}
$phone = trim($_REQUEST["phone"]);
$user = new UserConsumer(null, null,$phone);
if ($user->isExist()) {
    $R = new \stdClass();
    $R->name = $user->getOneFieldData("name");
    $R->photo = $user->getOneFieldData("photo");
    exit(HttpResponse::exitJSON(FALSE, "健康使者账号已注册~！", "popup_to_login",$R));
}
exit(HttpResponse::exitJSON(true, "健康使者账号未注册~！", "register"));
?>