<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/8/29
 * Time: 14:32
 */
use jiupian\api\model\UserConsumer;
use HoloPHP\tools\HttpResponse;
use HoloPHP\tools\UUID;
use tables\account\LoginStatus;
use config\ClentCmd;
use HoloPHP\AutoLoader;
use HoloPHP\tools\Verify;
use HoloPHP\tools\Array2Object;
Verify::existsingAll("bianhao",'login_password');
$phone = $_REQUEST["phone"];
$bianhao = $_REQUEST["bianhao"];
$password = $_REQUEST["login_password"];
$device =  $_REQUEST["device"]?:0;
$userInfo = new UserConsumer();
$res = $userInfo->getPrimaryKeyBybianhao($bianhao);
if(!$res){
    exit(HttpResponse::exitJSON(FALSE, "编号不存在~！", "to_register"));
}
if($res->phone || !empty($res->phone)){
    exit(HttpResponse::exitJSON(FALSE, "账号已经激活过请验证手机号~！", "to_register"));
}
$user = new UserConsumer($res->user_id);
if ($user->getLoginPwd() == substr($password, 0, 16)) {
    $token = UUID::token($res->user_id);
    $status = new LoginStatus($token);
    if ($status->isExist()) {
        if (! $status->reLogin($token, $device)) {
            $user->rollback();
            $data = [];
            exit(HttpResponse::exitJSON(FALSE, "插入登录数据失败2~！",ClentCmd::HINT,$data));
        }
    } else {
        if (! LoginStatus::newUserLogin($token, $res->user_id, $device)) {
            $user->rollback();
            $data = [];
            exit(HttpResponse::exitJSON(FALSE, "插入登录数据失败3~！",ClentCmd::HINT,$data));
        }
    }
    $user->commit();
    $data = array(
        "token" => $token,
        "cash" => 0,
        "rank" => 0,
        "login_pwd_status" => 0,
        "pay_pwd_status" => 0,
        "card_status" => 0,
        "bank_status" => 0,
        "merchant_status" => 0,
        "agent_status" => 0
    );
    $data = Array2Object::array2object($data);
    exit(HttpResponse::exitJSON(TRUE, "恭喜~！激活成功", ClentCmd::TO_MY, $data));
}else{
    exit(HttpResponse::exitJSON(FALSE, "登录密码输入错误~！", "to_register"));
}