<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/9/18
 * Time: 17:55
 */
use jiupian\api\model\UserConsumer;
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use config\ClentCmd;
use HoloPHP\AutoLoader;
use jiupian\api\model\types\UserLevel;
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
$R = new \stdClass ();
Verify::existsingAll("user_id", "device", "token");
$type = $_REQUEST['type'];
$page = $_REQUEST['page'];
if(!isset($_REQUEST['count']) || empty($_REQUEST['count'])){
    $count = 20;
}else{
    $count = $_REQUEST['count'];
}
$user_id = $_REQUEST["user_id"];
$ref_userInfo = new UserConsumer($user_id);
if(!$ref_userInfo){
    exit(HttpResponse::exitJSON(false, "用户不存在~！",ClentCmd::POPUP_TO_LOGIN));
}
$data = $ref_userInfo->getSubMember_v2($page, $count);
if(!$data){
    $list = [];
}else{
    foreach ($data as $key=>$value){
        $data[$key]->rank_name =  UserLevel::RANK_MAP[$value->rank];
    }
    $list =$data;
}
$R->list = $list;
$R->user_name = $ref_userInfo->getOneFieldData("name");
$R->phone = $ref_userInfo->getOneFieldData("phone");
$R->sale_cash = $ref_userInfo->getOneFieldData("total_out_cash");
exit(HttpResponse::exitJSON(TRUE, "查询数据成功~！",ClentCmd::POPUP_TO_LOGIN,$R));



