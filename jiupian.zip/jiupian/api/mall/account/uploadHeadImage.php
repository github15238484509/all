<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/4/27
 * Time: 17:02
 */
namespace jiupian\api\mall\account;
use HoloPHP\tools\HttpResponse;
use HoloPHP\tools\ImgUpload;
use HoloPHP\server\Server;
use jiupian\api\model\UserConsumer;
use HoloPHP\AutoLoader;
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
$directory = Server::getProject() . '/user/' . date("Ymd", time());
$oss = new ImgUpload($directory);
$ret = $oss->upload($_FILES["file"]);
if (! $ret) {
    exit(HttpResponse::exitJSON(false, "上传头像失败~！", "hint", $ret));
}
$filePath = $ret["data"][0]["uri"];
$userInfo = new UserConsumer($user_id);
$res = $userInfo->setHeadPhoto($filePath);
if(!$res){
    exit(HttpResponse::exitJSON(TRUE, "上传头像失败~！", "hint"));
}else{
    exit(HttpResponse::exitJSON(TRUE, "上传头像成功~！", "hint", $filePath));
}
?>