<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/6/26
 * Time: 17:38
 */
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use HoloPHP\AutoLoader;
use config\ClentCmd;
use jiupian\api\model\ModelUserBonusChange;
use jiupian\api\model\UserBonusChange;
use jiupian\api\model\types\BonusChange;
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
Verify::existsingAll("token","type");
$R = new \stdClass();
$type = $_REQUEST["type"];
if($type == 0){//首页显示
    $change = new ModelUserBonusChange();
    $page = 0;
    $list = $change->getList($page,$user_id);
    if(!$list){
        $list = array();
    }else{
        foreach($list as $key=>$val){
            $list[$key]->msg = BonusChange::TYPE_MAP[$val->type];
        }
        $list = array_slice ( $list, 0, 5 );
    }
    if(count($list) > 0){
        $R->is_all = 1;
    }else{
        $R->is_all = 0;
    }
    $R->bonus = $userInfo->getBonus();
    $R->list = $list;
    exit(HttpResponse::exitJSON(true, "获取列表成功~！", "hint",$R));
}else{
    Verify::existsingAll("page");
    $page = $_REQUEST["page"];
    if(isset($_REQUEST["start_time"])) {
        $start_time  = trim($_REQUEST["start_time"]);
        if(!empty($start_time) && $start_time != ""){
            $year = substr($start_time, 0, 4);
            $month = substr($start_time, 4, 2);
            $day = substr($start_time, -2);
            $new_time = $year . "-" . $month . "-" . $day;
            $start_time = strtotime($new_time);
            if ($start_time > time()) {
                exit(HttpResponse::exitJSON(false, "时间选择错误~！", "hint", $list));
            }
        }else{
            $start_time = null;
        }

    }else{
        $start_time = null;
    }


    $change = new ModelUserBonusChange();
    $list = $change->getList($page,$user_id,$start_time);
    if(!$list){
        $list = array();
        $R->is_all = 0;
    }else{
        foreach($list as $key=>$val){
            $list[$key]->msg = BonusChange::TYPE_MAP[$val->type];
        }
        $R->is_all = 1;
    }
    $R->bonus = $userInfo->getBonus();
    $R->list = $list;
    exit(HttpResponse::exitJSON(true, "获取列表成功~！", "hint",$R));
}