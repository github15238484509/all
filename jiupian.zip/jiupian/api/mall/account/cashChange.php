<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/6/27
 * Time: 9:41
 */
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use HoloPHP\AutoLoader;
use config\ClentCmd;
use jiupian\api\model\ModelUserCashChange;
use jiupian\api\model\types\UserCashChange;
$R = new \stdClass();
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
Verify::existsingAll("token","page","type");
/*if(isset($_REQUEST['start_time']) && !empty($_REQUEST['start_time'])){
    $start_time = $_REQUEST['start_time'];
}else{
    $start_time = null;
}*/
if(isset($_REQUEST["start_time"])) {
    $start_time  = trim($_REQUEST["start_time"]);
    if(!empty($start_time) && $start_time != ""){
        $year = substr($start_time, 0, 4);
        $month = substr($start_time, 4, 2);
        $day = substr($start_time, -2);
        $new_time = $year . "-" . $month . "-" . $day;
        $start_time = strtotime($new_time);
        if ($start_time > time()) {
            exit(HttpResponse::exitJSON(false, "时间选择错误~！", "hint", $list));
        }
    }else{
        $start_time = null;
    }

}else{
    $start_time = null;
}
$page = $_REQUEST["page"];
$type = $_REQUEST["type"];
if($type == 0){//全部
    $types = [];
}elseif($type == 1 ){
    $type1 = $types = [18];//伯乐奖
}elseif($type == 2){
    $type2 = $types = [12,13,14,15,16,17,19,20,21,22];//管理奖
}elseif($type == 3){//推荐奖
    $type3 = $types = [7,8,10,11];//推荐奖
}
$type3 = [7,8,10,11];
$type2 =  [12,13,14,15,16,17,19,20,21,22];//管理奖
$type1 =  [18];//伯乐奖
$cashChange = new ModelUserCashChange();
$list = $cashChange->getList($user_id,$page,$start_time,$types);
if($list){
    foreach($list as $key=>$val){
        if(in_array($val->type,$type1) ){
            $list[$key]->msg = "伯乐奖";
        }elseif(in_array($val->type,$type2)){
            $type5 = [12,14];
            $type6 = [16];
            $type7 = [17,13,15];
            $type8 = [19,20];
            $type9 = [21,22];
            if(in_array($val->type,$type5)){
                $list[$key]->msg = "管理奖(运营中心)";
            }elseif(in_array($val->type,$type6)){
                $list[$key]->msg = "管理奖(区域运营中心)";
            }elseif(in_array($val->type,$type7)){
                $list[$key]->msg = "管理奖(素膳之家)";
            }elseif(in_array($val->type,$type8)){
                $list[$key]->msg = "管理奖(合伙人)";
            }elseif(in_array($val->type,$type9)){
                $list[$key]->msg = "管理奖(至尊)";
            }
        }elseif(in_array($val->type,$type3)){
            $type4 = [7,10];
            if(in_array($val->type,$type4) ){
                $list[$key]->msg = "分享奖";
            }else{
                $list[$key]->msg = "分享奖(二)";
            }
        }else{
            $list[$key]->msg = UserCashChange::TYPE_MAP[$val->type];
        }
    }
}else{
    $list = array();
}
$R->list = $list;
exit(HttpResponse::exitJSON(true, "获取列表成功~！", "hint",$R));

