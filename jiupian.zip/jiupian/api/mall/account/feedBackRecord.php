<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/4/26
 * Time: 11:03
 */
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use config\ClentCmd;
use jiupian\api\model\UserFeedback;
use HoloPHP\AutoLoader;
use jiupian\api\model\VerifyToken;
$res = VerifyToken::checkToken($_REQUEST["token"]);
if($res){
    require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
    $R = new \stdClass ();
    $phone = $userInfo->getPhone();
    $feed = new UserFeedback ();
    $wheres = " feedback_contact = $phone";
    $sort = " feedback_addtime desc";
    $fields = " feedback_index,feedback_content,feedback_addtime";
    $list = $feed->selectArrayByWhere($wheres, $sort, $fields);
    if(!$list){
        $list = array();
    }
    $R->list = $list;
    exit(HttpResponse::exitJSON(TRUE, "获取列表成功~！", ClentCmd::HINT,$R));

}else{
    $R = new \stdClass ();
    Verify::existsingAll ("phone");
    $feed = new UserFeedback ();
    $phone = $_REQUEST['phone'];
    $feed = new UserFeedback ();
    $wheres = " feedback_contact = $phone";
    $sort = " feedback_addtime desc";
    $fields = " feedback_index,feedback_content,feedback_addtime";
    $list = $feed->selectArrayByWhere($wheres, $sort, $fields);
    if(!$list){
        $list = array();
    }
    $R->list = $list;
    exit(HttpResponse::exitJSON(TRUE, "获取列表成功~！", ClentCmd::HINT,$R));
}

