<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/6/26
 * Time: 17:38
 */
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use HoloPHP\AutoLoader;
use jiupian\api\model\ModelCurrenciesChange;
use jiupian\api\model\types\CurrenciesChange;
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
Verify::existsingAll("token","currencies_type");
$R = new \stdClass();
Verify::existsingAll("page");
$page = $_REQUEST["page"];
$currencies_type = $_REQUEST["currencies_type"];
if(isset($_REQUEST["start_time"])) {
    $start_time  = trim($_REQUEST["start_time"]);
    if(!empty($start_time) && $start_time != ""){
        $year = substr($start_time, 0, 4);
        $month = substr($start_time, 4, 2);
        $day = substr($start_time, -2);
        $new_time = $year . "-" . $month . "-" . $day;
        $start_time = strtotime($new_time);
        if ($start_time > time()) {
            exit(HttpResponse::exitJSON(false, "时间选择错误~！", "hint", $list));
        }
    }else{
        $start_time = null;
    }

}else{
    $start_time = null;
}
$change = new ModelCurrenciesChange();
$list = $change->getList($page,$user_id,$start_time,$currencies_type);
if(!$list){
    $list = array();
}else{
    foreach($list as $key=>$val){
        $list[$key]->msg = CurrenciesChange::TYPE_MAP[$val->type];
    }
}
$R->list = $list;
exit(HttpResponse::exitJSON(true, "获取列表成功~！", "hint",$R));
