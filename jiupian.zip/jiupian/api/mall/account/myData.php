<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/4/24
 * Time: 18:59
 */
use jiupian\api\model\UserConsumer;
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use config\ClentCmd;
use HoloPHP\AutoLoader;
use jiupian\api\model\types\UserLevel;
//require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
$userInfo = new UserConsumer(null,null,'13355811612');
$user_id = $userInfo->getOneFieldData("user_id");
$R = new \stdClass ();
$type = $_REQUEST['type'];
$page = $_REQUEST['page'];
if(!isset($_REQUEST['count']) || empty($_REQUEST['count'])){
    $count = 20;
}else{
    $count = $_REQUEST['count'];
}
if($type == 0){//用户本身
    Verify::existsingAll("type", "device", "page");
    $data = $userInfo->getSubMember_v2($page, $count);
    if(!$data){
        $list = [];
    }else{
        foreach ($data as $key=>$value){
            $data[$key]->rank_name =  UserLevel::RANK_MAP[$value->rank];
        }
        $list = $data;
    }
    $referrer_id = $userInfo->getOneFieldData("referrer");
    if(!$referrer_id) {
        $R->referrer_name = "";
    }else{
        $superInfo = new UserConsumer($referrer_id);
        $R->referrer_name = $superInfo->getOneFieldData("name");
    }
    $R->user_id = $user_id;
    $R->underling_income = $userInfo->getOneFieldData("total_income");
    $R->sale_cash = $userInfo->getOneFieldData("total_out_cash");
    $R->list = $list;
}elseif($type == 1){
    Verify::existsingAll("underling");
    $level_id = $_REQUEST['underling'];
    $level_info = new UserConsumer($level_id);
    if(!$level_info->isExist()){
        exit(HttpResponse::exitJSON(FALSE, "所查询的用户不存在~！",ClentCmd::POPUP_TO_LOGIN));
    }

    $referrer_id = $level_info->getOneFieldData("referrer");
    if($referrer_id != $user_id){
        if($referrer_id != $user_id){
            $ref_level_info = new UserConsumer($referrer_id);
            if($ref_level_info->getOneFieldData("referrer") != $user_id){
                exit(HttpResponse::exitJSON(FALSE, "当前帐号没有权限查询此用户的数据~！",ClentCmd::POPUP_TO_LOGIN));
            }
        }
    }
   /* $list = $level_info->getSubMember($page, $count);
    if(is_array($list) && !empty($list)){
        $lists = $level_info->getCountMyGroup($level_id);
        if(empty($lists)){
            $R->underling_count = 0;
        }else{
            $R->underling_count = count($lists);
        }
    }else{
        $list = array();
        $R->underling_count = 0;
    }*/
    $R->user_name = $level_info->getOneFieldData("name");
    $R->phone = $level_info->getPhone();
    $R->sale_cash = $level_info->getOneFieldData("total_out_cash");
}elseif($type == 2){
    Verify::existsingAll("underling");
    $leveler_id = $_REQUEST['underling'];
    $leveler_info = new UserConsumer($leveler_id);
    if(!$leveler_info->isExist()){
        exit(HttpResponse::exitJSON(FALSE, "所查询的用户不存在~！",ClentCmd::POPUP_TO_LOGIN));
    }

    $referrer_id = $leveler_info->getOneFieldData("referrer");
    $referrer_info = new UserConsumer($referrer_id);
    if($referrer_info->isExist()){
        $R->referrer_name = $referrer_info->getOneFieldData("name");
    }else{
        $R->referrer_name = "";
    }
    $referrerer_id = $referrer_info->getOneFieldData("referrer");
    if($referrerer_id != $user_id){
        exit(HttpResponse::exitJSON(FALSE, "当前帐号没有权限查询此用户的数据~！",ClentCmd::POPUP_TO_LOGIN));
    }

    $list = $leveler_info->getSubMember($page, $count);
    if(is_array($list) && !empty($list)){
        $lists = $leveler_info->getCountMyGroup($leveler_id);
        if(empty($lists)){
            $R->underling_count = 0;
        }else{
            $R->underling_count = count($lists);
        }
    }else{
        $list = array();
        $R->underling_count = 0;
    }
    $R->user_id = $leveler_id;
    $R->underling_income = $leveler_info->getOneFieldData("total_award");
    $R->underling_list = $list;
}
exit(HttpResponse::exitJSON(TRUE, "查询数据成功~！",ClentCmd::POPUP_TO_LOGIN,$R));

