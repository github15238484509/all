<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/24
 * Time: 17:12
 */

use HoloPHP\tools\HttpResponse;
use HoloPHP\AutoLoader;
use jiupian\api\model\ModelUserCashChange;
use jiupian\api\model\types\UserCashChange;
use jiupian\api\model\ModelUserBonusChange;
use jiupian\api\model\types\BonusChange;
use jiupian\api\model\UserConsumer;
use HoloPHP\tools\Verify;
use jiupian\api\model\types\UserLevel;
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
Verify::existsingAll("token","amount","phone");
$R = new \stdClass();
$amount = $_REQUEST['amount'];
$phone = $_REQUEST['phone'];
//判断当前用户级别
if($userInfo->getOneFieldData('rank') < UserLevel::VIPUSER){
    exit(HttpResponse::exitJSON(false, "您没有权限转赠余额~！", "hint"));
}
if($amount <= 0){
    exit(HttpResponse::exitJSON(false, "转出余额只能是大于0的整数~！", "hint"));
}
if($amount % 100 !=0){
    exit(HttpResponse::exitJSON(false, "转出余额只能是整数~！", "hint"));
}
//用户可转出余额
if($amount > $userInfo->getOneFieldData('cash')){
    exit(HttpResponse::exitJSON(false, "可转出余额不足~！", "hint"));
}
$CashChange = new ModelUserCashChange();
$BonusChange = new ModelUserBonusChange();
$CashChange->stopAutocommit();
//添加转出积分余额
$phoneUser = new UserConsumer(null,null,$phone);
if(!$phoneUser->isExist()){
    $CashChange->rollback();
    exit(HttpResponse::exitJSON(false, "手机号不存在~！", "hint"));
}
if($phoneUser->getOneFieldData('user_id') == $user_id){
    $CashChange->rollback();
    exit(HttpResponse::exitJSON(false, "不能转赠给自己~！", "hint"));
}
$old_cash =  $phoneUser->getOneFieldData('cash');
$new_cash = $old_cash + $amount;
$res1 = $phoneUser->updateFields('cash',$new_cash);
//添加用户余额
$before = $userInfo->getCash();
$after = $before - $amount;
$res2 = $userInfo->deductCash($amount);

$res3 = $CashChange->addDeal($user_id, $before, $after, $amount, UserCashChange::TYPE_CASH_TO_USER, 0, 0, 0, 0, $time = 0, $phoneUser->getOneFieldData('user_id'));
$res4 = $CashChange->addDeal( $phoneUser->getOneFieldData('user_id'), $old_cash, $new_cash, $amount, UserCashChange::TYPE_CASH_TO_CASH, 0, 0, 0, 0, $time = 0,$user_id);
if($res1 && $res2 && $res3 && $res4){
    $CashChange->commit();
    exit(HttpResponse::exitJSON(true, "转赠余额成功~！", "hint"));
}else{
    $CashChange->rollback();
    exit(HttpResponse::exitJSON(false, "转赠余额失败~！", "hint"));
}