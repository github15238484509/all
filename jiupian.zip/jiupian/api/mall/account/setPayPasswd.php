<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/4/23
 * Time: 19:02
 */
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use config\ClentCmd;
use HoloPHP\tools\SMS;
use HoloPHP\AutoLoader;
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
Verify::existsingAll("phone", "pay_password");
if (! SMS::verifyPass($_REQUEST["phone"])) {
    exit(HttpResponse::exitJSON(false, "安全验证超时~！", ClentCmd::HINT));
}
$res = $userInfo->setPayPwd(substr($_REQUEST["pay_password"], 0, 16));
if ($res) {
    exit(HttpResponse::exitJSON(true, "支付密码设置成功~！", ClentCmd::HINT));
} else {
    exit(HttpResponse::exitJSON(false, "支付密码设置失败~！", ClentCmd::HINT));
}







