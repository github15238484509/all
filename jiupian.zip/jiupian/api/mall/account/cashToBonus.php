<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/23
 * Time: 20:33
 */
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use HoloPHP\AutoLoader;
use jiupian\api\model\ModelUserCashChange;
use jiupian\api\model\types\UserCashChange;
use jiupian\api\model\ModelUserBonusChange;
use jiupian\api\model\types\BonusChange;
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
Verify::existsingAll("token","amount");
$R = new \stdClass();
$amount = $_REQUEST['amount'];
if($amount <= 0){
    exit(HttpResponse::exitJSON(false, "转出余额只能是大于0的整数~！", "hint"));
}
if($amount < 0){
    exit(HttpResponse::exitJSON(false, "转出余额只能是整数~！", "hint"));
}
if($amount % 100 !=0){
    exit(HttpResponse::exitJSON(false, "转出余额只能是整数~！", "hint"));
}
//用户可转出余额
if($amount > $userInfo->getOneFieldData('cash')){
    exit(HttpResponse::exitJSON(false, "可转出余额不足~！", "hint"));
}
$CashChange = new ModelUserCashChange();
$BonusChange = new ModelUserBonusChange();
$CashChange->stopAutocommit();
//添加转出积分余额
$old_cash =  $userInfo->getOneFieldData('cash');
$new_cash = $old_cash - $amount;
$res1 = $userInfo->updateFields('cash',$new_cash);
//添加用户余额
$before = $userInfo->getBonus();
$after = $before + $amount;
$res2 = $userInfo->addBonus($amount);
$res3 = $CashChange->addDeal($user_id, $old_cash, $new_cash, $amount, UserCashChange::TYPE_CASH_TO_BONUS, 0, 0, 0, 0, $time = 0,$link_user="");
$res4 = $BonusChange->addDeal($user_id, $before, $after, $amount, BonusChange::TYPE_BOUNS_TO_CASH,0, 0, 0, 0, 0, $time = 0,$link_user="");
if($res1 && $res2 && $res3 && $res4){
    $CashChange->commit();
    exit(HttpResponse::exitJSON(true, "转出到积分成功~！", "hint"));
}else{
    $CashChange->rollback();
    exit(HttpResponse::exitJSON(false, "转出到积分失败~！", "hint"));
}