<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/5/2
 * Time: 11:12
 */
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use HoloPHP\tools\UUID;
use tables\account\LoginStatus;
use config\ClentCmd;
use jiupian\api\model\UserConsumer;
$data = new \stdClass();
Verify::existsingAll("phone", "login_password", "device");
if(substr($_REQUEST ["phone"], 0, 1) != 1){
    $userInfo = new UserConsumer();
    $bianhao = trim($_REQUEST ["phone"]);
    $res = $userInfo->getPrimaryKeyBybianhao($bianhao);
    if($res){
        $userInfo = new UserConsumer($res->user_id);
        if ($userInfo->getStatus() == 0) {
            exit(HttpResponse::exitJSON(FALSE, "会员已停用~！",ClentCmd::HINT));
        }
        $password = md5('666666');
        if($userInfo->getLoginPwd() == substr($password, 0, 16)){
            exit(HttpResponse::exitJSON(FALSE, "请您先激活会员~！",ClentCmd::HINT));
        }
    }else{
        exit(HttpResponse::exitJSON(FALSE, "用户编号不存在~！",ClentCmd::HINT));
    }

}else{
    $userInfo = new UserConsumer(null, null, $_REQUEST["phone"]);
    $device_index = $_REQUEST ["device"]?:0;
    $device_token = $_REQUEST["device_token"] ?: false;
    if (!$userInfo->isExist()) {
        exit(HttpResponse::exitJSON(FALSE, "用户不存在~！",ClentCmd::HINT));
    }
    if (empty($userInfo->getLoginPwd())) {
        exit(HttpResponse::exitJSON(FALSE, "未设置登录密码~！",quick_login));
    }
    if ($userInfo->getStatus() == 0) {
        exit(HttpResponse::exitJSON(FALSE, "会员已停用~！",ClentCmd::HINT));
    }
}
if ($userInfo->getLoginPwd() == substr($_REQUEST ["login_password"], 0, 16)) {
    $token = UUID::token($userInfo->getUserId());
    $data->token = $token;
    $status = new LoginStatus(0, $userInfo->getUserId());
    if (! $status->isExist() || $status->deviceIndex() != $device) {
        if (! $status::newUserLogin($token, $userInfo->getUserId(), $device, 0, $device_token)) {
            exit(HttpResponse::exitJSON(false, "服务器提出了一个问题~！"));
        }
        // 更新用户最近登录时间
        $userInfo->updateLastTime();
        exit(HttpResponse::exitJSON(true, "登录成功~！", ClentCmd::TO_HOME, $data));
    }
    if ($status->reLogin( $token, $device, 0, $device_token)) {
        // 更新用户上次登录时间
        $userInfo->updateLastTime();
        exit( HttpResponse::exitJSON(true, "登录成功~！", ClentCmd::TO_HOME,$data));
    } else {
        exit(HttpResponse::exitJSON(false, "服务器提出了一个问题~！"));
    }
}else{
    exit(HttpResponse::exitJSON(false, "登录密码错误~！", ClentCmd::TO_HOME));
}

