<?php
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use HoloPHP\tools\ImageCode;
use HoloPHP\tools\SMS;
use HoloPHP\server\Server;
use jiupian\api\model\UserConsumer;
if (!Verify::existsingAll("phone", "verify_type")) {
    exit(HttpResponse::exitJSON(false, "缺少请求参数~！", "hint"));
}
if(Server::environment("prod")){
    $phone = trim($_REQUEST["phone"]);
    if ($_REQUEST["image_code"] && ImageCode::verifyCode($_REQUEST["image_code"])) {
        exit(HttpResponse::exitJSON(false, "图片验证码不正确~！", "hint"));
    }
    if ($_REQUEST["verify_type"] == 1) {
        $user = new UserConsumer(null, null, $phone);
        if ($user->isExist()) {
            exit(HttpResponse::exitJSON(FALSE, "此手机号已注册~！", "popup_to_login"));
        }
        $res = SMS::register($_REQUEST["phone"], Server::getPlatform());
    } elseif ($_REQUEST["verify_type"] == 2) {
        $user = new UserConsumer(null, null, $phone);
        if (!$user->isExist()) {
            exit(HttpResponse::exitJSON(FALSE, "此手机号未注册~！", "to_register"));
        }
        $res = SMS::login($_REQUEST["phone"], Server::getPlatform());
    } elseif ($_REQUEST["verify_type"] == 3) {
        $res = SMS::setPayPwd($_REQUEST["phone"], Server::getPlatform());
    }elseif ($_REQUEST["verify_type"] == 4){
        $res = SMS::resetPhone($_REQUEST["phone"], Server::getPlatform());
    }elseif ($_REQUEST["verify_type"] == 5){
        $res = SMS::activitePhone($_REQUEST["phone"], Server::getPlatform());
    }elseif ($_REQUEST["verify_type"] == 7){
        $user = new UserConsumer(null, null, $phone);
        if (!$user->isExist()) {
            exit(HttpResponse::exitJSON(FALSE, "此手机号未注册~！", "to_register"));
        }
        $res = SMS::setLoginPwd($_REQUEST["phone"], Server::getPlatform());
    }
    if ($res) {
        exit(HttpResponse::exitJSON(true, "短信验证码已下发，请注意查收~！", "hint"));
    } else {
        exit(HttpResponse::exitJSON(false, "短信验证码下发失败，请重新获取~！", "hint"));
    }
}else{
    exit(HttpResponse::exitJSON(true, "短信验证码已下发，请注意查收~！", "hint"));
}
?>