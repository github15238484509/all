<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/5/2
 * Time: 14:04
 */
namespace jiupian\api\mall;
use tables\account\LoginStatus;
use HoloPHP\tools\HttpResponse;
use HoloPHP\AutoLoader;
use jiupian\api\model\ModelLoginLogs;
use jiupian\api\model\ModelFunctions;
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
$token = $_REQUEST["token"];
$status = new LoginStatus();
if ($status->quitLogin($user_id,$token)) {
    //添加记录
    $loginLos = new ModelLoginLogs();
    $functions = new ModelFunctions();
    $ip = $functions->get_client_ip();
    $loginLos->addChangeLog($user_id,$ip,0,1);
    exit(HttpResponse::exitJSON(true, "退出成功~！", "hint"));
} else {
    exit(HttpResponse::exitJSON(false, "退出失败~！", "hint"));
}