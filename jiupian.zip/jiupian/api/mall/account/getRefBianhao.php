<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/8/29
 * Time: 15:28
 */
use jiupian\api\model\UserConsumer;
use HoloPHP\tools\HttpResponse;
use HoloPHP\tools\Verify;
Verify::existsingAll("bianhao");
$bianhao = $_REQUEST["bianhao"];
//判断会员编号是否存在
$userInfo = new UserConsumer();
$res = $userInfo->getPrimaryKeyBybianhao($bianhao);
if(!$res){
    exit(HttpResponse::exitJSON(FALSE, "编号不存在~！", "to_register"));
}else{
    unset($res->user_id);
    unset($res->phone);
    exit(HttpResponse::exitJSON(TRUE, "推荐编号获取成功~！", "to_register",$res));
}