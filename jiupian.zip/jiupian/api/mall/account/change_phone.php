<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/4/27
 * Time: 9:57
 */
namespace jiupian\api\mall;
use jiupian\api\model\UserConsumer;
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use tables\account\ModelUserPhoneChange;
use HoloPHP\AutoLoader;
require_once AutoLoader::autoPath('/api/mall/verify/verifyPhoneCode.php');
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
$R = new \stdClass ();
Verify::existsingAll("phone", "device", "token","phone_code");
$new_phone = $_REQUEST['phone'];
$old_phone=$userInfo->getUserPhone();
if ( $new_phone == $old_phone) {
    exit(HttpResponse::exitJSON(false, "新旧手机号不能相同~！", "hint"));
}
$user=new UserConsumer(null,null,$new_phone);
if ( $user->isExist() ) {
    exit(HttpResponse::exitJSON(false, "手机号已经存在~！", "hint"));
}
if ( !$userInfo->updatePhone($new_phone, $user_id) ) {
    exit(HttpResponse::exitJSON(false, "服务器异常，请稍后重试~！", "hint"));
}
$userchange=new ModelUserPhoneChange();
if(getenv('HTTP_CLIENT_IP')) {
    $ip = getenv('HTTP_CLIENT_IP');
} elseif(getenv('HTTP_X_FORWARDED_FOR')) {
    $ip = getenv('HTTP_X_FORWARDED_FOR');
} elseif(getenv('REMOTE_ADDR')) {
    $ip = getenv('REMOTE_ADDR');
} else {
    $ip = $HTTP_SERVER_VARS['REMOTE_ADDR'];
}
$userchange->addChangePhoneLog($user_id, $old_phone, $_REQUEST ["phone"], $ip);
exit(HttpResponse::exitJSON(true, "手机号更改成功~！", "hint"));


