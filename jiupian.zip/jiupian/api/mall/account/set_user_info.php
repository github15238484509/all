<?php
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use HoloPHP\AutoLoader;
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
if (! Verify::existsingAll("user_info")) {
    exit(HttpResponse::exitJSON(false, "缺少请求参数~！", "hint"));
}
if ($userInfo->setUserInfo(json_decode($_REQUEST["user_info"],true)) && $userInfo->updateVersion()) {
    exit(HttpResponse::exitJSON(true, "更新资料成功~！", "hint"));
}
exit(HttpResponse::exitJSON(false, "更新资料失败~！", "hint"));
?>