<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/8/29
 * Time: 14:32
 */
use jiupian\api\model\UserConsumer;
use HoloPHP\tools\HttpResponse;
use HoloPHP\tools\UUID;
use tables\account\LoginStatus;
use config\ClentCmd;
use HoloPHP\AutoLoader;
use HoloPHP\tools\Verify;
use HoloPHP\tools\Array2Object;
Verify::existsingAll("bianhao","password",'login_password');
$phone = $_REQUEST["phone"];
$bianhao = $_REQUEST["bianhao"];
$password = $_REQUEST["password"];
$device =  $_REQUEST["device"]?:0;
$userInfo = new UserConsumer();
$res = $userInfo->getPrimaryKeyBybianhao($bianhao);
 if(!$res){
     exit(HttpResponse::exitJSON(FALSE, "编号不存在~！", "to_register"));
 }
 $user = new UserConsumer($res->user_id);
if ($user->getLoginPwd() == substr($password, 0, 16)) {
    //1.判断会员编号是否存在
 /*   $res = $userInfo->getPrimaryKeyBybianhao($bianhao);
    if(!$res){
        exit(HttpResponse::exitJSON(FALSE, "编号不存在~！", "to_register"));
    }*/

    //2.更新用户登录密码
    $user->stopAutocommit();
    $login_password = $_REQUEST['login_password'];
    $login_password = substr( $login_password, 0, 16);
    $update_phone = $user->setLoginPwd($login_password);
    if(!$update_phone){
        $user->rollback();
    }
   //2.登录
    $token = UUID::token($res->user_id);
    $status = new LoginStatus($token);
    if ($status->isExist()) {
        if (! $status->reLogin($token, $device)) {
            $user->rollback();
            $data = [
            ];
            exit(HttpResponse::exitJSON(FALSE, "插入登录数据失败2~！",ClentCmd::HINT,$data));
        }
    } else {
        if (! LoginStatus::newUserLogin($token, $res->user_id, $device)) {
            $user->rollback();
            $data = [
            ];
            exit(HttpResponse::exitJSON(FALSE, "插入登录数据失败3~！",ClentCmd::HINT,$data));
        }
    }
    $user->commit();
    $data = array(
        "token" => $token,
        "cash" => 0,
        "rank" => 0,
        "login_pwd_status" => 0,
        "pay_pwd_status" => 0,
        "card_status" => 0,
        "bank_status" => 0,
        "merchant_status" => 0,
        "agent_status" => 0
    );
    $data = Array2Object::array2object($data);
    exit(HttpResponse::exitJSON(TRUE, "恭喜~！激活账号成功", ClentCmd::TO_MY, $data));
}else{
    $pass = md5('666666');
    if( substr($pass, 0, 16) == substr($password, 0, 16)){
        exit(HttpResponse::exitJSON(FALSE, "请勿重复激活~！", "to_register"));
    }else{
        exit(HttpResponse::exitJSON(FALSE, "默认密码输入错误~！", "to_register"));
    }

}