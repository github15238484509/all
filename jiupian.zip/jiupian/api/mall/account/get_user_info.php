<?php
use HoloPHP\tools\HttpResponse;
use config\ClentCmd;
use HoloPHP\AutoLoader;
use jiupian\api\model\types\UserLevel;
use jiupian\api\model\ModelUserBonusChange;
use tables\account\ModelUserBankCard;
use jiupian\api\model\ModelUpGradeRules;
use jiupian\api\model\MallGoodOrder;
use jiupian\api\model\MallGoodOrderGoods;
use jiupian\api\model\MallGood;
use tables\account\ModelUserRankChange;
use tables\model\ModelFunctions;
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
$R = new \stdClass();
$R->userinfo = $userInfo->getUserInfo();
$R->userinfo->rank_name = UserLevel::RANK_MAP[$R->userinfo->rank];
$R->userinfo->is_apply = 0;//申请素膳之家
$card_model = new ModelUserBankCard();
$info = $card_model->getCardByMerchant($user_id);
if (! $info) {
    $R->userinfo->bank_status = 0;
} else {
    $R->userinfo->bank_status = 1;
}
$bonus_change = new ModelUserBonusChange();
$R->userinfo->total_get_bonus = $bonus_change->getTotalincome($user_id)->total_bounus_count?:0;
// 银行卡状态
//会员升级状态
$upGradeRules = new ModelUpGradeRules();
$rules = $upGradeRules->getNewRules();

if($R->userinfo->rank  ==  UserLevel::VIPUSER){
    $res = $userInfo->getAllusersByRankv2($user_id,UserLevel::VIPUSER);
    if($res >= $rules->new_vip_to_super){
        $rankChange = new ModelUserRankChange();
        $funtions = new ModelFunctions();
        $ip = $funtions->get_client_ip();
        $res_log = $rankChange->addChangeLog($userInfo->getOneFieldData("user_id"), $R->userinfo->rank, UserLevel::SUPREUSER, $ip,1,0);
        $userInfo->updateFields("rank",UserLevel::SUPREUSER);
        $R->userinfo->rank = UserLevel::SUPREUSER;
    }
}elseif($R->userinfo->rank  ==  UserLevel::SUPREUSER){
    $res = $userInfo->getAllusersByRankv2($user_id,UserLevel::SUPREUSER);
    if(($res[1]+$res[0]) >= $rules->new_super_to_partner && $res[0] >= $rules->supre_to_partner_direct ){
        $rankChange = new ModelUserRankChange();
        $funtions = new ModelFunctions();
        $ip = $funtions->get_client_ip();
        $res_log = $rankChange->addChangeLog($userInfo->getOneFieldData("user_id"), $R->userinfo->rank, UserLevel::PARTNERUSER, $ip,1,0);
        $userInfo->updateFields("rank",UserLevel::PARTNERUSER);
        $R->userinfo->rank = UserLevel::PARTNERUSER;
    }
}elseif($R->userinfo->rank  ==  UserLevel::PARTNERUSER){
    $res = $userInfo->getAllusersByRankv2($user_id,UserLevel::PARTNERUSER);
    if(($res[1]+$res[0]) >= $rules->partner_to_home && $res[0] >=  $rules->partner_to_home_direct){
        $R->userinfo->is_apply = 1;

        $rankChange = new ModelUserRankChange();
        $funtions = new ModelFunctions();
        $ip = $funtions->get_client_ip();
        $res_log = $rankChange->addChangeLog($userInfo->getOneFieldData("user_id"), $R->userinfo->rank, UserLevel::SUSHANPARTNER, $ip,1,0);
        $userInfo->updateFields("rank",UserLevel::SUSHANPARTNER);
        $R->userinfo->rank = UserLevel::SUSHANPARTNER;
    }
}elseif($R->userinfo->rank  ==  UserLevel::SUSHANPARTNER){
    $res = $userInfo->getAllusersByRankv2($user_id,UserLevel::SUSHANPARTNER);
    if(($res[1]+$res[0]) >= $rules->home_to_center && $res[0] >= $rules->home_to_center_direct){
        $rankChange = new ModelUserRankChange();
        $funtions = new ModelFunctions();
        $ip = $funtions->get_client_ip();
        $res_log = $rankChange->addChangeLog($userInfo->getOneFieldData("user_id"), $R->userinfo->rank, UserLevel::OPERATIONPARTNER, $ip,1,0);
        $userInfo->updateFields("rank",UserLevel::OPERATIONPARTNER);
        $userInfo->updateFields("operation_id",1);
        $R->userinfo->rank = UserLevel::OPERATIONPARTNER;
    }
}
/*if($R->userinfo->rank  ==  UserLevel::VIPUSER){
    $res = $userInfo->getAllusersByRank($user_id,UserLevel::VIPUSER);
    if($res >= $rules->vip_to_super){
        $rankChange = new ModelUserRankChange();
        $funtions = new ModelFunctions();
        $ip = $funtions->get_client_ip();
        $res_log = $rankChange->addChangeLog($userInfo->getOneFieldData("user_id"), $R->userinfo->rank, UserLevel::SUPREUSER, $ip,1,0);
        $userInfo->updateFields("rank",UserLevel::SUPREUSER);
        $R->userinfo->rank = UserLevel::SUPREUSER;
    }
}elseif($R->userinfo->rank  ==  UserLevel::SUPREUSER){
    $res = $userInfo->getAllusersByRank($user_id,UserLevel::SUPREUSER);
    if($res >= $rules->super_to_partner){
        $rankChange = new ModelUserRankChange();
        $funtions = new ModelFunctions();
        $ip = $funtions->get_client_ip();
        $res_log = $rankChange->addChangeLog($userInfo->getOneFieldData("user_id"), $R->userinfo->rank, UserLevel::PARTNERUSER, $ip,1,0);
        $userInfo->updateFields("rank",UserLevel::PARTNERUSER);
        $R->userinfo->rank = UserLevel::PARTNERUSER;
    }
}elseif($R->userinfo->rank  ==  UserLevel::PARTNERUSER){
    $res = $userInfo->getAllusersByRank($user_id,UserLevel::PARTNERUSER);
    if($res[0] >= $rules->partner_to_merchant || $res[1] >= $rules->ref_partner_to_merchant){
        $R->userinfo->is_apply = 1;
    }
}*/

//判断用户是否购买过素膳礼包
$order = new MallGoodOrder();
$where = " order_consumer = $user_id and order_status>= 2";
$allOrders = $order->getAllOrders($where,"order_index");
if($allOrders){
    $mallOrderGoods = new MallGoodOrderGoods();
    foreach($allOrders as $key => $val){
        $goods_list = $mallOrderGoods->findOrderGoodsByOrder($val->order_index);
        foreach($goods_list as $key=>$val){
            $mallgoods = new MallGood($val->goods_index);
            $online_area = $mallgoods->getFieldsValue("online_area");
            if($online_area == UserLevel::SUSHANHOMEGOODS){
                $R->userinfo->is_apply = 1;
            }
        }
    }
}
//获取数据库是否有资格申请素膳之家
$apply_merchant = $userInfo->getOneFieldData("apply_merchant");
if($apply_merchant == 0 && $R->userinfo->is_apply == 1){
   //更新数据库
    $userInfo->updateFields("apply_merchant",1);
}
if($apply_merchant == 1 && $R->userinfo->is_apply == 0){
    $R->userinfo->is_apply = 1;
}
if($R->userinfo->rank >= UserLevel::VIPUSER){
    $R->userinfo->give = 1;
}else{
    $R->userinfo->give = 0;
}
if($userInfo->getOneFieldData('rank') == UserLevel::OPERATIONPARTNER){
    $R->userinfo->operation_sum = 1;
}else{
    $R->userinfo->operation_sum = 0;
}
exit(HttpResponse::exitJSON(true, "获取用户基础资料成功~！", ClentCmd::HINT, $R));
