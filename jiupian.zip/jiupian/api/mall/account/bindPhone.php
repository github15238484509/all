<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/6
 * Time: 11:06
 */
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use HoloPHP\AutoLoader;
use config\ClentCmd;
use jiupian\api\model\UserConsumer;
use jiupian\api\model\ModelFunctions;
Verify::existsingAll('phone');
$phone = trim($_REQUEST['phone']);
$functions = new ModelFunctions();
$verify_res = $functions->checkPhone($phone);
if(!$verify_res){
    exit(HttpResponse::exitJSON(FALSE, "请输入正确的手机号~！", ClentCmd::HINT));
}
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
require_once AutoLoader::autoPath('/api/mall/verify/verifyPhoneCode.php');
$user_phone = $userInfo->getPhone();
if($user_phone) {
    exit(HttpResponse::exitJSON(FALSE, "您已经绑定过手机号，请勿重复绑定~！", ClentCmd::HINT));
}
$users = new UserConsumer(null,null,$phone);
if($users->isExist()){
    exit(HttpResponse::exitJSON(FALSE, "此手机号已经绑定，请更换手机号~！", ClentCmd::HINT));
}
$res = $userInfo->updateFields('phone',$phone);
if($res){
    exit(HttpResponse::exitJSON(TRUE, "绑定手机号成功~！", ClentCmd::HINT));
}else{
    exit(HttpResponse::exitJSON(FALSE, "绑定手机号失败~！", ClentCmd::HINT));
}




