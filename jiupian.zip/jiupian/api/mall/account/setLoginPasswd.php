<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/4/23
 * Time: 19:02
 */
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use config\ClentCmd;
use HoloPHP\AutoLoader;
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
require_once AutoLoader::autoPath('/api/mall/verify/verifyPhoneCode.php');
Verify::existsingAll("login_password");
$res =$userInfo->setLoginPwd( substr ( $_REQUEST ["login_password"], 0, 16 ) );
if ($res) {
    exit(HttpResponse::exitJSON(true, "登录密码设置成功~！", ClentCmd::HINT));
} else {
    exit(HttpResponse::exitJSON(false, "登录密码设置失败~！", ClentCmd::HINT));
}







