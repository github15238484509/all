<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/8/29
 * Time: 14:32
 */
use jiupian\api\model\UserConsumer;
use HoloPHP\tools\HttpResponse;
use HoloPHP\tools\UUID;
use tables\account\LoginStatus;
use config\ClentCmd;
use HoloPHP\AutoLoader;
use HoloPHP\tools\Verify;
use HoloPHP\tools\Array2Object;
require_once AutoLoader::autoPath('/api/mall/verify/verifyPhoneCode.php');
Verify::existsingAll("phone","bianhao","password");
$phone = $_REQUEST["phone"];
$bianhao = $_REQUEST["bianhao"];
$password = $_REQUEST["password"];
$device =  $_REQUEST["device"]?:0;
$userInfo = new UserConsumer(null, null, $phone);
if($userInfo->isExist()){
    exit(HttpResponse::exitJSON(FALSE, "此手机号已经绑定过账号~！", "to_register"));
}
$res = $userInfo->getPrimaryKeyBybianhao($bianhao);
 if(!$res){
     exit(HttpResponse::exitJSON(FALSE, "编号不存在~！", "to_register"));
 }
 $user = new UserConsumer($res->user_id);
if ($user->getLoginPwd() == substr($password, 0, 16)) {
    //1.判断会员编号是否存在
 /*   $res = $userInfo->getPrimaryKeyBybianhao($bianhao);
    if(!$res){
        exit(HttpResponse::exitJSON(FALSE, "编号不存在~！", "to_register"));
    }*/
    if(!empty($res->phone)){
        exit(HttpResponse::exitJSON(FALSE, "编号已经绑定过手机号，请勿重复绑定~！", "to_register"));
    }
    //2.更新用户手机号
    $user->stopAutocommit();
    $update_phone = $user->updateFields("phone",$phone);
    if(!$update_phone){
        $user->rollback();
    }
   //2.登录
    $token = UUID::token($res->user_id);
    $status = new LoginStatus($token);
    if ($status->isExist()) {
        if (! $status->reLogin($token, $device)) {
            $user->rollback();
            $data = [
                "sql" => $user->getDB()->latelySQL(),
                "sql_error" => $user->getDB()->latelyError()
            ];
            exit(HttpResponse::exitJSON(FALSE, "插入登录数据失败2~！",ClentCmd::HINT,$data));
        }
    } else {
        if (! LoginStatus::newUserLogin($token, $res->user_id, $device)) {
            $user->rollback();
            $data = [
                "sql" => $user->getDB()->latelySQL(),
                "sql_error" => $user->getDB()->latelyError()
            ];
            exit(HttpResponse::exitJSON(FALSE, "插入登录数据失败3~！",ClentCmd::HINT,$data));
        }
    }
    $user->commit();
    $data = array(
        "token" => $token,
        "cash" => 0,
        "rank" => 0,
        "login_pwd_status" => 0,
        "pay_pwd_status" => 0,
        "card_status" => 0,
        "bank_status" => 0,
        "merchant_status" => 0,
        "agent_status" => 0
    );
    $data = Array2Object::array2object($data);
    exit(HttpResponse::exitJSON(TRUE, "恭喜~！激活手机号成功", ClentCmd::TO_MY, $data));
}else{
    exit(HttpResponse::exitJSON(FALSE, "密码输入错误~！", "to_register"));
}