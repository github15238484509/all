<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/7/19
 * Time: 10:05
 */
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use jiupian\api\model\UserConsumer;
// 检测手机号是否已经注册过会员
Verify::existsingAll("phone");
$user = new UserConsumer(null, null, $_REQUEST["phone"]);
if ($user->isExist()) {
    exit(HttpResponse::exitJSON(FALSE, "此手机号已注册~！", "popup_to_login"));
}
exit(HttpResponse::exitJSON(true, "此帐号未注册~！", "register"));
?>