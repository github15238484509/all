<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/8/14
 * Time: 15:08
 */
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use HoloPHP\AutoLoader;
use config\ClentCmd;
use jiupian\api\model\ModelUserBonusChange;
use jiupian\api\model\types\BonusChange;
use HoloPHP\tools\UUID;
use jiupian\api\model\ModelUserExtractBonus;
use jiupian\api\model\types\UserLevel;
use jiupian\api\model\ModelFunctions;
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
Verify::existsingAll("token","bonus_count","extract_url");
$R = new \stdClass();
$bonus_count = $_REQUEST["bonus_count"];
$extract_url = $_REQUEST["extract_url"];
$user_rank = $userInfo->getOneFieldData("rank");
$functions = new ModelFunctions();
$res = $functions->checkPhone($userInfo->getPhone());
if(!$res){
    exit(HttpResponse::exitJSON(FALSE, "请您去个人中心绑定手机号~！", ClentCmd::HINT));
}
if($user_rank < UserLevel::VIPUSER){
    exit(HttpResponse::exitJSON(FALSE, "普通会员暂时不能提取~！", ClentCmd::HINT));
}
if($bonus_count == 0){
    exit(HttpResponse::exitJSON(FALSE, "益豆的数量不能为0~！", ClentCmd::HINT));
}
if($bonus_count % 100 != 0 ){
    exit(HttpResponse::exitJSON(FALSE, "提取数量必须为整数~！", ClentCmd::HINT));
}
$user_bonus = $userInfo->getOneFieldData("bonus");
if($user_bonus < $bonus_count){
    exit(HttpResponse::exitJSON(FALSE, "益豆数量不足~！", ClentCmd::HINT));
}
//扣掉用户益豆
$bonusChange = new ModelUserBonusChange();
$bonusChange->stopAutocommit();
$before_bonus = $userInfo->getBonus();
$after_bonus = $before_bonus - $bonus_count;
$res1 = $userInfo->deductBonus($bonus_count);
if(!$res1){
    $bonusChange->rollback();
    exit(HttpResponse::exitJSON(FALSE, "网络异常，请稍后再试~！", ClentCmd::HINT));
}
//增加提取记录
$order = UUID::order_id();
$res3 = $bonusChange->addDeal($user_id, $before_bonus, $after_bonus, $bonus_count,BonusChange::TYPE_EXTRACT_DEDUCT ,0, 0, $order, 0, 0, $time = 0,$link_user="");
if(!$res3){
    $bonusChange->rollback();
    exit(HttpResponse::exitJSON(FALSE, "网络异常，请稍后再试~！", ClentCmd::HINT));
}
//增加用户累计提取的益豆
$res2 = $userInfo->addExtractBonus($bonus_count);
if(!$res2){
    $bonusChange->rollback();
    exit(HttpResponse::exitJSON(FALSE, "网络异常，请稍后再试~！", ClentCmd::HINT));
}
//插入提取记录
$extractBonus = new ModelUserExtractBonus();
$res4 = $extractBonus->addDeal($order,$user_id,$before_bonus,$after_bonus,$bonus_count,0,$extract_url);
if(!$res4){
    $bonusChange->rollback();
    exit(HttpResponse::exitJSON(FALSE, "网络异常，请稍后再试~！", ClentCmd::HINT));
}
$bonusChange->commit();
exit(HttpResponse::exitJSON(TRUE, "提取到钱包成功~！", ClentCmd::HINT));