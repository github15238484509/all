<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/7/25
 * Time: 18:59
 */
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use HoloPHP\AutoLoader;
use config\ClentCmd;
use jiupian\api\model\ModelCurrenciesChange;
use jiupian\api\model\ModelCurrencies;
require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
Verify::existsingAll("token");
$R = new \stdClass();
$currencies = new ModelCurrenciesChange();
$list = $currencies->getUserRecord($user_id);
if(!$list){
    $currencies = new ModelCurrencies();
    $list = $currencies->getGoodsListByWhere(" currencies_status  = 1 ", $sort = "", $fields = " currencies_name,currencies_index");
    foreach($list as $key=>$val){
        $list[$key]->currencies_count = 0;
        $list[$key]->currencies_type = $val->currencies_index;
        unset($val->currencies_index);
    }
}
$R->list = $list;
exit(HttpResponse::exitJSON(true, "获取记录成功~！", ClentCmd::HINT, $R));
