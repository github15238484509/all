<?php
use jiupian\api\model\UserConsumer;
use HoloPHP\tools\HttpResponse;
use HoloPHP\tools\UUID;
use tables\account\ModelUserBankCard;
use tables\account\LoginStatus;
use tables\offline\EntityStores;
use tables\offline\UserAgency;
use config\ClentCmd;
use tables\account\Card;
use HoloPHP\AutoLoader;
use HoloPHP\wechat\WeChatInfo;
use HoloPHP\tools\HttpRequest;
use jiupian\api\model\ModelFunctions;
use jiupian\api\model\ModelLoginLogs;
require_once AutoLoader::autoPath('/api/mall/verify/verifyPhoneCode.php');
$userInfo = new UserConsumer(null, null, $_REQUEST["phone"]);
$device = $_REQUEST["device"]?:0;
$device_token = $_REQUEST["device_token"] ?: false;
$openid = $_REQUEST["openid"];
if (! $userInfo->isExist()) {
    exit(HttpResponse::exitJSON(false, "此手机号尚未注册~！", ClentCmd::POPUP_TO_REGISTER));
}
if ($userInfo->getStatus() == 0) { // 被合并账户已经停用
    exit(HttpResponse::exitJSON(false, "此帐号已停用，无法登录~！", ClentCmd::POPUP_TO_REGISTER));
}

$token = UUID::token($userInfo->getUserId());
$data = $userInfo->getBaseStatus();
$data->token = $token;
$status = new LoginStatus(0, $userInfo->getUserId());
if (! $status->isExist() || $status->deviceIndex() != $device) {
    if (! $status::newUserLogin($token, $userInfo->getUserId(), $device, 0, $device_token)) {
        exit(HttpResponse::exitJSON(false, "服务器提出了一个问题~！"));
    }
    // 更新用户最近登录时间
    $userInfo->updateLastTime();
    $loginLos = new ModelLoginLogs();
    $functions = new ModelFunctions();
    $ip = $functions->get_client_ip();
    $loginLos->addChangeLog($userInfo->getUserId(),$ip,0,0);

    $user_openid =  $userInfo->getOneFieldData('wechat_openid');
    if(!$user_openid){
        $userInfo->updateFields("wechat_openid",$openid);
    }
    exit(HttpResponse::exitJSON(true, "登录成功~！", ClentCmd::TO_HOME, $data));
}
if ($status->reLogin($token, $device, 0, $device_token)) {
    // 更新用户上次登录时间
    $userInfo->updateLastTime();
    $loginLos = new ModelLoginLogs();
    $functions = new ModelFunctions();
    $ip = $functions->get_client_ip();
    $loginLos->addChangeLog($userInfo->getUserId(),$ip,0,0);

    $user_openid =  $userInfo->getOneFieldData('wechat_openid');
    if(!$user_openid){
        $userInfo->updateFields("wechat_openid",$openid);
    }
   exit( HttpResponse::exitJSON(true, "登录成功~！", ClentCmd::TO_HOME,$data));
} else {
    exit(HttpResponse::exitJSON(false, "服务器提出了一个问题~！"));
}

?>