<?php
set_time_limit(10);
use HoloPHP\tools\HttpResponse;
use config\ClentCmd;
use HoloPHP\AutoLoader;
use jiupian\api\model\types\UserLevel;
use jiupian\api\model\ModelUserBonusChange;
use tables\account\ModelUserBankCard;
use jiupian\api\model\ModelUpGradeRules;
use jiupian\api\model\MallGoodOrder;
use jiupian\api\model\MallGoodOrderGoods;
use jiupian\api\model\MallGood;
use tables\account\ModelUserRankChange;
use tables\model\ModelFunctions;
use jiupian\api\model\UserConsumer;

$user_model = new UserConsumer();
$sql = "select rank,user_id from user_consumer";
$users = $user_model->getDB()->readArray($sql);


if($users){
    foreach ($users as $k=>$v){
        $user_id = $v->user_id;
//    var_dump($user_id,$users);die;

        $userInfo = new UserConsumer($user_id);
        $R = new \stdClass();
        $R->userinfo = $userInfo->getUserInfo();
        $R->userinfo->rank_name = UserLevel::RANK_MAP[$R->userinfo->rank];
        $R->userinfo->is_apply = 0;//申请素膳之家
        $card_model = new ModelUserBankCard();
        $info = $card_model->getCardByMerchant($user_id);
        if (! $info) {
            $R->userinfo->bank_status = 0;
        } else {
            $R->userinfo->bank_status = 1;
        }
        $bonus_change = new ModelUserBonusChange();
        $R->userinfo->total_get_bonus = $bonus_change->getTotalincome($user_id)->total_bounus_count?:0;
        // 银行卡状态
        //会员升级状态
        $upGradeRules = new ModelUpGradeRules();
        $rules = $upGradeRules->getNewRules();

        if($R->userinfo->rank  ==  UserLevel::VIPUSER){
            $res = $userInfo->getAllusersByRankv2($user_id,UserLevel::VIPUSER);
            if($res >= $rules->new_vip_to_super){
                $rankChange = new ModelUserRankChange();
                $funtions = new ModelFunctions();
                $ip = $funtions->get_client_ip();
                $res_log = $rankChange->addChangeLog($userInfo->getOneFieldData("user_id"), $R->userinfo->rank, UserLevel::SUPREUSER, $ip,1,0);
                $userInfo->updateFields("rank",UserLevel::SUPREUSER);
                $R->userinfo->rank = UserLevel::SUPREUSER;
            }
        }elseif($R->userinfo->rank  ==  UserLevel::SUPREUSER){
            $res = $userInfo->getAllusersByRankv2($user_id,UserLevel::SUPREUSER);
            if(($res[1]+$res[0]) >= $rules->new_super_to_partner && $res[0] >= $rules->supre_to_partner_direct ){
                $rankChange = new ModelUserRankChange();
                $funtions = new ModelFunctions();
                $ip = $funtions->get_client_ip();
                $res_log = $rankChange->addChangeLog($userInfo->getOneFieldData("user_id"), $R->userinfo->rank, UserLevel::PARTNERUSER, $ip,1,0);
                $userInfo->updateFields("rank",UserLevel::PARTNERUSER);
                $R->userinfo->rank = UserLevel::PARTNERUSER;
            }
        }elseif($R->userinfo->rank  ==  UserLevel::PARTNERUSER){
            $res = $userInfo->getAllusersByRankv2($user_id,UserLevel::PARTNERUSER);
            if(($res[1]+$res[0]) >= $rules->partner_to_home && $res[0] >=  $rules->partner_to_home_direct){
                $R->userinfo->is_apply = 1;

                $rankChange = new ModelUserRankChange();
                $funtions = new ModelFunctions();
                $ip = $funtions->get_client_ip();
                $res_log = $rankChange->addChangeLog($userInfo->getOneFieldData("user_id"), $R->userinfo->rank, UserLevel::SUSHANPARTNER, $ip,1,0);
                $userInfo->updateFields("rank",UserLevel::SUSHANPARTNER);
                $R->userinfo->rank = UserLevel::SUSHANPARTNER;
            }
        }elseif($R->userinfo->rank  ==  UserLevel::SUSHANPARTNER){
            $res = $userInfo->getAllusersByRankv2($user_id,UserLevel::SUSHANPARTNER);
            if(($res[1]+$res[0]) >= $rules->home_to_center && $res[0] >= $rules->home_to_center_direct){
                $rankChange = new ModelUserRankChange();
                $funtions = new ModelFunctions();
                $ip = $funtions->get_client_ip();
                $res_log = $rankChange->addChangeLog($userInfo->getOneFieldData("user_id"), $R->userinfo->rank, UserLevel::OPERATIONPARTNER, $ip,1,0);
                $userInfo->updateFields("rank",UserLevel::OPERATIONPARTNER);
                $userInfo->updateFields("operation_id",1);
                $R->userinfo->rank = UserLevel::OPERATIONPARTNER;
            }
        }
    }
    exit('执行升级');
}else{
    exit('没有操作的用户');
}



