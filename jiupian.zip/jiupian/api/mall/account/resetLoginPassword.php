<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/4/24
 * Time: 9:15
 */

use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use config\ClentCmd;
use HoloPHP\AutoLoader;
use jiupian\api\model\UserConsumer;
Verify::existsingAll("new_login_password",'type');
require_once AutoLoader::autoPath('/api/mall/verify/verifyPhoneCode.php');
$type = $_REQUEST['type'];
if($type == 0){
    $userInfo = new UserConsumer(null,null,$_REQUEST['phone']);
    if(!$userInfo->isExist()){
        exit(HttpResponse::exitJSON(false, "您还未注册用户~！", ClentCmd::HINT));
    }
    $res =$userInfo->setLoginPwd( substr ( $_REQUEST ["new_login_password"], 0, 16 ) );
    if ($res) {
        exit(HttpResponse::exitJSON(true, "重置登录密码设置成功~！", ClentCmd::HINT));
    } else {
        exit(HttpResponse::exitJSON(false, "重置登录密码设置失败~！", ClentCmd::HINT));
    }
}else{
    require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
    $res =$userInfo->setLoginPwd( substr ( $_REQUEST ["new_login_password"], 0, 16 ) );
    if ($res) {
        exit(HttpResponse::exitJSON(true, "重置登录密码设置成功~！", ClentCmd::HINT));
    } else {
        exit(HttpResponse::exitJSON(false, "重置登录密码设置失败~！", ClentCmd::HINT));
    }
}
?>