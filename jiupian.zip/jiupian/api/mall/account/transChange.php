<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/7/5
 * Time: 14:01
 */
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/5/8
 * Time: 12:18
 */
use HoloPHP\tools\Verify;
use jiupian\api\model\ModelTransferOffline;
use HoloPHP\tools\HttpResponse;
use config\ClentCmd;
use jiupian\api\model\types\TransferOffline;
use HoloPHP\AutoLoader;
require_once AutoLoader::autoPath('/api/account/verify/verify_token.php');
Verify::existsingAll("token","page");
$R = new \stdClass();
$page = $_REQUEST["page"];
$count = 20;
$start = $page*$count;
$trans = new ModelTransferOffline();
$list = $trans->getCardList($user_id,$start,$count);
if(!$list){
    $list = array();
}else{
    foreach($list as $key=>$val){
        $val->type_msg = TransferOffline::STATUS_MAP[$val->trans_status];
        unset($val->user_id);
        unset($val->remark);
        //unset($val->trans_name);
        unset($val->trans_card);
        unset($val->trans_bank);
        unset($val->trans_voucher);
        unset($val->sub_time);
        unset($val->reason);
        unset($val->trans_type);
        unset($val->trans_vouchar);
    }
}
$R->list = $list;
exit(HttpResponse::exitJSON(TRUE, "获取充值记录成功~！", ClentCmd::HINT,$R));

