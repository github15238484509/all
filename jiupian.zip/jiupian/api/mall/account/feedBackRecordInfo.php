<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/7/25
 * Time: 15:34
 */
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use config\ClentCmd;
use jiupian\api\model\UserFeedback;
use HoloPHP\AutoLoader;
use jewelry\api\model\VerifyToken;
$R = new \stdClass ();
Verify::existsingAll ("feedback_index");
$feedback_index = $_REQUEST['feedback_index'];
$feed = new UserFeedback ($feedback_index);
if(!$feed->isExist()){
    exit(HttpResponse::exitJSON(FALSE, "获取详情失败~！", ClentCmd::HINT));
}else{
    $R->feedback_content = $feed->getOneValue("feedback_content");
    $R->feedback_answer = $feed->getOneValue("feedback_answer")?:"暂无回复";
    $R->feedback_addtime = $feed->getOneValue("feedback_addtime");
    $R->feedback_handle_time = $feed->getOneValue("feedback_handle_time");
    exit(HttpResponse::exitJSON(true, "获取详情成功~！", ClentCmd::HINT,$R));
}