<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/4/26
 * Time: 11:03
 */
use HoloPHP\tools\Verify;
use HoloPHP\tools\HttpResponse;
use config\ClentCmd;
use jiupian\api\model\UserFeedback;
use HoloPHP\AutoLoader;
use jiupian\api\model\VerifyToken;
use jiupian\api\model\ModelFunctions;
$res = VerifyToken::checkToken($_REQUEST["token"]);
if($res){
    require_once AutoLoader::autoPath('/api/mall/verify/verify_token.php');
    $R = new \stdClass ();
    Verify::existsingAll ( "type", "content","phone");
    $feed = new UserFeedback ();
    $phone = $userInfo->getPhone();
    $content = $_REQUEST["content"];
    $functions = new ModelFunctions();
    $content = $functions->filterString($content);
    $id = $feed->insertFeedback (0, $user_id, urldecode ( $_REQUEST ["type"] ), urldecode ( $content ),$phone,0 );
    if ($id) {
        exit(HttpResponse::exitJSON(TRUE, "提交成功~！", ClentCmd::HINT));
    } else {
        exit(HttpResponse::exitJSON(FALSE, "提交失败~！", ClentCmd::HINT));
    }
}else{
    $R = new \stdClass ();
    Verify::existsingAll ( "type", "content","phone");
    $feed = new UserFeedback ();
    $phone = $_REQUEST['phone'];
    $content = $_REQUEST["content"];
    $functions = new ModelFunctions();
    $res = $functions->checkPhone($phone);
    if(!$res){
        exit(HttpResponse::exitJSON(false, "手机号码错误~！", ClentCmd::HINT));
    }
    $content = $functions->filterString($content);
    $id = $feed->insertFeedback (0, 0, urldecode ( $_REQUEST ["type"] ), urldecode ( $content ),$phone,0 );
    if ($id) {
        exit(HttpResponse::exitJSON(TRUE, "提交成功~！", ClentCmd::HINT));
    } else {
        exit(HttpResponse::exitJSON(FALSE, "提交失败~！", ClentCmd::HINT));
    }
}

