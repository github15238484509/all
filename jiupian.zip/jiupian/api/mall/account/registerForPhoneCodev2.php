<?php
use HoloPHP\tools\HttpResponse;
use jiupian\api\model\UserConsumer;
use HoloPHP\tools\UUID;
use tables\account\LoginStatus;
use HoloPHP\tools\Array2Object;
use config\ClentCmd;
use HoloPHP\AutoLoader;
use jiupian\api\model\types\SystemUser;
use HoloPHP\wechat\WeChatInfo;
use HoloPHP\tools\HttpRequest;
use HoloPHP\server\Log;
use jiupian\api\model\ModelFunctions;
use HoloPHP\tools\SMS;
use HoloPHP\server\Server;
use jiupian\api\model\types\WechatNotice;
use HoloPHP\wechat\tools\TemplateMsg;
use HoloPHP\tools\Verify;
Verify::existsingAll("login_password");
$pwd = trim($_REQUEST['login_password']);
require_once AutoLoader::autoPath('/api/mall/verify/verifyPhoneCode.php');
require_once AutoLoader::autoPath('/api/mall/verify/verifyPhoneExist.php');
if(trim($_REQUEST['referrer_phone']) == trim($_REQUEST["phone"])){
    exit(HttpResponse::exitJSON(FALSE, "注册手机号和邀请手机号不能相同~！",ClentCmd::HINT));
}
$wechat_openid = $_REQUEST["wechat_openid"];
if(isset($_REQUEST["wechat_openid"]) && $wechat_openid && $wechat_openid != '""'){
    $wechat_openid = $_REQUEST["wechat_openid"];
    $wechat = new WeChatInfo();
    $accessToken = $wechat->accessToken();
    $url = "https://api.weixin.qq.com/cgi-bin/user/info?access_token=$accessToken&openid=$wechat_openid&lang=zh_CN";
    $res = HttpRequest::http_get($url);
    if(!$res){
        //用户默认头像
        $photo_image = "jiupian/logo.png";
        //用户默认昵称是手机号
        $name = "暂无昵称";
    }else{
        $res = json_decode($res,true);
        if($res["errcode"]){
            //用户默认头像
            $photo_image = "jiupian/logo.png";
            //用户默认昵称是手机号
            $name = "暂无昵称";
        }else{
            $functions = new ModelFunctions();
            $name =  $functions->filterString($res["nickname"]);
            if(empty($name)){
                $name =  "暂无昵称";
            }
            $photo_image = $res["headimgurl"];
            if(empty($photo_image)){
                $photo_image = "jiupian/logo.png";
            }
        }
    }
}else{
    $wechat_openid = "";
    //用户默认头像
    $photo_image = "jiupian/logo.png";
    //用户默认昵称是手机号
    $name = "暂无昵称";
}
$user = new UserConsumer(null, null, $_REQUEST['referrer_phone']);
$referrer_user_id = SystemUser::SYSTEM_REFERRER;
$is_leader = 0;
if ($user->isExist()) {
    $referrer_user_id = $user->getUserId();
}else{
    exit(HttpResponse::exitJSON(FALSE, "健康使者未注册账号~！",ClentCmd::HINT,$data));
}
//获取t邀请人id
$referrerInfo = new UserConsumer($referrer_user_id);
if($referrerInfo->getOneFieldData('rank') <= 0){
    exit(HttpResponse::exitJSON(FALSE, "健康使者暂没有邀请资格~！",ClentCmd::HINT,$data));
}
$leader_id = $referrerInfo->getOneFieldData("leader_id");
//用户默认头像
//$photo_image = "jiupian/logo.png";
//用户默认昵称是手机号
//$name = $_REQUEST["phone"];
//生成user_id
$user_id = UUID::user_id(); // 生成user_id
$device = $_REQUEST["device"] ?: 0;
$user->stopAutocommit();
if (! $user->regNewUserv2($_REQUEST["phone"], $user_id, $device, $referrer_user_id, $pwd,$wechat_openid,$leader_id,$is_leader,$photo_image,$name)) {
    $user->rollback();
    $data = [
        "sql" => $user->getDB()->latelySQL(),
        "sql_error" => $user->getDB()->latelyError()
    ];
    exit(HttpResponse::exitJSON(FALSE, "插入注册数据失败1~！",ClentCmd::HINT,$data));
}
$token = UUID::token($user_id);
$status = new LoginStatus($token);
if ($status->isExist()) {
    if (! $status->reLogin($token, $device)) {
        $user->rollback();
        $data = [

        ];
        exit(HttpResponse::exitJSON(FALSE, "插入登录数据失败2~！",ClentCmd::HINT,$data));
    }
} else {
    if (! LoginStatus::newUserLogin($token, $user_id, $device)) {
        $user->rollback();
        $data = [
            "sql" => $user->getDB()->latelySQL(),
            "sql_error" => $user->getDB()->latelyError()
        ];
        exit(HttpResponse::exitJSON(FALSE, "插入登录数据失败3~！",ClentCmd::HINT,$data));
    }
}
$user->commit();
//第三方注册
/*$ref_url = 'http://test.i1170.com/trade/v1/api.php?c=user/get_ref&appid=20180824201809051115&jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJhcHBpZCI6IjIwMTgwODI0MjAxODA5MDUxMTE1In0.BOKNh-Tb-PQ3tlj0xSroWhm2IPDmuZI0cZBFeLNPqOk&phone='. $_REQUEST['referrer_phone'];
$res = HttpRequest::http_get($ref_url);
$result = json_decode($res,true);
if($result["code"] == 1){
    $phone = $_REQUEST["phone"];
    $third_ref_user_id = $result['data']['user_id'];
    $reg_url = "http://test.i1170.com/trade/v1/api.php?c=user/create&appid=20180824201809051115&jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJhcHBpZCI6IjIwMTgwODI0MjAxODA5MDUxMTE1In0.BOKNh-Tb-PQ3tlj0xSroWhm2IPDmuZI0cZBFeLNPqOk&name=".$name."&phone=".$phone."&third_uid=".$user_id."&third_ref_uid=".$third_ref_user_id;
    $res1 = HttpRequest::http_get($reg_url);
    $result1 = json_decode($res1,true);
    if($result1["code"] == 1){
        $user1 = new UserConsumer(null, null, $phone);
        $user1->updateFields("third_uid",$result1['data']['user_id']);
    }
}*/
//微信通知
/*$ref_wechat_openid = $user->getOneFieldData("wechat_openid");
if($ref_wechat_openid){
    $title = '有人通过您的邀请，并成功注册';
    $user_name = $name;
    $user_phone = $_REQUEST["phone"];
    $template_id = WechatNotice::WECHAT_MAP[0];
    TemplateMsg::remindUser($title,$ref_wechat_openid, $template_id,$user_name, $user_phone,$link_url=null);
}*/
$data = array(
    "token" => $token,
    "cash" => 0,
    "rank" => 0,
    "login_pwd_status" => 0,
    "pay_pwd_status" => 0,
    "card_status" => 0,
    "bank_status" => 0,
    "merchant_status" => 0,
    "agent_status" => 0
);
//SMS::notify($_REQUEST["phone"],Server::getPlatform());
$data = Array2Object::array2object($data);
exit(HttpResponse::exitJSON(true, "恭喜~！注册成功", ClentCmd::TO_MY, $data));
