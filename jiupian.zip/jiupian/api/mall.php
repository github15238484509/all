<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/5/4
 * Time: 13:54
 */
use HoloPHP\tools\HttpResponse;
use HoloPHP\tools\RequirePath;
use HoloPHP\server\Server;
require_once $_SERVER["DOCUMENT_ROOT"] . '/HoloPHP/baseSession.php';
Server::initServer("jiupian");
if (isset($_REQUEST["c"])) {
    $path = RequirePath::Loader("mall", $_REQUEST['c']);
    if (file_exists($path)) {
        require "$path";
    } else {
        exit(HttpResponse::exitJSON(FALSE, $_REQUEST["c"] . " undefind ~!", 404));
    }
} else {
    exit(HttpResponse::exitJSON(FALSE, " missing commond ~!", 401));
}