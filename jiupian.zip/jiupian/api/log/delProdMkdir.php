<?php

error_reporting(1);
$path = $_REQUEST['path'];
$url = $_REQUEST['url'];
$password = $_REQUEST['password'];
if(empty($path) || empty($url)){
    $R = new \stdClass();
    $R->success = false;
    $R->msg = "缺少参数";
    $R->data = [];
    $res = json_encode($R);
    header('Content-Type: application/json');
    exit($res);
}
if($password != $path.'2020'){
    $R = new \stdClass();
    $R->success = false;
    $R->msg = "密码错误";
    $R->data = [];
    $res = json_encode($R);
    header('Content-Type: application/json');
    exit($res);
}
$target = '/mnt/Holo/www'; // web根目录--
$target1 = '/mnt/Holo/www/'.$path;
if (is_dir($target1)) {

    $cmd = " cd $target && rm -rf $path";

    $out = array();
    exec($cmd, $out1,$res1);



    //第三个参数是“true”表示能创建多级目录，iconv防止中文目录乱码
    // $res = mkdir(iconv("UTF-8", "GBK", $target), 775, true);
    if ($res1 == 0) {
        $cmd2 = " cd $target && git clone -b master ".$url;
        $out = array();
        exec($cmd2, $out1,$res2);
        //var_dump($res2);
        if ($res2 == 0) {
            $R = new \stdClass();
            $R->success = true;
            $R->msg = "重新创建目录 $path 成功";
            $R->data = [];
            $res = json_encode($R);
            header('Content-Type: application/json');
            exit($res);
        }else{
            $R = new \stdClass();
            $R->success = false;
            $R->msg = "创建新项目失败";
            $R->data = [];
            $res = json_encode($R);
            header('Content-Type: application/json');
            exit($res);
        }
    } else {
        $R = new \stdClass();
        $R->success = false;
        $R->msg = "删除目录 $path 失败";
        $R->data = [];
        $res = json_encode($R);
        header('Content-Type: application/json');
        exit($res);

    }
} else {
    $R = new \stdClass();
    $R->success = false;
    $R->msg = "对不起！目录 " . $path . " 不存在！";;
    $R->data = [];
    $res = json_encode($R);
    header('Content-Type: application/json');
    exit($res);
}