<?php
error_reporting(1);
$path = $_REQUEST['path'];
$target = '/mnt/Holo/webroot/test/'.$path; // web根目录--

if (is_dir($target)){
    $R = new \stdClass();
    $R->success = false;
    $R->msg = "对不起！目录 " . $path . " 已经存在！";;
    $R->data = [];
    $res = json_encode($R);
    header('Content-Type: application/json');
    exit($res);
}else{
    //第三个参数是“true”表示能创建多级目录，iconv防止中文目录乱码
    $res=mkdir(iconv("UTF-8", "GBK", $target),0775,true);
    if ($res){
        $R = new \stdClass();
        $R->success = true;
        $R->msg = "目录 $path 创建成功";
        $R->data = [];
        $res = json_encode($R);
        header('Content-Type: application/json');
        exit($res);
    }else{
        $R = new \stdClass();
        $R->success = false;
        $R->msg =  "目录 $path 创建失败";
        $R->data = [];
        $res = json_encode($R);
        header('Content-Type: application/json');
        exit($res);

    }
}