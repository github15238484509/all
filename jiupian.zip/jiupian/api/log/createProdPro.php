<?php
error_reporting(1);
$url = $_REQUEST['url'];
$target = '/mnt/Holo/www'; // web根目录--
$cmd = " cd $target && git clone -b master ".$url;
$out = array();
exec($cmd, $out1,$res1);
if($res1 == 0){
    $R = new \stdClass();
    $R->success = true;
    $R->msg = "创建项目success";
    $R->data = [];
    $res = json_encode($R);
    header('Content-Type: application/json');
    exit($res);
}else{
    $R = new \stdClass();
    $R->success = false;
    $R->msg = "创建项目fail";
    $R->data = [];
    $res = json_encode($R);
    header('Content-Type: application/json');
    exit($res);
}
