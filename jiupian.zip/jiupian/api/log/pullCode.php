<?php

error_reporting(1);
$project = $_REQUEST['project'];
$target = '/mnt/Holo/webroot/test/'.$project; // web根目录--
$cmd = " cd $target && git pull origin test " ;
$out = array();
exec($cmd, $out1, $res1);
if ($res1 == 0) {
    $R = new \stdClass();
    $R->success = true;
    $R->msg = "拉取代码success";
    $R->data = [];
    $res = json_encode($R);
    header('Content-Type: application/json');
    exit($res);
} else {
    $R = new \stdClass();
    $R->success = false;
    $R->msg = "拉取代码fail";
    $R->data = [];
    $res = json_encode($R);
    header('Content-Type: application/json');
    exit($res);
}
