<?php
include_once '../share.php';
include_once '../templ/head.php';
?>
<body class="mui-ios mui-ios-11 mui-ios-11-0">
<link rel="stylesheet" href="../js/mui-picker/mui.picker.min.css">
<header class="mui-bar mui-bar-nav">
    <a class="mui-action-back mui-icon mui-icon-arrowthinleft mui-pull-left"></a>
    <h1 class="mui-title fsz-large">更换手机号</h1>
</header>
<div class="mui-content div-data">
    <form id="setPhoneFirst" class="mui-input-group form-data">
        <div class="mui-input-row data-one">
            <label>新手机号</label>
            <input id="newPhone" type="text" placeholder="请输入手机号码">
        </div>
        <div class="mui-button-row register-btn-box">
            <button id="btn_next" type="button" class="mui-btn register-btn mui-btn-main mui-btn-block btnMall">下一步
            </button>
        </div>
    </form>

    <form id="setPhoneSecond" class="mui-input-group form-data" style="display:none">
        <div style="color:#009C33;font-size:13px;text-align:center;padding:10px 0;">短信验证码已发送，请填写验证码</div>
        <div class="mui-input-row data-one">
            <label>手机号</label>
            <input id="getNewPhone" type="text" disabled="disabled">
        </div>
        <div class="mui-input-row data-one">
            <label>验证码</label>
            <input id="getPhoneCodes" type="text" placeholder="请输入验证码">
        </div>
        <div class="mui-button-row register-btn-box">
            <button id="btn_submit" type="button" class="mui-btn register-btn mui-btn-main mui-btn-block btnMall">确认
            </button>
        </div>
    </form>

    <script src="../js/require.js"></script>
    <script src="../js/require.config.js"></script>
    <script>
        require(['mui', 'jquery', 'ajax'], function (Mui, $, Ajax) {

            var loginToken = getCookie("jiupian_token");
            var newPhone = "";
            var getPhoneCodes = "";

            $("#btn_next").click(function () {
                newPhone = $("#newPhone").val();
                if (newPhone === "" || newPhone.length < 11) {
                    return Mui.toast("请输入正确的手机号");
                }
                getPhoneCode();
            });

            function getPhoneCode() {
                Ajax.appAjax({
                    url: baseUrl + 'jiupian/api/mall.php', // 请求地址,
                    // url: DOMAIN_URL + 'mall.php', // 请求地址,
                    needLogin: false,
                    data: {
                        c: 'applyPhoneCode',
                        p: "jiupian",
                        phone: newPhone,
                        verify_type: "4"
                    },
                    success: function (e) {
                        console.log(e);
                        if (e.success) {
                            setTimeout(function () {
                                $("#setPhoneFirst").css("display", "none");
                                $("#setPhoneSecond").css("display", "block");
                                $("#getNewPhone").val(newPhone);
                                $("#btn_submit").click(function () {
                                    getPhoneCodes = $("#getPhoneCodes").val();
                                    if (getPhoneCodes === "") {
                                        return Mui.toast("请输入验证码");
                                    }
                                    submitPhone();
                                })
                            }, 500)
                        } else {
                            Mui.toast(e.msg);
                        }
                    },
                    error: function (e) {
                        console.log(e);
                    }
                });
            }

            function submitPhone(params) {
                Ajax.appAjax({
                    url: baseUrl + 'jiupian/api/mall.php', // 请求地址,
                    // url: DOMAIN_URL + 'mall.php', // 请求地址,
                    needLogin: false,
                    data: {
                        c: 'change_phone',
                        token: loginToken,
                        p: "jiupian",
                        phone: newPhone,
                        phone_code: getPhoneCodes,
                        device: 0
                    },
                    success: function (e) {
                        console.log(e);
                        if (e.success) {
                            window.location.href = "/jiupian/account/success.php";
                        } else {
                            Mui.toast(e.msg);
                        }
                    },
                    error: function (e) {
                        console.log(e);
                    }
                });

            }


            shareObj(getStringByConfig("share_title"), baseUrl + projectName + '/login/register.php?sing=' + getCache("_phone"), IMG_CDN + getStringByConfig("logo"), getStringByConfig("share_subtitle"));

        })
    </script>
</div>
</body>
</html>
