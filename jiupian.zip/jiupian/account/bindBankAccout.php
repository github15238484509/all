<?php
include_once '../share.php';
include_once '../templ/head.php';
?>
<body class="mui-ios mui-ios-11 mui-ios-11-0">
<link rel="stylesheet" href="../js/mui-picker/mui.picker.min.css">
<header class="mui-bar mui-bar-nav">
    <a href="/jiupian/member.php" class="mui-icon mui-icon-arrowthinleft mui-pull-left"></a>
    <h1 class="mui-title fsz-large">绑定银行卡</h1>
</header>
<div class="mui-content bind-bank-account">
    <!--    <div class="mui-input-row data-one" style="margin: 5px 0;">-->
    <!--        <label style="width: 40%;text-align: right">银行卡开户名：</label>-->
    <!--        <input id="bindName" type="text" placeholder="请输入银行卡开户名" style="width: 60%;">-->
    <!--    </div>-->
    <!--    <div class="mui-input-row data-one" style="margin: 5px 0;">-->
    <!--        <label style="width: 40%;text-align: right">银行卡号：</label>-->
    <!--        <input id="cardNumber" type="text" placeholder="请输入银行卡号" style="width: 60%;">-->
    <!--    </div>-->
    <!--    <div class="mui-input-row data-one" style="margin: 5px 0;">-->
    <!--        <label style="width: 40%;text-align: right">再次输入卡号：</label>-->
    <!--        <input id="cardNumbers" type="text" placeholder="请再次输入银行卡号" style="width: 60%;">-->
    <!--    </div>-->
    <!--    <div class="mui-input-row data-one" style="margin: 5px 0;">-->
    <!--        <label style="width: 40%;text-align: right">请选择开户银行：</label>-->
    <!--        <div class="mui-input-row J_picker-show" style="display: inline-block;width: 60%;line-height: 40px">-->
    <!--            <span id="bankName" class="bank">请选择开户银行</span>-->
    <!--            <input type="hidden" id="bankCode">-->
    <!--            <span class="picker-btn"><span class="mui-icon mui-icon-arrowdown"></span></span>-->
    <!--        </div>-->
    <!--    </div>-->
    <form class="mui-input-group">
        <div class="mui-input-row">
            <input id="bindName" type="text" placeholder="请输入银行卡开户名">
        </div>
        <div class="mui-input-row">
            <input id="cardNumber" type="text" placeholder="请输入银行卡号">
        </div>
        <div class="mui-input-row">
            <input id="cardNumbers" type="text" placeholder="请再次输入银行卡号">
        </div>
        <div class="mui-input-row J_picker-show">
            <span id="bankName" class="bank">请选择开户银行</span>
            <input type="hidden" id="bankCode">
            <span class="picker-btn"><span class="mui-icon mui-icon-arrowdown"></span></span>
        </div>
    </form>
    <div class="mui-button-row register-btn-box">
        <button id="btn_bank" type="button" class="mui-btn register-btn mui-btn-main mui-btn-block"
                style="border: 1px solid #009C33 !important;background: #009C33 !important;border-radius: 25px !important;">
            确定
        </button>
    </div>

    <script src="../js/require.js"></script>
    <script src="../js/require.config.js"></script>
    <script src="../js/libs/app.js"></script>

    <script>
        require(['mui', 'verify', 'ajax', 'picker'], function (Mui, Verify, Ajax) {
            mui.init();

            var userPicker = new mui.PopPicker();
            var $bindName = $("#bindName");
            var $cardNumber = $("#cardNumber");
            var $bankName = $("#bankName");
            if (getPValue("backName") != "") {
                $("#bindName").val(getPValue("backName"));
                $("#cardNumber").val(getPValue("backNumber"));
                $("#cardNumbers").val(getPValue("backNumber"));
                $("#bankName").text(getPValue("cardBank"));
            }

            $("#btn_bank").click(function () {
                if (!Verify.checkForm($bindName, Verify.CardHolderName) || !Verify.checkForm($cardNumber, Verify.BankCardNum)) {
                    return false;
                }
                if ($("#cardNumber").val() !== $("#cardNumbers").val()) {
                    return Mui.toast("两次银行卡号输入不一致");
                }

                if ($bankName.text() === "请选择开户银行") {
                    return Mui.toast("请选择开户银行!")
                }
                Ajax.appAjax({
                    url: baseUrl + 'jiupian/api/mall.php', // 请求地址,
                    // url: DOMAIN_URL + 'mall.php', // 请求地址,
                    needLogin: false,
                    data: {
                        c: "submitBankCard",
                        card_holder: $bindName.val(),
                        card_number: $cardNumber.val(),
                        card_bank: $bankName.text()
                    },
                    success: function (e) {
                        if (e.success) {
                            return thisConfirm("添加成功", "提示", ["取消", "确定"], function () {
                                setCache("_bank_status", "1");
                                window.history.back();
                            }, function () {
                                setCache("_bank_status", "1");
                                window.history.back();
                            });
                        } else {
                            Mui.toast(e.msg);
                        }
                    },
                    error: function (e) {
                        Mui.toast(e.msg);
                    }
                })
            });

            Ajax.appAjax({
                url: baseUrl + 'jiupian/api/mall.php', // 请求地址,
                // url: DOMAIN_URL + 'mall.php', // 请求地址,
                needLogin: false,
                data: {
                    c: "getBankList"
                },
                success: function (e) {
                    console.log(e);
                    if (e.success) {
                        userPicker.setData(e.data);
                    } else {
                        Mui.toast(e.msg);
                    }
                },
                error: function (e) {
                    Mui.toast(e.msg);
                }
            });
            mui('.mui-content').on('tap', '.J_picker-show', function (e) {
                userPicker.show(function (item) {
                    $('#bankCode').val(item[0]['value']);
                    $('#bankName').text(item[0]['text']);
                })
            });
            shareObj(getStringByConfig("share_title"), baseUrl + projectName + '/login/register.php?sing=' + getCache("_phone"), IMG_CDN + getStringByConfig("logo"), getStringByConfig("share_subtitle"));

        })
    </script>
</div>
</body>
</html>
