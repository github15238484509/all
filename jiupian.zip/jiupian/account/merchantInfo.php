<?php
include_once '../share.php';
require_once './../templ/head.php';

use HoloPHP\AutoLoader;

include_once AutoLoader::autoPath("/wechat/jsSign.php");
?>
<link rel="stylesheet" href="../css/swiper.min.css">
<body class="mui-ios mui-ios-11 mui-ios-11-0">
<header class="mui-bar mui-bar-nav">
    <a href="/jiupian/index.php" class="mui-action-back mui-icon mui-icon-arrowthinleft mui-pull-left"></a>
    <h1 class="mui-title fsz-large">门店</h1>
</header>
<div class="mui-content">
    <div id="slider_height" class="swiper-container" style="padding: 15px;">
        <div id="slider_parent" class="swiper-wrapper"></div>
    </div>
    <div class="pm10"></div>
    <div id="merchant_name" class="fontfa10 font18 color22" style="padding:0 0 10px 15px;font-weight: 600;"></div>
    <div class="fontfa10 font13 color99" style="padding:0 0 10px 15px;">营业时间：<span id="merchant_worktime"></span>
    </div>
    <div class="pm10"></div>
    <div class="positionR" style="height: 35px;">
        <img class="positionA" src="../image/jiupian/daohang.png" alt="" style="width: 30px;top: 0;left: 15px;">
        <div id="merchant_address" class="positionA color22 font13"
             style="top:0; left: 50px;right: 10px;bottom:0;word-wrap: break-word;font-family: 'FZLanTingKanHei-R-GBK'"></div>
    </div>
    <div class="pm10"></div>
    <a id="a_dadianhua" href="">
        <div class="positionR" style="height: 35px;">
            <img class="positionA" src="../image/jiupian/dianhua.png" alt="" style="width: 30px;top: 0;left: 15px;">
            <div id="merchant_tel" class="positionA color22 font13"
                 style="top:0; left: 50px;right: 10px;bottom:0;word-wrap: break-word;font-family: 'FZLanTingKanHei-R-GBK'"></div>
        </div>
    </a>
    <div class="pm10"></div>
    <div class="pm10 backf7"></div>
    <div style="padding: 15px;">
        <div class="fontfa10 color22 font18" style="font-weight: 600;padding-bottom: 5px;">商家简介</div>
        <div class="pm10"></div>
        <div id="merchant_desp" class="font13 color66" style="font-family: 'FZLanTingKanHei-R-GBK';"></div>
    </div>
    <div style="padding: 15px;">
        <div class="fontfa10 color22 font18" style="font-weight: 600;padding-bottom: 5px;">近期活动</div>
        <div class="pm10"></div>
        <div id="merchant_activite" class="font13 color66" style="font-family: 'FZLanTingKanHei-R-GBK';"></div>
    </div>

    <div class="page-bottom-btn-box relative mt-25" style="bottom: 15px !important;">
        <button id="btn_submit" type="button" class="mui-btn mui-btn-main mui-btn-block centerLR"
                style="border-radius: 25px;width: 80%;">导航到门店
        </button>
    </div>


</div>
<script src="../js/conf.js"></script>
<script src="../js/require.js"></script>
<script src="../js/require.config.js"></script>
<script src="../js/libs/app.js"></script>

<script>
    require(['mui', 'list', "ajax", 'swiper'], function (Mui, List, Ajax, Swiper) {

        Ajax.appAjax({
            url: baseUrl + 'jiupian/api/mall.php', // 请求地址,
            // url: DOMAIN_URL + 'mall.php', // 请求地址,
            needLogin: false,
            data: {
                c: 'merchantInfo',
                merchant_id: getPValue("merchant_id")
            },
            success: function (e) {
                console.log(e);
                if (e.success) {
                    getUserSlider(e.data.merchant_image);
                    $("#merchant_name").html(e.data.merchant_name);
                    $("#merchant_tel").html(e.data.merchant_tel);
                    $("#merchant_worktime").html(e.data.merchant_worktime);
                    $("#merchant_desp").html(e.data.merchant_desp);
                    $("#merchant_activite").html(e.data.merchant_activite);
                    $("#merchant_address").html(e.data.merchant_address);
                    $("#a_dadianhua").attr("href", "tel:" + e.data.merchant_tel);
                    //点击调用地图
                    $("#btn_submit").click(function () {

                        var WechatJsConfig = eval('(' + '<?php echo json_encode($wechatJsConfig);?>' + ')');
                        WechatJsConfig.jsApiList = ["openLocation"];
                        wx.config(WechatJsConfig);
                        wx.ready(function () {
                            var latitude;// 纬度
                            var longitude;// 经度
                            var speed;// 速度
                            var accuracy;// 位置精度
                            wx.openLocation({
                                latitude: Number(e.data.merchant_latitude), // 纬度，范围为90 ~ -90
                                longitude: Number(e.data.merchant_longitude), // 经度，范围为180 ~ -180。
                                name: e.data.merchant_name, // 位置名
                                address: e.data.merchant_address, // 地址详情说明
                                scale: 22, // 地图缩放级别,整形值,范围从1~28。默认为最大
                                infoUrl: '' // 在查看位置界面底部显示的超链接,可点击跳转
                            });
                        });
                    })
                } else {
                    Mui.toast(e.msg);
                }
            },
            error: function (e) {
                console.log(e);
            }
        });

        //商品轮播图
        function getUserSlider(data) {
            for (var i = 0; i < data.length; i++) {
                var dataI = data[i];
                var $add = $('<div class="swiper-slide" style="width: 80%;"><img src="' + IMG_CDN + dataI + '" style="width:100%" class="imgHeight"/></div>');
                $("#slider_parent").append($add);
            }

            $(".imgHeight").height($(".imgHeight").width() * 9 / 16);
            $("#slider_height").height($(".imgHeight").height());

            //设置轮播图参数
            var swiper = new Swiper('.swiper-container', {
                slidesPerView: 'auto',
                spaceBetween: 10,
                pagination: {
                    el: '.swiper-pagination',
                    clickable: true,
                },
            });
        }
        shareObj(getStringByConfig("share_title"), baseUrl + projectName + '/login/register.php?sing=' + getCache("_phone"), IMG_CDN + getStringByConfig("logo"), getStringByConfig("share_subtitle"));


    })
</script>
</body>