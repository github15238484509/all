<?php
include_once '../share.php';
include_once '../templ/head.php';
$address = array();
?>
<body class="mui-ios mui-ios-11 mui-ios-11-0">
<link rel="stylesheet" href="../js/mui-picker/mui.picker.min.css">
<header class="mui-bar mui-bar-nav">
    <span id="call_back" class="mui-icon mui-icon-arrowthinleft mui-pull-left"></span>
    <h1 class="mui-title fsz-large">收货地址</h1>
</header>
<div class="mui-content">
    <ul class="mui-table-view" id="addressList">
        <li class="padding10" style="padding-left: 20px;border-bottom: 1px solid #f7f7f7"></li>
    </ul>

    <div class="mui-button-row register-btn-box">
        <button id="addAddress" type="button" class="mui-btn register-btn mui-btn-main mui-btn-block centerLR"
                style="border: 1px solid #009C33;background:#009C33;border-radius: 25px;width: 70%;">添加收货地址
        </button>
    </div>
    <script src="../js/require.js"></script>
    <script src="../js/require.config.js"></script>
    <script>
        require(['mui', 'jquery', 'ajax', 'listener', 'picker', 'cityData'], function (Mui, $, Ajax, Listener) {
            mui.init();
            var loginToken = getCookie("jiupian_token");
            var froms = getPValue("from");
            userAddressList();
            var OrderListener = Listener.initOrderListener();

            $("#addAddress").click(function () {
                window.location.href = "editAddress.php?from=" + getPValue("from") + "&money=" + getPValue("money") + "&card_index=" + getPValue("card_index");
            });


            //获取地址列表
            function userAddressList() {
                Ajax.appAjax({
                    url: baseUrl + 'jiupian/api/mall.php', // 请求地址,
                    // url: DOMAIN_URL + 'mall.php', // 请求地址,
                    needLogin: false,
                    data: {
                        c: 'address/user_address_list',
                        token: loginToken,
                        device: 0
                    },
                    success: function (e) {
                        console.log(e);
                        if (e.success) {
                            getList(e.data.list);
                        } else {
                            Mui.toast(e.msg);
                        }
                    },
                    error: function (e) {
                        console.log(e);
                    }
                });
            }

            function getList(data) {
                for (var i = 0; i < data.length; i++) {
                    var dataI = data[i];
                    var $add = $('<li class="padding10" style="padding-left: 20px;border-bottom: 1px solid #f7f7f7">' +
                        '<div class="colorBA font15">' +
                        '<div class="fontfaW3 sure_address' + i + '" style="display: inline-block;width: 35%;">' + dataI.contacts + '</div>' +
                        '<div class="fontfalar sure_address' + i + '" style="display: inline-block">' + dataI.phone + '</div>' +
                        '</div>' +
                        '<div style="padding: 15px 0;">' +
                        '<table class="fullwidth">' +
                        '<tr>' +
                        '<td width="85%" class="goods_title sure_address' + i + '">' +
                        '<span id="goods_name">' + dataI.full_address + '</span>' +
                        '</td>' +
                        '<td width="1%">' +
                        '<div style="width: 1px;background: #e0e0e0;">&nbsp;</div>' +
                        '</td>' +
                        '<td class="get_bianji' + i + '" align="center" style="padding: 8px;"></td>' +
                        '</tr>' +
                        '</table>' +
                        '</div>' +
                        '<div class="colorBA font15" style="height: 25px;line-height: 25px;">' +
                        '<div class="fontfaW3 img_delete' + i + ' positionR" style="display: inline-block;width: 60%;"></div>' +
                        '<div class="fontfalar positionR is_address' + i + '" style="display: inline-block;">' +
                        '<div class="positionA color22 fontfaW3 font13" style="display: inline-block;height: 20px;top: -5px;left: 25px;width: 60px;">默认地址</div>' +
                        '</div>' +
                        '</div>' +
                        '</li>');
                    var $addBianji = $('<img src="../image/jiupian/bianji.png" style="width: 15px">');
                    if (dataI.default_address == "1") {
                        var $addDefultAddress = $('<img class="img_defult" src="../image/jiupian/addressyes.png" style="width: 15px;">');
                    } else {
                        var $addDefultAddress = $('<img class="img_defult" src="../image/jiupian/addressno.png" style="width: 15px;">');
                    }
                    var $addDelete = $('<img src="../image/jiupian/delete.png" style="width: 15px;">');
                    var $addZiTi = $('<div class="font12 positionA" style="display: inline-block;width:80px;margin-left: 20px;border: .5px solid #009C33;border-radius: 8px;text-align: center;left: 30px;top: -2px;height:20px;line-height: 20px;">自提地址</div>');
                    $("#addressList").append($add);
                    $(".get_bianji" + i).append($addBianji);
                    $(".is_address" + i).append($addDefultAddress);
                    $(".img_delete" + i).append($addDelete);
                    if( dataI.is_merchant_address == "1" ){
                        $(".img_delete" + i).append($addZiTi);
                    }

                    addTouchEdit($(".get_bianji" + i), dataI);
                    addTouchDefult($(".is_address" + i), dataI);
                    addTouchDelete($(".img_delete" + i), dataI);
                    asd($(".sure_address" + i), dataI);

                }

            }


            // function getList(data) {
            //     for (var i = 0; i < data.length; i++) {
            //         $(".go-next").empty;
            //         var dataI = data[i];
            //         var $add = $('<li class="mui-table-view-cell address-item address-active"><div class="clickOne' + i + '" style="position: relative"><div><span class="span-name">' + dataI.contacts + '</span><span class="span-number">' + dataI.phone + '</span></div><div class="div-where">' + dataI.full_address + '</div><div></li>');
            //         var $label = $('<div class="mui-input-row mui-radio mui-left go-next' + i + '"><div style="width:60%;" class="setA' + i + '"><label class="label-where" style="padding-right:0 !important;">设置为默认地址</label><input ' + (dataI.default_address === "1" ? "checked" : "") + ' name="radio1" type="radio" class="input-radio"></div></div>');
            //         var $addEdit = $('<button class="button-edit edit' + i + '" type="button" class="mui-btn" style="border: 1px solid #009C33;color: #009C33;">编辑</button>');
            //         var $addDelete = $('<button class="button-delete delete' + i + '" type="button" class="mui-btn" style="border: 1px solid #009C33;color: #009C33;">删除</button>');
            //         $("#addressList").append($add);
            //         $($add).append($label);
            //         $(".go-next" + i).append($addEdit);
            //         $(".go-next" + i).append($addDelete);
            //         if (froms === "order") {
            //             var $addBtn = $('<button type="button" class="mui-btn choose' + i + '" style="border: 1px solid #009C33;color: #009C33;position: absolute;top: -5px;right: 0;">选择地址</button>');
            //             $(".clickOne" + i).append($addBtn);
            //             asd($(".choose" + i), $(".setA" + i), dataI);
            //
            //         }
            //         if (froms === "tihuo") {
            //             var $addBtn = $('<button type="button" class="mui-btn chooses' + i + '" style="border: 1px solid #009C33;color: #009C33;position: absolute;top: -5px;right: 0;">选择地址</button>');
            //             $(".clickOne" + i).append($addBtn);
            //             asd($(".chooses" + i), $(".setA" + i), dataI);
            //
            //         }
            //         addTouchEdit($addEdit, dataI);
            //         addTouchDelete($addDelete, dataI);
            //         addTouch($(".setA" + i), dataI);
            //     }
            // }

            function asd(ele, one) {
                $(ele).click(function () {
                    if (froms === "shopcar") {
                        asds(one, "/jiupian/order/order_je.php?from=" + getPValue("from") + "&card_index=" + getPValue("card_index"));
                    }
                    if (froms === "tihuo") {
                        asds(one, "/jiupian/import_count.php?money=" + getPValue("money"));
                    }
                    if (froms === "order") {
                        asds(one, "/jiupian/order/order_je.php");
                    } else {
                        window.history.back();
                    }

                });

            }

            function asds(one, where) {
                var selected_user_address = {
                    address: one.address,
                    address_id: one.address_id,
                    province_id: one.province_id,
                    city_name: one.city_name,
                    contacts: one.contacts,
                    county_name: one.county_name,
                    default_address: one.default_address,
                    full_address: one.full_address,
                    phone: one.phone,
                    merchant_id: one.merchant_id,
                    province_name: one.province_name

                };
                window.sessionStorage.setItem('selected_user_address', JSON.stringify(selected_user_address));
                window.location.href = where;
            }

            function addTouchDelete(ele, one) {
                $(ele).click(function () {
                    var btnArray = ['否', '是'];
                    Mui.confirm('是否删除此地址？', '提示', btnArray, function (e) {
                        if (e.index == 1) {
                            Ajax.appAjax({
                                url: baseUrl + 'jiupian/api/mall.php', // 请求地址,
                                // url: DOMAIN_URL + 'mall.php', // 请求地址,
                                needLogin: false,
                                data: {
                                    c: 'address/del_user_address',
                                    address_id: one.address_id,
                                    device: 0
                                },
                                success: function (e) {
                                    console.log(e);
                                    if (e.success) {
                                        Mui.alert(e.msg);
                                        setTimeout(function () {
                                            window.location.reload();
                                        }, 500)
                                    } else {
                                        Mui.toast(e.msg);
                                    }
                                },
                                error: function (e) {
                                    console.log(e);
                                }
                            });
                        } else {

                        }
                    });
                })
            }

            function addTouchEdit(ele, one) {
                $(ele).click(function () {
                    window.location.href = "editAddress.php?addressId=" + one.address_id + '&from=' + getPValue("from") + "&money=" + getPValue("money") + "&card_index=" + getPValue("card_index");
                })
            }

            //设置默认收货地址
            function addTouchDefult(ele, one) {
                $(ele).click(function () {
                    Ajax.appAjax({
                        url: baseUrl + 'jiupian/api/mall.php', // 请求地址,
                        // url: DOMAIN_URL + 'mall.php', // 请求地址,
                        needLogin: false,
                        data: {
                            c: 'address/default_user_address',
                            address_id: one.address_id,
                            device: 0
                        },
                        success: function (e) {
                            console.log(e);
                            if (e.success) {
                                $(".img_defult").attr("src", "../image/jiupian/addressno.png")
                                $($(ele).find("img")).attr("src", "../image/jiupian/addressyes.png");
                                Mui.toast(e.msg);
                            } else {
                                Mui.toast(e.msg);
                            }
                        },
                        error: function (e) {
                            console.log(e);
                        }
                    });
                })

            }

            $("#call_back").click(function () {
                if (getPValue("from") == "userinfo") {
                    window.location.href = "/jiupian/member/userInfo.php";
                } else {
                    window.history.go(-1);
                }
            })

            shareObj(getStringByConfig("share_title"), baseUrl + projectName + '/login/register.php?sing=' + getCache("_phone"), IMG_CDN + getStringByConfig("logo"), getStringByConfig("share_subtitle"));

        })
    </script>
</div>
</body>
</html>
