<?php
include_once '../share.php';
require_once './../templ/head.php';
?>
<body class="mui-ios mui-ios-11 mui-ios-11-0">
<header class="mui-bar mui-bar-nav">
    <a class="mui-action-back mui-icon mui-icon-arrowthinleft mui-pull-left"></a>
    <h1 class="mui-title fsz-large">提交成功</h1>
</header>
<div class="mui-content drawings">
    <div class="succeed-tip">
        <span class="succeed mb-15"></span>
        <h4>提交成功</h4>
    </div>
    <div class="page-bottom-btn-box relative mt-25">
        <button id="btn_back" type="button" class="mui-btn mui-btn-main mui-btn-block btnMall">完成</button>
    </div>
</div>
<script src="../js/require.js"></script>
<script src="../js/require.config.js"></script>
<script>
    require(['mui', 'jquery'], function (Mui, $) {
        $("#btn_back").click(function () {
            window.location.href = "../member.php";
        })
        shareObj(getStringByConfig("share_title"), baseUrl + projectName + '/login/register.php?sing=' + getCache("_phone"), IMG_CDN + getStringByConfig("logo"), getStringByConfig("share_subtitle"));
    })
</script>
</body>
</html>