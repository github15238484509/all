<?php
include_once '../share.php';
require_once './../templ/head.php';
?>
<body class="mui-ios mui-ios-11 mui-ios-11-0 order-list-page">
<header class="mui-bar mui-bar-nav">
    <a class="mui-action-back mui-icon mui-icon-arrowthinleft mui-pull-left"></a>
    <h1 class="mui-title fsz-large">店铺补贴记录</h1>
</header>
<div class="mui-content balance-record asdasd">
    <div class="font15 fontfaW3 color99" style="padding: 20px 0 20px 20px;">总额：<span id="total_cash"
                                                                                     class="fontfalar"></span></div>
    <div class="mui-table-view J_balance-record">

        <script type="x-tmpl-mustache" id="J_RecordsListTmpl">
        <div class="positionR" style="height: 70px;border-bottom: .5px solid #e6e6e6">
            <div class="positionA fontfaW3 font15 color22" style="top: 15px;left: 15px;">{{msg}}</div>
            <div class="positionA fontfalar font12 color99" style="bottom:10px;left: 15px;">{{time_format}}</div>
            <div class="positionA fontfalar font18 color22" style="top: 27px;right: 15px;">{{amounts}}</div>
        </div>


        </script>
    </div>
</div>
<script src="../js/libs/app.js"></script>
<script src="../js/require.js"></script>
<script src="../js/require.config.js"></script>
<script>

    require(['mui', 'list'], function (Mui, List) {

        var loginToken = getCookie("jiupian_token");

        function initGoodsList(getUrl) {
            var oRequestData = {
                //0查看全部，1只看有货
            };

            var oListOptions = {
                token: loginToken,
                needLogin: true,
                type: 0,
                page: 0,
                selector: '.J_balance-record',
                url: baseUrl + '/jiupian/api/mall.php?c=merchantCashChange', // 请求地址,
                ajaxData: function () {
                    return oRequestData;
                },
                data: {
                    'time_format': function () {
                        return (timetrans(this['time']));
                    },
                    "amounts": function () {
                        if (this['type'] > 100) {
                            return "-" + (Number(this['amount']) / 100).toFixed(2)
                        }
                        if (this['type'] < 100) {
                            return "+" + (Number(this['amount']) / 100).toFixed(2)
                        }
                    }
                },
                template: $('#J_RecordsListTmpl').html(), // 渲染模板,
                dataList: 'list',
                refresh: true,
                success: function (obj, _list) {
                    console.log(obj)
                    $("#total_cash").html(setMoney(obj.data.total_cash));
                }
            };

            var oList = List.init(oListOptions);
        }

        initGoodsList();
        shareObj(getStringByConfig("share_title"), baseUrl + projectName + '/login/register.php?sing=' + getCache("_phone"), IMG_CDN + getStringByConfig("logo"), getStringByConfig("share_subtitle"));
    })
</script>
</body>