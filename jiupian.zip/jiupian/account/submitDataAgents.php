<?php
include_once '../baseConfig.php';
include_once '../share.php';
include_once '../templ/head.php';

use HoloPHP\AutoLoader;

include_once AutoLoader::autoPath("/wechat/jsSign.php");
?>
<body class="mui-ios mui-ios-11 mui-ios-11-0">
<link rel="stylesheet" href="../js/mui-picker/mui.picker.min.css">
<link rel="stylesheet" type="text/css" href="../css/public.css">
<!-- 引入样式和js文件 -->
<link rel="stylesheet" type="text/css" href="../css/mobileSelects.css">
<script src="../js/libs/mobileSelects.js" type="text/javascript"></script>
<script type="text/javascript" src="http://api.map.baidu.com/api?v=2.0&ak=E9hLG4mgunGuREmlxyDeLxq5F19BywLt"></script>

<header class="mui-bar mui-bar-nav">
    <a href="/jiupian/index.php" class="mui-icon mui-icon-arrowthinleft mui-pull-left"></a>
    <h1 class="mui-title fsz-large">提交资料</h1>
</header>
<div class="mui-content div-data">
    <form class="mui-input-group form-data">
        <div class="mui-input-row data-one">
            <label>联系人</label>
            <input id="contacts" type="text" placeholder="请输入联系人真实姓名">
        </div>
        <div class="mui-input-row data-one">
            <label>联系电话</label>
            <input id="phone" type="number" placeholder="请输入联系电话">
        </div>
        <div class="mui-input-row data-one">
            <label>营业时间</label>
            <div class="positionA"
                 style="right: 0;margin-top: 0;width: 70%;float: none;height: 50px;font-size: 13px;top: 0;">
                <div id="trigger2" class="positionA" style="left: 0;top: 15px;">起始时间</div>
                <div class="positionA" style="left: 75px;top: 15px;">——</div>
                <div id="trigger3" class="positionA" style="left: 130px;top: 15px;">结束时间</div>
            </div>

        </div>
        <div class="mui-input-row data-where">
            <label>营业地址</label>
            <div class="J_picker-show data-whereT">
                <span class="province">请选择地区 <span class="mui-icon mui-icon-forward"
                                                   style="font-size: 16px;"></span></span>
                <input type="hidden" id="province">
                <input type="hidden" id="city">
                <input type="hidden" id="district">
            </div>
            <div class="data-text-where">
                <textarea id="address" rows="5" placeholder="请输入详细位置"></textarea>
            </div>
        </div>
        <div id="allmap" style="height: 144px;width: 100%;"></div>
        <div class="mui-input-row data-one">
            <label>店铺名称</label>
            <input id="shopName" type="text" placeholder="请输入店铺名称">
        </div>

        <div class="mui-input-row data-one">
            <label>近期活动</label>
            <input id="post_code" type="text" maxlength="6" placeholder="请输入近期活动">
        </div>
        <div class="mui-input-row data-where">
            <label>店铺简介</label>
            <div class="data-text-where">
                <textarea id="merchant_desp" rows="5" placeholder="请输入店铺主营业务和及活动详情"
                          style="width: 100%;padding: 0 15px;"></textarea>
            </div>
        </div>
        <div class="mui-input-row">
            <label for="bank_account" style="font-size:13px;">店铺头像<span
                        style="min-width: 13em; color:#999; font-size: 12px; display: inline-block; margin-top: 8px;">1张(尺寸500*500)</span></label>
            <div class="img_up fr mb-10" id="J_ContractBox">
                    <span class="img_up_0 img_up_1" id="J_Contract">
                        <img id="merchant_logo" src="">
                    </span>
            </div>
        </div>
        <div class="mui-input-row">
            <label for="bank_accounts" style="font-size:13px;">店铺轮播图<span
                        style="min-width: 13em; color:#999; font-size: 12px; display: inline-block; margin-top: 8px;">至少2张(800*450)</span></label>
            <div class="img_up fr mb-10" id="J_ContractsBox">
                    <span class="img_up_0 img_up_1" id="J_Contracts">
                        <b class="hui mui-icon mui-icon-plusempty"></b>
                    </span>
            </div>
        </div>
        <div class="mui-button-row register-btn-box">
            <button id="btn_submit" type="button" class="mui-btn register-btn mui-btn-main mui-btn-block btnMall">确定
            </button>
        </div>
    </form>

    <script src="../js/require.js"></script>
    <script src="../js/require.config.js"></script>
    <script>
        require(['mui', 'jquery', 'picker', 'upload', 'ajax', 'cityData'], function (Mui, $, Picker, Upload, Ajax) {
            mui.init();
            var loginToken = getCookie("jiupian_token");
            var $contractFile = $('#J_Contract');
            var $contractFiles = $('#J_Contracts');
            var provinceV = "";
            var cityV = "";
            var districtV = "";
            var merchant_desp = "";
            var contacts = "";
            var phone = "";
            var beginTime = "";
            var endTime = "";
            var address = "";
            var agreements = "";
            var agreementss = "";
            var postCode = "";
            var shopName = "";
            var merchant_longitude = "";
            var merchant_latitude = "";
            var $imageBox2 = $('#J_ContractBox');
            var $imageBox3 = $('#J_ContractsBox');
            var userPicker = new mui.PopPicker({layer: 3});
            userPicker.setData(cityData3);

            var timeArr = ['06:30', '07:00', '07:30', '08:00', '08:30', '09:00', '09:30', '10:00', '10:30', '11:00', '11:30', '12:00', '12:30', '13:00', '13:30', '14:00', '14:30', '15:00', '15:30', '16:00', '16:30', '17:00', '17:30', '18:00', '18:30', '19:00', '19:30', '20:00', '20:30', '21:00', '21:30', '22:00', '22:30', '23:00', '23:30', '00:00', '00:30', '01:00', '01:30', '02:00', '02:30', '03:00', '03:30', '04:00', '04:30', '05:00', '05:30', '06:00'];

            if (!isEmpty(getPValue("merchant_id"))) {
                getMerchantInfo();
            }

            function getMerchantInfo() {
                Ajax.appAjax({
                    url: baseUrl + 'jiupian/api/mall.php', // 请求地址,
                    // url: DOMAIN_URL + 'mall.php', // 请求地址,
                    needLogin: false,
                    data: {
                        c: 'getMerchantInfo'
                    },
                    success: function (e) {
                        console.log(e);
                        if (e.success) {
                            $("#contacts").val(e.data.merchant_contacts);
                            $("#phone").val(e.data.merchant_tel);
                            $("#trigger2").html(e.data.merchant_worktime.substr(0, 5));
                            beginTime = e.data.merchant_worktime.substr(0, 5);
                            $("#trigger3").html(e.data.merchant_worktime.substr(6, 10));
                            endTime = e.data.merchant_worktime.substr(6, 10);
                            $(".province").html(e.data.province_name + e.data.city_name + e.data.county_name);
                            $("#address").val(e.data.merchant_address);
                            province = e.data.province_name;
                            provinceV = e.data.merchant_province;
                            city = e.data.city_name;
                            cityV = e.data.merchant_city;
                            district = e.data.county_name;
                            districtV = e.data.merchant_county;
                            $("#shopName").val(e.data.merchant_name);
                            $("#post_code").val(e.data.merchant_activite);
                            $("#merchant_desp").val(e.data.merchant_desp);
                            $("#merchant_logo").attr("src", IMG_CDN + e.data.merchant_logo);
                            agreements = e.data.merchant_logo;

                            for (var i = 0; i < e.data.merchant_image.length; i++) {
                                var dataI = e.data.merchant_image[i];
                                $contractFiles.before('<span class="img_up_0 J_Image2"><img src="' + IMG_CDN + dataI + '" /><i class="J_Delete"></i></span>');
                                if (i === 0) {
                                    agreementss = dataI;
                                } else {
                                    agreementss += "," + dataI;
                                }
                            }

                            merchant_longitude = e.data.merchant_longitude;
                            merchant_latitude = e.data.merchant_latitude;

                            // 百度地图API功能
                            var map = new BMap.Map("allmap");
                            map.centerAndZoom(new BMap.Point(116.331398, 39.897445), 20);
                            map.enableScrollWheelZoom(true);

                            // 用经纬度设置地图中心点
                            map.clearOverlays();
                            var new_point = new BMap.Point(merchant_longitude, merchant_latitude);
                            var marker = new BMap.Marker(new_point);  // 创建标注
                            map.addOverlay(marker);              // 将标注添加到地图中
                            map.panTo(new_point);

                            map.addEventListener("click", function (e) {
                                map.clearOverlays();
                                var new_point = new BMap.Point(e.point.lng, e.point.lat);
                                merchant_longitude = e.point.lng;
                                merchant_latitude = e.point.lat;
                                var marker = new BMap.Marker(new_point);  // 创建标注
                                map.addOverlay(marker);              // 将标注添加到地图中
                                map.panTo(new_point);
                            });

                        } else {
                            Mui.toast(e.msg);
                        }
                    },
                    error: function (e) {
                        console.log(e);
                    }
                });
            }

            $("#btn_submit").click(function () {
                contacts = $("#contacts").val();
                phone = $("#phone").val();
                address = $("#address").val();
                postCode = $("#post_code").val();
                shopName = $("#shopName").val();
                merchant_desp = $("#merchant_desp").val();
                console.log(contacts);
                console.log(phone);
                console.log(address);
                console.log(provinceV);
                console.log(cityV);
                console.log(districtV);
                console.log(agreementss);
                if (contacts === "") return Mui.toast("请输入联系人！");
                if (phone === "") return Mui.toast("请输入手机号！");
                if (beginTime === "") return Mui.toast("请选择营业开始时间");
                if (endTime === "") return Mui.toast("请选择营业结束时间");
                if (Number(String(beginTime).substr(0, 2)) > Number(String(endTime).substr(0, 2))) {
                    Mui.toast("开始时间不能大于结束时间")
                }
                if (provinceV === "" && cityV === "" && districtV === "") {
                    return Mui.toast("请选择地区~!");
                }
                if (address === "") return Mui.toast("请输入详细地址！");
                if (shopName === "") return Mui.toast("请输入店铺名称！");
                if (postCode === "") return Mui.toast("请输入近期活动！");
                if (merchant_desp === "") return Mui.toast("请输入店铺简介！");
                if (agreements === "") return Mui.toast("请上传店铺头像！");
                if (agreementss === "") return Mui.toast("请上传店铺轮播图！");
                submitMerInfo();

            });

            mui('.mui-content').on('tap', '.J_picker-show', function (e) {
                userPicker.show(function (item) {
                    province = item[0]['text'] ? item[0]['text'] : '';
                    provinceV = item[0]['value'] ? item[0]['value'] : '';
                    city = item[1]['text'] ? item[1]['text'] : '';
                    cityV = item[1]['value'] ? item[1]['value'] : '';
                    district = item[2]['text'] ? item[2]['text'] : '';
                    districtV = item[2]['value'] ? item[2]['value'] : '';
                    $('.province').html(province + city + district);
                    provinceValue = province + city + district;
                    $('#province').val(province);
                    $('#city').val(city);
                    $('#district').val(district)
                })
            });

            Upload.init({
                selector: '#J_Contract',
                accept: 'image/*',
                url: baseUrl + "jiupian/api/mall.php?c=uploadCheckImage&token=" + loginToken + "&type=0",
                before: function () {
                    Loading.show();
                },
                success: function (data) {
                    if (data.success) {
                        agreements = data.data;
                        $contractFile.before('<span class="img_up_0 J_Image1"><img src="' + IMG_CDN + data.data + '" /><i class="J_Delete"></i></span>');
                    } else {
                        Mui.toast(data.code, {duration: 'long', type: 'div'});
                    }
                    if ($('.J_Image1').length >= 1) {
                        $contractFile.hide();
                    } else {
                        $contractFile.show();
                    }
                    Loading.hide();
                },
                error: function (responseText) {
                    Loading.hide();
                    Mui.toast(responseText || '上传失败', {duration: 'long', type: 'div'});
                }
            });
            Upload.init({
                selector: '#J_Contracts',
                accept: 'image/*',
                url: baseUrl + "jiupian/api/mall.php?c=uploadCheckImage&token=" + loginToken + "&type=0",
                before: function () {
                    Loading.show();
                },
                success: function (data) {
                    console.log(data)
                    if (data.success) {
                        if (agreementss == "") {
                            agreementss = data.data;
                        } else {
                            agreementss += ("," + data.data)
                        }
                        $contractFiles.before('<span class="img_up_0 J_Image2"><img src="' + IMG_CDN + data.data + '" /><i class="J_Delete"></i></span>');
                    } else {
                        Mui.toast(data.code, {duration: 'long', type: 'div'});
                    }
                    if ($('.J_Image2').length >= 5) {
                        $contractFiles.hide();
                    } else {
                        $contractFiles.show();
                    }
                    Loading.hide();
                },
                error: function (responseText) {
                    Loading.hide();
                    Mui.toast(responseText || '上传失败', {duration: 'long', type: 'div'});
                }
            });

            function submitMerInfo() {
                var times = String(beginTime) + "-" + String(endTime);
                Ajax.appAjax({
                    url: baseUrl + 'jiupian/api/mall.php', // 请求地址,
                    // url: DOMAIN_URL + 'mall.php', // 请求地址,
                    needLogin: false,
                    data: {
                        c: 'updateMerchantInfo',
                        merchant_name: shopName,
                        merchant_activite: postCode,
                        merchant_contacts: contacts,
                        merchant_tel: phone,
                        merchant_worktime: times,
                        merchant_city: cityV,
                        merchant_county: districtV,
                        merchant_address: address,
                        merchant_province: provinceV,
                        merchant_image: agreementss,
                        merchant_desp: merchant_desp,
                        merchant_logo: agreements,
                        merchant_longitude: merchant_longitude,
                        merchant_latitude: merchant_latitude,
                        merchant_id: getPValue("merchant_id")
                    },
                    success: function (e) {
                        console.log(e);
                        if (e.success) {
                            window.location.href = "success.php";
                        } else {
                            Mui.toast(e.msg);
                        }
                    },
                    error: function (e) {
                        console.log(e);
                    }
                });
            }

            var mobileSelect1 = new MobileSelect({
                trigger: '#trigger2',
                title: '起始时间',
                wheels: [
                    {data: timeArr}
                ],
                position: [1, 2],
                transitionEnd: function (indexArr, data) {
                    beginTime = data;
                    console.log(beginTime)
                },
                callback: function (indexArr, data) {
                    beginTime = data;
                    console.log(beginTime);
                    if (endTime !== "") {
                        if (Number(String(beginTime).substr(0, 2)) > Number(String(endTime).substr(0, 2))) {
                            Mui.toast("开始时间不能大于结束时间")
                        }
                    }
                }
            });
            var mobileSelect2 = new MobileSelect({
                trigger: '#trigger3',
                title: '结束时间',
                wheels: [
                    {data: timeArr}
                ],
                position: [1, 2],
                transitionEnd: function (indexArr, data) {
                    endTime = data;
                    console.log(endTime)
                },
                callback: function (indexArr, data) {
                    endTime = data;
                    console.log(endTime);
                    if (beginTime !== "") {
                        if (Number(String(beginTime).substr(0, 2)) > Number(String(endTime).substr(0, 2))) {
                            Mui.toast("开始时间不能大于结束时间")
                        }
                    }
                }
            });

            $imageBox2.on('click', '.J_Delete', function () {
                var $img2 = $(this).closest('.J_Image1');
                agreements = "";
                $img2.remove();
                if ($('.J_Image1').length >= 3) {
                    $contractFile.hide();
                } else {
                    $contractFile.show();
                }
            });
            $imageBox3.on('click', '.J_Delete', function () {
                var dataImg = $(this.previousElementSibling).attr("src");
                dataImg = dataImg.replace(IMG_CDN, "");
                agreementss = agreementss.replace(dataImg, "");
                //去掉第一个逗号
                if (agreementss.substr(0, 1) === ',') agreementss = agreementss.substr(1);
                //去掉最后一个逗号
                var reg = /,$/gi;
                agreementss = agreementss.replace(reg, "");
                console.log(agreementss);


                var $img3 = $(this).closest('.J_Image2');
                $img3.remove();
                if ($('.J_Image2').length >= 3) {
                    $contractFiles.hide();
                } else {
                    $contractFiles.show();
                }
            });

            shareObj(getStringByConfig("share_title"), baseUrl + projectName + '/login/register.php?sing=' + getCache("_phone"), IMG_CDN + getStringByConfig("logo"), getStringByConfig("share_subtitle"));

        })
    </script>
</div>
</body>
</html>
