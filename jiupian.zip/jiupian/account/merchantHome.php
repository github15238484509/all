<?php
include_once '../share.php';
require_once './../templ/head.php';
?>
<body class="mui-ios mui-ios-11 mui-ios-11-0 order-list-page">
<header class="mui-bar mui-bar-nav">
    <a class="mui-action-back mui-icon mui-icon-arrowthinleft mui-pull-left"></a>
    <h1 class="mui-title fsz-large">管理中心</h1>
</header>
<div class="mui-content drawings">
    <ul>
        <li class="backWhite positionR" style="margin: 10px;height: 83px;">
            <div id="merchant_name" class="fontfa10 color22 font15 positionA"
                 style="font-weight: 600;left: 10px;top: 10px;">
            </div>
            <div id="merchant_address" class="positionA fontfaW3 color66 font13" style="left: 10px;bottom: 20px;"></div>
            <div id="change_merchant" class="positionA fontfaW3 color99 font12" style="top: 10px;right: 10px;">修改店面资料
            </div>
        </li>
        <li class="backWhite positionR" style="margin: 10px;height: 83px;">
            <div class="fontfa10 color22 font15 positionA" style="font-weight: 600;left: 10px;top: 10px;">我的体系会员</div>
            <div class="positionA fontfaW3 color66 font13" style="left: 10px;bottom: 20px;">共推广<span
                        id="underling_count"></span>个会员
            </div>
            <div id="merchantUser" class="positionA fontfaW3 color99 font12" style="top: 10px;right: 10px;">查看详情</div>
        </li>
        <li class="backWhite positionR" style="margin: 10px;height: 83px;">
            <div class="fontfa10 color22 font15 positionA" style="font-weight: 600;left: 10px;top: 10px;">店铺补贴记录</div>
            <div class="positionA fontfaW3 color66 font13" style="left: 10px;bottom: 20px;">累计获得<span
                        id="subsidies"></span>元店铺补贴
            </div>
            <div id="subsidiess" class="positionA fontfaW3 color99 font12" style="top: 10px;right: 10px;">查看详情</div>
        </li>
    </ul>


</div>
<script src="../js/require.js"></script>
<script src="../js/require.config.js"></script>
<script>
    require(['mui', 'jquery', 'ajax'], function (Mui, $, Ajax) {
        Ajax.appAjax({
            url: baseUrl + 'jiupian/api/mall.php', // 请求地址,
            // url: DOMAIN_URL + 'mall.php', // 请求地址,
            needLogin: false,
            data: {
                c: 'merchantHome'
            },
            success: function (e) {
                console.log(e);
                if (e.success) {
                    $("#merchant_name").html(e.data.merchant_name);
                    $("#merchant_address").html(e.data.merchant_address);
                    $("#underling_count").html(e.data.underling_count);
                    $("#subsidies").html((e.data.subsidies) / 100);
                    $("#change_merchant").click(function () {
                        window.location.href = "./submitDataAgents.php?merchant_id=" + e.data.merchant_id;
                    });
                    $("#merchantUser").click(function () {
                        window.location.href = "./merchantUser.php?merchant_id=" + e.data.merchant_id;
                    });
                    $("#subsidiess").click(function () {
                        window.location.href = "./subsidies.php?merchant_id=" + e.data.merchant_id;
                    })

                } else {
                    Mui.toast(e.msg);
                }
            },
            error: function (e) {
                console.log(e);
            }
        });
        shareObj(getStringByConfig("share_title"), baseUrl + projectName + '/login/register.php?sing=' + getCache("_phone"), IMG_CDN + getStringByConfig("logo"), getStringByConfig("share_subtitle"));


    })
</script>
</body>