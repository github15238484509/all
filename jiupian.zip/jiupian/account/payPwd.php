<?php
include_once '../share.php';
include_once '../templ/head.php'; ?>
<body class="mui-ios mui-ios-11 mui-ios-11-0">
<link rel="stylesheet" href="../js/mui-picker/mui.picker.min.css">
<header class="mui-bar mui-bar-nav">
    <a id="fanhui" class="mui-icon mui-icon-arrowthinleft mui-pull-left"></a>
    <h1 class="mui-title fsz-large">设置支付密码</h1>
</header>
<div class="mui-content set-paypwd">
    <form id="phoneCodeForm" class="mui-input-group">
        <div class="mui-input-row">
            <input id="phone" type="text" disabled="disabled">
            <button id="phoneCodeBtn" type="button"
                    class="mui-btn mui-btn-main sent-sms-btn">获取验证码
            </button>
        </div>
        <div class="mui-input-row">
            <input id="phoneCode" type="text" placeholder="输入验证码">
        </div>
        <div class="mui-button-row register-btn-box">
            <button id="btn_register" type="button"
                    class="mui-btn register-btn mui-btn-main mui-btn-block btnMall">下一步
            </button>
        </div>
    </form>
    <form id="first" class="mui-input-group" style="display: none">
        <p>请输入6位数字支付密码</p>
        <div class="pay-password J_password">
            <input class="password" type="tel" maxlength="6">
            <div class="password-style">
                <span></span> <span></span> <span></span> <span></span> <span></span>
                <span></span>
            </div>
        </div>
        <div class="mui-button-row register-btn-box">
            <button id="btn_next" type="button"
                    class="mui-btn register-btn mui-btn-main mui-btn-block btnMall">下一步
            </button>
        </div>
    </form>
    <form id="second" class="mui-input-group" style="display: none">
        <p>请再次输入6位数字支付密码</p>
        <div class="pay-password J_password_two">
            <input class="password" type="tel" maxlength="6">
            <div class="password-style">
                <span></span> <span></span> <span></span> <span></span> <span></span>
                <span></span>
            </div>
        </div>
        <div class="mui-button-row register-btn-box">
            <button id="btn_submit" type="button"
                    class="mui-btn register-btn mui-btn-main mui-btn-block btnMall">确认
            </button>
        </div>
    </form>
    <script src="../js/require.js"></script>
    <script src="../js/require.config.js"></script>
    <script>
        require(['mui', 'jquery', 'payPwd', 'ajax', 'md5', "sms"], function (Mui, $, PayPwd, Ajax, MD5, SMS) {
            mui.init();

            var phones = "";
            Ajax.appAjax({
                url: baseUrl + 'jiupian/api/mall.php', // 请求地址,
                // url: DOMAIN_URL + 'mall.php', // 请求地址,
                needLogin: true,
                data: {
                    c: 'get_user_info',
                    token: loginToken
                },
                success: function (e) {
                    console.log(e);
                    if (e.success) {
                        phones = e.data.userinfo.phone;
                        $("#phone").val(phones);
                        if (isEmpty(e.data.userinfo.phone)) {
                            Mui.confirm("尚未绑定手机号，是否前去绑定？", "提示", ["取消", "去绑定"], function (res) {
                                if (res.index == 1) {
                                    window.location.href = "/jiupian/member/setPhone.php?from=setPay&order_index=" + getPValue("order_index") + "&total_money=" + getPValue("total_money");
                                } else {
                                    window.history.back(-1);
                                }
                            });
                        }

                        SMS.init($phoneCodeBtn, $phone, {
                            $smsCode: $phoneCode,
                            url: baseUrl + 'jiupian/api/mall.php?c=applyPhoneCode', // 请求地址,
                            // url: DOMAIN_URL + 'mall.php', // 请求地址,
                            data: {verify_type: '3'}
                        });
                    } else {
                        Mui.toast(e.msg);
                    }
                },
                error: function (e) {
                    console.log(e);
                }
            });
            var loginToken = getCookie("jiupian_token");
            var Pwd = $('.J_password').payPwd();
            var Pwds = $('.J_password_two').payPwd();
            var $phone = $('#phone'),
                $phoneCodeBtn = $('#phoneCodeBtn'),
                $phoneCode = $('#phoneCode');
            var phoneNumber = "";
            var phoneCodes = "";


            $("#fanhui").click(function () {
                if (isEmpty(getPValue("order_index"))) {
                    window.history.back(-1);
                } else {
                    window.location.href = "../pay.php?order_index=" + getPValue("order_index") + "&total_money=" + getPValue("total_money");
                }
            });


            $("#btn_register").click(function () {
                phoneNumber = $("#phone").val();
                phoneCodes = $("#phoneCode").val();
                if (phoneNumber === "" && phoneCodes === "") {
                    return Mui.toast("验证码不正确");
                }
                verifySmsCode();
            });


            $("#btn_next").click(function () {
                $("#phoneCodeForm").css("display", "none");
                $("#first").css("display", "none");
                $("#second").css("display", "block");
            });

            $("#btn_submit").click(function () {
                if (Pwd.value === Pwds.value) {
                    console.log("1111111111");
                    loginForPhoneCode();
                } else {
                    console.log("222222222222");
                    Mui.toast("两次密码输入不一致");
                    // setTimeout(() => {
                    //     window.location.href = "account.php";
                    // }, 1000);
                }
            });


            function loginForPhoneCode() {
                Ajax.appAjax({
                    url: baseUrl + 'jiupian/api/mall.php', // 请求地址,
                    // url: DOMAIN_URL + 'mall.php', // 请求地址,
                    needLogin: false,
                    data: {
                        c: 'setPayPasswd',
                        phone: phones,
                        pay_password: MD5(Pwd.value)
                    },
                    success: function (e) {
                        if (e.success) {
                            setCache("_payPwd", true);
                            Mui.toast(e.msg);
                            setTimeout(function () {
                                if (isEmpty(getPValue("order_index"))) {
                                    window.history.back(-1);
                                } else {
                                    window.location.href = "../pay.php?order_index=" + getPValue("order_index") + "&total_money=" + getPValue("total_money") + "&user_cash=" + getPValue("user_cash") + "&user_bonus=" + getPValue("user_bonus");
                                }
                            }, 1000)
                        }
                    },
                    error: function (e) {
                        Mui.toast(e);
                    }
                });
            }

            //验证手机验证码
            function verifySmsCode() {
                Ajax.appAjax({
                    url: baseUrl + 'jiupian/api/mall.php', // 请求地址,
                    // url: DOMAIN_URL + 'mall.php', // 请求地址,
                    needLogin: false,
                    data: {
                        c: 'verifySmsCode',
                        token: loginToken,
                        phone: phoneNumber,
                        phone_code: phoneCodes

                    },
                    success: function (e) {
                        console.log(e);
                        if (e.success) {
                            Mui.toast(e.msg);
                            setTimeout(() => {
                                $("#phoneCodeForm").css("display", "none");
                                $("#first").css("display", "block");
                                $("#second").css("display", "none");
                            }, 500);
                        } else {
                            Mui.toast(e.msg);
                        }
                    },
                    error: function (e) {
                        Mui.toast(e);
                    }
                });
            }

            shareObj(getStringByConfig("share_title"), baseUrl + projectName + '/login/register.php?sing=' + getCache("_phone"), IMG_CDN + getStringByConfig("logo"), getStringByConfig("share_subtitle"));
        })
    </script>
</div>
</body>
</html>
