<?php
include_once '../share.php';
include_once '../templ/head.php';
?>
<body class="mui-ios mui-ios-11 mui-ios-11-0">
<link rel="stylesheet" href="../js/mui-picker/mui.picker.min.css">
<header class="mui-bar mui-bar-nav">
    <a class="mui-action-back mui-icon mui-icon-arrowthinleft mui-pull-left"></a>
    <h1 class="mui-title fsz-large">收货地址</h1>
    <span id="btn_save" class="header-btn" style="color: #009C33;">保存</span>
</header>
<div class="mui-content">
    <form class="mui-input-group">
        <div class="mui-input-row">
            <input id="consignee" type="text" placeholder="请输入收货人姓名">
        </div>
        <div class="mui-input-row">
            <input id="phone" type="number" placeholder="请输入收货人手机号">
        </div>
        <div class="mui-input-row J_picker-show">
            <span class="province">请选择地区 <span class="mui-icon mui-icon-forward" style="font-size: 16px;"></span></span>
            <input type="hidden" id="province">
            <input type="hidden" id="city">
            <input type="hidden" id="district">
        </div>
        <div class="data-table padding15">
            <table style="width:100%;">
                <tr>
                    <td class="fontfaW3 color22 font15" width="80%">设置提货地址</td>
                    <td align="right" class="td-right">
                        <img id="address_defults" src="../image/jiupian/guan.png" alt="" style="width: 40px;">
                    </td>
                </tr>
            </table>
        </div>

        <div class="mui-input-row">
            <textarea id="address" rows="5" placeholder="详细地址"></textarea>
        </div>
        <div class="data-table padding15">
            <table style="width:100%;">
                <tr>
                    <td class="fontfaW3 color22 font15" width="80%">设置默认地址</td>
                    <td align="right" class="td-right">
                        <img id="address_defult" src="../image/jiupian/guan.png" alt="" style="width: 40px;">
                    </td>
                </tr>
            </table>
        </div>
    </form>
    <div class="goods_address">
        <div class="goods_hide_address" style="position: fixed;top: 0;left: 0;right: 0;bottom: 100%"></div>
        <div class="backWhite" style="position:fixed;top: 100%;bottom: 0;left: 0;right: 0;">
            <div style="position: relative;height: 100%;">
                <span class="close_chooses mui-icon mui-icon-closeempty"
                      style="position:absolute;top: 5px;right: 5px;"></span>
                <div class="fontfaW3 color22 font18" style="height: 40px;line-height: 40px;text-align: center">提货地址
                </div>
                <ul id="load_address"></ul>
            </div>
        </div>
    </div>

    <script src="../js/require.js"></script>
    <script src="../js/require.config.js"></script>
    <script>
        require(['mui', 'jquery', 'ajax', 'picker', 'cityData'], function (Mui, $, Ajax) {
            mui.init();
            Loading.hide()
            var provinceValue = "";
            var phoneValue = "";
            var addressValue = "";
            var provinceV = "";
            var cityV = "";
            var districtV = "";
            var userAddress = "";
            var consignee = "";
            var loginToken = getCookie("jiupian_token");
            var addressId = getPValue("addressId");
            var userPicker = new mui.PopPicker({layer: 3});
            userPicker.setData(cityData3);
            var default_address_value = "0";
            var default_address_values = "0";
            var default_address_status = -1;
            var default_address_statuss = -1;
            var merchant_id = "";
            var is_merchant_address = "";

            if (!isEmpty(addressId)) {
                userAddress = "1";
                getAddressInfo();
            } else {
                userAddress = "0";
            }

            //选择区县
            mui('.mui-content').on('tap', '.J_picker-show', function (e) {
                userPicker.show(function (item) {
                    province = item[0]['text'] ? item[0]['text'] : '';
                    provinceV = item[0]['value'] ? item[0]['value'] : '';
                    city = item[1]['text'] ? item[1]['text'] : '';
                    cityV = item[1]['value'] ? item[1]['value'] : '';
                    district = item[2]['text'] ? item[2]['text'] : '';
                    districtV = item[2]['value'] ? item[2]['value'] : '';
                    $('.province').html(province + city + district);
                    provinceValue = province + city + district;
                    $('#province').val(province);
                    $('#city').val(city);
                    $('#district').val(district);

                    if (default_address_statuss == "1") {
                        $("#address_defults").attr("src", "../image/jiupian/kai.png");
                        default_address_values = "1";
                        $("#address").attr("disabled", true);
                        $("#goods_address").show();
                        $(".backWhite").animate({top: "25%"}, 500);
                        getGoodsEddress();
                    }

                })
            });

            $("#btn_save").click(function () {
                consignee = $("#consignee").val();
                phoneValue = $("#phone").val();
                addressValue = $("#address").val();
                // console.log("loginToken:"+loginToken);
                // console.log("provinceV:"+provinceV);
                // console.log("province:"+province);
                // console.log("cityV:"+cityV);
                // console.log("city:"+city);
                // console.log("districtV:"+districtV);
                // console.log("district:"+district);
                // console.log("consignee:"+consignee);
                // console.log("phoneValue:"+phoneValue);
                // console.log("addressValue:"+addressValue);
                if (consignee === "") return Mui.toast("请输入收货人名字");
                if (phoneValue === "") return Mui.toast("请输入收货人手机号");
                if (provinceV === "" && cityV === "" && districtV === "") {
                    return Mui.toast("请选择地区~!");
                }
                if (addressValue === "") return Mui.toast("请输入具体位置");
                Loading.show()
                editUserAddress();
            });

            //设置收货地址
            function editUserAddress() {
                Ajax.appAjax({
                    url: baseUrl + 'jiupian/api/mall.php', // 请求地址,
                    // url: DOMAIN_URL + 'mall.php', // 请求地址,
                    needLogin: false,
                    data: {
                        c: 'address/edit_user_address',
                        token: loginToken,
                        address_index: addressId,
                        address_id: userAddress,
                        province_id: provinceV,
                        province_name: province,
                        city_id: cityV,
                        city_name: city,
                        county_id: districtV,
                        county_name: district,
                        contacts: consignee,
                        phone: phoneValue,
                        address: addressValue,
                        default_address: default_address_value,
                        is_merchant_address: is_merchant_address,
                        merchant_id: merchant_id
                    },
                    success: function (e) {
                        console.log(e);
                        if (e.success) {
                            if (getPValue("from") === "order") {
                                Mui.toast(e.msg);
                                var selected_user_address = {
                                    address: e.data.address,
                                    address_id: e.data.addressId,
                                    city_name: e.data.city_name,
                                    contacts: e.data.contacts,
                                    county_name: e.data.county_name,
                                    default_address: e.data.default_address,
                                    full_address: e.data.full_address,
                                    phone: e.data.phone,
                                    province_name: e.data.province_name,
                                    merchant_id: merchant_id
                                };
                                window.sessionStorage.setItem('selected_user_address', JSON.stringify(selected_user_address));
                                window.location.href = "/jiupian/order/order_je.php";
                            } else if (getPValue("from") === "shopcar") {
                                Mui.toast(e.msg);
                                var selected_user_address = {
                                    address: e.data.address,
                                    address_id: e.data.addressId,
                                    city_name: e.data.city_name,
                                    contacts: e.data.contacts,
                                    county_name: e.data.county_name,
                                    default_address: e.data.default_address,
                                    full_address: e.data.full_address,
                                    phone: e.data.phone,
                                    province_name: e.data.province_name,
                                    merchant_id: merchant_id
                                };
                                window.sessionStorage.setItem('selected_user_address', JSON.stringify(selected_user_address));
                                window.location.href = "/jiupian/order/order_je.php?from=" + getPValue("from") + "&card_index=" + getPValue("card_index");
                            } else {
                                window.location.href = "addressList.php?from=" + getPValue("from") + "&money=" + getPValue("money");
                            }

                        } else {
                            Loading.hide();
                            Mui.toast(e.msg);
                        }
                    },
                    error: function (e) {
                        console.log(e);
                    }
                });
            }

            //获取编辑收货地址详情
            function getAddressInfo() {
                Ajax.appAjax({
                    url: baseUrl + 'jiupian/api/mall.php', // 请求地址,
                    // url: DOMAIN_URL + 'mall.php', // 请求地址,
                    needLogin: false,
                    data: {
                        c: 'address/get_address_info',
                        token: loginToken,
                        address_id: addressId,
                        device: "0"
                    },
                    success: function (e) {
                        console.log(e);
                        if (e.success) {
                            $("#consignee").val(e.data.contacts);
                            $("#phone").val(e.data.phone);
                            $(".province").html(e.data.province_name + e.data.city_name + e.data.county_name);
                            $("#address").val(e.data.address);
                            province = e.data.province_name;
                            provinceV = e.data.province_id;
                            city = e.data.city_name;
                            cityV = e.data.city_id;
                            district = e.data.county_name;
                            districtV = e.data.county_id;
                            default_address_value = e.data.default_address;
                            default_address_values = e.data.is_merchant_address;
                            default_address_statuss = e.data.is_merchant_address;
                            is_merchant_address = e.data.is_merchant_address;
                            if (e.data.default_address == "1") {
                                $("#address_defult").attr("src", "../image/jiupian/kai.png");
                            } else {
                                $("#address_defult").attr("src", "../image/jiupian/guan.png");
                            }
                            if (e.data.is_merchant_address == "1") {
                                $("#address_defults").attr("src", "../image/jiupian/kai.png");
                                $("#address").attr("disabled", true);
                            } else {
                                $("#address_defults").attr("src", "../image/jiupian/guan.png");
                            }
                            userPicker.pickers[0].setSelectedValue(provinceV);
                            setTimeout(function () {
                                userPicker.pickers[1].setSelectedValue(cityV);
                            }, 10);
                            setTimeout(function () {
                                userPicker.pickers[2].setSelectedValue(districtV);
                            }, 20);
                        } else {
                            Mui.toast(e.msg);
                        }
                    },
                    error: function (e) {
                        console.log(e);
                    }
                });
            }

            $("#address_defult").click(function () {
                default_address_status = default_address_status * -1;
                if (default_address_status == -1) {
                    $("#address_defult").attr("src", "../image/jiupian/guan.png");
                    default_address_value = "0";
                } else {
                    $("#address_defult").attr("src", "../image/jiupian/kai.png");
                    default_address_value = "1";
                }
            });
            $("#address_defults").click(function () {
                if (provinceV === "" && cityV === "" && districtV === "") {
                    return Mui.toast("请选择地区~!");
                }
                default_address_statuss = default_address_statuss * -1;
                if (default_address_statuss == -1) {
                    $("#address_defults").attr("src", "../image/jiupian/guan.png");
                    default_address_values = "0";
                    $("#address").attr("disabled", false);
                } else {
                    $("#address_defults").attr("src", "../image/jiupian/kai.png");
                    default_address_values = "1";
                    $("#address").attr("disabled", true);
                    $("#goods_address").show();
                    $(".backWhite").animate({top: "25%"}, 500);
                    getGoodsEddress();

                }
            });
            $(".close_chooses").click(function () {
                default_address_statuss = -1;
                default_address_values = "0";
                $("#address_defults").attr("src", "../image/jiupian/guan.png");
                $("#address").attr("disabled", false);
                $(".backWhite").animate({top: "100%"}, 500, function () {
                    $("#goods_address").hide();
                });
            });


            function getGoodsEddress() {
                $("#load_address").empty();
                Ajax.appAjax({
                    url: baseUrl + 'jiupian/api/mall.php', // 请求地址,
                    // url: DOMAIN_URL + 'mall.php', // 请求地址,
                    needLogin: false,
                    data: {
                        c: 'searchMerchant',
                        province_id: provinceV,
                        city_id: cityV,
                        county_id: districtV,
                    },
                    success: function (e) {
                        console.log(e);
                        if (e.success) {
                            if (e.data.list.length === 0) {
                                $("#load_address").append('<li class="fontfalar font15 color22" style="height:80px;line-height: 80px;text-align: center;font-weight: 600">暂无收货地址</li>');
                            }
                            for (var i = 0; i < e.data.list.length; i++) {
                                var dataI = e.data.list[i];
                                var $add = $('<li class="positionR" style="height: 80px;border-bottom: .5px solid #e6e6e6;margin: 0 15px;"><div class="positionA fontfaW3 font15 color22" style="left: 0;top: 10px;right: 15px;word-break: break-word">' + dataI.merchant_name + '</div><div class="positionA fontfaW3 font15 color99" style="left: 0;bottom: 10px;right: 15px;word-break: break-word">' + dataI.merchant_address + '</div></li>');
                                $("#load_address").append($add);
                                addTouchThisAddress($add, dataI, i);
                            }

                        } else {
                            // Mui.toast(e.msg);
                        }
                    },
                    error: function (e) {
                        console.log(e);
                    }
                });
            }


            //选择收货地址
            function addTouchThisAddress(ele, one, i) {
                $(ele).click(function () {
                    $("#address").val(one.merchant_address);
                    $(".backWhite").animate({top: "100%"}, 500, function () {
                        $("#goods_address").hide();
                    });
                    merchant_id = one.merchant_id;
                    is_merchant_address = "1";
                })

            }

            shareObj(getStringByConfig("share_title"), baseUrl + projectName + '/login/register.php?sing=' + getCache("_phone"), IMG_CDN + getStringByConfig("logo"), getStringByConfig("share_subtitle"));
        });

    </script>
</div>
</body>
