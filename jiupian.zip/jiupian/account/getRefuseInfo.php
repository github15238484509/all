<?php
include_once '../share.php';
require_once './../templ/head.php';
?>
<body class="mui-ios mui-ios-11 mui-ios-11-0 order-list-page">
<header class="mui-bar mui-bar-nav">
    <a class="mui-action-back mui-icon mui-icon-arrowthinleft mui-pull-left"></a>
    <h1 class="mui-title fsz-large">审核进度</h1>
</header>
<div class="mui-content drawings backWhite">
    <div class="fontfa10 colot22 font18" style="padding: 10px 20px;font-weight: 600">审核进度</div>
    <ul class="positionR">
        <li class="positionR" style="height: 80px;">
            <img class="positionA" src="../image/jiupian/shenhedian.png" alt="" style="width: 10px;top:10px;left: 15px;">
            <div class="positionA font13 color22" style="top: 6px;left: 43px;font-family: 'SourceHanSansCN-Regular';">
                待审核
            </div>
            <div class="positionA font13 color99" style="top: 30px;left: 43px;font-family: 'SourceHanSansCN-Regular';">
                您的资料已提交审核，请耐心等待
            </div>
            <div id="register_time" class="positionA font13 color99 fontfalar" style="top: 6px;right: 15px;"></div>
        </li>
        <li class="positionR refuse_no" style="height: 80px;display: none">
            <img class="positionA" src="../image/jiupian/shenhedian.png" alt="" style="width: 10px;top:10px;left: 15px;">
            <div class="positionA font13 color22" style="top: 6px;left: 43px;font-family: 'SourceHanSansCN-Regular';">
                审核拒绝
            </div>
            <div id="merchant_refuse" class="positionA font13"
                 style="top: 30px;left: 43px;font-family: 'SourceHanSansCN-Regular';color: red;"></div>
            <div id="audit_time" class="positionA font13 color99 fontfalar" style="top: 6px;right: 15px;"></div>
        </li>
        <li class="positionA backBA line_no" style="width: .5px;height: 66px;left: 20px;top: 22px;display: none">&nbsp;
        </li>
    </ul>

    <div class="mui-button-row register-btn-box" style="display: none">
        <button id="btn_submit" type="button" class="mui-btn register-btn mui-btn-main mui-btn-block btnMall">重新提交
        </button>
    </div>


</div>
<script src="../js/require.js"></script>
<script src="../js/require.config.js"></script>
<script>
    require(['mui', 'jquery', 'ajax'], function (Mui, $, Ajax) {
        Ajax.appAjax({
            url: baseUrl + 'jiupian/api/mall.php', // 请求地址,
            // url: DOMAIN_URL + 'mall.php', // 请求地址,
            needLogin: false,
            data: {
                c: 'getRefuseInfo'
            },
            success: function (e) {
                console.log(e);
                if (e.success) {
                    if (e.data.is_refuse == "1") {
                        $(".refuse_no").show();
                        $(".line_no").show();
                        $(".register-btn-box").show();
                        $("#merchant_refuse").html(e.data.merchant_refuse);
                        $("#register_time").html(timetrans(e.data.register_time));
                        $("#audit_time").html(timetrans(e.data.audit_time));

                        $("#btn_submit").click(function () {
                            window.location.href = "./submitDataAgent.php";

                        })
                    }
                } else {
                    Mui.toast(e.msg);
                }
            },
            error: function (e) {
                console.log(e);
            }
        });
        shareObj(getStringByConfig("share_title"), baseUrl + projectName + '/login/register.php?sing=' + getCache("_phone"), IMG_CDN + getStringByConfig("logo"), getStringByConfig("share_subtitle"));


    })
</script>
</body>
</html>