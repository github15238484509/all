<?php
include_once '../share.php';
require_once './../templ/head.php';
?>
<body class="mui-ios mui-ios-11 mui-ios-11-0 order-list-page">
<header class="mui-bar mui-bar-nav">
    <a class="mui-action-back mui-icon mui-icon-arrowthinleft mui-pull-left"></a>
    <h1 class="mui-title fsz-large">我的体系会员</h1>
</header>
<div class="mui-content drawings">

    <ul class="J_goods-list"></ul>

    <script type="x-tmpl-mustache" id="J_RecordsListTmpl">
        <li class="backWhite positionR" style="margin: 10px;height: 97px;">
            <img class="positionA" src="{{photos}}" style="left: 10px;top: 10px;width:40px;border-radius:50%;">
            <div class="fontfa10 color22 font15 positionA"
                 style="left: 65px;top: 10px;">{{name}}
            </div>
            <div class="positionA fontfaW3 color66 font13" style="left: 65px;top: 30px;">{{regtimes}}</div>
            <div class="positionA fontfaW3 color66 font13" style="left: 65px;bottom: 10px;">消费数据： </div>
            <div class="positionA fontfaW3 color22 font12" style="top: 10px;right: 10px;">{{phone}}</div>
            <div class="positionA fontfaW3 color22 font12" style="bottom: 10px;right: 10px;font-family:'DIN Next LT Pro'">{{total_out_cashs}}</div>
        </li>
    </script>
</div>
<script src="../js/require.js"></script>
<script src="../js/require.config.js"></script>
<script>
    require(['mui', 'jquery', 'ajax', "list"], function (Mui, $, Ajax, List) {


        function initGoodsList() {
            var oListOptions = {
                needLogin: false,
                selector: '.J_goods-list',
                url: baseUrl + 'jiupian/api/mall.php?c=merchantUser&page=0&p=jiupian&device=0', // 请求地址,
                data: {
                    'photos': function () {
                        if (this['photo'].slice(0, 4) !== "http") {
                            return IMG_CDN + this['photo'];
                        } else {
                            return this['photo'];
                        }
                    },
                    'regtimes': function () {
                        return timetrans(this['regtime']) ;
                    },
                    'total_out_cashs': function () {
                        return setMoney(this['total_out_cash']);
                    }
                },
                template: $('#J_RecordsListTmpl').html(), // 渲染模板,
                dataList: 'list',
                refresh: true,
                success: function (e, _list) {
                    console.log(e);

                }
            };
            var oList = List.init(oListOptions);
        }

        initGoodsList();

        shareObj(getStringByConfig("share_title"), baseUrl + projectName + '/login/register.php?sing=' + getCache("_phone"), IMG_CDN + getStringByConfig("logo"), getStringByConfig("share_subtitle"));

    })
</script>
</body>