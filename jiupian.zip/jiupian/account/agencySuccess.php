<?php
include_once '../share.php';
include_once '../templ/head.php';


?>
<body class="mui-ios mui-ios-11 mui-ios-11-0">
<link rel="stylesheet" href="../js/mui-picker/mui.picker.min.css">
<header class="mui-bar mui-bar-nav certification-head">
    <a href="#" onclick="javascript:history.back(-1);"
       class="mui-action-back mui-icon mui-icon-arrowthinleft mui-pull-left certification-white"></a>
    <h1 class="mui-title fsz-large">我的代理</h1>
</header>
<div class="mui-content div-data">
    <div class="div-certification"></div>
    <div id="certification" class="certification-content" style="display: none;">
        <div>信息已提交，请耐心等待1-3个工作日</div>
        <div>客服热线：<span class="spanPhone"></span></div>
        <img id="head_img1" src="">
    </div>
    <div id="loseCertification" class="certification-content" style="display: none;">
        <div>审核未通过，请重新提交</div>
        <div>客服热线：<span class="spanPhone"></span></div>
        <img id="head_img3" src="">

        <div class="mui-button-row register-btn-box">
            <button id="land" type="button" class="mui-btn register-btn mui-btn-main mui-btn-block btnMall">重新提交
            </button>
        </div>
    </div>
    <script src="../js/conf.js"></script>
    <script src="../js/require.js"></script>
    <script src="../js/require.config.js"></script>
    <script src="../js/libs/app.js"></script>
    <script>
        require(['mui', 'ajax', 'picker'], function (Mui, Ajax) {
            mui.init();

            var servicePhone = getStringByConfig("service_phone");
            $(".spanPhone").html(servicePhone);
            var loginToken = getCookie("jiupian_token");
            var agent_status = getCache("_agent_status");
            var photo;
            if( getCache("_photo").slice(0,4) !== "http" ){
                photo = IMG_CDN+getCache("_photo")
            }else{
                photo = getCache("_photo")
            }
            console.log(agent_status);
            switch (agent_status) {
                case "0":
                    $("#certification").css("display", "block");
                    $("#loseCertification").css("display", "none");
                    $("#head_img1").attr("src", photo);
                    break;
                case "1":
                    window.location.href = "/jiupian/account/agencyCenter.php";
                    break;
                case "-1":
                    $("#certification").css("display", "none");
                    $("#loseCertification").css("display", "block");
                    $("#head_img3").attr("src", photo);
                    break;
                default:
                    return thisConfirm("请填写资料!", "提示", ["取消", "确定"], function () {
                        window.location.href = "/jiupian/account/submitDataAgent.php";
                    });
            }

            $("#land").click(function () {
                window.location.href = "/jiupian/account/submitDataAgent.php";

            });

            function headSize() {
                var headLeft = ($("#certification").width() - $("#head-img").width()) / 2;
                $("#head_img1").css("left", headLeft);
                $("#head_img2").css("left", headLeft)
            }

            $(window).resize(function () {
                headSize();
            });
            shareObj(getStringByConfig("share_title"), baseUrl + projectName + '/login/register.php?sing=' + getCache("_phone"), IMG_CDN + getStringByConfig("logo"), getStringByConfig("share_subtitle"));
        });

    </script>
</div>
</body>
</html>
