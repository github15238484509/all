<?php

use HoloPHP\wechat\tools\WxPage;

include_once '../share.php';

require_once '../baseConfig.php';
if (WxPage::system() == "wx") {
    if ($_REQUEST["state"] == "jianyunkeji" && $_REQUEST["code"]) {
        $openid = WxPage::getWechatOpenIdByCode($_REQUEST["code"]);
    } elseif (!$openid || $openid == "") {
        WxPage::getOpenId();
    }
} else {
    $openid = "";
}

use tools\Tools;

include_once '../templ/head.php'; ?>
<div class="mui-content register">
    <p hidden id="wechat_openid"><?php echo $openid ?></p>
    <header class="mui-bar mui-bar-nav">
        <a href="javascript:history.back(-1)" class="mui-icon mui-icon-arrowthinleft mui-pull-left"></a>
        <h1 class="mui-title fsz-large">修改密码</h1>
    </header>
    <div class="mui-content">
        <div class="pm20"></div>
        <form class="mui-input-group">
            <div class="mui-input-row">
                <div style="height: 40px;min-height: 40px;max-height: 40px;"></div>
                <div style="padding-left: 15px;font-size: 16px;color: #222222;font-family: 'HiraginoSansGB-W3';padding-bottom: 10px;">
                    手机号：
                </div>
                <input id="phone" type="number" placeholder="输入手机号" style="margin-top: 0 !important;">
                <button id="phoneCodeBtn" type="button"
                        class="mui-btn mui-btn-main sent-sms-btn" style="border: none;">获取验证码
                </button>
            </div>
            <div style="height: 30px;min-height: 30px;max-height: 30px;"></div>
            <div class="mui-input-row">
                <div style="padding-left: 15px;font-size: 16px;color: #222222;font-family: 'HiraginoSansGB-W3';padding-bottom: 10px;">
                    验证码：
                </div>
                <input id="phoneCode" type="text" placeholder="输入验证码" style="margin-top: 0 !important;">
            </div>
            <div style="height: 30px;min-height: 30px;max-height: 30px;"></div>
            <div class="mui-input-row">
                <div style="padding-left: 15px;font-size: 16px;color: #222222;font-family: 'HiraginoSansGB-W3';padding-bottom: 10px;">
                    新密码：
                </div>
                <input id="login_psw" type="password" placeholder="请输入您的新密码" style="margin-top: 0 !important;">
            </div>
            <div style="height: 30px;min-height: 30px;max-height: 30px;"></div>
            <div class="mui-input-row">
                <div style="padding-left: 15px;font-size: 16px;color: #222222;font-family: 'HiraginoSansGB-W3';padding-bottom: 10px;">
                    确认密码：
                </div>
                <input id="login_psw1" type="password" placeholder="请再次输入密码" style="margin-top: 0 !important;">
            </div>
            <div class="pm30"></div>
            <div class="mui-button-row register-btn-box" style="padding: 0 15px 0 15px !important;">
                <button id="land" type="button"
                        class="mui-btn register-btn mui-btn-main mui-btn-block btnMall">确定
                </button>
            </div>
        </form>
    </div>

    <!--    <script type="text/javascript"-->
    <!--            src="http://res.wx.qq.com/open/js/jweixin-1.2.0.js"></script>-->
    <script src="../js/libs/app.js"></script>
    <script src="../js/require.js"></script>
    <script src="../js/require.config.js"></script>
    <script>
        require(['mui', 'jquery', 'ajax', 'sms', 'verify', 'md5'], function (Mui, $, Ajax, SMS, Verify, MD5) {
            var $phone = $("#phone");
            var $phoneCode = $("#phoneCode");
            var $phoneCodeBtn = $('#phoneCodeBtn');
            var loginToken = getCookie("jiupian_token");
            $("#phone").val(getCache("_phone")).attr("disabled","true");
            if (!isEmpty($("#wechat_openid").html())) {
                setCookie("openID", $("#wechat_openid").html(), 7);
            }

            $("#land").click(function () {
                if (!Verify.checkForm($phone, Verify.Phone) || !Verify.checkForm($phoneCode, Verify.SmsCode)) {
                    return false;
                }
                if (!Verify.checkForm($("#login_psw"), Verify.Pwd)) {
                    return false;
                }
                if ($("#login_psw").val() !== $("#login_psw1").val()) {
                    return Mui.toast("两次密码不一致！");
                }
                loginForPhoneCode();
            });

            $(".go-register,#go_reg").click(function () {
                if (getPValue("goods_index") || getPValue("sing")) {
                    window.location.href = "register.php?goods_index=" + getPValue("goods_index") + '&sing=' + getPValue("sing");
                } else {
                    window.location.href = "register.php";
                }
            });

            $("#go_psw").click(function () {
                if (getPValue("goods_index") || getPValue("sing")) {
                    window.location.href = "pswLogin.php?goods_index=" + getPValue("goods_index") + '&sing=' + getPValue("sing");
                } else {
                    window.location.href = "pswLogin.php";
                }
            });

            console.log(getPValue("from"));


            function loginForPhoneCode() {
                Ajax.appAjax({
                    url: baseUrl + 'jiupian/api/mall.php', // 请求地址,
                    // url: DOMAIN_URL + 'mall.php', // 请求地址,
                    needLogin: false,
                    data: {
                        c: 'resetLoginPassword',
                        phone: $phone.val(),
                        phone_code: $phoneCode.val(),
                        new_login_password: MD5($("#login_psw").val()),
                        type: "1"
                    },
                    success: function (e) {
                        console.log(e);
                        if (e.success) {
                            Mui.toast(e.msg);
                            Ajax.appAjax({
                                url: baseUrl + 'jiupian/api/mall.php', // 请求地址,
                                // url: DOMAIN_URL + 'mall.php', // 请求地址,
                                needLogin: false,
                                data: {
                                    c: 'loginOut',
                                    token: loginToken,
                                    device: 0
                                },
                                success: function (e) {
                                    console.log(e);
                                    if (e.success) {
                                        setCookie("jiupian_token", "");
                                        setTimeout(function () {
                                            window.location.href = "/jiupian/login/pswLogin.php";
                                        }, 500)
                                    }
                                },
                                error: function (e) {
                                    console.log(e);
                                }
                            });
                        } else {
                            Mui.toast(e.msg);
                        }
                    },
                    error: function (e) {
                        console.log(e);
                    }
                });
            }

            SMS.init($phoneCodeBtn, $phone, {
                $smsCode: $phoneCode,
                url: baseUrl + '/jiupian/api/mall.php?c=applyPhoneCode',
                data: {verify_type: '7'}
            });

            shareObj(getStringByConfig("share_title"), baseUrl + projectName + '/login/register.php?sing=' + getCache("_phone"), IMG_CDN + getStringByConfig("logo"), getStringByConfig("share_subtitle"));

            $("#old_login").click(function () {
                window.location.href = "../member/oldLogin.php";
            })
        })
    </script>
</div>

