<?php
include_once '../share.php';
require_once './../templ/head.php';
?>
<body class="mui-ios mui-ios-11 mui-ios-11-0">
<header class="mui-bar mui-bar-nav">
    <a href="/jiupian/member/userInfo.php" class="mui-icon mui-icon-arrowthinleft mui-pull-left"></a>
    <h1 class="mui-title fsz-large">账号与安全</h1>
</header>
<div class="mui-content account">
    <ul class="mui-table-view">
<!--        <li class="mui-table-view-cell">-->
<!--            <h4>支付密码</h4>-->
<!--            <p>6位数字更安全快捷</p>-->
<!--            <span class="cell-right-btn"><span id="padStatus"></span></span>-->
<!--        </li>-->
<!--        <li class="mui-table-view-cell">-->
<!--            <h4>重置支付密码</h4>-->
<!--            <p>支付更方便</p>-->
<!--        </li>-->
        <li id="setPhones" class="mui-table-view-cell">
            <!--            <a class="mui-navigate-right" href="/jiupian/account/setPhone.php">-->
            <h4>修改手机号</h4>
            <p>登录更方便快捷</p>
            <!--            </a>-->
        </li>
        <li class="mui-table-view-cell">
            <!--            <a class="mui-navigate-right" href="/jiupian/account/remLogionPsws.php">-->
            <h4>设置登录密码</h4>
            <p>更安全快捷</p>
            <span class="cell-right-btn"><span id="pswStatus"></span></span>
            <!--            </a>-->
        </li>
        <li class="mui-table-view-cell">
            <!--            <a class="mui-navigate-right" href="/jiupian/account/remLogionPsw.php">-->
            <h4>修改登录密码</h4>
            <p>登录更加简单</p>
            <!--            </a>-->
        </li>
    </ul>
</div>
<script src="../js/libs/app.js"></script>
<script src="../js/require.js"></script>
<script src="../js/require.config.js"></script>
<script>
    require(['mui', 'jquery', "ajax"], function (Mui, $, Ajax) {
        var loginToken = getCookie("jiupian_token");
        loginForPhoneCode();


        function loginForPhoneCode() {
            Ajax.appAjax({
                url: baseUrl + 'jiupian/api/mall.php', // 请求地址,
                // url: DOMAIN_URL + 'mall.php', // 请求地址,
                needLogin: true,
                data: {
                    c: 'get_user_info',
                    token: loginToken
                },
                success: function (e) {
                    console.log(e);
                    if (e.success) {
                        if (isEmpty(e.data.userinfo.phone)) {
                            $("#setPhones").hide();
                        }
                        if (!e.data.userinfo.pay_password) {
                            $("#padStatus").html("未设置");
                        } else {
                            $("#padStatus").html("已设置");
                        }
                        if (!e.data.userinfo.login_password) {
                            $("#pswStatus").html("未设置");
                        } else {
                            $("#pswStatus").html("已设置");
                        }

                        $(".mui-table-view-cell").click(function () {
                            var setStatus = $(this).find("h4").html();
                            switch (setStatus) {
                                case "支付密码":
                                    if (e.data.userinfo.pay_password) {
                                        Mui.toast("支付密码已设置");
                                    } else {
                                        window.location.href = "/jiupian/account/payPwd.php";
                                    }
                                    break;
                                case "重置支付密码":
                                    window.location.href = "/jiupian/account/payPwd.php";
                                    break;
                                case "修改手机号":
                                    window.location.href = "/jiupian/account/setPhone.php";
                                    break;
                                case "设置登录密码":
                                    if (e.data.userinfo.login_password) {
                                        Mui.toast("登录密码已设置");
                                    } else {
                                        window.location.href = "/jiupian/account/remLogionPsws.php";
                                    }
                                    break;
                                case "修改登录密码":
                                    if (isEmpty(e.data.userinfo.phone)) {
                                        Mui.confirm("尚未绑定手机号，是否前去绑定？", "提示", ["取消", "去绑定"], function (res) {
                                            if (res.index == 1) {
                                                window.location.href = "/jiupian/member/setPhone.php";
                                            }
                                        });
                                    } else {
                                        if (!e.data.userinfo.login_password) {
                                            Mui.toast("登录密码未设置，请先设置登录密码")
                                        } else {
                                            window.location.href = "/jiupian/account/remLogionPsw.php";
                                        }
                                    }
                                    break;

                            }
                        });

                    } else {
                        Mui.toast(e.msg);
                    }
                },
                error: function (e) {
                    console.log(e);
                }
            });
        }


        shareObj(getStringByConfig("share_title"), baseUrl + projectName + '/login/register.php?sing=' + getCache("_phone"), IMG_CDN + getStringByConfig("logo"), getStringByConfig("share_subtitle"));


    })
</script>
</body>
</html>