<script>
	export default {
		onLaunch: function() {
			console.log('App Launch')
		},
		onShow: function() {
			console.log('App Show')
		},
		
		onHide: function() {
			console.log('App Hide')
		},
		

	}
</script>

<style lang="scss">
	/* 注意要写在第一行，同时给style标签加入lang="scss"属性 */
	@import "uview-ui/index.scss";

	/*每个页面公共css */
	/* 按钮蓝底白字 */
	/* page{
	                background-color: red;
	        } */
	.imgsss {
		width: 100%;
	}

	.xbtn-blue {
		width: 690rpx;
		height: 90rpx;

		background: #F87897;
		color: #FFFFFF;
		text-align: center;
		line-height: 90rpx;
		font-size: 36rpx;
		border-radius: 10rpx;
	}

	/* 白底按钮 */
	.xbtn-white {
		width: 690rpx;
		height: 90rpx;
		background-color: #FFFFFF;
		color: #4794FF;
		border: 1rpx solid #4794FF;
		border-radius: 10rpx;
		text-align: center;
		line-height: 90rpx;
		font-size: 36rpx;

	}

	/* 高度90 between对齐 带下边框 */
	.xline-bet {
		height: 90rpx;
		display: flex;
		align-items: center;
		justify-content: space-between;
		border-bottom: 1rpx solid #F5F5F5;
	}

	/* 高度90 between对齐 不带下边框  用于末尾元素*/
	.xline-bet-end {
		height: 90rpx;
		display: flex;
		align-items: center;
		justify-content: space-between;
	}

	.xblack {
		color: #333333;
	}

	.xgray {
		color: #666666;
	}

	.xline {
		width: 100%;
		height: 1rpx;
		background-color: #F5F5F5
	}

	.xline20 {
		width: 100%;
		height: 20rpx;
		background-color: #F5F5F5
	}

	.xbt {
		display: flex;
		align-items: center;
		justify-content: space-between;
	}

	.xev {
		display: flex;
		align-items: center;
		justify-content: space-evenly;
	}

	.xal {
		display: flex;
		align-items: center;

	}

	.xflex {
		display: flex;
	}
</style>
