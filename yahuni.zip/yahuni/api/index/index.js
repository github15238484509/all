import request from '@/api/request.js';

// 首页轮播图 
function banner(data) {
	return request({
		url: '/index/banner',
		method: 'post',
		data
	})
}

// 首页消息轮转 
function news(data) {
	return request({
		url: '/index/news',
		method: 'post',
		data
	})
}

// 课程列表 
function goods_list(data) {
	return request({
		url: '/goods/goods_list',
		method: 'post',
		data
	})
}

// 搜索 
function search_goods(data) {
	return request({
		url: '/goods/search_goods',
		method: 'post',
		data
	})
}

// 历史搜索 
function user_search(data) {
	return request({
		url: '/index/user_search',
		method: 'post',
		data
	})
}

// 删除历史搜索记录 
function user_search_empty(data) {
	return request({
		url: '/index/user_search_empty',
		method: 'post',
		data
	})
}

// 课程详情
function goods_details(data) {
	return request({
		url: '/goods/goods_details',
		method: 'post',
		data
	})
}

//添加取消收藏
function add_collection(data) {
	return request({
		url: '/goods/add_collection',
		method: 'post',
		data
	})
}

//评价列表
function goods_comment_list(data) {
	return request({
		url: '/goods/goods_comment_list',
		method: 'post',
		data
	})
}

//课程视频列表
function goods_video_list(data) {
	return request({
		url: '/goods/goods_video_list',
		method: 'post',
		data
	})
}

//分享二维码
function share_goods(data) {
	return request({
		url: '/goods/share_goods',
		method: 'post',
		data
	})
}

//获取用户邀请的人数 
function user_invite(data) {
	if (!data) {
		data =  {
			page: "1"
		}
	}
	return request({
		url: '/user/user_invite',
		method: 'get',
		data: data
	})
}
//面对面邀请图片
function my_invitation() {
	return request({
		url: '/user/my_invitation',
		method: 'get',
		data: {}
	})
}
//首页消息轮转
function index_news(data) {
	return request({
		url: '/index/news',
		method: 'post',
		data
	})
}
//视频详情增加播放量
function goods_video_info(data) {
	return request({
		url: '/goods/goods_video_info',
		method: 'post',
		data
	})
}

//消息和帮助中心增加浏览记录
function browsingHistory(data) {
	return request({
		url: '/app/browsingHistory',
		method: 'post',
		data
	})
}



export default {
	
	banner,
	news,
	goods_list,
	search_goods,
	user_search,
	user_search_empty,
	goods_details,
	add_collection,
	goods_comment_list,
	goods_video_list,
	share_goods,
	user_invite,
	my_invitation,
	index_news,
	goods_video_info,
	browsingHistory
}

