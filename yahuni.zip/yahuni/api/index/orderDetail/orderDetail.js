import request from '@/api/request.js';
//订单详情
function order_details(data){
	return request({
		url: '/order/order_details',
		method: 'post',
		data
	})
}

//删除订单
function delete_orders(data){
	return request({
		url: '/order/delete_orders',
		method: 'post',
		data
	})
}
//取消订单和立即学习
function cancel_orders(data){
	return request({
		url: '/order/cancel_orders',
		method: 'post',
		data
	})
}

//确认订单
function confirm_order(data){
	return request({
		url: '/order/confirm_order',
		method: 'post',
		data
	})
}

//提交订单
function establish_order(data){
	return request({
		url: '/order/establish_order',
		method: 'post',
		data
	})
}

//订单查询邀请人
function my_invite(data){
	return request({
		url: '/user/my_invite',
		method: 'post',
		data
	})
}

//支付订单
function payment_orders(data){
	return request({
		url: '/PayController/payment_orders',
		method: 'post',
		data
	})
}

//浏览列表
function test(data){
	return request({
		url: '/order/payment_orders',
		method: 'post',
		data
	})
}
//立即评价
function order_evaluate(data){
	return request({
		url: '/order/order_evaluate',
		method: 'post',
		data
	})
}

//确认支付接口
function confirm_pay(data){
	return request({
		url: '/PayController/confirm_pay',
		method: 'post',
		data
	})
}
//wx支付成功
function wxpay_success(data){
	return request({
		url: '/PayController/wxpay_success',
		method: 'post',
		data
	})
}


export default{
	order_details,
	delete_orders,
	cancel_orders,
	confirm_order,
	establish_order,
	my_invite,
	payment_orders,
	test,
	confirm_pay,
	wxpay_success,
	order_evaluate
	
}