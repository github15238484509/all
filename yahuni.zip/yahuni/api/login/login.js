import request from '@/api/request.js';
//获取微信授权信息
function get_wechat(data) {
	return request({
		url: '/login/get_wechat',
		method: 'get',
		data
	})
}
//解密手机号
function getWxphone(data){
	return request({
		url: '/login/getWxphone',
		method: 'get',
		data
	})
}
//微信授权登陆接口
function wechat_login(data){
	return request({
		url: '/login/wechat_login',
		method: 'get',
		data
	})
}
//获取个人信息
function get_user_info(data){
	return request({
		url: '/login/get_user_info',
		method: 'post',
		data
	})
}
//修改个人信息
function set_user_edit(data){
	return request({
		url: '/user/set_user_edit',
		method: 'post',
		data
	})
}
//修改个人信息
function aboutWe(data){
	return request({
		url: '/user/aboutWe',
		method: 'post',
		data
	})
}
function binding(data){
	return request({
		url: '/login/binding',
		method: 'post',
		data
	})
}
function my_invite(data){
	return request({
		url: '/user/my_invite',
		method: 'post',
		data
	})
}

export default{
	my_invite,
	binding,
	get_wechat,
	getWxphone,
	wechat_login,
	set_user_edit,
	get_user_info,
	aboutWe
}
