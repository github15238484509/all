import request from '@/api/request.js';
function cart_list(data){
	return request({
		url: '/cart/cart_list',
		method: 'post',
		data
	})
}

function add_cart(data){
	return request({
		url: '/cart/add_cart',
		method: 'post',
		data
	})
}

function edit_cart(data){
	return request({
		url: '/cart/edit_cart',
		method: 'post',
		data
	})
}

function delete_cart(data){
	return request({
		url: '/cart/delete_cart',
		method: 'post',
		data
	})
}

function cart_confirm_order(data){
	return request({
		url: '/order/cart_confirm_order',
		method: 'post',
		data
	})
}
function cart_establish_order(data){
	return request({
		url: '/order/cart_establish_order',
		method: 'post',
		data
	})
}

export default {
	cart_establish_order,
	cart_confirm_order,
	cart_list,
	add_cart,
	edit_cart,
	delete_cart
}