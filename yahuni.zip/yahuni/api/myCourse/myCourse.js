import request from '@/api/request.js';
function user_order_list(data){
	return request({
		url: '/order/user_order_list',
		method: 'post',
		data
	})
}
function edit_orders(data){
	return request({
		url: '/order/edit_orders',
		method: 'post',
		data
	})
}
function order_details(data){
	return request({
		url: '/order/order_details',
		method: 'post',
		data
	})
}
function refund_orders(data){
	return request({
		url: '/PayController/refund_orders',
		method: 'post',
		data
	})
}
function confirm_pay(data){
	return request({
		url: '/PayController/confirm_pay',
		method: 'post',
		data
	})
}
function order_evaluate(data){
	return request({
		url: '/order/order_evaluate',
		method: 'post',
		data
	})
}
function search_express(data){
	return request({
		url: '/order/search_express',
		method: 'post',
		data
	})
}


export default {
	search_express,
	order_evaluate,
	user_order_list,
	edit_orders,
	order_details,
	refund_orders,
	confirm_pay
}