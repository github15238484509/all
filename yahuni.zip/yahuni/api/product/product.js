import request from '@/api/request.js';
function goods_partition(data){
	return request({
		url: '/goods/goods_partition',
		method: 'post',
		data
	})
}
function goods_list(data){
	return request({
		url: '/goods/goods_list',
		method: 'post',
		data
	})
}


export default {
	goods_list,
	goods_partition
}