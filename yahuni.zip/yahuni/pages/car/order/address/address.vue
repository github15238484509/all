<template>
	<view>
		<view class="content" v-for="(item,index) in list" :key="index"
			style="border-top: 2rpx solid #F5F5F5;padding: 30rpx;">
			<view class="top" style="border-bottom: 2rpx solid #F5F5F5;" @click="toOrder(item)">
				<view class="top-t">
					<view class="text">
						{{item.contacts}}
					</view>
					<view class="text" style="margin-left: 45rpx;">
						{{item.phone}}
					</view>
				</view>
				<view class="top-b" style="margin-top: 22rpx;margin-bottom: 30rpx;">
					{{item.address}}
				</view>
			</view>
			<view class="bottom">
				<view class="left">
					<u-radio-group v-model="value" @change="radioGroupChange">
						<u-radio active-color="#F87897" @change="radioChange" :name="item.index">
							默认地址
						</u-radio>
					</u-radio-group>

				</view>
				<view class="right">
					<image src="../../../../static/my/bianji.png"
						style="width: 36rpx;height: 36rpx;margin-left: 250rpx;"></image>
					<view class="" style="margin-left: 13rpx;" @click="edit(item.index)">
						编辑
					</view>
					<image src="../../../../static/my/shanchu.png"
						style="width: 36rpx;height: 36rpx;margin-left: 40rpx;margin-right: 10rpx;"></image>
					<view class="" @click="del(item.index)">
						删除
					</view>
				</view>
			</view>
		</view>
		<view style="text-align: center;margin-top: 190rpx;" v-if="list.length==0" class="center">
			<image src="../../../../static/noAdressPic.png" class="img123" style="width: 445rpx;height: 435rpx;">
			</image>
			<view class="text">
				您还没有收货地址哦~
			</view>
		</view>
		<view class="" style="width: 100%;height: 150rpx;">

		</view>
		<view>
			<view class="sureBind" @click="add">
				新增收货地址
			</view>
		</view>
	</view>
</template>

<script>
	import addressApi from "../../../../api/my/my.js"
	import myApi from "../../../../api/my/my.js"
	export default {
		data() {
			return {
				page: 1,
				count: 10,
				list: [],
				value: "",
				//判断是否是从订单跳转而来
				order: "",
				editAddress: {}
			}
		},
		onShow() {
			this.init()
		},
		onLoad(el) {
			console.log(el);

			if (el.editAddress) {
				let editAddress = JSON.parse(decodeURIComponent(el.editAddress));
				this.editAddress = editAddress
			}

		},
		onShareAppMessage: function(options) {
			return {
				title: '源爱汇',
				path: '/page/index/index',
				success: function(res) {
					// 转发成功
				},
				fail: function(res) {
					// 转发失败
				}		
			}		
		},
		methods: {
			toOrder(el) {
				console.log(el);
				
				this.editAddress.address_id = el.index
				this.editAddress.contacts = el.contacts
				this.editAddress.phone = el.phone
				this.editAddress.address = el.address
				uni.setStorageSync("carAddress", JSON.stringify(this.editAddress));
				uni.navigateTo({
					url: "../order"
				})
			
		},
		init() {
			addressApi.user_address({
				page: this.page,
				count: this.count
			}).then(res => {
				console.log(res)
				if (res.status == 200) {
					this.list = res.result
					if(this.list.length>0){
						let item = this.list.find(el => {
							return el.default_address == '1'
						})
						
						this.value = item.index
					}
					



				} else {
					uni.showToast({
						title: res.message,
						icon: 'none'
					})
				}
			})


		},
		add() {
			console.log(1);
			uni.navigateTo({
				url: "./add/add"
			})
		},
		// 选中某个单选框时，由radio时触发
		radioChange(e) {
			// console.log(e);
		},
		// 选中任一radio时，由radio-group触发
		radioGroupChange(e) {
			console.log(e);
			myApi.edit_address({
				index: e,
				type: "1"
			}).then(res => {
				console.log(res)
				if (res.status == 200) {

				} else {
					// uni.showToast({
					// 	title: res.message,
					// 	icon: 'none'
					// })
				}
			})
		},
		edit(id) {
			uni.navigateTo({
				url: "add/add?id=" + id
			})
		},
		del(e) {
			let this_ = this
			uni.showModal({
				title: '删除地址',
				content: '您确认要删除此地址吗',
				success: function(res) {
					if (res.confirm) {
						console.log('用户点击确定');
						myApi.edit_address({
							index: e,
							type: "2"
						}).then(res => {
							console.log(res)
							if (res.status == 200) {
								this_.init()
							} else {
								uni.showToast({
									title: res.message,
									icon: 'none'
								})
							}
						})
					} else if (res.cancel) {
						console.log('用户点击取消');
						uni.showToast({
							title: "取消成功",
							icon: 'none'
						})
					}
				}
			});

		}

	}
	}
	
</script>

<style>
	page {
		background-color: #F5F5F5;
	}
</style>
<style lang="scss" scoped>
	.center {
		.text {
			margin-top: 86rpx;


			font-size: 30rpx;
			font-family: PingFang SC;
			font-weight: 400;
			color: #999999;
		}
	}

	.sureBind {
		width: 690rpx;
		height: 90rpx;
		background: #F87897;
		border-radius: 20rpx;
		margin: 50rpx 30rpx 0;
		line-height: 90rpx;
		text-align: center;
		color: #fff;
		font-size: 30rpx;
		position: fixed;
		bottom: 33rpx;
	}

	.content {
		width: 750rpx;
		height: 250rpx;
		background: #FFFFFF;

		.top-t {
			display: flex;
			justify-content: flex-start;

			font-size: 30rpx;
			font-family: PingFang SC;
			font-weight: 500;
			color: #333333;

			.text {
				font-size: 26rpx;
				font-weight: 400;
			}
		}

		.bottom {
			display: flex;
			justify-content: flex-start;
			align-items: center;
			margin-top: 18rpx;

			.left {
				display: flex;
				justify-content: flex-start;
				align-items: center;
			}

			.right {
				display: flex;
				justify-content: flex-start;
				align-items: center;
			}
		}
	}
</style>
