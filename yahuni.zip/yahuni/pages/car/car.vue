<template>
	<view class="container">

		<view class="status_bar">
			<!-- 这里是状态栏 -->
		</view>
		<view class="page-header">
			<view class="title" v-if="dingWei && cartList.length > 0">
				<!-- <view :class="['title', cartList.length > 0 ? '' : 'text-center']"> -->
				<u-icon name="map" size="32"></u-icon>
				<text style="margin-left: 10rpx;"> {{dingWei}} </text>
			</view>
			<block v-if="cartList.length > 0">
				<view class="edit" v-if="btnType === 'edit'" @click="toEdit">编辑</view>
				<view class="edit" v-if="btnType === 'done'" @click="hasDone">完成</view>

			</block>
		</view>
		<!-- <u-checkbox-group> -->
		<view class="cart-box" v-if="cartList.length > 0">
			<!-- 下面注掉的是左滑删除 如果后期需要 可以放开   底部还有一个结尾标签也注掉了-->
			<!--  <u-swipe-action
                :show="item.show"
                :disabled="swipeAction"
                btn-width="160"
                :index="index"
                v-for="(item, index) in cartList"
                :key="item._id"
                @click="throttle(actionClick($event, item._id),2000)"
                @open="actionOpen"
                :options="options"
            > -->
			<view class="item u-border-bottom" v-for="(item, index) in cartList" :key="index">
				<u-checkbox-group @change="checkboxChange" width="36rpx">
					<u-checkbox v-model="cartList[index].check" size="36" shape="circle" active-color="#F87897"
						class="checkbox"></u-checkbox>
				</u-checkbox-group>

				<view class="cart-img">
					<image :src="$imgUrl(item.sku_pic)" @click.stop="gotoDetail(item.goods_index)"></image>
				</view>
				<!-- 此层wrap在此为必写的，否则可能会出现标题定位错误 -->
				<view class="title-wrap" @click.stop="gotoDetail(item.goods_index)">
					<view class="title u-line-1 ">
						<text class="text-type1">
							{{item.zone_name}}
						</text>

						<text>
							{{item.goods_name}}
						</text>

					</view>

					<view class="sku" style="#999999">{{ item.goods_norms }}</view>
					<view class="price">
						¥
						<!-- <text class="large">{{ priceInt(item.product.price) }}</text>
                            .{{ priceDecimal(item.product.price) }} -->
						{{$returnFloat(item.sku_cost_price)}}
					</view>
				</view>
				<!-- 库存最大值 是下面的max -->
				<view class="num-box">
					<u-number-box v-model="cartList[index].goods_count" :min="1" input-width="100" input-height="50"
						@change="valChange($event,item.cart_index)"></u-number-box>
				</view>



			</view>
			<!-- </u-swipe-action> -->
		</view>
		<view class="page-box1" style="text-align: center;" v-if="cartList.length==0&&isShow">

			<image src="../../static/datanull.png" class="img1"
				style="width: 344rpx;height: 300rpx; margin-top: 50%;margin-left: 0rpx;"></image>
		</view>
		<!-- <u-loadmore bg-color="rgb(240, 240, 240)" :status="loadStatus" @loadmore="addRandomData"></u-loadmore> -->
		<u-gap height="100" bg-color="#fff"></u-gap>
		<view class="bottom" v-if="cartList.length > 0">
			<u-checkbox @change="checkedAll" v-model="checked" size="40" shape="circle" active-color="#F87897"
				class="checkall"><span>全选</span></u-checkbox>
			<text class="price fill" v-if="btnType === 'edit'">
				<text class="sml">合计:</text>
				￥{{ $returnFloat(totalPrice) }}
			</text>
			<view class="settleBtn btn1" v-if="btnType === 'edit'" @click="btnClick('order') ">
				结算
			</view>
			<view class="delBtn btn1" v-if="btnType === 'done'" @click="btnClick('del')">
				删除
			</view>

		</view>
		<u-modal v-model="showModal" :title="title" :content="content" :title-style="titleStyle"
			:content-style="contentStyle" :confirm-style="confirmStyle" :show-cancel-button="true" @confirm="confirm">
		</u-modal>
		<u-toast ref="uToast" />
		<view class="ttttt" v-show="!isShow">
			
			<view class="xbtn-blue" @click="goLogin">
				<text>登录/注册</text>
			</view>
		</view>
	</view>
</template>

<script>
	import carApi from "../../api/car/car.js"
	export default {
		data() {
			return {
				isShow: true,
				loadStatus: 'loadmore',
				cartList: [], //购物车列表
				showModal: false, //modal弹窗
				title: '提示', //弹窗标题
				content: '确认删除商品?', //弹窗内容
				delId: '', //删除id,
				id3: "",
				options: [{
					text: '删除',
					style: {


						//如果需要替换颜色 直接全页面搜索下面的颜色 并批量替换 
						backgroundColor: '#F87897'
					}
				}], //u-swipe-action样式
				btnType: 'edit', //按钮类型
				checked: false, //是否全选
				swipeAction: false, //是否禁止滑动
				// u-button样式
				customStyle: {
					color: '#fff',
					backgroundColor: '#F87897',
					margin: '0',
					padding: '0 20rpx',
					width: '200rpx',
					fontSize: '32rpx'
				},
				customStyle2: {
					color: '#FFFFFF',
					backgroundColor: '#999999',
					margin: '0',
					padding: '0 20rpx',
					border: 'none',
					width: '200rpx',
					fontSize: '32rpx'
				},
				// 模态窗样式
				titleStyle: {
					fontSize: '36rpx'
				},
				contentStyle: {
					fontSize: '36rpx'
				},
				confirmStyle: {
					color: '#fff',
					backgroundColor: '#F87897'
				},
				page: 1,
				count: 10,
				dingWei: ""

			};
		},
		onShareAppMessage: function(options) {		
			return {
				title: '源爱汇',
				path: '/page/index/index',
				success: function(res) {
					// 转发成功
				},
				fail: function(res) {
					// 转发失败
				}		
			}		
		},
		onShow() {
			
			if (!uni.getStorageSync('token')) {
				this.isShow = false
				// console.log("没有登录");
				return;
			}else{
				this.isShow = true
			}
			
			this.checked = false;
			this.getCart();
			console.log(this.cartList);
		},
		computed: {
			// 价格合计
			totalPrice() {
				console.log('totalPrice')
				let sumPrice = 0,
					items = this.cartList;
				items.forEach(val => {
					// let priceVal = parseFloat(val.product.price),
					// 	salesVal = parseFloat(val.product.number);
					let priceVal = parseFloat(val.sku_cost_price),
						salesVal = parseFloat(val.goods_count);
					if (val.check) {
						sumPrice += priceVal * salesVal;
					}
				});
				// sumPrice = sumPrice == 0 ? 0 : sumPrice.toFixed(2);
				let tofixNum = sumPrice.toFixed(2);
				return parseFloat(tofixNum);
			},
			// 数量统计
			totalCount() {
				console.log('totalCount')
				let totalNumber = 0,
					items = this.cartList;
				items.forEach(val => {
					if (val.check) {
						totalNumber += val.goods_count;
					}
				});
				return totalNumber;
			},
			// 价格整数
			priceInt() {
				console.log('priceInt')
				return val => {
					let priceStr = val.toString();
					if (priceStr != parseInt(priceStr)) {
						return priceStr.split('.')[0];
					} else {
						return priceStr;
					}
				};
			},
			// 价格小数
			priceDecimal() {
				console.log('priceDecimal')
				return val => {
					let priceStr = val.toString();
					if (priceStr != parseInt(priceStr)) {
						return priceStr.split('.')[1];
					} else {
						return '00';
					}
				};
			}
		},
		methods: {
			goLogin() {
				console.log(1)
				uni.navigateTo({
					url: '../login/login'
				})
			},
			toEdit() {
				this.$u.throttle(() => {
					this.btnType = 'done';
					this.swipeAction = true;
					let items = this.cartList;
					items.forEach(val => {
						val.show = false;
					});
				}, 1000)
			},
			hasDone() {
				this.$u.throttle(() => {
					this.btnType = 'edit';
					this.swipeAction = false;
				}, 1000)

			},
			// 购物车列表
			getCart() {
				carApi.cart_list({
					page: this.page,
					count: this.count
				}).then(res => {
					console.log(res)
					if (res.status == 200) {
						const resData = res.result.list;
						resData.forEach(val => {
							val.show = false;
							val.check = false;
						});
						this.cartList = resData;
						let str = res.result.addressInfo.province_name
						let str1 = res.result.addressInfo.city_name
						let str2 = res.result.addressInfo.county_name
						this.dingWei = str + str1 + str2
					} else {
						uni.showToast({
							title: res.message,
							icon: 'none'
						})
					}
				})

			},
			// gotoHome() {
			// 	uni.switchTab({
			// 		url: '/pages/index/index'
			// 	});
			// },


			// 删除
			actionClick(index, del) {

				this.showModal = true;
				this.delId = del;
			},
			// 删除确认
			confirm() {
				let _self = this;

				let delArr = [],
					type = _self.btnType,
					items = _self.cartList;

				items.forEach(val => {
					if (val.check) {
						delArr.push(val.cart_index);
					}
				});
				let delArr1 = delArr.toString()
				console.log(delArr1);
				carApi.delete_cart({
					cart_index: delArr1
				}).then(res => {
					console.log(res)
					if (res.status == 200) {
						_self.getCart()
					} else {
						uni.showToast({
							title: res.message,
							icon: 'none'
						})
					}
				})
				_self.btnType = 'edit';


				//为了模拟清空购物车
				if (delArr.length == items.length) {
					_self.cartList = [];
				}

				_self.$refs.uToast.show({
					title: '删除成功',
					icon: false
				});
			},
			// 如果打开一个的时候，不需要关闭其他，则无需实现本方法
			actionOpen(index) {
				// 先将正在被操作的swipeAction标记为打开状态，否则由于props的特性限制，
				// 原本为'false'，再次设置为'false'会无效
				let items = this.cartList;
				items[index].show = true;
				items.forEach((val, idx) => {
					if (index != idx) {
						items[idx].show = false;
					}
				});
			},
			// 跳转详情
			gotoDetail(id) {
				this.$u.throttle(res => {
					uni.navigateTo({
						url: '/pages/index/detail/detail?id=' + id
					})

				}, 2000)

			},
			// 选中商品
			checkboxChange(e) {
				let items = this.cartList;
				let checkedArr = [];
				items.forEach(val => {
					if (val.check) {
						checkedArr.push(val);
					}
				});
				let len = checkedArr.length;
				// 如果选择的数组中有值，并且长度等于列表长度，就是全选
				if (len > 0 && len == items.length) {
					this.checked = true;
				} else {
					this.checked = false;
				}
			},
			// 数量增减
			valChange(e, id) {
				console.log(e, id);
				carApi.edit_cart({
					cart_index: id,
					goods_count: e.value,
				}).then(res => {
					console.log(res)
					if (res.status == 200) {

					} else {
						uni.showToast({
							title: res.message,
							icon: 'none'
						})
					}
				})
			},
			// 全选
			checkedAll() {
				this.checked = !this.checked;
				let flag = this.checked,
					items = this.cartList;
				items.forEach(val => {
					if (flag) {
						val.check = true;
					} else {
						val.check = false;
					}
				});
			},
			// 结算
			btnClick(type) {


				let _self = this;
				switch (type) {
					case 'order':
						this.$u.throttle(() => {
							let items = _self.cartList;
							let checkedArr = [];
							items.forEach(val => {
								if (val.check) {
									checkedArr.push(val.cart_index);
								}
							});
							let shopIds = checkedArr.toString();
							if (!shopIds) {
								_self.$refs.uToast.show({
									title: '请选择要结算的商品!',
									icon: false
								});
								return;
							}
							console.log(shopIds);
							uni.setStorageSync("shopIds", shopIds)
							uni.navigateTo({
								url: './order/order'
							});


						}, 1000)

						break;
					case 'del':
						this.$u.throttle(() => {
							if (!_self.totalCount) {
								_self.$refs.uToast.show({
									title: '请选择要删除的商品!',
									icon: false
								});
								return;
							}
							_self.showModal = true;

						}, 1000)
						break;
				}
			}


		}
	};
</script>

<style lang="scss" scoped>
	// 状态栏占位
	.ttttt {
		.img {
			width: 396rpx;
			height: 343rpx;
			margin-left: 177rpx;
			margin-top: 340rpx;
		}
	
		.xbtn-blue {
			width: 300rpx;
			margin-left: 225rpx;
			margin-top: 450rpx;
		}
	}
	.status_bar {
		background-color: #F87897;
	}

	.page-box1 {
		width: 100%;
		text-align: center;

		.img1 {
			width: 344rpx;
			height: 300rpx;
			// margin-left: 150rpx;
			// margin-top: 360rpx;
			margin-top: 50%;

		}
	}

	.page-header {
		padding: 26rpx 30rpx;
		display: flex;
		position: relative;
		color: #333333;
		font-size: 26rpx;

		.text-center {
			width: 100%;

		}

		.edit {
			position: absolute;
			top: 50%;
			transform: translateY(-50%);
			right: 30rpx;
			font-size: 26rpx;
			color: #F87897;
		}
	}

	.item {
		display: flex;
		justify-content: space-between;
		padding: 20rpx;
		align-items: center;
		position: relative;

		.cart-img {
			width: 200rpx;
			height: 200rpx;
			border-radius: 12rpx;

			// overflow: hidden;
			image {
				width: 200rpx;
				height: 200rpx;
			}
		}

		.num-box {
			position: absolute;
			width: 130rpx;
			height: 50rpx;
			left: 486rpx;
			top: 160rpx;
		}

		.title-wrap {
			width: 440rpx;

			.sku {
				margin: 20rpx 0;
				font-size: 28rpx;
				color: #666;
			}

			.price {
				font-size: 28rpx;
				color: #FF1C1C;
				letter-spacing: 2rpx;

				.large {
					margin-left: 6rpx;
					font-size: 34rpx;

				}
			}

			.clamp {
				overflow: hidden;
				text-overflow: ellipsis;
				white-space: nowrap;
				display: block;
			}

			.title {
				text-align: left;
				font-size: 30rpx;
				color: #333;
				// margin-top: 20rpx;
				line-height: 46rpx;

				.text-type1 {
					// padding:  10rpx  10rpx;
					padding-left: 10rpx;
					padding-right: 10rpx;
					margin-right: 10rpx;
					background-color: #F87897;
					font-size: 22rpx;
					border-radius: 9rpx;
					color: #FFFFFF;
					height: 22rpx;
				}
			}
		}

		// .u-numberbox {
		//     position: absolute;
		//     bottom: 20rpx;
		//     right: 20rpx;
		// }
	}

	// emputy
	.emputy {
		text-align: center;
		margin: 200rpx auto;
		font-size: 32rpx;

		image {
			width: 439rpx;
			height: 270rpx;
			// border-radius: 50%;
			margin-bottom: 20rpx;
		}

		.tips {
			font-size: 24rpx;
			color: #999999;
			margin-top: 20rpx;
		}

		.btn {
			margin: 80rpx auto;
			width: 200rpx;
			border-radius: 32rpx;
			line-height: 64rpx;
			color: #ffffff;
			font-size: 26rpx;
			background: -webkit-linear-gradient(to right, rgba(253, 1, 62, 0.3) 0%, rgba(253, 1, 62, 1) 100%);
			background: linear-gradient(to right, rgba(253, 1, 62, 0.3) 0%, rgba(253, 1, 62, 1) 100%);
		}
	}

	.bottom {

		width: 100%;
		position: fixed;
		left: 0;
		bottom: var(--window-bottom);
		display: flex;
		align-items: center;
		justify-content: flex-end;
		z-index: 99;
		height: 100rpx;
		background-color: #fff;
		box-sizing: border-box;
		// box-shadow: 0 0 10rpx 6rpx rgba(0, 0, 0, 0.1);
		border-top: 1rpx solid #F5F5F5;

		// padding-bottom: constant(safe-area-inset-bottom);
		// padding-bottom: env(safe-area-inset-bottom);
		.checkall {
			position: absolute;
			left: 20rpx;
			top: 50%;
			transform: translateY(-50%);

			span {
				color: #999;
				font-size: 32rpx;
			}
		}

		.price {
			margin-right: 20rpx;
			color:#FF1C1C;
			font-size: 32rpx;

			.sml {
				margin-right: 10rpx;
				color: #666;
				font-size: 36rpx;
			}
		}
	}

	.btn1 {
		width: 200rpx;
		height: 100rpx;
		text-align: center;
		line-height: 100rpx;
		font-size: 30rpx;
		color: #FFFFFF;

	}

	.delBtn {
		background-color: #999999;

	}

	.settleBtn {
		background-color: #F87897;
	}
</style>
