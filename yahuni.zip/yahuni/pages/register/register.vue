<template>
	<view>
		<view style="padding: 0 50rpx;">
			<view class="title">欢迎使用</view>
			<view class=""
				style="display: flex;align-items:center;border-bottom:1px solid #E0E0E0;padding: 20px 0;margin-top: 100rpx;">
				<!-- <image src="../../static/register/user.png" mode="" style="width: 30rpx;height: 38rpx;"></image> -->
				<image src="../../static/user.png" mode="" style="width: 30rpx;height: 38rpx;">
				</image>
				<input class="input" v-model="superior_phone" type="number" value="" placeholder="请输入推荐人的手机号" @input="change" maxlength="11" />
			</view>
			<view class="sj" v-if="shang.name">
				<image :src="$imgUrl(shang.photo)" class="img222"></image>
				<view class="text">
					{{shang.name}}
				</view>
			</view>
			<view @click="register"
				style="width:100%;height:90rpx;background: #F87897;border-radius: 10rpx;color: #fff;text-align: center;line-height: 90rpx;margin:24rpx auto;margin-top: 200rpx;">
				确定
			</view>
		</view>
		
	</view>
</template>
<script>
	import loginApi from "../../api/login/login.js"

	export default {
		data() {
			return {

				objs: {},
				flag: false,
				isSelect: '',
				formData: {
					phone: '',
					openid: '',
					identity_card: '',
					province_id: '',
					city_id: '',
					district_id: '',
					photo: '',
					name: '',
					sex: '',
					unionid: ''
				},
				superior_phone: "",

				cdnUrl: '',
				token:"",
				shang:{},
				phone11:""

			};
		},
		components: {
			// citydata
		},
		onLoad(e) {
			console.log(e);
			this.formData.phone = e.phone;
			this.formData.openid = e.openid;
			this.formData.photo = e.photo;
			this.formData.name = e.name;
			this.formData.sex = e.sex;
			this.formData.unionid = e.unionid;
			this.init()
		},
		onShareAppMessage: function(options) {
			return {
				title: '源爱汇',
				path: '/page/index/index',
				success: function(res) {
					// 转发成功
				},
				fail: function(res) {
					// 转发失败
				}		
			}		
		},
		methods: {
			change(e){
					console.log(e)
					
					if(this.superior_phone.length==11){
						loginApi.my_invite({
							phone:this.superior_phone
						}).then(res => {
						        console.log(res)
						        if (res.status == 200) {
						       
						        this.shang.name=res.result.name
						        this.shang.photo=res.result.photo
								this.phone11=res.result.phone
						        } else {
						                uni.showToast({
						                title: res.message,
						                icon: 'none'
						                })
						        }
						})
						
					}
			},
			init() {
				this.cdnUrl = this.$cdnUrl;
				console.log(this.cdnUrl);

				let self = this;


			},

			register() {
				console.log(123);
				if (!/(^1[3|4|5|6|7|8|9][0-9]{9}$)/.test(this.superior_phone)) {
					uni.showToast({
						title: '请输入正确的手机号码',
						icon: 'none'
					});
					return;
				}
				if (this.phone11=="") {
					uni.showToast({
						title: '没有这个用户',
						icon: 'none'
					});
					return;
				}
				loginApi.binding({
					phone: this.formData.phone,
					openid: this.formData.openid,
					photo: this.formData.photo,
					name: this.formData.name,
					sex: this.formData.sex,
					unionid: this.formData.unionid,
					superior_phone: this.phone11
				}).then(res => {
					console.log(res);
					if (res.status == 200) {
						uni.setStorageSync('token', res.result.token);
						uni.switchTab({
							url: '../my/my',
						})
						
					} else {
						uni.showToast({
							title: res.message,
							icon: 'none'
						})
					}
				})
				
				
			}
		}
	};
</script>

<style scoped lang="scss">
	.footer {
		margin-left: 0rpx;
		margin-right: 0rpx;
		width: 100%;
		position: absolute;
		bottom: 30rpx;
		left: 0;
	}

	.title {
		margin-top: 77rpx;
		font-size: 56rpx;
		font-family: PingFang SC;
		font-weight: bold;
		color: #222222;
	}

	.input {
		flex: 1;
		margin-left: 44rpx;
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #999999;
	}

	.picker-view {
		width: 100%;
		height: 600rpx;
		margin-top: 20rpx;
	}

	.img {
		display: block;
		width: 80rpx;
		height: 80rpx;
		margin: auto;
		box-shadow: 0px 0px 32rpx 0px rgba(166, 166, 166, 0.3);
		border-radius: 15rpx;
		// margin-top: 220rpx;

		image {
			width: 80rpx;
			height: 80rpx;
		}

	}

	.texts {
		text-align: center;
		display: block;
		margin: auto;
		margin-top: 10rpx;
		font-size: 18rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #999999;
	}
	.sj{
		height: 100rpx;
		width: 100%;
		margin-top: 20rpx;
		display: flex;
		align-items: center;
		justify-content: flex-start;
		.img222{
			width: 100rpx;
			height: 100rpx;
			margin-right: 20rpx;
			border-radius: 50%;
		}
		.text{
			
			font-size: 36rpx;
			font-family: PingFang SC;
			font-weight: 500;
			color: #999999;
		
		}
	}
</style>
