<template>
	<view class="video">
		<video :src="url" :poster="img" object-fit="fill" :controls="controls"></video>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				url:'',
				img:'',
				controls:false,//
			}
		},
		onLoad(option){
			// this.url = this.$cdnUrl+option.url;
			this.url = this.$imgUrl(option.url)
			
			// this.img = this.$cdnUrl+option.img;
			this.img = this.$imgUrl(option.img);
		},
		onShow() {
		
		},
		methods: {
			
		}
	}
</script>

<style>
	.video {
	   width: 100%;
	   height: 424rpx;
	    position: relative;
	  }
	video {
		width: 100%;
		height: 100%;
	}
	
</style>

