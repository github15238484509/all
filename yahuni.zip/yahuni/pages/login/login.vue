<template>
	<view class="">
		<view class="img">
		 <image class='i-logo' :src="$imgUrl(logo)" style="box-shadow: 0 1px 3px rgba(0, 0, 0, .4);"></image>
		</view>
		<view class="word word1">{{company.company_name}}</view>
		<view class="word word2">申请获取你的公开信息（昵称、头像等）</view>
		<button  class="btn" v-if="show" style="margin-top:100rpx;"  @click="$u.throttle(getUserInfo,1000)">微信授权</button>
		<button  class="btn" v-else style="margin-top:100rpx;" open-type="getPhoneNumber"  @getphonenumber="btnBClick">微信用户快捷登录</button>
		<!-- <image src="../../static/register/registerBg.png" style="width: 100%;position: absolute;bottom: 0;height:476rpx" mode=""></image> -->
		<!-- <image :src="$imgUrl('/CxtxUni/static/register/registerBg.png')" style="width: 100%;position: absolute;bottom: 0;height:476rpx" mode=""></image> -->
	</view>
</template>

<script>
	import login from "../../api/login/login.js"
	export default {
		data() {
			return {
				show:true,
				code:'',
				openid:'',
				session_key:'',
				phoneNumber:'',
				sex:'',
				userInfo:{},
				url:'',
				logo:'',
				unionid:''
			}
		},
		onLoad() {
			login.aboutWe().then(res=>{
				console.log(res)
				this.logo=res.result.small_logo
			})
			this.init()
		},
		onShareAppMessage: function(options) {
			return {
				title: '源爱汇',
				path: '/page/index/index',
				success: function(res) {
					// 转发成功
				},
				fail: function(res) {
					// 转发失败
				}		
			}		
		},
		methods: {
			init(){
				let self = this
				uni.login({
				  success: res => {
					// 发送 res.code 到后台换取 openId, sessionKey, unionId
					self.code = res.code;
					self.getOpenId()
					// self.getUserInfo()
				  }
				})
			},
			//获取openId
			  getOpenId(){
				login.get_wechat({
					code: this.code
				}).then(res=>{
					if(res.status==200){
						this.openid= res.result.openid;
						this.session_key=res.result.session_key
						this.unionid=res.result.unionid
					}
				})
			  },
			  // 判断是否授权
			 getUserInfo(){
				 console.log(1111)
				 uni.getUserProfile({
					 desc:"获取用户信息",
					 success:res=>{
						 console.log(res)
						 if(res.userInfo){
							this.show=false
							this.userInfo = res.userInfo
							if(this.userInfo.gender==1){
							  this.sex='男'
							}else{
							  this.sex='女'
							}  
						 }
					 },
					 fail(err) {
					 	console.log(err)
					 }
				 })
			   //  uni.getSetting({
			   //    success: res => {
					 //  console.log(res)
			   //      if (res.authSetting) {
			   //        this.show=false
			   //        uni.getUserInfo({
			   //          success: res => {
						// 	this.userInfo = res.userInfo
						// 	 if(this.userInfo.gender==1){
						// 	   this.sex='男'
						// 	 }else{
						// 	   this.sex='女'
						// 	 }  
			   //          },
						// fail(e) {
						// 	console.log(e)
						// }
			   //        })
			   //      }else{
			   //        this.show=true
			   //      } 
			   //    },
				  // fail(err) {
				  // 	console.log(err)
				  // }
			   //  })
			  },
			  btnBClick(e) {
			  				// 此处用法为在js中调用，需要写this.$u.throttle()
			  				this.$u.throttle(()=>{
								this.getPhoneNumber(e)
							}, 500)
			  			},
			  //调用获取用户手机号
			  getPhoneNumber (e) {
				  console.log(e);
			    var encryptedData = e.detail.encryptedData;
			    var iv = e.detail.iv;
			    this.getWechatPhone(encryptedData,iv);
			  },
			  //获取用户手机号
			  getWechatPhone(encryptedData,iv) {
			    let that = this;
				login.getWxphone({
					sessionKey: that.session_key,
					encryptedData: encryptedData,
					iv: iv
				}).then(res=>{
					console.log(res);
					that.phoneNumber = res.result.phoneNumber
					that.checkPhone()
				})
			  },
			  //检测手机号是否注册过
			  checkPhone(){
			    let that = this;
				login.wechat_login({
					phone:that.phoneNumber,
					openid:that.openid
				}).then(res=>{
					console.log(res);
					if(Number(res.status)==200){
						uni.setStorageSync('token',res.result.token);
						 uni.navigateBack({
						 	data:2
						 })
					}
					else if(Number(res.status)==350){
						console.log(this.unionid);
						uni.navigateTo({  
							url:'../register/register?phone='+this.phoneNumber+'&openid='+this.openid+'&photo='+this.userInfo.avatarUrl+'&name='+this.userInfo.nickName+'&sex='+this.sex+'&unionid='+this.unionid
						})
					}
					else {
						uni.showToast({
						    title: res.memessage,
						    duration: 2000
						});
					}
				})
			  },
			  //用户授权登录
			  register(){
			    let that = this;
				that.request({
					url:that.url,
					data:{
						unionid: that.unionid,
						phone:that.phoneNumber,
						wechat_openid:that.openid,
						sex:that.sex,
						nickname: that.userInfo.nickName,
						headimgurl: that.userInfo.avatarUrl,
						app_type : '3'
					},success:function(res){
						console.log(res);
						if(res.data.success){
							uni.setStorageSync("token", res.data.data.token)
							uni.setStorageSync("phone", that.phoneNumber)
							uni.switchTab({
								url: './my',
							})
						}else{
							uni.showToast({
								title:res.message
							})
						}
					}
				})
			    
			  },
			  // getLogo(){
				 //  let that = this;
				 //  that.request({
				 //  	url:'api/app.php?c=account/appConfig',
					// success:function(res){
				 //  		that.logo=that.$cdnUrl+res.data.platform_logo
				 //  	}
				 //  })
			  // }
		},
		mounted() {
			// this.getLogo()
			
		}
	}
	
</script>

<style>
	page{
		background-color: #fff;
	}
	.img{
	  padding: 100rpx 0;
	  text-align: center;
	}
	image{
	  width: 150rpx;
	  height: 150rpx;
	  border-radius:15rpx;
	  /* box-shadow: 0px 0px 32px 0px rgba(166, 166, 166, 0.3); */
	}
	.word{
	  text-align: center;
	}
	.word1{
	  font-size:36rpx;
	  font-family:PingFang SC;
	  font-weight:bold;
	  color:rgba(51,51,51,1);
	  line-height:66rpx;
	}
	.word2{
	  font-size:24rpx;
	  font-family:PingFang SC;
	  font-weight:400;
	  color:rgba(153,153,153,1);
	  line-height:66rpx;
	}
	.btn{
	  width:690rpx!important;
	  height:90rpx;
	  line-height: 90rpx;
	  color: #fff;
	  background:#F87897;
	  border-radius:10rpx;
	  padding: 0!important;
	  margin-top: 50rpx;
	}
</style>
