<template>
	<view class="box">
		<view class="title">
			<text v-if="obj.order_status=='0'">已取消</text>
			<text v-if="obj.order_status=='1'">待支付</text>
			<text v-if="obj.order_status=='2'">待出库</text>
			<text v-if="obj.order_status=='3'">正在出库</text>
			<text v-if="obj.order_status=='4'">已部分发货</text>
			<text v-if="obj.order_status=='5'">已全部发货</text>
			<text v-if="obj.order_status=='6'">已完成</text>
			<text v-if="obj.order_status >= '7'">已退款</text>
		</view>
		<view class="list-t">
			<image src="../../../static/index/place.png" class="img"></image>
			<view class="list2">
				<view class="card">
					<view class="top">
						<view class="top-l">
							{{obj.order_contacts?obj.order_contacts:""}}
						</view>
						<view class="top-r">
							{{obj.order_phone?obj.order_phone:""}}
						</view>
					</view>
					<view class="bottom">
						{{obj.order_address?obj.order_address:""}}
					</view>
				</view>
				<!-- <image src="../../../static/right.png" class="img"></image> -->
			</view>

		</view>
		<view class="list" v-for="(item,index) in obj.goodsInfo" :key="index" @click="toDetail(item)">
			<image :src="$imgUrl(item.sku_pic)" class="img"></image>
			<view class="list-r">
				<view class="text-1">
					<text class="text-type1">
						{{item.zone_name?item.zone_name:""}}
					</text>

					<text>
						{{item.goods_name?item.goods_name:""}}
					</text>

				</view>
				<view class="text-2">
					{{item.goods_describe?item.goods_describe:""}}
				</view>
				<view class="text-bg">
					<view class="text-4" v-if="item.sku_name">
						{{item.sku_name?item.sku_name:""}}
					</view>
				</view>
				<view class="text-6">
					<text class="text-3">
						￥{{item.goods_price?$returnFloat(item.goods_price):""}}
					</text>
					<text class="text-5">
						x{{item.goods_count}}
					</text>
					<view class="llll" v-if="obj.order_status=='6'&&obj.order_button=='1'&&item.goods_order_status=='2'"
						@click.stop="go(item)">
						<text>立即评价</text>
					</view>
					<view class="llll" v-if="obj.order_status=='6'&&obj.order_button=='1'&&item.goods_order_status=='3'"
						style="color: #FFFFFF;background-color: #DDDDDD;border: none;">
						<text>已评价</text>
					</view>
				</view>


			</view>
		</view>
		<view class="beizhu">
			<view class="bz-title">
				备注
			</view>
			<textarea value="" placeholder="你没有填写备注"
				style="width: 100%;margin-top:20rpx;height: 80rpx;background-color: #FFF;" v-model="area"
				class="font-input" />
		</view>
		<view class="money">
			<view class="money-c" style="margin-top: 20rpx;margin-bottom: 30rpx;">
				<view class="left">
					商品总价
				</view>
				<view class="right">
					￥{{obj.order_goods_price?$returnFloat(obj.order_goods_price):""}}
				</view>
			</view>
			<view class="money-c" style="margin-bottom: 30rpx;">
				<view class="left">
					运费
				</view>
				<view class="right">
					￥{{$returnFloat(obj.order_freight_price)}}
				</view>
			</view>
			<view class="money-c">
				<view class="left1">
					订单金额
				</view>
				<view class="right1">
					￥{{obj.order_total_price?$returnFloat(obj.order_total_price):""}}
				</view>
			</view>

		</view>

		<view class="item">
			<view class="left">
				付款方式
			</view>
			<view class="gray">
				{{obj.payment_name?obj.payment_name:""}}
			</view>

		</view>
		<view class="banner">
			<view class="text1">
				<view class="dot">

				</view>
				<view class="tip">
					订单信息
				</view>
			</view>
			<view class="text2">
				<view class="left">
					<view class="left-l">
						订单编号：
					</view>
					<view class="left-r">
						{{obj.order_id?obj.order_id:""}}
					</view>
				</view>
				<view class="right" @click="copy()">
					复制
				</view>
			</view>
			<view class="text3">
				<view class="left">
					<view class="left-l">
						下单时间：
					</view>
					<view class="left-r">
						{{time1}} {{time2}}
					</view>
				</view>
			</view>
			<view class="text3" v-if="obj.order_status>'1'">
				<view class="left">
					<view class="left-l">
						支付时间：
					</view>
					<view class="left-r">
						{{time3}} {{time4}}
					</view>
				</view>
			</view>
			<view class="text3" v-if="obj.order_status=='4'||obj.order_status=='5'||obj.order_status=='6'">
				<view class="left">
					<view class="left-l">
						发货时间：
					</view>
					<view class="left-r">
						{{time5}} {{time6}}
					</view>
				</view>
			</view>
			<view class="text3" v-if="obj.order_status=='6'">
				<view class="left">
					<view class="left-l" style="margin-right: 68rpx;">
						收货时间:
					</view>
					<view class="left-r">
						{{time7}} {{time8}}
					</view>
				</view>
			</view>
			<!-- <view class="text3" v-if="obj.order_status=='4'&&obj.cancel_time!==''">
				<view class="left">
					<view class="left-l">
						退款时间：
					</view>
					<view class="left-r">
						{{time7}} {{time8}}
					</view>
				</view>
			</view> -->
		</view>
		<view class="footer">
			<view class="fff" v-if="obj.order_status=='0' || obj.order_status >= '7'" @click="del">
				<text>删除订单</text>
			</view>
			<view class="fff" v-if="obj.order_status=='1'" @click="revise('1')">
				<text>取消订单</text>
			</view>
			<view class="bbb" v-if="obj.order_status=='1'" @click="pay">
				<text>立即支付</text>
			</view>
			<view class="bbb" v-if="obj.order_status=='2'&&obj.is_refund=='1'" @click="back">
				<text>退款</text>
			</view>
			<view class="bbb" v-if="obj.order_status=='2'&&obj.is_refund=='0'" style="background-color: #cccccc;">
				<text>不可退款</text>
			</view>
			<view class="fff" v-if="obj.order_status=='4'||obj.order_status=='5'||obj.order_status=='6'" @click="goto1(obj)">
				<text>查看物流</text>
			</view>
			<view class="bbb" v-if="obj.order_status=='5'" @click="take">
				<text>确认收货</text>
			</view>


			<!-- <view class="bbb" v-if="obj.order_status=='2'" @click="revise('2')">
				<text>立即学习</text>
			</view> -->
			<!-- <view class="bbb" v-if="obj.order_status=='2'" @click="open">
				<u-modal v-model="show" :show-cancel-button="true" @confirm="revise('2')">
					<view class="slot-content">
						<rich-text :nodes="content"></rich-text>
					</view>
				</u-modal>

				<text>立即学习</text>
			</view>
			<view class="bbb" v-if="obj.order_status=='3'&&obj.is_comment=='1'" @click="go">
				<text>立即评价</text>
			</view>
			<view class="bbb" v-if="obj.order_status=='3'&&obj.is_comment=='0'">
				<text>已评价</text>
			</view> -->

		</view>

	</view>
</template>

<script>
	// import orderDetailApi from "../../../api/myCourse/orderDetail/orderDetail.js"
	import myCourseApi from "../../../api/myCourse/myCourse.js"
	export default {
		data() {
			return {
				obj: {},
				order_index: "",
				time1: "",
				time2: "",
				time3: "",
				time4: "",
				time5: "",
				time6: "",
				time7: "",
				time8: "",
				show: false,
				skus: "",
				content: '<br>1.请在现场人员的指示下执行此操作.<br> 2.如未在引导下执行此操作则视为已执行过学习操作,平台及其他人员不负任何责任.<br><br>',
				area: "",



			};
		},
		onLoad(el) {
			// const item = JSON.parse(decodeURIComponent(el.item));
			console.log(el)
			this.order_index = el.order_index
			this.init()

		},
		onShareAppMessage: function(options) {
			return {
				title: '源爱汇',
				path: '/page/index/index',
				success: function(res) {
					// 转发成功
				},
				fail: function(res) {
					// 转发失败
				}		
			}		
		},
		methods: {
			goto1(item) {
				
				uni.navigateTo({
					url: './logistics/logistics?order_index=' + item.order_index
				})
			},
			toDetail(item) {
				uni.navigateTo({
					url: "../../index/detail/detail?id=" + item.goods_index
				})
			},
			//确认收货
			take() {
				let this_ = this
				uni.showModal({
					title: '提示',
					content: '确认已经收到该商品了吗?',
					success: function(res) {
						if (res.confirm) {
							myCourseApi.edit_orders({
								// token: "5846783423223160416",
								order_index: this_.order_index,
								type: "3"
							}).then(res => {
								console.log(res)
								if (res.status == 200) {
									this_.init()
								} else {
									uni.showToast({
										title: res.message,
										icon: 'none'
									})
								}
							})
						}
					}
				});
			},
			open() {
				this.show = true;
			},
			//订单详情
			init() {
				myCourseApi.order_details({
					// token: "5846783423223160416",
					order_index: this.order_index
				}).then(res => {
					// console.log(res)

					this.obj = res.result
					console.log(this.obj)

					this.time1 = this.$time(this.obj.order_time, 0)
					this.time2 = this.$time(this.obj.order_time, 3)
					this.time3 = this.$time(this.obj.payment_time, 0)
					this.time4 = this.$time(this.obj.payment_time, 3)
					this.time5 = this.$time(this.obj.fahuo_time, 0)
					this.time6 = this.$time(this.obj.fahuo_time, 3)
					this.time7 = this.$time(this.obj.confirm_time, 0)
					this.time8 = this.$time(this.obj.confirm_time, 3)
					// this.skus = res.result.goods_info.sku_name
					// console.log(this.time1, this.time2,this.time3,this.time4,)
				})
			},
			//复制
			copy() {


				//uni.setClipboardData方法就是讲内容复制到粘贴板
				uni.setClipboardData({
					data: this.order_index, //要被复制的内容
					success: () => { //复制成功的回调函数
						uni.showToast({ //提示
							title: "复制成功"
						})
					}
				});

			},
			//删除订单
			del() {
				let this_ = this
				uni.showModal({
					title: '提示',
					content: '您确定要删除订单吗?',
					success: function(res) {
						if (res.confirm) {
							myCourseApi.edit_orders({
								// token: "5846783423223160416",
								order_index: this_.order_index,
								type: "2"
							}).then(res => {
								if (res.status == 200) {
									uni.redirectTo({
										url: '../myCourse'
									})
									uni.setStorageSync("current", '0')
								} else {
									uni.showToast({
										title: res.message,
										icon: 'none',
										duration: 2000
									});
								}
								// console.log(res)
								// uni.redirectTo({
								// 	url: "../myCourse"
								// });
								// uni.setStorageSync("current", '0')
							})
						}
					}
				});
			},
			//取消订单 立即学习
			revise(type) {
				if (type == "1") {
					let this_ = this
					uni.showModal({
						title: '提示',
						content: '您确定要取消订单吗?',
						success: function(res) {
							if (res.confirm) {
								myCourseApi.edit_orders({
									// token: "5846783423223160416",
									order_index: this_.order_index,
									type: type
								}).then(res => {
									console.log(res)
									this_.init()
								})
							}
						}
					});
				} else {
					let this_ = this
					// uni.showModal({
					// 	title: '提示',
					// 	content: '1.请在现场人员的指示下执行此操作.\n 2.如未在引导下执行此操作则视为已执行过学习操作,平台及其他人员不负任何责任.',
					// 	success: function(res) {
					// 		if (res.confirm) {
					orderDetailApi.cancel_orders({
						// token: "5846783423223160416",
						order_index: this_.order_index,
						type: type
					}).then(res => {
						console.log(res)
						this_.init()
						uni.showToast({ //提示
							title: "学习成功"
						})
					})
					// 		}
					// 	}
					// });
				}

			},
			//立即评价
			go(item) {
				// console.log(this.obj);
				uni.navigateTo({
					url: "./publish/publish?order_goods_index=" + item.order_goods_index + "&&sku_pic=" + item

						.sku_pic + "&&goods_name=" + item.goods_name + "&&goods_price=" + item
						.goods_price + "&&goods_describe=" + item.goods_describe +
						"&&sku_name=" + item.sku_name + "&&zone_name=" + item.zone_name
				})
			},
			//支付
			pay() {
				myCourseApi.confirm_pay({
					// token:"5846783423223160416",
					order_index: this.order_index
				}).then(res => {
					console.log(res)
					let item = res.result
					uni.navigateTo({
						url: "../../index/detail/order/pay/pay?item=" + encodeURIComponent(JSON.stringify(
							item))
					})
				})

			},
			//退款
			back() {
				let this_ = this
				uni.showModal({
					title: '提示',
					content: '您确定要退款吗?',
					success: function(res) {
						if (res.confirm) {
							myCourseApi.refund_orders({
								order_index: this_.order_index
							}).then(res => {
								console.log(res)
								if (res.status == 200) {
									uni.showToast({ //提示
										title: "退款提交成功!"
									})
									uni.reLaunch({
										url: "../myCourse"
									})
								} else {
									uni.showToast({
										title: res.message,
										icon: 'none'
									})
								}
							})

						}
					}
				});

			}


		}
	}
</script>
<style>
	page {
		height: 100%;
		background-color: #F5F5F5;
	}
</style>
<style lang="scss" scoped>
	.box {
		overflow: hidden;

		.money {
			width: 750rpx;
			height: 220rpx;
			background: #FFFFFF;
			overflow: hidden;
			margin-bottom: 20rpx;

			.money-c {
				display: flex;
				align-items: center;
				justify-content: space-between;

				.left1 {
					font-size: 30rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #333333;
					margin-left: 30rpx;

				}

				.right1 {
					font-size: 30rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #FF1C1C;
					margin-right: 30rpx;
				}

				.left {
					margin-left: 30rpx;
					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #999999;
				}

				.right {

					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #999999;
					margin-right: 30rpx;
				}
			}

		}

		.beizhu {
			background-color: #fff;
			padding: 20rpx 30rpx;
			margin-bottom: 20rpx;
		}

		.list-t {
			width: 750rpx;
			height: 200rpx;
			background-color: #fff;


			margin-top: 20rpx;
			display: flex;
			justify-content: flex-start;
			align-items: center;
			margin-bottom: 20rpx;

			.img {
				width: 64rpx;
				height: 64rpx;
				margin-left: 30rpx;
				margin-right: 30rpx;
			}

			.list2 {
				display: flex;
				justify-content: flex-start;
				align-items: center;

				.img {
					width: 17rpx;
					height: 32rpx;
				}

				.card {
					width: 470rpx;
					margin-right: 70rpx;

					.top {
						display: flex;
						justify-content: flex-start;
						margin-bottom: 24rpx;

						.top-l {

							font-size: 28rpx;
							font-family: PingFang SC;
							font-weight: 500;
							color: #333333;
							margin-right: 20rpx;

						}

						.top-r {

							font-size: 24rpx;
							font-family: PingFang SC;
							font-weight: 400;
							color: #999999;

						}
					}

					.bottom {
						width: 100%;

						font-size: 26rpx;
						font-family: PingFang SC;
						font-weight: 400;
						color: #333333;
					}
				}
			}
		}

		.slot-content {
			font-size: 28rpx;
			color: $u-content-color;
			padding-left: 30rpx;
		}

		.title {
			width: 750rpx;
			height: 70rpx;
			background: #F87897;
			font-size: 30rpx;
			font-family: PingFang SC;
			font-weight: 400;
			color: #FFFFFF;
			display: flex;
			align-items: center;
			margin-bottom: 20rpx;

			text {
				margin-left: 30rpx;
			}
		}

		.footer {
			width: 750rpx;
			height: 90rpx;
			background: #FFFFFF;
			position: fixed;
			bottom: 0;
			left: 0;
			display: flex;
			align-items: center;
			justify-content: flex-end;

			.fff {
				margin-right: 30rpx;
				display: flex;
				align-items: center;
				width: 180rpx;
				height: 70rpx;
				background: #FFFFFF;
				border: 1rpx solid #F87897;
				color: #F87897;
				border-radius: 35rpx;
				justify-content: center;
			}

			.bbb {
				width: 180rpx;
				height: 70rpx;
				background: #F87897;
				border-radius: 35rpx;
				justify-content: center;
				margin-right: 30rpx;
				display: flex;
				align-items: center;
				color: #FFFFFF;
			}
		}

		.banner {
			width: 750rpx;
			// height: 200rpx;
			background: #FFFFFF;
			overflow: hidden;
			margin-bottom: 155rpx;

			.text1 {
				display: flex;
				justify-content: flex-start;
				align-items: center;
				margin-top: 30rpx;

				.dot {
					width: 4rpx;
					height: 30rpx;
					background: #F87897;
					margin-left: 30rpx;
					margin-right: 10rpx;
				}

				.tip {
					font-size: 30rpx;
					font-family: PingFang SC;
					font-weight: 500;
					color: #333333;
				}
			}

			.text2 {

				font-size: 26rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #666666;
				display: flex;
				justify-content: space-between;
				align-items: center;
				margin: 30rpx 0;

				.left {
					display: flex;
					justify-content: space-between;
					margin-left: 30rpx;

					.left-l {
						margin-right: 50rpx;
					}
				}

				.right {

					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 400;
					text-decoration: underline;
					color: #1E63B5;
					margin-right: 30rpx;
				}
			}

			.text3 {

				font-size: 26rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #666666;
				display: flex;
				justify-content: space-between;
				align-items: center;
				margin: 30rpx 0;

				.left {
					display: flex;
					justify-content: space-between;
					margin-left: 30rpx;

					.left-l {
						margin-right: 50rpx;
					}
				}

				.right {

					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 400;
					text-decoration: underline;
					color: #1E63B5;
					margin-right: 30rpx;
				}
			}
		}

		.item {
			width: 750rpx;
			height: 90rpx;
			background: #FFFFFF;
			margin-bottom: 20rpx;
			font-size: 30rpx;
			font-family: PingFang SC;
			font-weight: 400;
			color: #333333;
			display: flex;
			align-items: center;
			justify-content: space-between;

			.left {
				margin-left: 30rpx;
			}

			.right {
				margin-right: 30rpx;
				color: #FF1C1C;
			}

			.gray {
				margin-right: 30rpx;
				color: #999999;
			}
		}

		.list {
			width: 750rpx;
			height: 220rpx;
			background-color: #fff;
			padding: 20rpx 30rpx;
			border-top: 2rpx solid #F5F5F5;
			border-bottom: 2rpx solid #F5F5F5;
			// margin-left: 30rpx;
			display: flex;
			justify-content: flex-start;
			// margin-bottom: 20rpx;

			.img {
				width: 300rpx;
				height: 170rpx;
				border-radius: 10rpx;
				margin-right: 20rpx;
			}

			.list-r {
				width: 360rpx;

				// background-color: red;
				.text-1 {
					overflow: hidden;
					white-space: nowrap;
					text-overflow: ellipsis;
					// height: 31rpx;
					font-size: 32rpx;
					font-family: Source Han Sans CN;
					font-weight: 400;
					color: #333333;

					// line-height: 36px;
					.text-type1 {
						// padding:  10rpx  10rpx;
						padding-left: 10rpx;
						padding-right: 10rpx;
						margin-right: 10rpx;
						background-color: #F87897;
						font-size: 22rpx;
						border-radius: 9rpx;
						color: #FFFFFF;
						height: 22rpx;
					}
				}

				.text-2 {
					// width: 284px;
					// height: 25rpx;
					overflow: hidden;
					white-space: nowrap;
					text-overflow: ellipsis;
					font-size: 26rpx;
					font-family: Source Han Sans CN;
					font-weight: 300;
					color: #999999;
					// line-height: 36px;
					margin-top: 5rpx;
					// margin-bottom: 47rpx;
				}

				.text-5 {
					margin-left: 20rpx;
					font-size: 30rpx;
					font-family: PingFang SC;
					font-weight: 500;
					color: #CCCCCC;
				}

				.text-3 {
					// width: 90px;
					// height: 24rpx;
					font-size: 30rpx;
					font-family: Source Han Sans CN;
					font-weight: 400;
					color: #FF1C1C;
					// margin-bottom: 10rpx;
					opacity: 1;
					// position: absolute;
					width: 130rpx;
					// height: 76rpx;
					// left: 345rpx;
					// top: 240rpx;
				}

				.text-4 {
					// width: 284px;
					height: 38rpx;
					font-size: 26rpx;
					font-family: Source Han Sans CN;
					font-weight: 300;
					color: #999999;
					// line-height: 38px;
					margin-left: 12rpx;
					margin-right: 12rpx;
				}

				.text-bg {
					// width: 284px;
					display: inline-block;
					height: 38rpx;
					font-size: 26rpx;
					font-family: Source Han Sans CN;
					font-weight: 300;
					margin-top: 10rpx;
					// margin-bottom: 47rpx;
					background-color: #F5F5F5;
					border-radius: 5rpx;
				}

				.text-6 {
					display: flex;
					justify-content: flex-start;
					align-items: center;
				}

				.llll {
					margin-left: 35rpx;
					width: 150rpx;
					height: 50rpx;
					background: #FFFFFF;
					border: 1rpx solid #F87897;
					color: #F87897;
					border-radius: 25rpx;
					text-align: center;
					display: flex;
					// justify-content: space-between;
					align-items: center;
					justify-content: center
				}
			}

		}
	}
</style>
