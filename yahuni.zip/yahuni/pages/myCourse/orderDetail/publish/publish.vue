<template>
	<view class="box">
		<view class="header">
			<view class="list">
				<image :src="$imgUrl(sku_pic)" class="img"></image>
				<view class="list-r">
					<view class="text-1">
						<text class="text-type1">
							{{zone_name?zone_name:""}}
						</text>

						<text>
							{{goods_name?goods_name:""}}
						</text>

					</view>
					<view class="text-2">
						{{goods_describe}}
					</view>
					<view class="text-bg">
						<view class="text-4" v-if="sku_name">
							{{sku_name}}
						</view>
					</view>
					<view class="text-3">
						￥{{$returnFloat(goods_price)}}
					</view>

				</view>
			</view>
			<view class="list2">
				<view class="text">
					整体评价
				</view>
				<u-rate active-color="#FFC600" :count="count" v-model="value" min-count="1"></u-rate>
				<view class="good" v-if="value==1">
					很差
				</view>
				<view class="good" v-if="value==2">
					差
				</view>
				<view class="good" v-if="value==3">
					一般
				</view>
				<view class="good" v-if="value==4">
					好
				</view>
				<view class="good" v-if="value==5">
					很好
				</view>
			</view>
		</view>
		<view class="content">

			<view class="uni-textarea">
				<textarea placeholder="你对收到的商品还满意吗？说说你的看法吧" v-model="textValue" />
			</view>
			<!-- <u-upload style="margin-left: 20rpx;" :custom-btn="true" max-count="5" :action="action" :auto-upload="true"
				width="130rpx" height="130rpx" @on-success="addChange">
				<view slot="addBtn" class="slot-btn" hover-class="slot-btn__hover" hover-stay-time="150">
					<image style="width: 130rpx;height: 130rpx;margin: 5px;" src="../../../../static/myCourse/add.png"
						mode=""></image>
				</view>
			</u-upload> -->
			<view class="kkkkk">


				<u-uploadd ref="uUpload" :custom-btn="true" max-count="5" :action="action" :show-progress="false"
					:auto-upload="true" width="126rpx" height="126rpx" @on-success="imgChange1" @on-remove="removeArr"
					:file-list="envimgs">
					<view slot="addBtn" style="box-sizing: border-box;width: 126rpx;height: 126rpx;" class="slot-btn"
						hover-class="slot-btn__hover" hover-stay-time="150">
						<image src="../../../../static/myCourse/add.png" class="img"></image>
					</view>
				</u-uploadd>
			</view>
		</view>
		<view class="line">

		</view>
		<view class="list2" style="margin-top: 40rpx;">
			<view class="text">
				服务态度
			</view>
			<u-rate active-color="#FFC600" :count="count1" v-model="value2" min-count="1"></u-rate>
			<view class="good" v-if="value2==1">
				很差
			</view>
			<view class="good" v-if="value2==2">
				差
			</view>
			<view class="good" v-if="value2==3">
				一般
			</view>
			<view class="good" v-if="value2==4">
				好
			</view>
			<view class="good" v-if="value2==5">
				很好
			</view>
		</view>
		<view class="list2" style="margin-top: 40rpx;">
			<view class="text">
				物流评价
			</view>
			<u-rate active-color="#FFC600" :count="count1" v-model="value3" min-count="1"></u-rate>
			<view class="good" v-if="value3==1">
				很差
			</view>
			<view class="good" v-if="value3==2">
				差
			</view>
			<view class="good" v-if="value3==3">
				一般
			</view>
			<view class="good" v-if="value3==4">
				好
			</view>
			<view class="good" v-if="value3==5">
				很好
			</view>
		</view>
		<view class="btn" @click="add">
			<text>提交发布</text>
		</view>
	</view>
</template>

<script>
	import orderApi from "../../../../api/myCourse/myCourse.js"
	export default {
		data() {
			return {
				count: 5,
				count1: 5,
				value: 5,
				value2: 5,
				value3: 5,
				textValue: '',
				imgArr: [],
				//上传地址
				action: this.$uptImgUrl,
				order_goods_index: "",
				sku_pic: "",
				goods_price: "",
				goods_name: "",
				goods_describe: "",
				sku_name: "",
				zone_name: "",

			};
		},
		onLoad(e) {
			console.log(e)
			this.sku_pic = e.sku_pic
			this.order_goods_index = e.order_goods_index
			this.goods_price = e.goods_price
			this.goods_name = e.goods_name
			this.goods_describe = e.goods_describe
			this.sku_name = e.sku_name
			this.zone_name = e.zone_name
		},
		onShareAppMessage: function(options) {
			return {
				title: '源爱汇',
				path: '/page/index/index',
				success: function(res) {
					// 转发成功
				},
				fail: function(res) {
					// 转发失败
				}		
			}		
		},
		methods: {
			// addChange(e) {
			// 	console.log(e, 11)
			// 	this.img = e.result.img_name


			// },
			imgChange1(e) {
				console.log("得到的返回值")
				console.log(e)
				// this.files = this.$refs.uUpload.lists;
				this.imgArr.push(e.result.img_name)
				console.log(this.imgArr)
			},
			removeArr(index) {
				this.imgArr.splice(index, 1);
			},
			// text(e) {
			// 	this.textValue = e.detail.value
			// 	console.log(this.textValue)
			// },
			add() {
				this.imgArr = this.imgArr.join()
				console.log(this.imgArr);
				orderApi.order_evaluate({
					order_goods_index: this.order_goods_index,
					whole_star: this.value,
					service_star: this.value2,
					content: this.textValue,
					img_name: this.imgArr,
					express_star: this.value3
				}).then(res => {
					console.log(res)
					uni.showToast({ //提示
						title: "提交成功"
					})
					// uni.relaunch({
					// 	url:"../orderDetail?order_id="+this.order_id
					// })
					uni.setStorageSync("current", '4')
					uni.redirectTo({
						url: "../../myCourse"
					})
				})
			}

		}
	}
</script>

<style lang="scss" scoped>
	.box {
		.header {
			height: 320rpx;
			width: 750rpx;
			border-top: 2rpx solid #F5F5F5;
			border-bottom: 2rpx solid #F5F5F5;

			.list {
				width: 750rpx;
				height: 210rpx;
				background-color: #fff;
				padding: 20rpx 30rpx;
				// border-top: 2rpx solid #F5F5F5;
				// border-bottom: 2rpx solid #F5F5F5;
				margin-top: 30rpx;
				display: flex;
				justify-content: flex-start;
				margin-bottom: 10rpx;

				.img {
					width: 300rpx;
					height: 170rpx;
					border-radius: 10rpx;
					margin-right: 20rpx;
				}

				.list-r {
					width: 360rpx;

					// background-color: red;
					.text-1 {
						overflow: hidden;
						white-space: nowrap;
						text-overflow: ellipsis;
						// height: 31rpx;
						font-size: 32rpx;
						font-family: Source Han Sans CN;
						font-weight: 400;
						color: #333333;
						// line-height: 36px;
						.text-type1 {
						                        // padding:  10rpx  10rpx;
						                        padding-left: 10rpx;
						                        padding-right: 10rpx;
						                        margin-right: 10rpx;
						                        background-color: #F87897;
						                        font-size: 22rpx;
						                        border-radius: 9rpx;
						                        color: #FFFFFF;
						                        height: 22rpx;
						                    }
					}

					.text-2 {
						// width: 284px;
						// height: 25rpx;
						overflow: hidden;
						white-space: nowrap;
						text-overflow: ellipsis;
						font-size: 26rpx;
						font-family: Source Han Sans CN;
						font-weight: 300;
						color: #999999;
						// line-height: 36px;
						margin-top: 5rpx;
						// margin-bottom: 47rpx;
					}

					.text-3 {
						// width: 90px;
						// height: 24rpx;
						font-size: 30rpx;
						font-family: Source Han Sans CN;
						font-weight: 400;
						color: #FF1C1C;
						// margin-bottom: 10rpx;
						opacity: 1;
						position: absolute;
						width: 130rpx;
						height: 76rpx;
						left: 345rpx;
						top: 180rpx;
					}

					.text-4 {
						// width: 284px;
						height: 38rpx;
						font-size: 26rpx;
						font-family: Source Han Sans CN;
						font-weight: 300;
						color: #999999;
						// line-height: 38px;
						margin-left: 12rpx;
						margin-right: 12rpx;
					}

					.text-bg {
						// width: 284px;
						display: inline-block;
						height: 38rpx;
						font-size: 26rpx;
						font-family: Source Han Sans CN;
						font-weight: 300;
						margin-top: 10rpx;
						// margin-bottom: 47rpx;
						background-color: #F5F5F5;
					}
				}
			}


		}

		.content {
			// height: 410rpx;
			width: 100%;

			.kkkkk {
				padding-left: 30rpx;
				margin-bottom: 100rpx;
			}

			.uni-textarea {
				margin-top: 30rpx;
				margin-left: 30rpx;
				width: 690rpx;
				height: 190rpx;
				overflow: hidden;
				margin-bottom: 20rpx;
			}

			// .addBtn{
			// 	width: 126rpx;height: 126rpx;
			// }
			.img {
				width: 100%;
				height: 100%;
				margin: 0;
				padding: 0;

			}

		}

		.line {
			width: 750rpx;
			height: 20rpx;
			background: #F5F5F5;
		}

		.btn {
			width: 690rpx;
			height: 90rpx;
			background: #F87897;
			border-radius: 10rpx;
			display: flex;
			align-items: center;
			justify-content: center;
			margin-left: 30rpx;
			color: #FFFFFF;
			margin-top: 100rpx;
		}
	}

	.list2 {
		height: 44rpx;
		width: 100%;
		display: flex;
		justify-content: flex-start;
		align-items: center;
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #333333;

		.text {
			margin-left: 30rpx;
			margin-right: 15rpx;
		}

		.good {
			margin-left: 20rpx;
			font-weight: 400;
			color: #999999;
		}
	}
</style>
