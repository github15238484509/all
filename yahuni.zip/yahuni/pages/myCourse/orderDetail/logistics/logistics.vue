<template>
	<view class="box">
		<!-- 纵向排列 -->
		<view class="title">
			<u-tabs name="cate_name"  :gutter="80" :list="titleList"  active-color="#F87897" :is-scroll="true" :current="current" @change="change"></u-tabs>
		</view>
		<view class="banner" v-if="isShow==false">
			<view class="title1">
				<view class="text">
					{{dataTxt.txt1}}{{obj.order_id?obj.order_id:""}}
				</view>
				<view class="text">
					{{dataTxt.txt2}}{{obj.logistics_data.expName?obj.logistics_data.expName:""}}
				</view>
				<view class="text">
					{{dataTxt.txt3}}{{obj.order_contacts?obj.order_contacts:""}}
				</view>
				<view class="text">
					{{dataTxt.txt4}}{{obj.order_phone?obj.order_phone:""}}
				</view>
			</view>
		</view>
		<view class="content" v-if="isShow==false">
			<steps active-color="#F87897" :options="textLsit" direction="column" :active="0"></steps>
		</view>
		<image src="../../../../static/datanull.png" class="img" v-if="isShow"></image>
		
	</view>
</template>

<script>
	import steps from "../../../../components/uni-steps/uni-steps.vue"
	import myCourseApi from "../../../../api/myCourse/myCourse.js"
	export default {
		data() {
			return {
				dataTxt:{
					txt1:"",
					txt2:"",
					txt3:"",
					txt4:""
				},//文字
				titleList: [
					
				],
				order_index:"",
				current: 0,
				obj:{},
				textLsit:[],
				isShow:false
			};
		},
		components: {
			steps
		},
		onLoad(e) {
			console.log(e);
			
			this.order_index=e.order_index
			let this_ = this
			myCourseApi.search_express({
				order_index: this.order_index
			}).then(res => {
				console.log(res)
				if (res.status == 200) {				
					this_.titleList=res.result.list.map(item => {
					      return {
					        cate_name: item.cate_name
					      }
					    })
					console.log(this_.titleList);
					this.dataTxt={
						txt1:"订单编号：",
						txt2:"国内承运人：",
						txt3:"买家姓名：",
						txt4:"买家电话：",
					}
					this.obj=res.result.list[0];
					console.log(this.obj)
					this.textLsit=this.obj.logistics_data.list.map(el=>{
						return {
							title:el.status,
							desc:el.time
						}
					})
				} else {
					uni.showToast({
						title: res.message,
						icon: 'none'
					})
				}
			})
		},
		onShareAppMessage: function(options) {
			return {
				title: '源爱汇',
				path: '/page/index/index',
				success: function(res) {
					// 转发成功
				},
				fail: function(res) {
					// 转发失败
				}		
			}		
		},
		methods: {
			change(index) {
				this.isShow=false
				this.textLsit=[]
				this.obj={}
				this.current = index;
				console.log(this.current);
				let this_ = this
				myCourseApi.search_express({
					order_index: this.order_index
				}).then(res => {
					console.log(res)
					if(!res.result.list[index].logistics_data){
						this.isShow=true
						return
					}
					if (res.status == 200) {
						this.dataTxt={
							txt1:"订单编号：",
							txt2:"国内承运人：",
							txt3:"买家姓名：",
							txt4:"买家电话：",
						}
						this.obj=res.result.list[index];
						console.log(this.obj)
						
						this.textLsit=this.obj.logistics_data.list.map(el=>{
							return {
								title:el.status,
								desc:el.time
							}
						})
					} else {
						uni.showToast({
							title: res.message,
							icon: 'none'
						})
					}
				})
			}
		}
	}
</script>

<style lang="scss">
	.box {
		overflow: hidden;
		.title {
			width: 100%;
			height: 72rpx;
			border-top: 1px solid #F5F5F5;
			// border-bottom: 2px solid #999999;
		}
		.banner{
			height: 170rpx;
			width: 100%;
			padding: 30rpx;
			// margin-top: 30rpx;
			.title1{
				margin-top: 20rpx;
				font-size: 26rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: #333333;
				.text{
					margin-bottom: 20rpx;
				}
			}
		}
		.content{
			// padding: 30rpx;
			padding-right: 20rpx;
			padding-top: 30rpx;
			margin-top: 60rpx;
			width: 100%;
		}
		.img{
			width: 396rpx;
			height: 343rpx;
			margin-left: 177rpx;
			margin-top: 340rpx;
		}
	}
</style>
