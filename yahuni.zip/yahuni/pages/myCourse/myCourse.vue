<template>
	<view class="box">
		<view class="xx" v-show="isShow">


			<view class="nav">
				<u-sticky :enable="enable">
					<div class="content-nav">
						<div class="nav-item" :class="{active: current=='0'}" @tap="currentChange('0')">
							<text class="text">全部</text>
						</div>
						<div class="nav-item" :class="{active: current=='1'}" @tap="currentChange('1')">
							<text class="text">待支付</text>
						</div>
						<div class="nav-item" :class="{active: current=='2'}" @tap="currentChange('2')">
							<text class="text">待发货</text>
						</div>
						<div class="nav-item" :class="{active: current=='3'}" @tap="currentChange('3')">
							<text class="text">待收货</text>
						</div>
						<div class="nav-item" :class="{active: current=='4'}" @tap="currentChange('4')">
							<text class="text">已完成</text>
						</div>
					</div>
				</u-sticky>
			</view>
			<view>
				<view style="text-align: center; width: 100%;">
					<image v-if="list.length==0" src="../../static/datanull.png" class="imgsss"
						style="width: 344rpx;height: 300rpx; margin-top: 60%;"></image>
				</view>

				<view class="item" v-for="(item,index) in list" :key="index">
					<view class="title" @click="toDetail(item)">
						<view class="title-l">

							<image src="../../static/myCourse/list.png" class="img"></image>
							<view class="text">
								{{item.order_id?item.order_id:""}}
							</view>
						</view>
						<view class="title-r" style="color: #999999;" v-if="item.order_status=='0'">
							已取消
						</view>
						<view class="title-r"  style="color: #F87897;" v-if="item.order_status=='1'">
							待支付
						</view>
						<view class="title-r" style="color: #F87897;" v-if="item.order_status=='2'">
							待出库
						</view>
						<view class="title-r" style="color: #F87897;" v-if="item.order_status=='3'">
							正在出库
						</view>
						<view class="title-r" style="color: #F87897;" v-if="item.order_status=='4'">
							已部分发货
						</view>
						<view class="title-r" style="color: #F87897;" v-if="item.order_status=='5'">
							已全部发货
						</view>
						<view class="title-r" style="color: #999999;" v-if="item.order_status=='6'">
							已完成
						</view>
						<view class="title-r" style="color: #F87897;" v-if="item.order_status=='7'">
							退款中
						</view>
						<view class="title-r" style="color: #F87897;" v-if="item.order_status=='8'">
							已退款
						</view>
					</view>
					<view class="list" v-for="(item1,index1) in item.goodsList" :key="index1" @click="toDetail(item)">
						<image :src="$imgUrl(item1.image)" class="img"></image>
						<view class="list-r">
							<view class="text-1">
								<text class="text-type1">
									{{item1.zone_name?item1.zone_name:""}}
								</text>

								<text>
									{{item1.goods_name?item1.goods_name:""}}
								</text>

							</view>
							<view class="text-2">
								{{item1.goods_describe?item1.goods_describe:""}}
							</view>
							<view class="list-b">
								<view class="text-3">
									￥{{item1.goods_price?$returnFloat(item1.goods_price):""}}
								</view>
								<view class="left"
									v-if="item.order_status=='6'&&item1.order_button=='1'&&item1.goods_status=='2'"
									@click.stop="goto(item)">
									<text>立即评价</text>
								</view>
								<view class="left"
									v-if="item.order_status=='6'&&item1.order_button=='1'&&item1.goods_status=='3'"
									style="color: #FFFFFF;background-color: #DDDDDD;border: none;">
									<text>已评价</text>
								</view>
							</view>


						</view>
					</view>
					<view class="footer">
						<view class="footer-l">
							订单总价:￥{{item.order_total_price?$returnFloat(item.order_total_price):""}}
						</view>
						<view class="footer-r">
							<view class="left" v-if="item.order_status=='1'" @click="goto(item)">
								<text>取消订单</text>
							</view>
							<view class="left" v-if="item.order_status=='0'||item.order_status=='7'" @click="del(item)">
								<text>删除订单</text>
							</view>
							<view class="left" v-if="item.order_status=='2'&&item.is_refund=='1'" @click="goto(item)">
								<text>退款</text>
							</view>
							<view class="left" v-if="item.order_status=='2'&&item.is_refund=='0'">
								<text>不可退款</text>
							</view>
							<view class="left" v-if="item.order_status=='4'||item.order_status=='5'"
								@click="goto1(item)">
								<text>查看物流</text>
							</view>
							<view class="right" v-if="item.order_status=='4'" style="background-color: #cccccc;">
								<text>确认收货</text>
							</view>
							<view class="right" v-if="item.order_status=='5'" @click="goto(item)">
								<text>确认收货</text>
							</view>
							<!-- <view class="right" v-if="item.order_status=='6'&&item.is_comment=='1'" @click="goto(item)">
								<text>立即评价</text>
							</view>
							<view class="right" v-if="item.order_status=='6'&&item.is_comment=='0'">
								<text>已评价</text>
							</view> -->
							<view class="right" v-if="item.order_status=='1'" @click="goto(item)">
								<text>立即支付</text>
							</view>

						</view>
					</view>
				</view>
			</view>
		</view>
		<!-- <view class="ttttt" v-show="!isShow">
			<image src="../../static/myCenter/datanull.png" class="img"></image>
			<view class="xbtn-blue" @click="goLogin">
				<text>登录/注册</text>
			</view>
		</view> -->
	</view>
</template>

<script>
	import myCourseApi from "../../api/myCourse/myCourse.js"
	// import orderDetailApi from "../../api/myCourse/orderDetail/orderDetail.js"
	export default {
		data() {
			return {
				//激活的tab栏
				current: '0',
				enable: true,
				page: "1",
				list: [],
				// text:"",
				isShow: true

			}
		},
		onLoad(e) {
			console.log(e)

			// this.init()
			if (uni.getStorageSync("current")) {

				this.current = uni.getStorageSync("current")
			}

			this.enable = true
			// if (!uni.getStorageSync('token')) {
			// 	this.isShow = false
			// 	return;
			// };
			// this.init()
		},
		onShareAppMessage: function(options) {
			return {
				title: '源爱汇',
				path: '/page/index/index',
				success: function(res) {
					// 转发成功
				},
				fail: function(res) {
					// 转发失败
				}		
			}		
		},
		onShow() {

			if (uni.getStorageSync("current")) {
				this.current = uni.getStorageSync("current")
			}
			// if (!uni.getStorageSync('token')) {
			// 	this.isShow = false
			// 	return;
			// };
			this.init()

		},
		// 在对应的show和hide页面生命周期中打开或关闭监听
		onHide() {
			this.enable = false
		},
		onTabItemTap() {
			uni.removeStorageSync('current');
		},
		methods: {
			//删除订单
			del(item) {
				let this_ = this
				uni.showModal({
					title: '提示',
					content: '您确定要删除订单吗?',
					success: function(res) {
						if (res.confirm) {
							myCourseApi.edit_orders({
								// token: "5846783423223160416",
								order_index: item.order_index,
								type: "2"
							}).then(res => {
								console.log(res)
								if (res.status == 200) {
									this_.init()
								} else {
									uni.showToast({
										title: res.message,
										icon: 'none',
										duration: 2000
									});
								}

							})
						}
					}
				});
			},
			goLogin() {
				console.log(1)
				uni.navigateTo({
					url: '../login/login'
				})
			},
			init() {

				this.list = []
				myCourseApi.user_order_list({
					// token:uni.getStorageSync("token"),
					status: this.current,
					page: this.page,
					count: "20"
				}).then(res => {
					console.log(res)
					this.list = res.result.list
				})
			},
			//切换tab栏
			currentChange(e) {
				// console.log(e)
				this.current = e
				console.log(this.current)
				this.init()
			},
			goto1(item) {
				uni.removeStorageSync('current');
				uni.navigateTo({
					url: './orderDetail/logistics/logistics?order_index=' + item.order_index
				})
			},
			goto(item) {
				console.log(item)
				// uni.navigateTo({
				// 	url:'./orderDetail/orderDetail?item='+encodeURIComponent(JSON.stringify(item))
				// })
				uni.removeStorageSync('current');
				uni.navigateTo({
					url: './orderDetail/orderDetail?order_index=' + item.order_index
				})
			},
			toDetail(item) {
				console.log(item)
				uni.removeStorageSync('current');
				uni.navigateTo({
					url: "./orderDetail/orderDetail?order_index=" + item.order_index
				})
			}
		},


	}
</script>
<style>
	page {
		height: 100%;
		background-color: #f5f5f5;
	}
</style>

<style lang="scss" scoped>
	.box {
		.ttttt {
			.img {
				width: 396rpx;
				height: 343rpx;
				margin-left: 177rpx;
				margin-top: 340rpx;
			}

			.xbtn-blue {
				width: 300rpx;
				margin-left: 225rpx;
				margin-top: 50rpx;
			}
		}

		.nav {
			background-color: #fff;
			// margin-top: 20rpx;
			height: 70rpx;
			margin-bottom: 20rpx;

			.content-nav {
				background-color: #fff;
				display: flex;
				justify-content: space-around;

				.nav-item {
					.text {
						width: 76rpx;
						height: 25rpx;
						font-size: 26rpx;
						font-family: PingFang SC;
						font-weight: 400;
						line-height: 66rpx;
					}
				}

				.active {
					border-bottom: 4rpx solid #F87897;

					.text {
						color: #F87897;
						font-weight: 500;
						font-size: 30rpx !important;
						line-height: 66rpx;
						font-family: PingFang SC;
						// height: 29rpx;
					}
				}
			}
		}

		.item {
			background-color: #fff;
			margin-bottom: 20rpx;

			.title {
				display: flex;
				justify-content: space-between;
				align-items: center;
				height: 70rpx;
				width: 750rpx;

				.title-l {
					display: flex;
					align-items: center;
					margin-left: 30rpx;
				}

				.title-r {
					margin-right: 30rpx;
				}

				.img {
					height: 32rpx;
					width: 32rpx;
					margin-right: 15rpx;
				}
			}

			.list {
				width: 750rpx;
				height: 210rpx;

				padding: 20rpx 30rpx;
				border-top: 2rpx solid #F5F5F5;
				border-bottom: 2rpx solid #F5F5F5;
				// margin-left: 30rpx;
				display: flex;
				justify-content: flex-start;
				// margin-bottom: 20rpx;

				.img {
					width: 300rpx;
					height: 170rpx;
					border-radius: 10rpx;
					margin-right: 20rpx;
				}

				.list-r {
					width: 380rpx;

					// background-color: red;
					.text-1 {
						// width: 126px;
						white-space: nowrap;
						overflow: hidden;
						text-overflow: ellipsis;
						// height: 31rpx;
						font-size: 32rpx;
						font-family: Source Han Sans CN;
						font-weight: 400;
						color: #333333;

						// line-height: 36px;
						.text-type1 {
							// padding:  10rpx  10rpx;
							padding-left: 10rpx;
							padding-right: 10rpx;
							margin-right: 10rpx;
							background-color: #F87897;
							font-size: 22rpx;
							border-radius: 9rpx;
							color: #FFFFFF;
							height: 22rpx;
						}
					}

					.text-2 {
						// width: 284px;
						// height: 25rpx;
						font-size: 26rpx;
						font-family: Source Han Sans CN;
						font-weight: 300;
						color: #999999;
						// line-height: 36px;
						margin-top: 20rpx;
						margin-bottom: 40rpx;

						white-space: nowrap;
						overflow: hidden;
						text-overflow: ellipsis;
					}

					.list-b {
						display: flex;
						justify-content: space-between;
					}

					.text-3 {
						// width: 90px;
						// height: 24rpx;
						font-size: 30rpx;
						font-family: Source Han Sans CN;
						font-weight: 400;
						color: #FF1C1C;
					}

					.left {
						width: 150rpx;
						height: 50rpx;
						background: #FFFFFF;
						border: 1rpx solid #F87897;
						color: #F87897;
						border-radius: 25rpx;
						text-align: center;
						display: flex;
						// justify-content: space-between;
						align-items: center;
						justify-content: center
					}
				}
			}

			.footer {
				display: flex;
				justify-content: space-between;
				align-items: center;
				height: 70rpx;

				.footer-l {
					margin-left: 30rpx;

					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 500;
					color: #333333;

				}

				.footer-r {
					display: flex;
					// justify-content: space-between;
					align-items: center;
					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 500;
					margin-right: 30rpx;

					.left {
						width: 150rpx;
						height: 50rpx;
						background: #FFFFFF;
						border: 1rpx solid #F87897;
						color: #F87897;
						border-radius: 25rpx;
						text-align: center;
						display: flex;
						// justify-content: space-between;
						align-items: center;
						justify-content: center
					}

					.right {
						width: 150rpx;
						height: 50rpx;
						background: #F87897;
						border-radius: 25rpx;
						text-align: center;
						color: #fff;
						display: flex;
						// justify-content: space-between;
						align-items: center;
						justify-content: center;
						margin-left: 20rpx;


					}
				}
			}
		}

	}
</style>
