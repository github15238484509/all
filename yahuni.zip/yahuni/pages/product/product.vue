<template>
	<view class="box">
		<view class="nav">
			<u-sticky :enable="enable">
				<div class="content-nav">
					<div class="nav-item" :class="{active: zone_index == item1.zone_index}"
						@tap="currentChange(item1.zone_index)" v-for="(item1,index1) in titleList" :key="index1">
						<text class="text">{{item1.zone_name}}</text>
					</div>
					<!-- <div class="nav-item" :class="{active: zone_index==1}" @tap="currentChange(zone_index)">
						<text class="text">零售产品</text>
					</div> -->
				</div>
			</u-sticky>
		</view>
		<view style="text-align: center; width: 100%;">
			<image v-if="list.length==0" src="../../static/datanull.png" class="imgsss"
				style="width: 344rpx;height: 300rpx; margin-top: 60%;"></image>
		</view>
		<view class="list" v-for="(item,index) in list" :key="index" @click="to(item.goods_index)">
			<image :src="$imgUrl(item.goods_icon)" class="img"></image>
			<view class="list-r">
				<view class="text-1">
					<text class="text-type1">
						{{item.zone_name}}
					</text>

					<text>
						{{item.goods_name}}
					</text>

				</view>
				<view class="text-2">
					{{item.goods_describe}}
				</view>
				<view class="text-3">
					￥{{$returnFloat(item.goods_cost)}}
				</view>
				<view class="text-4">
					<view class="left">
						￥{{$returnFloat(item.goods_price)}}
					</view>
					<view class="right">
						已售{{item.goods_sale}}
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import productApi from "../../api/product/product.js"
	export default {
		data() {
			return {
				list: [],
				page: 1,
				titleList: [],
				zone_index: "",
			}
		},
		onLoad() {
			productApi.goods_partition().then(res => {
				console.log(res)
				if (res.status == 200) {
					this.titleList = res.result
					this.zone_index = this.titleList[0].zone_index
					// console.log(this.zone_index);
					this.init()

				} else {
					uni.showToast({
						title: res.message,
						icon: 'none'
					})
				}
			})

		},
		onReachBottom() {
			console.log("触底")
			this.page++
			productApi.goods_list({
				type: "2",
				page: this.page,
				zone_index: this.zone_index,
				count: "10"
			}).then(res => {
				console.log(res)
				if (res.status == 200) {
					this.list = this.list.concat(res.result.list)
				} else {
					uni.showToast({
						title: res.message,
						icon: 'none'
					})
				}
			})

			// this.list = this.list.concat([xxx])
		},
		onShareAppMessage: function(options) {
			return {
				title: '源爱汇',
				path: '/page/index/index',
				success: function(res) {
					// 转发成功
				},
				fail: function(res) {
					// 转发失败
				}		
			}		
		},
		methods: {
			init() {


				productApi.goods_list({
					type: "2",
					zone_index: this.zone_index,
					page: this.page,
					count: "10"
				}).then(res => {
					console.log(res)

					if (res.status == 200) {
						this.list = res.result.list
					} else {
						uni.showToast({
							title: res.message,
							icon: 'none'
						})
					}
				})
			},
			to(id) {
				// console.log(id)
				uni.navigateTo({
					url: "../index/detail/detail?id=" + id
				})
			},
			//切换tab栏
			currentChange(e) {
				console.log(e)

				if (e !== this.zone_index) {
					this.zone_index = e;
				}
				console.log(this.zone_index)
				this.init()
			},
		}
	}
</script>

<style lang="scss">
	.box {
		.nav {
			background-color: #fff;
			// margin-top: 20rpx;
			height: 70rpx;
			margin-bottom: 20rpx;

			.content-nav {
				background-color: #fff;
				display: flex;
				justify-content: space-around;

				.nav-item {
					.text {
						width: 76rpx;
						height: 25rpx;
						font-size: 26rpx;
						font-family: PingFang SC;
						font-weight: 400;
						line-height: 66rpx;
					}
				}

				.active {
					border-bottom: 4rpx solid #F87897;

					.text {
						color: #F87897;
						font-weight: 500;
						font-size: 30rpx !important;
						line-height: 66rpx;
						font-family: PingFang SC;
						// height: 29rpx;
					}
				}
			}
		}

		.list {
			width: 690rpx;
			height: 170rpx;

			margin-left: 30rpx;
			display: flex;
			justify-content: flex-start;
			margin-bottom: 60rpx;

			.img {
				width: 300rpx;
				height: 170rpx;
				border-radius: 10rpx;
				margin-right: 20rpx;
			}

			.list-r {
				width: 360rpx;

				// background-color: red;
				.text-1 {
					overflow: hidden;
					// height: 31rpx;
					// white-space: nowrap;
					font-size: 32rpx;
					font-family: Source Han Sans CN;
					font-weight: 400;
					color: #333333;
					// text-overflow: ellipsis;
					text-overflow: ellipsis;
					display: -webkit-box;
					-webkit-line-clamp: 2;
					-webkit-box-orient: vertical;

					.text-type1 {
						// padding:  10rpx  10rpx;
						padding-left: 10rpx;
						padding-right: 10rpx;
						margin-right: 10rpx;
						background-color: #F87897;
						font-size: 22rpx;
						border-radius: 9rpx;
						color: #FFFFFF;
						height: 22rpx;
					}
				}

				.text-2 {
					// width: 284px;
					white-space: nowrap;
					overflow: hidden;
					text-overflow: ellipsis;
					// height: 25rpx;
					font-size: 26rpx;
					font-family: Source Han Sans CN;
					font-weight: 300;
					color: #999999;
					// line-height: 36px;
					margin-top: 13rpx;
					// margin-bottom: 6rpx;
				}

				.text-3 {
					// width: 90px;
					// height: 24rpx;
					font-size: 30rpx;
					font-family: Source Han Sans CN;
					font-weight: 400;
					color: #FF1C1C;
					// line-height: 36px;
					// margin-bottom: 13rpx;
				}

				.text-4 {
					display: flex;
					justify-content: space-between;
					align-items: center;
					font-size: 24rpx;
					font-family: Source Han Sans CN;
					font-weight: 300;
					color: #999999;

					.left {
						text-decoration: line-through;
						width: 89rpx;
						height: 19rpx;
					}

					.right {
						width: 100rpx;
						height: 23rpx;
					}
				}
			}

			// .list-r {
			// 	width: 360rpx;

			// 	// background-color: red;
			// 	.text-1 {
			// 		overflow: hidden;
			// 		// height: 31rpx;
			// 		white-space: nowrap;
			// 		font-size: 32rpx;
			// 		font-family: Source Han Sans CN;
			// 		font-weight: 400;
			// 		color: #333333;
			// 		text-overflow: ellipsis;
			// 	}

			// 	.text-2 {
			// 		// width: 284px;
			// 		white-space: nowrap;
			// 		overflow: hidden;
			// 		text-overflow: ellipsis;
			// 		// height: 25rpx;
			// 		font-size: 26rpx;
			// 		font-family: Source Han Sans CN;
			// 		font-weight: 300;
			// 		color: #999999;
			// 		// line-height: 36px;
			// 		margin-top: 13rpx;
			// 		margin-bottom: 13rpx;
			// 	}

			// 	.text-3 {
			// 		// width: 90px;
			// 		// height: 24rpx;
			// 		font-size: 30rpx;
			// 		font-family: Source Han Sans CN;
			// 		font-weight: 400;
			// 		color: #FF5657;
			// 		// line-height: 36px;
			// 		margin-bottom: 13rpx;
			// 	}

			// 	.text-4 {
			// 		display: flex;
			// 		justify-content: space-between;
			// 		align-items: center;
			// 		font-size: 24rpx;
			// 		font-family: Source Han Sans CN;
			// 		font-weight: 300;
			// 		color: #999999;

			// 		.left {
			// 			text-decoration: line-through;
			// 			width: 89rpx;
			// 			height: 19rpx;
			// 		}

			// 		.right {
			// 			width: 100rpx;
			// 			height: 23rpx;
			// 		}
			// 	}
			// }
		}
	}
</style>
