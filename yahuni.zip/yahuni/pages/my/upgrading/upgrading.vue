<template>
	<view class="box">
		<view class="title">
			<view class="left">
				说明:
			</view>
			<view class="right">
				请缴纳相应的金额转账到上级推荐人的银行卡账户里，截图保存<text style="color: #F46487;">转账凭证</text>后,再进行下方信息填写
			</view>
		</view>
		<view class="list">
			<view class="left">
				转账方式：
			</view>
			<view class="right">
				<picker class="right-picker" @change="bindPickerChange" :value="index" :range="array">
					<!-- <view class="uni-input">{{array[index]}}</view>-->
					<text class="uni-input"> {{array[index]}} </text>
					<image src="../../../static/right.png" style="width: 13rpx;height: 26rpx;margin-left: 40rpx;">
					</image>
				</picker>
			</view>
			<!-- <image src="../../../static/right.png" style="width: 13rpx;height: 26rpx;margin-left: 30rpx;"></image> -->
		</view>
		<view class="list">
			<view class="left">
				转账账号：
			</view>
			<view class="right">
				<input type="text" value="" placeholder="请填写您已付款的账户" v-model="user" />
			</view>

		</view>
		<view class="list">
			<view class="left">
				转账金额：
			</view>
			<view class="right">
				<input type="digit" value="" placeholder="请填写已转账的金额" v-model="money" />
			</view>

		</view>
		<view class="list">
			<view class="left">
				真实姓名：
			</view>
			<view class="right">
				<input type="text" value="" placeholder="请填写您的真实姓名" v-model="name" />
			</view>

		</view>
		<view class="upImg">
			<view class="left">
				<view class="text">
					转账凭证截图:
				</view>
				<view class="text1">
					1.请上传转账凭证截图
				</view>
			</view>
			<view class="right">
				<u-uploadd ref="uUpload" :custom-btn="true" max-count="1" :action="action" :show-progress="false"
					:auto-upload="true" width="126rpx" height="126rpx" @on-success="imgChange1" @on-remove="removeArr"
					:file-list="envimgs">
					<view slot="addBtn" style="box-sizing: border-box;width: 126rpx;height: 126rpx;" class="slot-btn"
						hover-class="slot-btn__hover" hover-stay-time="150">
						<image src="../../../static/add.png" class="img"></image>
					</view>
				</u-uploadd>
			</view>
		</view>
		<view class="level">
			<view class="title1">
				选择升级的身份级别
			</view>
			<view class="" style="margin-left: 30rpx;margin-top: 30rpx;">
				<u-radio-group v-model="level" @change="radioGroupChange">
					<u-radio active-color="#F87897" @change="radioChange" v-for="(item, index) in list" :key="index"
						:name="item.name" :disabled="item.disabled">
						{{item.name}}
					</u-radio>
				</u-radio-group>
			</view>
		</view>
		<view class="list2">
			<view class="left">
				姓 名：
			</view>
			<view class="right">
				<input type="text" value="" placeholder="请输入您的名字" v-model="name2" />
			</view>

		</view>
		<view class="list2">
			<view class="left">
				联系电话：
			</view>
			<view class="right">
				<input type="number" value="" placeholder="请输入联系电话" v-model="phone" />
			</view>

		</view>
		<view class="list2">
			<citydata @get_reginId="getId" :nnn="objs" style="width: 100%;margin-right: 30rpx;"></citydata>
		</view>
		<view class="list2">
			<input style="margin-left: 30rpx;" type="text" value="" placeholder="请输入详细地址" v-model="address" />
		</view>
		<view class="footer" style="margin-top: 20rpx;">
			<view class="title2">
				备注（选填）
			</view>
			<view style="background-color: #FFFFFF;padding: 0 30rpxs;">
				<view
					style="height: 260rpx;display: flex;justify-content: center;align-items: center;position: relative;">
					<textarea
						style="height: 200rpx;width: 690rpx;background-color: #F5F5F5;padding: 20rpx;box-sizing: border-box;"
						maxlength="500" placeholder="请填写其他备注信息，最多输入100个字" v-model="reason" @input="monitor"></textarea>

					<text
						style="position: absolute;right: 50rpx;bottom: 50rpx;font-size: 24rpx;color: #999999;">{{num}}/500</text>
				</view>

			</view>
		</view>
		<view class="">
			<view class="btn" @click="next">
				<text>提交申请</text>
			</view>
		</view>

	</view>
</template>

<script>
	import citydata from './citydata2.vue'
	import myApi from "../../../api/my/my.js"
	export default {
		components: {
			citydata
		},
		data() {
			return {
				array: ['银行卡', '微信', '支付宝'],
				index: 0,
				name: "",
				name2: "",
				phone: "",
				money: "",
				user: "",
				//上传地址
				action: this.$uptImgUrl,
				imgArr: "",
				envimgs: [],
				level: "",
				list: [],
				objs: {},
				province_id: "",
				province_name: "",
				city_id: "",
				city_name: "",
				county_id: "",
				county_name: "",
				selectArea: "",
				address: "",
				num: "0",
				//备注
				reason: "",
				upgrade_id: "",
				flag: ""
			};
		},
		onLoad(e) {
			myApi.get_grade().then(res => {
			        console.log(res)
			        if (res.status == 200) {
						this.list=res.result
						this.level=this.list[0].name
			        } else {
			                uni.showToast({
			                title: res.message,
			                icon: 'none'
			                })
			        }
			})
			if (e.flag == "1") {
				this.flag = "1"
				myApi.upgrade_info().then(res => {
					console.log(res)
					if (res.status == 200) {
						// if (res.result.rank_index == "2") {
						// 	this.level = 'VIP会员'
						// }
						// if (res.result.rank_index == "3") {
						// 	this.level = '一级代理'
						// }
						// if (res.result.rank_index == "4") {
						// 	this.level = '全国代理'
						// 	console.log(this.level);
						// }
						this.upgrade_id = res.result.upgrade_id
						this.index = res.result.payment_method
						this.user = res.result.account_number
						this.money = this.$returnFloat(res.result.amount)
						this.name = res.result.full_name
						this.name2 = res.result.name
						this.phone = res.result.phone
						this.reason = res.result.remarks_2
						this.address = res.result.address
						this.objs.province_id = res.result.province_id
						this.objs.city_id = res.result.city_id
						this.objs.county_id = res.result.county_id
						this.county_id = res.result.county_id
						this.objs.province_name = res.result.province_name
						this.objs.city_name = res.result.city_name
						this.objs.county_name = res.result.county_name


						this.province_id = this.objs.province_id;
						this.city_id = this.objs.city_id;
						this.county_id = this.objs.county_id;
						this.objs.show = true
						this.envimgs.push({
							url: this.$imgUrl(res.result.screenshot_1)
						})
						this.imgArr = res.result.screenshot_1
						console.log(this.objs);
					} else {
						uni.showToast({
							title: res.message,
							icon: 'none'
						})
					}
				})
			}
		},
		onShareAppMessage: function(options) {
			return {
				title: '源爱汇',
				path: '/page/index/index',
				success: function(res) {
					// 转发成功
				},
				fail: function(res) {
					// 转发失败
				}		
			}		
		},
		methods: {
			monitor(e) {

				this.num = e.detail.value.length
			},
			getId(obj) {
				console.log(obj);
				this.selectArea = obj
				this.province_name = obj.province_name;
				this.city_name = obj.city_name;
				this.county_name = obj.county_name;
				this.province_id = obj.province_id;
				this.city_id = obj.city_id;
				this.county_id = obj.county_id;
			},
			bindPickerChange: function(e) {
				console.log(e)
				this.index = e.target.value
			},
			removeArr(index) {
				this.imgArr = ""
				console.log(this.imgArr);
			},
			// imgChange3(e){
			// 	console.log(e)
			// 	let a=JSON.stringify(e)
			// 	// this.files = this.$refs.uUpload.lists;
			// 	uni.showModal({

			// 			title:"提示",
			// 			content:a
			// 	})

			// },
			imgChange1(e) {
				console.log(e)
				let a = JSON.stringify(e)
				// this.files = this.$refs.uUpload.lists;

				this.imgArr = e.result.img_name


				console.log(this.imgArr)
			},
			// 选中某个单选框时，由radio时触发
			radioChange(e) {
				// console.log(e);
				// this.level=e

			},
			// 选中任一radio时，由radio-group触发
			radioGroupChange(e) {
				console.log(e);
				if (e == 'VIP会员') {
					// this.level = "2"
					this.level = "VIP会员"
				}
				if (e == '一级代理') {
					// this.level = "3"
					this.level = "一级代理"
				}
				if (e == '全国代理') {
					// this.level = "4"
					this.level = "全国代理"
				}
				console.log(this.level);
			},
			next() {
				if (!/(^1[3|4|5|6|7|8|9][0-9]{9}$)/.test(this.phone)) {
					uni.showToast({
						title: '请输入正确的手机号码',
						icon: 'none'
					});
					return;
				}
				if (this.user == "") {
					uni.showToast({
						title: '请输入转账账号',
						icon: 'none'
					});
					return;
				}
				if (this.money == "") {
					uni.showToast({
						title: '请输入转账金额',
						icon: 'none'
					});
					return;
				}
				if (this.name == "") {
					uni.showToast({
						title: '请输入真实姓名',
						icon: 'none'
					});
					return;
				}
				if (this.imgArr == "") {
					uni.showToast({
						title: '请上传转账凭证',
						icon: 'none'
					});
					return;
				}
				if (this.name2 == "") {
					uni.showToast({
						title: '请输入名字',
						icon: 'none'
					});
					return;
				}
				if (this.name2 == "") {
					uni.showToast({
						title: '请输入名字',
						icon: 'none'
					});
					return;
				}
				if (this.county_id == "") {
					uni.showToast({
						title: '请选择区域',
						icon: 'none'
					});
					return;
				}
				if (this.address == "") {
					uni.showToast({
						title: '请输入详细地址',
						icon: 'none'
					});
					return;
				}
				if (this.level !== "3" && this.level !== "4") {
					this.level = "2"
				}

				myApi.user_upgrade({
					//修改的时候传递
					upgrade_id: this.upgrade_id,
					payment_method: this.index,
					account_number: this.user,
					amount: this.money,
					full_name: this.name,
					screenshot_1: this.imgArr,
					rank_index: this.level,
					name: this.name2,
					phone: this.phone,
					province_id: this.province_id,
					city_id: this.city_id,
					county_id: this.county_id,
					address: this.address,
					remarks_2: this.reason
				}).then(res => {
					console.log(res)
					if (res.status == 200) {
						uni.reLaunch({
							url: "./upgradingInfo/upgradingInfo"
						})
					} else {
						uni.showToast({
							title: res.message,
							icon: 'none'
						})
					}
				})
			}
		}
	}
</script>
<style>
	page {
		height: 100%;
		background-color: #f5f5f5;
	}
</style>
<style lang="scss">
	.box {
		.btn {
			width: 690rpx;
			height: 90rpx;
			background: #F66F90;
			border-radius: 20rpx;
			margin-top: 80rpx;
			margin-left: 30rpx;
			margin-bottom: 60rpx;
			display: flex;
			align-items: center;
			justify-content: center;

			text {

				font-size: 36rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: #FFFFFF;
			}
		}

		.title {
			height: 117rpx;
			width: 100%;
			padding: 28rpx;
			display: flex;
			justify-content: flex-start;
			font-size: 24rpx;
			font-family: PingFang SC;
			font-weight: 400;
			color: #999999;

			.left {
				width: 90rpx;
			}
		}

		.list {
			background-color: #FFFFFF;
			height: 87rpx;
			display: flex;
			justify-content: flex-start;
			align-items: center;

			.left {
				margin-left: 30rpx;

				font-size: 26rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #333333;

			}

			.right {

				font-size: 26rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #999999;
				width: 530rpx;
				

				.right-picker {

					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #999999;
					

				}
			}
		}

		.upImg {
			height: 197rpx;
			display: flex;
			justify-content: space-between;
			background-color: #FFFFFF;

			.left {
				margin-left: 30rpx;
				margin-top: 30rpx;

				.text {

					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #333333;

				}

				.text1 {
					margin-top: 40rpx;
					font-size: 24rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #999999;

				}
			}

			.img {
				width: 100%;
				height: 100%;
				margin: 0;
				padding: 0;

			}

			.right {
				margin-right: 60rpx;
				padding-top: 30rpx;
			}
		}

		.level {
			height: 168rpx;
			padding: 30rpx;
			background-color: #FFFFFF;
			margin-top: 30rpx;

			.title1 {

				font-size: 26rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #222222;

			}
		}

		.list2 {
			background-color: #FFFFFF;
			height: 87rpx;
			display: flex;
			justify-content: space-between;
			align-items: center;

			.left {
				margin-left: 30rpx;

				font-size: 26rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #333333;

			}

			.right {

				font-size: 26rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #999999;
				text-align: right;
				margin-right: 30rpx
			}
		}

		.footer {
			width: 100%;
			height: 320rpx;
			background-color: #FFFFFF;
			overflow: hidden;

			.title2 {
				margin-left: 30rpx;
				margin-top: 30rpx;
				// margin-bottom: 20rpx;
				font-size: 26rpx;
				font-family: Source Han Sans CN;
				font-weight: 300;
				color: #222222;

			}
		}
	}
</style>
