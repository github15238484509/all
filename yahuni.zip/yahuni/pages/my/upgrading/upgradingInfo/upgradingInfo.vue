<template>
	<view class="box">
		<view class="content" >
			<view class="item">
				<view class="dot">
					
				</view>
				<view class="text">
					<view class="text1">
						信息提交成功,等待审核
					</view>
					<view class="text2">
						{{time}}
					</view>
				</view>
			</view>
			<view class="line" v-if="show">
				
			</view>
			<view class="item" style="margin-top: 65rpx;" v-if="show">
				<view class="dot">
					
				</view>
				<view class="text">
					<view class="text1">
						信息审核失败
					</view>
					<view class="text2">
						{{time1}}
					</view>
				</view>
			</view>
			<view class="item1" v-if="show">
				<text class="text1">失败原因：{{text}}</text>
				<text class="text2" @click="goto()">重新提交</text>
			</view>
		</view>
	</view>
</template>

<script>
	
	import myApi from "../../../../api/my/my.js"
	export default {
		data() {
			return {
				time:"",
				show:false,
				time1:"",
				text:""
			};
		},
		onLoad() {
			myApi.upgrade_info().then(res => {
			        console.log(res)
			        if (res.status == 200) {
						
						let str = this.$time(res.result.add_time,0)
						let str1 = this.$time(res.result.add_time,4)
						this.time= str+'\xa0\xa0\xa0'+str1 
						
						
						if(res.result.state=="1"){
							
							let str2 = this.$time(res.result.edit_time,0)
							let str3 = this.$time(res.result.edit_time,4)
							this.time1= str+'\xa0\xa0\xa0'+str1 
							this.text=res.result.reason
							this.show=true
							
							
						}
			        } else {
			                uni.showToast({
			                title: res.message,
			                icon: 'none'
			                })
			        }
			})
			
		},
		onShareAppMessage: function(options) {
			return {
				title: '源爱汇',
				path: '/page/index/index',
				success: function(res) {
					// 转发成功
				},
				fail: function(res) {
					// 转发失败
				}		
			}		
		},
		methods:{
			goto(){
				uni.navigateTo({
					url:"../upgrading?flag="+1
				})
			}
		}
	}
</script>

<style lang="scss">
	.box{
		padding: 50rpx;
		.content{
			width: 100%;
			
			position: relative;
			.item1{
				
				font-size: 24rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: #999999;
				margin-left: 38rpx;
				.text1{
					
				}
				.text2{
					color: #F87897;
					margin-left: 20rpx;
				}
			}
			.line{
				width: 2px;
				height: 80rpx;
				background: #F87897;
				position: absolute;
				left: 9rpx;
				top: 67rpx;
			}
			.item{
				display: flex;
				justify-content: flex-start;
				align-items: center;
				.text{
					margin-left: 20rpx;
					.text1{
						
						font-size: 26rpx;
						font-family: PingFang SC;
						font-weight: 500;
						color: #333333;
						margin-bottom: 10rpx;
					}
					.text2{
						
						font-size: 24rpx;
						font-family: PingFang SC;
						font-weight: 400;
						color: #999999;
						
					}
				}
				.dot{
					width: 20rpx;
					height: 20rpx;
					background: #F87897;
					border-radius: 50%;
				}
			}
		}
	}
</style>
