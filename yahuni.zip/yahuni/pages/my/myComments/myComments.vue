<template>
	<view class="">
		<view class="comments" v-if="evaluateInfo.length!=0">
			<block v-for="(item,i) in evaluateInfo" :key="i">
				<view style="background-color: #f5f5f5;width: 100%;height: 20rpx;"></view>
				<view class="user_msg">
					<view class="user_left">
						<image :src="$imgUrl(item.comment_user_photo)"></image>
						<view class="">
							<view class="">
								{{item.comment_nick}}
								<block v-for="(items,j) in item.src" :key="j">
									<image :src="items.icon" class="star"></image>
								</block>

							</view>
							<view class="label">
								({{item.goods_sku_name}})
							</view>
						</view>
					</view>
					<view class="time">
						{{item.comment_time}}
					</view>
				</view>
				<view class="content">
					{{item.comment_content}}
				</view>
				<view class="imgss" v-if="item.comment_images!==''">
					<image :src="$imgUrl(item1)" v-for="(item1,k) in item.comment_images" :key="k" class="img22"
						@click="toBig(item.comment_images,k)"></image>
				</view>
				<view class="detail">
					<view class="con" @click="goDetail(item.goods_status,item.comment_goods_id)">
						<view class="img">
							<image :src="$imgUrl(item.goods_icon)" mode=""></image>
						</view>
						<view class="right">
							<view class="right_msg">
								<text class="text-type1">
									{{item.zone_name?item.zone_name:""}}
								</text>

								<text>
									{{item.goods_name?item.goods_name:""}}
								</text>

							</view>
							<view class="num">
								<view class="">
									<text class="text1">￥</text>
									<text class="text2">{{item.goods_cost/100}}</text>
									<!-- <text class="text3" v-if="item.goods_unit">/{{item.goods_unit}}</text> -->
								</view>
								<view class="count">
									<!-- <text class="text4">×</text>{{item.goods_count}} -->
								</view>
							</view>
						</view>
					</view>
				</view>
			</block>
		</view>
		<view style="text-align: center; width: 100%;" v-else>
			<image v-if="evaluateInfo.length==0" src="../../../static/datanull.png" class="imgsss"
				style="width: 344rpx;height: 300rpx; margin-top: 60%;"></image>

		</view>
	</view>
</template>

<script>
	import get_comment from '../../../api/my/my.js'
	export default {
		data() {
			return {
				page: 1,
				pageCount: 10,
				last_page: "",
				cdnUrl: '',
				goods_id: '', //商品id
				type: '0',
				evaluateInfo: [],
				stars: [{
						icon: '../../../static/star.png',
						icon1: '../../../static/star1.png',
						flag: false
					},
					{
						icon: '../../../static/star.png',
						icon1: '../../../static/star1.png',
						flag: false
					},
					{
						icon: '../../../static/star.png',
						icon1: '../../../static/star1.png',
						flag: false
					},
					{
						icon: '../../../static/star.png',
						icon1: '../../../static/star1.png',
						flag: false
					},
					{
						icon: '../../../static/star.png',
						icon1: '../../../static/star1.png',
						flag: false
					}
				], //评价星星
			}
		},
		onLoad() {
			this.init()
		},
		onShareAppMessage: function(options) {
			return {
				title: '源爱汇',
				path: '/page/index/index',
				success: function(res) {
					// 转发成功
				},
				fail: function(res) {
					// 转发失败
				}		
			}		
		},
		methods: {
			init() {
				console.log(111111111111111)
				let self = this;
				get_comment.get_comment({
					page: self.page,
					count: self.pageCount
				}).then(res => {
					if (res.status == 200) {
						self.last_page = res.result.last_page;

						if (res.result.list.length != 0) {
							for (let i = 0; i < res.result.list.length; i++) {
								if (res.result.list[i].comment_images !== "") {
									res.result.list[i].comment_images = res.result.list[i].comment_images.split(
										/(^\/)|(,\/)/)
									console.log(res.result.list[i].comment_images);
									if (res.result.list[i].comment_images.length == 1) {
										console.log(res.result.list[i].comment_images)
										res.result.list[i].comment_images = res.result.list[i].comment_images[0]
											.split(",")


									} else {
										res.result.list[i].comment_images = res.result.list[i].comment_images
											.filter((item) => {
												if (item) {
													return item.startsWith("CxtxMapi")
												}
											})
										res.result.list[i].comment_images = arr
									}
								}

								res.result.list[i].comment_time = self.$time(res.result.list[i].comment_time, 0)
								if (res.result.list[i].comment_score == 0) {
									var src = [{
											icon: '../../../static/star1.png'
										},
										{
											icon: '../../../static/star1.png'
										},
										{
											icon: '../../../static/star1.png'
										},
										{
											icon: '../../../static/star1.png'
										},
										{
											icon: '../../../static/star1.png'
										},
									]
								} else if (res.result.list[i].comment_score == 1) {
									var src = [{
											icon: '../../../static/star.png'
										},
										{
											icon: '../../../static/star1.png'
										},
										{
											icon: '../../../static/star1.png'
										},
										{
											icon: '../../../static/star1.png'
										},
										{
											icon: '../../../static/star1.png'
										},
									]
								} else if (res.result.list[i].comment_score == 2) {
									var src = [{
											icon: '../../../static/star.png'
										},
										{
											icon: '../../../static/star.png'
										},
										{
											icon: '../../../static/star1.png'
										},
										{
											icon: '../../../static/star1.png'
										},
										{
											icon: '../../../static/star1.png'
										},
									]
								} else if (res.result.list[i].comment_score == 3) {
									var src = [{
											icon: '../../../static/star.png'
										},
										{
											icon: '../../../static/star.png'
										},
										{
											icon: '../../../static/star.png'
										},
										{
											icon: '../../../static/star1.png'
										},
										{
											icon: '../../../static/star1.png'
										},
									]
								} else if (res.result.list[i].comment_score == 4) {
									var src = [{
											icon: '../../../static/star.png'
										},
										{
											icon: '../../../static/star.png'
										},
										{
											icon: '../../../static/star.png'
										},
										{
											icon: '../../../static/star.png'
										},
										{
											icon: '../../../static/star1.png'
										},
									]
								} else if (res.result.list[i].comment_score == 5) {
									var src = [{
											icon: '../../../static/star.png'
										},
										{
											icon: '../../../static/star.png'
										},
										{
											icon: '../../../static/star.png'
										},
										{
											icon: '../../../static/star.png'
										},
										{
											icon: '../../../static/star.png'
										},
									]
								}
								res.result.list[i].src = src
								self.evaluateInfo.push(res.result.list[i])
							}
						} else {
							self.evaluateInfo = []
						}
					}
				})
			},
			goDetail(status, id) {
				if (status == '2') {
					uni.navigateTo({
						url: '../../index/detail/detail?id=' + id
					})
				} else {
					uni.navigateTo({
						url: '../../index/detail/noGoods/noGoods'
					})
				}
			},
			toBig(arr, index) {
				let imgs = []
				arr.forEach(el => {
					el = this.$imgUrl(el)
					imgs.push(el)
				})

				console.log(imgs)
				// let img =this.$imgUrl(url)
				// 预览图片
				uni.previewImage({
					urls: imgs,
					current: index

				});

			},
		},
		onShow() {
			// this.evaluateInfo = []
			// this.cdnUrl = this.$cdnUrl
			// this.init()
		},
		onReachBottom() {
			if (this.page < this.last_page) {
				this.page++
				this.init()
			}
		}
	}
</script>

<style lang="scss">
	.none {
		margin: 50rpx;
		text-align: center;
	}

	.imgss {
		margin-top: 20rpx;
		display: flex;
		justify-content: flex-start;
		margin-left: 108rpx;
		flex-wrap: wrap;

		.img22 {
			width: 130rpx;
			height: 130rpx;
			margin-right: 20rpx;
			margin-bottom: 20rpx;
		}
	}

	.comments {
		.user_msg {
			padding: 0 30rpx;
			display: flex;
			justify-content: space-between;
			margin-top: 20rpx;

			.user_left {
				display: flex;
				font-size: 26rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: rgba(51, 51, 51, 1);

				image {
					width: 60rpx;
					height: 60rpx;
					border-radius: 50%;
					margin-right: 20rpx;
				}

				.star {
					width: 22rpx;
					height: 22rpx;
					margin: 0 0 0 10rpx;
				}

				.label {

					font-size: 24rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: rgba(153, 153, 153, 1);
				}
			}

			.time {
				font-size: 24rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: rgba(153, 153, 153, 1);
			}
		}

		.content {
			font-size: 26rpx;
			font-family: PingFang SC;
			font-weight: 400;
			color: rgba(51, 51, 51, 1);
			margin-top: 20rpx;
			padding-left: 110rpx;
		}

		.imgs {
			display: flex;
			flex-wrap: wrap;
			padding-left: 110rpx;
			margin-bottom: 20rpx;

			image {
				width: 130rpx;
				height: 130rpx;
				margin: 20rpx 10rpx 0;
			}
		}

		.detail {
			// padding: 0 30rpx 30rpx 110rpx;
			overflow: hidden;

			.con {
				margin-top: 30rpx;
				padding: 20rpx;
				background-color: #F8F8F8;
				display: flex;
				margin-left: 103rpx;
				width: 617rpx;
				margin-bottom: 30rpx;

				.img {
					margin-right: 20rpx;

					image {
						width: 130rpx;
						height: 130rpx;
					}
				}

				.right {
					flex: 1;

					.right_msg {
						height: 80rpx;
						font-size: 24rpx;
						font-family: PingFang SC;
						font-weight: 500;
						color: rgba(51, 51, 51, 1);
						overflow: hidden;
						text-overflow: ellipsis;
						word-break: break-all;
						display: -webkit-box;
						-webkit-box-orient: vertical;
						-webkit-line-clamp: 2;
						line-height: 40rpx;

						.text-type1 {
							// padding:  10rpx  10rpx;
							padding-left: 10rpx;
							padding-right: 10rpx;
							margin-right: 10rpx;
							background-color: #F87897;
							font-size: 22rpx;
							border-radius: 9rpx;
							color: #FFFFFF;
							height: 22rpx;
						}
					}

					.num {
						margin-top: 10rpx;
						font-family: PingFang SC;
						color: rgba(153, 153, 153, 1);
						display: flex;
						justify-content: space-between;

						.text1 {
							font-size: 22rpx;
							color: rgba(255, 54, 54, 1);
						}

						.text2 {
							font-size: 30rpx;
							color: rgba(255, 54, 54, 1);
						}

						.text3 {
							font-size: 18rpx;
							color: rgba(153, 153, 153, 1);
						}

						.count {
							font-size: 30rpx;
							color: #999;

							.text4 {
								font: 22rpx;
							}
						}
					}
				}
			}
		}

	}
</style>
