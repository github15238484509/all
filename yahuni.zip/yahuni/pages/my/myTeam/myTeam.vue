<template>
	<view class="box">
		<view class="nav">
			<u-sticky :enable="enable">
				<div class="content-nav">
					<div class="nav-item" :class="{active: current=='1'}" @tap="currentChange('1')">
						<text class="text">上月</text>
					</div>
					<div class="nav-item" :class="{active: current=='2'}" @tap="currentChange('2')">
						<text class="text">本月</text>
					</div>
					<div class="nav-item" :class="{active: current=='3'}" @tap="currentChange('3')">
						<text class="text">累计</text>
					</div>

				</div>
			</u-sticky>
		</view>
		<view class="title">
			<text>我的业绩(元）:</text>
			<text style="font-size: 42rpx;font-weight: bold;">{{$returnFloat(obj.MyAchievemen)}}</text>
		</view>
		<view class="title1" >
			<view class="left" @click="goto()">
				<view class="left-3">
					<view class="left-1">
						本月团队总人数：
					</view>
					<view class="left-2" style="margin-top: 20rpx;">
						{{obj.TeamNum}}
					</view>
				</view>

				<image src="../../../static/right.png" class="img"></image>
			</view>
			<view class="right">
				<view class="left-3">
					<view class="left-1">
						间推官方合伙人：
					</view>
					<view class="left-2" style="margin-top: 20rpx;">
						{{obj.InterpositionNum}}
					</view>
				</view>
			</view>
		</view>
		<view class="title1" >
			<view class="left" @click="goto()">
				<view class="left-3">
					<view class="left-1">
						直推官方合伙人：
					</view>
					<view class="left-2" style="margin-top: 20rpx;">
						{{obj.DirectPushNum}}
					</view>
				</view>
		
				<image src="../../../static/right.png" class="img"></image>
			</view>
			<view class="right">
				<view class="left-3">
					<view class="left-1">
						直推官方合伙人业绩：
					</view>
					<view class="left-2" style="margin-top: 20rpx;">
						{{$returnFloat(obj.DirectPushAchievemen)}}
					</view>
				</view>
			</view>
		</view>
		<view class="title1" >
			<view class="left" @click="goto()">
				<view class="left-3">
					<view class="left-1">
						体系有效官方合伙人：
					</view>
					<view class="left-2" style="margin-top: 20rpx;">
						{{obj.SystemNum}}
					</view>
				</view>
		
				<image src="../../../static/right.png" class="img" style="margin-left: 26rpx;"></image>
			</view>
			<view class="right">
				<view class="left-3">
					<view class="left-1">
						体系有效官方合伙人业绩：
					</view>
					<view class="left-2" style="margin-top: 20rpx;">
						{{$returnFloat(obj.SystemAchievemen)}}
					</view>
				</view>
			</view>
		</view>
		<view style="width: 100%;height: 20rpx;"></view>
		<!-- 我的团队 -->
		<view class="time">
			
			<view style="display: flex;  align-items: center;margin-bottom: 10rpx;padding: 10rpx 0 10rpx 43rpx;">
				<view class="inp">
					<image src="../../../static/searchs.png"></image>
					<input type="number" maxlength="11" @input="iptNum" placeholder="请输入手机号搜索团队成员" v-model="phone" placeholder-style="color:#CCCCCC"/>
					
					<!-- <image :src="$imgUrl('/CxtxUni/static/index/del-round.png')" mode="" v-if="phone.length!=0" @click="reset"></image> -->
					<image src="../../../static/index/del-round.png" v-if="phone.length!=0" @click="reset"></image>
				</view>
				<text style="font-size: 30rpx;color: #F87897;margin-left: 40rpx;" @click="getsearch">搜索</text>
			</view>
			<!-- 个人信息 -->
			<block>
				
				<view class="user" v-for="(item,index) in teamList" :key="index" v-if="teamList.length>0">
					
					<view style="display: flex; align-items: center;">
						<view class="one">
							
							<image :src="$imgUrl(item.photo)"></image>
							
							<!-- <view class="rank" v-if="item.rank==1">普通会员</view>
							<view class="rank" v-if="item.rank==2">VIP会员</view>
							<view class="rank" v-if="item.rank==3">推荐官</view>
							<view class="rank" v-if="item.rank==5">服务商</view> -->
							<view class="rank">
								{{item.rank_name}}
							</view>
						</view>
						<view class="two">
							<view>用户昵称:{{item.name}}</view>
							<view style="margin-top: 10rpx;">手机号码: {{item.phone | mobileFilter}}</view>
						</view>
					</view>
					<view @click="getsee(item)">查看>></view>
				</view>
				<loadmore :content-text="contentText" :status="status" @clickLoadMore="reachBtm" v-if="isshow&&teamList.length>0"></loadmore>
				<view class="zwsj" v-if="teamList.length==0">
					<image src="../../../static/datanull.png" style="width: 344rpx;height: 300rpx;"></image>
				</view>
			</block>
		</view>
		<!-- 查看弹窗 -->
		<view class="window" v-if="see" @click="closeWindow">
			<view class="particulars">
				<image src="../../../static/index/del-round.png" class="del" @click="getdel()"></image>
				<!-- <image :src="$imgUrl('/CxtxUni/static/index/del-round.png')" mode=""></image> -->
				
				<view style="font-size: 36rpx;font-weight: bold;text-align: center;margin-bottom: 40rpx;">成员详情</view>
				<view class="hang">
					<view>用户头像</view>
					<image :src="$imgUrl(teamMember.photo)" style="margin-left: 16rpx;"></image>
		
				</view>
				<view class="hang">
					<view>用户昵称</view>：
					<text>{{teamMember.name}}</text>
				</view>
				<view class="hang">
					<view>等级</view>：
					<text class="rank" >{{teamMember.rank_name}}</text>
					
				</view>
				<view class="hang">
					<view>手机号</view>：
					<text>{{teamMember.phone}}</text>
				</view>
				<view class="hang">
					<view>性别</view>：
					<!-- <text v-if="teamMember.sex==''">男</text>
					<text v-if="teamMember.sex=='女'">女</text> -->
					<text>{{teamMember.sex}}</text>
				</view>
				<view class="hang">
					<view>累计消费</view>：
					<text>{{$returnFloat(teamMember.achievement)}}</text>
				</view>
				<view class="hang">
					<view>直接推荐</view>：
					<text>{{teamMember.straight_num}}人</text>
				</view>
				<view class="hang">
					<view>间接推荐</view>：
					<text>{{teamMember.interposition_num}}人</text>
				</view>
				<view class="hang">
					<view>注册时间</view>：
		
					<text> {{timeConvert(teamMember.regtime,0)}}</text>
		
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import loadmore from "../../../uni-load-more/uni-load-more.vue"
	import myTeamApi from "../../../api/my/my.js"
	export default {
		data() {
			return {
				//激活的tab栏
				current: '2',
				enable: true,
				
				
					phone: '', //手机号
					see: false, //弹窗是否显示
					
					
					
				// token: "12223161487201300",
					//团队列表
					teamList: [],
					//数组备份  用于重置数组
					preList: [],
					
					flag: true,
					isshow: true,
					//要查询的页码
					page: 1,
					//一页多少条
					count: 10,
					//当前页
					currentPage: "",
					//总页数
					lastPage: "",
					//判断触底加载是否触发调用接口
					flag1: true,
					teamMember:{},
					status: 'more',
					statusTypes: [{
						value: 'more',
						text: '加载前',
						checked: true
					}, {
						value: 'loading',
						text: '加载中',
						checked: false
					}, {
						value: 'noMore',
						text: '没有更多',
						checked: false
					}],
					contentText: {
						contentdown: '查看更多',
						contentrefresh: '加载中',
						contentnomore: '没有更多了'
					},	
					obj:{
						
					}
					
			};
		},
		onLoad(options) {	
			
			this.init();
			this.init1();
		},
		onShareAppMessage: function(options) {
			return {
				title: '源爱汇',
				path: '/page/index/index',
				success: function(res) {
					// 转发成功
				},
				fail: function(res) {
					// 转发失败
				}		
			}		
		},
		//触底分页
		onReachBottom() {
			if (this.flag1) {
				this.reachBtm();
			}
		
		},
		filters: {
			mobileFilter(val) {
				let reg = /^(.{3}).*(.{4})$/
				return val.replace(reg, '$1****$2')
			}
		},
		methods: {
			goto(){
				uni.navigateTo({
					url:"./teamNum/teamNum?status="+this.current
				})
			},
			init1(){
				myTeamApi.user_team({
					type:this.current
				}).then(res => {
				        console.log(res)
				        if (res.status == 200) {
				        this.obj=res.result
				        } else {
				                uni.showToast({
				                title: res.message,
				                icon: 'none'
				                })
				        }
				})
			},
			//切换tab栏
			currentChange(e) {
				// console.log(e)
				this.current = e
				// console.log(this.current)
				this.init1()
			},
			
			//时间戳转日期
			timeConvert(timestamp, num) { //num:0 YYYY-MM-DD  num:1  YYYY-MM-DD hh:mm:ss // timestamp:时间戳 
			
				timestamp = timestamp + '';
				timestamp = timestamp.length == 10 ? timestamp * 1000 : timestamp;
				var date = new Date(timestamp);
				var y = date.getFullYear();
				var m = date.getMonth() + 1;
				m = m < 10 ? ('0' + m) : m;
				var d = date.getDate();
				d = d < 10 ? ('0' + d) : d;
				var h = date.getHours();
				h = h < 10 ? ('0' + h) : h;
				var minute = date.getMinutes();
				var second = date.getSeconds();
				minute = minute < 10 ? ('0' + minute) : minute;
				second = second < 10 ? ('0' + second) : second;
				if (num == 0) {
					return y + '-' + m + '-' + d;
				} else {
					return y + '-' + m + '-' + d + ' ' + h + ':' + minute + ':' + second;
				}
			},
			init() {
				this.status = "loading"
				myTeamApi.user_invite({
					// token: this.token,
					type:"1",
					count: this.count,
					// count: this.count,
					page: this.page
				}).then(res => {
					if(res.status==200){
						
						this.teamList = res.result.list
						console.log(this.teamList)
						//备份原数组
						this.preList = this.teamList;
						this.lastPage = res.result.last_page
						// this.currentPage = res.data.current_page
						console.log(this.page)
						console.log(this.lastPage)
						if(this.page>=this.lastPage){
							console.log(this.page)
							console.log(this.lastPage)
							this.status='noMore'
						}else{
							this.status='more'
						}
					}
					if (res.status!=200) {
						uni.showToast({
							title: res.message,
							icon: "none"
						})
						
					}
					console.log(res)
					
			
				})
			},
			//重置搜索栏   值清0    还原数组
			reset() {
				this.phone = ""
				this.teamList = this.preList
				this.isshow = true
			
			
			},
			//长度为0 就反显 后期看需求 是否更改  例如长度小于11 就反显
			//长度为0 就反显 后期看需求 是否更改  例如长度小于11 就反显
			//长度为0 就反显 后期看需求 是否更改  例如长度小于11 就反显
			iptNum(e) {
				console.log(123)
				if (e.detail.value.length == 0) {
					this.teamList = this.preList
				}
			
			},
			
			// 搜索
			getsearch() {
				myTeamApi.user_invite({	
					type:"1",
					count: this.count,					
					page: this.page,
					phone: this.phone
				}).then(res => {
					console.log(res);
					if (res.status ==200) {
						this.teamList = res.result.list
						this.isshow = false
					}else{
						uni.showToast({
							title: res.message,
							icon: "none"
						})
					}
				
					
			
				})
				
			},
			//触底加载
			reachBtm() {
				console.log(123)
				this.status = "loading"
				this.flag1 = false
				if (this.page < this.lastPage) {
					this.page++;
					console.log(3333333)
					console.log(this.page)
					myTeamApi.user_invite({
						// token: this.token,
						type:"1",
						count: this.count,
						page: this.page
					}).then(res => {
						this.teamList = this.teamList.concat(res.result.list)
						this.preList = this.teamList
						this.flag1 = true
						if (res.data.data.length < this.count) {
							this.status = "noMore"
							this.flag1 = false
						}
					})
				}else{
					this.status='noMore'
				}
			
			
			
			},
			// 查看弹窗
			getsee(item) {
				this.see = true
				this.teamMember = item		
			},
			// 关闭查看
			getdel() {
				this.see = false
			},
		}
	}
</script>

<style lang="scss">
	page image {
		width: 100%;
		height: 100%;
	}
	/* 我的团队 */
	.time {
		// padding-top: 10rpx;
		margin: 0 30rpx;
		padding-bottom: 20rpx;
		background-color: #FFFFFF;
		box-sizing: border-box;
		box-shadow: -2rpx 0rpx 1rpx 1rpx #EFEFEF inset,0rpx -2rpx 1rpx 1rpx #EFEFEF inset,2rpx 0rpx 5rpx 1rpx #EFEFEF inset,0rpx 2rpx 5rpx 1rpx #EFEFEF inset;
	}
	
	.time .inp {
		// padding-top: 10rpx;
		// padding-left: 43rpx;
		width: 500rpx;
		height: 70rpx;
		
		position: relative;
		background: #F5F5F5;
		border-radius: 35rpx;
	}
	
	.time .inp image {
		width: 29rpx;
		height: 29rpx;
		position: absolute;
		left: 20rpx;
		top: 20rpx;
	}
	
	.time .inp image:last-child {
		width: 29rpx;
		height: 29rpx;
		position: absolute;
		left: 440rpx;
		top: 20rpx;
	}
	
	.time .inp input {
		width: 400rpx;
		height: 70rpx;
		background: #F5F5F5;
		border-radius: 35rpx;
		padding-left: 60rpx;
		box-sizing: border-box;
		font-size: 26rpx;
	}
	
	/* 个人信息 */
	.user {
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #999999;
		padding: 50rpx 40rpx;
		display: flex;
		justify-content: space-between;
		align-items: center;
		border-top: 1rpx solid #F5F5F5;
	}
	
	.user .one {
		position: relative;
		
	}
	
	.user image {
		width: 80rpx;
		height: 80rpx;
		border-radius: 50%;
	}
	
	.user .rank {
		width: 110rpx;
		height: 30rpx;
		background: #FFFFFF;
		border: 1rpx solid #F87897;
		border-radius: 13rpx;
		font-size: 18rpx;
		text-align: center;
		line-height: 26rpx;
		color: #F87897;
		position: absolute;
		left: -15rpx;
		bottom: -10rpx;
	}
	
	.user .two {
		margin-left: 50rpx;
		color: #333333;
	}
	
	/* 弹窗 */
	.window {
		position: fixed;
		left: 0;
		top: 0;
		width: 100%;
		height: 100%;
		background: rgba(0, 0, 0, 0.5);
		font-family: PingFang SC;
		font-weight: 400;
		z-index: 999;
	}
	
	.particulars {
		position: absolute;
		left: 50%;
		top: 50%;
		transform: translate(-50%, -50%);
		width: 500rpx;
		height: 600rpx;
		background: #FFFFFF;
		border-radius: 20rpx;
		padding: 40rpx;
		box-sizing: border-box;
		z-index: 999;
	}
	
	.particulars .del {
		position: absolute;
		right: 30rpx;
		top: 50rpx;
		width: 36rpx;
		height: 36rpx;
	}
	
	.particulars .hang {
		display: flex;
		font-size: 24rpx;
		color: #333333;
		align-items: center;
		margin: 10rpx;
	}
	
	.particulars .hang image {
		width: 70rpx;
		height: 70rpx;
		border-radius: 50%;
		vertical-align: middle;
	}
	
	.hang view {
		width: 110rpx;
		text-align: justify;
		text-align-last: justify;
		text-justify: inter-ideograph;
	}
	
	.hang text {
		text-aline: justify;
	}
	
	.swiper {
		height: 80rpx;
		overflow: hidden;
	}
	
	.swiper-item {
		margin-left: 37rpx;
		height: 80rpx;
		display: flex;
		align-items: center;
		justify-content: space-between;
		padding-right: 27rpx;
	}
	
	.zwsj {
		height: 430rpx;
		width: 350rpx;
		margin: 0 auto;
	
		image {
			width: 100%;
			height: 100%;
		}
	}
	.box {
		
		.nav {
			background-color: #fff;
			// margin-top: 20rpx;
			height: 70rpx;
			margin-bottom: 20rpx;

			.content-nav {
				background-color: #fff;
				display: flex;
				justify-content: space-around;

				.nav-item {
					.text {
						width: 76rpx;
						height: 25rpx;
						font-size: 26rpx;
						font-family: PingFang SC;
						font-weight: 400;
						line-height: 66rpx;
						color: #999999;
					}
				}

				.active {
					border-bottom: 4rpx solid #F87897;

					.text {
						color: #F87897;
						font-weight: 500;
						font-size: 30rpx !important;
						line-height: 66rpx;
						font-family: PingFang SC;
						// height: 29rpx;
					}
				}
			}
		}

		.title {
			width: 749rpx;
			height: 150rpx;
			background: #FFFFFF;
			border: 1px solid #EEEEEE;
			display: flex;
			justify-content: center;
			align-items: center;

			text {

				font-size: 30rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: #F87897;

			}
		}

		.title1 {
			width: 749rpx;
			height: 150rpx;
			background: #FFFFFF;
			border: 1px solid #EEEEEE;
			display: flex;
			justify-content: flex-start;
			align-items: center;

			.right {
				// border-right: 1px solid #EEEEEE;
				width: 374rpx;
				height: 160rpx;
				display: flex;
				// justify-content: space-around;
				align-items: center;
				.left-3{
					margin-left: 20rpx;
				}
				.left-1,
				.left-2 {

					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #333333;
					// line-height: 38px;
				}
			}

			.left {
				border-right: 1px solid #EEEEEE;
				width: 374rpx;
				height: 160rpx;
				display: flex;
				// justify-content: space-around;
				align-items: center;
				.left-3{
					margin-left: 30rpx;
				}
				.left-1,
				.left-2 {

					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #333333;
					// line-height: 38px;
				}

				.img {
					width: 10rpx;
					height: 20rpx;
					margin-left: 80rpx;
				}
			}
		}
	}
</style>
