<!-- 领取成功页面 -->
<template>
	<view>
		<view class="one">
			<image src="../../../static/my/ok1.png"></image>
			<view>提现申请提交成功</view>
		</view>
		<view class="check" @click="examine()">返回我的余额</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				money:'',
				cdnUrl:'',
			}
		},
		onShareAppMessage: function(options) {
			return {
				title: '源爱汇',
				path: '/page/index/index',
				success: function(res) {
					// 转发成功
				},
				fail: function(res) {
					// 转发失败
				}		
			}		
		},
		methods: {
			// 转跳到门店页面
			examine(){
				uni.navigateBack({
					delta:2
				})
			},
		}
	}
</script>

<style>
.one{
	text-align: center;
	font-size: 30rpx;
	font-family: PingFang SC;
	font-weight: 500;
	color: #343434;
	padding-top: 150rpx;
}
.one image {
	width: 146rpx;
	height: 185rpx;
	padding-bottom: 50rpx;
}
.check {
	width: 690rpx;
	height: 90rpx;
	background: #F87897;
	border-radius: 20rpx;
	line-height: 90rpx;
	text-align: center;
	font-size: 30rpx;
	font-family: PingFang SC;
	font-weight: 500;
	color: #FFFFFF;
	margin: 50rpx 30rpx;
}
</style>

