<!-- 提现页面 -->
<template>
	<view class="" >
		<view class="cardMsg">
			<view class="card_img">
				<image :src="$imgUrl(cardMsg.bank_logo)" mode="" style="border-radius: 50%;" v-if="statusStyle==3"></image>
				<img :src="$imgUrl(userInfo.avatarUrl)" alt=""  v-else style="border-radius: 50%;">
			</view>
			<view>
				<view class="card_msg" v-if="statusStyle==3">
					<view class="card_num">
						{{handleNum(cardMsg.card_number)}}
					</view>
					<view class="card_name">
						{{cardMsg.branch_bank}}
					</view>
				</view>
				<view class="card_msg" v-else>
					<view class="card_num" >{{userInfo.nickName}}</view>
				</view>
			</view>
			<view class="card_choose" v-if="statusStyle==3"  @click="goChangeBankCard">
				<image src="../../../static/youbai.png" mode="" style="height: 27rpx;width: 15rpx;color: #ffffff;"></image>
			</view>
		</view>
		<view class="money">
			<view class="word">
				提现金额
			</view>
			<view class="ipt">
				<view class="money_mark">
					￥
				</view>
				<input type="number" placeholder="请输入提现金额" v-model="withdrawalMoney" :class="withdrawalMoney!=''?'current':''"/>
				<view class="" class="del_money" @click="delMoney">
				</view>
			</view>
			<view class="left_monry">
				可提现余额：{{$returnFloat(cash)}}
				<view class="all_money" @click="getAll">
					全部提现
				</view>
			</view>
		</view>
		<view class="rule">
			<view class="" style="width: 340rpx;" >
				提现规则：
			</view>
			<view>
				<view class="" v-for="(item,index) in ruleList" :key="index" style="margin-bottom: 20rpxs;">
					{{index+1}}. {{item}}
				</view>
			</view>

		</view>
		<view class="sure" @click="confirm">
			确定提现
		</view>
	</view>
</template>

<script>
	import myCashApi from "../../../api/my/my.js"
export default {
	data() {
		return {
			cdnUrl:'',
			cash:'',
			show:false,
			cardMsg:{},
			txcash:0,
			show_style:'',
			token:"",
			withdrawalMoney:"",
			ruleList:[],
			userInfo:{
				avatarUrl:"",
				nickName:""
			},
			statusStyle:""
		};
	},
	onShareAppMessage: function(options) {
		return {
			title: '源爱汇',
			path: '/page/index/index',
			success: function(res) {
				// 转发成功
			},
			fail: function(res) {
				// 转发失败
			}		
		}		
	},
	methods: {
		goChangeBankCard(){
			uni.navigateTo({
				url:"./changeBankCard"
			})
		},
		confirm(){
			myCashApi.user_apply_extract({
				money:this.withdrawalMoney*100,
				type:this.statusStyle
			}).then(res=>{
				if(res.status==200){
					uni.navigateTo({
						url:"withdrawalSuccess"
					})
				}else{
					uni.showToast({
						title:res.message,
						icon:"none"
					})
				}
			})

		},
		// 点击全部提现将可提现余额值给Input框
		getAll(){
			this.withdrawalMoney=this.cash/100
		},
		handleNum(p) {
			if (p) {
				return p.substring(0, 4) + ' **** **** ' + p.substring(p.length - 4);
			}
		}
	},
	onLoad(options) {
		console.log(options)
		// this.token=uni.getStorageSync("xxytoken");
		this.cash = options.cash
		if(options.weixin){
			this.statusStyle=1
			myCashApi.get_user_info({}).then(res=>{
				if(res.status==200){
					this.userInfo.avatarUrl=res.result.photo
					this.userInfo.nickName=res.result.wechat_name
				}
			})
			// this.userInfo=JSON.parse(options.userInfo)
			// console.log(this.userInfo)
		}else{
			this.statusStyle=3
			myCashApi.user_bank({}).then(res=>{
				if(res.status==200){
					this.cardMsg=res.result
				}else{
					uni.showToast({
						title:res.message,
						icon:"none"
					})
				}
			});
		}
		myCashApi.withdrawal_rule({}).then(res=>{
			if(res.status==200&&res.result!=""){
				this.ruleList=res.result.rule
			}
		})
	}
};
</script>

<style>
	page{
		background-color: #f8f8f8;
	}
	.cardMsg{
		background: #555555;
		border-radius: 30rpx 30rpx 0rpx 0rpx;
		margin: 102rpx 54rpx 0;
		display: flex;
		align-items: center;
		padding: 45rpx;
	}
	.card_img{
		width: 78rpx;
		height: 78rpx;
	}
	.card_img image{
		width: 78rpx;
		height: 78rpx;
	}
	.card_msg{
		width: 430rpx;
		padding-left: 20rpx;
		color: #fff;
	}
	.card_num{
		font-size: 36rpx;
	}
	.card_name{
		font-size: 24rpx;
		margin-top: 10rpx;
	}
	.card_choose{
		width: 40rpx;
		height: 40rpx;
	}
	.card_choose image{
		width: 40rpx;
		height: 40rpx;
	}
	.money{
		width: 100%;
		padding: 30rpx 30rpx 0 30rpx;
		height: 285rpx;
		background: #FFFFFF;
		box-shadow: 0px 5rpx 7rpx 0px rgba(0, 0, 0, 0.15);
		box-sizing: border-box;
	}
	.word{
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #333333;
	}
	.ipt{
		position: relative;
		padding: 0 80rpx 0 40rpx;
		margin-top: 40rpx;
		border-bottom: 1rpx solid #DFDFDF;
	}
	.money_mark{
		position: absolute;
		bottom: 10rpx;
		left: 0;
		font-size: 36rpx;
		font-family: HiraginoSansGB;
		font-weight: bold;
		color: #212121;
	}
	.ipt input{
		/* border-bottom: 1rpx solid #DFDFDF; */
		height: 80rpx;
		line-height: 80rpx;
	}
	.ipt .current{
		color: #333;
		font-size: 64rpx;
		font-weight: bold;
	}
	.del_money{
		position: absolute;
		bottom: 0;
		right: 0;
		width: 80rpx;
		height: 80rpx;
	}
	.del_money image{
		width: 30rpx;
		height: 30rpx;
		margin: 25rpx;
	}
	.left_monry{
		height: 90rpx;
		line-height: 90rpx;
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #999999;
		position: relative;
	}
	.all_money{
		position: absolute;
		top: 0;
		right: 0;
		height: 90rpx;
		line-height: 90rpx;
		padding-left: 40rpx;
		color: #509EE0;
		font-size: 24rpx;
	}
	.rule{
		/* width: 180rpx; */
		padding: 30rpx;
		display: flex;
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #999999;
	}
	.rule_right{
		flex: 1;
		line-height: 40rpx;
	}
	.sure{
		width: 690rpx;
		height: 90rpx;
		background: #F87897;
		border-radius: 20rpx;
		margin: 50rpx 30rpx 0;
		line-height: 90rpx;
		text-align: center;
		color: #fff;
		font-size: 30rpx;
	}
</style>
