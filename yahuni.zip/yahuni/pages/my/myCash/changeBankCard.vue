<template>
	<view>
		<view>
			<view class="header">
				<view class="card_img" style="display: flex;padding: 30rpx 0 0 80rpx;align-items: center;">
					<image :src="$imgUrl(cardMsg.bank_logo)" mode="" style="border-radius: 50%;width: 66rpx;height: 64rpx;"></image>
					<view class="card_name" style="margin-left: 30rpx;">
						{{cardMsg.branch_bank}}
					</view>
				</view>
				<view class="card_msg">
					<view class="card_num" style="margin-left: 178rpx;">
						{{cardMsg.card_number}}
					</view>
				</view>
			</view>
			<view class="font">
				更换银行卡请联系客服
			</view>
		</view>
	</view>
</template>

<script>
	import myCashApi from "../../../api/my/my.js"
	export default {
		data() {
			return {
				cardMsg:""
			}
		},
		onLoad(){
			// this.token=uni.getStorageSync("xxytoken");
			myCashApi.user_bank({}).then(res=>{
				if(res.status==200){
					this.cardMsg=res.result
				}else{
					uni.showToast({
						title:res.message,
						icon:"none"
					})
				}
			});
		},
		onShareAppMessage: function(options) {
			return {
				title: '源爱汇',
				path: '/page/index/index',
				success: function(res) {
					// 转发成功
				},
				fail: function(res) {
					// 转发失败
				}		
			}		
		},
		methods: {
			handleNum(p) {
				if (p) {
					return p.substring(0, 4) + ' **** **** ' + p.substring(p.length - 4);
				}
			}
		}
	}
</script>

<style>
	page{
		background-color:#555555;
		padding: 30rpx;
	}
</style>
<style scoped>
	.card_num{
		font-size: 36rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #333333;
	}
	.font{
		text-align: center;
		margin-top: 100rpx;
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #FFFFFF;
	}
	.header{
		width: 690rpx;
		height: 204rpx;
		background: #FFFFFF;
		border-radius: 15rpx;
	}

</style>
