<template>
	<view class="box">
		<view class="box-c">
			<view class="list">
				<view class="left">
					收货人
				</view>
				<view class="contentInput">
					<input type="text" maxlength="11" value="" placeholder="请输入收货人姓名" v-model="getName"
						@input="matchingPhone" />
				</view>
			</view>
			<view class="list">
				<view class="left">
					手机号码
				</view>
				<view class="contentInput">
					<input type="number" maxlength="11" value="" placeholder="请输入手机号码" v-model="getNum"
						@input="matchingPhone" />
				</view>
			</view>
			<view class="list">
				<citydata @get_reginId="getId" :nnn="objs"></citydata>
			</view>
			<view class="list">
				<view class="left">
					详细地址
				</view>
				<textarea style="height: 100rpx;margin-left: 60rpx;margin-top: 70rpx;padding-right: 40rpx;" value=""
					placeholder="详细地址,  如1层101室" v-model="getAdressDetailed"></textarea>
			</view>
		</view>
		<view style="height: 20rpx;background-color: #F5F5F5;"></view>
		<view
			style="display:flex;justify-content: space-between;padding: 0 30rpx;padding-top: 30rpx;height: 250rpx;background-color: #FFFFFF;">
			<view style="font-size: 26rpx;font-family: PingFang SC;font-weight: 400;color: #333333;">设为默认地址</view>
			<view>
				<switch :checked="isDefault_address==0?false:true" @change="selectIsDefault" color="#F87897" />
			</view>
		</view>
		<view>
			<view class="sureBind" @click="confirm">
				保存
			</view>
		</view>

	</view>
</template>

<script>
	import citydata from '../../citydata.vue'
	import myApi from "../../../../api/my/my.js"
	export default {
		components: {
			citydata
		},
		data() {
			return {
				getName: "",
				getNum: "",
				objs: {},
				selectArea: "",
				province_id: "",
				province_name: "",
				city_id: "",
				city_name: "",
				county_id: "",
				county_name: "",
				getAdressDetailed: "",
				isDefault_address: 1,
				index: ""
			};
		},
		onLoad(e) {
			if (e.id) {
				console.log(e);
				this.index = e.id
				myApi.address_info({
					index: this.index
				}).then(res => {
					console.log(res)
					if (res.status == 200) {
						this.getAdressDetailed = res.result.address
						this.getName = res.result.contacts
						this.getNum = res.result.phone
						this.isDefault_address = res.result.default_address
						this.objs.province_id = res.result.province_id
						this.objs.province_name = res.result.province_name
						this.objs.city_id = res.result.city_id
						this.objs.city_name = res.result.city_name
						this.objs.county_id = res.result.county_id
						this.objs.county_name = res.result.county_name
						this.objs.show = true
					} else {
						uni.showToast({
							title: res.message,
							icon: 'none'
						})
					}
				})
			}
		},
		onShareAppMessage: function(options) {
			return {
				title: '源爱汇',
				path: '/page/index/index',
				success: function(res) {
					// 转发成功
				},
				fail: function(res) {
					// 转发失败
				}		
			}		
		},
		methods: {
			selectIsDefault(e) {
				console.log(e)
				if (e.detail.value) {
					this.isDefault_address = 1
				} else {
					this.isDefault_address = 0
				}

			},
			matchingPhone() {
				let reg_tel = /^(13[0-9]|14[01456879]|15[0-35-9]|16[2567]|17[0-8]|18[0-9]|19[0-35-9])\d{8}$/;
				if (this.getNum.length == 11) {
					if (!reg_tel.test(this.getNum)) {
						uni.showToast({
							title: "手机号错误,请重新输入",
							icon: "none"
						})
					}
				}
			},
			// 省市区
			getId(obj) {
				console.log(obj);
				this.selectArea = obj
				this.province_name = obj.province_name;
				this.city_name = obj.city_name;
				this.county_name = obj.county_name;
				this.province_id = obj.province_id;
				this.city_id = obj.city_id;
				this.county_id = obj.county_id;
			},
			confirm() {
				let self = this;
				if (self.getName == "") {
					uni.showToast({
						title: "请输入收货人姓名",
						icon: 'none'
					})
					return
				}
				if (self.getNum == "") {
					uni.showToast({
						title: "请输入手机号码",
						icon: 'none'
					})
					return
				}
				if (!/^(13[0-9]|14[01456879]|15[0-35-9]|16[2567]|17[0-8]|18[0-9]|19[0-35-9])\d{8}$/.test(self.getNum)) {
					uni.showToast({
						title: "手机号错误,请重新输入",
						icon: "none"
					})
					return
				}
				console.log(this.objs)
				if (self.objs.city_id === false && self.selectArea == "") {
					uni.showToast({
						title: "请选择所在区域",
						icon: 'none'
					})
					return
				}

				if (self.getAdressDetailed == "") {
					uni.showToast({
						title: "请输入详细地址",
						icon: 'none'
					})
					return
				}
				console.log(this.province_id);
				if (this.index) {
					// console.log(111);
					// console.log(this.objs.province_id);
					// console.log(this.province_id);
					if (this.province_id) {
						// console.log(11112345678965456);
					} else {
						this.province_id = this.objs.province_id
						this.city_id = this.objs.city_id
						this.county_id = this.objs.county_id
					}
					myApi.update_address({
						contacts: this.getName,
						phone: this.getNum,
						province_id: this.province_id,
						city_id: this.city_id,
						county_id: this.county_id,
						address: this.getAdressDetailed,
						default_address: this.isDefault_address,
						index: this.index
					}).then(res => {
						console.log(res)
						if (res.status == 200) {
							uni.showToast({
								title: res.message,
							})
							uni.navigateBack({
								delta: 1
							});

						} else {
							uni.showToast({
								title: res.message,
								icon: 'none'
							})
						}
					})
					return
				}
				myApi.update_address({
					contacts: this.getName,
					phone: this.getNum,
					province_id: this.province_id,
					city_id: this.city_id,
					county_id: this.county_id,
					address: this.getAdressDetailed,
					default_address: this.isDefault_address

				}).then(res => {
					console.log(res)
					if (res.status == 200) {
						uni.showToast({
							title: res.message,
						})
						uni.navigateBack({
							delta: 1
						});
					} else {
						uni.showToast({
							title: res.message,
							icon: 'none'
						})
					}
				})
			}

		}
	}
</script>
<style>
	page {
		background-color: #F5F5F5;
	}
</style>
<style lang="scss" scoped>
	.box {
		overflow: hidden;

		.sureBind {
			width: 690rpx;
			height: 90rpx;
			background: #F87897;
			border-radius: 45rpx;
			margin: 0 30rpx;
			line-height: 90rpx;
			text-align: center;
			color: #fff;
			font-size: 30rpx;
		}

		.box-c {
			height: 450rpx;
			background: #FFFFFF;

			.list {
				width: 750rpx;
				height: 100rpx;
				background: #FFFFFF;
				display: flex;
				justify-content: flex-start;
				align-items: center;

				.left {
					display: inline-flex;
					width: 142rpx;
					margin-left: 30rpx;
					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #222222;
				}

				.contentInput {
					margin-left: 30rpx;
				}

				.contentInput1 {}
			}
		}

	}
</style>
