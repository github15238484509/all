<template>
	<view class="main-box">
		<view class="xline-bet" @click="editAvatar" style="height: 140rpx;border-top: 1rpx solid #F5F5F5;">
			<view class="left">
				头像
			</view>
			<view class="right avatar">
				<image :src="$imgUrl(userObj.photo)" mode="aspectFill"></image>
				<u-icon name="arrow-right" size="28" style="margin-left: 10rpx;" color="#CCCCCC"></u-icon>
			</view>
		</view>
		<view class="xline-bet">
			<view class="left">
				手机号
			</view>
			<view class="right">
				{{userObj.phone}}
				<!-- <u-icon name="arrow-right" size="28" style="margin-left: 10rpx;" color="#CCCCCC"></u-icon> -->
			</view>
		</view>
		<view class="xline-bet" @click="editName">
			<view class="left">
				昵称
			</view>
			<view class="right">
				{{userObj.name ? userObj.name : ''}}
				<u-icon top="2" style="margin-left: 10rpx;" name="arrow-right" size="28" color="#CCCCCC"></u-icon>
			</view>
		</view>
		<view class="xline-bet" @click="genderControl">
			<view class="left">
				性别
			</view>

			<view class="right" style="color: #000000;">
				{{genderValue?genderValue:'请选择'}}
				<u-icon name="arrow-right" size="32" color="#CCCCCC"></u-icon>
			</view>
		</view>


		<view class="xline-bet">
			<view class="left">
				级别
			</view>
			<view class="right">
				「{{userObj.rank_name}}」
			</view>
		</view>
		<!-- <view class="xline-bet">
			<view class="left">
				所在地区
			</view>
			<view class="right">
				{{userObj.province_name}}省 {{userObj.city_name}}市 {{userObj.district_name}}
			</view>
		</view> -->
		<view class="xline-bet">
			<view class="left">
				推荐人
			</view>
			<view class="right">
				{{userObj.referrer_phone? mobileFilter(userObj.referrer_phone) :'无'}}
			</view>
		</view>
		<view class="xline-bet">
			<view class="left">
				注册时间
			</view>
			<view class="right">
				{{userObj.regtime? $time(userObj.regtime,1) : '' }}
			</view>
		</view>


		<view class="xbtn-blue" @click="logout">
			退出登录
		</view>
		<u-select v-model="isGenderShow" :list="genderList" @confirm="genderConfirm"></u-select>
	</view>

</template>

<script>
	import userApi from "../../../api/my/my.js"

	export default {

		data() {
			return {

				userObj: {},
				isselectShow: true,
				isGenderShow: false,
				genderList: [{
						value: '0',
						label: '男'
					},
					{
						value: '1',
						label: '女'
					}
				],
				aliId: "",
				sex: '',
				//默认的性别
				genderValue: "",
				avatar:""
			}
		},
		onLoad() {
			let this_=this
			this.init()
			uni.$on('uAvatarCropper', path => {
				this.avatar = path;
				// 可以在此上传到服务端
				uni.uploadFile({
					url: this.$uptImgUrl,
					filePath: path,
					name: 'file',
					complete: (res) => {
						console.log(res);
						let newData = JSON.parse(res.data)

						let newUrl = newData.result

						newUrl = '/' + newUrl.img_name

						userApi.set_user_edit({
							// token: uni.getStorageSync("token"),
							photo: newUrl
						}).then(res => {
							console.log(res)
							this_.init()
						})


					}
				});
			})
		},
		onShareAppMessage: function(options) {
			return {
				title: '源爱汇',
				path: '/page/index/index',
				success: function(res) {
					// 转发成功
				},
				fail: function(res) {
					// 转发失败
				}		
			}		
		},
		onShow() {
			
			this.init()
		},
		methods: {
			init() {
				userApi.get_user_info({
					token: uni.getStorageSync("token")
				}).then(res => {

					this.userObj = res.result
					if (res.result.sex == 0) {
						this.genderValue = '男'
					} else if (res.result.sex == 1) {
						this.genderValue = '女'
					}

				})
			},
			mobileFilter(val) {
				if (val) {
					let reg = /^(.{3}).*(.{4})$/
					return val.replace(reg, '$1****$2')
				}

			},
			editAvatar() {


				// 此为uView的跳转方法，详见"文档-JS"部分，也可以用uni的uni.navigateTo
				this.$u.route({
					// 关于此路径，请见下方"注意事项"
					url: '/uview-ui/components/u-avatar-cropper/u-avatar-cropper',
					// 内部已设置以下默认参数值，可不传这些参数
					params: {
						// 输出图片宽度，高等于宽，单位px
						destWidth: 300,
						// 裁剪框宽度，高等于宽，单位px
						rectWidth: 200,
						// 输出的图片类型，如果'png'类型发现裁剪的图片太大，改成"jpg"即可
						fileType: 'jpg',
					}
				})
				console.log(this.avatar);

			},


			editName() {
				uni.navigateTo({
					// url: 'editUserInfo/editName?name=' + this.userObj.name
					url: '../editUserInfo/editName?name=' + this.userObj.name
				})
			},

			genderControl() {
				this.isGenderShow = true
			},
			genderConfirm(e) {
				this.isGenderShow = false
				this.genderValue = e[0].label
				this.sex = e[0].value
				userApi.set_user_edit({
					// token: this.token,
					sex: this.sex
				}).then(res => {
					if (res.status == 200) {
						this.isselectShow = true
						uni.showToast({
							title: res.message,
							icon: 'none'
						})
					} else {
						uni.showToast({
							title: res.message,
							icon: 'none'
						})
					}
				})


			},
			logout() {
				uni.removeStorageSync('token')
				uni.clearStorageSync()
				setTimeout(() => {
					uni.reLaunch({
						url: '../my'
					})
				}, 1500)
			}
		}

	}
</script>

<style lang="scss" scoped>
	.main-box {
		padding: 36rpx 30rpx 0;

		.avatar {

			// overflow: hidden;
			display: flex;
			align-items: center;

			image {
				width: 80rpx;
				height: 80rpx;
				border-radius: 50%;


			}
		}
	}

	.xbtn-blue {
		position: fixed;
		bottom: 105rpx;
	}

	.xbtn-blue {
		width: 690rpx;
		height: 90rpx;


		background: #F87897;
		color: #FFFFFF;
		text-align: center;
		line-height: 90rpx;
		font-size: 36rpx;
		border-radius: 10rpx;
	}

	/* 白底按钮 */
	.xbtn-white {
		width: 690rpx;
		height: 90rpx;
		background-color: #FFFFFF;
		color: #4794FF;
		border: 1rpx solid #4794FF;
		border-radius: 10rpx;
		text-align: center;
		line-height: 90rpx;
		font-size: 36rpx;

	}

	/* 高度90 between对齐 带下边框 */
	.xline-bet {
		height: 90rpx;
		display: flex;
		align-items: center;
		justify-content: space-between;
		border-bottom: 1rpx solid #F5F5F5;
	}

	/* 高度90 between对齐 不带下边框  用于末尾元素*/
	.xline-bet-end {
		height: 90rpx;
		display: flex;
		align-items: center;
		justify-content: space-between;
	}

	.xblack {
		color: #333333;
	}

	.xgray {
		color: #666666;
	}

	.xline {
		width: 100%;
		height: 1rpx;
		background-color: #F5F5F5
	}

	.xline20 {
		width: 100%;
		height: 20rpx;
		background-color: #F5F5F5
	}

	.xbt {
		display: flex;
		align-items: center;
		justify-content: space-between;
	}

	.xev {
		display: flex;
		align-items: center;
		justify-content: space-evenly;
	}

	.xal {
		display: flex;
		align-items: center;

	}

	.xflex {
		display: flex;
	}
</style>
