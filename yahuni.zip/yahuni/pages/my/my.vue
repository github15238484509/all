<template>
	<view>
		<view style="position: relative;height: 260rpx;" v-if="!istoken">
			<image src="../../static/mineTeamBgc.png" mode="" class="myBg"></image>
			<view class="noLogin">
				<view class="photo">
					<image src="../../static/my/nologin.png" mode="" style="width: 100%;height: 100%;"></image>
				</view>
				<view class="loginText" @click="$u.throttle(goLogin,500)">
					登录/注册
				</view>
			</view>
		</view>
		<view v-else style="position: relative;height: 260rpx;">
			<image src="../../static/mineTeamBgc.png" mode="" class="myBg"></image>

			<view class="noLogin">
				<view class="photo">
					<image @click="goSetting" :src="$imgUrl(user_info.photo)" mode=""
						style="width: 100%;height: 100%;border-radius: 50%;">
					</image>
				</view>
				<view class="loginText" style="flex:1;display: flex;align-items: center;">
					<view style="height: 100%;">
						<view @click="goSetting"
							style="font-size: 36rpx;font-family: PingFang SC;font-weight: 500;color: #FFFFFF;">
							{{user_info.name}}
						</view>
						<view v-if="user_info.is_upgrade=='1'" @click="toTeam()" style="font-size: 26rpx;font-family: PingFang SC;font-weight: 400;color: #FFFFFF;margin-top: 20rpx;
text-decoration: underline;">
							您的本月业绩已达标，点击查看>></view>
					</view>
					<view @click="goSetting" style="position: absolute;right: 56rpx;width: 74%;">
						<image src="../../static/my/right.png" mode="" style="width: 17rpx;height: 32rpx;float: right;">
						</image>
					</view>
				</view>
				<view class="rank">
					{{user_info.rank_name}}
				</view>
			</view>
		</view>
		<view class="myCash">
			<view class="cashTitle">
				我的余额(元)
			</view>
			<view style="display: flex;justify-content: space-between;margin-top: 34rpx;">
				<text class="money">{{$returnFloat(user_info.cash)}}</text>
				<view
					style="font-size: 30rpx;font-family: PingFang SC;ont-weight: 500;color: #F87897;border: 2rpx solid #F87897;border-radius: 24rpx;width: 140rpx;height:48rpx;line-height: 48rpx;text-align: center;"
					@click="lookCash">
					查看
				</view>
			</view>
		</view>
		<!-- 全部课程 -->
		<view class="courseAll">
			<view class="courseTitle">
				<text style="font-size: 30rpx;font-family: PingFang SC;font-weight: 500;color: #333333;">全部订单</text>
				<view style="display: flex;justify-content: space-between;align-items: center;"
					@click="goOrderDetil(0)">
					<view
						style="font-size: 30rpx;font-family: PingFang SC;font-weight: 400;color: #999999;margin-bottom: 1rpx;">
						查看</view>
					<image src="../../static/my/right1.png" mode=""
						style="width: 14rpx;height: 31rpx;margin-left: 10rpx;"></image>
				</view>

			</view>
			<view style="display: flex;justify-content: space-between;margin-top: 25rpx;">
				<view style="display: flex;flex-direction: column;align-items: center;width: 25%;"
					@click="goOrderDetil(item.index)" v-for="(item,index) in courseAll" :key="item">
					<image :src="item.img" mode="" style="width: 44rpx;height: 44rpx;"></image>
					<view class=""
						style="margin-top: 22rpx;font-size: 26rpx;font-family: PingFang SC;font-weight: 400;color: #333333;">
						{{item.title}}
					</view>
				</view>
			</view>
		</view>
		<!-- 常用功能 -->
		<view class="courseAll">
			<view class="courseTitle">
				<text style="font-size: 30rpx;font-family: PingFang SC;font-weight: 500;color: #333333;">常用功能</text>
			</view>
			<view style="display: flex;flex-wrap: wrap;margin-top:27rpx">
				<view @click="taps(item.index)"
					style="display: flex;flex-direction: column;align-items: center;position:relative;width: 25%;margin-top:26rpx;"
					v-for="(item,index) in commonlyUsed" :key="item">
					<image :src="item.img" mode="" style="width: 40rpx;height: 40rpx;"></image>
					<view class=""
						style="margin-top: 22rpx;font-size: 26rpx;font-family: PingFang SC;font-weight: 400;color: #333333;">
						{{item.title}}
					</view>
					<button v-if="index ==7"
						style="opacity: 0;position: absolute;width: 100%;height: 100%;left: 0;top:0;" type="default"
						open-type="contact"></button>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import myApi from '../../api/my/my.js'
	export default {
		data() {
			return {
				titleBarTop: 0,
				titleLeft: 0,
				titleHeight: 0,
				istoken: false,
				user_info: {
					cash: 0
				},
				courseAll: [{
						index: 1,
						img: '../../static/my/allOrder.png',
						title: '待支付'
					},
					{
						index: 2,
						img: '../../static/my/allCash.png',
						title: '待发货'
					},
					{
						index: 3,
						img: '../../static/my/dxx.png',
						title: '待收货'
					},
					{
						index: 4,
						img: '../../static/my/yxx.png',
						title: '已完成'
					}
				],
				commonlyUsed: [{
						index: 0,
						img: '../../static/my/wdtd.png',
						title: '我的团队'
					},
					{
						index: 1,
						img: '../../static/my/sjsq.png',
						title: '升级申请'
					},
					{
						index: 2,
						img: '../../static/my/yqzc.png',
						title: '邀请注册'
					},
					{
						index: 3,
						img: '../../static/my/dzgl.png',
						title: '地址管理'
					},
					{
						index: 4,
						img: '../../static/my/wdpl.png',
						title: '我的评论'
					},
					{
						index: 5,
						img: '../../static/my/lljl.png',
						title: '我的收藏'
					},
					{
						index: 6,
						img: '../../static/my/wdsc.png',
						title: '浏览记录'
					},
					{
						index: 7,
						img: '../../static/my/zxkf.png',
						title: '在线客服'
					},
					{
						index: 8,
						img: '../../static/my/gywm.png',
						title: '关于我们'
					},
					{
						index: 9,
						img: '../../static/my/cjwt.png',
						title: '常见问题'
					},
					{
						index: 10,
						img: '../../static/yjfk.png',
						title: '意见反馈'
					},
					{
						index: 11,
						img: '../../static/my/bzzx.png',
						title: '帮助中心'
					}
				]
			}
		},
		created() {

		},
		onLoad() {

		},
		onShow() {
			if (uni.getStorageSync('token')) {
				this.init();
			};
		},
		onShareAppMessage: function(options) {
			return {
				title: '源爱汇',
				path: '/page/index/index',
				success: function(res) {
					// 转发成功
				},
				fail: function(res) {
					// 转发失败
				}
			}
		},
		methods: {
			toTeam() {
				uni.navigateTo({
					url: "./myTeam/myTeam"
				})
			},
			//获取个人资料接口
			init() {
				myApi.get_user_info().then(res => {
					if (res.status == 200) {
						this.user_info = res.result
						this.istoken = true;
					} else {
						uni.showToast({
							title: res.message,
							icon: 'none'
						})
					}
				})
			},
			//去登陆
			goLogin() {
				uni.navigateTo({
					url: '../login/login'
				})
			},
			//去设置
			goSetting() {
				uni.navigateTo({
					url: "./user/user"
				})
			},
			//去订单详情
			goOrderDetil(index) {
				if (!uni.getStorageSync('token')) {
					uni.navigateTo({
						url: "../login/login"
					})
					return;
				};
				console.log(index);
				uni.setStorageSync("current", index)
				uni.navigateTo({
					url: '../myCourse/myCourse?index=' + index
				})
			},
			//查看余额明细
			lookCash() {
				if (!uni.getStorageSync('token')) {
					uni.navigateTo({
						url: "../login/login"
					})
					return;
				};
				uni.navigateTo({
					url: "./myCash/myCash"
				})
				console.log('查看余额明细');
			},
			// 常用功能
			taps(index) {
				if (!uni.getStorageSync('token')) {
					uni.navigateTo({
						url: "../login/login"
					})
					return;
				};
				switch (index) {
					case 0:
						/* if (this.user_info.rank < "5") {
							uni.showToast({
								title: "您还不是官方合伙人，请升级后再查看",
								icon: "none"
							})
							return
						} */
						uni.navigateTo({
							url: "./myTeam/myTeam"
						})
						break;
					case 1:
						if (this.user_info.rank == "5") {
							uni.showToast({
								title: "您已是最高级别~",
								icon: "none"
							})
							return
						}
						myApi.upgrade_info().then(res => {
							console.log(res)
							if (res.status == 200) {
								if (res.result.length < 1) {
									uni.navigateTo({
										url: "./upgrading/upgrading"
									})
								}
								if (res.result.state == '1' || res.result.state == '0') {
									uni.navigateTo({
										url: "./upgrading/upgradingInfo/upgradingInfo"
									})
								}
							} else {
								uni.showToast({
									title: res.message,
									icon: 'none'
								})
							}
						})

						break;
					case 2:
						uni.navigateTo({
							url: "./allowinvite/allowinvite"
						})
						break;
					case 3:
						uni.navigateTo({
							url: './address/address'
						})
						break;
					case 4:
						uni.navigateTo({
							url: './myComments/myComments'
						})
						break;
					case 5:
						uni.navigateTo({
							url: './myCollection/myCollection'
						})
						break;
					case 6:
						uni.navigateTo({
							url: './record/record'
						})
						break;
					case 7:

						break;
					case 8:
						uni.navigateTo({
							url: '../aboutUs'
						})
						break;
					case 9:
						uni.navigateTo({
							url: '../hu/faq'
						})
						break;
					case 10:
						uni.navigateTo({
							url: '../feedBack'
						})
						break;
					case 11:
						uni.navigateTo({
							url: '../help'
						})
						break;
				}
			}


		}
	}
</script>

<style lang="scss">
	page {
		background: #F5F5F5 !important;
	}

	.myBg {
		width: 100%;
		height: 260rpx;
		position: absolute;
		left: 0;
		top: -2px;
	}

	.noLogin {
		display: flex;
		width: 100%;
		align-items: center;
		position: absolute;
		top: 60rpx;
		left: 0px;
		padding: 0 30rpx;

		.photo {
			width: 114rpx;
			height: 114rpx;
			border-radius: 50%;
		}

		.loginText {
			margin-left: 24rpx;
			font-size: 44rpx;
			font-family: PingFang SC;
			font-weight: 500;
			color: #FFFFFF;
		}

		.rank {
			width: 118rpx;
			height: 35rpx;
			text-align: center;
			line-height: 35rpx;
			position: absolute;
			border: 1px solid #ED5A7E;
			border-radius: 18rpx;
			bottom: -22rpx;
			background-color: #fff;
			font-size: 22rpx;
			font-family: PingFang SC;
			font-weight: 500;
			color: #ED5A7E;
			left: 30rpx;
		}
	}

	.myCash {
		padding: 10rpx 30rpx;
		background: #fff;

		.cashTitle {
			font-size: 30rpx;
			font-family: PingFang SC;
			font-weight: 500;
			color: #333333;
		}

		.money {
			font-size: 40rpx;
			font-family: PingFang SC;
			font-weight: bold;
			color: #333333;
		}
	}

	.courseAll {
		margin-top: 20rpx;
		background: #fff;
		padding: 15rpx 30rpx;

		.courseTitle {
			display: flex;
			justify-content: space-between;
			align-items: center;
		}
	}
</style>
