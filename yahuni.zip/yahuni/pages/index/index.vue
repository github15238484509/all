<template>
	<view class="content">

		<view class="header">
			<image src="../../static/index/topBanner.png" class="bg"></image>
			<!-- <view class="text">
				禅行天下
			</view> -->
			<view class="btn" @tap="search">
				<image src="../../static/index/sousuo.png" class="img"></image>
				<text>请输入商品名称</text>
			</view>
			<view class="banner">
				<!-- <view class="page-section swiper">
					<view class="page-section-spacing">
						<swiper class="swiper" :autoplay="true" :interval="3000" :circular="true">
							<swiper-item class="swiper-item">
								<view class="swiper-text">1</view>
							</swiper-item>
							<swiper-item class="swiper-item">
								<view class="swiper-text">2</view>
							</swiper-item>
						</swiper>
					</view>
				</view> -->
				<view class="swiper-box">
					<swiper :autoplay="autoplay" class="theSwiper" :indicator-dots="true" :interval="3000"
						:duration="1000" :circular="true" @change="swiperChange">
						<swiper-item v-for="(item,index) in swiperList" :key="index">
							<view class="swiper-item">
								<!-- 如果containVideo为真 第一条显示视频 -->
								<video :src="$imgUrl(videoUrl)" :poster="$imgUrl(coverImg1) " :autoplay='false'
									@play="bofang" @pause="zanting" @ended="mowei" v-if="containVideo&&index==0"
									:loop='false' :enable-progress-gesture="false" id="theVideo"></video> '
								<!-- $imgUrl(videoUrl) -->
								<!-- http://clips.vorwaerts-gmbh.de/big_buck_bunny.mp4 -->
								<!-- :poster="$imgUrl(coverImg1) " -->
								<!-- 如果containVideo 为真 index为0的图片不显示 -->
								<image :src="$imgUrl(item.banner_pic)" class="img" v-if="containVideo==true&&index!=0"
									@click="picJump(item)"></image>
								<!-- 如果containVideo为假 上面一条不生效 图片全部显示-->
								<image :src="$imgUrl(item.banner_pic) " class="img" v-if="containVideo==false"
									@click="picJump(item)"></image>
								<view class="url-box" v-if="videoUrl&&index==0&& item.banner_type != 1 "
									@click="videoJump(item)">
									<image src="../../static/index/videoLink.png" class="img1"></image>
								</view>
							</view>
						</swiper-item>
					</swiper>
				</view>
			</view>
			<view class="news">
				<image src="../../static/index/news.png" class="img"></image>
				<view class="newsSwiper">
					<!-- 这是个公告重大消息，重大消息重... -->
					<view class="page-section swiper">
						<view class="page-section-spacing">
							<swiper class="swiper" :vertical="true" :autoplay="true" :interval="3000" :circular="true">
								<swiper-item class="swiper-item" v-for="(item,index) in newsList" :key="item.id">
									<view class="swiper-text" @click="toGoods(item)">{{item.title}}</view>
								</swiper-item>

							</swiper>
						</view>
					</view>
				</view>
				<view class="line">
				</view>
				<view class="more" @click="toNews">
					更多>>
				</view>

			</view>
		</view>
		<view class="box">
		</view>
		<view class="bookList">
			<view class="title">
				<view class="line">

				</view>
				<view class="text">
					热销推荐
				</view>
			</view>
			<view style="text-align: center; width: 100%;">
				<image v-if="list1.list.length==0" src="../../static/datanull.png" class="imgsss"
					style="width: 344rpx;height: 300rpx;"></image>
			</view>
			<view class="list" v-for="(item,index) in list1.list" :key="index" @tap="goto(item.goods_index)">
				<image v-if="item.goods_icon" :src="$imgUrl(item.goods_icon)" class="img"></image>
				<view class="list-r">
					<view class="text-1">
						<text class="text-type1">
							{{item.zone_name}}
						</text>

						<text>
							{{item.goods_name}}
						</text>

					</view>
					<view class="text-2">
						{{item.goods_describe}}
					</view>
					<view class="text-3">
						￥{{$returnFloat(item.goods_cost)}}
					</view>
					<view class="text-4">
						<view class="left">
							￥{{$returnFloat(item.goods_price)}}
						</view>
						<view class="right">
							已售{{item.goods_sale}}
						</view>
					</view>
				</view>
			</view>

		</view>
		
	</view>
</template>

<script>
	import indexApi from "../../api/index/index.js"
	export default {
		data() {
			return {
				// 新闻消息列表
				newsList: [],
				//推荐课程
				list1: [],
				swiperList: [],
				videoUrl: "",
				coverUrl: "",
				the_banner_type: "1",
				//是否包含视频
				containVideo: false,
				coverImg1: "",
				autoplay: true,
				
			}
		},
		onShareAppMessage: function(options) {
		
			return {
				title: '源爱汇',
				path: '/page/index/index',
				success: function(res) {
					// 转发成功
				},
				fail: function(res) {
					// 转发失败
				}
		
			}
		
		},
		onLoad() {
			this.theCdn = this.$cdnUrl
			//轮播
			indexApi.banner({
				region: "1"
			}).then(res => {
				console.log(res.result)
				this.videoUrl = res.result.video.video_url
				this.coverUrl = res.result.video.video_cover
				this.the_banner_type = res.result.video.banner_type
				//如果有视频 就把视频拼到前面
				//这里等后台加了视频 再测
				if (res.result.video.video_url) {
					this.containVideo = true
					this.coverImg1 = res.result.video.video_cover
					this.swiperList.push(res.result.video)
					console.log(this.swiperList)
					this.swiperList = this.swiperList.concat(res.result.image)
					console.log(this.swiperList)
					
				}
				//如果没有视频 图片数组 就是轮播数组
				else {
					this.swiperList = res.result.image
					
				}
			})
			//消息轮播
			indexApi.news({
				region: "1"
			}).then(res => {
				console.log(res)
				this.newsList = res.result

			})
			// this.init()
		},
		onShow() {
			this.init()
		},
		
		methods: {
			bofang() {
				// console.log(33333333333);
				this.autoplay = false
			},
			zanting() {
				// console.log(444444444444);
				this.autoplay = true
			},
			mowei(){
				this.autoplay = true
			},
			
			init() {
				//推荐课程列表
				indexApi.goods_list({
					type: "1",
					page: "1",
					count: "10"
				}).then(res => {
					this.list1 = res.result
					console.log(this.list1)
				})
			},
			toGoods(item) {
				uni.navigateTo({
					url: "./newsDetail/newsDetail?url=" + item.content + "&title=" + item.title
					// url:'./newsDetail/newsDetail?url='+url+'&title='+title
				})
			},
			toNews() {
				uni.navigateTo({
					url: "./newsList/newsList"
				})
			},
			search() {
				console.log(1)
				uni.navigateTo({
					url: "/pages/index/search/search"
				})
			},
			swiperChange(e) {
				this.autoplay=true
				let swiperIndex = e.detail.current;
				//如果下标不为0   拿视频上下文对象 暂停视频
				if (swiperIndex != 0) {
					uni.createVideoContext('theVideo').pause()
				}

			},
			picJump(e) {
				// let jUrl = 'https://www.baidu.com/'
				// jUrl = JSON.stringify(jUrl)
				// uni.navigateTo({
				// 	url: 'newsDetail?jurl=' + jUrl
				// })								
				console.log(e)
				//跳页面
				if (e.banner_type == 3) {
					uni.navigateTo({
						url: "./detail/detail?id=" + e.jump_parameter
					})
				}
				//跳外链
				else if (e.banner_type == 2) {
					let jUrl = e.url

					uni.navigateTo({
						url: "./newsDetail/newsDetail?url=" + e.url
					})
				}
			},
			videoJump(e) {

				//跳页面
				if (e.banner_type == 3) {
					uni.navigateTo({
						url: "./detail/detail?id=" + e.jump_parameter
					})
				}
				//跳外链
				else if (e.banner_type == 2) {
					let jUrl = e.url

					uni.navigateTo({
						url: "./newsDetail/newsDetail?url=" + e.url
					})
				}
			},
			goto(id) {
				console.log(id)
				uni.navigateTo({
					url: './detail/detail?id=' + id
				})
			}
		}
	}
</script>
<style>
	page {
		height: 100%;
		/* background-color: red; */
	}
</style>
<style lang="scss" scoped>
	.header {
		width: 100%;
		position: relative;
		height: 500rpx;

		.bg {
			width: 750rpx;
			height: 378rpx;
			position: absolute;
			top: 0;
			left: 0;
			// z-index: 0;

		}

		.text {
			position: absolute;
			top: 0;
			left: 34rpx;
			// width: 145px;
			// height: 35px;
			font-size: 36rpx;
			font-family: PingFang SC;
			font-weight: bold;
			color: #333333;
			// line-height: 66px;
			// z-index: 99;
		}

		.btn {
			width: 690rpx;
			height: 70rpx;
			background: #faa7bb;
			opacity: 1;
			border-radius: 10px;
			position: absolute;
			top: 0rpx;
			left: 30rpx;
			display: flex;
			align-items: center;
			justify-content: center;

			.img {
				width: 32rpx;
				height: 32rpx;
			}

			text {

				font-size: 26rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #FFFFFF;
				margin-left: 20rpx;
				opacity: 0.6;
			}
		}

		.banner {
			width: 690rpx;
			height: 276rpx;
			position: absolute;
			bottom: 120rpx;
			left: 30rpx;

			.swiper-box {
				width: 690rpx;
				height: 276rpx;
			}

			.theSwiper {
				width: 690rpx;
				height: 276rpx;

				.swiper-item {
					width: 100%;
					height: 100%;

					#theVideo {
						width: 100%;
						height: 100%;
					}

					.img {
						width: 100%;
						height: 100%;
						position: absolute;
						bottom: 0;
						left: 0;
					}

					.url-box {
						position: absolute;
						bottom: 1%;
						right: 1%;
						z-index: 999;
						width: 150rpx;
						height: 60rpx;

						image {
							width: 100%;
							height: 100%;
						}
					}
				}
			}
		}

		.news {
			width: 690rpx;
			height: 36rpx;
			position: absolute;
			bottom: 30rpx;
			left: 30rpx;
			display: flex;
			align-items: center;
			justify-content: flex-start;

			.img {
				width: 137rpx;
				height: 36rpx;
			}

			.newsSwiper {
				width: 409rpx;
				// height: 26rpx;
				margin-left: 15rpx;
				margin-right: 25rpx;
				font-size: 26rpx;
				font-family: Source Han Sans CN;
				font-weight: 400;
				color: #999999;

				display: flex;
				align-items: center;

				.swiper {
					display: flex;
					align-items: center;
					width: 409rpx;
					height: 32rpx;

					.swiper-text {
						white-space: nowrap;
						overflow: hidden;
						text-overflow: ellipsis;
					}
				}
			}

			.line {
				width: 2rpx;
				height: 27rpx;
				background: #999999;
				margin-right: 18rpx;
			}

			.more {
				width: 94rpx;
				// height: 24rpx;
				font-size: 26rpx;
				font-family: Source Han Sans CN;
				font-weight: 400;
				color: #333333;

			}
		}
	}

	.box {
		width: 750rpx;
		height: 20rpx;
		background: #F5F5F5;
	}

	.bookList {
		width: 750rpx;

		.title {
			width: 100%;
			display: flex;
			justify-content: flex-start;
			align-items: center;
			margin-top: 30rpx;
			margin-bottom: 35rpx;

			.line {
				width: 6rpx;
				height: 36rpx;
				background: #F87897;
				margin-left: 30rpx;
				margin-right: 20rpx;
			}

			.text {
				// width: 142rpx;
				// height: 34rpx;
				font-size: 36rpx;
				font-family: Source Han Sans CN;
				font-weight: 400;
				color: #333333;
				// line-height: 36px;
			}
		}

		.list {
			width: 690rpx;
			height: 170rpx;
			margin-bottom: 60rpx;
			margin-left: 30rpx;
			display: flex;
			justify-content: flex-start;

			.img {
				width: 300rpx;
				height: 170rpx;
				border-radius: 10rpx;
				margin-right: 20rpx;
			}

			.list-r {
				width: 360rpx;

				// background-color: red;
				.text-1 {
					overflow: hidden;
					// height: 31rpx;
					// white-space: nowrap;
					font-size: 32rpx;
					font-family: Source Han Sans CN;
					font-weight: 400;
					color: #333333;
					// text-overflow: ellipsis;
					text-overflow: ellipsis;
					display: -webkit-box;
					-webkit-line-clamp: 2;
					-webkit-box-orient: vertical;

					.text-type1 {
						// padding:  10rpx  10rpx;
						padding-left: 10rpx;
						padding-right: 10rpx;
						margin-right: 10rpx;
						background-color: #F87897;
						font-size: 22rpx;
						border-radius: 9rpx;
						color: #FFFFFF;
						height: 22rpx;
					}
				}

				.text-2 {
					// width: 284px;
					white-space: nowrap;
					overflow: hidden;
					text-overflow: ellipsis;
					// height: 25rpx;
					font-size: 26rpx;
					font-family: Source Han Sans CN;
					font-weight: 300;
					color: #999999;
					// line-height: 36px;
					margin-top: 13rpx;
					// margin-bottom: 6rpx;
				}

				.text-3 {
					// width: 90px;
					// height: 24rpx;
					font-size: 30rpx;
					font-family: Source Han Sans CN;
					font-weight: 400;
					color: #FF1C1C;
					// line-height: 36px;
					// margin-bottom: 13rpx;
				}

				.text-4 {
					display: flex;
					justify-content: space-between;
					align-items: center;
					font-size: 24rpx;
					font-family: Source Han Sans CN;
					font-weight: 300;
					color: #999999;

					.left {
						text-decoration: line-through;
						width: 89rpx;
						height: 19rpx;
					}

					.right {
						width: 100rpx;
						height: 23rpx;
					}
				}
			}
		}
	}
</style>
