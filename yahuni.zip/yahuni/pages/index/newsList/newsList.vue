<template>
	<view class="main-box">
		<view class="news-box">
			<view style="text-align: center; width: 100%;">
				<image v-if="newsList.length==0" src="../../../static/datanull.png" class="imgsss"
					style="width: 344rpx;height: 300rpx; margin-top: 60%;"></image>

			</view>
			<view class="news-item" v-for="(item,index) in newsList" @click="toDetail(item.content,item.title,item.id)">

				<view class="line">
					{{item.title}}
				</view>
				<u-icon name="arrow-right" color="#999999" size="32"></u-icon>

			</view>

		</view>
	</view>
</template>

<script>
	import newsApi from "../../../api/index/index.js"
	export default {
		data() {
			return {
				newsList: []
			}
		},
		onLoad() {
			newsApi.index_news({
				region: 1
			}).then(res => {
				console.log(res.result)
				this.newsList = res.result
			})

		},
		onShareAppMessage: function(options) {
			return {
				title: '源爱汇',
				path: '/page/index/index',
				success: function(res) {
					// 转发成功
				},
				fail: function(res) {
					// 转发失败
				}		
			}		
		},
		methods: {
			toDetail(url, title, id) {
				newsApi.browsingHistory({
					id: id,
					type: "1"
				}).then(res => {
					console.log(res)
				})
				uni.navigateTo({
					url: "../newsDetail/newsDetail?url=" + url + "&title=" + title
					// url:'./newsDetail/newsDetail?url='+url+'&title='+title
				})
			}
		}
	}
</script>
<style>
	page {
		background-color: #F5F5F5;
	}
</style>
<style lang="scss" scoped>
	.main-box {}

	.news-box {
		margin-top: 20rpx;
	}

	.news-item {
		display: flex;
		justify-content: space-between;
		line-height: 83rpx;
		height: 83rpx;
		font-size: 26rpx;
		padding: 0 30rpx;
		width: 750rpx;
		background-color: #FFFFFF;
		border-bottom: 1rpx solid #F5F5F5;

		.line {
			width: 680rpx;
			white-space: nowrap;
			text-overflow: ellipsis;
			overflow: hidden;
			word-break: break-all;
		}
	}
</style>
