<template>
	<view class="main-box">
		<view class="title">
			<view class="ipt-box">

				<view class="ipt-img1">
					<image src="../../../../static/index/ss.png" mode="aspectFill" style="margin-left: 29rpx;"></image>
				</view>
				<input type="text" value="" v-model="iptValue" placeholder="请输入搜索内容"
					placeholder-style="color:#333333;margin-left:10rpx;" @input="ipting" />
				<view class="ipt-img2">
					<image class="ipt-img2" src="../../../../static/index/del-round.png" mode="aspectFill"
						@click="delIpt" v-if="isDelShow"></image>
				</view>

			</view>
			<text style="margin-left: 36rpx;color: #333333;font-size: 26rpx;" @click="search">搜索</text>
		</view>
		<view class="score-box">
			<view class="tap">
				<view class="item" :class="{'active':active=='0'}" @tap="change1">
					<view class="text">
						综合
					</view>
				</view>.
				<view class="item" :class="{'active':active=='1'}" @tap="change2">
					<view class="text">
						销量
					</view>
					<image src="../../../../static/index/none.png" class="img" v-show="sale=='0'"></image>
					<image src="../../../../static/index/up.png" class="img" v-show="sale=='1'"></image>
					<image src="../../../../static/index/down.png" class="img" v-show="sale=='2'"></image>
				</view>
				<view class="item" :class="{'active':active=='2'}" @tap="change3">
					<view class="text">
						价格
					</view>
					<image src="../../../../static/index/none.png" class="img" v-show="price=='0'"></image>
					<image src="../../../../static/index/up.png" class="img" v-show="price=='1'"></image>
					<image src="../../../../static/index/down.png" class="img" v-show="price=='2'"></image>
				</view>
			</view>
			<view style="text-align: center; width: 100%;">
				<image v-if="shopList.length==0" src="../../../../static/datanull.png" class="imgsss"
					style="width: 344rpx;height: 300rpx; margin-top: 60%;"></image>
			</view>
			<view class="list" v-for="(item,index) in shopList" :key="index" @click=goTo(item.goods_index)>
				<image :src="$imgUrl(item.goods_icon)" class="img"></image>
				<view class="list-r">
					<view class="text-1">
						<text class="text-type1">
							{{item.zone_name}}
						</text>

						<text>
							{{item.goods_name}}
						</text>

					</view>
					<view class="text-2">
						{{item.goods_describe}}
					</view>
					<view class="text-3">
						￥{{$returnFloat(item.goods_cost)}}
					</view>
					<view class="text-4">
						<view class="left">
							￥{{$returnFloat(item.goods_price)}}
						</view>
						<view class="right">
							已售{{item.goods_sale}}
						</view>
					</view>
				</view>
			</view>

		</view>

	</view>
</template>

<script>
	import searchListApi from "../../../../api/index/index.js"
	export default {
		onLoad(options) {
			console.log(options)
			// this.token = uni.getStorageSync("xxytoken")
			this.iptValue = options.searchValue
			// this.search()
		},
		onShow() {
			this.search()
		},
		onShareAppMessage: function(options) {
			return {
				title: '源爱汇',
				path: '/page/index/index',
				success: function(res) {
					// 转发成功
				},
				fail: function(res) {
					// 转发失败
				}		
			}		
		},
		data() {
			return {
				iptValue: "",
				isDelShow: false,
				shopList: [],
				// count: 2,
				//当前页数
				page: 1,
				// status: 'loading',
				// totalPage: 1,
				// loadText: {
				// 	loadmore: '上拉或点击加载更多',
				// 	loading: '努力加载中',
				// 	nomore: '没有更多了'
				// },
				// //防止请求还没返回 就又再次触发触底发送请求
				// reachFlag: true,

				active: "0",
				sale: "0",
				price: "0",
				xlorder: "1",
				jgorder: "1"

			}
		},
		onReachBottom() {


		},
		methods: {
			goTo(id) {
				uni.navigateTo({
					url: "../../detail/detail?id=" + id
				})
			},
			delIpt() {
				this.iptValue = ""
				this.isDelShow = false
			},
			ipting() {
				if (this.iptValue.length > 0) {
					this.isDelShow = true
				} else {
					this.isDelShow = false
				}

			},
			search() {
				// console.log(123)

				searchListApi.search_goods({
					// token:"5846783423223160416",
					name: this.iptValue,
					page: this.page,
					count: 10,
					zhorder: "1",
					xlorder: "",
					jgorder: ""


				}).then(res => {
					if (res.result) {
						console.log(res.result)
						this.shopList = res.result.list
					} else {
						this.shopList = []
						// this.status = "nomore"
					}
				})
			},
			change1() {
				this.active = "0"
				this.price = "0"
				this.sale = "0"
				this.search()
			},
			change2() {
				this.active = "1"
				this.price = "0"

				if (this.sale == "0") {
					this.sale = "1"
					searchListApi.search_goods({
						// token:"5846783423223160416",
						name: this.iptValue,
						page: this.page,
						count: 10,
						zhorder: "",
						xlorder: this.xlorder,
						jgorder: ""


					}).then(res => {
						if (res.result) {
							console.log(res.result)
							this.shopList = res.result.list
						} else {
							this.shopList = []
							// this.status = "nomore"
						}
					})
				} else if (this.sale == "1") {
					this.sale = "2"
					this.xlorder = "2"
					searchListApi.search_goods({
						// token:"5846783423223160416",
						name: this.iptValue,
						page: this.page,
						count: 10,
						zhorder: "",
						xlorder: this.xlorder,
						jgorder: ""


					}).then(res => {
						if (res.result) {
							console.log(res.result)
							this.shopList = res.result.list
						} else {
							this.shopList = []
							// this.status = "nomore"
						}
					})
				} else if (this.sale == "2") {
					this.sale = "1"
					this.xlorder = "1"
					searchListApi.search_goods({
						// token:"5846783423223160416",
						name: this.iptValue,
						page: this.page,
						count: 10,
						zhorder: "",
						xlorder: this.xlorder,
						jgorder: ""


					}).then(res => {
						if (res.result) {
							console.log(res.result)
							this.shopList = res.result.list
						} else {
							this.shopList = []
							// this.status = "nomore"
						}
					})
				}


			},
			change3() {
				this.active = "2"
				this.sale = "0"
				if (this.price == "0") {
					this.price = "1"
					searchListApi.search_goods({
						// token:"5846783423223160416",
						name: this.iptValue,
						page: this.page,
						count: 10,
						zhorder: "",
						xlorder: "",
						jgorder: this.jgorder


					}).then(res => {
						if (res.result) {
							console.log(res.result)
							this.shopList = res.result.list
						} else {
							this.shopList = []
							// this.status = "nomore"
						}
					})
				} else if (this.price == "1") {
					this.price = "2"
					this.jgorder = "2"
					searchListApi.search_goods({
						// token:"5846783423223160416",
						name: this.iptValue,
						page: this.page,
						count: 10,
						zhorder: "",
						xlorder: "",
						jgorder: this.jgorder


					}).then(res => {
						if (res.result) {
							console.log(res.result)
							this.shopList = res.result.list
						} else {
							this.shopList = []
							// this.status = "nomore"
						}
					})
				} else if (this.price == "2") {
					this.price = "1"
					this.jgorder = "1"
					searchListApi.search_goods({
						// token:"5846783423223160416",
						name: this.iptValue,
						page: this.page,
						count: 10,
						zhorder: "",
						xlorder: "",
						jgorder: this.jgorder


					}).then(res => {
						if (res.result) {
							console.log(res.result)
							this.shopList = res.result.list
						} else {
							this.shopList = []
							// this.status = "nomore"
						}
					})
				}
			}



		}
	}
</script>

<style lang="scss" scoped>
	.title {
		display: flex;
		height: 98rpx;
		align-items: center;
		background-color: #fff;

		.ipt-box {

			input {
				margin-left: 20rpx;
				width: 420rpx;
				background-color: #eef2f4;
				color: #333333;
			}

			width: 565rpx;
			height: 70rpx;
			margin-left: 36rpx;
			display: flex;
			align-items: center;
			background-color: #eef2f4;
			border-radius: 10rpx;
			// color: #FFFFFF;


		}

		.ipt-img1 {
			image {
				width: 30rpx;
				height: 30rpx;
				margin-left: 10rpx;
			}
		}

		.ipt-img2 {
			image {
				width: 30rpx;
				height: 30rpx;
				// margin-left: 10rpx;
			}
		}
	}

	.score-box {
		width: 750rpx;

		.tap {
			width: 750rpx;
			height: 60rpx;
			background: #FFFFFF;
			border-top: 2rpx solid #eef2f4;
			border-bottom: 2rpx solid #eef2f4;
			margin-bottom: 20rpx;
			display: flex;
			align-items: center;
			justify-content: flex-start;

			.item {
				margin-left: 37rpx;
				display: flex;
				align-items: center;
				justify-content: center;
				// background-color: pink;
				height: 100%;
				width: 200rpx;

				.img {
					width: 12rpx;
					height: 22rpx;
					margin-left: 15rpx;
				}
			}

			.active {
				color: #FF625E;
			}
		}

		.list {
			width: 690rpx;
			height: 170rpx;

			margin-left: 30rpx;
			display: flex;
			justify-content: flex-start;
			margin-bottom: 60rpx;

			.img {
				width: 300rpx;
				height: 170rpx;
				border-radius: 10rpx;
				margin-right: 20rpx;
			}

			.list-r {
				width: 360rpx;

				// background-color: red;
				.text-1 {
					overflow: hidden;
					// height: 31rpx;
					// white-space: nowrap;
					font-size: 32rpx;
					font-family: Source Han Sans CN;
					font-weight: 400;
					color: #333333;
					// text-overflow: ellipsis;
					text-overflow: ellipsis;
					display: -webkit-box;
					-webkit-line-clamp: 2;
					-webkit-box-orient: vertical;

					.text-type1 {
						// padding:  10rpx  10rpx;
						padding-left: 10rpx;
						padding-right: 10rpx;
						margin-right: 10rpx;
						background-color: #F87897;
						font-size: 22rpx;
						border-radius: 9rpx;
						color: #FFFFFF;
						height: 22rpx;
					}
				}

				.text-2 {
					// width: 284px;
					white-space: nowrap;
					overflow: hidden;
					text-overflow: ellipsis;
					// height: 25rpx;
					font-size: 26rpx;
					font-family: Source Han Sans CN;
					font-weight: 300;
					color: #999999;
					// line-height: 36px;
					margin-top: 13rpx;
					// margin-bottom: 6rpx;
				}

				.text-3 {
					// width: 90px;
					// height: 24rpx;
					font-size: 30rpx;
					font-family: Source Han Sans CN;
					font-weight: 400;
					color: #FF1C1C;
					// line-height: 36px;
					// margin-bottom: 13rpx;
				}

				.text-4 {
					display: flex;
					justify-content: space-between;
					align-items: center;
					font-size: 24rpx;
					font-family: Source Han Sans CN;
					font-weight: 300;
					color: #999999;

					.left {
						text-decoration: line-through;
						width: 89rpx;
						height: 19rpx;
					}

					.right {
						width: 100rpx;
						height: 23rpx;
					}
				}
			}
		}

	}

	.btmline {
		height: 1rpx;
	}

	.line-txt {
		margin-left: 10rpx;
	}
</style>
