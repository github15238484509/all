<template>
	<view class="main-box">
		<view class="title">
			<view class="ipt-box">
				
				<view class="ipt-img1">
					<image  src="../../../static/index/ss.png" mode="aspectFill" style="margin-left: 29rpx;"></image>
				</view>
				<input type="text" value="" v-model="iptValue" placeholder="请输入搜索内容" placeholder-style="color:#CCCCCC;margin-left:10rpx;" @input="ipting"  />
				<view class="ipt-img2">
					<image class="ipt-img2" src="../../../static/index/del-round.png" mode="aspectFill" @click="delIpt" v-if="isDelShow"></image>
				</view>
				
			</view>
			<text style="margin-left: 36rpx;color: #333333;font-size: 26rpx;" @click="search">搜索</text>
		</view>
		<view class="content">
			<view class="content-top">

				<view class="" style="font-size: 26rpx;">
					历史搜索
				</view>
				<view class="" style="margin-right: 10rpx;" @click="clkbin">
					<image src="../../../static/index/bin.png" mode="aspectFill"></image>
				</view>
			</view>
			<view style="text-align: center; width: 100%;">
			                <image v-if="arr.length==0" src="../../../static/datanull.png" class="imgsss"
			                    style="width: 344rpx;height: 300rpx; margin-top: 60%;"></image>
			            </view>
			<view class="content-box">
				<view class="content-box-item" v-for="item in arr" @click="hisSearch(item)">
					{{item.key_word}}
				</view>
			</view>
		</view>
		<!-- <image src="../../../static/index/background.png" class="foot"></image> -->
	</view>
</template>

<script>
	import searchHistoryApi from "../../../api/index/index.js"
	export default {
		data() {
			return {
				iptValue: "",
				theArr: [],
				arr: [],
				isDelShow:false,
				token:"",
				longitude:"",
				latitude:"",
				nowCity:"",
				merSort:""
			}
		},
		onShow() {
			// this.arr=[]
			// this.token = uni.getStorageSync('xxytoken');
			// searchHistoryApi.searchHistory({
			// 	token:this.token
				
			// }).then(res =>{
			// 	if(res.status==200){
			// 		res.result.forEach((item,index)=>{
			// 			this.arr.push(item.key_word)
			// 		})
			// 	}else{
			// 		uni.showToast({
			// 			title:res.message,
			// 			icon:"none"
			// 		})
			// 	}
			// })
		},
		onShareAppMessage: function(options) {
			return {
				title: '源爱汇',
				path: '/page/index/index',
				success: function(res) {
					// 转发成功
				},
				fail: function(res) {
					// 转发失败
				}		
			}		
		},
		onLoad(options) {
			
			// this.token=uni.getStorageSync('xxytoken')
			
			
		},
		onShow() {
			this.arr=[]
			searchHistoryApi.user_search({
				// token:"12223161462052158"
			}).then(res=>{
				console.log(res)
				this.arr=res.result
			})
		},
		methods: {
			//点击了搜索    存入本地数组
			search() {		
				if(this.iptValue){
					// uni.setStorageSync("search",this.iptValue)
					uni.navigateTo({
						url:'searchList/searchList?searchValue='+ this.iptValue
					})
				}else{
					uni.showToast({
						title:'搜索内容不能为空',
						icon:'none'
					})
				}								
			},
			hisSearch(e){
				this.iptValue=e.key_word;
				console.log(this.iptValue)
				uni.navigateTo({
					url:'searchList/searchList?searchValue='+ this.iptValue
				})				
			},
			clkbin() {
				let that=this
				uni.showModal({
				    title: '提示',
				    content: '确认清空搜索历史吗？',
					
				    success: function (res) {
				        if (res.confirm) {
				          that.arr = []
						searchHistoryApi.user_search_empty({
							// token:"5846783423223160416"
						}).then(res=>{
							console.log(res)
						})
						  
						  
				        } else if (res.cancel) {
				           console.log(222)
				        }
				    }
				});
				
			},
			delIpt(){
				this.iptValue=""
				this.isDelShow=false
			},
			ipting(){
				if(this.iptValue.length>0){
					this.isDelShow=true
				}else{
					this.isDelShow=false
				}
				
			}

		}
	}
</script>
<style>
   page{ background:#FFFFFF }
</style>
<style lang="scss" scoped>
	.main-box {
		.ipt-img2{
			display: flex;
			align-items: center;
		}

		.title {
			display: flex;
			height: 98rpx;
			align-items: center;
			// background-color: #4894FE;

			.ipt-box {
				
				input {
					margin-left: 20rpx;
					width: 420rpx;
					background-color: #eef2f4;
					color: #333333;
				}

				width: 565rpx;
				height: 70rpx;
				margin-left: 36rpx;
				display: flex;
				align-items: center;
				background-color: #eef2f4;
				border-radius: 10rpx;
				// color: #FFFFFF;

				
			}
		}
	}

	.content {
		padding: 0 30rpx;
		margin-top: 50rpx;

		.content-top {
			display: flex;
			justify-content: space-between;
			align-items: center;

			image {
				width: 30rpx;
				height: 32rpx;
			}
		}
		.content-box {
			display: flex;
			margin-top: 26rpx;
			// justify-content: space-evenly;
			flex-wrap: wrap;
			.content-box-item {
				white-space:nowrap;
				overflow:hidden;
				text-overflow:ellipsis;
				box-sizing: border-box;
				padding: 19rpx 34rpx;
				color: #999999;
				font-size: 24rpx;
				height: 60rpx;
				line-height: 24rpx;
				text-align: center;
				background-color: #F5F5F5;
				border-radius: 30rpx;
				margin-right: 20rpx;
				margin-bottom: 21rpx;
			}
		}
		
	}
	.ipt-img1{
		image {
			width: 30rpx;
			height: 30rpx;
			margin-left: 10rpx;
		}
	}
	.ipt-img2{
		image {
			width: 30rpx;
			height: 30rpx;
			// margin-left: 10rpx;
		}
	}
	.foot{
		width: 750rpx;
		height: 400rpx;
		position: fixed;
		bottom: 0;
		left: 0;
	}
</style>

