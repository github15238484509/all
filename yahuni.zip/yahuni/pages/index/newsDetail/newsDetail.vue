<template>
	<view>
		<!-- <web-view :src="url"></web-view> -->
		   <web-view :webview-styles="webviewStyles" :src="url"></web-view>
	</view>
</template>

<script>
	export default {
		data() {
			return {  
				url:"",
				title:"",
				webviewStyles: {
				                    progress: {
				                        color: '#4794FF'
				                    }
				                }
			}
		},
		onLoad(options) {
			
			
			this.url=this.$imgUrl(options.url) 
			this.title=options.title
			uni.setNavigationBarTitle({
			    title: this.title
			});
			
		},
		onShareAppMessage: function(options) {
			return {
				title: '源爱汇',
				path: '/page/index/index',
				success: function(res) {
					// 转发成功
				},
				fail: function(res) {
					// 转发失败
				}		
			}		
		},
		methods: {
			
		}
	}
</script>

<style>

</style>

