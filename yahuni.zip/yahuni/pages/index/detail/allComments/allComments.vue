<template>
	<view class="box">
		<view class="navbar">
			<view class="item" :class="{active: current=='1'}" @tap="currentChange('1')">
				<text>全部</text>
			</view>
			<view class="item" :class="{active: current=='2'}" @tap="currentChange('2')">
				<text>好评</text>
			</view>
			<view class="item" :class="{active: current=='3'}" @tap="currentChange('3')">
				<text>中评</text>
			</view>
			<view class="item" :class="{active: current=='4'}" @tap="currentChange('4')">
				<text>差评</text>
			</view>
			<view class="item" :class="{active: current=='5'}" @tap="currentChange('5')">
				<text>有图</text>
			</view>
		</view>
		<view class="line">

		</view>
		<view class="talk">
			<view class="title" v-if="list.length>0">
				评价
			</view>
			<view class="title" v-if="list.length==0">
				暂无评价
			</view>
			<view style="text-align: center; width: 100%;">
				<image v-if="list.length==0" src="../../../../static/datanull.png" class="imgsss"
					style="width: 344rpx;height: 300rpx; margin-top: 60%;"></image>
			</view>
			<view class="content1" v-for="(item,index) in list" :key="index">
				<view class="top">


					<image :src="$imgUrl(item.comment_user_photo)" class="img"></image>
					<view class="item-c">
						<view class="zz">
							<text>{{item.comment_nick}}</text>
							<u-rate :disabled="true" active-color="#FFC600" :count="count"
								v-model="list[index].comment_goods_score"></u-rate>
						</view>
						<view class="gray">
							({{item.goods_sku_name}})
						</view>
						<view class="tt">
							{{item.comment_content}}
						</view>

					</view>
					<view class="time">
						{{item.comment_time}}
					</view>


				</view>
				<view class="imgss" >
					<image v-for="(item1,index1) in item.comment_images" :src="$imgUrl(item1)" class="img22"
						:key="index1" @click="toBig(item.comment_images,index1)"></image>

				</view>
			</view>
		</view>


	</view>
</template>

<script>
	import indexApi from "../../../../api/index/index.js"
	export default {
		data() {
			return {
				current: "1",
				goods_index: "",
				list: [],
				count: 5,
			};
		},
		onLoad(e) {
			console.log(e)
			this.goods_index = e.id
			this.init()
		},
		onShareAppMessage: function(options) {
			return {
				title: '源爱汇',
				path: '/page/index/index',
				success: function(res) {
					// 转发成功
				},
				fail: function(res) {
					// 转发失败
				}		
			}		
		},
		methods: {
			toBig(arr, index) {
				let imgs = []
				arr.forEach(el => {
					el = this.$imgUrl(el)
					imgs.push(el)
				})

				console.log(imgs)
				// let img =this.$imgUrl(url)
				// 预览图片
				uni.previewImage({
					urls: imgs,
					current: index

				});

			},
			currentChange(e) {
				console.log(e)
				this.current = e
				this.init()
			},
			init() {
				this.list = []
				indexApi.goods_comment_list({
					goods_index: this.goods_index,
					type: this.current,
					page: "1",
					count: "10"
				}).then(res => {
					console.log(res)
					if (res.result.info.length > 0) {
						this.list = res.result.info
						this.list.map(el => {
							el.comment_time = this.$time(el.comment_time, 0)
							el.comment_images = el.comment_images.split(/(^\/)|(,\/)/)
							if(el.comment_images.length==1){
								console.log(el.comment_images)
								el.comment_images=el.comment_images[0].split(",")
								// console.log(el.comment_images)
								
								
							}else{
								console.log(el.comment_images)
								el.comment_images = el.comment_images.filter((item) => {
									if (item) {
										return item.startsWith("CxtxMapi")
									}
								})
								// console.log(el.comment_images)
								// this.imgs = arr
							}
							
							
						})
					}

				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	.gray {
	                margin-top: 10rpx;
	                margin-left: 8rpx;
	                font-size: 24rpx;
	                font-family: PingFang SC;
	                font-weight: 400;
	                color: #999999;
	        }
	.box {
		
		.talk {
			// height: 360rpx;
			width: 100%;
			padding-left: 30rpx;
			padding-right: 30rpx;

			.top {
				display: flex;
				justify-content: flex-start;
				position: relative;
			}

			.title {
				margin-top: 29rpx;
				font-size: 30rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: #333333;
			}

			.content1 {
				margin-top: 40rpx;
				border-bottom: 2rpx solid #F5F5F5;
				width: 100%;
				padding-bottom: 30rpx;
				// height: 100%;

				.img {
					width: 60rpx;
					height: 60rpx;
					margin-right: 15rpx;
				}

				.item-c {
					// height: 260rpx;
					// width: 430rpx;
					margin-right: 40rpx;

					.zz {
						font-size: 26rpx;
						font-family: PingFang SC;
						font-weight: 500;
						color: #333333;

						text {
							margin-right: 15rpx;
						}
					}

					.tt {

						font-size: 26rpx;
						font-family: PingFang SC;
						font-weight: 400;
						color: #333333;
						margin-left: 8rpx;
						margin-top: 25rpx;
					}




				}

				.time {
					font-size: 24rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #999999;
					line-height: 100%;
					position: absolute;
					top: 0;
					right: 0;
				}


			}
		}

		.imgss {
			margin-top: 20rpx;
			display: flex;
			justify-content: flex-start;
			margin-left: 80rpx;

			.img22 {
				width: 130rpx;
				height: 130rpx;
				margin-right: 20rpx;
			}
		}

		.line {
			width: 750rpx;
			height: 20rpx;
			background: #F5F5F5;
		}

		.navbar {
			height: 100rpx;
			width: 100%;
			display: flex;
			align-items: center;
			justify-content: space-around;
			font-size: 24rpx;
			font-family: PingFang SC;
			font-weight: 400;
			color: #999999;

			.item {
				width: 120rpx;
				height: 40rpx;
				background: #EEEEEE;
				border-radius: 20rpx;
				display: flex;
				align-items: center;
				justify-content: center;
			}

			.active {
				color: #FFFFFF;

				background: #FD635E;
			}

		}
	}
</style>
