<template>
	<view class="box">
		<view class="uni-padding-wrap">
			<view class="page-section swiper">
				<view class="page-section-spacing">
					<swiper class="swiper" :circular="true" :indicator-dots="indicatorDots" :autoplay="false"
						 :duration="1000" >
							<swiper-item  v-if="containVideo">
							<!-- 	<video
								:src="$imgUrl(videoUrl)" 
								:poster="$imgUrl(coverImg1) " 
								:autoplay='false'
								:object-fit='fill'
								:loop='false' 
								:enable-progress-gesture="false" 
								id="theVideo"></video> -->
								<video
								style="width: 100%;height: 100%;"
								:src="$imgUrl(videoUrl)" 
								:poster="$imgUrl(coverImg1) " 
								:autoplay='false'
								:object-fit='fill'
								:loop='false' 
								:enable-progress-gesture="false" 
								></video>
							</swiper-item>
						<swiper-item v-for="(item,index) in swiperList" :key="index">
							
							
							<!-- 如果containVideo为真 第一条显示视频 -->
							<!-- <video :src="$imgUrl(videoUrl)" :poster="$imgUrl(coverImg1) " :autoplay='false' @error="haha"
								 v-if="containVideo&&index==0"
								:loop='false' :enable-progress-gesture="false" id="theVideo" :object-fit='fill' ></video> -->
							<!-- <image :src="$imgUrl(item)" class="img" v-if="containVideo==true&&index!=0"></image> -->
							
							
							<image :src="$imgUrl(item) " class="img" ></image>
						</swiper-item>
					</swiper>
				</view>
			</view>
		</view>
		<view class="describe">
			<view class="title">
				<view class="left">
					<text class="text-type1">
						{{obj.goods_info.zone_name}}
					</text>

					<text>
						{{obj.goods_info.goods_name?obj.goods_info.goods_name:""}}
					</text>

				</view>
				<view class="right" @click="open2">
					<image src="../../../static/index/share.png" class="img"></image><text>分享</text>

				</view>
			</view>
			<view class="des">
				{{obj.goods_info.goods_describe?obj.goods_info.goods_describe:""}}
			</view>
			<view class="num">
				<view class="left">
					<view class="l1">
						¥{{obj.goods_info.goods_cost?$returnFloat(obj.goods_info.goods_cost):""}}
					</view>
					<view class="l2">
						¥{{obj.goods_info.goods_price?$returnFloat(obj.goods_info.goods_price):""}}
					</view>
				</view>
				<view class="right">
					销量{{obj.goods_info.goods_sale}}

				</view>
			</view>
		</view>
		<view class="line">

		</view>
		<view class="spec">
			<view class="left">
				<view class="l1">
					发货
				</view>
				<image src="../../../static/index/wz.png" style="width: 27rpx;height: 27rpx;margin-right: 7rpx;">
				</image>
				<view class="l1">
					{{obj.goods_info.province_name}}-{{obj.goods_info.city_name}}
				</view>
			</view>
		</view>
		<view class="line">

		</view>
		<view class="spec" v-if="isMore" @click="select">
			<view class="left">
				<view class="l1">
					选择
				</view>
				<view class="l2">
					规格
				</view>
			</view>
			<view class="right">
				>
			</view>
		</view>

		<view class="spec" v-if="skuList.length>0" @click="select">
			<view class="left">
				<view class="l1">
					已选：{{curItems[0]}}
				</view>
				<view class="l2">
					{{curItems[1]}}
				</view>
			</view>
			<view class="right">
				>
			</view>
		</view>
		<view class="line" v-if="isMore">

		</view>
		<!-- <view class="content" v-if="videoList.length>0">
			<view class="title">
				<view class="left">
					课程视频
				</view>
				<view class="right" @click="goVideo">
					更多 >
				</view>
			</view>
			<view class="item" v-for="(item,index) in videoList" :key="index" @click="play11(item.video_id)">

				<video v-if="!show2" :id="'video_play'+item.video_id" :src="$imgUrl(item.video_url)" controls
					class="img" @play="playVedio(item.video_id)" :show-fullscreen-btn="false"
					:show-center-play-btn="true" play-btn-position="center">
				</video>

				<image src="../../../static/index/sp.png" class="ding"></image>
				<view class="item-r">
					<view class="name">
						{{item.video_name}}
					</view>
					<view class="bottom">
						<view class="left">
							{{item.time}}
						</view>
						<view class="right">
							<image src="../../../static/index/huo.png" class="img"></image>
							<text>{{item.video_popular}}浏览</text>
						</view>
					</view>
				</view>
			</view>

			<view class="more1" @click="goVideo">
				查看全部>>
			</view>
		</view>
		<view class="line" v-if="videoList.length>0">

		</view> -->
		<view class="talk" v-if="obj.goods_comment.comment_content">
			<view class="title">
				评价
			</view>
			<view class="content1">
				<view style="display: flex;">
					<image :src="$imgUrl(obj.goods_comment.comment_user_photo)" class="img"></image>
					<view class="item-c">
						<view class="zz">
							<text>{{obj.goods_comment.comment_nick}}</text>
							<u-rate :disabled="true" active-color="#FFC600" :count="count" v-model="value"></u-rate>
						</view>
						<view class="gray">
							({{obj.goods_comment.goods_sku_name}})
						</view>
						<view class="tt">
							{{obj.goods_comment.comment_content}}
						</view>

					</view>
				</view>

				<view class="time">
					{{obj.goods_comment.time}}
				</view>

			</view>
		</view>
		<view class="imgss" v-if="imgs">
			<image v-for="(item,index) in imgs" :src="$imgUrl(item)" class="img"></image>

		</view>
		<view class="more" v-if="obj.goods_comment.comment_content" @click="toMore">
			<view class="more-c">
				查看全部>>
			</view>
		</view>
		<view class="line" v-if="obj.goods_comment.comment_content">

		</view>
		<view class="navbar">
			<view class="left" :class="{active: current=='0'}" @tap="currentChange('0')">
				<text>图文介绍</text>
			</view>
			<view class="right" :class="{active: current=='1'}" @tap="currentChange('1')">
				<text>规格参数</text>
			</view>
		</view>
		<view class="sku" v-for="(item,index) in obj.goods_info.goods_params" v-if="current=='0'">
			<text class="sku1">{{item.name}}</text>
			<text class="sku2">{{item.value}}</text>
		</view>
		<view class="sku" v-for="(item,index) in obj.goods_info.goods_params_list" v-if="current=='1'">
			<text class="sku1">{{item.name}}</text>
			<text class="sku2">{{item.value}}</text>
		</view>
		<view class="openSku" v-if="current=='0'&& obj.goods_info.goods_params.length > 4">
			<image src="../../../static/index/down22.png" class="img"></image>
			<text @tap="currentChange('1')">展开</text>
		</view>
		<rich-text :nodes="obj.goods_info.goods_details.replace(/\<img/gi, '<img style=max-width:100%;height:auto')"
			v-if="current=='0'"></rich-text>
		<view class="footer">
			<view class="left">
				<view class="item" @click="goHome">
					<image src="../../../static/index/home.png" class="img"></image>
					<view class="text">
						首页
					</view>
				</view>
				<view class="item" @click="change">
					<image src="../../../static/index/heart.png" class="img" v-if="obj.goods_info.is_collection=='0'">
					</image>
					<image src="../../../static/index/heart1.png" class="img" v-if="obj.goods_info.is_collection=='1'">
					</image>
					<view class="text">
						收藏
					</view>
				</view>
				<view class="item" @click="open">
					<image src="../../../static/index/custom.png" class="img"></image>
					<view class="text">
						客服
					</view>
				</view>
			</view>
			<view class="right" @click="toCar" v-if="obj.goods_info.is_cart=='1'">
				<text style="font-size: 30rpx;">加入购物车</text>
			</view>
			<view class="right1" @click="buy" v-if="obj.goods_info.is_cart=='1'">
				<text style="font-size: 30rpx;">立即购买</text>
			</view>
			<view class="right2" @click="buy" v-if="obj.goods_info.is_cart=='0'">
				<text style="font-size: 30rpx;">立即购买</text>
			</view>
		</view>
		<u-popup v-model="show" mode="center" border-radius="10" width="500rpx" height="310rpx">
			<view class="dingwei">
				<view class="call">
					<text>联系客服</text>
				</view>
				<view class="call-c">
					<view class="item1">
						<view class="name">
							{{customService.service_name}}
						</view>
						<view class="time">
							({{customService.service_start}} - {{customService.service_end}})
						</view>
					</view>
					<view class="item2">
						<view class="txt1">
							微信：
						</view>
						<view class="txt2">
							{{customService.service_wechat}}
						</view>
						<image src="../../../static/index/ccc.png" class="img" @click="copy"></image>
					</view>
					<view class="item2 " style="margin-top: 10rpx;">
						<view class="txt1">
							电话：
						</view>
						<view class="txt2">
							{{customService.service_phone}}
						</view>
						<image @click="goPhone" src="../../../static/index/phone.png" class="img"></image>
					</view>
				</view>
				<view class="xxx" @click="close">
					<text>取消</text>
				</view>

			</view>
		</u-popup>

		<view class="share" v-if="show2">
			<image :src="$imgUrl(share_goods)" class="share_center"></image>
			<view class="footer2">
				<view class="item">
					<view class="left">
						<image src="../../../static/index/wx.png" class="img"></image>
						<button :plain="true" open-type="share" class="fx"></button>
						<view class="text">
							微信好友
						</view>

					</view>
					<view class="right">
						<image @click="getImg()" src="../../../static/index/pic.png" class="img"></image>
						<view class="text">
							保存图片
						</view>

					</view>
				</view>
				<view class="item2" @click="close2()">
					<view class="txt">
						取消
					</view>

				</view>
			</view>
		</view>

		<u-popup v-model="show3" mode="bottom" border-radius="30" width="750rpx" height="900rpx">
			<view class="showDev" style="overflow:hidden ;">


				<view class="header44">
					<image :src="$imgUrl(skuImg)" class="img"></image>
					<view class="right">
						<view class="item1">
							<view class="item3">
								<view class="left">
									￥
								</view>
								<view class="right">
									{{$returnFloat(skuPrice)}}
								</view>
							</view>
							<view class="item2" v-if="skuList.length>0">
								<view class="item4">
									已选：{{curItems[0]}}
								</view>
								<view class="item5">
									{{curItems[1]}}
								</view>
							</view>
							<view class="item6">
								剩余库存{{sku_inventory}}
							</view>

						</view>
						<image @click="close3" src="../../../static/index/del1.png" class="img2"></image>
					</view>
				</view>
				<view class="sku1" v-for="(item,typeIndex) in skuList" :key="item.sku_index">
					<view class="top">
						<text>
							{{ item.sku_name }}
						</text>

					</view>
					<view class="list">
						<view class="item"     v-for="(el, itemIndex) in item.next_sku"
							 :class="curIndex[typeIndex].curIndex === itemIndex ? 'act' : ''"
							 @click="changeCur(typeIndex, itemIndex)">
							<view class="ttt">
								<text>

									 {{ el.sku_name }}
								</text>
							</view>
						</view>
					</view>

				</view>
				<view style="padding-left: 30rpx;padding-right: 30rpx;margin-top: 100rpx;">
					<view class="dddd">
						<view class="text">
							购买数量
						</view>
						<u-number-box v-model="goods_count" @change="valChange" :min="1" :max="limit_num"
							style="margin-left: 340rpx;"></u-number-box>
					</view>
				</view>

				<view class="btn" @click="close4">
					<view class="txt">
						确定
					</view>
				</view>
			</view>
		</u-popup>

	</view>
</template>

<script>
	import indexApi from "../../../api/index/index.js"
	import carApi from "../../../api/car/car.js"
	// import aboutApi from "../../../api/about/about.js"
	export default {
		data() {
			return {
				indicatorDots: true,
				// autoplay: true,
				interval: 5000,
				duration: 500,
				obj: {
					goods_info: {
						goods_details: ""
					},
					goods_comment: {},

				},
				count: 5,
				//星数
				value: 4,
				current: "0",
				goods_index: "",
				imgs: [],
				//视频列表
				videoList: [],
				//评论区域:
				comment: {},
				//单规格多规格判断
				isMore: true,
				//客服信息
				customService: {},
				show: false,
				show2: false,
				show3: false,
				//二维码
				share_goods: "",

				//sku数组
				skuList: [],
				//sku图片数组
				skuImgs: [],
				//   定义一个数组，存放当前每种类型选择的属性
				curIndex: [],
				//sku
				curChoose: "",
				curItems: [],
				skuImg: "",
				skuPrice: "",
				sku_index: "",
				// number: 0,
				videoContext: "",
				//是否包含视频
				containVideo: false,
				coverImg1: "",
				videoUrl: "",
				coverUrl: "",
				swiperList: [],
				//库存
				sku_inventory: "0",
				goods_count: 1,
				isCar: "",
				limit_num: "",
				is_level: "",
				autoplay:true


			};
		},
		onLoad(e) {
			console.log(e)
			this.goods_index = e.id
		},
		onShareAppMessage() {
			return {
				title: "缘爱汇",
				path: `pages/index/detail/detail?id=` + this.goods_index,
				imageUrl: this.$imgUrl(this.share_goods)
			}
		},
		onShow() {
			this.show3 = false
			// this.number = "0"
			this.init()
		},
		methods: {
			// bofang() {
			// 	// console.log(33333333333);
			// 	this.autoplay = false
			// },
			// zanting() {
			// 	// console.log(444444444444);
			// 	this.autoplay = true
			// },
			// mowei(){
			// 	this.autoplay = true
			// },
			
			valChange(e) {
				console.log('当前值为: ' + e.value)
				this.goods_count=e.value
			},
			copy() {
				uni.setClipboardData({
					data: this.customService.service_wechat, //要被复制的内容
					success: () => { //复制成功的回调函数
						uni.showToast({ //提示
							title: "复制成功"
						})
					}
				});
			},
			toCar() {
				this.isCar="1"
				this.show3 = true


			},
			buy() {
				
				this.show3=true
				
			},
			changeCur(type, index) {
			
				if (this.curIndex[type].curIndex == index) {
					return;
				}
				this.curIndex[type].curIndex = index;
				console.log(this.curChoose)
				this.curChoose = this.curChoose.split(",");

				this.curChoose[type] = `${this.skuList[type].sku_index}:${this.skuList[type].next_sku[index].sku_index}`;

				this.curChoose = this.curChoose.join(",");

				this.curItems[type] = this.skuList[type].next_sku[index].sku_name;
				console.log(this.skuImgs)

				let obj = this.skuImgs.find(el => {
					return el.sku_info == this.curChoose
				})

				this.skuImg = obj.sku_pic
				this.skuPrice = obj.sku_cost_price
				this.sku_index = obj.sku_index

				this.sku_inventory = obj.sku_inventory
				console.log(obj.sku_two)
			},
			init() {
				indexApi.goods_details({
					// token: uni.getStorageSync('token'),
					goods_index: this.goods_index
				}).then(res => {
					console.log(res.result)
					this.limit_num = res.result.goods_info.limit_num
					this.is_level = res.result.goods_info.is_level
					this.videoUrl = res.result.goods_info.goods_video
					this.coverUrl = res.result.goods_info.goods_video_cover
					if (res.result.goods_info.goods_video) {
						this.containVideo = true
						this.coverImg1 = res.result.goods_info.goods_video_cover
						// this.swiperList.push(res.result.goods_info.goods_video)
						console.log(this.swiperList)
						this.swiperList = res.result.goods_info.goods_icon
						console.log(this.swiperList)

					} else {
						this.swiperList = res.result.goods_info.goods_icon

					}
					if (res.result.goods_info.goods_sku == "1") {
						this.sku_index = res.result.goods_info.skuInfo[0].sku_index
						this.skuList = res.result.goods_info.next_sku
						this.skuImgs = res.result.goods_info.skuInfo
						this.skuImg = res.result.goods_info.skuInfo[0].sku_pic
						this.skuPrice = res.result.goods_info.skuInfo[0].sku_cost_price
						this.sku_inventory = res.result.goods_info.skuInfo[0].sku_inventory
						// console.log(this.sku_inventory,333333333333333333);

					}
					if (res.result.goods_info.goods_sku == "2") {
						this.skuList = res.result.goods_info.next_sku
						this.skuImgs = res.result.goods_info.skuInfo
						this.skuList.map((item) => {
							// 存放每种类型，并默认选中该类型的第一项
							this.curIndex.push({
								sku_name: item.sku_name,
								curIndex: 0,
							});
							this.curItems.push(item.next_sku[0].sku_name);
							this.curChoose += `${item.sku_index}:${item.next_sku[0].sku_index},`;
						});
						this.curChoose = this.curChoose.substring(0, this.curChoose.length - 1);
						console.log(this.curChoose)
						this.skuImg = res.result.goods_info.skuInfo[0].sku_pic
						this.skuPrice = res.result.goods_info.skuInfo[0].sku_cost_price
						this.sku_index = res.result.goods_info.skuInfo[0].sku_index
						this.sku_inventory = res.result.goods_info.skuInfo[0].sku_inventory
						// console.log(this.sku_inventory,333333333333333333);

					}
					// if (res.result.video_list.length > 0) {
					// 	//视频列表
					// 	res.result.video_list.map(el => {
					// 		el.time = this.$time(el.add_time, 0)
					// 	})
					// 	this.videoList = res.result.video_list

					// }
					this.obj = res.result
					
					console.log(this.obj)
					if (this.obj.goods_comment.comment_content) {
						this.value = res.result.goods_comment.comment_goods_score
						this.obj.goods_comment.time = this.$time(res.result.goods_comment.comment_time, 0)
					}
					if (this.obj.goods_comment.comment_images) {
						let arr = this.obj.goods_comment.comment_images.split(/(^\/)|(,\/)/)
						console.log(arr);
						if (arr.length == 1) {
							let arr1 = arr[0].split(",")
							console.log(arr1)
							this.imgs = arr1

						} else {
							arr = arr.filter((item) => {
								if (item) {
									return item.startsWith("CxtxMapi")
								}
							})
							this.imgs = arr
						}

						console.log(this.imgs);
					}
					if (res.result.goods_info.goods_sku == '1') {
						this.isMore = false
					}
					this.customService = res.result.customer_service
					// console.log(this.obj.goods_info.goods_icon)
				})
			},
			//切换tab栏
			currentChange(e) {
				// console.log(e)
				this.current = e
				// console.log(this.current)

			},
			goHome() {
				uni.switchTab({
					url: '/pages/index/index'
				});
			},
			goPhone() {
				uni.makePhoneCall({
					phoneNumber: this.obj.customer_service.service_phone,
					success: () => {
						// console.log("成功拨打电话")
					}
				})
			},
			// goVideo() {
			// 	uni.navigateTo({
			// 		url: "/pages/index/detail/coursesList/coursesList?id=" + this.goods_index
			// 	})
			// },
			toMore() {
				uni.navigateTo({
					url: "/pages/index/detail/allComments/allComments?id=" + this.goods_index
				})
			},
			open() {
				this.show = true
			},
			open2() {
				//分享二维码
				indexApi.share_goods({
					// token:uni.getStorageSync('token'),
					page: "pages/index/detail/detail",
					goods_id: this.goods_index
				}).then(res => {
					if (res.status==200){
						this.share_goods = res.result.share_goods
						this.show2 = true
						console.log(111);
					}else{
						uni.showToast({
						        title:res.result.message,
						        icon:'none'
						})
					}
					
				})
				
				// if(!uni.getStorageSync('token')){
				// 				 uni.showToast({
				// 					  title:'请选登录',
				// 					  icon:'none'
				// 				  })
				// 				  return;
				// };
			},
			close() {
				this.show = !this.show
			},
			close2() {
				this.show2 = false
			},
			select() {
				this.show3 = true
			},
			close3() {
				this.show3 = false
			},
			close4() {
				
				if (this.is_level == "0") {
					uni.showToast({
						title: "请联系你的上级进行下单购买",
						icon: "none"
					})
					return
				}
				if (!uni.getStorageSync('token')) {
					uni.navigateTo({
						url: "../../login/login"
					})
					return;
				};
				if (this.sku_inventory == 0) {
					// console.log(416546456456456);
					uni.showToast({
						title: "库存不足",
						duration: 2000,
						icon: 'none'
					})
					return
				}
				if (this.isCar == '1') {
					carApi.add_cart({
						goods_index: this.goods_index,
						sku_index: this.sku_index,
						goods_count: this.goods_count
					}).then(res => {
						this.isCar = "2"
						this.close3()
						console.log(res)
						if (res.status == 200) {
							uni.showToast({
								title: "添加成功",
								duration: 2000
							})
						} else {
							uni.showToast({
								title: res.message,
								icon: 'none'
							})
						}
					})
					return
				}

				if (this.obj.goods_info.goods_sku == "1") {
					this.sku_index = this.obj.goods_info.skuInfo[0].sku_index
					// console.log(this.obj.goods_info.skuInfo[0].sku_index)
					uni.navigateTo({
						url: "./order/order?index=" + this.sku_index + "&id=" + this.goods_index +
							"&goods_count=" + this.goods_count
					})
					return
				}
				
				
				uni.navigateTo({
					url: "./order/order?index=" + this.sku_index + "&id=" + this.goods_index + "&goods_count=" +
						this.goods_count
				})

			},

			change() {
				indexApi.add_collection({
					// token: uni.getStorageSync('token'),
					goods_id: this.obj.goods_info.goods_index
				}).then(res => {
					this.init()
				})
			},
			
			//保存图片
			getImg() {
				// uni.showModal({
				// 	content: '进到了getimg方法'
				// })
				console.log(this.share_goods)
				console.log(this.$imgUrl(this.share_goods))
				let this_ = this
				uni.getImageInfo({
					src: this.$imgUrl(this.share_goods),
					success: function(image) {
						// uni.showModal({
						// 	content: '进到了getImageInfo'
						// })
						console.log(image);
						let imgPath = image.path
						console.log(image.path);
			
						uni.saveImageToPhotosAlbum({
							filePath: imgPath,
							success: function() {
			
								console.log('save success');
							},
							fail: function(err) {
								uni.authorize({
									// scope: 'scope.userLocation',
									success() {
										//1.1 允许授权
										// console.log(error);
									},
									fail() {
										//1.2 拒绝授权
										uni.showModal({
											content: '检测到您没打开获取信息功能权限，是否去设置开？',
											confirmText: '确认',
											cancelText: '取消',
											success: res => {
												if (res.confirm) {
													uni.openSetting({
														success: res => {
															// console.log(res);
															self
																.getImg();
			
														}
													});
												} else {
													return false;
												}
											}
										});
										return false;
									}
								});
							}
						});
					}
			
				});
			
			},





		}
	}
</script>

<style lang="scss" scoped>
	.box {
		position: relative;
		padding-bottom: 100rpx;
		z-index: 0;

		.uni-scroll-view-content {
			height: auto;
		}

		.btn {
			width: 690rpx;
			height: 90rpx;
			background: #F87897;
			border-radius: 10rpx;
			display: flex;
			align-items: center;
			justify-content: center;
			// margin-top: 180rpx;
			// margin-bottom: 20rpx;
			// margin-left: 30rpx;
			position: fixed;
			left: 30rpx;
			bottom: 20rpx;

			.txt {
				color: #fff;
			}
		}

		.sku1 {
			width: 690rpx;
			margin-left: 30rpx;
			margin-right: 30rpx;

			.top {
				font-size: 26rpx;
				font-family: Source Han Sans CN;
				font-weight: 400;
				color: #333333;
				margin-bottom: 30rpx;

			}

			.list {
				display: flex;
				justify-content: flex-start;
				flex-wrap: wrap;



				.item {
					width: 164rpx;
					height: 54rpx;
					background: rgba(238, 238, 238, 0.2);
					border: 1rpx solid #CCCCCC;
					border-radius: 10rpx;
					margin-right: 20rpx;
					margin-bottom: 20rpx;

					.ttt {
						display: flex;
						align-items: center;
						justify-content: center;
						margin-top: 6rpx;
					}
				}

				.act {
					width: 164rpx;
					height: 54rpx;

					background: rgba(253, 99, 94, 0.2);

					border: 1px solid #FD635E;
					border-radius: 10rpx;
					margin-right: 20rpx;
					margin-bottom: 20rpx;

					.ttt {
						display: flex;
						align-items: center;
						justify-content: center;
						margin-top: 6rpx;
					}
				}
			}

		}

		.header44 {
			width: 690rpx;
			margin: 32rpx 30rpx 80rpx 30rpx;
			display: flex;
			justify-content: flex-start;

			.img {
				width: 300rpx;
				height: 169rpx;
				border-radius: 10rpx;
				margin-right: 30rpx;
			}

			.right {
				display: flex;
				justify-content: flex-start;

				.item1 {
					width: 320rpx;

					.item3 {
						display: flex;
						justify-content: flex-start;
						margin-top: 10rpx;

						.left {

							font-size: 26rpx;
							font-family: Source Han Sans CN;
							font-weight: 400;
							color: #FF1C1C;
							margin-top: 15rpx;
							margin-right: 10rpx;

						}

						.right {

							font-size: 40rpx;
							font-family: Source Han Sans CN;
							font-weight: 400;
							color: #FF1C1C;

						}
					}

					.item2 {
						display: flex;
						justify-content: flex-start;

						font-size: 26rpx;
						font-family: Source Han Sans CN;
						font-weight: 300;
						color: #333333;
						margin-top: 20rpx;

						.item4 {
							margin-right: 20rpx;

						}

						.item5 {}

					}

					.item6 {

						margin-top: 20rpx;
						font-size: 26rpx;
						font-family: Source Han Sans CN;
						font-weight: 300;
						color: #999999;
						line-height: 36rpx;
					}

				}

				.img2 {
					width: 32rpx;
					height: 32rpx;
				}
			}
		}

		.share {
			position: fixed;
			top: 0;
			left: 0;
			width: 750rpx;
			height: 100vh;
			background: rgba(0, 0, 0, 0.4);

			.share_center {
				position: absolute;
				bottom: 400rpx;
				left: 127rpx;
				width: 500rpx;
				height: 681rpx;
				z-index: 9999;
			}


			.center {
				position: absolute;
				background-color: #fff;
				bottom: 400rpx;
				left: 127rpx;
				width: 500rpx;
				height: 681rpx;
				background: #FFFFFF;
				border-radius: 10rpx;

				.item1 {

					width: 100%;
					height: 130rpx;
					display: flex;
					align-items: center;
					justify-content: center;

					.img {
						width: 60rpx;
						height: 60rpx;
						margin-right: 30rpx;
					}
				}

				.item2 {
					width: 100%;
					height: 281rpx;
				}

				.item3 {
					width: 100%;
					height: 265rpx;
					padding-top: 27rpx;
					padding-left: 22rpx;
					display: flex;
					justify-content: flex-start;

					.left {
						.left1 {
							width: 275rpx;
							// height: 55rpx;
							font-size: 24rpx;
							font-family: PingFang SC;
							font-weight: 500;
							color: #333333;
						}

						.left2 {
							width: 278rpx;
							font-size: 26rpx;
							font-family: Source Han Sans CN;
							font-weight: 300;
							color: #999999;
							margin-top: 20rpx;
							margin-bottom: 30rpx;

						}

						.left3 {
							width: 72rpx;

							font-size: 28rpx;
							font-family: PingFang SC;
							font-weight: bold;
							color: #FF1C1C;
						}
					}

					.right {
						.right1 {
							width: 160rpx;
							height: 160rpx;
						}

						.right2 {

							font-size: 22rpx;
							font-family: Source Han Sans CN;
							font-weight: 300;
							color: #999999;
						}
					}
				}
			}

			.footer2 {
				position: absolute;
				bottom: 11rpx;
				left: 10rpx;
				background-color: #fff;
				width: 730rpx;
				height: 300rpx;
				background: #FFFFFF;
				border-radius: 10rpx;

				.item2 {
					margin-top: 35rpx;
					width: 690rpx;
					height: 80rpx;
					border: 2rpx solid #EEEEEE;
					border-radius: 10rpx;
					margin-left: 30rpx;
					display: flex;
					align-items: center;
					justify-content: center;

					.txt {

						font-size: 36rpx;
						font-family: PingFang SC;
						font-weight: 400;
						color: #333333;
					}
				}

				.item {
					margin-top: 40rpx;
					width: 100%;
					height: 125rpx;
					display: flex;
					justify-content: space-around;
					position: relative;

					.left {
						position: relative;

						.img {
							width: 80rpx;
							height: 80rpx;
							margin-bottom: 18rpx;
							margin-left: 15rpx;
						}

						.fx {
							width: 80rpx;
							height: 80rpx;
							position: absolute;
							top: 0;
							left: 14rpx;
							opacity: 0
						}

						.text {

							font-size: 26rpx;
							font-family: PingFang SC;
							font-weight: 400;
							color: #333333;
						}
					}

					.right {
						.img {
							margin-left: 15rpx;
							width: 80rpx;
							height: 80rpx;
							margin-bottom: 18rpx;
						}

						.text {

							font-size: 26rpx;
							font-family: PingFang SC;
							font-weight: 400;
							color: #333333;
						}
					}
				}
			}
		}

		.dingwei {

			// position: relative;
			.xxx {
				display: flex;
				justify-content: center;
				align-items: center;

				text {
					margin-top: 10rpx;
				}
			}

		}

		.call {
			width: 100%;
			height: 69rpx;
			border-bottom: 2rpx solid #F5F5F5;
			display: flex;
			align-items: center;
			justify-content: center;

			text {

				font-size: 30rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: #333333;

			}
		}

		.call-c {
			width: 100%;
			height: 185rpx;
			border-bottom: 2rpx solid #F5F5F5;

			.item1 {
				height: 78rpx;
				width: 100%;
				display: flex;
				align-items: center;
				justify-content: flex-start;

				.name {
					margin-right: 15rpx;
					margin-left: 70rpx;
					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #333333;
				}

				.time {

					font-size: 22rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #999999;

				}
			}

			.item2 {
				height: 50rpx;
				width: 100%;
				display: flex;
				justify-content: flex-start;

				.txt1 {

					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #999999;
					margin-left: 71rpx;
					margin-right: 20rpx;

				}

				.txt2 {

					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 400;
					text-decoration: underline;
					color: #1E63B5;
					margin-right: 30rpx;

				}

				.img {
					width: 30rpx;
					height: 30rpx;
				}

			}
		}

		.footer {
			width: 750rpx;
			height: 100rpx;
			// background-color: yellow;
			position: fixed;
			bottom: 0;
			left: 0;
			display: flex;
			font-size: 20rpx;
			font-family: PingFang SC;
			font-weight: 400;
			color: #999999;
			justify-content: flex-start;

			.left {
				width: 310rpx;
				height: 100%;
				display: flex;
				align-items: center;
				background-color: #fff;
				justify-content: space-around;

				.item {}

				.img {
					width: 36rpx;
					height: 36rpx;
					margin-left: 3rpx;
				}
			}

			.right {
				width: 220rpx;
				color: #fff;
				height: 100%;
				display: flex;
				align-items: center;
				justify-content: center;
				background: linear-gradient(186deg, #595C60, #73787E);
			}

			.right1 {
				width: 220rpx;
				color: #fff;
				height: 100%;
				display: flex;
				align-items: center;
				justify-content: center;
				background: linear-gradient(0deg, #F87897, #F695AC);
			}

			.right2 {
				width: 440rpx;
				color: #fff;
				height: 100%;
				display: flex;
				align-items: center;
				justify-content: center;
				background: linear-gradient(0deg, #F87897, #F695AC);
			}
		}

		.openSku {
			height: 65rpx;
			width: 100%;
			display: flex;
			align-items: center;
			justify-content: center;

			font-size: 26rpx;
			font-family: PingFang SC;
			font-weight: 400;
			color: #333333;

			.img {
				width: 24rpx;
				height: 14rpx;
				margin-right: 10rpx;
			}

		}

		.sku {
			height: 89rpx;
			width: 100%;
			display: flex;
			align-items: center;
			justify-content: flex-start;
			font-size: 26rpx;
			font-family: PingFang SC;
			font-weight: 400;
			color: #333333;
			border-bottom: 2rpx solid #F5F5F5;

			.sku1 {
				margin-left: 28rpx;
				// margin-right: 150rpx;
				width: 200rpx;
			}
		}

		.navbar {
			height: 78rpx;
			width: 100%;
			border-bottom: 2rpx solid #F5F5F5;
			display: flex;
			align-items: center;
			justify-content: flex-start;

			font-size: 26rpx;
			font-family: PingFang SC;
			font-weight: 400;
			color: #333333;

			.left {
				width: 374rpx;
				display: flex;
				justify-content: center;
				border-right: 2rpx solid #EEEEEE;
			}

			.right {
				width: 374rpx;
				display: flex;
				justify-content: center;
			}

			.active {
				color: #FD4950;
			}
		}

		.uni-padding-wrap {
			height: 422rpx;

			.swiper {
				height: 422rpx;

				.img {
					width: 100%;
					height: 100%;
				}

				#theVideo {
					width: 100%;
					height: 100%;
				}
			}

		}

		.describe {
			height: 244rpx;
			width: 100%;

			.title {
				display: flex;
				align-items: center;
				justify-content: space-between;
				margin-top: 26rpx;
				margin-left: 30rpx;

				.left {
					width: 587rpx;
					// height: 64rpx;
					font-size: 30rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #333333;
					overflow: hidden;

					.text-type1 {
						// padding:  10rpx  10rpx;
						padding-left: 10rpx;
						padding-right: 10rpx;
						margin-right: 10rpx;
						background-color: #F87897;
						font-size: 22rpx;
						border-radius: 9rpx;
						color: #FFFFFF;
						height: 22rpx;
					}
				}

				.right {
					display: flex;
					align-items: center;
					width: 120rpx;
					height: 50rpx;
					background: #F5F5F5;
					border-radius: 25rpx 0rpx 0rpx 25rpx;

					// margin-right: 23rpx;
					.img {
						width: 28rpx;
						height: 28rpx;
						margin-left: 22rpx;
					}

					text {

						font-size: 24rpx;
						font-family: PingFang SC;
						font-weight: 400;
						color: #999999;
					}

				}
			}

			.des {
				margin-right: 15rpx;
				margin-left: 30rpx;
				margin-top: 20rpx;
				font-size: 26rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #999999;

			}

			.num {
				width: 690rpx;
				height: 30rpx;
				margin: 0 30rpx;
				margin-top: 50rpx;
				display: flex;
				align-items: center;
				justify-content: space-between;

				.left {
					display: flex;
					align-items: center;
					justify-content: flex-start;

					.l1 {
						margin-right: 15rpx;

						font-size: 36rpx;
						font-family: PingFang SC;
						font-weight: 500;
						color: #FF1C1C;

					}

					.l2 {

						font-size: 30rpx;
						font-family: PingFang SC;
						font-weight: 400;
						text-decoration: line-through;
						color: #999999;

					}
				}

				.right {

					font-size: 30rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #999999;

				}
			}
		}

		.line {
			width: 750rpx;
			height: 20rpx;
			background: #F5F5F5;
		}

		.spec {
			width: 690rpx;
			display: flex;
			align-items: center;
			justify-content: space-between;
			margin: 0 30rpx;
			height: 90rpx;

			.left {
				display: flex;
				align-items: center;
				justify-content: flex-start;

				.l1 {
					margin-right: 20rpx;

					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #333333;

				}

				.l2 {

					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #999999;

				}
			}

			.right {
				color: #999999;
			}
		}

		.content {
			width: 750rpx;
			// height: 790rpx;
			// background-color: yellow;
			padding: 20rpx 30rpx 20rpx;

			.title {
				display: flex;
				align-items: center;
				justify-content: space-between;
				margin-bottom: 20rpx;

				.left {

					font-size: 30rpx;
					font-family: PingFang SC;
					font-weight: 500;
					color: #333333;

				}

				.right {

					font-size: 30rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #999999;

				}
			}

			.item {
				position: relative;
				width: 689rpx;
				height: 200rpx;
				background: #FFFFFF;
				box-shadow: 0rpx 1rpx 10rpx 0rpx rgba(0, 0, 0, 0.07);
				border-radius: 10rpx;
				margin-bottom: 20rpx;
				padding: 14rpx 10rpx 18rpx;
				display: flex;
				// align-items: center;
				justify-content: flex-start;

				.ding {
					width: 56rpx;
					height: 24rpx;
					// border-radius: 10rpx 0px 10rpx 0px;
					position: absolute;
					bottom: 19rpx;
					left: 255rpx;

				}

				.img {
					width: 300rpx;
					height: 168rpx;
					border-radius: 10px;
				}

				.item-r {
					width: 328rpx;
					margin-left: 20rpx;

					.name {
						// white-space: nowrap;
						// overflow: hidden;
						// text-overflow: ellipsis;
						height: 87rpx;
						font-size: 30rpx;
						font-family: PingFang SC;
						font-weight: 500;
						color: #222222;
						display: -webkit-box;
						-webkit-box-orient: vertical;
						-webkit-line-clamp: 2;
						overflow: hidden;
						margin-bottom: 50rpx;
						// display: -webkit-box;
						// -webkit-line-clamp: 2;
						// -webkit-box-orient: vertical;
						// overflow: hidden;
						// text-overflow: ellipsis
					}

					.bottom {
						display: flex;
						align-items: center;
						justify-content: space-between;

						.left {

							font-size: 22rpx;
							font-family: PingFang SC;
							font-weight: 400;
							color: #666666;

						}

						.right {
							display: flex;
							align-items: center;
							justify-content: flex-start;

							font-size: 22rpx;
							font-family: PingFang SC;
							font-weight: 400;
							color: #666666;

							.img {
								width: 26rpx;
								height: 26rpx;
								margin-right: 10rpx;
							}
						}
					}
				}
			}

			.more1 {
				width: 142rpx;

				font-size: 26rpx;
				font-family: Source Han Sans CN;
				font-weight: 300;
				color: #999999;
				margin: 0 auto;
			}
		}

		.talk {
			// height: 360rpx;
			width: 100%;
			padding-left: 30rpx;
			padding-right: 30rpx;

			.title {
				margin-top: 29rpx;
				font-size: 30rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: #333333;
			}

			.content1 {
				margin-top: 40rpx;
				display: flex;
				justify-content: space-between;
				width: 100%;
				// height: 100%;

				.img {
					width: 60rpx;
					height: 60rpx;
					margin-right: 15rpx;
					border-radius: 50%;
				}

				.item-c {
					// height: 260rpx;
					// width: 430rpx;
					margin-right: 40rpx;

					.zz {
						font-size: 26rpx;
						font-family: PingFang SC;
						font-weight: 500;
						color: #333333;

						text {
							margin-right: 15rpx;
						}
					}

					.tt {

						font-size: 26rpx;
						font-family: PingFang SC;
						font-weight: 400;
						color: #333333;
						margin-left: 8rpx;
						margin-top: 25rpx;
					}




				}

				.time {
					font-size: 24rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #999999;
					line-height: 100%;

				}


			}
		}
	}

	.gray {
		margin-top: 10rpx;
		margin-left: 8rpx;
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #999999;
	}

	.more {
		margin-top: 50rpx;
		width: 100%;
		height: 70rpx;
		border-top: 2rpx solid #F5F5F5;
		display: flex;
		align-items: center;
		justify-content: center;

		.more-c {

			font-size: 26rpx;
			font-family: Source Han Sans CN;
			font-weight: 300;
			color: #999999;

		}
	}

	.imgss {
		margin-top: 20rpx;
		display: flex;
		justify-content: flex-start;
		margin-left: 113rpx;

		.img {
			width: 130rpx;
			height: 130rpx;
			margin-right: 20rpx;
		}
	}

	.dddd {
		display: flex;
		justify-content: flex-start;
		align-items: center;
		border-top: 2rpx solid #F5F5F5;
		border-bottom: 2rpx solid #F5F5F5;
		height: 87rpx;

		.text {

			font-size: 30rpx;
			font-family: PingFang SC;
			font-weight: 500;
			color: #333333;
		}
	}
</style>
