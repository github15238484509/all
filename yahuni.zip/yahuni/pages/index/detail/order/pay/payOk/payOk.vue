<template>
	<view class="box">
		<view class="header">
			<image src="../../../../../../static/ok1.png" class="img"></image>
		</view>
		<view class="text1">
			支付成功
		</view>
		<view class="text2">
			<text>支付金额：</text><text class="tt">{{$returnFloat(order_supplier_coupon)}}元</text>
		</view>
		<view class="text3">
			{{remarks}}
		</view>
		<view class="look" @click="look">
			<text>查看订单</text>
		</view>
		<view class="back" @click="back">
			<text>返回首页</text>
		</view>
		<!-- <image src="../../../../../../static/index/background.png" class="banner"></image> -->
	</view>
</template>

<script>
	export default {
		data() {
			return {
				order_supplier_coupon: "",
				remarks: "",
				order_id: ""
			};
		},
		onLoad(el) {
			// console.log(el)
			this.order_supplier_coupon = el.order_supplier_coupon
			this.remarks = el.remarks
			this.order_id = el.order_id
		},
		onShareAppMessage: function(options) {
			return {
				title: '源爱汇',
				path: '/page/index/index',
				success: function(res) {
					// 转发成功
				},
				fail: function(res) {
					// 转发失败
				}		
			}		
		},
		methods: {
			look() {
				uni.setStorageSync("current", '2')
				uni.reLaunch({
					url: "../../../../../myCourse/myCourse"
				});
			},
			back() {
				uni.switchTab({
					url: "../../../../index"
				})
			}

		}
	}
</script>

<style lang="scss">
	.box {
		.header {
			width: 100%;
			height: 330rpx;
			border-top: 2rpx solid #F5F5F5;
			display: flex;
			justify-content: center;
			align-items: flex-end;

			.img {
				width: 146rpx;
				height: 180rpx;
			}
		}

		.text1 {
			width: 100%;
			height: 34rpx;
			font-size: 36rpx;
			font-family: PingFang SC;
			font-weight: 500;
			color: #333333;
			text-align: center;
			margin-top: 45rpx;
			margin-bottom: 30rpx;
		}

		.text2 {
			width: 100%;
			height: 29rpx;
			font-size: 30rpx;
			font-family: PingFang SC;
			font-weight: 400;
			color: #999999;
			text-align: center;
			margin-bottom: 33rpx;

			text {
				margin-right: 13rpx;
			}

			.tt {
				font-size: 30rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: #333333;
			}
		}

		.text3 {
			width: 100%;
			height: 26rpx;
			font-size: 26rpx;
			font-family: PingFang SC;
			font-weight: 400;
			color: #999999;
			text-align: center;
			margin-bottom: 60rpx;
		}

		.look {
			margin-left: 30rpx;
			width: 690rpx;
			height: 90rpx;
			background: #FFFFFF;

			border: 1px solid #F87897;
			border-radius: 10rpx;
			display: flex;
			align-items: center;
			justify-content: center;
			margin-bottom: 30rpx;

			text {
				font-size: 30rpx;
				font-family: PingFang SC;
				font-weight: 500;

				color: #F87897;
			}
		}

		.back {
			margin-left: 30rpx;
			width: 690rpx;
			height: 90rpx;

			background: #F87897;
			// border: 2rpx solid #3E5061;
			border-radius: 10rpx;
			display: flex;
			align-items: center;
			justify-content: center;

			text {
				font-size: 30rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: #FFFFFF;
			}
		}

		.banner {
			width: 750rpx;
			height: 400rpx;
		}
	}
</style>
