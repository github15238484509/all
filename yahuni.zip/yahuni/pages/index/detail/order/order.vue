<template>
	<view class="box">
		<view class="list-t">
			<image src="../../../../static/index/place.png" class="img"></image>
			<view class="list2" @click="toAddress">
				<view class="card" v-if="userAddress.address">
					<view class="top">
						<view class="top-l">
							{{userAddress.contacts?userAddress.contacts:""}}
						</view>
						<view class="top-r">
							{{userAddress.phone?userAddress.phone:""}}
						</view>
					</view>
					<view class="bottom">
						 {{userAddress.province_name+userAddress.city_name+userAddress.county_name+userAddress.address}}
					</view>
				</view>
				<view class="card1" v-if="!userAddress.address">
					<view class="card-t">
						请选择收货地址
					</view>
					<view class="card-b">
						您还没有设置收货地址，请点击这里设置！
					</view>
				</view>
				<image src="../../../../static/right.png" class="img"></image>
			</view>

		</view>
		<view class="list">
			<view class="list-t">
				<image :src="$imgUrl(obj.goods_icon)" class="img" ></image>
				<view class="list-r">
					<view class="text-1">
						<text class="text-type1">
							{{obj.zone_name?obj.zone_name:""}}
						</text>

						<text>
							{{obj.goods_name?obj.goods_name:""}}
						</text>

					</view>
					<view class="text-2">
						{{obj.goods_describe?obj.goods_describe:""}}
					</view>
					<view class="text-bg" v-if="skus">
						<view class="text-4">
							{{skus?skus:""}}
						</view>
					</view>
					<view class="text-3" v-if="skus">
						<view class="">
							￥{{obj.goods_cost?$returnFloat(obj.goods_cost):""}}
						</view>
						<view class="num">
							x{{goods_count?goods_count:""}}
						</view>
					</view>
					<view class="text-5" v-if="!skus">
						￥{{obj.goods_cost?$returnFloat(obj.goods_cost):""}}
					</view>


				</view>
			</view>
			<view class="list-b">
				<textarea @blur="bindTextAreaBlur" class="textarea" v-model="order_remark" placeholder="给商家留言（选填）" />
			</view>
		</view>
		<view class="money">
			<view class="money-c" style="margin-top: 20rpx;margin-bottom: 30rpx;">
				<view class="left">
					商品总价
				</view>
				<view class="right">
					￥{{goods_price?$returnFloat(goods_price):""}}
				</view>
			</view>
			<view class="money-c" style="margin-bottom: 30rpx;">
				<view class="left">
					运费
				</view>
				<view class="right">
					￥{{$returnFloat(freight)}}
				</view>
			</view>
			<view class="money-c">
				<view class="left1">
					订单金额
				</view>
				<view class="right1">
					￥{{total_price?$returnFloat(total_price):""}}
				</view>
			</view>

		</view>

		<view class="btn" @click="next">
			<text>提交订单</text>
		</view>
	</view>
</template>

<script>
	import orderApi from "../../../../api/index/orderDetail/orderDetail.js"
	export default {
		data() {
			return {
				//规格id
				skuIndex: "",
				//课程id
				id: "",
				obj: {},
				inputValue: '',
				item: {},
				skus: "",
				goods_count: "",
				userAddress: {},
				goods_price: "",
				freight: "",
				total_price: "",
				editAddress: {},
				address_id: "",
				order_remark: ""
			};
		},
		onLoad(el) {
			console.log(el)
			if (!uni.getStorageSync("address")) {
				this.skuIndex = el.index
				this.id = el.id
				this.goods_count = el.goods_count
			}



		},
		onShareAppMessage: function(options) {
			return {
				title: '源爱汇',
				path: '/page/index/index',
				success: function(res) {
					// 转发成功
				},
				fail: function(res) {
					// 转发失败
				}		
			}		
		},
		onShow() {
			this.init()
		},
		methods: {
			init() {
				if (uni.getStorageSync("address")) {
					let obj = JSON.parse(uni.getStorageSync("address"))
					console.log(obj);
					this.skuIndex = obj.skuIndex
					this.id = obj.id
					this.goods_count = obj.goods_count
					this.address_id = obj.address_id
					orderApi.confirm_order({
						goods_index: this.id,
						sku_index: this.skuIndex,
						goods_count: this.goods_count,
						address_id: this.address_id
					}).then(res => {
						console.log(res)
						this.obj = res.result.goodsInfo
						console.log(this.obj)
						this.skus = res.result.goodsInfo.skuInfos
						this.userAddress = res.result.userAddress
						this.goods_price = res.result.goods_price
						this.freight = res.result.freight
						this.total_price = res.result.total_price
					})
				} else {

					orderApi.confirm_order({
						goods_index: this.id,
						sku_index: this.skuIndex,
						goods_count: this.goods_count
					}).then(res => {
						console.log(res)
						this.obj = res.result.goodsInfo
						console.log(this.obj)
						this.skus = res.result.goodsInfo.skuInfos
						this.userAddress = res.result.userAddress
						this.address_id = res.result.userAddress.index
						this.goods_price = res.result.goods_price
						this.freight = res.result.freight
						this.total_price = res.result.total_price
					})
				}
			},
			next() {
				if (!this.address_id) {
					uni.showToast({
						icon: "none",
						title: "请选择地址"
					})
				} else {
					orderApi.establish_order({
						// token:'12114411462052158',
						address_id: this.address_id,
						goods_id: this.id,
						sku_index: this.skuIndex,
						goods_count: this.goods_count,
						order_remark: this.order_remark
					}).then(res => {
						if (res.status == 200) {
							// console.log(res);
							this.item = res.result
							uni.navigateTo({
								url: "./pay/pay?item=" + encodeURIComponent(JSON.stringify(this.item))
							})
						} else {
							uni.showToast({
								title: res.message,
								icon: "none"
							})
						}

					})
				}



			},

			toAddress() {
				this.editAddress.skuIndex = this.skuIndex
				this.editAddress.id = this.id
				this.editAddress.goods_count = this.goods_count
				uni.removeStorageSync('address');
				uni.navigateTo({
					url: "../../../my/address/address?editAddress=" + encodeURIComponent(JSON.stringify(this
						.editAddress))
				})
			}
		}
	}
</script>
<style>
	page {
		height: 100%;
		background-color: #F5F5F5;
	}
</style>
<style lang="scss">
	.box {
		position: relative;
		height: 100%;

		.news {
			width: 750rpx;
			height: 340rpx;
			background: #FFFFFF;
			overflow: hidden;

			.title {

				font-size: 30rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: #333333;
				margin-top: 40rpx;
				margin-left: 30rpx;
				margin-bottom: 30rpx;
			}

			.content {
				width: 690rpx;
				height: 90rpx;
				background: #F5F5F5;
				border-radius: 10rpx;
				margin-left: 30rpx;
				display: flex;
				align-items: center;
				justify-content: flex-start;
				margin-bottom: 20rpx;

				.left {
					margin-left: 20rpx;
					font-size: 28rpx;
					font-family: PingFang SC;
					font-weight: 500;
					color: #333333;
				}
			}

			.user {
				display: flex;
				justify-content: flex-start;
				width: 100%;
				height: 80rpx;

				.img {
					width: 80rpx;
					height: 80rpx;
					// background: #8CCAFF;
					border-radius: 50%;
					margin-left: 77rpx;
					margin-right: 20rpx;
				}

				.right {

					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #999999;

					.top {
						margin-bottom: 18rpx;
					}
				}
			}

			.text {
				display: flex;
				justify-content: center;
				margin-top: 50rpx;
			}
		}

		.btn {
			width: 690rpx;
			height: 90rpx;
			background: #F66F90;
			border-radius: 20rpx;
			position: absolute;
			left: 30rpx;
			bottom: 50rpx;
			display: flex;
			align-items: center;
			justify-content: center;

			text {

				font-size: 36rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: #FFFFFF;
			}
		}

		.money {
			width: 750rpx;
			height: 220rpx;
			background: #FFFFFF;
			overflow: hidden;
			margin-bottom: 20rpx;

			.money-c {
				display: flex;
				align-items: center;
				justify-content: space-between;

				.left1 {
					font-size: 30rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #333333;
					margin-left: 30rpx;

				}

				.right1 {
					font-size: 30rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #FF1C1C;
					margin-right: 30rpx;
				}

				.left {
					margin-left: 30rpx;
					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #999999;
				}

				.right {

					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #999999;
					margin-right: 30rpx;
				}
			}

		}

		.list-t {
			width: 750rpx;
			height: 200rpx;
			background-color: #fff;


			margin-top: 20rpx;
			display: flex;
			justify-content: flex-start;
			align-items: center;
			margin-bottom: 20rpx;

			.img {
				width: 64rpx;
				height: 64rpx;
				margin-left: 30rpx;
				margin-right: 30rpx;
				
			}

			.list2 {
				display: flex;
				justify-content: flex-start;
				align-items: center;

				.img {
					width: 17rpx;
					height: 32rpx;
				}

				.card1 {
					width: 495rpx;
					margin-right: 40rpx;

					.card-t {
						margin-bottom: 20rpx;
						font-size: 36rpx;
						font-family: PingFang SC;
						font-weight: 500;
						color: #333333;
					}

					.card-b {

						font-size: 26rpx;
						font-family: PingFang SC;
						font-weight: 400;
						color: #999999;
					}
				}

				.card {
					width: 470rpx;
					margin-right: 70rpx;

					.top {
						display: flex;
						justify-content: flex-start;
						margin-bottom: 24rpx;

						.top-l {

							font-size: 28rpx;
							font-family: PingFang SC;
							font-weight: 500;
							color: #333333;
							margin-right: 20rpx;

						}

						.top-r {

							font-size: 24rpx;
							font-family: PingFang SC;
							font-weight: 400;
							color: #999999;

						}
					}

					.bottom {
						width: 100%;

						font-size: 26rpx;
						font-family: PingFang SC;
						font-weight: 400;
						color: #333333;
					}
				}
			}
		}

		.list {
			width: 750rpx;
			// height: 210rpx;
			background-color: #fff;
			padding: 20rpx 30rpx;
			border-top: 2rpx solid #F5F5F5;
			border-bottom: 2rpx solid #F5F5F5;
			margin-top: 23rpx;

			margin-bottom: 20rpx;

			.textarea {
				width: 690rpx;
				height: 136rpx;
				background: #F5F5F5;
				border-radius: 10rpx;
				padding: 20rpx;
			}

			.list-t {
				display: flex;
				justify-content: flex-start;

				.img {
					width: 300rpx;
					height: 170rpx;
					border-radius: 10rpx;
					margin-right: 20rpx;
				}

				.list-r {
					width: 360rpx;

					// background-color: red;
					.text-1 {
						overflow: hidden;
						white-space: nowrap;
						text-overflow: ellipsis;
						// height: 31rpx;
						font-size: 32rpx;
						font-family: Source Han Sans CN;
						font-weight: 400;
						color: #333333;

						// line-height: 36px;
						.text-type1 {
							// padding:  10rpx  10rpx;
							padding-left: 10rpx;
							padding-right: 10rpx;
							margin-right: 10rpx;
							background-color: #F87897;
							font-size: 22rpx;
							border-radius: 9rpx;
							color: #FFFFFF;
							height: 22rpx;
						}
					}

					.text-2 {
						// width: 284px;
						// height: 25rpx;
						overflow: hidden;
						white-space: nowrap;
						text-overflow: ellipsis;
						font-size: 26rpx;
						font-family: Source Han Sans CN;
						font-weight: 300;
						color: #999999;
						// line-height: 36px;
						margin-top: 5rpx;
						// margin-bottom: 47rpx;
					}

					.text-5 {
						font-size: 30rpx;
						font-family: Source Han Sans CN;
						font-weight: 400;
						color: #FF1C1C;
						// margin-bottom: 10rpx;
						opacity: 1;
						// position: absolute;
						width: 130rpx;
						// height: 76rpx;
						margin-top: 55rpx;
					}

					.text-3 {
						// width: 90px;
						// height: 24rpx;
						font-size: 30rpx;
						font-family: Source Han Sans CN;
						font-weight: 400;
						color: #FF1C1C;
						// margin-bottom: 10rpx;
						opacity: 1;
						// position: absolute;
						width: 130rpx;
						// height: 76rpx;
						// left: 345rpx;
						// top: 160rpx;
						display: flex;
						justify-content: start;
						// margin-top: 13rpx;

						.num {
							margin-left: 20rpx;
							font-size: 30rpx;
							font-family: PingFang SC;
							font-weight: 500;
							color: #CCCCCC;
						}
					}

					.text-4 {
						// width: 284px;
						height: 38rpx;
						font-size: 26rpx;
						font-family: Source Han Sans CN;
						font-weight: 300;
						color: #999999;
						// line-height: 38px;
						// margin-left: 12rpx;
						margin-right: 12rpx;
					}

					.text-bg {
						// width: 284px;
						display: inline-block;
						height: 38rpx;
						font-size: 26rpx;
						font-family: Source Han Sans CN;
						font-weight: 300;
						margin-top: 10rpx;
						// margin-bottom: 47rpx;
						background-color: #F5F5F5;
					}
				}
			}
		}
	}
</style>
