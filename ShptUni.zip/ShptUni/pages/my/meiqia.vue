<template>
	<view>
		<web-view src="https://test.jianyunkeji.net/Shpt/meiqia/#/pages/server/server"></web-view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style>

</style>
