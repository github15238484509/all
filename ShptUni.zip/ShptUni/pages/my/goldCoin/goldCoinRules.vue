<template>
    <web-view :src="src"></web-view>
</template>
<script>
    export default {
        data() {
            return {
                src: ''
            }
        },
        onLoad(e) {
            console.log(e)
            if (e.type == '5') {

                uni.setNavigationBarTitle({
                    title: '金币说明'
                })
            } else if (e.type == '6') {
                uni.setNavigationBarTitle({
                    title: '鸿运勋章说明'
                })
            }

            this.request({
                url: 'ShptUapi/public/index.php/UserConsumers/getAgreement',
                data: {
                    type: e.type
                }
            }).then(res => {
                console.log(res);
                var datas = res.data.data
                // for (var i = 0; i < datas.length; i++) {
                //     var dict = datas[i]
                //     if (dict.agreement_type == 5 && e.type == 5) {
                //         this.src = this.$cdnUrl + dict.agreement_content;

                //         console.log(this.src);
                //         // return
                //     } else if (dict.agreement_type == 6 && e.type == 6) {
                //         this.src = this.$cdnUrl + dict.agreement_content;

                //         console.log(this.src);
                //         // return
                //     }
                // }

                if ( e.type == 5) {
                    this.src = this.$cdnUrl + datas.agreement_content;

                    console.log(this.src);
                    // return
                } else if ( e.type == 6) {
                    this.src = this.$cdnUrl + datas.agreement_content;

                    console.log(this.src);
                    // return
                }

            })
        }
    }
</script>

<style>
</style>
