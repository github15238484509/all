<template>
	<view style="text-align: center;padding-top: 400rpx;">
		<img :src="$cdnUrl+'/ShptUapi/static/budilding.png'" alt="" style='height: 410rpx;width: 475rpx;'>
		<view style="color:#999999;font-size: 30rpx;position: relative;">正在建设中</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
			}
		},
		methods: {
		}
	}
</script>

<style>

</style>
