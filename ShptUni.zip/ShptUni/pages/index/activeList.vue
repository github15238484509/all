<template>
	<view class="active" >
			<image src="../../static/activeHeadimg.png" mode="" style="width: 100%;height: 262rpx;"></image>
		<view v-if='activeList.list.length>0' style="padding: 0 30rpx;">
			<view v-for="(item,i) in activeList.list" :key="i" class="concent" @click="goGroupGoods(item)" >
				<view style="margin: 0 22rpx;">
					<image style="width: 159rpx;height: 159rpx" :src="$cdnUrl+item.goods_icon" mode=""></image>
				</view>
				<view style="display: flex;height: 150rpx;flex-direction:column;justify-content: space-between;">
					<view style="display: flex;align-items: center;">
						<view class="font-24" :class="item.status>1?'title1':'title'">{{item.status>1?'拼购':'未开始'}}</view>
						<view class="name">{{item.goods_name}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;padding-right: 20rpx">
						<view>
							<view style="color: #FF3F3F;">￥{{item.group_price/100}}</view>
							<view style="color: #999999;font-size: 24rpx;text-decoration: line-through;">￥{{item.goods_cost/100}}</view>
						</view>
						<view :class="item.status==0||item.status==2?'btn':'btn1'" @click.stop="groupBtn(item)">{{item.status==0?'预定轻松拼团':item.status==1?'已预订(点击可关闭)':item.status==2?'去抢购':item.status==3?'轻松拼团中':'参与中'}}</view>
					</view>
				</view>
			</view>
		</view>
		<view v-else style="text-align: center;padding-top: 300rpx;">
			<image src="../../static/nodata1.png" mode="" style="width: 480rpx;height: 360rpx;"></image>
			<view style="color: #999999;">该地区拼购促销活动已结束，请敬请期待新的活动</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				page:1,//默认页数
				activeList:{
					list:[]
				},//活动列表数据
			}
		},
		onShow(){
			this.page=1;
			this.activeList={
				list:[]
			};
			this.init();
		},
		onReachBottom(){
			if(this.page<this.activeList.total_page){
				this.page++;
				this.init()
			}
		},
		methods: {
			// 跳转至拼购商品详情
			goGroupGoods(e){
				uni.navigateTo({
					url:"../shop/groupGoodsDetail?id="+e.goods_index+'&group_id='+e.group_goods_index
				})
			},
			// 点击按钮事件
			groupBtn(e){
				e.status==3||e.status==2?uni.navigateTo({
					url:'../shop/groupGoodsDetail?id='+e.goods_index+'&group_id='+e.group_goods_index
				}): this.changeGroupStatus(e)
			},
			// 改变拼购状态
			changeGroupStatus(e){
				let self = this;
				self.request({
					url:'ShptUapi/public/index.php/goods/join_group_work',
					data:{
						group_goods_index:e.group_goods_index,
						type:e.status,
					}
				}).then(res => {
				if (res.data.success) {
					uni.showToast({
						title:res.data.msg,
						icon:'none'
					});
					self.activeList={list:[]};
					self.page=1;
					self.init();
					} else {
						uni.showToast({
						title: res.data.msg,
						icon: 'none'
						})
					}
				})
			},
			// 获取拼购列表数据
			init(){
				let self = this;
				self.request({
					url:'ShptUapi/public/index.php/goods/getLimit',
					data:{
						page:self.page,
						count:10
					}
				}).then(res => {
                    console.log(res)
				if (res.data.success) {
					// 判断是否有数据，有数据拼接数组，没有数据直接赋值
						self.activeList.list>0?self.activeList.list=[...self.activeList.list,...res.data.data.list]:self.activeList=res.data.data
					} else {
						uni.showToast({
						title: res.data.msg,
						icon: 'none'
						})
					}
				})
			},
		}
	}
</script>

<style lang="scss" scoped>
	.font-24{
		text-align: center;
		line-height: 30rpx;
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #FFFFFF;
	}
	.active{
		min-height: 460rpx;
		background-repeat: no-repeat;
		background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAu4AAAHMCAYAAACKkS1qAABVqElEQVR42u29i5dc2XrQ139G1srKSgJJIBAgCVgzraoeOzYPg415xbzM28bgC8ZgbGJi4oeqTlV33UtIFjgJiQmQ2HfgwlyF6HK5xoR3CHmMRlJGsMDcJLhH0Vjdjkg0aNTWHXXOKVVJp3bt77XPqepqza/X+rlO7bMf33t/0+6Zu3f+Dd9wDgAAAAAAu80eRgAAAAAAoHEHAAAAAAAadwAAAAAAGncAAAAAAKBxBwAAAAAAGncAAAAAABp3AAAAAACgcQcAAAAAABp3AAAAAIDL17j/pvoBAAAAAAB2Ghp3AAAAAAAadwAAAAAA6Klx/43nAAAAAACw29C4AwAAAADQuAMAAAAAAI07AAAAAACNOwAAAAAA0LgDAAAAAACNOwAAAAAAjTsAAAAAANC4AwAAAAAAjTsAAAAAAI07AAAAAADQuAMAAAAA0LgDAAAAAMCuNu6/uX4AAAAAAICdhsYdAAAAAIDGHQAAAAAAaNwBAAAAAGjcAQAAAACAxh0AAAAAAGjcAQAAAABo3AEAAAAAYNuN+284BwAAAACA3YbGHQAAAACAxh0AAAAAAGjcAQAAAABo3AEAAAAAgMYdAAAAAABo3AEAAAAAXq3G/bfUDwAAAAAAsNPQuAMAAAAA0LgDAAAAAACNOwAAAAAAjTsAAAAAANC4AwAAAAAAjTsAAAAAAI07AAAAAADQuAMAAAAAAI07AAAAAACNOwAAAAAA0LgDAAAAAHxcG/dffw4AAAAAALvN3vlvrR8AAAAAAGCnoXEHAAAAAKBxBwAAAAAAGncAAAAAABp3AAAAAACgcQcAAAAAABp3AAAAAAAadwAAAAAAoHEHAAAAAAAadwAAAAAAGncAAAAAAKBxBwAAAAD4mDbuv61+AAAAAACAnYbGHQAAAACAxh0AAAAAAHpq3H/dOQAAAAAA7DY07gAAAAAANO4AAAAAAEDjDgAAAABA4w4AAAAAADTuAAAAAABA4w4AAAAAQOMOAAAAAABbbtx/e/0AAAAAAAA7DY07AAAAAACNOwAAAAAA0LgDAAAAANC4AwAAAAAAjTsAAAAAANC4AwAAAAC8Yo37rz0HAAAAAIDdhsYdAAAAAIDGHQAAAAAA+mncf0f9AAAAAAAAOw2NOwAAAAAAjTsAAAAAANC4AwAAAADQuAMAAAAAAI07AAAAAADQuAMAAAAA0LgDAAAAAACNOwAAAAAA0LgDAAAAANC4AwAAAADAJhr3b/z6cwAAAAAA2G1o3AEAAAAAaNwBAAAAAIDGHQAAAACAxh0AAAAAAGjcAQAAAACAxh0AAAAAgMYdAAAAAABo3AEAAAAAIG3cv6l+AAAAAACAnYbGHQAAAACAxh0AAAAAAGjcAQAAAABo3AEAAAAAYIca93//HAAAAAAAdhsadwAAAAAAGncAAAAAAKBxBwAAAACgcQcAAAAAgN1p3H9n/QAAAAAAADsNjTsAAAAAAI07AAAAAADQuAMAAAAA0LgDAAAAAACNOwAAAAAA0LgDAAAAANC4AwAAAADAthv3X3MOAAAAAAC7zd75N9cPAAAAAACw09C4AwAAAADQuAMAAAAAAI07AAAAAACNOwAAAAAA0LgDAAAAAACNOwAAAAAAjTsAAAAAANC4AwAAAABA2rj/rvoBAAAAAAB2Ghp3AAAAAIDL0bj/6nMAAAAAANhtaNwBAAAAAGjcAQAAAACAxh0AAAAAgMYdAAAAAABo3AEAAAAAgMYdAAAAAODVatx/d/0AAAAAAAA7DY07AAAAAACNOwAAAAAA0LgDAAAAANC4AwAAAADADjXuv+ocAAAAAAB2Gxp3AAAAAAAadwAAAAAAoHEHAAAAAPjYNO7fUj8AAAAAAMBOQ+MOAAAAAEDjDgAAAAAANO4AAAAAADTuAAAAAABA4w4AAAAAADTuAAAAAAA07gAAAAAAsOXG/RO/8hwAAAAAAHYbGncAAAAAABp3AAAAAACgcQcAAAAAoHEHAAAAAAAadwAAAAAAoHEHAAAAAKBxBwAAAAAAGncAAAAAAEgb999TPwAAAAAAwE5D4w4AAAAAQOMOAAAAAAA9Ne6/4hwAAAAAAHYbGncAAAAAABp3AAAAAACgcQcAAAAAoHEHAAAAAIDdadx/b/0AAAAAAAA7DY07AAAAAACNOwAAAAAA0LgDAAAAANC4AwAAAAAAjTsAAAAAAEQa9687BwAAAACA3YbGHQAAAADgUjTu31o/AAAAAADATkPjDgAAAABA4w4AAAAAADTuAAAAAAA07gAAAAAAQOMOAAAAAAA07gAAAAAANO4AAAAAALDlxv331Q8AAAAAALDT0LgDAAAAAFyOxv2XnwMAAAAAwG5D4w4AAAAAQOMOAAAAAAA07gAAAAAANO4AAAAAAEDjDgAAAAAAgcb92+oHAAAAAADYaWjcAQAAAABo3AEAAAAAgMYdAAAAAIDGHQAAAAAAdqhx/9pzAAAAAADYbWjcAQAAAABo3AEAAAAAoJ/G/ffXDwAAAAAAsNPQuAMAAAAA0LgDAAAAAACNOwAAAAAAjTsAAAAAANC4AwAAAAAAjTsAAAAAAI07AAAAAABsuXH/A19zDgAAAAAAuw2NOwAAAAAAjTsAAAAAANC4AwAAAADQuAMAAAAAAI07AAAAAADQuAMAAAAA0LgDAAAAAMCWG/dvrx8AAAAAAGCnoXEHAAAAAKBxBwAAAACAnhr3X3YOAAAAAAC7DY07AAAAAACNOwAAAAAA0LgDAAAAANC4AwAAAADA7jTuf7B+AAAAAACAnYbGHQAAAACAxh0AAAAAAGjcAQAAAABo3AEAAAAAgMYdAAAAAAAijfsvPQcAAAAAgN2Gxh0AAAAA4FI07t9RPwAAAAAAwE5D4w4AAAAAQOMOAAAAAAA07gAAAAAANO4AAAAAAEDjDgAAAAAANO4AAAAAADTuAAAAAACw5cb9O+uHbjxLPneVZwVznm1RhmcXpPezDvbp0/bbtovn3BLbPDPePQvo+GwH7HCRsbnL9eLZJdL5WSDOL0s9v+gY7LtePtvxONnE/puqb896rPvPLlnduojY3eSZzy7IJs+c8flsi33Ii/Pqxv2rny04X/Bsy1zEmc960vt8C7qeb9H25x1lOn9FYuX8FdRp12XoS8bzV1D3yxwL5z28k+rUebCOnTvvgPNLZv/zLfj23GH3yD7nPcm0a3fVZa4/5xuQ73wH5Dt/1er9HhcVAAAAAACNOwAAAAAA0LgDAAAAANC4AwAAAAAAjTsAAAAAANC4AwAAAAC8Uo37H6ofAAAAAABgp6FxBwAAAACgcQcAAAAAABp3AAAAAICPT+P+S54BAAAAAMBuQ+MOAAAAAEDjDgAAAAAANO4AAAAAAB+bxv0/qB8AAAAAAGCnoXEHAAAAAKBxBwAAAAAAGncAAAAAABp3AAAAAACgcQcAAAAAABp3AAAAAAAadwAAAAAA2Hbj/oufAQAAAADAbrN3/l31AwAAAAAA7DQ07gAAAAAANO4AAAAAAEDjDgAAAABA4w4AAAAAADTuAAAAAABA4w4AAAAAQOMOAAAAAABbbtz/cP0AAAAAAAA7DY07AAAAAMDlaNx/0TMAAAAAANhtaNwBAAAAAGjcAQAAAACAxh0AAAAAgMYdAAAAAABo3AEAAAAAINC4/4f1AwAAAAAA7DQ07gAAAAAANO4AAAAAAEDjDgAAAABA4w4AAAAAALvUuH/UgWcbnv9RS9iPNsyzAjm3IddHW/TRsw2ddxnstEl5n12QH58Ja5/1lAvPdsAPz3YsNp4V+qiv/Hp2ieP1omLjWc/xoeWdpz4+29E6BruVY5fh7tuWbJu+s59tuFaFqBv3X/gRAAAAAADsNjTuAAAAAAA07gAAAAAA0E/j/t31AwAAAAAA7DQ07gAAAAAANO4AAAAAAEDjDgAAAABA4w4AAAAAADTuAAAAAABA4w4AAAAAQOMOAAAAAABbbtz/SP0AAAAAAAA7Td24f9VHAAAAAACw29C4AwAAAADQuAMAAAAAAI07AAAAAACNOwAAAAAA0LgDAAAAAACNOwAAAAAAjTsAAAAAAGy5cf+P6gcAAAAAANhpaNwBAAAAAGjcAQAAAACAxh0AAAAA4OPTuH/lRwAAAAAAsNvQuAMAAAAA0LgDAAAAAACNOwAAAAAAjTsAAAAAAOxO4/499QMAAAAAAOw0NO4AAAAAAJekcf9ST3y04fmb3mfTe75qMn50Ce3z0QXa4yNiyXXmRzuqy2WoCa9KDOCf7daVy5gzfdSJj7ZQbz66oDj9aEfq8S7p+tGW9P5o0/P2XvHLCAAAAADglYDGHQAAAACAxh0AAAAAAGjcAQAAAAA+Po37v/clAAAAAADYbWjcAQAAAAAuReP+vfUDAAAAAADsNDTuAAAAAAA07gAAAAAAQOMOAAAAAEDjDgAAAAAAu9S4P13wpdZn+iyNPRU2zs2T9n7qFDa3xjvm2dfaqwt97vd0g+ufBnz1NODvqC++5NhPi9GnhkxPnft64vipU+engXOjOntz1LP2ac/x10Ue7/5Pe1r7tFCPL/VcJ0ryo09bPQ2e9bSjX0prw9MNxMfTYM1+2mMsdo2rp8F9n27Q9k8D9/hF3IfR3H8arBFPN5C/Xc/ZRG/Tl6x91bCnzv6kj7usz9oRypG9pNEBAAAAAIAdhMYdAAAAAIDGHQAAAAAA+mncv69+AAAAAACAnYbGHQAAAADgcjTuX/EUAAAAAAB2Gxp3AAAAAAAadwAAAAAAoHEHAAAAAKBxBwAAAACAXWrcfwrCPL2AM56+gvZ6ukOyPb0kcfGqxjvgn4+73n3V/IusZU8vyF9PL/n6XZWFHN1BHWncAQAAAAAuATTuAAAAAACXonH//voBAAAAAAB2Ghp3AAAAAAAadwAAAAAAoHEHAAAAAKBxBwAAAAAAGncAAAAAAIg07l/+UwAAAAAAsNvQuAMAAAAA0LgDAAAAAMAmGvez4Aal888K1pae+VMdzoquPys476yjjGc9679p+27bF9s4q8/ciMw521KhOHO+OwusP+sh9rdphz7jaVflPdtgXekq99mG4uSsIN7PLqhG7EIeXKTsZztmg1zO9HU/nW1Jx7Mt+PWsp/v7bAf83Xd8nJU17tfqhde+/EmLs+SzPX6WmZeuOcusfSKsS/e13p0pMp5l0PSR9NLktfaykPTxrn2i+Msai+7rtdOZ4ccz44yzQNydBfTRdDgz4vFJQM6zDvJE4q1LzEX0fOLw11kHXc8Mfc8c9njisFFUxrNC/UvzWKpbntiX6m209nrt7HkXtclZB9+cBeKitHb3kdfSPVRyR5bkuvc+PHP6+cxh/7PA/d21Vj5x5vwTI7+890K0xpw577xIj/QkKKO3vnvvnTNHrJX2RE96qF2eGnNm1N0nzp7lScfa/6SgH5qPNY37hx14Ujj+RJmTzn/iGLPOf7IhPT/s4ZwnWzyjr/0iujzpKWb68sWTjnZ7sgG7efft+8w+cuHJhmK2q2xPes7xJ0ZNipzzZEN5/aRjHdjF+PowubQ2sfcm42zX8vnJBvP8IurAkwvwvzcWnvSUi082WGefGPo82cL9cBE58OSCYq5r//K4+dxbPDxuDbafP0zG07Hc+8fCYbl9tbWPlT1y6x4L5zxW1n9orPHYQTSuww6PAwHwWPgu2eXDwv01/2n2e2zsrcWGZTuvPpYsVkx8aMRpxG5dfOCJUUt+yybeGO3DFl4fWLH8OKDfh0q8RnLhcWFsPg743FNzvXaxatiHBTkk1dfIffGhEbcfBuqD1y+PA/XNI58nJyP3Vddab8X4Y2f+P3bmyGPnXRC92715/Lggfjw+9t5vpXH3uLAWPQ7Wiw+D/cljIx4+dMTI48C9G8m1x8E6WXKWp2f19kWPA/dj1D5rZy4b939uNMIAAAAAAHAx/PNl4948fLD4BAAAAACA3WLeq+8tHh4ln20eJc+PhHm5dY8C7x8JY9YZ1lnSOdIcz16PMvJa7zx6fGDYQDtL28fri0eKfT9w+OqR0/+PjDMeFfhQ2u+Rw+dWnHvffeCM50eKPaIx/si53yPBNpG489aDR4b8j5yx/CiY6x5dNTk88WTFwSOHPb1YsWbZy9LTG4ePnPX/kcPOVq5+EJDPsn/kLormVIkvrBpr1a5Hjvpr2f1RoBY/MojWmohdPnDmr6dWeO61kju71AcfOGqhZp9Hzvv7A8e+nr7iA2dOde0BPDWn9N4t6TM+COaGV69ovVtb0zTu/1/N/7v4BAAAAACA3WLeq9f/Hfc3mod/thgA2CbEHQA5CUCuXa48pk5cVMzUPfvewgH/z+Iz5aEwbr3zvPewqT362Nd73sMt7fVwC7r1rdfDHs7Zlr592/xhB31Kz324A/mY7tPWZdvyPdyi3x/uWOxuMi63dd5F14yHF5hD/+wC7Lape7drbD3sucY93FLOPuzQbz3cUm156Nz/4Zb6t4dGPd61fiF6V7jk3zsfzZv2n1w07w8XnynSeFcetj4fOuduWraHHXTo8+w+9X3YYZ/SeQ83YOs+ZX9YYPtN5cDDDcbVtnXZ1t6l+bFNe+zi+V1r0MMN5V/ftfHhDvjq4Q7ExsNgPj3ckvwPN1jvHxbef33eid6e5mFPsd/X3deXTx5uwf+bPmPbPYxnr59sevb6N+4H9cMbpzU/uXh++f3552lmPIJvzcsz8uvbcupnnBbKdlqkny5XTB7ZBtocW3dbxv7x6KLb7HSDMpwqNjlN1nlj67SjjKV7n/Y0XnLeaSiHy/1+6vSttlbzY1e/9lkXT3utq3m9T3vKq9PO8e/Vqe1vKXf12rgNTo26e9q7XXw56V/frW73WfckmU7DdX/VBqdFe5b43n9G1x6hpOc57VTb9Fp/asrZR5z58/3UtEVOnpdxE72/TjvYz5J9vv/e4uFE+TxRxk+d60+FfU4ze5w6ZUnnWuecGPNOhPmnBtY8y1aa/aL7WXqfGPM0nTx2t/yp2dny4Ymx56lzfp+yaPbT7F8S36fG+lPnfp6xEyO3TgzdrD0idj0N5PyJMz4ja6P2K7X3iRED3nrpqZ8ngZpjxaNWfz0x7NX9xFnvTwzZvTY9cdZ5j++9df00cLd5c/4kePeeFMTciTNeTh13kDdOTp05d2LU9VKbnTruWG9+eOpe5N44ceZu5D719gieHuPEmStWT3YS6IEsP50Yfo3UCOuePw3omX4+OL/2xsne/GH0xk8sPk9an20eJOMPkrEHCifK+ElmjrS/JsuJIp93T6880n4nhv7S/tK+J04ba2tOHPJ59s/Z2atr1zNL3z8ojBtrbZdYjtijxP+ePC3JtRK5HhTOO+npnBNnTfPG4knBO4+sJ8FxTxyfBGzywGkPq+ad9OR/S+bInifBHHnQIV+lGDspqMeeu8+T0ycFtfjEGXuldi/Jn5NCWUpt9iBQU0vytTQOTwrsLNWGSAyedOwXIrEYve9PCnwRve9OnDkj2bjPuvsTzxv3awdN0/7+onl/zvMxH5G5q/+QYK19YJ5TdrY9HttXn//83YO1Z59s3fDqsS7Xg6J92+NRG0bklu3o2e9B6/sDhw4PQvt30dufG9p5DwTdHnTKtS7xmt/PkudB0KYPim3vWafpoNemWC6V6GDXn59Q7Plgo7WlpD578skbE5uoq9vlQUEOvFzTv59K9nzQSx3vN+4e9JD/fvnL4viB8x58sJE87FZvSn39IPRuua98D0pjDzZec9P8663WH/zE3qJp/78Xnw33F7yfjL0vcF9ZZ3G/YO59x/r7wvv7Tjmict1X1t0PnnPfaeP7QVt57eKdcz8j131j/vsd4+h+oR/vB30SsbHHfved+aXZWIuD+0rceGW7H4zL+4Wx837H2tJ1r/eDOReJmfuOOLpv+Od+R9ned+SdFiuefLjvqFPvO/W876w1qYwRm2qfJf722rn0TukiT6TWRO89j/271N7SnuF+QQ5I91ikvkbP8sy/X9AXvN+xtkXv7K75db+gP3i/sCcoza3IvertZe4X3LPZPffmTfu1g3uL5h3gsnBvy+sAAGA36jjAx49Fr763eDheJNB7Le61xtLndOy95N3xAumdtOd7yZz0XW7tcUau9wQ0md8z1h1nZEltca811yPDPUV2SZ97QdmPlTWeMzw2fS/RXYsRbY/3FP8eZ2ybm+ext0eXnPz3hLjwxNo9Iw4te3vi+p6y971MHt4T4iUSW5Ju94zztVjU/Grtc+yQ+z2jPnltGH0+LoyBe846EKkN94QYvldQQyWZjo1ciOSmlRuaz46dNU7L5+OAryw/ajY8dub4e874bN/H95z33HvB+i354Fjx9T3nPvccPUFXOe8J+99z1IZ7RkxreWDF9HHm+7HQX72n2N2ae+y8a+4F7WrlhtZ33jPi4Z4SC6mv7jl8663Bx4Z8nny9Z9w9ab+TzD+4VzfuzYuDf7qY8OMtjltjL5+vtcauZddI3639PfN+vCWDdJYsg75OI9U9d+axYBNp7o8nSSjZIaqPdrZkd93m11y+Oy6wx3pMaXpdS/Tw6X8syGj5yPKPHjvrsh2rMW3ve+zQ8Vjc+5or16J5kffLSMmza2JcHRvrV9dcc+vhxeMfy4bHztoXjYFjZ2312+SaWtOOnfmkja/6U/d1l7g8NmLGm7vHHeJIll3OjWPnvZnWE01OyadSDdDPvRayybERp8cOv0fuxONC36X3ht1L5O+dyD3otdGPO+PIW5OPjXXHznswegd5aoIec9fMO/jY2XNaMnj7gWNnD5eLs2ND/2Olv8vJ+N7e86b94P96zhv/9CXtMel9+7s0Jr1L91+MXztYX7c2Ju2XGc/tJ8rolT13Zs5GOTkSva8dCLIL+pj6WfK37amcoe3bvMvuIeml2UMaM/y0dr6muxZfWgwt1opnec6WniO54smtlKhMb/SQJ1oueG3l0aEvWZ0xo+Zk9LkkBix7WnL1obvxfi3fF8/ZOuCpc05fXzswZHbW0XDMleZUJr7TmiTWKCs3nPKr+5fmlpX3Qj+RvZ89uVPquyQe1Pg0zs7e3VrflN4nfdi9xM/OOAj1TlJcR31p1b6cva21kfWaHaQ664z7XB8RtdH4jf+zWbO3GPw/5gNLmrH2d+8779zIHn2ub6+7thxr6W7t6zm37cguOqZcM+RZPl9TZO3Dbn2ulWzljZuc/toeaZxvkq55IunWhw/7jM22/yL5UZpvacxE4+uaNFeJjaicEXtY8a7J7tn/mhEDUq2y8ikaQ5F8zMnmiq16v0jd6+If7x3Zx7yoDCXxeK2gdm+0fta+vKbEi6XTtR7vs5w9++iD+oo3K4f6lvFaxzjwxNX8H3A2dHcXybw4/4V8Dnn66HPXYu/5uXv1/6kfDr74vOgtGLeeU8Yrz18U52n7aPt7GPewbil7W4dxD+eOW4x6JGfrceb5pV6bsVufayVbeeNm7Hznjdd+/dVt7tipZ1ns96vnuHD+uNAu4w65KMWAFhtROcdBO4+dtk1lHAfrxliQcRzMtZIYiuTjuCBWlvuNN3APjQvqWp/zojJ443E1Nr5YULu/uMH6+cVMvH/RnWNd8tljz/FW+pUvdpZ5vJH76ouddBs75bbic5v9Y9pXeeQZb+BuXfTqdeN+8E/qlz9Wd/b/5AXpd+ndWJhj7aPt76F0fU72cWBfz7nNnCVddFzb19Jn8TxWZO3Dbn2ulWzljZuc/toe4x794dV77PCn5StNz6LYl+xbuK+lqzi/IN/SmBkHc1Hzx7gw/qXY8/pKi3dNdlc9suqFUKusfIr4PJqPOdm8ukbqXhf/uO/IHuaNOuq1Yk8pNkpq9ybrZy7eAzk27vE+y9kzskf4vEBv4smhvmUcd+wNPDmhxWpfd3ORT4J3XV93a5J3zW/c/3HNP1p8AkC//FhwfBdl3db6iz7zx4hXbIa/4BL5CH9+vPJu3qs3v3FvHv7hYgAAAAAAAHaLf9j07HuLpv3u4hMAAAAAAHaJ0Rv/oPlsfuN+93w0fLf+XHJ3gTR2V5h3VxjT9sm9f1c4565wxrvKd2mPdzNYemmyWLbQbOexYeRcj/6e8+86bKTZ925Q73cD9vCs94zdNfzliSFN57vOdZEce9eI4btGDntjRtv73UBc3XXE0F2nnT25dNcZJ564jsR2NB7eNeqRZft3A3q967TPu46489SNklyx6pYl47vOehytT3ed9vDeW3eD9dNTG7056KmNd3usCZ6Y8tTiuwF7vBvwsSdX7gb7g3eDNc1jqy49w7sOO74bqB+RPqtrHkfqfBc57hb0fZH6/a6zV7lr9yrD/73+W/d/sLd4uDP/fEH63TOWe+/Zw7NmuS79lPaVvmvnt+doenls5dHfu07TWdrDo6/X5h5dcz6Knldql4juHv9bNimNvU3YoMR/lm89dtCeveutfPPKaeVrNMeiMW7FVDq3S072UVdL8tTr54h+kXlWrpfYKlqzSmWQYqAkj6KxE7kHtdju0/6Szlrd9JzT173htaG31lp1N2Ivb/9j9Wx952jXPqAkX/vubfqI46647HC7+UX73kKRW/OB58+3W7QCLvv9dub7rdb3W5k16fv2HreSfW9nvt8KyJZbl8qU7iHpdUeR7Vai121F/9vGnrcSO9xOvufe31b2zp17K2NHae5tQ/47zvPvZHS5o6y507Kf5nPNllJc5WTx+FmbG7HLnSRm7jj9dluJ4Vxs3DFkua3EUk6OW0peaXp64t8TF5psdzJ5ckeIwzuGn24F6slto8ZpddXSx4rNO0at9uSvVAOkeib5WKtXt4V75paS73ec9eR2INesOL9l3Em5+Zrtbxk+uCXYW7KP5rf0jrvtyK07zlizvlv73Anmn3bP3naQy/1bAR3vCLF7x1H/7zjvDa2fuRXoQ24Z9dRT424X+O9O4C685ejvcjbw5Lrm4ztGHlj177ajb70t3MXSGVJtdPpt+E4zvvfyy3ygWXTz+ecb79S/ib/1spgtvo9a35fvXs67+XK8+Vw8r6x5se9i7vCdlTNWxpbf31j/viJbjuE7KzKu7LGQaZTIP8rJncqTypqTsdFtuCrnqC3XytjNvL7D3P438+cNM3IkvhunPkptP3znpb5tWYcZv+dsJPkviakVedv2eCNv41ESN6PWmem7rL8zcTNK7SCcPdbmJee/8E8ullrv1uwoyZvmSBILa/E7XJdxZJ0n+Sv9HCrf07hsxdIolSMXO0Jcjdfy5eZa7os+T22UxMfac2q/3Bm5WjYUcq1dnzL5OMrsm9p01Mq/tZxs75/UEzE3cnnaznvpfa7ODfN1PVsH3nhntbak/krOHwm1YJTE3yitW8N3xFwU87x13kiKwfZeqS+TmMjGc/pOyflRdu5NYc+bq3dImovDd/L3ScbWo8zeo9w9Kuwj1vHheg+RtZdVQ7X7Nu1dUvnSuye3XtJHq8/Dd5Q79pZyp9wUa7JZJ99Q7utcDOfuaGGvlfXDd4T41e63W/keIxMTWRtncn2k1aT2nKEyJ72/pXOkWEv72lZ+5XrQ0VpM3pJ7XMlGGd+81Lfxwe29uSDVwf9Wf769GHx74aC3W8/t7+m89TXW+3VuLta8nD9Kzh1l1rfXrK5fXbcuz/q+6/vnvr88q7HZ0m7rOqzusX7GzZXzmn1GL/xwMyND3naSHG1ZRoI9l+eOMzKPEvnSvV+eeTNrr+W7pV6pLu14y82Rz39bkCmne3ufm8raVbuPMrZL42XV3jlf32zZ4W0xHtZjZj1f2nvk/DVS4i0v800hL1flHymxm/ernKc5X+k1IlcL3hbPWffZTSNGvLXpppHHaYzJNs3FYjuPVm2az/X1GtFet65jO3ZGmdq37o/VM+TYfFusKyPD9nl55TjS9h9lbJnX+e1snmv+1mv5TTFPxhmb5XJJjteb2bzO3R2jTM1d/Z7WuLeNeijbdyTch1aNb5+Zt798z6zXr/X4T+XLxa4cb6uxnq/7N8W4yMWC1G/k7Ldaz29m3+XrsFXf1+NoXc/UL29nfZevGbn77Wa2V0zH23KmOo7VvkOuC+u1czUuc7YZOWq7dL+298zFzfq7fI8r9w43k3rfkm84t9neotj9L88nvPG/vix+9XPue5t2sczNk961v+ee299z5+bO0M7zyOOVK6djbg9LhnS9JIu1n2UP7WzL5lYsSDaU9rF0iLz3xJUkZ04eKyYkX1oxHYk7Lf60vay9S9dqfvbkt5Qb3vy1/OnRWdtXO8fri2gd0mqINx8isW/p5Mlnb5235PTkl5VnVq5JtvDGhlbTrVrnyWFrn8hd6ckHb7xZceA9S4s3T554Y8aqM94a6o17j16euPLo693bcz9G/O6xU6S3ivRNpfpKddPbo2ix7r1vvP2Pt+7qPpn36s2/nFp/Gf79xQAAAAAAAOwWf7/p2Zs/lfmf6y9/bz5QxBv/U/naPtZvik3KFd17OX9XbXVZaduzeS71C1w+f1+WekWMXb442TWfvSoxJOnhuR9LbGCdF117Gf3Ql8wf9zrWm/5/r+nZm9+41xsO/+6ieQcAAAAAgJ2i7tXrnr35jfv/WH/52/Xg3wUAAAAAgF2j7tXrnr35jfvfqQf+5vPmHQAAAAAAdoy/2fTse/OmfXLwPzxv3ufPf2Pl00s6X1rfHm+ftcSzd0SW3FrrPOvsVO5036jskrzaXiWye+TV9oquTe3slT9dI8Wk5pv0fEkGb5xGfOSxSzRmLXuW5GE0tr2+Kz3Dk6PS92iNiOhRUmc8NUazj0fviP8j+kR93dVWpXEk1YuIjT3zo3paeVMad9reXpn6yhdP3EbvR+uu8NY+77m5emrZxzsnUgtKcjnSK1n7dM3xqB0idaj0Pula20tt2cd9otpz+Nfr37j/rb3nD8MfnX+2mTfzyZhGOl9a3x5fPltndZUl935JyV5tuVN9vHawbGLZNGqTLvJ597LmeeVP10hxovkm9bMkgydOoz7qGs+WTFrelORhad565kXyx5OjUblL/dAlb701RrOPpbdl2y76RH3d1ValcWTVGI+NPfOjenprRdea690vZ5+u+VISt9567Z0biX1vDHh7h0iudakDJXUzapeuOd6HLJ4zPXYq7elK5ff4pKveq/y15rP5G/e/VvMj9eQffd7AN9+HPyrSvLfmtsdzc5r16R7N55L2vPZ5y8/0rOWc3Fnt/dv7avp59En3SNdJ+7TXtfXLyZTO1faOzvPs0/ZR2zeWLZdr27bKxYwUSzl/p+dIMSjFwVIGKYY8MaHtrT2nMZPTJaeHZCfJx5IO0t5a7rTfSXtF7VEai95aI8lg5Yp2dl/6efxRInuuTrbHpPjQzkjzJBcHWr1qr7fqWiQP0/2lGPXmsrR3SS7l8jl3RjtncrLk7hrrzHYOp3XaE0tSbffW9Mg9Ja2X7gLt7pHyQIr79jlSvfP2MB5S+3js7I0vbT9vXHlqgLdX8t7V3j3TmPbUylwM5ca0+1rzWaRWab1MWzer3qzr8iPNZ/Mb979a8/n6yxfmDbyH5dzImnR9uja3V/ucdI1n/XO+UHy+xwYlukv6eeZa53f1jWYjrx1yvrLktXToqn8uhqL20vYeCzJL/pb9/wV1ra37F8y5bXkt3UveeWUt9YXXV33sY9m5JH7isb0eE1pcWXnl8aun3mr+0+ySxl8s3rrcBT8Szs3S+ue1WTTHonv0lQNSTbfs6Lkj9LpallPt3KkCudr13ozeY/LZX3DlcRffaj1TFaxv3nyM9F4e3SN9pKcHi/ise89Q0K8N/0rNX91bCPu5+svn6xd/pf7vTT7/lGjeL+dIc9vjuTm5PZZj6doUaS/tfU6mdK6mU04fab2mtySHJbtH/hcMP2/PMWTM+Ujyu+UTLWbmz8PP+2w8dPpr+HnRv5Fx6SxtD82/OZk1+2j2s+LCE+svxgvsZcWh5jdpraeueOuLdq43573x7ZVZ8m2klnjjTKt7kdyX5PXUUKueRsZzua3Vzkgur60Z+u82b/3z1oM+8tnym8fXkZjwxJ0nRqyewJXnw8+bclox473jPHjqfLTP8NYDT+6rPhp+vkheT/2K3rWePkDqJ7I6DD8v9kuaz3I2MuNguH5m9P5YnfO5pmev/1Rm8Jfrh79U/9a9ad4bbiw+1/HMWWcx9+AvJ2M3lP1X166c2+yzZG3tDZfMVfsz2ScvR0Yfl50S5mfdEPa6kcx7Ph61eZWsXz8/r3NOz8ql343s2PqcGyvnVqqtbog+a/u6EmW7oYzfMPz6OcVGN9Q41Z+96yX7eGLhRsZOnxPyL2+vKjN3zZeL95UjxitPvBp2r9wx61iTicE4L/2o7iHIbPv/hqOe3MjU05wf7disXLl/I4nJG0be3liLl/Z5L+Rz3Av5Wi7otabz53z5nrtrsr401r04/4bg5xsOWfS6UDnntutupd4BN8zYrcSYS+/4G+tniLX0huNOXfeDVOMqs74Z961W1xx5HekVxLq3tvcN/z20Jv8N192d26ty5KN81g3jzKQmZGPxRvb8Su01bgh33o38nbqMpZV5en9XuftEq8+5kcjs7O/qXr3+h4DmPwf539cLrz//bBr4hsFfevkcZdBa32WfdM/W3o2sK/Lm5i3GsvOsc6x3A+f6QV7+3uyc+f5C38zea7YYlNlivs+go7xB/5jzBsq8AlndOg46nnXQb6647CTlx6BHuQcF+XfQX8z1cu6gp5rl3SuSI4MOcdhnfS6If7F+G/Ea9unAnwcred+xPhbbrK/7MqJze1yRay3/Bj3YpYfa2fZXLj7M3Blsth4X+XhTZwfsv+LvgTOGNBtv+n4b+N6rMTMo6IOcZ/XWMw0/2zT5e8+b9sFfnH82g89pP3/WMS7N8cz/bMH868Lc60EZrneUw7vvdWP8sz3KeL1ArhL9rm/IJhE7XN+A79r69bFX19i/voH8ux6Miesb0KuPHOh7TZ+yXw/7Zdyrja5vqO52rfGf7ZBb1zc6f9xJt+tbis3N1exxr3f5pnXxyni9MK+vb0jX6x36kr57gOuKzlqPdd28x8cbqceSXNF+73qHGl96v17vpZdrevXx4L/bO58M36r583V3/xdbvJV8j9Ds9xd62Ocly/2az5d758/ucq62d/udNC8dX7fDW8mcbnb2ne3fI7b+rU7z+8bru5ht3wrHQvys7dhnVb63erKTPxf6kLvvPTfrk7eEGrCpeH8rnNv92POtHfb7W8U1o3t9jNts8/H9VvYM2cZvifL1k/ebjR3PufKZb23ozLe2fhf4dXzLqGHLsbcKcuXi7n9vbGk50E/deavzPpPhZ5qefW/x8Om6m//z8wb+OZ9pPctUCzzztO/tMc9+0l5V5rs27jnb8y49o1JsVRl26GK7Pm1cCfaris/9jBo3Hj1zOlif0t6R+RH/RN9HZYjmRx9UAT9VW7JZdH2fNSdSAz25Uxl1t+rJrlG/VoX+LZ1bBfSN1LDK7b/PdKqzfdeUqlD/KhCbk4J7P5JPXeKlcs6peq6ZVQ/1rArUi2qDdbvagM6V65zPFOWvZZ/K6ecqmLN93EubqGHrujS9+l9oGvc3z6eD/3b+2QzGeFNcVxXt9+kX+1XF8sTk9K3/9JbWe/Z+0z2/bcNqxQZvqn5aH3vT8Zye0dXv8TioQn5+Uxl7s4eY+3TH+H1T1b3K2r787CoQV5F8rZQYqYw4LNfhTTW+4mdtJ3crtX59uldbabnsyaOoDL46E6vXUg5USo3SbFAVnJnPU9vfVW8xZdX+Ny8krrTz/bXrTXf92Vz+vlmYz1pdfLP3Oh2zYfezK/X+7BLzb7r7KKumyO/fFOdVvcdKF5uuM+/VB3+uadx/uF7wZ2t+uB74oTnPX/7QOgern9V87Q+vvj/4obXv8/1a49n9W3tmzx4I61v7Nmvb75bPqZzp+e152bMOFu8S/dt6Nc/L9Tn9Xsh2sL531saprKl9DHvmdFmOqTZu6dPWPWcj7YycDZf7v9g7XXcgf091lT499mnHw5p/D35oPaaVWGzLmeqp5pIRf5IMaTy4OQjMO5DzLfXvmr8PhLMO9BgRY96xn6eGiHGp2ebAtl0ultP3K3l3INSwXO0U6lrIxwdG7ArxlqtX2Xg+KIu53D5SvXatz515INeRdqyYeh446+yBUmcD+bpS0w5s30nnt2PPvYdhT6l+r9WxA0NOqU/w5LGQG1JM5O5urVaJ9S7N01RuRx/zwiebrOktOV0+Vnoqz1xVp2BNzeV+6g+pb3LlbGKTXL8YrjlCL1BqA0mv+Z51r1737E3j/t/U/NeL5v0l0+T7cmyavGt/nyrfc/u1aeSYLj6lOdbeU2Vd5XyX22vakq9S9NXsJuk1Vew0DdrBksFrj6lhD81OU8W/0j6pfSsjziqHfB7dJHtK+0+d41NlHyv2pk4feO3uia2poE9JzOTyxOO/SrGjZ9ySMZd/08y7aSDGp4YuU6UmVhmbeXNfs32k9lm5JOWllXdTIeejPivJ99x7yy7TDnLk7oipcr9VQaw6OHXo3uVenBr+q4J3V0SnnN+0XJk6dfD6XdOxpAZZd473jiu5DyL+sO7iqkOPMg3mw7QwD7R+q6S3qRy+ku6RKugbLY+aXr0+p27cB3+m5gcXA5ujGvzpTu93icsk62WyGXa9/DHYyJWT7aLl3RV7SbZJ7daXvCX7XOTZu3jmZalL28i7yxwbu5Qbm967y16XQcdd7Ce3cmbdq08Hf7r5z0H+qZo/WR/6X7l43uT/oDnHMxZ5n5XDuUabl76LytGH7l3mLZ9zY5vUIXeudrbHB5oOlr+72rjUZn36tq1jRB7LLpZ9JdtGYsqKycg6r5+62sjtu+EPhuvOcl46P+cPbc+01kbzIlxTh3n5lrJ0ic+crKU5bcVHX/lTejdtqsbk4qmvuy+ao5uIwS722aQMffcJUm6X1qku8lgxVeLftM55+sa+9IrU6EhvsxM0vfrwTzV/KvNf1g8/MB+YDP+LOcvn3GfDeL7mT66syc1L37XHtWftfbpfenZ6VnquJY9mB0lXTXft/Jzcku45XXJ28/hBs7lHB8221rPHFzmbR+LBsoklX05HLe6i8aXFmXV+9Azvew8ltvT40cpFrT54ckuyoaVj5ExJdy1eJN3b+7VrrTemNH0t/dPz2uukdyV13Ou/SF215kdzIJK3ml2teNP8H5FTWi/JZN1/kZiN5pqn5nrvaEtHz93nudNL+ptojEZz2eu3SI/k9Ye39kdqhhXPWs2V7uhoPffqHelFvf2I/f0Hmp69/o374D+v/8nij9df/rN6MM9EoFLG0rWVsq5S9vDMnwTkmCjyad/TsUqQM32uAnbS1mi+0fSLzJk4/K7JZ8laKXaL7OO1oxZTE0cMVu55P+CKp4nD1qU5qMWltnc0ryfB+Nb0nChxYcXfJGCXysiLymGjqrBOecdKbTZx+N8TRxG/az6OymDVhMpZ0yunbJYunrvFE5OVo7ZXwfvSo1NpzlSOc7X6UQXq/iR4/08C971Hh0ngLrDuzSpYIyuHbaN30sTR40T6GeleqzrI5OltPDXSEyOlfvX2plWg3njvCHdu17163bM3f+P+J+pJ/0n9b6/+8ecN/PKzzYHAQBkbKHMHxj7R7wcBOQ4SHaN7Dgx9vDYcKHIMOtraO2cQOF9bY9lpINjDK79my4HTnwNnvBwE52lxYPnR0uegIAc9MT1wvu9yzqBDzBwU1J1SHaO5GY2pyJqI/h5/RPK6q98HRswOgrWttJZ10S0ii3UvDJx+GjhtW+JP694qyS2rFg+Ue6XErl3nDgwbluRhpD54a8jA2SdFa/YgUDMisRj1ycCZE33U90GH+tol/j1+9dZFYe95rz74E82fyvyn9b+5+qn5QMN08Zn73sxtP0+TseX85dhUWLf8XJI7d7l/JaC9b58h7Z1bN02ep5m92vNytpoq7yU5pxl9cs/TzBmSzaeC/SX9276oFN1z9tJioXLaIt3H8r/GNKPTVJEzZ5epU+ac79N4T3XR7FQ540faw4rbqWKjyshnSWdPbkm5O1X0T2XLxZw0rxLq0FTIcymHc2dJeeb18TRjA+mMqWCzypCzNI41u+fyJxrblRLrmo5ToZ5ocnrjRIrz9K7yxnnu3TSjq3XPajFtxbrnXtTqveSLKlirJL21Oj81YlH77ukLpo7+JrLOez/keojS/bXY1GLQE/dW/kXuyfQOnjrurzQ+JNktHdvrrbtf289zztRxn1t+9fWNn2rOa37j/sfqh6OaP7oVqsF/nP3cRaKy7bIuJbpflD67YMdtyvAqxc0uxdbH0a6XzXbSPWCdT/x8POPS2q/0HTaHy2Hvo+asvecd/GBa/ydmZitUC6YBmvmTwSfXxqx5y+/R8yJyVY453v1SHaVxzRZVD3JY8kw3aM/c96rHPSPvq8J4vSiqjnaOxFM03qoe5dd8U23IptWW/FI5cq8K7l2ax5YsnnwtrZFVoQ+qnmwWzZc+74E+4qrqMc/6lKHawB1R9ZTfkV6hUvKsCubctu/ZTcZnJF661qVInufOqjrcZ6n/+rqPqg34qB2Xsn6TpmffW/y2fVRTN+/Dwxc035csv+fepeTe5/aVztDkkOZK50aRZJfGNB0seSNrcraUvnt0TP1pyRS1seXrPvzS1YelMRy1S4ntNhHH0XjZls0j9vHmjlV7SmLZGxNemXM1tTSPNxlLXWJQqgN914PSeI7W3uhZpXp66mck9rvERtuP3r28snveRXLXa3ft/oz4PneXet5JevZVB0t16Fo3+rrjNnGHR/ukSD5G+mMtZn1+aHr1o726i5/Unf7311QrTIfjOem4Rjpf2qM91p4TPc8rh0cf77uIjDl7eNb0YfsS+0RklNZKvrXktM61/BOxmSZ/H/HXxVeRWJPsHok9z7zUPpqtvbnXNV67xG/0HG9d8/qyJMc8NcN7ds5WnjrsqeVd9fPYqY9Y7pqbF/0uanNP/dyk7F3vtFwNKs2Nkhzb5P1QWgulPO7jTG1PT19Xes95c7ZLH9H1Puojb0ti9vnY9zc9+975Yd3BT4ffW/8K/tqc6cG1F8+57xGaQ/qYY8mxfCfNaf4pJXJWbm1UXku2dN/0jOg5kfnp3LZs88Doyeft5+WeXfzdHovIaM3VdC7Nh2ae5mNpL80+1n45G0XktfLI48d0PCezJVNE7pJcjM71xqzHP5G6Je0rxU30/D5qSRcbl9oxV78853rsuA2bWbWtS00p9YeUt11iYVMxsona4ImbrrYo8Xsutts1eB4Twp27bfo+u887/qIplW+tbxx8T9Oz179xv/p9Nd9d870rHNYT0rES+tqnlEnw/FTeyHqPrukc6/tF2nvTvivVvVSubcdiLnYmF5wP2/RnH2suun5cxPldatBlqtHSuZOONdG7b3v+4SXJy1e5fuxqbOdsfvgK+qGLTtu2x6GSy9uyRzsutpeXTa/+fXvzAyf733U+ufpHVmgmpGMS2lzpXWT/LkTPSedHdPOcZa3papf2+j732sQ+mu65Nc+D9ruL4q2PWJBkjMR4W/5N2/eicydqz75ybJs22ER966OuRM7ps2b0oWdXn0d9YtWUi4i7PuTYZl0oPatL7HW5byOxX3oXXTY8fo3aYlP1u6TuRuM2UhNK+roiWzS9+uB79uaLDwffUf/dzB8u5nDwXVtZsy3Zdk2Hyy5fX/HRjFl79amzJEP6HDmzrUNfsm7Kz33v28d+u5ZzkjzblrPPHPu416vLWOsvui6UnpWrp9uI+VwNLjn/MsZFFxtrvvfExa7Vly7yaLETsVvszO9oeva9eQc/HfyBupv/QwAAAAAAsGPMe/X972r+qzLfWf93Ib+t/hdU/+B5dfU5y+fmMzeePrfn5tbmntvfc3tIaHvk3lvrI/tINonInLOZdx/NH6X65+SwdPPMs+SR1kqxZungwYoDjz5eH3v2jsig+djKWY8MXXIxJ1uJHUtiJeoHT5xptojKqM2J5L0Ux5H1kTOisll5r9k4srav/Iz4wWOTSIx6ct97h3p0894/JXdHaQ0vzaGIb7S7MZLb3ppbWicsn5ee681Fb+8X9ZN1J0TujVL/WHHijZ0udtHyLyr3vFcffGf9G/er314//N7672Z+f5aq6fCFd5F5y/fNpzS3r/Guc0v2Ssc0PSP7t+0W3SO3zybs0SVOJDv1FXel8rflisR2ybnaOslvkTzqMzajORA9s0vM9pE30TjrGr+WDhFfSXKktsjZxtKhD32iebUNeTZZ7yx/9CFTHza56DsgWl+kvCjdN1LLtRrTJVf7jGcp5/vuo7R6UqJD6f3Zd35H7pk+ZfPsO+/Vr35785+D/Lbzw6vfUvOtL5hc/X3ZZ41mnjZ3+W45LzfXOsv7PndG7nn5WRk6tffSZG/v1zxXAdlzcnnOteROx6IySfPSMWuO5HdvLFSFMeGZa8kVsVNVsLcllxbHXt941kVtZtnGsqEV55rulqySvp64jcSHJKNW5zx2jfq4JI4lHaT3Xl97Y89zX0TiRaIK3G2VI0e8fvXkTmrbKljLtPM8+SLZuQrc7ZXjfC1HojaS4rFyxk7pHSzFr5Yj3lrr6S8qZ22zxrrGrHZHa/XQ20t06Tujd2tJXaqcslcFsW7r/C1Nz74333x69ZvrX8H/nhdMh59Y+cyRvpte/YT4roT2HulzTr7cmWsyCnK1ZS+Vs/2Ze/ba0XtOkZ6C7bR9PTp4YiK7t8Puy3keGTy2ydlC3O+qz14rz1c/YdrNk18uuwz7zTnvXiV6eW3ilUOrAVrtEM+6+gk1P7rUj1zsRHVL49Hax9q/q4+l2rfyeTUeo+26UBpn3voYjTmPHXK1Sry/MnemVusitTh3J+XWS+dl5zrmRXoGTz0NxU2mDpfko9celp1Kcjxyr+fiqssdGO3hcvneV59XcgeUxI1bx6ufeEmmd8nm9NVPFPcqoi+bXv3qt+7NN58MvrH+FfzvfsHh4HfNPyeLTw8la6x1h62x6L7p+ua5YbmPtHfuvcVksXf7HGsPaY6kZ5c9U9kOBVvnzp4I8z12b/t20tp/osiRk1eyr+ZvzVfemJkk8ZPGkmTr1M6SP3LrInJbsXZYkDPaeskHaf4cKvkU8Z0Uk1pcTASZ23OlOPfmWbpmIsip1bicXFIt8uShpz4eZuS16vZEiYGJEdeHic1TPTVfafl46JD1MPOc+8zVJW/uTZTc13Jb01Orzzm5tBjRbOC5bw4dfjh03g+SXby21uyf0630zrJ869GrJE4PjRqixbGls1ZHJblzsWX1Bd4e7bCgr/T0CVbeTTJ3syfO0h7mMKkZmm8ngR5W2nf1nvnGpmffm3fw06u/rX7xTfXf2HzTi8/J1d85/0zH0vHpYjz9XJKuTd+lLPdP907fp3LkZFieXSVnSHpWyfx0r2lmr9ycnI5tvXK6596398mdm87LvW/PqTI2mGb8mp6bk8fyZ5Xx7TSxu8fvaQxNhXjMjaVyV8k+Urxae6QyarJJftH8lpMtN1/yS87WVUbeXJ565KoEf+ZkqwS90zyU9snpIeVLJdi+rb8kV6XEQe59Wockv1eGPbUclOZWQj5LcVAJOSj5aqrUOC3GpNpfCfnqqVNS7OT0z9mtctTeKhOLUk2cOvLIugciY1rttOyq3WearGmMS/tqNasyYkPKMY+ttXtkKtTiaeZ+1/qSyrjvND9I8uVyshLu4lzN0nohqX/Q7F8Z93UuZ3K1W6u/0v2lvZPiUdPVc49UQm3z5F4l+LRSarlUvzx2qoRcm/fqV795b97BH179TfWk3+6i2v8d4vjyXfqZzsnNze3fnpe+l+TQ5C5ZY52Ve5fqaOlZIndqw9x5HhtbOlj6aj7q6g9rb+m9NSbFqSaTx96R+JXmeudbunlitctcj92jNaRL7Ei2tOTS/OrJbS1eLL95/SjFllavPGdG7G3VFK+PtHrurXXRGPPmR5dYjMhfUjO9ORPxT2k8Wmd5YtO6G7311BPXXlto/UpUz6gcUu526YFKZemjlnn28dRlK15KezOrX+s7d6wY8taEea8++Ma9+Zfp/m+ov/zW+o/ef0uW9rv0efl9+azt49kvfbY+02dpTu67h1S/VNecPbR5uf0s2S275PaP2EqSw9pLmmfZRHonyRDxtUeXyDxvHHl00fzvGbfk9MS4ZstILkXsX+IPKccs/a2Y88Sud/9Svb1+l7DqiDbPk0/WGm8clsSi1x7ROh7J5b7uB0/MR2LUe29665D3LorWPc+95o0N7x0UrZdeGUvuTk9+Wr2UR79I7HrvDK3f8rzz3q3e+6TLPaLJHn3vvQutOh25X3Px0fTq9W/dm8b9N9d/W/Nr61/Df8Oco8Vn+pz73nT/R8I7iSPjnbXfkWOttUY6J/fsmZt+X9ql+ZwKe04NXdO16fzce0tHTVfLDpKcHpt4fZ6Ot+NLs4u193LNkTOuPfF85PTnkbI250dJvyPDZpatUxt48tOb09o+R4H89caIlBtHBftaOX6kxFQuPjUbLOcfOeycqx1avKWyHBX4s2udnAr3g1XLUqYF+RnN7aMO8uT2sWKhJN6PHPLmclu6d0pr3pEhnxWvXvtZMei9O715Pw3cw1ruHQXqnGRDr/7SmUdKTbPuFyl209zV6lnkrjkK5PSRUXOs+/PIUQO0O9db66JjUr2ZCjZ/oW/dq9c9e/Ofg/yNdQf/a+p/U/XX1wue034+TMYr4Vn7lOYfKudoslSO/Srje1TOyrBBe17zT0WHTn2ls5d7HDp1rIz9NZm95x0GfFgiRyXIVCljlcNnbd0kf5XER25fK14tu7X1s+LcsqX03srjQ2W/yrB95ZCvctQPzZ6a3StlLFozIjFfBf3ssau3jkm5UgV8WWKLyqhHqZ+i9qmCd1AVuL+894i1R05XS2ZvnkZiMK2RlfP+8t6xhwW10Ov7ynmnefuLUj9IsnpysTLqWp+2PnTmpicOqmCPVAX7kUjsHwb6pSpYgyunXatAHlbBHrcKnCHJ3/Tqdc++dz4b/Lr6f0L1V9ZO/vr6Pz/z9S8/a6rmN/HDr19lf/V5Pmd/fXxtbnt+umfmvBfPmT3Wzhu25JD23c+fJZ7ZOkOdO8zLt3Lmvq5Tbq+1sf28HCItGVbW7ef3l3RT9bTm7ic+G+bjJGeXVHYxtjKxkI3VoWI/aY992b/i/vtG3izeS/Gqxsi+IvO+EMNDxz65/Ez12M/knvRdygPFb1r+qvmyr/tHyumcTzy1Q8ybjE2kOHjh/0COWLVvZc80FvcVWRW7Zu28L+hoxaMSQ2Ktt+rK0JG3gkySXG27rc3L1KhcnVdrxtDIU+ns/eD9oNloX78TvfGmnbEW4/uyrq7+IrePEn9aDZZqafYs4e5Y63v2dZupdUC5U6R+RL0/9h39m9DjeO5Aqyaad81+vhaZ/ebQ7ptctUXoz6RaoNXUNV33fT2ZGMNDwS+LsaZXr3v2vcWXr61/Df+r67+heU77uenwc+Pt5/bYcn57XXt+M76cl85djuX2bs9P9zzKyHCUkb+9f3tOW+4jQaf23BTJHtL5k8z65RlHyh7L9amd0ufUTjkdczpLe08S3aWYaK/P6T/JyHtk2Kwtey62jgQ/pTLn/JnOz+nvkdGK2SPBVkcZn04yfkrzKqfjJOMbr9/SONR84UGSYWLYISePlV+a/SX/HSn160jIGa22SLUjFydWXW3vJdlEi58jw2+prEfG3KNgDETuC6se5Ox8pNwpUhxLPszFmVRj0tqd1rkjpdZK96B0n0m2Sf0hyZA7+0jJkyPhfpood3xunjY2ceSVFScTZ18g5ZDVo0j158jIhSOlzqT3+pHRu3hzM1cLrB7Fcydbd8SREZuWT7WaJtlB6puk2mfVkdwdOwnUbs+96a1FVj+9tnfdq9c9e9O4/6r672Z+af1r+F8Roun8o2v6ZhsybFPPLmdZa7X3F+nLPs++KD36PncXcutVy+NX1Ubt8V2zY1/yePeJntfMj+wdqaHE9KtZW7rut4m4uEyx9qrWqK1R9+p1z9785yC/ru7of/G8k58Nv3b+ucT6bpGbH93Du3b57nD4y8Pn9C2ntudyPP3Unjdhr5xMfe3b9X1f8/qwYcSOXWQu8YN3z9J9S+OnxAZdZI34Z5vx5zlfqwldYmlT/u4a+6U6XlTul/rUirk+8j16j2nvc3HYtx03kaelMvc1x6u3N069MeXJny73eh81XbuLInHZd13vw24R+3hl9Jw779UHX1f/y6lXv+b8aP+rnv/WvaZqcShQKZ/pmLT20Nhf2ieVrVLeafMrZb02X5JJOsuj76Gxd+U815I7ck7JftIeHn9VDn9VyrxDxU9VYI43PrxxURk2Wr6bDH5ZOG4rZyzkZNd08ay3cq9y5klVYLeSeDx02rNy5vphhxroqXuRWlwF8tlrw8rIucqpw2HwLjl01P7S+uutF5rNDgvseOg4twr6xBNzkXw5DOxp1ZHDYC6U3FWHzvy26m7EX976F/FhNAc8Neiw4H6qAnejN0+7xNih056HgfvX2wtYvupaA701MifbvFe/+jXNn8p89fn09a+Yd/LV/i+Zf8LF0LZ/H77w7NHMiZ61rTjxnkPc5u2w/F5qn9L4KfVbSSxuMrf6lKXv3L7IfJPWeeNlGzJv28a583bNz5o8uxiTEZl2Pb+6xqmUY5uqUZu4i9v13fJX17trV2tlZ5peff+r9+o/gP9F9W/7Dup/c/UXzqnqjr7h6OCrXjy3xyWWc9rrvGul+ZG16bnW3t49PPu250bme+T07Kf5qnmX+tbSNd1Pslv7nSVnTqf2mqWcHvtHY8obW5rdI2d2iXnpfG98a/M88enxpxY7mu595Ibmu+V4agctfnOxGNWrq+xd5kXyzpPvfdRZq1ZoMlkxXFoTlvuW+LFEZ6u+lO5XcsdEz/XkRFq7S+7O3J3k7TvSd564yeW0VUu8dSKVq+86GLm/tdiR+jzvfeO9q7w5Kvnb8me0Pkrzo/e8x/995WfOX02vXvfs9W/cr37l+eH+1eedfIRhYLw1Ntv/cnFP7Z1G6TpVh2Fgfuk5fc3vi+EFnDMMxlJXHYY7bBfrrOEOxUoHOXqvAcrZk2a/Ydk+k9K6siu+GPZQu3cphoYdc+Uy1OBS+YYBe3T1//ArNtsvXESdHl6y3N5l+Td5Tw031AuWyHsBNp/36le/cm+u6NH+lXkn32aW+UyZZMi9a685HAzFfaV3k2TPdP/2ullAZuldyT4TZUyT3XPOzLGf1zeTwHtLT+0sr3wzh70nhm+8/pw45Z0ZMajZybNW86sWX7OArzxxZ9nD64OJsybk8jy1RfNuZsTgzMiVSSB3ZoZvPHXOs8/EUXtmjpyZOeLCk3PeOjgx4sqKPatmeOrcLGALr80nPfhl4rgPZsG4mzj3tu4Rj81nwRrtyYuIj715PgnWgq73stcX1l03cdpqUmCTWVC+WUAuT73x1k5PjZoE7inLNrkeMnLvT4J125MbkV7FyvumV6979vpfTn1teD6+8gvmnXzDePHpYZyZP3l9sLLP2Fh/uCHGDpmXsqbvm/FUD2m+59xm3Tigu+ecPu00VuSM2noc9LNXV69c6X7jHmJGipPI98NC+UvjaFwgy1jI6U3kYZ97aT6XbDZ27NM1D3M+GG+oJo6VGtzXOeMefTsuzDNvnbHqwLhDHvYZw2MhLscXkGvRGtuH/8fBO6pLXzFWbJ7TaXwBNa7kfhgbtW0csO24o65SXpb0FuOg/JHebxw4exyoV33HxJpuTa/+2nDv/JNX9+s/dv93zifD11YYD15f+0zHJq+/Jq6zxlf2en31vXqmwnJ+ur49dpSck9u/PZ6TR9JFGlt5/7phr9f9tsvp7vHBUfL+KONrz7k5W3jiSHuv2k7xgeRvr5xWDJk6vf7y3ZEQOzk/5eT05lBxDCr+8MafNw+OBJ+s6f+6L+9zPvb4aGX89dfCNcCKbY8uVr5KsaLJmB17/TV3THnz0BuH3hyT7OCV05PDaVxrtvTkjpa33rVpXli56smxNHe73BdW/fTEk2WfLn3DkSBrpL7n7GQ9p3nlzSFJ39K8GzvjpuReS3MlEjtanYvU1mj/6B2L+M+TN5F7o7THye3R9Op1z743V+aTr/3c+u9mvmzO0eAXvHjOkb7PzW/GluPt9561fSHJNa7/Xw2aHOlzTo/ouZbu6RnLczXb9WXTpU26+MSS02vDkliJxmuXuR5/5GKnz1jOxUpXWa047CJ7O7a65rwWW5rdrRpVkk8ePSS/baImenTpKz48eS29i9RTzWYev5fW6RIZI+dqd0yfuddHDPU537rjPHOX9aTEf546UJIXnlra110a6Vm8+3hjztuTSH4oqVFemSwbeOtSNE67xI4nx9P3Ta9e9+x78y+Hg599Xr3+75rMFiyfp6/9fHGe9D33brnPLHNO7nvpWel+s4J10vuZ8X1JW9fcfqktKue+M+N9bs4sKLsUB5550f1zvpoZcswKdInEvEYuhjV9PPEzM3yU8+PMiHfLd7mcnjlsEvXzzLCfdVaXuEtzcFaQyzOHLlosV0LszoJxr+nnqb2eGjIrzIkS+80cdWrmrElt+0l3VdVBl5mR77Oe6s7MGePe+ziqqxXDkTy3fOGpszNnHElyWPkv2T+XV57YLL3TK+fdNgvmn5XnSxtH958FfGDdX7OC+LXuUOmOnhX0UFXBnTjrUB+Wc5teve7Z9+YDn9r/meeHV37ec4YtriTkxoeZddJYun7xvbr6b8vrpXMkuYYOeSVZvPMk27S+z3WS9vbaxppvyas9t2UcOs4RbLCmp8d/V3xx4Y0fV/xJcTJ0ynfl5+m2avt9aMSutd8VRw55uRKceyXgs9a8F3pfEfzvrSWevYdKPbDee3PJqofW+VeCfhTmrMVTe/xKZu6VzDurRlm5cKWsBpp17IrDBlGfep49vhwW+O6KUhOvOOv3Fafckftp6LThFaWWeWr1lcDdHcnLSF/gretXgnep5zxhjXrPavVy6Kyt3rhy9hzZmqPVxytOm1g5otQ78U6K3B3OOMvVVjUGrwRyY+j0oaB306vXPfve/MvstX+9Fvbfqv92ZpVm7HD/56zwycVY7nNJe276Pvcuup93rnZOw1K/KqNraovlPE2/dP/cWGXYLzfHY0vJPks/fjLjS80vub1SG1XGWo++Od9Z9pd0kdbl7JbaRbKdJ6Y13+RyRxqT1npzwpMPlZE77VyQfKLFfs7GlWGPnC9y+Sit+aQgcyXUMsk+WnxLfpHkkeTVZNDiwJMnks0i+Z++qwRfanKntojGkBR7Xrm1emzFgySbJ8el+LFqSu7ujdgtZ3MrfrQ6r9XpKnOnVEotkHJIuiOsevZJR13Q8tqyT+Wsm9LefdRx62627m1P/Gv9ihTPUl2Q7lJJr8p5D1p9nRbflaNHsPax5PDYULufLJ1zcTS58m80Pfve/MUfG/60808d/Kw5k9dWP5tfzS9pvh+9/m++eE4/2zRjyz3SvZfz2+/Tuc056XnpHu137fWSPNI+6Rxrz2bca4/2WPo+p3977XLv1Japb3L2s8bb8ufss1zb1jW3b1vG1OapTks9PPpI8ZiLL2tNTgfpXft96v/0zJxMS3uma9L56TspZqQcan+mc3JxKvlGinFPjmuxnLNpml+a73Lv0tzQak7OJlacemqatIdkm2V+WH7M1SbLvzl9Pf7K6eCpYdpebVlS33jtlsaSFEeST9M80+pWujbN23Q/6a6SakvuvsjVC6lOt+uypr+VD1IcL89s1i3JyS7lyfLMnK+W+yxl0u4QqdaldbYdW2nNzPkot6dVP6y4lGRtn9+WI3fnS/7M3Rs5H7djKe2NJHlzcazJKdVDzx2Yiw0pfq2a0N4jvS+luiLFr1SDpL4rFx85vSO9puQjT11c6jW7+tObBn5vPjB9/V+p/8dGfuac0eBn1H8Q/zPmn8uxJbnxo8X3o8U67Xu6dtSaM2rNS9+19xu1xkaZs9JzjpJ9pfPaMrXlbcuQ6pHKI3Ek2GyUyC2dM0rOydkiZ+tU1tz+OftI/vOOp/6x4mOUke1IsE1qu1wcjIz4kORI5TnKxMiRolPOD6kc6R6joF1zNpbeW7k6EmJPixHJhiPFV7l9c2daMa35L5dbuffaGsmHR0KsjRT/az6X/JSLbcm2Utzk/CzVQq1GanEv+XakrMvJNFLy2sqrXI0ZGe+lWmPViJFRu6SctvJX0m8k1CJPzT1y1FKpBki1SspXz/2hyTkS8u5I0X8kxM9ImDty3l9WnUx7I+0+PXLUnqPAXKmuHDn7n9y7nA4jIy6lO1Cr71q8S7U/51+tx2l/Hyk9z8gRkxG0O9+qW16bpbLPe/XXftbefHD8Zf/S+aj+c5nZglHrsz0+3f/XVsZz85bPzdz2/Jmwp/Z9uc9IOD933ijRIbdPun9uz5wtpLXts0cZ+8wydkz3y62XbJfaRNIvXTdK9sitHxk2ba+T1mv2as+fCXrOFDk1O44c56axmT637ZraJJUjlw+597PMO02/3Htp/kw5c5aRPc1l6dyREZuSz7VcsPJ4lpDuo9l2JOT5SKlX0pp2TMyMumjlvBTvyzPa4zmd0vcjpQaNnDXbG2ueOi/V7Jmwt1bzpZo2ct4bubix5uf8k47lcizn55lyRpoX1p65M2aO82dKnR0Z99fM6cOcnDnd2u+k+JTiRqrFM0cs5fQZKTFikbuntLos6T0T7qKZ4/6cZezjyY9RptZINsjFQq5W5+JW2sfqCaTaOlJ0ngl32kzpI0dCbfDeYWmsS7VBsv9M6Hm88bdc/0frXr3u2ffmA+P9f7H+n2/9aXOaX8U3n6PFZ4o0PhPGtbXtNek7z/ldZOxr/5FDb689pPfNZ26utn5k+LGr7F30mzl97d07FzszwWZ9+OWi9psFY2DmjK/S/a15s45+7WKfTcW2N/cj51u1b9TBLyUxta0470Mvyx+eGO+i1yZ8M9pCHEfvXW3tbIN1VpMvfc7NXd4FfdhoVNgbbfsu8dwJm6wpfdWiUfD+Wvr7Iv2zab83vXrds9eN+8+vA/vL/oX5r+AbRlf+1RfPEdrrPnX1X57jWZOb51nbVUYN7XzPu03J39636xmR9d65XrtJft+mrzd9fle/LHMotZsmvza/z/zYZE3o4qM+8rurz/o8bxsxurRZepbkr1wN2tVc2kSMlOjaZ93eRgzlYmGbdaNvW3W5C/qQoUss9d0f5e6Qktq8CT9uKo52KR+72qnp1esmfo8ffvjhhx9++OGHH3744Ycffvjhhx9++OGHH3746eHn/weWi3Du0oHPYwAAAABJRU5ErkJggg==);;
		background-size: 100% 460rpx;
		.concent{
			box-shadow: 0px 0px 7px 0px rgba(192, 192, 192, 0.35);
			margin-bottom: 20rpx;
			width: 100%;
			height: 230rpx;
			background-color: #FFFFFF;
			border-radius: 10rpx;
			display: flex;
			align-items: center;
			justify-content: space-between;
			.title{
				width: 80rpx;
				height: 30rpx;
				background: linear-gradient(30deg, #999999, #CCCCCC);
				border-radius: 4rpx;
			}
			.title1{
				width: 60rpx;
				height: 30rpx;
				background: linear-gradient(30deg, #FD4950, #FF6F60);
				border-radius: 4rpx;
			}
			.name{
				white-space: nowrap;
				text-overflow: ellipsis;
				overflow: hidden;
				word-break: break-all;
				width:400rpx ;
			}
			.btn{
				text-align: center;
				line-height: 60rpx;
				width: 250rpx;
				height: 60rpx;
				background: linear-gradient(30deg, #FD4950, #FF6F60);
				border-radius: 30rpx;
				font-size: 26rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: #FFFFFF;
			}
			.btn1{
				text-align: center;
				line-height: 60rpx;
				width: 250rpx;
				height: 60rpx;
				border: 1px solid #FD4950;
				background: #FFFFFF;
				border-radius: 30rpx;
				font-size: 26rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color:#FD4950;
			}
		}
	}
</style>
